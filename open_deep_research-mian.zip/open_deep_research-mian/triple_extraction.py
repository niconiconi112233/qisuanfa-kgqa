# import json
# from tqdm import tqdm
# import anthropic

# # ========= 配置 =========
# ANTHROPIC_API_KEY = "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"  # ← 修改为你的 Claude API Key
# INPUT_FILE = "/Users/yangjianxin/linked_diseases_all_0.7+.jsonl"
# OUTPUT_FILE = "linked_diseases_claude_filtered.jsonl"
# MODEL = "claude-3-7-sonnet-20250219"  # 或 claude-3-haiku / opus

# # ========= 初始化 Claude =========
# client = anthropic.Anthropic(api_key=ANTHROPIC_API_KEY)

# # ========= Claude 过滤函数 =========
# def filter_matches_with_claude(input_term, matches) -> dict | None:
#     joined_terms = "、".join([m['term'] for m in matches])

#     prompt = f"""这是我进行相似度匹配后的结果，请你判断原始术语与候选术语中的哪些不是同一类疾病（语义上等价或高度相似）：
# 原始术语：{input_term}
# 候选术语：{joined_terms}

# 如果有不是的，请你把它从候选术语中删除，并将剩余匹配项以如下 JSON 格式返回：

# {{
#   "input_term": "原始术语",
#   "matches": [
#     {{"term": "候选1", "score": 相似度 }},
#     ...
#   ]
# }}

# 如果剩下的都不相关，也请你返回一个空的 matches 列表。
# 只返回 JSON，其他任何注释或解释都不要写。"""

#     try:
#         response = client.messages.create(
#             model=MODEL,
#             max_tokens=1024,
#             temperature=0.2,
#             system="你是一个专业的宠物医学知识助手。",
#             messages=[
#                 {"role": "user", "content": prompt}
#             ]
#         )
#         text = response.content[0].text.strip()
#         filtered = json.loads(text)
#         if filtered.get("matches"):
#             return filtered
#         else:
#             return None  # 如果过滤后为空，则跳过写入
#     except Exception as e:
#         print(f"❌ Claude 调用失败: {e}")
#         return None

# # ========= 主流程 =========
# with open(INPUT_FILE, "r", encoding="utf-8") as fin, open(OUTPUT_FILE, "w", encoding="utf-8") as fout:
#     for line in tqdm(fin, desc="🤖 Claude 过滤中"):
#         data = json.loads(line.strip())
#         result = filter_matches_with_claude(data["input_term"], data["matches"])
#         if result:
#             fout.write(json.dumps(result, ensure_ascii=False) + "\n")

# print(f"✅ 筛选完成，结果保存至: {OUTPUT_FILE}")import json

import json
import pandas as pd

INPUT_JSONL = "linked_diseases_claude_filtered_fixed.jsonl"
OUTPUT_XLSX = "claude_entity_linking_result.xlsx"

rows = []

with open(INPUT_JSONL, "r", encoding="utf-8") as f:
    for line in f:
        data = json.loads(line.strip())
        input_term = data.get("input_term", "")
        match_terms = [m["term"] for m in data.get("matches", [])]

        # 构建一行数据，动态添加匹配列
        row = {"疾病库数据": input_term}
        for i, term in enumerate(match_terms):
            row[f"病例库匹配数据_{i+1}"] = term
        rows.append(row)

# 转为 DataFrame
df = pd.DataFrame(rows)

# 写入 Excel
df.to_excel(OUTPUT_XLSX, index=False)

print(f"✅ 已保存为 Excel：{OUTPUT_XLSX}")
