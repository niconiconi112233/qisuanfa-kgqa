#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import pandas as pd

# ===== 配置 =====
EXCEL_FILE = "/Users/yangjianxin/Downloads/open_deep_research-mian/src/疾病诊断库xlsx.xlsx"
DISEASE_COLUMN = "英文名全称"
COMMONNESS_COLUMN = "常见性（5最高）"
ALLOWED_EXTS = {".md", ".MD", ".markdown", ".mkd"}
OUTPUT_TXT = "unmatched_diseases.txt"

def to_basename(name: str) -> str:
    """与保存时一致：只替换斜杠、strip、lower"""
    return name.replace("/", "_").strip().lower()

def list_md_basenames_curdir() -> set:
    """列出当前目录所有 md 文件（去后缀、lower）"""
    ret = set()
    for fn in os.listdir("."):
        base, ext = os.path.splitext(fn)
        if ext in ALLOWED_EXTS:
            ret.add(base.strip().lower())
    return ret

def main():
    # 读取 Excel 并筛选
    df = pd.read_excel(EXCEL_FILE)
    df = df[df[COMMONNESS_COLUMN] == 4]  # 只取常见性==4
    diseases = (
        df[DISEASE_COLUMN]
        .dropna()
        .astype(str)
        .unique()
        .tolist()
    )

    # 当前目录已存在的 md 基名集合
    md_bases = list_md_basenames_curdir()

    # 匹配（使用与保存一致的命名规则）
    unmatched = []
    matched = 0
    for d in diseases:
        key = to_basename(d)
        if key in md_bases:
            matched += 1
        else:
            unmatched.append(d)

    # 输出结果
    print(f"Excel疾病数(常见性==4)：{len(diseases)}")
    print(f"当前目录 Markdown 数：{len(md_bases)}")
    print(f"已匹配：{matched}  未匹配：{len(unmatched)}")
    print("\n未匹配疾病（示例前20条）：")
    for x in unmatched[:20]:
        print(" -", x)

    # 保存到文件
    with open(OUTPUT_TXT, "w", encoding="utf-8") as f:
        for x in unmatched:
            f.write(f"{x}\n")
    print(f"\n✅ 未匹配清单已保存：{OUTPUT_TXT}")

if __name__ == "__main__":
    main()
