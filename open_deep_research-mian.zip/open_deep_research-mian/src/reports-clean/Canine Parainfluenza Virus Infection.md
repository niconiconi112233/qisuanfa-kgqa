# 犬副流感病毒感染

犬副流感病毒（CPIV）感染是小动物兽医临床中最重要的呼吸道病原体之一，是犬传染性气管支气管炎复合体的主要组成部分。这种高度传染性的RNA病毒表现出显著的稳定性和全球分布，特别影响犬舍、收容所和寄养设施等群居环境中的犬。本报告探讨了CPIV作为独立病原体和犬咳嗽关键辅助因素的作用，分析了其独特的"鹅鸣"咳嗽表现、与犬流感和博德特氏菌感染鉴别时的诊断挑战，以及包括新型口服疫苗接种方案在内的预防策略演变。通过对临床表现、治疗方法和预后因素的综合分析，本报告为兽医从业人员管理犬群呼吸道疾病爆发提供了重要见解。

## 疾病概述与流行病学

**定义**

犬副流感病毒（CPIV）感染是由犬副流感病毒引起的呼吸道疾病，该病毒分类于副粘病毒科（Paramyxoviridae）副粘病毒亚科（Paramyxovirinae）中的Rubulavirus属[1]。该病毒也称为猴病毒5（SV-5）或副流感病毒5，反映了其复杂的分类历史[3]。CPIV是一种球形至多形态的包膜RNA病毒，直径为150-200纳米，具有包含七个基因的单股负链RNA基因组[3]。

**流行病学背景**

近50年来，CPIV一直被认为是犬传染性气管支气管炎（犬咳嗽）的重要传染性辅助因素[3]。该病毒在犬舍、收容所和寄养设施等密切圈养环境中的犬之间表现出高度传染性[6]。20世纪60年代和70年代的经典流行病学研究确定，当犬在犬舍环境中混养时，CPIV是呼吸道疾病爆发中最常见的病原体[3]。

该病毒表现出显著的遗传稳定性，30年来从不同国家收集的分离株之间的序列变异最小（0-3%）[3]。CPIV在全球分布，影响所有年龄段的犬，幼犬特别容易发生严重疾病表现[6]。传播通过直接的犬与犬接触和气溶胶发生，病毒在环境中可存活有限时间，但容易被常用消毒剂灭活[3]。

### Sources
[1] AVMA Reference Point - Characteristics of CPIV: https://avmajournals.avma.org/downloadpdf/view/journals/javma/240/3/javma.240.3.273.pdf
[3] A review of canine parainfluenza virus infection in dogs: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[6] Kennel Cough - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 病因学与临床表现

犬副流感病毒（CPIV）是Rubulavirus属、副粘病毒亚科中的单股RNA病毒[1]。CPIV是犬传染性气管支气管炎复合体的主要病原体，通常与继发性细菌病原体（特别是支气管败血波氏杆菌*Bordetella bronchiseptica*）共同发生[1][2]。这种协同关系导致的呼吸道疾病比单独感染任一病原体更为严重[1]。

CPIV表现出广泛的细胞嗜性，通过其血凝素-神经氨酸酶蛋白结合呼吸道上皮细胞上的唾液酸残基[2]。该病毒优先靶向纤毛呼吸道上皮，导致纤毛停滞并损害粘液纤毛清除机制[1][2]。

临床表现通常在暴露后5-10天出现，包括特征性的"鹅鸣"咳嗽，常伴有干呕和咳痰[3]。在无并发症的感染中，犬可能表现为轻微的上呼吸道症状，包括浆液性鼻分泌物和咽炎[2]。然而，与细菌病原体的混合感染常导致粘脓性鼻和眼分泌物、发热，并可能发展为肺炎[1]。生活在拥挤环境中的幼犬发生严重疾病表现的风险最大[1][4]。

### Sources
[1] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[2] A review of canine parainfluenza virus infection in dogs in: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[3] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[4] Canine infectious respiratory disease: Challenges and: https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings

## 诊断方法与鉴别诊断

犬副流感病毒感染的诊断主要依靠临床表现和实验室检测，因为仅凭临床症状无法将其与其他呼吸道病原体区分[1]。PCR检测是最可靠的诊断方法，应在临床症状出现后1-2天内进行，即在病毒排毒停止之前[2][3]。口咽和鼻拭子在含盐水的无菌管中收集用于PCR检测，或在病毒运输培养基中收集用于病毒分离[3]。

发病4天后，使用血凝抑制（HI）的血清学检测变得更加可靠。最好在10-14天内采集配对的急性期和恢复期血清样本，抗体滴度增加四倍可确认感染[3]。胸部X光片有助于评估疾病严重程度并排除肺炎，但在无并发症的上呼吸道病例中通常正常[7]。

**鉴别诊断**包括多种临床表现重叠的呼吸道病原体[1][5]。主要的鉴别诊断包括支气管败血波氏杆菌*Bordetella bronchiseptica*、犬流感病毒（H3N8/H3N2）、犬腺病毒-2、支原体*Mycoplasma*属和犬呼吸道冠状病毒[1][5]。犬流感通常潜伏期较短，可能比副流感引起更严重的全身症状[1]。波氏杆菌感染通常表现为更持久的咳嗽，并有继发性细菌并发症的可能[6]。

混合感染在犬传染性呼吸道疾病复合体中很常见，没有全面的呼吸道PCR检测板很难确定病原体[5]。近期接触其他犬的临床史和特征性的"鹅鸣"咳嗽支持诊断[7]。

### Sources

[1] Canine influenza and the current outbreak: 10 takeaways: https://www.dvm360.com/view/canine-influenza-and-current-outbreak-ten-takeaways
[2] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings-0
[3] Clinical Signs & Diagnosis of Canine Influenza: https://www.dvm360.com/view/clinical-signs--diagnosis-of-canine-influenza
[4] A review of canine parainfluenza virus infection in dogs in: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[5] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-animal-shelters
[6] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[7] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 治疗选择与预防措施

### 治疗选择

犬副流感病毒感染通常需要支持性护理而非特定的抗病毒治疗[1]。传染性气管支气管炎（"犬咳嗽"）的治疗围绕支持性护理，大多数病例在1-3周内自行缓解[1]。

对于收容所或寄养环境中的犬，通常需要抗生素治疗以预防继发性细菌感染。当怀疑波氏杆菌感染时，多西环素和增效磺胺是相对较好的经验性选择[1]。对于病毒性呼吸道疾病后的继发感染，头孢氨苄、氟喹诺酮类或阿莫西林克拉维酸可能更有效[1]。

支持性护理包括减少吠叫和使用胸背带而非项圈以避免气管压力[1]。每天三至四次使用盐水溶液雾化是安全的，可能对患有呼吸道感染的犬有益[1]。镇咳药通常不适用或效果不佳[1]。抗病毒治疗（奥司他韦）既未被批准也不推荐用于副流感病毒感染的犬[8]。

### 预防措施

**疫苗接种方案**：核心犬疫苗接种方案包括在入院时接种改良活犬瘟热、肝炎、副流感和细小病毒（DHPP）疫苗[1]。幼犬应在4-8周龄开始接种，每2-4周加强一次，直到16-18周龄[1]。鼻内和注射用波氏杆菌疫苗均可提供额外保护[1]。新型口服疫苗（Nobivac Intra-Trac Oral BbPi）可同时预防犬副流感病毒和支气管败血波氏杆菌[9]。

**环境控制**：有效的疾病控制需要使用适当的消毒剂进行适当的卫生消毒、通过减少拥挤来减轻压力，以及及时隔离有症状的动物[1]。受影响的动物应与其他犬隔离，犬舍应使用有效消毒剂彻底清洁[1]。犬流感病毒可在环境中存活1-2天，但很容易被常用消毒剂杀死[8]。

### Sources

[1] Non-core vaccines: FIP, canine corona, Lyme disease, and Bordetella (Proceedings): https://www.dvm360.com/view/non-core-vaccines-fip-canine-corona-lyme-disease-and-bordetella-proceedings
[2] Canine infectious respiratory disease complex: https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[3] Canine vaccine update (Proceedings): https://www.dvm360.com/view/canine-vaccine-update-proceedings
[4] Controlling disease transmission in animal shelters: Part 2 (Proceedings): https://www.dvm360.com/view/controlling-disease-transmission-animal-shelters-part-2-proceedings
[5] Inhalant therapy: Finding its place in small-animal practice: https://www.dvm360.com/view/inhalant-therapy-finding-its-place-small-animal-practice
[6] Managing upper airway disease (Proceedings): https://www.dvm360.com/view/managing-upper-airway-disease-proceedings
[7] Merck Veterinary Manual Canine Influenza (Flu) - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/canine-influenza-flu
[8] Miscellaneous Antiviral Agents Used in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/antiviral-agents/miscellaneous-antiviral-agents-used-in-animals
[9] New oral vaccine is launched for prevention of 2 canine respiratory pathogens: https://www.dvm360.com/view/new-oral-vaccine-is-launched-for-prevention-of-2-canine-respiratory-pathogens

## 预后与临床结果

无并发症的犬副流感病毒（CPIV）感染的预后极好，大多数病例是自限性的，无需特定治疗即可恢复[1]。在实验性感染中，犬通常仅表现出持续3-5天的轻微上呼吸道症状，在感染后12-14天内出现临床改善[1]。

然而，几个因素显著影响临床结果。与其他呼吸道病原体（如支气管败血波氏杆菌或犬腺病毒）混合感染的CPIV犬比单独CPIV感染经历更严重和更持久的呼吸道疾病[1]。幼犬（2-3个月大）特别容易发生气道高反应性和肺功能降低，这些可能在临床恢复后持续数周[1]。

长期呼吸道并发症可能发生，特别是在有混合感染的幼犬中。研究表明，CPIV与其他病原体的双重感染可导致慢性气道炎症，包括闭塞性细支气管炎，持续超过6个月[1]。此外，感染的犬可能对组胺产生短暂的气道高反应性，与临床症状过程平行，但可能持续2-3周[1]。

大多数犬从无并发症的CPIV感染中完全恢复并产生持久的免疫力。单独CPIV的死亡率极低，死亡通常仅发生在非常年幼或免疫功能低下动物的严重并发症或并发感染情况下[1]。兽医应监测嗜睡、发热、呼吸困难和打喷嚏作为预后不良的指标[2]。

### Sources
[1] A review of canine parainfluenza virus infection in dogs: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[2] an observational survey using dog o - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0133/ajvr.25.04.0133.pdf
