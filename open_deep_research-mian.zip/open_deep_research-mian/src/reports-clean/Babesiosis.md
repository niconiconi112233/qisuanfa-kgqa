# 伴侣动物的巴贝斯虫病

巴贝斯虫病是兽医临床中影响犬和猫的一种重要的新兴蜱传疾病。该病由*巴贝斯虫属*的红细胞内原虫寄生虫引起，临床表现从亚临床携带状态到危及生命的溶血性贫血不等。本报告检查了主要致病种类，包括*犬巴贝斯虫 vogeli亚种*、*吉布森巴贝斯虫*和*猫巴贝斯虫*，它们的临床表现从轻微嗜睡到多器官功能障碍综合征等严重并发症不等。关键诊断方法包括血涂片检查和PCR检测，而治疗方案主要围绕二丙酸咪唑苯脲和联合疗法展开。预防策略主要集中在全面的蜱虫控制上，因为疫苗选择仍然有限。了解物种特异性预后因素以及与其他蜱传疾病的鉴别诊断对获得最佳患者预后至关重要。

## 预后

巴贝斯虫病的预后关键取决于早期诊断和及时治疗，物种特异性差异显著影响结果。*犬巴贝斯虫 vogeli亚种*通常引起轻度至中度疾病，恢复率良好，而*吉布森巴贝斯虫*感染的预后更为谨慎，尽管经过治疗，经常导致慢性携带状态。加利福尼亚分离株表现出特别严重的结果，死亡率接近60%。

| 因素 | 良好预后 | 谨慎预后 |
|--------|-------------------|-------------------|
| 物种 | *犬巴贝斯虫 vogeli亚种* | *吉布森巴贝斯虫*、加利福尼亚分离株 |
| 宿主年龄 | 健康成年犬 | 幼犬、免疫功能低下 |
| 治疗时机 | 早期干预 | 延迟治疗 |
| 品种 | 大多数品种 | 美国比特犬（*吉布森巴贝斯虫*） |

宿主因素包括年龄和免疫状态显著影响恢复潜力，幼犬和免疫功能低下的动物面临更高的死亡风险。许多犬发展为慢性携带状态，特别是*吉布森巴贝斯虫*感染，需要长期监测潜在的复发和继发并发症，包括肾小球肾炎和血管炎。

## 疾病概述

巴贝斯虫病是一种由*巴贝斯虫属*的红细胞内原虫寄生虫感染引起的临床疾病，这些寄生虫属于顶复门、梨形虫目[1]。这些血液寄生虫由硬蜱传播，是小动物兽医临床中一种重要的新兴传染病[2,4]。

该疾病影响犬和猫，裂殖子（梨浆虫）侵入红细胞并在其内繁殖，主要通过免疫介导机制引起溶血性贫血[1,2]。*巴贝斯虫属*存在100多个物种，其中几个物种专门影响伴侣动物，包括*犬巴贝斯虫 vogeli亚种*、*吉布森巴贝斯虫*和*猫巴贝斯虫*[1,7]。

巴贝斯虫病在全球范围内的分布取决于蜱媒的地理范围，特别是*血红扇头蜱*（棕色犬蜱）和其他硬蜱种类[1,7]。病理生理学涉及红细胞入侵，随后是血管内和血管外溶血，自身凝集和继发性免疫介导破坏导致临床表现[2]。

疾病严重程度差异很大，从亚临床携带状态到危及生命的急性表现，伴有严重贫血、血红蛋白尿和系统性并发症。过去十年中，美国犬和猫的几种蜱传疾病似乎正在出现，包括巴贝斯虫病，报告频率有所增加[4]。

### Sources
[1] Babesiosis in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/blood-parasites/babesiosis-in-animals
[2] Parasites of red blood cells: Babesia and Mycoplasma (Proceedings): https://www.dvm360.com/view/parasites-red-blood-cells-babesia-and-mycoplasma-proceedings
[3] Zoonotic Implications of Changing Tick Populations: https://www.dvm360.com/view/zoonotic-implications-of-changing-tick-populations
[4] Three emerging vector-borne diseases in dogs and cats in the United States: https://www.dvm360.com/view/three-emerging-vector-borne-diseases-dogs-and-cats-united-states
[5] Babesia rapidly emerging parasite in the United States: https://www.dvm360.com/view/babesia-rapidly-emerging-parasite-united-states
[6] Canine babesiosis continues to create challenges for practitioners: https://www.dvm360.com/view/canine-babesiosis-continues-create-challenges-practitioners
[7] Table: Zoonotic Diseases: Parasitic Diseases - Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/zoonotic-diseases-parasitic-diseases

## 常见病原体

犬和猫的巴贝斯虫病由几种基因上不同的巴贝斯虫物种引起，每种都有特定的媒介关系和地理分布。在犬中，大型巴贝斯虫物种包括犬巴贝斯虫的三个亚种：*犬巴贝斯虫 vogeli亚种*（由*血红扇头蜱*传播，全球分布）、*犬巴贝斯虫 canis亚种*（由网纹革蜱传播，主要在欧洲）和*犬巴贝斯虫 rossi亚种*（由李氏血蜱传播，南非特有）[1]。这些亚种的致病性差异显著，*犬巴贝斯虫 rossi亚种*毒力最强[1]。

影响犬的小型巴贝斯虫物种包括*吉布森巴贝斯虫*，全球分布，由血蜱属蜱虫传播[1]。此外，一种最初称为*吉布森巴贝斯虫*但现在称为"西方梨浆虫"的基因上不同的生物体已在加利福尼亚南部被鉴定，但其媒介仍未知[1]。第三种小型梨浆虫，暂命名为*泰勒虫 annae种*，是西班牙特有的，怀疑由六角硬蜱传播[1]。

猫巴贝斯虫病主要由*猫巴贝斯虫*引起，主要在非洲南部报告，以及*狮巴贝斯虫*和*lengau巴贝斯虫*[2]。这些猫科巴贝斯虫物种表现出不寻常的特征，包括对常规杀巴贝斯虫药物治疗的耐药性[2]。

### Sources
[1] Three emerging vector-borne diseases in dogs and cats in the United States: https://www.dvm360.com/view/three-emerging-vector-borne-diseases-dogs-and-cats-united-states
[2] Babesiosis in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/blood-parasites/babesiosis-in-animals

## 临床症状和体征

犬巴贝斯虫病表现出一系列临床表现，从亚临床感染到危及生命的疾病。严重程度取决于多种因素，包括涉及的巴贝斯虫物种、动物年龄、免疫状态和并发感染[1]。

**急性疾病表现**
最常见的表现症状包括嗜睡、虚弱、厌食和苍白黏膜[2,3]。发热经常存在，通常达到≥106°F（41°C）[1]。由于寄生虫直接破坏红细胞和免疫介导的溶血，逐渐发展为贫血[6]。血小板减少从轻度到重度不等，可能独立于贫血发生[3,6]。

**严重形式和并发症**
最急性病例可进展为低血压休克、血管炎和多器官功能障碍综合征（MODS）[2,4]。临床症状可能包括血红蛋白尿、黄疸、脾肿大和淋巴结肿大[1,2]。中枢神经系统受累，特别是*牛巴贝斯虫*，可导致虚弱、定向障碍和虚脱，这是由于被寄生虫感染的红细胞在脑毛细血管中粘附所致[1]。尽管有严重的血小板减少，但很少观察到瘀点和瘀斑[6]。

**物种和品种差异**
在美国，*犬巴贝斯虫 vogeli亚种*通常引起亚临床感染，特别是在灵缇犬中[2,4]。相比之下，*吉布森巴贝斯虫*感染主要影响美国比特犬，通常引起更严重的临床疾病，伴有明显贫血和血小板减少[2,4]。小型巴贝斯虫物种通常比大型形式产生更严重的病理变化[4]。

**亚临床携带者**
许多受感染的犬保持无症状携带状态，高达46%的赛犬灵缇犬检测呈阳性但无临床症状[2]。这些携带者在免疫抑制、脾切除或应激后可能发展为临床疾病[6]。

### Sources
[1] Merck Veterinary Manual Babesiosis in Animals: https://www.merckvetmanual.com/circulatory-system/blood-parasites/babesiosis-in-animals
[2] DVM 360 Canine babesiosis (Proceedings): https://www.dvm360.com/view/canine-babesiosis-proceedings
[3] DVM 360 Babesiosis (Proceedings): https://www.dvm360.com/view/babesiosis-proceedings
[4] DVM 360 Canine babesiosis continues to create challenges for practitioners: https://www.dvm360.com/view/canine-babesiosis-continues-create-challenges-practitioners
[5] DVM 360 Update on babesiosis, leptospirosis in dogs: https://www.dvm360.com/view/update-babesiosis-leptospirosis-dogs
[6] DVM 360 Parasites of red blood cells: Babesia and Mycoplasma (Proceedings): https://www.dvm360.com/view/parasites-red-blood-cells-babesia-and-mycoplasma-proceedings

## 诊断方法

诊断犬巴贝斯虫病需要一种多方面的方法，结合临床评估和特定的实验室测试。最重要的诊断方法是血涂片显微镜检查，从业者应特别要求手动（非自动化）检查外周血涂片以检测红细胞内梨浆虫[1]。大型巴贝斯虫物种（*犬巴贝斯虫 vogeli亚种*）表现为4-5 μm成对、双叶的生物体，而小型物种（*吉布森巴贝斯虫*、*conradae巴贝斯虫*）表现为1-2 μm圆形到卵圆形、环形的寄生虫，单独存在于红细胞内[6]。因为被寄生虫感染的细胞在毛细血管血中可能更普遍，涂片最好从耳廓或甲床制作以提高检测灵敏度[6]。

可能需要多次血涂片检查，因为寄生虫血症可能是间歇性的[1]。离心后的血沉棕黄层检查提供了检测运动寄生虫的增强灵敏度，因为被寄生虫感染的细胞在离心的毛细血管管中刚好沉淀在白细胞下方[6]。常规实验室检查结果通常包括急性病例的溶血性贫血和血小板减少[1]。

使用间接荧光抗体（IFA）测试的血清学检测显示出高灵敏度，滴度≥1:80被认为是*犬巴贝斯虫*感染阳性，而*吉布森巴贝斯虫*感染通常看到滴度≥1:320[6]。然而，*犬巴贝斯虫*和*吉布森巴贝斯虫*在IFA测试上存在交叉反应，需要形态学区分，除非有PCR检测可用[6]。基于PCR的分子诊断与光学显微镜相比具有更高的灵敏度，特别是用于检测慢性感染和携带状态，尽管检测到生物体不一定表明活动性疾病[7]。

### Sources
[1] Clinical Overview of Babesiosis: https://www.cdc.gov/babesiosis/hcp/clinical-overview/index.html
[2] Babesiosis - Centers for Disease Control and Prevention: https://www.cdc.gov/dpdx/babesiosis/index.html
[6] Canine babesiosis (Proceedings): https://www.dvm360.com/view/canine-babesiosis-proceedings
[7] Babesiosis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/blood-parasites/babesiosis-in-animals

## 治疗选择

犬巴贝斯虫病的一线治疗是二丙酸咪唑苯脲，这是美国FDA批准的唯一用于此适应症的药物[1]。标准剂量是6.6 mg/kg肌肉或皮下注射，每两周重复一次，总共两到三次治疗[1]。用阿托品（0.022-0.04 mg/kg皮下注射）预处理有助于最小化胆碱能副作用，包括流涎、流泪和胃肠道症状[1][3]。

对于对二丙酸咪唑苯脲耐药的*吉布森巴贝斯虫*感染，阿托伐醌（13.5 mg/kg口服，每日三次，与高脂餐同服）和阿奇霉素（10 mg/kg口服，每日一次）联合治疗10天，显示出显著疗效，清除了83%治疗犬的寄生虫血症[1][3]。这种联合治疗很昂贵（每只犬300-900美元），但代表了消除*吉布森巴贝斯虫*感染的最有效治疗方法[3]。

在严重病例中，支持性护理至关重要。静脉输液治疗纠正脱水和酸中毒，而对于严重贫血的患者，输血可能是挽救生命的[3][4]。由于85%感染巴贝斯虫病的犬发展为免疫介导的溶血性贫血，Coombs测试阳性，皮质类固醇（泼尼松2 mg/kg每12小时一次）通常在抗原生动物治疗开始后控制溶血所必需的[3]。二脒那嗪虽然在美国未获得FDA批准，但以3.5 mg/kg肌肉注射治疗*犬巴贝斯虫*感染非常有效[2][3]。

### Sources

[1] Three emerging vector-borne diseases in dogs and cats in the United States: https://www.dvm360.com/view/three-emerging-vector-borne-diseases-dogs-and-cats-united-states
[2] Babesiosis in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/blood-parasites/babesiosis-in-animals
[3] Canine babesiosis (Proceedings): https://www.dvm360.com/view/canine-babesiosis-proceedings
[4] Babesiosis (Proceedings): https://www.dvm360.com/view/babesiosis-proceedings

## 预防措施

犬和猫巴贝斯虫病的有效预防主要集中在全面的蜱虫控制策略上。最重要的预防方法包括定期局部使用杀蜱剂，如氟虫腈，并在流行地区配合使用蜱项圈[1]。每日蜱虫检查并在24小时内及时移除可以防止疾病传播，因为病原体传播需要蜱附着2-3天[1][2]。

环境管理在预防中起着至关重要的作用。宠物主人应通过清除蜱虫滋生的灌木和碎屑来维护庭院。在高风险地区，可能需要专业杀蜱剂处理室外环境[2]。

目前，疫苗选择仍然有限。法国有一种疫苗（Pirodog）可提供对同源菌株5-8个月的保护，但对其他巴贝斯虫菌株无交叉保护[1]。美国没有商业上可用的疫苗。

献血者筛查在通过输血预防传播中至关重要。巴贝斯虫抗体滴度阳性的犬绝不应作为献血者，在流行地区，潜在献血者可能需要脾切除以揭示潜伏感染[1]。

犬舍管理需要积极的蜱虫控制计划，结合血清学检测、隔离协议和所有新动物引入前的治疗[1]。主人教育应强调全年一致的蜱虫预防而非间歇性治疗，因为不规律的保护可能会增加疾病风险[2]。

### Sources
[1] Canine babesiosis (Proceedings): https://www.dvm360.com/view/canine-babesiosis-proceedings
[2] Managing fleas, ticks and vector-borne diseases (Proceedings): https://www.dvm360.com/view/managing-fleas-ticks-and-vector-borne-diseases-proceedings

## 鉴别诊断

巴贝斯虫病必须与几种具有重叠临床体征的疾病区分开来。主要的鉴别考虑包括其他蜱传疾病、免疫介导疾病和肿瘤过程[1]。

**埃里希体病/无形体病**表现出类似的血小板减少和发热，但通常引起非再生性贫血而非再生性贫血。埃里希体病中的血小板缺乏巴贝斯虫病中见到的严重溶血成分[1]。PCR检测和血清学可以区分这些情况，尽管可能发生共同感染。

**落基山斑疹热**具有血小板减少和发热，但很少引起免疫介导的溶血性贫血。与巴贝斯虫病相比，落基山斑疹热的贫血通常是轻度的（PCV 25-30%）[1]。

**免疫介导的溶血性贫血（IMHA）**是最具挑战性的鉴别诊断。两种情况都表现为再生性贫血、球形红细胞和阳性Coombs测试（巴贝斯虫病中>85%）[1]。然而，巴贝斯虫病常显示品种易感性（灵缇犬易感*犬巴贝斯虫*，美国比特犬易感*吉布森巴贝斯虫*）和并发的高球蛋白血症[4]。

**淋巴瘤和其他造血系统肿瘤**可引起贫血和血小板减少，但缺乏急性溶血危象和红细胞内寄生虫的特异性显微镜检查结果[6]。

**关键鉴别特征**包括血涂片上直接观察到梨浆虫、PCR确认和品种特异性风险因素。巴贝斯虫病的免疫介导成分使其与原发性IMHA的区分特别具有挑战性，需要仔细评估旅行史、蜱虫暴露和特定诊断测试[1][4]。

### Sources

[1] Diagnosis, treatment of tick-borne diseases: https://www.dvm360.com/view/diagnosis-treatment-tick-borne-diseases
[2] Three emerging vector-borne diseases in dogs and cats in the United States: https://www.dvm360.com/view/three-emerging-vector-borne-diseases-dogs-and-cats-united-states
[3] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/infectious-diseases/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[4] Babesia rapidly emerging parasite in the United States: https://www.dvm360.com/view/babesia-rapidly-emerging-parasite-united-states
[5] The ticktock of ticks: https://www.dvm360.com/view/the-ticktock-of-ticks
[6] Immune-mediated hemolytic anemia: Understanding and diagnosing a complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-understanding-and-diagnosing-complex-disease

## 预后

犬巴贝斯虫病的预后根据几个关键因素差异很大。治疗时机至关重要，早期诊断和及时治疗可获得最佳结果[1][2]。感染物种显著影响预后，*犬巴贝斯虫 vogeli亚种*通常在大多数成年犬中引起轻度至中度疾病，而*吉布森巴贝斯虫*和加利福尼亚分离株的预后更为谨慎[1][2][3]。

宿主因素显著影响恢复潜力。幼犬和免疫功能低下的犬与健康的成年犬相比面临更高的死亡风险[1][3]。存在品种易感性，美国比特犬显示*吉布森巴贝斯虫*高患病率，尽管许多发展为亚临床携带状态[3]。

生存率因亚种而异很大。虽然*犬巴贝斯虫*感染通常对二丙酸咪唑苯脲治疗反应良好，但*吉布森巴贝斯虫*病例显示治疗耐药性，许多犬尽管经过治疗仍成为慢性携带者[2]。加利福尼亚分离株表现出特别差的结果，尽管经过治疗，死亡率仍接近60%[3]。

慢性携带状态经常发展，特别是*吉布森巴贝斯虫*感染。这些携带者可能经历周期性复发并作为疾病宿主[1][2]。长期并发症可能包括慢性肾小球肾炎、肝功能障碍和某些情况下的血管炎[1]。

早期使用适当的抗原生动物治疗显著改善预后，而延迟治疗与发病率和死亡率增加相关[2]。

### Sources
[1] Canine babesiosis continues to create challenges for practitioners: https://www.dvm360.com/view/canine-babesiosis-continues-create-challenges-practitioners
[2] Update on babesiosis, leptospirosis in dogs: https://www.dvm360.com/view/update-babesiosis-leptospirosis-dogs
[3] Babesia rapidly emerging parasite in the United States: https://www.dvm360.com/view/babesia-rapidly-emerging-parasite-united-states
