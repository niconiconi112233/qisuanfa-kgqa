# 伴侣动物的霍纳氏综合征

霍纳氏综合征是一种影响犬猫的神经系统疾病，源于控制眼部和面部肌肉功能的交感神经系统通路中断。本综合报告探讨了涉及该综合征的复杂三级神经元通路，从其起源于下丘脑，通过颈交感链到眼部结构。该病症表现为特征性体征，包括上睑下垂、瞳孔缩小、眼球内陷和第三眼睑抬高，但确定潜在病因需要系统性的诊断方法。报告涵盖了从创伤性损伤和中耳感染到手术并发症等多种病因，特别强调了金毛寻回犬和可卡犬的品种易感性，同时针对患病动物提出了即时管理策略和长期预后考量。

## 摘要

霍纳氏综合征代表了伴侣动物中一种复杂的神经系统疾病，具有多样化的潜在病因和可变的预后结果。该综合征的特征性四联征（上睑下垂、瞳孔缩小、眼球内陷和第三眼睑抬高）是由于从下丘脑到眼部结构任何部位的交感通路中断所致。创伤，特别是机动车事故，是最常见的可识别病因，而中耳感染则构成重大风险，尤其在猫中，由于其解剖学易感性。

| 方面 | 主要发现 |
|--------|-------------|
| 最常见病因 | 机动车创伤和臂丛神经损伤 |
| 品种易感性 | 特发性病例中的金毛寻回犬和可卡犬 |
| 诊断工具 | 用于病灶定位的苯肾上腺素测试 |
| 最佳预后 | 特发性病例，恢复时间为3-6周 |

治疗主要侧重于处理潜在病因而非症状管理，苯肾上腺素兼具诊断和治疗双重作用。预后因病因差异显著，特发性病例显示良好结果，而创伤性损伤则取决于神经损伤程度。成功的管理需要全面的诊断检查，包括先进的影像学和药理学测试，以区分病灶位置并指导适当的治疗干预。

## 疾病概述和病理生理学

霍纳氏综合征是一种神经系统疾病，特征是犬猫眼部及周围结构的交感神经支配中断[1]。该综合征源于从下丘脑和脑干开始的复杂三级神经元交感通路任何部位的损伤[2]。

交感通路始于下丘脑的第一级神经元，其通过脑干和颈脊髓下行，与C8-T7脊髓节段中的交感神经节前神经元形成突触[2]。第二级节前轴突通过颈部的交感干和迷走交感干到达颈上神经节。第三级节后纤维随后支配眼部结构[2]。

霍纳氏综合征影响各年龄段的犬猫，特发性节后疾病最常见于中老年金毛寻回犬和可卡犬[1]。该病症可由多种原因引起，包括创伤、中耳疾病、手术并发症和医源性原因[5][6]。犬的项圈约束和猫的食管造口管置入或鼓室骨切开术等手术代表了常见的医源性原因[1][2][5][6]。交感纤维与中耳等结构的解剖学邻近性使猫特别容易因中耳炎或手术并发症而发生霍纳氏综合征[4]。

### Sources
[1] Cranial nerve disorders in dogs (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings
[2] Clinical Exposures: Horner syndrome - esophagostomy tube placement complication: https://www.dvm360.com/view/clinical-exposures-horner-syndrome-esophagostomy-tube-placement-complication
[3] An update in feline endocrine diseases (Proceedings): https://www.dvm360.com/view/update-feline-endocrine-diseases-proceedings-0
[4] Feline nasopharyngeal polyps (Proceedings): https://www.dvm360.com/view/feline-nasopharyngeal-polyps-proceedings
[5] Cranial nerve disorders (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-proceedings
[6] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings

## 常见病因和风险因素

犬猫的霍纳氏综合征由多种病因引起，其中创伤是最常被识别的病因。机动车事故是主要的创伤因素，常导致臂丛神经根撕脱，从而中断交感通路[1]。该病症似乎与小动物的性别、品种或侧别偏好无关[1]。

**创伤性病因**
除车辆创伤外，手术并发症可引发霍纳氏综合征，特别是在涉及颈部或胸廓入口的手术后[6]。影响T1-T3节段的脊髓损伤可能损害交感神经根，导致同侧交感功能障碍[6]。

**感染性和炎症性病因**
中耳炎和内耳炎是伴侣动物霍纳氏综合征的重要原因[1][2][7]。中耳感染可影响通过鼓室的交感纤维，特别是当炎症扩展到周围神经结构时[2]。猫的腹侧鼓室含有一个隔，交感神经从中穿过，这使得猫在中耳疾病存在时特别容易发生霍纳氏综合征[7]。患有中耳炎/内耳炎的猫可能同时出现前庭体征、面神经麻痹和霍纳氏综合征[5]。

**肿瘤性病因**
颅内和胸腔肿瘤均导致霍纳氏综合征的发生[1][8]。猫的头颈部肿瘤，包括唾液腺腺癌，可通过局部浸润或压迫交感通路引起霍纳氏综合征[8]。

**特发性病例**
相当比例的病例仍为特发性，特别是中老年金毛寻回犬和可卡犬的节后霍纳氏综合征[3]。

### Sources
[1] Horner's syndrome in dogs and cats: 100 cases (1975-1985): https://avmajournals.avma.org/view/journals/javma/195/3/javma.1989.195.03.369.xml
[2] Horner's syndrome explained: https://www.dvm360.com/view/horner-s-syndrome-explained/1000
[3] Cranial nerve disorders (Proceedings) - dvm360: https://www.dvm360.com/view/cranial-nerve-disorders-proceedings
[4] Otitis Media and Interna in Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/ear-disorders-of-cats/otitis-media-and-interna-in-cats
[5] Unilateral Laryngeal Paralysis Secondary to Otitis Media ...: https://meridian.allenpress.com/jaaha/article/58/1/42/476084/Unilateral-Laryngeal-Paralysis-Secondary-to-Otitis
[6] Acute spinal cord injury - The first hour can make ... : https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[7] Feline nasopharyngeal polyps (Proceedings): https://www.dvm360.com/view/feline-nasopharyngeal-polyps-proceedings
[8] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings

## 临床体征和诊断方法

伴侣动物的霍纳氏综合征表现为典型的四联征，包括上睑下垂（上眼睑下垂伴眼裂变窄）、眼球内陷（眼球向眼眶内退缩）、第三眼睑（瞬膜）抬高和瞳孔缩小（瞳孔收缩）[1]。

其他体征反映交感神经去神经支配，包括由于外周血管扩张引起的同侧面红和皮肤温度升高[2]。在猫中，患侧耳廓可能明显充血，比对侧温暖9-13°F[2]。由于血管扩张和鼻组织硬度增加，可发生鼻塞[4]。

诊断方法侧重于病灶定位和识别潜在病因[7]。使用苯肾上腺素（0.25-1%溶液）的药理学测试作为α-肾上腺素能交感神经兴奋剂，在三级霍纳氏综合征诊断中作用于虹膜开大肌，模拟缺失的神经递质[9]。苯肾上腺素测试有助于区分病灶位置，尽管对兽医患者的具体方案需要谨慎应用[4]。

包括MRI和CT扫描的先进影像学检查可检测中枢神经系统病变或中耳病理[4]。耳镜检查对犬猫至关重要，因为中耳炎是霍纳氏综合征的常见原因[4]。

并发神经系统体征的存在有助于解剖学定位。伴有前庭功能障碍的同侧头倾斜提示中耳/内耳受累，而肢体轻瘫或精神状态改变则表明脑干病变[4]。霍纳氏综合征最常与外周前庭疾病相关，表明同侧眼部交感神经支配受累[10]。

### Sources

[1] Merck Veterinary Manual - Horner syndrome, llama: https://www.merckvetmanual.com/multimedia/image/horner-syndrome-llama
[2] DVM 360 - Clinical Exposures: Horner syndrome: https://www.dvm360.com/view/clinical-exposures-horner-syndrome-esophagostomy-tube-placement-complication
[3] DVM 360 - Horner's syndrome explained: https://www.dvm360.com/view/horner-s-syndrome-explained
[4] Merck Veterinary Manual - Facial Paralysis in Animals: https://www.merckvetmanual.com/nervous-system/facial-paralysis/facial-paralysis-in-animals
[5] Journal of the American Veterinary Medical Association - Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.03.0155.xml
[6] Merck Veterinary Manual - Inflammatory Disorders: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/inflammatory-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals
[7] DVM 360 - Cranial nerve disorders in dogs: https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings
[8] DVM 360 - Phenylephrine ingestion in dogs: https://www.dvm360.com/view/toxicology-brief-phenylephrine-ingestion-dogs-whats-harm
[9] Merck Veterinary Manual - Diagnostic Tests Pertaining to Ocular Medications in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/diagnostic-tests-pertaining-to-ocular-medications-in-animals
[10] DVM 360 - Neurologic syndromes: localizing a lesion: https://www.dvm360.com/view/neurologic-syndromes-localizing-lesion-proceedings

## 治疗和管理策略

伴侣动物霍纳氏综合征的治疗主要侧重于处理潜在病因而非综合征本身。由于霍纳氏综合征是一种由交感神经支配中断引起的神经系统疾病，成功的管理取决于识别和治疗根本原因[1]。

**诊断性苯肾上腺素测试**
苯肾上腺素滴眼液既是诊断工具也是症状治疗。眼部苯肾上腺素制剂专门用于霍纳氏综合征的诊断和分类，帮助兽医定位交感通路内的病灶[4]。该测试有助于确定病灶是节前还是节后，从而影响治疗计划。

**症状管理**
当用于治疗时，苯肾上腺素可通过引起瞳孔散大和血管收缩提供暂时的症状缓解[4]。然而，兽医在使用苯肾上腺素时必须谨慎，因为它可引起高血压和其他不良反应，特别是在犬中使用口服制剂时[4]。

**手术考量**
全耳道切除术和鼓室骨切开术（TECA-BO）通常导致暂时性霍纳氏综合征作为并发症，影响大多数患者[6]。这种暂时性状况通常随着愈合进展而解决，但恢复期间可能需要支持性护理。

**支持性护理**
治疗强调处理引起综合征的原发疾病过程。眼用润滑剂可能有益于预防因泪液减少引起的角膜并发症。根据潜在病因，可能需要疼痛管理和抗炎药物。

### Sources

[1] Horner's syndrome in dogs and cats: https://avmajournals.avma.org/view/journals/javma/195/3/javma.1989.195.03.369.xml
[4] Toxicology Brief: Phenylephrine ingestion in dogs: What's the harm?: https://www.dvm360.com/view/toxicology-brief-phenylephrine-ingestion-dogs-whats-harm
[6] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings

## 鉴别诊断和预后

**鉴别诊断**

几种疾病可能模拟霍纳氏综合征的临床体征。中耳疾病（中耳炎）可引起类似的眼部体征，但通常伴有额外的前庭症状，如头倾斜和眼球震颤[3]。面神经麻痹可能伴随霍纳氏综合征，但对面部表情和眼睑反射的影响不同[4]。三叉神经病变导致下颌下垂和咀嚼肌萎缩，这与霍纳氏综合征的眼部特异性体征不同[4]。

影响海绵窦或脑干的脑肿瘤可引起包括霍纳氏综合征在内的多发性颅神经缺陷，但这些病例通常表现为意识改变和姿势反应缺陷[4]。年轻金毛寻回犬的眼外肌炎可引起双侧眼球突出，可能被误认为眼球内陷，但缺乏霍纳氏综合征特征性的瞳孔缩小和第三眼睑抬高[4]。

**预后**

霍纳氏综合征的预后因潜在病因和神经损伤位置而异[5]。特发性病例通常在3-6周内显示自发性改善，许多动物完全康复[4]。创伤性损伤取决于神经损伤的严重程度--神经失用症（暂时性功能障碍）通常在1-2个月内解决，而轴突断伤或神经断伤可能导致永久性缺陷[2]。

继发于中耳感染的病例在潜在感染成功治疗时通常预后良好[3]。然而，手术引起的医源性病例可能根据交感干损伤程度有不同的结果[2]。猫比犬更容易在TECALBO等手术后发生霍纳氏综合征[1]。

### Sources

[1] Ocular examinations before and after total ear canal ablation: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.08.0533.xml
[2] Clinical Exposures: Horner syndromeAn esophagostomy tube placement complication: https://www.dvm360.com/view/clinical-exposures-horner-syndrome-esophagostomy-tube-placement-complication
[3] DVM 360 Cranial nerve disorders in dogs (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-proceedings
[4] DVM 360 Horner's syndrome explained: https://www.dvm360.com/view/horner-s-syndrome-explained
[5] Cranial nerve disorders (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-proceedings
