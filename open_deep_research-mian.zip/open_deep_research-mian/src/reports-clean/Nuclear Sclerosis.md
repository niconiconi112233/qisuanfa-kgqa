# 伴侣动物的核硬化

核硬化是兽医实践中最常被误解的眼部疾病之一，尽管它是正常的生理衰老过程，但经常与白内障混淆。这种与年龄相关的晶状体硬化几乎影响所有七岁以上的犬和猫，产生特征性的蓝灰色混浊，可能令宠物主人感到担忧。理解核硬化与病理性白内障之间的区别对于准确诊断、适当的客户教育和正确的治疗决策至关重要。本报告探讨了核硬化的临床表现、诊断方法和鉴别诊断，为兽医从业者提供必要知识，以便自信地将这种良性状况与威胁视力的晶状体疾病区分开来，并为年老的伴侣动物提供循证护理。

## 疾病概述

核硬化，也称为晶状体硬化，是犬和猫晶状体中发生的正常与年龄相关的生理变化[1]。这种情况代表衰老的必然结果，而非病理性疾病过程，影响晶状体核的透明度和密度。

核硬化在犬和猫约7岁时变得明显，尽管一些资料表明它可能早在8-10岁就开始[1]。这种情况同时同等地影响双眼，没有明显的品种或性别倾向[1]。然而，阳光照射可以加速晶状体的硬化变化[1]。

其潜在机制涉及一生中在皮层持续产生新的晶状体细胞，迫使较老的细胞向内朝向核移动[1][7]。随着晶状体纤维随着年龄增长变得更加紧密压缩，晶状体变得更致密和更硬，产生特征性的光散射和混浊[1]。这种混浊与晶状体结构内不溶性蛋白增加和可溶性蛋白减少有关，衰老导致不溶性蛋白与可溶性蛋白的比例增加[7]核硬化在环境光下呈现均匀的珍珠状不透明，带有灰色至蓝色色调，必须与白内障区分[1]。与白内障不同，核硬化不会显著损害视力，并且在后照明时完整的眼底反射仍然可见[1]。这种情况在年老的伴侣动物中是完全正常和普遍的。

### Sources
[1] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[2] The Lens in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals

## 临床症状和体征

核硬化表现为中央晶状体核的特征性蓝灰色混浊，呈现为"眼睛表面或晶状体的普遍混浊"[1]。这种情况在年老的犬和猫中双侧对称出现，通常表现为晶状体内的中央圆形灰色区域[2][3]。

区分核硬化与白内障的关键临床特征是，从业者在直接照明时可以直视透过混浊[1]。当使用后照明技术时，核硬化呈现为细微的混浊，而不是白内障特有的黑色或黑色外观[1]。直接检眼镜的裂隙束功能显示"在前和后晶状体囊之间增加的混浊"，与白内障中明显的不透明形成对比[1]。

核硬化在犬和猫约7岁时变得明显，动物在就诊时通常"至少8或10岁"[4]。重要的是，核硬化对视力影响最小，代表"老年动物中发生的核密度正常增加"[2][3]。这种与年龄相关的晶状体硬化使动物能够在可见的晶状体变化下保持功能性视力。

虽然品种和性别被认为与核硬化的发展无关，但阳光照射可以加速硬化变化[4]。这种情况应与幼犬的轻微晶状体缺陷和病理性白内障形成区分开来[2][3]。

### Sources
[1] Differentiating nuclear sclerosis from early cataracts during an ophthalmic exam: https://www.dvm360.com/view/differentiating-nuclear-sclerosis-from-early-cataracts-during-an-ophthalmic-exam
[2] The Lens in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
[3] Nuclear sclerosis and early cataract formation, dog-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/image/nuclear-sclerosis-and-early-cataract-formation-dog
[4] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis

## 诊断方法

核硬化诊断主要依赖于使用标准眼科设备的临床检查技术。使用局部托吡卡胺进行瞳孔扩张对于最佳晶状体评估至关重要[1]。最有效的诊断方法结合使用透照器或笔灯进行后照明和直接焦点照明[1]。

**后照明技术**
当存在核硬化而无白内障时，完整的眼底反射通过晶状体仍然可见，晶状体核的轮廓可能明显[1][3]。这种技术利用照膜反射，通过从不同角度观察眼睛来突出晶状体变化[1]。

**直接照明评估**
在直接照明下，核硬化呈现为允许光线穿透的普遍混浊，而白内障呈现亮白色并阻挡光线传输[4]。关键诊断区别是核硬化尽管有混浊但保持晶状体透明度[3]。

**裂隙灯生物显微镜**
裂隙灯生物显微镜代表晶状体检查的最佳方法[1][6]。使用直接检眼镜的裂隙束功能，临床医生可以观察到光束撞击角膜表面、前晶状体囊和后晶状体囊[4]。核硬化在这些光束之间显示增加的混浊，而白内障显示明显的不透明[4]。

患者年龄（通常8岁以上）、无显著视力缺陷和特征性后照明发现的组合强烈提示核硬化而非白内障[3]。

### Sources

[1] The Lens in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
[2] Getting ready for the eye patient (Proceedings): https://www.dvm360.com/view/getting-ready-eye-patient-proceedings
[3] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[4] Differentiating nuclear sclerosis from early cataracts during an ophthalmic exam: https://www.dvm360.com/view/differentiating-nuclear-sclerosis-from-early-cataracts-during-an-ophthalmic-exam
[5] Ophthalmic examinations should not be complicated or expensive: https://www.dvm360.com/view/ophthalmic-examinations-should-not-be-complicated-or-expensive
[6] Lens - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/lens?ruleredirectid=19

## 鉴别诊断

核硬化的主要鉴别诊断是白内障，因为两种情况都表现为晶状体不透明[1]。核硬化是晶状体核的正常与年龄相关的硬化和增厚，导致普遍混浊但允许光线传输[1]。相比之下，白内障是真正阻挡光线通过的病理性不透明[2]。

关键区分特征包括照明特性。当直接照明时，白内障呈现亮白色，而核硬化呈现混浊但保持半透明[1]。在后照明下（使用照膜反射），白内障呈现黑色或黑色，而核硬化保持混浊但可见的外观[1]。

使用裂隙束功能的裂隙灯生物显微镜提供明确的区分[1]。核硬化显示前和后晶状体囊束之间增加的混浊，而白内障呈现为明显的、清晰界定的不透明[1]。

其他需要区分的晶状体状况包括仅在生物显微镜下可见的幼犬轻微晶状体缺陷，以及表现为虹膜震颤（虹膜震颤）和无晶状体新月形的晶状体半脱位或脱位[2]。引起继发性晶状体变化的炎症状况可通过伴随的葡萄膜炎体征来区分。

临床意义在于预后和治疗：核硬化不需要干预，通常保持功能性视力，而白内障可能进展导致显著视力损害，需要手术管理[2]。

### Sources

[1] Differentiating nuclear sclerosis from early cataracts during an ophthalmic exam: https://www.dvm360.com/view/differentiating-nuclear-sclerosis-from-early-cataracts-during-an-ophthalmic-exam

[2] The Lens in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
