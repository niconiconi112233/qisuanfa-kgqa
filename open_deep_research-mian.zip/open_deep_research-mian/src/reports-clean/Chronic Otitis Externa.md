# 伴侣动物的慢性外耳炎

慢性外耳炎是小动物兽医临床中最常见的疾病之一，影响10-20%到兽医诊所就诊的犬，并且在大多数情况下需要终身管理而非治愈。这种外耳道的持续性炎症造成了复杂的诊断和治疗挑战，因为它通常涉及多种病原体，包括葡萄球菌属、铜绿假单胞菌和厚皮马拉色菌，它们在感染和炎症的循环中共同作用。

本报告探讨了慢性外耳炎的多方面性质，从其流行病学模式（显示可卡犬和长耳品种存在品种易感性）到先进的诊断方法（包括视频耳镜检查和细胞学检查）。分析涵盖了全面的治疗策略，从局部抗菌药物组合到TECA-LBO（全耳道切除术与侧壁鼓室骨切除术）的手术干预，同时强调了识别潜在过敏病因的关键重要性，这些病因导致了43%的慢性病例。

## 摘要

慢性外耳炎是一种复杂的兽医疾病，需要全面了解其原发性病因、继发性感染和持续因素。流行病学数据显示了显著的品种易感性，可卡犬表现出独特的炎症反应，而长耳品种则面临更高的风险。过敏性疾病驱动了43%的慢性病例，而细菌和真菌病原体则造成继发性并发症，将可控的疾病转变为慢性状态。

| 方面 | 关键发现 |
|--------|-------------|
| **原发性病因** | 过敏（占病例的43%）、寄生虫、内分泌疾病 |
| **常见病原体** | 葡萄球菌（急性）、铜绿假单胞菌（慢性）、马拉色菌 |
| **诊断金标准** | 视频耳镜检查结合细胞学检查 |
| **治疗成功率** | 取决于控制潜在病因和早期干预 |
| **手术选择** | TECA-LBO适用于终末期、药物治疗无效的病例 |

诊断方法强调细胞学检查和视频耳镜检查以准确识别病原体，而治疗策略则结合局部抗菌药物，并在有指征时使用全身治疗。预后因潜在病因的识别和早期干预而有很大差异，慢性病例需要终身管理。成功的治疗结果取决于解决原发性过敏状况、保持适当的耳部卫生以及实施同时针对感染和炎症的综合治疗方案。

## 疾病概述与常见病原体

**定义**
慢性外耳炎是犬猫外耳道上皮的持续性炎症，其特征是反复的感染和炎症循环，导致获得性病理变化[1]。这种情况是小动物就诊兽医的最常见原因之一，外耳炎影响大约10-20%到兽医诊所就诊的犬[2]。

**流行病学背景**
发病率最高的是5-8岁年龄段，长耳品种（史宾格犬、寻回犬、德国牧羊犬）表现出较高的易感性[2]。在慢性病例中，感染常常蔓延至中耳，研究报告称，多达83%的慢性外耳炎犬存在中耳炎[3]。猫的外耳炎诊断较少见，与犬相比，约占病例的2-6%[6]。

**原发性和继发性病因**
原发性病因在正常耳朵中引发疾病，包括过敏（食物反应、特应性皮炎）、寄生虫（耳螨、蠕形螨）、内分泌疾病和异物[1]。过敏性疾病是最常见的原发性病因，占43%的慢性外耳炎病例[10]。继发性病因在异常的耳朵中发展，包括细菌感染（葡萄球菌属、铜绿假单胞菌）和酵母菌过度生长（厚皮马拉色菌）[1]。

**细菌病原体**
葡萄球菌属是急性感染中最常见的病原体，而铜绿假单胞菌在慢性病例中占主导地位[3]。铜绿假单胞菌感染尤其具有挑战性，表现出对多种抗菌药物的耐药性，并与溃疡性病变和脓性分泌物相关[3]。在猫中，凝固酶阴性葡萄球菌更为常见，而铜绿假单胞菌则很少见[6]。

**真菌病原体**
厚皮马拉色菌是主要的酵母菌病原体，常在外耳炎中大量繁殖，并且通常与特应性疾病相关[2]。这种生物体可能引起超敏反应，即使数量很少也具有临床意义[2]。几项研究表明，马拉色菌在猫的外耳炎中尤其成问题[6]。

**寄生虫病原体**
耳痒螨在猫中比在犬中更为重要，并且可能与顽固性耵聍性外耳炎中局部蠕形螨属的增殖有关[1]。猫的蠕形螨可引起慢性轻度耵聍性外耳炎，而无皮肤病变[2]。

### Sources

[1] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
[3] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[4] Otitis externa sometimes complicated, frustrating: https://www.dvm360.com/view/otitis-externa-sometimes-complicated-frustrating
[5] Otitis: Inside look at pathogenesis, treatment and prevention: https://www.dvm360.com/view/otitis-inside-look-pathogenesis-treatment-and-prevention
[6] Otitis in cats: what is different from dogs (Proceedings): https://www.dvm360.com/view/otitis-cats-what-different-dogs-proceedings
[7] Banfield releases major veterinary study showing spike in diabetes, dental disease and otitis externa: https://www.dvm360.com/view/banfield-releases-major-veterinary-study-showing-spike-diabetes-dental-disease-and-otitis-externa
[8] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
[9] Feline otitis (Proceedings): https://www.dvm360.com/view/feline-otitis-proceedings
[10] Ears an

## 临床症状与诊断方法

慢性外耳炎表现出多样的临床表现，需要系统的诊断评估。摇头、耳部瘙痒和恶臭分泌物是其标志性体征[1]。疼痛可能表现为不愿张口或在操作耳朵时敏感[3]。进行性的病理变化包括慢性病例中的角化过度、增生、棘层肥厚和耳道狭窄[3]。

不同物种的表现模式存在差异。在犬中，外耳炎影响3.5%的普通犬群，但占兽医就诊犬的10-20%，高发年龄在5-8岁之间[3]。某些品种表现出易感性，特别是长耳犬，包括史宾格犬、寻回犬和德国牧羊犬[3]。可卡犬表现出旺盛的炎症反应，伴有快速进展的耵聍腺增生，而非典型的纤维化变化[9]。在猫中，外耳炎较不常见，约占猫科动物兽医就诊的5%，而犬科动物为15%[5]。

诊断评估始于全面的耳镜检查，通常需要镇静以获得充分的视野[3]。使用棉签涂片和Diff-Quik染色的细胞学检查用于评估上皮细胞、细菌形态（杆菌与球菌）和马拉色菌数量[3]。取样应针对水平耳道与垂直耳道的交界处，以获得最佳的诊断效果[10]。

与手持式耳镜检查相比，视频耳镜提供了更优越的观察和记录能力[3,10]。当怀疑存在中耳受累、肿瘤或慢性病例时，可能需要进行包括CT扫描在内的先进影像学检查[3,8]。

### Sources
[1] Quick update: What to know about allergic otitis in cats: https://www.dvm360.com/view/quick-update-what-know-about-allergic-otitis-cats
[2] Hydrolyzed protein diets (Sponsored by Nestlé Purina): https://www.dvm360.com/view/when-pieces-are-better-whole-hydrolyzed-protein-diets-sponsored-nestl-purina
[3] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
[4] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
[5] Computed tomography and its uses in veterinary medicine (Proceedings): https://www.dvm360.com/view/computed-tomography-and-its-uses-veterinary-medicine-proceedings
[6] How to love and care for cocker spaniel ears (Proceedings): https://www.dvm360.com/view/how-love-and-care-cocker-spaniel-ears-proceedings
[7] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause

## 治疗选择与预防措施

慢性外耳炎的治疗需要多方面的方法，既要处理活动性感染，也要解决潜在病因[1]。局部治疗是治疗的基石，通常根据细胞学检查结果，结合使用抗菌剂、抗真菌剂和糖皮质激素[2]。大多数商业制剂包含抗生素（氨基糖苷类、氟喹诺酮类）、抗真菌药（咪康唑、克霉唑）和抗炎剂的组合，以溶液或混悬液形式提供[4]。

当耳道增生、增殖、糜烂、溃疡或存在中耳炎时，需要使用全身性抗菌药物[5]。对于耐药性铜绿假单胞菌感染，优选氟喹诺酮类药物，如恩诺沙星（10-20 mg/kg/日）或马波沙星（4-5.5 mg/kg/日）[5]。全身性糖皮质激素有助于减轻炎症、狭窄和水肿，初始剂量为泼尼松龙1-2 mg/kg/日[3,5]。

专业的耳部清洁至关重要，因为不清除碎屑就直接治疗感染往往会导致失败[6]。其主要目的是清除过多的耵聍、微生物和毒素以及炎症介质，使药物能直接与上皮接触[6]。

对于对药物治疗无效的终末期疾病，手术干预成为必要。全耳道切除术与侧壁鼓室骨切除术（TECA-LBO）为严重受损的耳朵提供了根治性治疗[7]。

维护性护理包括使用合适的清洁剂定期清洁耳朵、环境控制以防止水分积聚，以及解决过敏等易感因素[3]。通过适当的耳部卫生和管理潜在的过敏性疾病进行预防，是减少慢性外耳炎复发的最有效方法。

### Sources

[1] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[3] Managing otitis externa (Proceedings): https://www.dvm360.com/view/managing-otitis-externa-proceedings
[4] How to improve your outcome in otitis externa cases: https://www.dvm360.com/view/straight-sewer-ear-how-improve-your-outcome-otitis-externa-cases
[5] A powerful tool for addressing inflammation early in dogs with otitis externa: https://www.dvm360.com/view/a-powerful-tool-for-addressing-inflammation-early-in-dogs-with-otitis-externa

## 鉴别诊断与预后

### 鉴别诊断

慢性外耳炎的临床表现与多种疾病有重叠，因此准确的鉴别诊断至关重要。单侧性外耳炎常提示异物、肿瘤（特别是耵聍腺肿瘤）或息肉[1]。双侧性表现通常表明过敏性疾病，特应性皮炎是一个主要的鉴别诊断，在3-5%的特应性病例中，外耳炎可能是唯一的症状，并且可以表现为单侧[5][6]。食物过敏在高达20%的病例中可仅表现为外耳炎[3]。

鉴别因素包括揭示特定微生物和炎症模式的细胞学检查。溃疡的存在提示革兰氏阴性细菌感染，特别是铜绿假单胞菌[4]。耳痒螨等寄生虫性病因占犬外耳炎病例的7%[6]。局部药物引起的接触性皮炎在猫中尤其成问题，猫发生刺激反应的比例显著高于犬[1]。

### 预后

慢性外耳炎的预后因潜在病因和持续因素而有很大差异。已识别且可控制的原发性病因的病例通常预后较好[7]。然而，慢性病例通常需要终身管理而非治愈，其成功与否以临床症状的控制和预防复发来衡量[6][7]。

进行性的病理变化，包括耳道狭窄、钙化和增殖性变化，对预后有显著影响[3]。病例常发展为中耳炎，在高达83%的慢性外耳炎犬中有证据表明[3]。早期诊断和治疗可带来更好的结果，而严重、慢性或无反应的病例可能需要手术，并可能留下永久性神经功能缺损[1][3]。

### Sources

[1] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[2] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer/1000
[3] Diagnostic otology (Proceedings): https://www.dvm360.com/view/diagnostic-otology-proceedings
[4] Surgery of the ear (Proceedings): https://www.dvm360.com/view/surgery-ear-proceedings-1
[5] Approach to otitis, client education leads to success (Proceedings): https://www.dvm360.com/view/approach-otitis-client-education-leads-success-proceedings
[6] Ears, the basics all practitioners should know (Proceedings): https://www.dvm360.com/view/ears-basics-all-practitioners-should-know-proceedings
[7] 2024 AAHA Community Care Guidelines for Small Animal: https://meridian.allenpress.com/jaaha/article/60/6/227/503803/2024-AAHA-Community-Care-Guidelines-for-Small
