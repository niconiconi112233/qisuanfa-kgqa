# 伴侣动物肛门周腺癌

肛门周腺癌在小动物临床实践中代表着重要的肿瘤学挑战，其侵袭性的生物学行为和转移潜力使其区别于更常见的良性肛门周腺瘤。这种肛门周区域的恶性肿瘤约占犬类所有皮肤肿瘤的2%，其中令人担忧的是40-72%的病例在诊断时已出现淋巴结转移。该疾病主要影响平均年龄为10.5岁的老年犬，显著的品种易感性包括可卡犬和德国牧羊犬。一个重要的并发症是25-50%的病例中出现相关的副肿瘤性高钙血症，这可能掩盖原发性肿瘤的表现。本综述全面探讨了临床表现、诊断方法、多模式治疗策略和预后考虑因素，这些都是伴侣动物临床实践中优化管理这一具有挑战性肿瘤的关键。

## 疾病概述与流行病学

**肛门周腺癌**是起源于犬猫肛门囊顶泌腺的恶性肿瘤。这种肿瘤是影响肛门周区域最常见的恶性肿瘤，与更常见的良性肛门周腺瘤（肝样腺瘤肿瘤）有区别[1]。

**流行病学数据**揭示了显著的人口统计学模式。肛门囊腺癌占犬类所有皮肤肿瘤的2%，占肛门周肿瘤的17%[1][2]。该疾病主要影响老年犬，就诊时的平均年龄为10.5岁[1]。

**性别倾向**在文献中显示出不断变化的模式。虽然历史上报道雌性犬易感，但最近的回顾性研究表明绝育雌性和去势雄性之间的分布均等[1]。然而，一些研究表明不存在性别偏好[2]。有趣的是，未去势的雄性似乎不太可能发展这种肿瘤，表明睾酮可能具有保护作用[1]。

**品种易感性**包括几个易感品种。可卡犬、史宾格犬、德国牧羊犬、腊肠犬和阿拉斯加雪橇犬表现出过度代表性[1]。英国可卡犬和德国短毛指示犬也经常受到影响[2]。该疾病显示出高度的转移潜力，40-72%的病例在诊断时出现髂淋巴结受累[1]。

在猫中，已有肛门周腺癌的记录，但与犬相比报道较少[3]。一例病例报告描述了一只15岁去势雄性家养短毛猫出现复发性肛门周顶泌腺腺癌[3]。

### Sources
[1] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs
[2] Apocrine gland adenocarcinoma of the anal sac: Catch it early to improve prognosis: https://www.dvm360.com/view/apocrine-gland-adenocarcinoma-anal-sac-catch-it-early-improve-prognosis
[3] Apocrine gland adenocarcinoma and pheochromocytoma in a cat: https://meridian.allenpress.com/jaaha/article/33/1/33/175097/Apocrine-gland-adenocarcinoma-and-pheochromocytoma

## 常见病原学与病因学

肛门周腺癌是一种非感染性肿瘤性疾病，没有细菌、病毒或寄生虫病因学[1]。这种恶性肿瘤自发起源于肛门周围的肛门周腺（肝样腺），区别于感染性肛门周疾病。

激素影响在发病机制中起着关键作用。未去势的雄性犬发展肛门周肿瘤的可能性是雌性的3-10倍[2]。这种强烈的性别倾向表明肿瘤发展和进展中存在睾酮依赖性。

遗传因素对疾病易感性有显著贡献。某些品种表现出增加的易感性，尽管特定的基因突变尚未完全表征。年龄相关的细胞变化和积累的遗传损伤也可能影响老年患者的肿瘤发展。

这种情况必须与感染性肛门周疾病相区别，如肛门周瘘管，后者涉及毛囊和肛门腺的慢性细菌污染和炎症[2]。与表现为化脓性分泌物和全身炎症的感染性疾病不同，肛门周腺癌通常表现为离散的肿块，除非发生继发性细菌污染，否则没有活动性感染。

肛门周腺癌的非感染性性质强调了组织病理学诊断的重要性，以区别于可能需要抗菌治疗而非肿瘤学管理的炎症性或感染性肛门周疾病。

### Sources
[1] A literature review on the welfare implications of gonadectomy: https://avmajournals.avma.org/view/journals/javma/250/10/javma.250.10.1155.xml
[2] Disorders of the Rectum and Anus in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-rectum-and-anus-in-dogs

## 临床症状和体征

犬肛门周腺癌的临床表现以局部和全身表现为特征。最常见的初始体征是与一个肛门囊相关的肛门周肿块，主人最初可能不会注意到[2]。原发性肿瘤症状包括里急后重（排便不完全感）、排便困难和因结肠压迫产生带状粪便[2,6]。随着肿瘤进展，便秘、顽固性便秘和肛门周肿胀变得更加明显。

25-50%的受影响犬出现显著的副肿瘤综合征，表现为高钙血症，伴有多尿、烦渴、肌肉无力、呕吐和便秘[2]。犬也可能因高钙血症效应表现出厌食和嗜睡。在某些情况下，原发性肛门囊肿块可能比扩大的转移性髂淋巴结要小[6]。

品种特异性模式显示可卡犬、史宾格犬、德国牧羊犬、腊肠犬和阿拉斯加雪橇犬易感，受影响的犬通常年龄较大（平均10.5岁）[6]。重要的是，在很大比例的病例中，肿瘤可能是常规直肠检查的偶然发现，这强调了彻底体格检查的重要性[6]。

### Sources
[1] Short- and long-term outcomes associated with anal sacculectomy in dogs: https://avmajournals.avma.org/view/journals/javma/261/10/javma.23.02.0102.xml
[2] Clinical Rounds: Anal sac adenocarcinoma - dvm360: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[3] Rectal Neoplasms in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/rectal-neoplasms-in-dogs-and-cats
[4] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs
[5] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
[6] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 诊断方法

对于所有出现肛门周肿块或高钙血症的犬，直肠指检都是必不可少的，因为肛门囊腺癌可能作为与肛门囊相关的硬结增厚或肿块被触及[1]。细针抽吸和细胞学检查显示特征性的致密乳头状细胞团簇，伴有大量散在的游离细胞核，尽管细胞可能看起来良性，但具有侵袭性的生物学行为[1]。

组织病理学评估提供明确诊断，显示三种不同的模式：实性、玫瑰花结和管状形成[1]。必须向病理学家提供位置信息以准确解释，因为其他解剖位置也会出现类似的模式。

实验室评估包括全血细胞计数和血清生化分析，以检测副肿瘤性高钙血症，25-53%的病例存在这种情况[3]。升高的钙水平要求测量离子钙以确认，犬的真性高钙血症定义为离子钙>1.45 mmol/L[8]。

分期影像学包括三视图胸部X光片以检测肺转移和腹部超声以评估髂淋巴结肿大[3]。计算机断层扫描在检测可疑肺病变方面比调查X光片具有更高的敏感性[4]。腹部X光检查可能显示腰下软组织不透明，但超声在检测淋巴结肿大和表征淋巴结大小方面提供更高的敏感性[3]。

### Sources
[1] Clinical Rounds: Anal sac adenocarcinoma - dvm360: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[2] Merck Veterinary Manual Diagnostic Imaging: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging
[3] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs
[4] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats

## 治疗选择

现有部分内容为肛门周腺癌的多模式治疗方法提供了极好的覆盖。我将整合来源材料以增强特定方面，同时保持已建立的综合方法。

**姑息治疗策略**

姑息性放射治疗为非手术候选犬或患有广泛疾病的犬提供了显著益处[1]。每周使用6-8 Gy分割进行3-4周的治疗可以在约75%的病例中提供有意义的症状缓解和部分肿瘤消退[1]。这种方法在维持生活质量的同时，为拒绝积极多模式治疗的主人最小化了治疗负担。

**先进化疗考虑**

虽然铂类药物仍然是化疗方案的基石，但新出现的数据表明联合方法可能优化结果[1]。一些临床医生现在倾向于序贯或交替铂类和多柔比星方案，尽管已发表的研究尚未证明比单药铂类治疗有显著的生存优势[1]。卡铂和顺铂之间的选择通常取决于患者因素，卡铂在肾功能受损的患者中因其肾毒性降低而更受青睐[1]。

**支持性护理整合**

全面的支持性护理应解决原发性肿瘤影响和治疗相关并发症。在涉及广泛盆腔受累或侵袭性手术切除后的病例中，疼痛管理变得尤为重要。抗炎药物和镇痛药有助于在多模式治疗方案期间保持舒适。

### Sources
[1] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs
[2] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
[3] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[4] Toceranib: a weapon against apocrine gland anal sac tumors in dogs?: https://www.dvm360.com/view/toceranib-a-weapon-against-apocrine-gland-anal-sac-tumors-in-dogs
[5] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 预防措施

**通过常规直肠检查进行早期检测是肛门周腺癌最重要的预防措施[1]。直肠指检（DRE）作为筛查工具的重要性怎么强调都不为过，因为它可以在治疗效果最有利时检测早期肛门囊腺癌[1]。**

**DRE涉及将戴手套的食指放入直肠并360°触诊以评估直肠括约肌和周围组织的异常[2]。这个简单的程序可以在肿块对主人变得临床明显之前识别肛门囊区域的小肿块或增厚[3]。即使肿块在外部不可见，也建议对所有犬进行彻底的直肠指检作为常规体格检查的一部分[4]。**

**去势对这种肿瘤类型提供的预防益处有限[5]。与去势具有高度保护性的肛门周腺瘤不同，绝育在预防肛门囊腺癌中的作用仍不清楚。一些研究表明未去势的雄性可能风险较低，表明睾酮可能具有保护作用[4]。**

**筛查建议强调定期兽医检查，特别是对于易感品种，包括可卡犬、史宾格犬、德国牧羊犬、腊肠犬和阿拉斯加雪橇犬[4]。患有可疑肛门周肿块或高钙血症的犬应立即接受评估，包括DRE和细胞学检查。**

### Sources
[1] Outcome and clinical, pathological, and immunohistochemical ...: https://avmajournals.avma.org/view/journals/javma/253/1/javma.253.1.84.xml
[2] Abnormalities detected on digital rectal examinations in dogs ...: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.12.0695.xml
[3] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[4] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs
[5] Age at gonadectomy, sex, and breed size affect risk of canine ...: https://avmajournals.avma.org/view/journals/javma/261/9/javma.22.12.0596.xml

## 鉴别诊断

将肛门周腺癌与其他肛门周肿块区分需要仔细评估位置、细胞学特征和临床表现[1]。主要鉴别诊断是肛门囊腺癌，它起源于顶泌腺，具有明显不同的细胞学特征[1]。与肛门周腺癌的类似肝细胞的颗粒细胞粘附性团簇不同，肛门囊腺癌细胞形成粘附性较差的聚集体，细胞边界不清，嗜碱性胞浆最少[1][2]。

肛门周腺瘤（肝样腺瘤）是最常见的良性鉴别诊断，占犬类所有肛门周肿瘤的80%以上[1]。这些肿瘤与肛门周腺癌具有相似的细胞学外观，具有丰富的颗粒状胞浆和肝细胞样形态，因此需要组织学评估边缘和组织侵袭以进行明确区分[1][4]。

肛门周腺癌与腺瘤的区别在于存在大量具有高核质比的小上皮细胞（储备细胞）以及肝细胞中的恶性核标准[5]。在细胞学上，这些区别特征可能产生变异性，即使在腺瘤中也模拟恶性，需要仔细评估[4]。

其他重要的鉴别诊断包括肥大细胞瘤、黑色素瘤和淋巴瘤，可以通过其特征性的细胞学特征区分[2]。浆细胞瘤、鳞状细胞癌、基底细胞肿瘤和皮肤附属器肿瘤也发生在肛门周区域，但缺乏肝样肿瘤特有的颗粒状胞浆[1]。破裂的肛门囊脓肿通常表现为单侧引流道，与恶性肿瘤相比蜂窝织炎程度较轻[3]。

### Sources

[1] Clinical Exposures: Canine circumanal gland adenoma: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[2] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[3] Tumors best treated by complete surgical excision: https://www.dvm360.com/view/anorectal-disease-tumors-best-treated-complete-surgical-excision
[4] Diagnostic cytology--the basics (Proceedings): https://www.dvm360.com/view/diagnostic-cytology-basics-proceedings
[5] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0
