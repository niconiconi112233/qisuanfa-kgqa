# 伴侣动物慢性细菌性前列腺炎

慢性细菌性前列腺炎在小动物兽医临床实践中是一个重要的临床挑战，影响性成熟的完整雄性犬，是继良性前列腺增生之后第二常见的前列腺疾病。这种持续性炎症性疾病主要由大肠杆菌、葡萄球菌和链球菌等细菌病原体引起，通常继发于前列腺增大，需要长期治疗方案。

本报告探讨了慢性细菌性前列腺炎的综合兽医管理，涵盖基本诊断方法，包括前列腺液分析和超声检查；基于证据的治疗策略，强调使用氟喹诺酮类和甲氧苄啶-磺胺甲噁唑等药物进行长期抗生素治疗；以及去势在取得治疗成功中的关键作用。分析讨论了影响患病犬临床结果的关键鉴别诊断、预防措施和预后因素。

## 疾病概述

慢性细菌性前列腺炎是雄性犬由细菌感染引起的前列腺持续性炎症性疾病[1]。与急性前列腺炎不同，慢性细菌性前列腺炎在兽医实践中更常见，是继良性前列腺增生之后第二常见的前列腺疾病[1]。

该疾病影响所有年龄段的性成熟完整雄性犬，但在中老年动物中更为常见[1]。慢性细菌性前列腺炎通常作为良性前列腺增生的并发症发展，因为增大的前列腺组织为细菌定植和持续存在提供了有利环境[1]。其流行病学意义在于它与复发性尿路感染相关，因为任何患有尿路感染的完整雄性犬都应被认为前列腺中存在微生物[2]。

易感因素包括良性前列腺增生的存在、免疫抑制状态和损害正常宿主防御机制的解剖缺陷[3]。该疾病的慢性性质使其治疗具有挑战性，通常需要长期抗生素治疗并解决潜在的易感因素才能成功治愈[1]。

### Sources

[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[3] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings

## 常见病原体

犬的慢性细菌性前列腺炎通常由几种关键细菌生物引起，这些细菌从下尿路上行或通过血源性传播。最常见的分离病原体包括大肠杆菌，它是急性和慢性前列腺炎中最常见的单一致病菌[1]。革兰氏阳性菌也起着重要作用，葡萄球菌和链球菌种类被常见识别[1][2]。

其他重要病原体包括变形杆菌、克雷伯氏菌、假单胞菌和肠杆菌种类[2]。支原体种类也与前列腺感染有关，尽管它们可能需要特殊培养基才能检测到[1]。犬布鲁氏菌是另一种需要关注的病原体，特别是在与前列腺疾病相关的椎间盘炎病例中[2]。

感染途径通常涉及慢性病例中来自尿道的上行细菌或急性表现中的血源性传播[1]。革兰氏阴性菌如大肠杆菌、肠球菌、变形杆菌和克雷伯氏菌是犬尿路感染中最常见的尿路病原体之一，这些感染可延伸至前列腺[3][4]。

### Sources

[1] Prostatitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats

[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings

[3] Resistant urinary tract infections (Proceedings): https://www.dvm360.com/view/resistant-urinary-tract-infections-proceedings

[4] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals

## 临床症状和体征

犬的慢性细菌性前列腺炎通常表现为微妙且常为间歇性的临床症状，这些症状最初可能被忽视[1]。患病犬可能有复发性尿路感染病史，伴有脓性或血性尿道分泌物和排尿困难[1]。与急性前列腺炎不同，慢性细菌性前列腺炎患者通常没有全身性疾病症状[1]。

常见的泌尿系统症状包括血尿、排尿困难（排尿时用力）和里急后重（排便时用力）[1]。犬还可能表现出间歇性尿道分泌物，这些分泌物可能呈清澈、脓性或血性[1][2]。分泌物可能是持续性或间歇性的，有些病例表现为明显血液[2]。

体格检查时，前列腺可能不肿大或疼痛，但触诊时常有不规则轮廓[1]。这与急性前列腺炎形成对比，后者前列腺通常疼痛且柔软[1]。一些犬可能因前列腺不适而出现后肢僵硬步态[1]。

虽然慢性细菌性前列腺炎可影响任何品种的犬，但尚未明确建立该疾病的特定品种易感性，这与前列腺肿瘤不同，后者在苏格兰梗、设得兰牧羊犬和杜宾犬中表现出品种特异性模式[1]。该疾病主要影响性成熟的完整雄性犬，因为去势雄性犬由于去势后前列腺萎缩很少发生细菌性前列腺炎[1]。

### Sources
[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge

## 诊断方法

诊断慢性细菌性前列腺炎需要结合临床评估、实验室检查和影像学研究的综合方法。体格检查包括腹部和直肠触诊，以评估前列腺大小、对称性、质地和疼痛[1]。

**尿液分析和培养**

尿液分析通常显示血尿、脓尿和菌尿[2]。然而，单独的细胞学检查可能显示退行性中性粒细胞而没有可见细菌[1]。尿液培养应使用通过膀胱穿刺术收集的样本进行，以避免远端泌尿生殖道污染[2]。来自前列腺液或尿液的细菌培养可识别常见病原体，包括大肠杆菌、葡萄球菌、链球菌和假单胞菌[2]。

**前列腺液分析**

最明确的诊断方法涉及通过手动射精或前列腺按摩收集前列腺液[6]。前列腺灌洗用于细胞学和细菌培养提供最佳的标本质量[3]。可以在超声引导下经直肠或经皮进行细针穿刺抽吸，但这存在医源性腹膜炎的风险[6]。

**影像学研究**

腹部X线摄影可能显示前列腺增大伴不规则轮廓和可能的钙化[2]。超声检查是首选的影像学方法，可评估前列腺实质并检测局灶性至多灶性强回声区域伴小实质内无回声灶[2][6]。回声增强与慢性细菌性前列腺炎相关，而钙化区域可能表明慢性感染[6]。

### Sources

[1] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[3] Should you consider prostatic disease?: https://www.dvm360.com/view/should-you-consider-prostatic-disease
[6] Prostatic Diseases in Small Animals - Reproductive System: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-diseases-in-small-animals

## 治疗选择

慢性细菌性前列腺炎的治疗需要多方面的方法，结合长期抗生素治疗、手术干预和支持性护理措施[1][2]。

**抗生素选择和疗程**
成功治疗取决于选择能有效穿透前列腺-血液屏障的抗生素。最理想的抗生素包括红霉素、克林霉素、甲氧苄啶-磺胺甲噁唑、氯霉素和氟喹诺酮类[1]。对于慢性病例，建议使用能有效穿透前列腺-血液屏障的抗生素治疗至少6周[1]。默克兽医手册规定抗生素治疗应持续≥4周，在中性pH下非离子化且具有高脂溶性的抗生素最有效[2]。

**手术管理**
建议在开始抗生素治疗且患者临床稳定后进行去势，以促进前列腺炎的消退[1][2]。这种手术干预解决了导致前列腺疾病的基础激素因素。在前列腺脓肿病例中，可能需要手术引流以实现持久缓解[1]。

**支持性护理**
治疗包括消除易感因素，如免疫抑制药物或解剖缺陷[1]。成功监测的最佳方法是在治疗后30天内获得两次前列腺液培养阴性结果[1]。在某些情况下可能需要长期抑制治疗，使用适当抗菌药物的每日一次给药[1]。

### Sources

[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] Prostatitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats

## 预防措施

慢性细菌性前列腺炎的主要预防措施是去势，这消除了良性前列腺增生的激素刺激[1]。由于慢性细菌性前列腺炎继发于良性前列腺增生，解决基础疾病至关重要[1]。去势增加了成功治疗的可能性并防止复发[3]。

易感因素的药物治疗包括使用非那雄胺减少完整种用犬的前列腺大小[4]。环境因素如通过适当卫生预防尿路感染和及时治疗下尿路疾病有助于减少上行性细菌感染[4]。

## 鉴别诊断

关键鉴别诊断包括良性前列腺增生，表现为对称性前列腺增大而无全身性疾病[4]。前列腺肿瘤，特别是腺癌，通常发生在老年犬中，伴有不对称性前列腺增大和潜在转移[4]。前列腺脓肿表现为严重的全身性疾病、疼痛的不对称性前列腺增大和超声显示的液性腔[4]。

前列腺和前列腺旁囊肿引起肿块效应并压迫周围结构，可通过其特征性超声表现区分[4]。与慢性细菌性前列腺炎不同，良性前列腺增生很少引起全身症状，而前列腺肿瘤通常表现为更严重的临床恶化和对抗生素治疗反应不良[1][4]。

### Sources

[1] Prostatitis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats
[2] Effects of castration on chronic bacterial prostatitis in dogs: https://avmajournals.avma.org/view/journals/javma/199/3/javma.1991.199.03.346.xml
[3] Pharmacotherapeutics in Bacterial Prostatitis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-prostatitis-in-dogs-and-cats
[4] Prostatic disease in the dog (Proceedings) - dvm360: https://www.dvm360.com/view/prostatic-disease-dog-proceedings
