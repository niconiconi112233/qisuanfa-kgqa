# 伴侣动物气管炎：综合兽医指南

气管炎是影响犬猫的一种重要呼吸道疾病，其特征为气管黏膜炎症，产生兽医从业人员所熟悉的独特刺耳干咳。该疾病的发生涉及猫疱疹病毒1型、犬副流感病毒等病毒病原体与支气管败血波氏杆菌等继发性细菌入侵者之间的复杂相互作用。本报告探讨了气管炎的多因素性质，从其流行病学模式和品种易感性，到间歇性病原体脱落和环境污染物造成的诊断挑战。临床表现从犬的特征性"鹅鸣"咳嗽，到猫休息期后的咳嗽痉挛，存在影响治疗方法的物种特异性变异。理解这些复杂性使兽医能够实施有针对性的诊断策略、适当的抗菌治疗和有效的预防措施，以获得最佳的患者治疗效果。

## 疾病概述

气管炎是犬猫气管黏膜的炎症性疾病，通常作为更广泛呼吸道疾病复合体的一部分发生。在犬中，它常表现为传染性气管支气管炎或"犬窝咳"，而在猫中，它常伴随猫上呼吸道疾病复合体。

**流行病学背景**
该疾病在动物密集的环境中显示出高患病率，包括寄养设施、收容所和繁育场。幼年动物由于免疫系统未成熟而面临更高的易感性，而运输、过度拥挤和环境变化等压力因素显著增加风险。某些品种表现出更高的易感性，犬的短头颅品种因气道解剖结构限制而表现出更高的脆弱性，而暹罗猫和喜马拉雅猫则对支气管哮喘并发症表现出更大的易感性。该疾病通常遵循季节性模式，在动物流动和聚集的高发期发病率增加。

## 常见病原体

伴侣动物的气管炎由多种传染性病原体引起，这些病原体通常协同作用导致疾病。**病毒病原体**起着主要作用，猫疱疹病毒1型（FHV-1）占猫急性上呼吸道感染的大部分 [1]。猫杯状病毒（FCV）同样重要，临床上通常难以与FHV-1区分，并且往往更严重地影响口腔和肺部 [1]。在犬中，犬副流感病毒、犬腺病毒2型和犬流感病毒是传染性气管支气管炎的主要病毒贡献者 [2]。

**细菌病原体**常常使病毒感染复杂化或作为主要病原体。支气管败血波氏杆菌尤为重要，它既是幼犬幼猫的主要病原体，也是病毒损伤呼吸道防御机制后的继发入侵者 [2]。支原体物种可引起结膜炎和鼻炎，尽管它们被认为不如主要病毒病原体重要 [1]。马链球菌兽疫亚种是犬呼吸道疾病的另一个重要细菌病因 [3]。

**继发性细菌感染**通常在初次病毒感染后发展。猫衣原体和鹦鹉热衣原体可引起结膜炎和轻微呼吸道症状，而包括假单胞菌、大肠杆菌和肺炎克雷伯菌在内的各种革兰氏阴性细菌可能在免疫功能受损的患者中引起机会性感染 [2]。

### Sources
[1] Feline Calicivirus - Cat Owners: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[2] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[3] What are the best practices for antibiotic use in canine infectious respiratory disease complex?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-canine-infectious-respiratory-disease-complex

## 临床症状和体征

犬气管炎的特征性临床表现是刺耳的干咳，通常被描述为具有"鹅鸣"性质 [1][2]。这种独特的咳嗽通过轻柔触诊喉部或气管很容易诱发，这在体格检查期间作为重要的诊断指标 [1][2]。咳嗽痉挛是最显著的临床体征，通常在休息期后或运动开始时最为严重 [3]。

在猫中，气管炎表现为咳嗽痉挛作为主要体征，在休息后或运动初期最为严重 [2]。猫患者还可能表现出呼吸急促、可能时有时无的喘息，在支气管哮喘（过敏性支气管炎）病例中，幼猫以及暹罗猫和喜马拉雅猫品种最常受影响 [2]。

咳嗽可能伴随干呕和作呕，主人有时会误认为是呕吐 [2]。在急性阶段，两个物种的体温升高通常较轻微 [3]。该疾病通常遵循可预测的病程，严重程度在最初五天内减轻，尽管症状可能持续10-20天 [1]。在无并发症的病例中，受影响的动物通常保持正常的食欲和活动水平，这使气管炎与更严重的呼吸道疾病区分开来 [3]。

当气管炎进展为支气管肺炎时，会出现更严重的体征，包括发热、脓性鼻分泌物、精神沉郁、厌食和湿咳 [1][2]。这些并发症在幼犬和体弱动物中更为常见 [3]。

### Sources
[1] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[2] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[3] Tracheobronchitis (Bronchitis, Bronchial Asthma) in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/tracheobronchitis-bronchitis,-bronchial-asthma-in-cats

## 诊断方法

由于获取和观察气管组织存在挑战，犬猫气管炎的诊断依赖于多种互补方法 [1]。临床表现评估形成基础，兽医评估特征性体征，包括刺耳咳嗽、呼吸困难和声音变化 [3]。

**实验室检测**
气管冲洗提供比鼻拭子更高的诊断准确性，为细胞学检查和细菌培养提供材料 [1]。PCR检测有助于识别特定病原体，特别是在培养结果为阴性或需要快速识别时 [2]。培养和药敏试验应包括需氧和厌氧生物，尽管解释混合细菌种群需要仔细考虑 [1]。

**影像学检查**
胸部X光片作为基本诊断工具，显示肺部变化并排除肺炎 [3]。然而，通过CT或MRI的横断面成像在显示气管病变范围和相关并发症方面提供更高的灵敏度 [4]。支气管镜检查允许直接观察气管黏膜并收集靶向活检样本 [3]。

**诊断挑战**
几个因素使小动物气管炎的诊断复杂化。环境污染可能影响培养结果，而间歇性病原体脱落可能产生假阴性结果 [2]。此外，区分原发性气管炎和继发性并发症需要仔细评估潜在疾病过程和相关临床发现 [1][3]。

### Sources
[1] The pneumonias of small mammals (Proceedings): https://www.dvm360.com/view/pneumonias-small-mammals-proceedings
[2] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[3] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[4] Aspergillosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/fungal-infections/aspergillosis-in-animals
