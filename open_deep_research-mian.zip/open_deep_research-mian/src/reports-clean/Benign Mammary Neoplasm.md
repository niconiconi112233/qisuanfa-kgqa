# 伴侣动物的乳腺良性肿瘤

乳腺良性肿瘤是小动物临床实践中一个重要的临床问题，尤其影响未绝育的雌性犬和猫。虽然乳腺良性肿瘤约占犬乳腺肿瘤的50%，但在猫中则相当罕见，只有10-20%的乳腺肿块是良性的。本报告探讨了乳腺良性肿瘤的综合兽医管理，涵盖细胞学和组织病理学等基本诊断方法、从肿块切除术到乳房切除术的手术治疗策略，以及通过战略性卵巢子宫切除术时机的关键预防措施。分析强调了影响伴侣动物临床决策和长期结果的关键预后因素、区分良性与恶性疾病的鉴别诊断，以及物种特异性考虑因素。

## 疾病概述

乳腺良性肿瘤是指影响伴侣动物乳腺的非恶性肿瘤。这些肿瘤起源于乳腺上皮或间质组织，不具有侵袭或转移潜能[1][2]。

**定义与分类**
在犬中，约50%的乳腺肿瘤是良性的，相比之下，猫中只有10-20%是良性的，这使得猫乳腺肿瘤主要为恶性[2][3]。犬的乳腺良性肿瘤包括腺瘤、混合瘤（复杂腺瘤）和纤维腺瘤，而良性形式在猫中罕见[2]。

**流行病学背景**
乳腺肿瘤是性成熟雌性犬最常见的肿瘤，在该群体中50-70%的所有肿瘤都起源于乳腺[2]。犬的诊断平均年龄在7-11岁之间[2]。在猫中，乳腺肿瘤最常见于老年雌性（平均年龄11岁），未绝育雌性主要受影响[3]。

长期暴露于雌激素和孕激素会显著增加风险。在第一次发情前绝育的犬发病率非常低，而在6个月前绝育的猫发生乳腺肿瘤的风险降低91%[2][4]。某些品种表现出易感性，包括小型犬品种和纯种动物[2]。

### Sources
[1] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/239/7/javma.239.7.960.xml
[2] Merck Veterinary Manual Mammary Tumors in Dogs: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[3] Merck Veterinary Manual Mammary Tumors in Cats: https://www.merckvetmanual.com/cat-owners/reproductive-disorders-of-cats/mammary-breast-tumors-in-cats
[4] Merck Veterinary Manual Mammary Tumors in Cats Professional: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats

## 临床表现与诊断

乳腺良性肿瘤通常表现为乳腺链中的单个或多个坚硬、可移动的肿块[1]。这些肿块通常边界清晰，触诊时无疼痛。与恶性肿瘤不同，乳腺良性肿块很少引起覆盖皮肤的溃疡或炎症[1]。

体格检查应包括对所有乳腺的彻底触诊、区域淋巴结评估以及并发全身性疾病的评估[2]。可以进行细针抽吸细胞学检查，但存在局限性，因为乳腺肿瘤在细胞学上可能难以明确诊断[2]。经验法则是，犬乳腺肿瘤中50%是良性的[3]。

诊断影像学在评估中起着关键作用[1]。超声检查可以评估肿块特征、血管化情况，并可以指导活检程序[1]。可能需要进行X光检查等高级影像学检查来评估并发疾病或进行手术规划[2]。

明确诊断需要手术切除或切开活检后的组织病理学检查[2]。术前组织取样在可行时被推荐，但由于存在恶性转化的可能性，无论细胞学结果如何，通常都建议完全手术切除[2]。

临床分期应包括胸部X光和腹部影像学检查以排除转移性疾病，尽管良性病变很少发生转移[2]。

### Sources

[1] Mammary gland tumors (Proceedings) - dvm360: https://www.dvm360.com/view/mammary-gland-tumors-proceedings
[2] Mammary Tumors in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[3] Current recommendations for mammary gland tumors in dogs - dvm360: https://www.dvm360.com/view/current-recommendations-mammary-gland-tumors-dogs

## 治疗与预防

完全手术切除为乳腺良性肿瘤提供明确诊断和局部区域控制[1]。手术方法根据肿瘤大小、位置和存在的肿块数量而有所不同。对于小型、可移动的良性肿瘤（<0.5厘米），肿块切除术是合适的，而较大的病变可能需要单纯或区域乳房切除术[1]。

**医疗管理与术后护理**

术后监测至关重要，因为乳房切除术后的并发症率约为16.9%，其中三分之一需要住院治疗[3]。对所有切除组织的完整组织病理学评估仍然至关重要，以确认良性诊断并评估手术切缘[1]。有多发肿瘤的犬受益于对所有乳腺的系统评估，因为50-70%的犬在其一生中会发展出多个肿瘤[2]。

**卵巢子宫切除术时机与益处**

早期卵巢子宫切除术显著降低乳腺肿瘤风险，在第一次发情前保护率为0.5%，第一次发情后为8%，第二次发情后为26%[1]。最近的研究表明，与肿瘤切除同时进行的卵巢子宫切除术减少了新肿瘤的发展（未绝育犬为64%对比36%），并可能提高生存率，特别是对于雌激素受体阳性肿瘤的犬[2]。

**预防策略**

一级预防依赖于早期绝育，但时机必须平衡乳腺肿瘤风险与其他健康考虑。对于晚年绝育的犬，定期的主人监测和兽医检查能够早期发现新的肿块[2]。

### Sources

[1] Current recommendations for mammary gland tumors in dogs: https://www.dvm360.com/view/current-recommendations-mammary-gland-tumors-dogs
[2] Mammary Tumors in Dogs - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[3] Factors influencing complications following mastectomy: https://avmajournals.avma.org/view/journals/javma/258/3/javma.258.3.295.xml

## 鉴别诊断与预后

乳腺良性肿瘤必须与几种关键疾病进行鉴别。主要鉴别诊断包括恶性乳腺癌，占猫乳腺肿瘤的80-90%，而犬仅占50%[4]。在未绝育的年轻猫中，乳腺纤维腺瘤病表现为双侧巨大肿大，绝育后可消退，这与真正的肿瘤不同[1]。

其他鉴别诊断包括犬的炎性乳腺癌，其特征是快速生长伴有溃疡和红斑，以及乳腺炎或乳腺增生[1]。正常大小的淋巴结不能排除转移性疾病，因此细胞学评估对于准确诊断至关重要。

**预后因素显著影响结果**。肿瘤大小仍然是最关键的预后指标，<3厘米的肿块比较大肿瘤的预后明显更好[2]。使用Elston-Ellis系统的组织学分级与生存率强烈相关 - 猫的I级肿瘤中位生存期为36个月，而III级肿瘤为6个月[3]。

**临床分期显著影响预后**。淋巴结转移是一个重要的负面预后因素，所有显示淋巴结受累的猫在8个月内发展为进行性疾病[3]。手术时卵巢完整的犬生存期较短（中位9.5个月），而手术前两年内绝育的犬生存期较长（25个月）[2]。

**预期结果因物种和肿瘤特征而异**。两个物种的乳腺良性肿瘤在完全手术切除后通常预后良好。然而，猫乳腺癌的侵袭性导致总体预后谨慎，而早期疾病的犬患者通常能够实现长期生存[5]。

### Sources
[1] What you need to know about mammary gland tumors (Proceedings): https://www.dvm360.com/view/what-you-need-know-about-mammary-gland-tumors-proceedings
[2] Prognosis, treatment of canine mammary tumors: https://www.dvm360.com/view/prognosis-treatment-canine-mammary-tumors
[3] Mammary Tumors in Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[4] Mammary Tumors in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[5] Current recommendations for mammary gland tumors in dogs: https://www.dvm360.com/view/current-recommendations-mammary-gland-tumors-dogs
