# 伴侣动物创伤性寰枢椎脱位

创伤性寰枢椎脱位是伴侣动物中一种关键的颈脊髓紧急情况，涉及外部创伤后第一和第二颈椎之间正常解剖关系的破坏。这种情况对神经功能和呼吸稳定性构成直接威胁，需要快速诊断和干预。虽然主要影响先天性易感的玩具品种犬，但创伤性形式可影响任何品种，继发于机动车事故、跌倒或钝力创伤。本报告探讨了创伤性寰枢椎脱位的综合临床处理方法，涵盖诊断影像学方案、保守与手术治疗结果，以及影响恢复率的预后因素，根据干预时间和神经严重程度，恢复率在62%至89%之间。

## 疾病概述

创伤性寰枢椎脱位是一种急性颈脊髓不稳定疾病，影响第一颈椎（寰椎，C1）和第二颈椎（枢椎，C2）之间的关节[1]。这种情况是由于外力或创伤导致这些椎骨之间正常解剖关系破坏而引起的，可能导致脊髓压迫和神经功能障碍。

这种情况表现出明显的品种易感性，主要发生在年轻的玩具品种犬中[2]。最常受影响的品种包括约克夏梗、吉娃娃、博美犬和其他玩具品种[1][3]。虽然先天性形式比获得性创伤形式更常见，但创伤性寰枢椎脱位也可能影响大型犬和猫，尽管频率较低[3]。

幼犬应考虑先天性问题的可能性，包括枕寰或寰枢不稳定和齿突缺陷[4]。大多数受影响的犬年龄小于一岁，尽管临床症状可能是急性、缓慢进展或间歇性的，并且通常与轻微创伤相关[2][8]。虽然文献中确切的发病率尚未明确建立，但该病强烈的品种易感性表明存在影响寰枢椎稳定性创伤破坏易感性的遗传因素。

### Sources
[1] Atlantoaxial Instability - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats
[2] Cervical disorders of small breed dogs: https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
[3] Congenital and Inherited Spinal Cord Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-spinal-cord-disorders-in-animals
[4] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings
[5] The crooked spine: Congenital and developmental spinal disorders: https://www.dvm360.com/view/crooked-spine-congenital-and-developmental-spinal-disorders-proceedings

## 常见病原体

创伤性寰枢椎脱位是一种非感染性骨科疾病，由机械创伤而非感染因子引起[1]。这种情况是由于破坏寰椎（C1）和枢椎（C2）椎骨之间正常解剖关系的物理力量造成的，导致颈脊髓不稳定。

与许多其他兽医疾病不同，寰枢椎脱位不涉及病毒、细菌、真菌或寄生虫病原体。该病纯属创伤性质，通常继发于影响颈脊髓区域的外力，如机动车事故、跌倒或其他钝性创伤事件。

病理生理学涉及韧带结构的机械破坏，特别是维持C1和C2椎骨之间稳定性的寰枢横韧带和翼状韧带。在某些情况下，齿突（齿状突）的先天性畸形可能使幼犬易患寰枢椎不稳定，但这代表的是发育异常而非感染过程[2]。

兽医应认识到，寰枢椎脱位需要立即进行骨科和神经干预，而非抗菌治疗。治疗重点集中在手术稳定、抗炎管理和支持性护理上，而非解决不参与该病病因的感染因子。

### Sources
[1] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings
[2] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings

## 临床症状和体征

创伤性寰枢椎脱位表现出独特的临床表现，反映了上颈脊髓压迫和不稳定的严重程度。

**急性神经表现**是寰枢椎创伤的标志。受影响的动物通常表现出严重的颈痛觉过敏和颈部姿势僵硬，常将头部放低或向肩部伸展[1]。从轻度共济失调到完全四肢瘫痪的四肢轻瘫可能迅速发展，严重情况下由于靠近呼吸中枢可能出现呼吸功能障碍[2]。

**疼痛表现**包括显著的颈部僵硬、肌肉痉挛和不愿移动颈部。动物可能拒绝抬头、从地面进食或正常弯曲颈部。偶尔出现根征症状，受影响的肢体保持弯曲并离地，尽管这在大型犬中较少见[2]。

**品种特异性模式**显示主要发生在年轻的玩具品种犬中，特别是2岁以下的犬。骑士查理王小猎犬、约克夏梗、吉娃娃和博美犬最常受影响[2][3]。该病通常由齿突或韧带支持结构的先天性异常引起，而非纯粹创伤性原因[1]。

**进行性表现**可能发展为缓慢进展的共济失调伴间歇性疼痛发作，通常由轻微创伤或颈部操作诱发。一些动物表现出细微体征，包括活动减少、食欲不振或间歇性哭泣，使早期诊断具有挑战性[2]。体征通常在生命的前几年内发展，包括突然或逐渐加重的颈部疼痛或运动困难[4]。

临床病程从伴有呼吸麻痹的急性、危及生命的表现，到随时间波动的慢性、间歇性症状不等。

### Sources
[1] Merck Veterinary Manual: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals
[2] DVM 360 Cervical disorders: https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
[3] Merck Veterinary Manual Congenital Anomalies: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats
[4] Merck Veterinary Manual Nervous System Disorders: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs

## 诊断方法

创伤性寰枢椎脱位的诊断需要系统的方法，结合临床评估和先进的影像学检查方法。体格检查是基础，重点进行神经评估以识别影响所有四肢的上运动神经元体征，这是高位颈髓病变的特征[8]。动物通常表现为从轻度共济失调到完全瘫痪的四肢轻瘫，常伴有严重颈部疼痛和不愿移动头部[8]。

放射学评估是初始的影像学方法，侧位颈X线片显示寰枢椎距离增加和C1与C2椎骨之间的排列异常[8]。寰枢椎距离测量至关重要--在人类中通常小于2mm，类似原则适用于兽医患者[2]。

先进影像学提供更高的诊断准确性。计算机断层扫描（CT）提供骨结构和骨折模式的详细可视化，而磁共振成像（MRI）在评估脊髓压迫、水肿和软组织损伤方面表现出色[6][7][8]。这些模式对手术计划和预后评估至关重要。

脊髓造影术，尽管在CT和MRI可用时较少使用，可以显示脊髓压迫和脑脊液流动阻塞[8]。临床表现、神经定位和影像学检查结果的结合能够明确诊断并为这种潜在危及生命的疾病制定适当的治疗计划。

### Sources

[1] Atlantoaxial Joint Anatomical Structure: Pivot Joint of the Neck: https://anatomynote.com/atlantoaxial-joint-anatomical-structure-pivot-joint-of-the-neck/
[2] Atlanto-axial joint - Wikipedia: https://en.wikipedia.org/wiki/Atlanto-axial_joint
[3] Atlantoaxial Joints | Complete Anatomy - Elsevier: https://www.elsevier.com/resources/anatomy/connective-tissue/joints-of-vertebral-column/atlantoaxial-joints/23881
[4] Atlantoaxial Instability - Spine - Orthobullets: https://www.orthobullets.com/spine/2049/atlantoaxial-instability
[5] Atlanto-Axial Dislocation And Fracture: Causes, Symptoms ,... : https://www.epainassist.com/back-pain/upper-back-pain/atlanto-axial-dislocation-and-fracture
[6] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/79/10/ajvr.79.10.1079.xml
[7] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings
[8] Congenital and Inherited Spinal Cord Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-spinal-cord-disorders-in-animals
[9] Atlantoaxial joint stabilization using patient-specific 3-D ...: https://avmajournals.avma.org/view/journals/ajvr/85/7/ajvr.24.02.0023.xml
[10] Use of magnetic resonance imaging for morphometric ...: https://avmajournals.avma.org/view/journals/ajvr/70/3/ajvr.70.3.340.xml

## 治疗方案

创伤性寰枢椎脱位的治疗涉及保守和手术方法。保守治疗包括立即应用颈托以轻微伸展位置稳定颈脊髓，允许在4-15周内寰枢关节周围形成纤维结缔组织[1]。使用颈托进行非手术治疗在约62%的急性病例（临床症状<30天）中显示出良好的长期结果[2]。

手术稳定通常适用于对保守治疗无反应或伴有严重神经功能缺损的病例。标准手术方法是在放射学确诊后进行腹侧固定[3]。腹侧固定通常优于背侧方法，因为稳定性更好且并发症更少[5]。先进技术包括患者特异性3D稳定方法和新型经椎间孔入路，可减少对周围结构的损伤[1][4]。

疼痛管理在整个治疗过程中至关重要。对于疼痛严重的患者，可能需要住院治疗，每4-6小时注射一次阿片类药物或使用多药恒速输注（吗啡/利多卡因/氯胺酮）[1]。加巴喷丁和曲马多提供有效的神经性疼痛控制，而地西泮或美索巴莫有助于控制肌肉痉挛[3]。

术后护理需要在几周内严格笼养，并在使用颈托时定期更换绷带。在初始治疗期间密切监测至关重要，特别是对于因绷带过紧引起的发绀或呼吸困难等并发症[2]。无论采用何种治疗方式，预后仍然谨慎，手术成功率在61-91%之间[2]。急性病例的早期干预通常比慢性半脱位的治疗效果更好。

### Sources
[1] Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease
[2] Conservative treatment of atlantoaxial subluxation in ...: https://www.dvm360.com/view/conservative-treatment-atlantoaxial-subluxation-canine-patients
[3] A pain in the neck: diagnosing and treating neck and back ...: https://www.dvm360.com/view/pain-neck-diagnosing-and-treating-neck-and-back-pain-proceedings
[4] Novel transforaminal approach allows surgical ...: https://avmajournals.avma.org/view/journals/ajvr/83/12/ajvr.22.08.0122.xml
[5] Atlantoaxial joint stabilization using patient-specific 3-D ...: https://avmajournals.avma.org/view/journals/ajvr/85/7/ajvr.24.02.0023.xml

## 预防措施

创伤性寰枢椎脱位的预防策略主要集中在品种特异性考虑和环境调整上，因为这种情况主要影响玩具品种和迷你品种犬[1,2]。

**繁殖考虑**
寰枢椎不稳定最常见于玩具品种犬，原因是包括齿突发育不全或缺失在内的先天性畸形[1]。约克夏梗特别易患寰枢椎半脱位，原因是先天性齿突缺失[3]。负责任的繁殖实践应包括对繁殖动物进行寰枢椎异常筛查，避免繁殖已知有颈椎椎骨畸形的犬[2]。

**活动限制**
年轻的玩具品种犬应限制颈部活动，特别是避免可能诱发半脱位的腹屈[4]。应限制高强度活动和粗暴玩耍，特别是在易感品种生命的前几年，此时通常会出现临床症状[2]。

**环境管理**
主人应通过避免可能导致颈椎过度屈曲或伸展的活动来最小化创伤风险。正确的处理技术至关重要，避免通过头部或颈部区域提举。散步时使用胸带而非项圈可减少颈部的压力[6]。

**主人教育**
早期识别临床症状至关重要，因为当犬年龄小于2岁且神经体征存在时间少于10个月时，成功率更高[4]。应教育高危品种的主人了解这种情况的遗传性质，以及在出现颈部疼痛或神经功能缺损时立即就医的重要性[2]。使用颈托进行保守治疗的早期干预可能在约62%的急性病例中取得良好结果[6]。

### Sources
[1] Atlantoaxial joint stabilization using patient-specific 3-D: https://avmajournals.avma.org/view/journals/ajvr/85/7/ajvr.24.02.0023.xml
[2] Congenital and Inherited Disorders of the Nervous System: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs
[3] The recognized risks in Yorkshire terriers: https://www.dvm360.com/view/recognized-risks-yorkshire-terriers
[4] The crooked spine: Congenital and developmental spinal: https://www.dvm360.com/view/crooked-spine-congenital-and-developmental-spinal-disorders-proceedings
[5] DVM 360 Veterinarians see benefit to canine OA management protocols: https://www.dvm360.com/view/veterinarians-see-benefit-to-canine-oa-management-protocols
[6] Conservative treatment of atlantoaxial subluxation in canine patients: https://www.dvm360.com/view/conservative-treatment-atlantoaxial-subluxation-canine-patients

## 鉴别诊断

创伤性寰枢椎脱位必须与几种影响颈脊髓并表现出相似神经体征的疾病进行鉴别[1]。主要鉴别诊断包括其他形式的颈脊髓不稳定，如先天性寰枢椎半脱位，它发生在玩具品种犬中，表现出类似的颈部疼痛和四肢轻瘫，但逐渐发展而非创伤后急性发生[1]。

尾侧颈脊髓病（摇摆犬综合征）代表另一个重要的鉴别诊断，特别是在杜宾犬和大丹犬中，导致进行性共济失调和四肢轻瘫，但通常影响颈中至尾侧区域而非颅颈交界处[1]。

必须考虑炎症性疾病，包括脑脊髓炎和品种相关性无菌性脑膜炎，它们引起严重的颈部疼痛和神经功能缺损，但伴有发热、脑脊液细胞计数升高和全身炎症体征[2]。椎间盘炎表现为慢性颈部疼痛，X线片上可能显示椎骨终板变化，这与急性创伤性脱位不同[2]。

其他脊柱骨折和脱位也必须与寰枢椎脱位进行鉴别[3]。这些通常发生在钝性创伤后的T11-L6之间，引起后肢轻瘫而非四肢轻瘫，并且可以通过放射学定位来区分[3]。

创伤性寰枢椎脱位的关键鉴别特征是已知创伤后的急性发作，结合C1-C2排列异常的放射学证据。与先天性形式不同，创伤性病例通常发生在没有品种易感性的老年动物中，需要立即稳定以防止进一步的脊髓损伤[1][2]。

### Sources
[1] Congenital and Inherited Spinal Cord Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-spinal-cord-disorders-in-animals
[2] A pain in the neck: diagnosing and treating neck and back pain (Proceedings): https://www.dvm360.com/view/pain-neck-diagnosing-and-treating-neck-and-back-pain-proceedings
[3] Acute spinal cord injury - The first hour can make the difference (Proceedings): https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings

## 预后

创伤性寰枢椎脱位的预后根据神经严重程度、干预时间和治疗方法而有显著差异。手术稳定通常达到85.3%至88.9%的成功率，但由于固定失败或植入物并发症可能需要二次手术[1]。

使用颈托进行保守治疗在约62%的病例中显示出良好的长期结果，成功率与手术干预相似[1]。然而，急性病例（临床症状少于30天）比慢性表现有显著更好的预后[1]。

年龄显著影响结果。年龄小于2岁且临床症状持续时间少于10个月的犬显示出更好的手术成功率[2]。早期干预至关重要，因为随着治疗延迟和神经状况恶化，预后会逐渐变差[1][2]。

就诊时严重的神经功能缺损与较差的结果相关[2]。继发于脑干功能障碍的呼吸衰竭可导致死亡，大多数手术失败或死亡发生在术后前20天内[2]。术前神经状态仍然是最重要的预后因素，因此早期识别和及时干预对于最佳结果至关重要[2]。

### Sources
[1] Conservative treatment of atlantoaxial subluxation in canine patients: https://www.dvm360.com/view/conservative-treatment-atlantoaxial-subluxation-canine-patients
[2] Cervical disorders of small breed dogs (Proceedings): https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
