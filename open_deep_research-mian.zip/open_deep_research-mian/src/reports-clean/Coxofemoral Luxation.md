# 伴侣动物髋关节脱位：综合临床指南

髋关节脱位是小动物临床中最常见的关节脱位，占犬猫所有脱位的90%。这种骨科急症需要及时识别和适当治疗，以优化患者预后并防止骨关节炎和慢性跛行等长期并发症。

本综合报告探讨了髋关节脱位的多方面问题，从主要由车辆事故造成的创伤性病因到各种治疗方式，包括闭合复位、手术稳定和挽救性手术。该报告综合了当前兽医知识，包括诊断技术、预后因素和影响患病伴侣动物成功治疗的循证治疗方法。

## 摘要

髋关节脱位是影响伴侣动物的一种重要骨科疾病，车辆创伤占病例的60-85%，而头背侧移位占脱位的78%。在4-5天内进行早期干预可显著提高治疗成功率，尽管延迟治疗不一定使预后恶化。

| 治疗方法 | 成功率 | 关键考虑因素 |
|-------------------|--------------|-------------------|
| 闭合复位 | 不定 | 最佳时间为4-5天内，需要Ehmer悬带 |
| 开放复位 | 85% | 有多种技术可用 |
| 纽扣针固定 | 85-90% | 允许早期负重 |
| 挽救手术（股骨头颈切除术/全髋关节置换术） | 良好-优秀 | 适用于复位失败或不适合其他手术的病例 |

长期结果显示，62%的犬恢复正常功能，但55-62%的病例会发展为骨关节炎。环境伤害预防、体重管理和早期筛查髋关节发育不良仍然是关键的预防措施。使用拇指移位测试等体格检查技术，结合放射学确认进行及时诊断，使兽医能够选择合适的治疗策略，并向主人提供关于恢复和长期关节健康的现实期望。

## 疾病概述与流行病学

现有章节内容提供了关于髋关节脱位的全面流行病学信息。所审查的来源材料不包含额外的特定流行病学数据来补充已包含的内容。

当前内容准确地将髋关节脱位描述为股骨头从髋臼中移位[1]，确定其为小动物中最常见的关节脱位，占所有脱位的90%[2]，并正确识别了双峰年龄分布，即年轻犬出现创伤性脱位，而老年动物可能因严重的髋关节发育不良继发脱位[1]。关于髋关节主要稳定结构的解剖学描述以及头背侧脱位（占病例78%）的主导地位[1][2]也是准确的。

所审查的其他来源主要关注其他髋部疾病，如髋关节发育不良的患病率和关节创伤，但没有提供髋关节脱位本身的新特定流行病学数据来增强当前的综合概述。

### Sources

[1] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[2] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[3] Hip luxations (Proceedings): https://www.dvm360.com/view/hip-luxations-proceedings

## 病因与病理生理学

髋关节脱位是犬最常见的脱位关节，占所有脱位的90%[7]。创伤性原因是主要病因，其中车辆事故占病例的60-85%[10]。其他创伤机制包括跌倒和从移动车辆上跳下[10]。

易感的解剖条件显著增加了脱位风险。髋关节发育不良导致关节松弛和不协调，使脱位更容易发生[2]。Legg-Calvé-Perthes病，以小型犬股骨头缺血性坏死为特征，削弱了关节结构并易导致脱位[2]。在幼犬中，股骨头骨骺骨折可能伴随髋部创伤[8]。

发病机制涉及髋部主要稳定结构的破坏：关节囊和圆韧带（股骨头韧带）[7]。这些稳定结构中必须有两个受损才会发生脱位[6]。头背侧脱位占病例的78%，而尾腹侧和腹侧移位较少见[7,10]。

解剖结构的破坏导致特征性的移位模式。头背侧脱位导致股骨头移位越过髋臼背侧缘，而腹侧脱位可能导致股骨头卡在闭孔内[10]。这种机械破坏导致关节不稳定、软骨损伤，如果不及时处理，会进行性发展为退行性变化[6,8]。

### Sources
[1] Evaluating hindlimb lameness in juvenile dogs: https://www.dvm360.com/view/evaluating-hindlimb-lameness-juvenile-dogs
[2] Evaluating hindlimb lameness in juvenile dogs: https://www.dvm360.com/view/evaluating-hindlimb-lameness-juvenile-dogs
[3] 3 products to get pets back to peak condition: https://www.dvm360.com/view/3-products-get-pets-back-peak-condition
[4] 3 products to get pets back to peak condition: https://www.dvm360.com/view/3-products-get-pets-back-peak-condition
[5] VMX 2020-Pet weight loss and mobility: tips from the pros: https://www.dvm360.com/view/vmx-2020-pet-weight-loss-and-mobility-tips-from-the-pros
[6] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[7] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[8] Merck Veterinary Manual Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[9] Analysis of outcomes following treatment of craniodorsal hip luxation with closed reduction and Ehmer sling application in dogs: https://avmajournals.avma.org/view/journals/javma/254/12/javma.254.12.1436.xml
[10] Hip luxations (Proceedings): https://www.dvm360.com/view/hip-luxations-proceedings

## 临床表现与诊断

髋关节脱位的体格检查通常表现为患肢外旋和内收的非负重性跛行[1]。急性脱位表现为更严重的跛行，而慢性病例可能显示一定程度的负重[1]。触诊常发现髋部肿胀和操作时的不适感。

拇指移位测试是一种有价值的诊断技术，通过将拇指置于大转子和坐骨结节之间的坐骨切迹中，然后外旋股骨进行[1]。在正常髋部，拇指会随着旋转而离开切迹，但当股骨头脱位时保持不动。解剖标志的评估涉及触诊头背侧髂骨缘、大转子和坐骨结节[1]。在正常髋部，大转子位于连接髂骨和坐骨的线的远侧，而头背侧脱位使转子与两点等距。

诊断成像主要依靠骨盆的正交放射线照片来确认脱位方向、评估包括髋关节发育不良在内的关节构型，以及评估并发骨折[2,3]。放射线照片应包括腹背伸展位和侧位投影，以全面表征移位模式[2,3]。当可用时，CT等高级成像可提供额外的诊断信息[4]。

鉴别诊断包括髋臼或股骨颈骨折、伴有半脱位的严重髋关节发育不良、前十字韧带断裂以及其他后肢跛行的原因[4]。区分因素包括特定的跛行模式、解剖标志移位和确认股骨头从髋臼移位的放射学发现。

### Sources

[1] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[2] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[3] Hip luxations (Proceedings): https://www.dvm360.com/view/hip-luxations-proceedings
[4] Joint Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 治疗方法

髋关节脱位的治疗包括闭合和开放复位技术。对于脱位后4-5天内的急性病例，应首先尝试闭合复位[1]。患者置于全身麻醉下，侧卧位，通过外旋、牵引和内旋，同时在大转子上施加向下压力来实现复位[3]。成功闭合复位后，应用Ehmer悬带7-14天以维持髋关节屈曲和内旋[1]。

当闭合复位失败或再次脱位时，需要开放手术技术[2]。存在多种稳定方法，包括关节囊缝合术（83-90%成功率）、假体关节囊技术（65-100%成功率）和纽扣针稳定术，再次脱位率为10-15%[2]。纽扣针稳定术允许早期负重，涉及在髋臼和股骨颈上钻孔，并用缝线连接锚定物[3]。

挽救手术包括股骨头颈切除术（FHO）或全髋关节置换术（THR），适用于髋关节构型不良、复位失败或慢性脱位的病例[2]。THR提供关节重建，并发症率约为6%，而FHO在小型犬中效果更好[4]。术后护理包括4-6周的活动限制，以及使用抗炎药和营养补充剂的医疗管理，以预防骨关节炎发展[1]。

### Sources

[1] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[2] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[3] Hip luxations (Proceedings): https://www.dvm360.com/view/hip-luxations-proceedings
[4] Joint Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 预防与预后

**预防措施**
环境伤害预防对髋关节脱位至关重要[1]。体重管理和适当的运动方案有助于减少关节应力和创伤风险[2]。避免高强度冲击活动和确保安全环境可最大限度地减少脱位可能性。由于潜在的髋关节发育不良易导致脱位，早期筛查和管理发育不良关节至关重要[1][3]。通过控制运动维持肌肉力量有助于关节稳定。

**预后因素**
如果在损伤后尽快实现复位和稳定，髋关节脱位的预后为一般到良好[4]。在4-5天内进行早期治疗可显著改善结果[1]。治疗延迟超过3天不一定使预后恶化，但仍建议及时干预[4]。并发损伤的存在、患者年龄和并发髋关节发育不良影响恢复结果[1][4]。

**恢复和长期结果**
开放复位达到85%的成功率，显著优于单独闭合复位[4]。长期研究显示，62%的犬没有跛行，而20%仍有严重跛行[4]。脱位后55-62%的患者会发展为骨关节炎，在体重较重的犬中更为明显[4]。32%的恢复犬可触及摩擦音，48%有疼痛，但92%保持正常的髋关节活动范围[4]。即使少量减重（体重的6%）也能显著减少跛行[2]。

### Sources

[1] DVM 360 Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[2] DVM 360 Obesity and orthopedic disease: a relationship to remember: https://www.dvm360.com/view/obesity-and-orthopedic-disease-relationship-remember
[3] DVM 360 Surgery STAT: Diagnosis and treatment of juvenile canine hip dysplasia: https://www.dvm360.com/view/surgery-stat-diagnosis-and-treatment-juvenile-canine-hip-dysplasia
[4] DVM 360 Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
