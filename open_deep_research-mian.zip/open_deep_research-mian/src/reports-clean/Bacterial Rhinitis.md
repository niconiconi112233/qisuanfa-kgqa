# 伴侣动物细菌性鼻炎

细菌性鼻炎在小动物兽医临床实践中代表一项重要的临床挑战，主要作为病毒性呼吸道疾病或其他易感条件后的继发感染发生于犬和猫。虽然原发性细菌性鼻炎罕见，但当猫疱疹病毒-1或犬副流感病毒等病原体损害正常鼻腔防御机制时，常发生继发性细菌并发症。本报告探讨了细菌性鼻炎的病理生理学、临床表现、诊断方法和治疗策略，特别强调基于培养结果的抗菌药物选择以及通常需要4-8周延长抗生素治疗的慢性病例管理。

## 摘要

本综合综述揭示，伴侣动物的细菌性鼻炎主要作为继发感染而非原发性疾病发生。主要病原体包括多杀性巴氏杆菌、支气管败血波氏杆菌和葡萄球菌属，诊断依赖黏液脓性鼻分泌物、鼻镜检查和细菌培养以指导治疗。治疗需要3-6周的延长抗生素治疗，阿莫西林-克拉维酸、克林霉素和多西环素提供良好的组织穿透性。

| 方面 | 犬 | 猫 |
|--------|------|------|
| 主要原因 | 继发于创伤、异物 | 继发于FHV-1、杯状病毒 |
| 常见病原体 | 波氏杆菌、葡萄球菌 | 巴氏杆菌、混合细菌 |
| 诊断影像学 | CT优于X线摄影 | 慢性病例使用CT |
| 治疗持续时间 | 最少4-6周 | 慢性病例4-8周 |
| 预防 | 环境管理 | 核心疫苗、减压 |

成功管理需要解决潜在的易感因素，疫苗接种计划和环境控制作为主要预防策略。慢性病例预后谨慎，但通过适当的长期抗生素管理可以改善生活质量。

## 疾病概述与流行病学

犬和猫的细菌性鼻炎定义为由细菌病原体引起的鼻腔炎症，特征为黏液脓性鼻分泌物和相关临床症状[1]。大多数病例作为继发感染而非原发性细菌疾病发生，原发性细菌性鼻炎在两个物种中均被认为是罕见的[2]。

继发性细菌性鼻炎通常在病毒感染后发展，特别是猫的猫疱疹病毒-1（FHV-1）和杯状病毒感染，这些感染损害鼻甲结构并破坏正常黏液纤毛清除机制[1]。这为细菌定植和慢性感染创造了有利条件。其他易感因素包括创伤、异物、肿瘤、牙周病和炎性息肉[2]。

发病率在物种和环境之间差异显著。在猫中，细菌性鼻炎常作为病毒性上呼吸道感染的后遗症，几乎所有表现黏液脓性鼻分泌物的猫其疾病都有细菌成分[1]。然而，与收容所环境相比，从宠物猫中分离出的原发性细菌病原体如支气管败血波氏杆菌和支原体属较少见[1]。犬可能因各种潜在条件而发展为细菌性鼻炎，尽管原发性细菌感染不常见[2]。

风险因素包括免疫抑制状态、拥挤的饲养条件、幼年和解剖学倾向如短头颅构型。慢性细菌性鼻炎可进展为软骨炎和骨髓炎，需要数周的延长抗生素治疗[1]。传统X线摄影显示有限的诊断敏感性，在一项42只犬的回顾性研究中，只有10%的炎症性鼻炎病例得到准确诊断[3]。

### Sources

[1] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[2] Nasal disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/nasal-disorders-dog-and-cat-proceedings
[3] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors

## 常见细菌病原体

现有的细菌性鼻炎病原体综合概述需要细化，专注于犬和猫同时保持临床准确性。多杀性巴氏杆菌作为主要的共生生物，在免疫抑制或应激条件下变得具有致病性[3]。这种革兰氏阴性细菌当宿主防御机制被原发性病毒病原体或环境损害破坏时，常建立鼻腔感染[5]。

支气管败血波氏杆菌代表一种重要的呼吸道病原体，能够引起原发性细菌性鼻炎，特别是在犬中，尽管它更常作为继发性病原体[3][6]。这种生物体具有高度传染性，常从多动物环境中分离出来，其中应激和过度拥挤促进疾病传播。

葡萄球菌属，包括金黄色葡萄球菌，构成细菌性鼻炎中重要的革兰氏阳性病原体[3][5]。这些生物体是正常共生菌群的一部分，但当呼吸道防御机制被原发性病毒感染如犬的犬瘟热、副流感病毒或犬腺病毒，以及猫的鼻气管炎病毒或杯状病毒破坏时，可变得具有致病性[5]。

继发性细菌感染使两个物种的病毒性呼吸道疾病管理复杂化[5]。混合细菌群体常发展，通常涉及革兰氏阴性和革兰氏阳性生物体的组合，增加抗菌药物耐药性风险并使治疗方案复杂化。

### Sources

[1] Bacterial Diseases of Pet Birds: https://www.merckvetmanual.com/exotic-and-laboratory-animals/pet-birds/bacterial-diseases-of-pet-birds
[2] Managing respiratory diseases in exotic mammals: https://www.dvm360.com/view/managing-respiratory-diseases-exotic-mammals-proceedings
[3] Respiratory diseases of small mammals (Proceedings): https://www.dvm360.com/view/respiratory-diseases-small-mammals-proceedings
[4] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[5] Rhinitis and Sinusitis in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/rhinitis-and-sinusitis-in-dogs
[6] Rhinitis and Sinusitis in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/rhinitis-and-sinusitis-in-dogs-and-cats

## 临床表现与诊断

犬和猫的细菌性鼻炎表现为有助于诊断的特征性临床症状。最一致的临床症状是黏液脓性鼻分泌物[1]。其他常见症状包括打喷嚏、抓挠面部、呼吸鼾声、张口呼吸和严重病例的鼻出血[1][4]。

体格检查发现晚期病例有鼾声呼吸和下颌淋巴结肿大[1]。鼻分泌物的性质和分布提供诊断线索。单侧分泌物常提示异物参与、肿瘤或真菌感染，而双侧分泌物通常表示更弥漫性炎症过程或病毒/细菌感染[4]。随着继发性细菌感染的发展，分泌物可能从浆液性进展为黏液脓性[1]。

诊断方法从全面的病史和体格检查开始。传统X线摄影敏感性有限，仅能准确诊断10%的炎症性鼻炎病例[1]。计算机断层扫描提供更佳的可视化效果，推荐用于评估疾病程度，显示鼻腔软组织密度和不等程度的鼻甲破坏[4]。

鼻镜检查允许直接可视化和细菌培养样本收集[1][4]。细菌培养材料最好通过从鼻腔深处放置良好的拭子获得，因为正常鼻腔菌群包括各种细菌[1]。一两种生物体的多个菌落生长比多种不同生物体的稀疏生长更具诊断意义[1]。培养和敏感性测试应指导抗生素选择，特别是在需要治疗4-6周的慢性病例中[2]。

### Sources
[1] Nasal disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/nasal-disorders-dog-and-cat-proceedings
[2] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings  
[3] Rhinitis and Sinusitis in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/rhinitis-and-sinusitis-in-dogs
[4] Clinical approach to nasal discharge (Proceedings): https://www.dvm360.com/view/clinical-approach-nasal-discharge-proceedings

## 治疗与管理

细菌性鼻炎治疗需要针对原发性细菌病原体和继发并发症的多方面方法[1]。广谱抗生素构成治疗的基石，当鼻腔组织的细菌培养鉴定出非正常共生生物时，选择最好基于培养和敏感性结果[3]。然而，细菌培养可能具有有限的诊断价值，因为原发性细菌性鼻炎在犬和猫中极为罕见，通常继发于其他鼻腔疾病[2]。

经验性抗生素治疗应持续3-6周等待培养结果[1]。当培养中生长多种生物体时，其意义可疑，但如果分离出单一非共生细菌物种，敏感性结果指导抗生素选择[3]。有效穿透软骨和骨的抗生素包括阿莫西林-克拉维酸、克林霉素和头孢氨苄[1]。多西环素和阿奇霉素提供优异的鼻组织穿透性和对支原体属的有效性[1]。

支持性护理措施对患者舒适和恢复至关重要。严重病例可能需要静脉输液管理脱水和通过饲管提供营养支持[1]。生理盐水冲洗有助于清除厚分泌物，而加湿减少分泌物黏度[1]。间歇性血管收缩鼻减充血剂提供暂时缓解，但应仅在需要时使用[1]。

慢性病例带来显著的管理挑战，常需要长期间歇性抗生素治疗当发作发生时[3]。解决潜在原因如牙科疾病、异物或解剖异常对成功治疗结果至关重要[1]。

### Sources

[1] Rhinitis and Sinusitis in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/rhinitis-and-sinusitis-in-dogs-and-cats
[2] Diagnostic Techniques for Respiratory Disease in Animals: https://www.merckvetmanual.com/respiratory-system/respiratory-system-introduction/diagnostic-techniques-for-respiratory-disease-in-animals
[3] Snots and snuffles: chronic feline upper respiratory: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings

Looking at the provided source material, I notice it contains mostly content about exotic mammals, human allergies, and general respiratory topics rather than specific information about bacterial rhinitis prevention and prognosis in dogs and cats. However, I can synthesize the existing section content with the relevant information available.

## 预防与预后

**预防措施**

疫苗接种仍然是预防猫细菌性鼻炎的基石[1]。含有FHV-1和FCV的核心疫苗应根据AAFP指南接种，初始系列从9周龄开始，1岁时加强接种，然后每3年一次[2]。鼻内疫苗可能提供更快速的保护（72小时内）和更好的局部免疫力[2]。 

波氏杆菌疫苗接种应主要考虑高风险猫，如有培养证实的疫情暴发的收容所中的猫或有呼吸道问题的猫[1]。环境管理至关重要，包括使用Feliway等产品减压、多猫环境中的适当通风和减少过度拥挤[3]。应激是疾病发展的重要易感因素，应通过适当的住房和环境控制来最小化[5]。

**预后与治疗持续时间**

细菌性鼻炎的预后因慢性程度和潜在因素而异[1]。有中性粒细胞细胞学和阳性细菌培养的猫通常需要4-8周的适当抗生素治疗，取决于放射学严重程度和治疗反应[1]。由于细菌性鼻炎可导致软骨炎和骨髓炎，慢性病例需要延长治疗时间[1]。

大多数慢性鼻鼻窦炎猫预后谨慎，因为临床症状难以控制且不可能完全根除[4]。然而，通过适当的长期管理，生活质量可以显著改善[4]。

### Sources

[1] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[2] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings  
[3] WVC 2017: Managing Cats with Upper Respiratory Infection - Viral Causes: https://www.dvm360.com/view/wvc-2017-managing-cats-with-upper-respiratory-infection--viral-causes
[4] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[5] Managing respiratory diseases in exotic mammals (Proceedings): https://www.dvm360.com/view/managing-respiratory-diseases-exotic-mammals-proceedings
