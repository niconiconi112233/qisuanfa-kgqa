# 犬冠状病毒性肠炎

犬冠状病毒性肠炎是一种常见但通常较轻微的胃肠道感染，影响全球范围内的犬只。虽然该疾病通常表现为自限性腹泻和呕吐，但了解其临床表现、诊断方法和治疗策略对兽医从业者仍然至关重要。本报告全面考察了犬冠状病毒性肠炎的各个方面，从其流行病学意义和病原体特征到临床表现和治疗方案。分析涵盖了诊断方法、预防策略、鉴别诊断考量以及影响患者预后的因素。主要发现强调了冠状病毒与更严重的病毒性肠炎（如细小病毒）之间的对比，强调了准确诊断和适当支持性护理对实现最佳患者康复的重要性。

## 疾病概述

**定义**

犬冠状病毒性肠炎是由犬冠状病毒（CCoV）引起的轻至中度胃肠道感染，该病毒与引起呼吸道疾病的犬呼吸道冠状病毒不同[1]。这种肠道冠状病毒主要影响小肠上皮，导致犬只出现急性腹泻和呕吐，尤其是幼犬和免疫功能低下的动物。

**流行病学背景**

犬冠状病毒在全球范围内广泛分布，血清学研究表明全球犬群暴露率很高。该病毒表现出显著的环境持久性，在有利的条件下可在受污染环境中长期存活[1][2]。温度、湿度和有机物等环境因素影响病毒在宿主体外的存活。

传播主要通过粪口途径发生，感染犬只在疾病急性阶段通过粪便排出大量病毒。该病毒在高密度饲养环境中（如犬舍、收容所和繁殖场）容易传播，在这些地方，压力和拥挤促进了疾病传播[1][2]。幼犬由于免疫系统不成熟和可能缺乏母体抗体保护而特别易感。

虽然来自中国和全球的特定患病率数据因地区而异，但犬冠状病毒属于更广泛的冠状病毒科，该科包含数百种影响全球各种脊椎动物的毒株[3]。该病毒表现出显著的基因可塑性和重组能力，这促使其在犬群中的广泛分布[3]。

### Sources
[1] Canine infectious respiratory disease: Challenges and considerations in animal shelters (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings
[2] Canine infectious respiratory disease complex: management and prevention in canine populations (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[3] SARS-CoV-2 Infection in Animals - Generalized Conditions: https://www.merckvetmanual.com/generalized-conditions/sars-cov-2/sars-cov-2-infection-in-animals

## 常见病原体

犬冠状病毒性肠炎由犬肠道冠状病毒（CECoV）引起，这是一种有包膜的单链RNA病毒[1]。主要病原体表现出基因多样性，有两个主要基因型组：CCoV-I和CCoV-II，其中CCoV-II根据刺突蛋白基因中的氨基酸序列进一步细分为CCoV-IIa和CCoV-IIb亚型[1]。

冠状病毒是有包膜的病毒，直径约120-160纳米，具有特征性的表面刺突糖蛋白突起[5]。病毒包膜包含结构蛋白，包括刺突蛋白（S）、包膜蛋白（E）、膜蛋白（M）和核衣壳蛋白（N），基因组编码结构蛋白和非结构蛋白[5]。

虽然冠状病毒是一个影响多个物种的大科，但犬冠状病毒特异性地靶向犬的肠道上皮[4]。该病毒表现出跨物种进化关系，因为犬细小病毒被认为起源于猫泛白细胞减少症病毒，而SARS-CoV-2显示出与强毒犬冠状病毒株类似的极端CpG二核苷酸缺乏[4]。

与其他肠道病原体的共同感染很常见，并可能加剧临床疾病。已记录有与弯曲杆菌属、沙门氏菌属、贾第鞭毛虫属和其他冠状病毒的并发感染[1]。这些共同感染可能使诊断复杂化并加重胃肠道症状的严重程度。

发病机制涉及病毒在肠道上皮细胞中复制，导致刷状缘破坏和绒毛萎缩[3]。与影响多个器官系统的一些冠状病毒不同，CECoV主要局限于胃肠道，特异性地靶向肠绒毛的成熟顶端上皮细胞[3]。

### Sources
[1] Merck Veterinary Manual Canine Parvovirus Infection: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/feline-enteric-coronavirus
[2] Merck Veterinary Manual Porcine Coronaviral Enteritis: https://www.merckvetmanual.com/digestive-system/intestinal-diseases-in-pigs/porcine-coronaviral-enteritis
[3] Merck Veterinary Manual Feline Enteric Coronavirus Infection: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-enteric-coronavirus-infection
[4] SARS-CoV-2 Infection in Animals: https://www.merckvetmanual.com/generalized-conditions/sars-cov-2/sars-cov-2-infection-in-animals
[5] Merck Veterinary Manual Feline coronavirus genome organization and virion morphology: https://www.merckvetmanual.com/multimedia/image/feline-coronavirus-genome-organization-and-virion-morphology

## 临床症状和体征

我需要更正现有部分的内容，因为它似乎包含了关于**猪**冠状病毒性肠炎的信息，而不是**犬**冠状病毒性肠炎。提供的资料来源关注的是犬冠状病毒感染，这与现有内容中描述的猪版本有显著差异。

**犬冠状病毒性肠炎在大多数犬中表现为轻微的自限性疾病**[1][2]。最常见的临床表现是**中度严重腹泻伴短暂厌食和偶尔呕吐**[2]。受影响的犬通常产生**非常恶臭的粪便，可能带有橙色调**，很少观察到黑便或血便[2]。

**年龄相关的表现**在疾病严重程度上显示出重要区别。**成年犬通常无需任何干预即可康复**，仅经历轻微、短暂的症状[2]。然而，**新生儿和儿科患者是唯一可能出现危及生命疾病的群体**[2]。**幼犬对脱水的耐受性比成年动物差，厌食会导致低血糖和器官衰竭**[2]。

**潜伏期和持续时间**与细小病毒感染明显不同。虽然**冠状病毒性肠炎以轻微和自限性临床症状为特征**[1]，**即使在更严重的病例中也很少发生脱水，但静脉输液治疗24-48小时通常足够**支持受影响的犬直到疾病消退[2]。

**品种易感性**信息在现有文献中有限，尽管调查表明**多达三分之二的腹泻犬可能正在排出冠状病毒**[2]。**冠状病毒引起的疾病（肠绒毛破坏）通常比细小病毒性肠炎轻微**[1]，这使得区分这些病毒性肠炎在预后和治疗计划方面临床上很重要。

### Sources
[1] Managing patients with parvoviral enteritis (Proceedings): https://www.dvm360.com/view/managing-patients-with-parvoviral-enteritis-proceedings
[2] Non-core vaccines: FIP, canine corona, lyme, and Bordetella (Proceedings): https://www.dvm360.com/view/non-core-vaccines-fip-canine-corona-lyme-and-bordetella-proceedings

## 诊断方法

犬冠状病毒性肠炎的诊断依赖于全面的临床评估结合特定的实验室检测方法。临床表现评估形成基础，重点关注易感幼犬（通常6-12周龄）呕吐、水样至血性腹泻和精神不振的特征性三联征[1]。

实验室确认主要使用**粪便抗原检测方法**。商业ELISA检测提供快速、即时诊断，对检测新鲜粪便样本中的病毒抗原具有良好的敏感性和特异性[1]。**PCR检测**提供更高的敏感性，即使在抗原水平低时也能检测病毒遗传物质，使其在感染早期阶段特别有价值[1]。

粪便样本的**RT-PCR检测**仍然是确诊的金标准，能够区分冠状病毒性肠炎与其他肠道病原体[2]。最近的进展表明，**实时PCR**比常规PCR提供更高的敏感性和特异性，同时更快速[3]。**1组犬冠状病毒**已通过PCR在严重肠炎病例中成功鉴定[4]。

**诊断局限性**包括病毒排出量低时潜在的假阴性结果、与其他冠状病毒的交叉反应性，以及需要新鲜粪便样本以获得最佳检测性能[1]。**血清学检测**可用于犬呼吸道冠状病毒，尽管临床医生必须指定**呼吸道**而非肠道毒株[5]。组合检测方法，包括评估白细胞反应的全血细胞计数和全面的粪便病原体组合检测，增强了复杂病例的诊断准确性。

### Sources

[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/en/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[2] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[3] Viral diagnostics: What do the results mean? (Proceedings): https://www.dvm360.com/view/viral-diagnostics-what-do-results-mean-proceedings
[4] Update on viral enteritis (Proceedings): https://www.dvm360.com/view/update-viral-enteritis-proceedings-0
[5] Emerging viral pathogens (Proceedings): https://www.dvm360.com/view/emerging-viral-pathogens-proceedings-0

## 治疗方案

犬冠状病毒性肠炎的治疗以支持性护理为中心，因为没有特定的抗病毒疗法。主要目标包括液体补充、电解质纠正和症状管理[1]。

**液体疗法**代表治疗的基石。及时静脉输注平衡晶体溶液（如乳酸林格氏液或Normosol-R）对于纠正脱水和持续损失至关重要[2]。维持液体计划应解决补液量（脱水百分比×体重×0.6）、维持需求（30×体重+70 mL/24小时）以及呕吐和腹泻的持续损失[2]。皮下输液可能足以满足轻度病例，但对于中重度脱水则不够。

**止吐疗法**应在呕吐持续导致脱水时实施。马罗匹坦（1 mg/kg皮下或静脉注射，每24小时一次）和昂丹司琼（0.5 mg/kg静脉注射，每8小时一次）是有效的选择[3]。甲氧氯普胺通过1-2 mg/kg/天静脉持续输注提供止吐和促动力作用[3]。

**电解质管理**需要仔细监测。静脉输液中的钾补充（20-40 mEq/L）可预防低钾血症，而葡萄糖（2.5-5%）可解决低血糖[2]。液体治疗的定期监测包括评估水合状态、体重、尿产量和电解质水平[2]。

**抗菌疗法**在怀疑细菌移位时可能是必要的，尽管冠状病毒性肠炎通常表现出比细小病毒病更轻微的临床症状[1]。氨苄青霉素或头孢菌素提供适当的覆盖范围。

**营养支持**通过早期肠内喂养促进更快恢复并维持肠道屏障功能[3]。门诊管理对于轻度病例通常是可行的，包括皮下输液、口服电解质溶液和止吐药物。

### Sources
[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[2] Maintenance Fluid Plan in Animals: https://www.merckvetmanual.com/therapeutics/fluid-therapy/maintenance-fluid-plan-in-animals
[3] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

## 预防措施

由于缺乏特定疫苗和病毒的环境持久性，犬冠状病毒性肠炎的当前预防策略仍然有限。通过严格的消毒方案进行环境控制成为主要的防御机制[1]。

兽医权威机构不推荐犬冠状病毒疫苗接种。AAHA犬疫苗接种工作组正式建议不要接种冠状病毒疫苗，因为该疾病引起的症状如此轻微，以至于潜在的疫苗接种风险超过益处[2]。改良活疫苗和灭活疫苗都未能证明减轻疾病严重程度，并且由于疫苗接种组和对照组中的疾病表现最小，有效性研究无法准确确定免疫持续时间[2]。

有效消毒剂包括1:32稀释的次氯酸钠（漂白剂）、加速过氧化氢产品（Accel®）和过一硫酸钾化合物（Trifectant®）[1]。这些试剂需要表面预清洁和足够的接触时间以灭活病毒。

多犬环境需要对受影响动物实施严格的隔离方案。单独的住房、专用的个人防护装备（包括长袖袍和鞋套）以及分组管理有助于防止交叉污染[1]。管理重点是通过机械清除和化学消毒最小化环境病毒载量[1]。暴露动物可能需要14天的隔离期[1]。寄养安置减少了收容所种群密度和传播风险[1]。

### Sources
[1] Canine parovirus and feline panluekopenia: New ideas for prevention: https://www.dvm360.com/view/canine-parovirus-and-feline-panluekopenia-new-ideas-prevention-risk-assessment-and-treatment-parts-1
[2] Non-core vaccines: FIP, canine corona, lyme, and Bordetella (Proceedings): https://www.dvm360.com/view/non-core-vaccines-fip-canine-corona-lyme-and-bordetella-proceedings

## 鉴别诊断

犬冠状病毒性肠炎表现为非特异性胃肠道体征，与其他感染性和寄生虫性疾病有显著重叠。主要鉴别诊断是犬细小病毒感染，它引起更严重的出血性腹泻，通常在感染后5-7天内发展[1]。细小病毒产生严重的白细胞减少症、淋巴细胞减少症和中性粒细胞减少症，将其与冠状病毒引起的较轻微白细胞变化区分开来。

寄生虫感染代表另一个主要的鉴别诊断。贾第鞭毛虫属引起慢性吸收不良性腹泻，伴有粘液样、苍白的粪便和强烈气味，但受影响的猫通常无发热且总蛋白值正常[2]。隐孢子虫属感染通常保持亚临床状态，但可引起小肠腹泻和体重减轻，特别是在免疫功能低下的动物中[2]。

额外的鉴别诊断包括其他病毒性肠炎，如轮状病毒和细菌病原体，如沙门氏菌属和弯曲杆菌属。区分因素包括全身体征的严重程度、脱水程度和实验室异常。与细小病毒相比，冠状病毒通常引起较轻微的临床疾病，血液学变化较不明显[1]。

细菌性肠炎通常表现为伴随的全身炎症和白细胞计数升高，这与冠状病毒感染中典型的轻微实验室变化形成对比。结合信号特征、疫苗接种史、临床表现严重程度和特定病原体检测指导准确的鉴别诊断[1]。

### Sources

[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

[2] An update on three important protozoan parasitic infections: https://www.dvm360.com/view/update-three-important-protozoan-parasitic-infections-cats-cryptosporidiosis-giardiasis-and-tritrich

## 预后

在适当的支持性护理下，犬冠状病毒性肠炎的预后通常极好。大多数犬在1-2周内完全康复，没有长期并发症。然而，在疾病严重程度和死亡率方面与其他病毒性肠炎存在重要区别[1][2]。

**预期临床结果**
轻度至中度感染的犬通常在开始适当支持性治疗后24-48小时内显示出改善。腹泻完全消退和恢复正常食欲通常在7-14天内发生。冠状病毒性肠炎的自限性意味着大多数犬无需特定抗病毒治疗即可完全康复[1]。

**生存率和死亡率**
犬冠状病毒性肠炎以轻微和自限性临床症状为特征，与更严重的病毒性肠炎（如细小病毒）形成鲜明对比[3]。在健康的犬中死亡率极低，大多数研究报告在提供基本支持性护理时生存率接近100%。死亡很罕见，通常仅发生在严重免疫功能低下的动物或患有显著并发疾病的动物中[2]。

**影响恢复的因素**
年龄显著影响预后，6周以下的幼犬由于免疫系统不成熟而并发症风险增加。与其他肠道病原体（如细小病毒）的并发感染可能恶化结果并延长恢复时间。压力因素，包括营养不良、过度拥挤或并发疾病，可能延长临床症状[2]。

**长期影响**
从冠状病毒性肠炎康复的犬会对再感染产生免疫力。没有记录到从无并发症病例康复后出现慢性后遗症或长期胃肠功能障碍[1]。

### Sources
[1] Therapy and vaccination for a new canine parvovirus: https://www.dvm360.com/view/therapy-and-vaccination-new-canine-parvovirus-proceedings
[2] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[3] Intensive care management of severe viral and bacterial enteritis (Proceedings): https://www.dvm360.com/view/intensive-care-management-severe-viral-and-bacterial-enteritis-proceedings
