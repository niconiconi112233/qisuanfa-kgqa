# 伴侣动物的暴露性角膜炎

暴露性角膜炎是兽医实践中一种重要的眼科疾病，尤其影响具有眼睑覆盖不足解剖学倾向的短头颅犬种。这种角膜疾病是由于泪膜保护不足和不完全眨眼导致的，进而导致进行性角膜干燥和潜在威胁视力的并发症。随着选择性繁殖实践在流行伴侣动物品种中强调极端面部特征，该疾病的患病率有所增加。本综合报告探讨了犬猫暴露性角膜炎的病理生理学、临床表现和管理策略，特别强调品种特异性考虑、诊断方法以及维护角膜健康和视觉功能所必需的药物和手术治疗选择。

## 摘要

暴露性角膜炎是一种多方面疾病，需要全面了解解剖学易感因素，特别是在哈巴狗和波士顿梗等短头颅品种中。该疾病从简单的角膜干燥发展到可能威胁视力的并发症，包括深层基质溃疡和继发感染。虽然主要是非感染性的，但葡萄球菌和假单胞菌属的继发性细菌定植显著增加了管理和预后难度。

临床诊断依赖于结合希默泪液测试、荧光素染色和眼睑功能评估的全面检查。治疗方法从保守的润滑疗法到明确的手术干预，如睑缘缝合术和眦成形术。早期干预至关重要，因为浅表病例通常不会造成永久性视力损伤，而慢性或复杂病例可能导致角膜瘢痕和视力下降。

| 治疗方法 | 适应症 | 结果 |
|---|---|---|
| 药物治疗 | 早期/轻度病例 | 定期润滑效果良好 |
| 临时睑缘缝合术 | 急性创伤，眼球脱位术后 | 愈合期间提供保护 |
| 永久性眦成形术 | 慢性眼睑闭合不全 | 长期预防 |

及时识别和适当干预使预后保持良好，强调针对高风险人群的品种特异性预防策略和主人教育的重要性。

## 疾病概述

暴露性角膜炎是一种由于眼睑覆盖不足或不完全眨眼导致的角膜疾病，引起角膜表面干燥和炎症[1]。当眼睑的保护机制无法维持适当的角膜水合作用和免受环境因素保护时，就会发生这种情况。

流行病学模式显示强烈的品种易感性，特别影响眼眶浅和眼球突出的短头颅犬[4]。常见受影响的品种包括哈巴狗、波士顿梗、西施犬、斗牛犬和北京犬，因为它们的解剖结构具有巨睑（过大的睑裂）和眼球突出[9][10]。这些结构异常使这些品种易患眼睑闭合不全或不完全眼睑闭合，这是暴露性角膜炎的主要危险因素。

眼球脱位的后遗症包括眼睑闭合不全，导致暴露性角膜炎、干性角膜结膜炎和角膜溃疡[11]。该疾病可影响任何年龄的犬，但在中年至老年动物中更为常见，因为代偿机制开始失效[9]。文献中未报告显著的性别偏好。在短头颅品种中，患病率似乎在增加，可能是由于强调极端面部特征的选择性繁殖实践[10]。

### Sources

[1] Canine corneal diseases: Treatment for transparency: https://www.dvm360.com/view/canine-corneal-diseases-treatment-transparency-greater-federal-stimulus-proceedings
[4] Ocular emergencies--what to do next: https://www.dvm360.com/view/ocular-emergencies-what-do-next
[9] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[10] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings
[11] Ocular emergencies: Presenting signs, initial exam and treatment (Proceedings): https://www.dvm360.com/view/ocular-emergencies-presenting-signs-initial-exam-and-treatment-proceedings

## 常见病原体

虽然暴露性角膜炎主要是由眼睑保护不足引起的非感染性疾病，但继发性细菌和病毒感染经常使暴露的角膜表面复杂化。

**病毒病原体**
疱疹病毒是暴露性角膜炎病例中最重大的病毒威胁。犬疱疹病毒-1（CHV-1）可引起成年犬的结膜炎、角膜水肿和树枝状角膜溃疡[1]。在猫中，猫疱疹病毒-1（FHV-1）通常引起角膜溃疡和角膜炎，树枝状溃疡被认为是疱疹病毒感染的特征性表现[2]。这两种病毒都建立终身潜伏感染，并可能在压力或免疫抑制期间重新激活[2]。

**细菌病原体**
继发性细菌定植常见于受损的角膜表面。葡萄球菌属经常定植受损的角膜上皮，而假单胞菌属特别令人担忧，因为它们能够产生蛋白水解酶，迅速消化角膜基质，导致溶解性溃疡[6]。链球菌属也可能导致继发感染，但比上述病原体少见。

**其他相关病原体**
真菌生物，包括曲霉属和枝顶孢属，可能机会性感染慢性暴露的角膜表面，特别是在免疫功能低下患者或伴有干性角膜结膜炎的患者中[10]。这些感染通常表现为角膜斑块，伴有白色蓬松的基质浸润，需要积极的抗真菌治疗。

### Sources

[1] Merck Veterinary Manual Canine Herpesvirus Infection: https://www.merckvetmanual.com/infectious-diseases/canine-herpesvirus-infection/canine-herpesvirus-infection

[2] DVM 360 Feline herpesvirus and calicivirus infections: https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings

[6] Merck Veterinary Manual The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

[10] DVM 360 Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog

## 临床症状和体征

暴露性角膜炎由于泪膜保护不足和眼睑闭合而表现出特征性角膜变化。主要体征包括角膜干燥，表现为暗淡、混浊外观和泪膜立即破裂时间（正常为20秒）[1]。睑裂间上皮通常吸收荧光素染色并显示粗糙[1]。

随着病情发展，上皮缺陷发展为浅表溃疡，特别是在眼睑之间暴露的中央角膜区域。慢性病例表现出从角膜缘开始的角膜血管化，伴有从内侧开始的色素沉着，并可进展到整个角膜[1]。长期暴露可能发生纤维增生，导致角膜瘢痕和混浊[2]。

**品种特异性模式**在短头颅犬和猫中显著。眼眶浅和眼球突出的犬，如西施犬、哈巴狗和波士顿梗，即使在希默泪液测试结果正常的情况下，眨眼时也表现出中央角膜覆盖不完全[1]。哈巴狗特征性地发展为内侧倒睫，伴有从内侧开始的显著色素性角膜炎[1]。短头颅品种由于其解剖学倾向，特别容易因感染性角膜炎而丧失基质[6]。

**非典型表现**包括泪液产生正常但由于睑板腺炎导致泪膜质量差的病例，导致快速蒸发和干斑形成[1]。一些患者可能表现出反射性流泪，这可以掩盖潜在的干燥问题[1]。

### Sources
[1] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[2] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] Disorders of the Cornea in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-cornea-in-dogs
[4] Characteristics of corneal pigmentation in Pugs: https://avmajournals.avma.org/view/journals/javma/243/5/javma.243.5.667.xml
[5] Eyelids in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals
[6] Deep Stromal Corneal Ulcers in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/deep-stromal-corneal-ulcers-descemetocele-and-iris-prolapse-in-small-animals

## 诊断方法

临床评估是暴露性角膜炎诊断的基石。从业者从详细的病史采集和体格检查开始，评估易感因素，如眼睑闭合不全、面神经麻痹或解剖异常[4]。临床表现包括评估角膜表面完整性、泪膜分布和干燥体征，包括角膜外观暗淡[1]。

希默泪液测试（STT）对于评估泪液产生至关重要。正常值在犬中>15毫米/分钟，尽管大多数健康犬表现出>20毫米[4]。10-15毫米之间的值应怀疑干性角膜结膜炎，这通常导致暴露性角膜炎[7]。测试应在应用荧光素或局部麻醉剂之前进行，以确保准确性[1]。

荧光素染色显示暴露性角膜炎特征性的上皮缺陷。应在昏暗光线下使用钴蓝滤光片应用染色剂以获得最佳可视化效果[4]。暴露性角膜炎的水平带通常出现在受影响患者的中央角膜区域[1]。

角膜细胞学有助于排除感染原因并识别炎症细胞群。在嗜酸性角膜炎病例中，Wright-Giemsa染色可显示嗜酸性粒细胞，而当怀疑感染性角膜炎时，Gomori六胺银等特殊染色有助于识别真菌元素[3][6]。

先进成像，包括使用荧光素的泪膜破裂时间评估，需要专业设备和兽医眼科医生专业知识[2]。

### Sources

[1] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[2] Investigation of fluorescein stain-based tear film breakup time ...: https://avmajournals.avma.org/view/journals/ajvr/82/12/ajvr.21.01.0002.xml
[3] Ophthalmology Challenge: Aggressive ulcerative keratitis ...: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[4] Ophthalmology Made Simple: https://www.dvm360.com/view/ophthalmology-made-simple
[5] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[6] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[7] Canine corneal diseases: secrets for transparency greater ...: https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings

## 治疗选择

暴露性角膜炎治疗侧重于三种主要方法：药物干预、手术矫正和支持性护理。

**药物治疗**构成治疗的基础。局部润滑剂保护和滋润暴露的角膜表面，需要频繁应用[1]。人工泪液，特别是粘性制剂，有助于减少摩擦和继发性炎症[5]。局部抗生素预防继发性细菌感染，而环孢素或他克莫司等抗炎药物可减少角膜炎症和血管化[2]。在伴有免疫介导成分的病例中，局部皮质类固醇可能有益，但必须谨慎使用以避免并发症[2][4]。

**手术干预**解决潜在的解剖学原因。临时睑缘缝合术使用通过软橡胶支架的水平褥式模式将上下眼睑缝合在一起，在急性发作或创伤性眼球脱位期间提供保护[1]。该程序作为生理性绷带，同时允许药物应用。对于永久性矫正，内侧眦成形术在患有眼睑闭合不全和暴露性角膜炎的短头颅品种中减少睑裂[1][3]。该手术涉及切除3-4毫米的眼睑边缘并分两层闭合，有效减少角膜暴露[3]。外侧眦成形术也可用于永久性减少易患眼科眼球脱位犬的睑裂宽度[1]。

**护理策略**包括环境修改和支持措施。患者应避免多风条件、通风口和车窗暴露[6]。伊丽莎白圈防止自伤，而加湿器可能有益于严重病例[6]。定期清除粘液性分泌物和轻柔的眼睑清洁有助于维持眼表健康[6]。

### Sources
[1] Cryptorchid surgery and simple ophthalmic procedures: https://www.dvm360.com/view/cryptorchid-surgery-and-simple-ophthalmic-procedures-proceedings
[2] Canine corneal diseases: Treatment for transparency: https://www.dvm360.com/view/canine-corneal-diseases-treatment-transparency-greater-federal-stimulus-proceedings
[3] Everyday answers for common conditions of the eyelid: https://www.dvm360.com/view/everyday-answers-common-conditions-eyelidconjunctiva-proceedings
[4] Feline corneal diseases: herpesvirus and more: https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[5] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[6] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0

## 预防措施

环境控制是伴侣动物暴露性角膜炎预防的基石。短头颅品种由于其角膜暴露和相关并发症的解剖学倾向而需要特别关注[1]。定期牙齿预防可能减少这些品种的口腔细菌负荷，潜在减少结膜污染[1]。

对于高风险患者，保护措施包括维持适当的湿度水平并避免加剧角膜干燥的多尘或多风环境。频繁应用眼润滑剂有助于维持易感动物的角膜水合[2]。

品种特异性方法对短头颅犬和猫至关重要。永久性内侧或外侧睑缘缝合术有效减少睑裂长度并改善眼睑对角膜的覆盖[3][4]。这些手术干预提供长期保护，防止暴露相关的角膜损伤。

易感因素的管理包括及时治疗潜在疾病，如面神经麻痹、眼睑创伤或眼睑闭合不全。通过希默泪液测试定期监测泪液产生有助于识别加重暴露性角膜炎的并发干眼症。环境修改，包括避免接触刺激物和维持一致的润滑方案，显著减少疾病进展并改善患者舒适度。

### Sources

[1] Oral bacteria may affect conjunctival microorganisms in...: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.11.0260.xml
[2] Canine corneal diseases: Treatment for transparency...: https://www.dvm360.com/view/canine-corneal-diseases-treatment-transparency-greater-federal-stimulus-proceedings
[3] Eyelid disease and surgery (Proceedings): https://www.dvm360.com/view/eyelid-disease-and-surgery-proceedings
[4] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings

## 鉴别诊断

几种眼科疾病与暴露性角膜炎有重叠症状，使准确的鉴别诊断对适当治疗至关重要[1]。主要鉴别诊断包括干性角膜结膜炎（KCS）、慢性浅表性角膜炎（血管翳）、感染性角膜炎和其他免疫介导的角膜疾病。

**干性角膜结膜炎**表现为角膜干燥和表面不规则，但通过异常的希默泪液测试结果（< 15毫米/分钟）区分，而暴露性角膜炎通常维持正常泪液产生[1]。**慢性浅表性角膜炎（血管翳）**表现为起源于颞侧角膜缘的双侧肉质病变，伴有进行性血管化和色素沉着，与暴露性角膜炎更广泛的角膜表面受累形成对比[1]。

**感染性角膜炎**可能引起类似的角膜混浊和不适，但通常表现为脓性分泌物和细菌培养阳性，与暴露性角膜炎中观察到的无菌炎症不同[1]。**猫疱疹病毒角膜炎**通常引起具有树枝状模式的溃疡性病变，而暴露性角膜炎更常为非溃疡性[2]。**嗜酸性角膜炎**表现为白色至粉色斑块，细胞学上以嗜酸性粒细胞为主，与暴露性角膜炎区分[1][2]。

由解剖异常引起的**眼睑闭合不全**可能模拟暴露症状，但通过评估眼睑功能和闭合能力来识别[3]。暴露性角膜炎的区分因素仍然是无法完全闭合眼睑覆盖角膜，导致角膜保护不足[1]。

### Sources

[1] Ophthalmology Challenge: A greyhound with red eyes: https://www.dvm360.com/view/ophthalmology-challenge-greyhound-with-red-eyes
[2] Feline corneal diseases: Herpes and more (Proceedings) - dvm360: https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[3] Eyelids in Animals - Eye Diseases and Disorders - Merck: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals

## 预后

暴露性角膜炎的预后因潜在原因、就诊时严重程度和及时干预而显著不同。当易感因素得到有效管理时，大多数病例对适当治疗反应良好[1]。

**临床结果和恢复率**
结果良好的病例通常涉及可以纠正暴露原因的情况，如眼睑缺陷的手术修复或潜在干眼症的治疗。当倒睫、眼睑外翻或眼睑闭合不全等机械因素早期得到处理时，角膜愈合通常在几天到几周内发生，永久性损伤最小[2]。

**预后因素**
几个因素影响恢复成功。在深层基质受累之前早期干预显著改善结果[2]。纠正影响眼睑功能的潜在解剖异常或神经缺陷的能力对预防复发至关重要[1]。患者因素包括年龄、品种易感和并发全身疾病也影响愈合潜力。

**视力丧失风险和并发症**
未经治疗的暴露性角膜炎可进展为严重并发症，包括深层角膜溃疡、穿孔和继发性细菌感染[2]。在猫中，慢性暴露可导致角膜坏死，需要手术干预[3]。严重病例可能发展溶解性角膜溃疡，如果超过50%的角膜深度受影响，可能导致视力丧失[4]。

通过适当治疗，浅表暴露性角膜炎通常愈合而无显著视力损伤。然而，慢性病例或继发感染复杂病例可能导致角膜瘢痕和不同程度的视力下降[1][2]。

### Sources

[1] Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[2] The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
