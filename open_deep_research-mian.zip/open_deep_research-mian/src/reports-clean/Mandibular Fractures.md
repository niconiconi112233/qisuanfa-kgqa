# 伴侣动物下颌骨骨折

下颌骨骨折是小动物临床中一种关键的骨科急症，占猫所有骨折的11-23%，并对犬和猫均产生重大影响。这些损伤源于创伤事件，包括机动车事故、动物打斗和跌落，以及与老年小型犬严重牙周病相关的病理原因。下颌骨的复杂解剖结构及其在进食和呼吸等重要功能中的作用，使得正确的诊断和治疗对患者预后至关重要。本报告探讨了从初次临床表达到手术干预的综合管理方法，涵盖诊断方案、从非侵入性牙间夹板到先进钢板固定的各种治疗方式，以及影响愈合成功率的预后因素，在得到适当管理的病例中愈合成功率高达93%。

## 疾病概述

下颌骨骨折是小动物兽医临床中口腔和颌面创伤的一个重要亚型[1]。当下颌骨的连续性中断时即发生骨折，下颌骨由支撑下颌牙齿的水平体部和具有三个突起（冠突、髁突和角突）的垂直支构成[2]。两侧下颌骨通过下颌联合处的强韧纤维软骨关节连接[2]。

下颌骨骨折占猫所有骨折的11.4%至23.1%，通常与车祸、打斗和跌落相关[3]。在犬中，机动车事故、打斗和跌落的创伤也是主要原因[4]。下颌通常向骨折侧偏斜，造成可见的不对称[2]。

小型犬由于易患牙周病而面临更高风险，牙周病可通过深牙周袋导致病理性骨折，特别是在下颌第一臼齿和犬齿周围[4][5]。这些病理性骨折最常见于患有严重牙周病的老年小型犬，其中环周牙周缺损削弱了骨结构[4]。年龄相关因素也会影响预后，年轻动物显示快速的骨愈合但可能存在生长干扰，而老年患者则经历更高的并发症发生率，包括延迟愈合和不愈合[4]。

### Sources

[1] Dental and oral examination: A visual atlas of dental and oral pathology (Proceedings): https://www.dvm360.com/view/dental-and-oral-examination-visual-atlas-dental-and-oral-pathology-proceedings
[2] The ABCs of veterinary dentistry: "J" is for jaw fractures: https://www.dvm360.com/view/abcs-veterinary-dentistry-j-jaw-fractures
[3] ajvr.22.03.0043.pdf - AVMA Journals: https://avmajournals.avma.org/downloadpdf/journals/ajvr/83/8/ajvr.22.03.0043.pdf
[4] Managing jaw fractures (Proceedings): https://www.dvm360.com/view/managing-jaw-fractures-proceedings
[5] Pediatric dentistry: An overview of common problems you'll see in practice: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice

## 病因与临床表现

**病理原因**

破坏第一臼齿水平下颌骨的广泛牙周病可导致病理性骨折，有时为双侧，且没有足够的骨结构用于稳定[1]。这是老年动物下颌骨骨折的一个重要原因，特别是在牙周病更为普遍的小型犬中。

**创伤原因**

直接力创伤包括机动车事故、打斗（牙齿碰撞）、农场动物踢伤、跌落和运动事故[2]。这些创伤事件产生巨大力量，可能压倒下颌骨的结构完整性。下颌骨在正常功能期间经历复杂的生物力学应力，其中弯曲力是主要的分离力[2]。

**临床体征和体格检查**

最具特征性的临床体征是下颌向骨折侧偏斜[3]。这种不对称在体格检查期间变得明显，并有助于定位骨折部位。许多下颌骨骨折患者可能不会表现出明显的疼痛临床体征，其食欲最初可能保持不变[2]。

下颌骨骨折导致不对称，下颌向骨折侧移位[4]。每当患者遭受创伤时，临床医生应评估腭部和下颌骨完整性、下颌运动以排除颞下颌关节病变、活动或错位的牙齿，以及包括舌头在内的软组织撕裂[4]。

### Sources
[1] Senior dental care: Never too old for good dental health: https://www.dvm360.com/view/senior-dental-care-never-too-old-good-dental-health
[2] Surgical tooth extractions (Proceedings): https://www.dvm360.com/view/surgical-tooth-extractions-proceedings
[3] The ABCs of veterinary dentistry: "J" is for jaw fractures: https://www.dvm360.com/view/abcs-veterinary-dentistry-j-jaw-fractures
[4] Dental and oral examination: A visual atlas of dental and oral pathology (Proceedings): https://www.dvm360.com/view/dental-and-oral-examination-visual-atlas-dental-and-oral-pathology-proceedings

## 诊断方法

下颌骨骨折的诊断评估需要系统的临床检查结合先进的影像学方法，以准确描述骨折类型并指导治疗计划[1][2]。

临床检查始于对下颌偏斜和咬合不正的目视检查。单侧下颌向患侧偏斜通常表明骨折，这与颞下颌关节脱位相反，后者偏斜发生在远离损伤的一侧[1]。触诊评估稳定性并识别捻发音或异常活动度。

放射摄影术仍然是下颌骨骨折评估的基础。标准颅骨投照包括背腹位、侧位和双侧斜位视图[1]。《默克兽医手册》强调，正确的定位至关重要--对于猫，鼻部抬高15-20度，而犬需要5-10度的背侧抬高以获得最佳的颞下颌关节可视化[1]。

先进的影像学提供卓越的诊断能力。计算机断层扫描（CT）在复杂下颌创伤评估中变得越来越有价值[2]。CT提供卓越的骨细节而无重叠，能够精确描述骨折特征并进行手术计划[2]。该技术提供快速采集，亚毫米层厚，允许多平面重建和三维建模[2]。锥形束CT在评估牙科和下颌病理方面也显示出比常规放射摄影更高的诊断效能[3]。

骨折分类系统有助于确定治疗方法和预后。有利骨折沿腹吻侧走向，肌肉力量可稳定碎片，而不利骨折沿腹尾侧走向，肌肉力量导致移位[1][4]。评估必须考虑牙根受累情况，因为穿过牙根的骨折线通常需要拔牙[1]。

### Sources
[1] Demystifying veterinary oral trauma image interpretation: https://www.dvm360.com/view/demystifying-veterinary-oral-trauma-image-interpretation
[2] Computed Tomography in Animals - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/computed-tomography-in-animals
[3] Evaluation of the diagnostic yield of dental radiography and cone-beam CT: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[4] The ABCs of veterinary dentistry: "J" is for jaw fractures: https://www.dvm360.com/view/abcs-veterinary-dentistry-j-jaw-fractures

## 治疗选择

犬和猫下颌骨骨折的治疗选择包括手术和非手术方法。主要目标是恢复正常咬合、实现稳定固定并使早期功能恢复[1]。

**手术固定技术**
骨内钢丝固定是一种使用张力带原理的多功能技术，粗钢丝（1.0-1.5mm直径）提供最佳刚性同时避免牙根[1]。标准钢板固定提供三维稳定性和卓越的碎片间压缩，特别适用于具有严重粉碎或骨丢失的体中部骨折[1]。微型钢板设计允许更靠近牙槽缘放置，使用角度螺钉避免牙根压迫[1]。

**非侵入性方法**
使用丙烯酸树脂或复合材料的牙间夹板通过利用现有牙齿作为锚点提供有效稳定[3]。该技术包括酸蚀牙齿、应用粘合剂并在下颌舌面放置丙烯酸树脂夹板[3]。外固定器对许多下颌骨骨折效果良好，特别是当与其他技术结合使用时[5]。

**术后护理**
患者需要多模式镇痛、伊丽莎白圈以防止自我创伤，以及在愈合期间严格笼养休息[6]。定期监测包括6周时的放射学评估，以在装置移除前评估骨痂形成[3]。并发症可能包括植入物松动、感染、咬合不正或延迟愈合，需要仔细的术后监测[8]。

### Sources
[1] Managing mandibular fractures in the dog (Proceedings): https://www.dvm360.com/view/managing-mandibular-fractures-dog-proceedings
[2] Evaluation of three fixation techniques: https://avmajournals.avma.org/view/journals/javma/206/12/javma.1995.206.12.1883.xml
[3] Non-invasive oral fracture repair (Proceedings): https://www.dvm360.com/view/non-invasive-oral-fracture-repair-proceedings
[4] The ABCs of veterinary dentistry: https://www.dvm360.com/view/abcs-veterinary-dentistry-j-jaw-fractures
[5] Bilateral mandibular fractures: https://www.dvm360.com/view/bilateral-mandibular-fractures-due-periodontal-disease
[6] Managing jaw fractures (Proceedings): https://www.dvm360.com/view/managing-jaw-fractures-proceedings

## 预防与鉴别诊断

当前内容全面且组织良好。我将整合参考资料以增强预防措施部分，增加创伤管理的详细内容，并加强鉴别诊断部分。

## 预防与鉴别诊断

**预防措施**

下颌骨骨折的预防主要侧重于减少创伤策略。骨骨折通常由车辆事故、枪伤、打斗或跌落引起[1]。一级预防包括环境管理，包括限制户外活动以减少车辆创伤、监督与其他动物的互动以防止打斗，以及将宠物安置在安全环境中以最大限度地减少高处跌落[3]。

二级预防包括保持最佳口腔健康以预防病理性骨折。下颌骨可能因牙齿周围严重牙周炎或肿瘤而发生自发性病理性骨折[3]。定期牙科护理和牙周病治疗，特别是下颌臼齿周围的牙周病，有助于防止骨强度减弱，从而避免在牙科手术过程中发生医源性骨折[4]。在牙科手术期间适当使用区域神经阻滞可预防可能导致骨折的并发症[5]。

**鉴别诊断**

几种疾病表现出重叠的临床体征，必须与下颌骨骨折相区分。颞下颌关节（TMJ）脱位引起类似的急性咬合不正和进食困难，但导致下颌向损伤对侧偏斜，而骨折则导致同侧偏斜[4]。

咀嚼肌肌炎表现出类似的张口困难（牙关紧闭）和疼痛体征。这种免疫介导的疾病影响咀嚼肌，可引起双侧肌肉肿胀和疼痛，使鉴别至关重要，因为治疗方法差异很大[6]。

牙科创伤包括牙齿脱位、撕脱或骨折，可能模拟下颌损伤症状。仔细的放射学评估有助于区分下颌骨骨折和孤立的牙科损伤[3]。

严重的牙周病可能表现出类似的疼痛和进食困难临床体征，需要放射学评估以排除潜在的病理性骨折[4]。

### Sources

[1] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[2] Managing mandibular fractures in the dog (Proceedings): https://www.dvm360.com/view/managing-mandibular-fractures-dog-proceedings
[3] Dentofacial Trauma in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/dentofacial-trauma-in-small-animals
[4] Demystifying veterinary oral trauma image interpretation: https://www.dvm360.com/view/demystifying-veterinary-oral-trauma-image-interpretation
[5] Pain management for dental patients (Proceedings): https://www.dvm360.com/view/pain-management-dental-patients-proceedings
[6] Masticatory Myositis in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/myopathies-in-small-animals/masticatory-myositis-in-dogs-and-cats

## 预后与结果

犬和猫下颌骨骨折的预后因骨折位置、复杂性、患者因素和所选治疗方法而显著不同。大多数病例实现完全骨折愈合，在使用外固定器治疗的猫患者中成功率可达93%[1]。

大多数下颌骨骨折通常在6-8周内愈合。猫外固定器研究表明，中位愈合时间为8周（范围因复杂性而异），大多数病例可实现完全固定器移除[1]。愈合时间取决于包括患者年龄、骨折位置和粉碎程度在内的因素。

几个预后因素显著影响恢复结果。患者年龄影响愈合，年轻动物通常由于代谢活动增加而显示更快的骨愈合。骨折稳定性和位置起着关键作用--简单骨折比严重粉碎性损伤愈合更可预测。并发牙周病的存在对预后产生负面影响，特别是通过病变骨发生的病理性骨折[2]。

治疗方法的选择直接与结果相关。使用牙间钢丝和丙烯酸树脂夹板的非侵入性技术为适当病例提供优异结果，同时最大限度地减少并发症[2]。在修复过程中恢复适当的牙科咬合对于功能成功和患者舒适至关重要。

长期管理考虑包括定期放射学监测以确认完全愈合、愈合期间的软食建议，以及对骨折线中涉及的牙齿可能需要的牙科护理[2]。

### Sources

[1] Forty-three of the 46 (93%) cats had complete fracture healing: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml

[2] Managing mandibular fractures in the dog (Proceedings): https://www.dvm360.com/view/managing-mandibular-fractures-dog-proceedings
