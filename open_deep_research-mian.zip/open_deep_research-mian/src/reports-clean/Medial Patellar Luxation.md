# 犬猫内侧髌骨脱位

内侧髌骨脱位（MPL）是影响伴侣动物，特别是小型和玩具品种犬的最常见骨科疾病之一。本综合报告探讨了MPL的多方面性质，从涉及复杂骨骼畸形的潜在病理生理学到所需的精细手术矫正技术。该疾病的影响不仅限于简单的跛行，继发并发症包括软骨侵蚀和十字韧带疾病显著影响长期预后。通过对诊断方法、治疗策略和预防措施的详细分析，本报告为兽医从业者管理这一具有挑战性的疾病提供了重要见解。主要主题包括用于严重程度评估的标准化分级系统、品种特异性易感性、滑车成形术和胫骨粗隆移位等先进手术程序，以及负责任繁育实践在预防中的关键作用。

## 总结与临床意义

内侧髌骨脱位是一种复杂的骨科疾病，需要全面了解其病理生理学、诊断挑战和治疗选择。该疾病从I级间歇性脱位发展到IV级永久性移位的过程表明了早期干预的重要性，特别是在年幼生长中的犬中，骨骼畸形可能随时间恶化。

本分析的关键临床见解表明，MPL涉及多种解剖异常，不仅仅是简单的髌骨移位，还包括需要精细手术矫正的股骨和胫骨畸形。并发十字韧带疾病的高发病率（15-20%的病例）和进行性软骨侵蚀强调了全面评估和及时治疗的必要性。

| 治疗方法 | 适应症 | 预期结果 |
|-------------------|-------------|------------------|
| 保守治疗 | I级，轻度病例 | 长期成功率有限 |
| 手术矫正 | II-IV级 | 技术得当预后良好 |
| 复杂重建 | 伴有畸形的IV级 | 预后谨慎，需要专业知识 |

强调负责任的繁育实践和基因筛查是降低易感品种MPL患病率的最有效长期策略。兽医从业者应通过常规骨科筛查优先进行早期检测，并考虑将需要专业手术专业知识的复杂病例转诊。

## 病理生理学与临床表现

内侧髌骨脱位（MPL）是由影响后肢整个伸肌机制的发育异常引起的[1]。其病理机制涉及骨骼畸形的复杂相互作用，包括减少的髋臼股骨角（髋内翻）、股骨外侧弓形弯曲、胫骨内旋、滑车沟变浅和股骨内侧髁发育不全[1]。最常见的是，髌骨脱位是由于先天性构象异常导致膝关节伸肌机制排列不正，而非创伤[4]。

该疾病根据严重程度遵循标准化分级系统[1][6]。I级表现为轻微、不频繁的临床症状，髌骨可手动脱位但松开压力后立即复位[6]。II级在屈曲时引起间歇性脱位，伸展时复位，造成特征性的"跳跃"跛行，主人常报告当犬"将腿向后伸展"时跛行消失[4][6]。III级涉及更频繁的脱位并伴有持续性跛行，明显的骨骼畸形，且髌骨大部分时间位于沟外[6]。IV级表现为严重跛行、肢体变形和持续脱位，无法手动复位[6]。

品种特异性模式已得到充分证实，小型和迷你品种主要受内侧脱位影响，而大型犬通常发展为外侧脱位[1]。患有持续性内侧脱位的犬，特别是年幼生长中的犬，可能表现出特征性的"弓形腿"外观（膝内翻）[6]。

继发并发症显著影响预后。每次脱位发作都会对髌骨和滑车造成潜在的软骨损伤[6]。MPL导致进行性软骨侵蚀和退行性关节变化[3]。并发前十字韧带断裂发生在15-20%的髌骨脱位犬中[6]，这些动物通常由于十字韧带撕裂表现出比单纯髌骨脱位更严重的跛行。

### Sources
[1] Patellar Luxation in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/patellar-luxation-in-dogs-and-cats
[3] Medial patellar luxation induces cartilage erosion in dogs: https://avmajournals.avma.org/view/journals/ajvr/85/11/ajvr.24.07.0190.xml
[4] Patella luxation: Diagnosis and surgical decision making (Proceedings): https://www.dvm360.com/view/patella-luxation-diagnosis-and-surgical-decision-making-proceedings
[6] Patella luxations (Proceedings): https://www.dvm360.com/view/patella-luxations-proceedings

## 诊断方法与鉴别诊断

内侧髌骨脱位的诊断主要依靠系统的骨科检查技术[1]。八步方法包括病史评估、病史采集、步态评估、站立检查、卧姿检查以及必要时进行镇静检查[1]。患有膝关节病理的犬常将受影响的肢体外展坐着以避免不适，使坐姿测试对诊断有价值[7]。

体格检查应通过手动操作评估髌骨稳定性，根据移位和复位的难易程度检查I-IV级脱位[3,4]。同时触诊两个膝关节有助于识别肌肉萎缩、关节积液和关节周围纤维化[1]。对膝关节完全伸展的疼痛反应和内侧支撑物的存在是重要的诊断指标[7]。

放射学检查包括标准侧位和头尾位视图，以评估肢体构象并排除并发疾病[3,4]。在慢性病例中可能看到关节积液和骨赘性变化[3]。D45°投影等特殊视图可以更好地显示滑车嵴病理，类似于用于OCD病变的技术[2]。

后肢跛行的主要鉴别诊断包括前十字韧带断裂、髋关节发育不良、幼年小型品种犬的Legg-Perthes病和化脓性关节炎[5,7]。应识别并发疾病如十字韧带疾病，因为幼年小型品种犬可能同时出现髌骨脱位和Legg-Perthes病[4]。

### Sources

[1] Orthopedic exam and bandaging (Proceedings): https://www.dvm360.com/view/orthopedic-exam-and-bandaging-proceedings
[2] Juvenile bone and joint diseases: large dogs, rear legs: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-rear-legs-and-small-dogs-proceedings
[3] Patellar Luxation in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/patellar-luxation-in-dogs-and-cats
[4] Patella luxation: Diagnosis and surgical decision making (Proceedings): https://www.dvm360.com/view/patella-luxation-diagnosis-and-surgical-decision-making-proceedings
[5] Laboratory Tests Routinely Performed in Veterinary Medicine: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/laboratory-tests-routinely-performed-in-veterinary-medicine
[6] Diagnosing and treating strains and sprains (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-strains-and-sprains-proceedings
[7] Diagnosing cranial cruciate ligament pathology: https://www.dvm360.com/view/diagnosing-cranial-cruciate-ligament-pathology

## 治疗策略与手术技术

内侧髌骨脱位治疗分为保守管理和手术干预。保守治疗通常保留用于I级脱位，包括抗炎药物、体重控制和受控运动的物理康复[1]。

手术矫正根据脱位等级和解剖畸形采用多种技术。核心手术包括加深股骨沟的块状滑车成形术、侧向重新排列伸肌机制的胫骨粗隆移位术、减少张力的内侧松解术和关节囊外侧缝合术[1][2]。 

滑车成形术技术通过楔形或块状切除方法保留透明软骨，而不是破坏性磨损程序，后者会破坏软骨并用质量较差的纤维软骨替代[3][5]。磨损性滑车成形术往往在大型犬中引起更多的术后发病率[3]。

胫骨粗隆移位术通过将胫骨粗隆向外侧移动来重新排列股四头肌机制，对于内侧脱位，使用克氏针或张力带固定[2][3]。胫骨粗隆远端保留骨膜附着以最小化撕脱风险[3]。

手术决策取决于脱位等级、患者年龄和临床严重程度。II-IV级通常需要手术干预，IV级病例常需要矫正截骨术来治疗严重的骨骼畸形[2][3][5]。6个月以下的犬可能经历等级进展，不应延迟手术[3]。

术后护理需要严格笼养3-4周，然后额外限制活动一个月以防止并发症[6]。物理康复和逐渐恢复活动对最佳结果至关重要[2][5]。

### Sources
[1] Comprehensive Patellar Luxation Correction Course: https://www.dvm360.com/view/comprehensive-patellar-luxation-correction-course-0
[2] Patella luxation (Proceedings): https://www.dvm360.com/view/patella-luxation-proceedings
[3] Patella luxation (Proceedings): https://www.dvm360.com/view/patella-luxation-proceedings
[4] Not one good leg to stand on ... literally: https://www.dvm360.com/view/not-one-good-leg-stand-literally
[5] Juvenile bone and joint diseases: large dogs, rear legs: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-rear-legs-and-small-dogs-proceedings
[6] Hind limb sprains and strains (Proceedings): https://www.dvm360.com/view/hind-limb-sprains-and-strains-proceedings

## 预防、预后与长期管理

**预防措施**
内侧髌骨脱位预防侧重于负责任的繁育实践，因为该疾病具有强烈的遗传成分。常规体格检查应包括髌骨评估，因为筛查对易感品种特别重要[1]。早期识别允许进行主动管理，包括体重控制和运动调整以减少关节压力。活动管理应强调在平坦表面上进行受控运动，同时避免可能加剧脱位的高冲击活动。

**繁育考虑**
繁育健康检查应评估髌骨脱位作为全面骨科筛查的一部分[2]。患有MPL的犬应仔细评估其繁育适宜性，因为该疾病具有遗传影响。基因筛查计划有助于识别有风险的繁育谱系，类似于用于其他骨科疾病如十字韧带断裂的方法[3]。负责任的繁育实践有助于降低易感品种中MPL的总体患病率。

**预后与长期结果**
预后根据脱位等级和治疗方法差异很大。保守管理可能适用于较低等级，而手术干预通常推荐用于较高等级。需要多种手术的复杂病例可能预后谨慎，特别是当出现并发症或多个肢体受影响时[4]。长期管理通常需要持续监测，并可能包括物理康复以维持肌肉力量和关节功能。

### Sources
[1] Epidemiology of Patellar Luxation in Dogs in England: https://www.dvm360.com/authors/laurie-anne-walden-dvm-els?page=4
[2] The Breeding Soundness Examination in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/the-breeding-soundness-examination-in-dogs-and-cats
[3] Breakthrough genetic test detects risk of canine cruciate ligament rupture: https://www.dvm360.com/view/breakthrough-genetic-test-detects-risk-of-canine-cruciate-ligament-rupture
[4] Not one good leg to stand on ... literally: https://www.dvm360.com/view/not-one-good-leg-stand-literally
