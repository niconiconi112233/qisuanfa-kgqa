# 猫三体炎：一种复杂的炎症综合征

三体炎代表了猫医学中最具挑战性的诊断和治疗疾病之一，其特征是三个相互关联器官同时发生炎症：肝脏（胆管炎/胆管性肝炎）、胰腺（胰腺炎）和小肠（炎症性肠病）。这种复杂的综合征影响中老年至老年猫，其发生原因在于这些器官在猫体内的独特解剖关系，共享的导管系统促进了炎症过程的扩散。由于临床症状不特异，该疾病呈现出重大的诊断挑战，需要全面评估，包括专门的实验室检测、先进的影像学检查，以及通常需要的组织病理学确认。兽医从业者了解这种疾病的相互关联性至关重要，因为成功的管理需要同时解决所有三个组成部分，而不是孤立地治疗每个器官系统。

## 疾病概述与流行病学

**定义**
三体炎是猫的一种临床综合征，特征是三个解剖学相关器官同时发生炎症：肝脏（胆管炎/胆管性肝炎）、胰腺（胰腺炎）和小肠（炎症性肠病）[1]。这种情况代表了在猫体内通过胆管和胰腺导管系统具有共同解剖连接的器官中同时发生炎症过程[2]。

**流行病学背景**
三体炎的患病率在兽医文献中差异显著，研究报告称，在患有慢性胆道疾病的猫中，39-83%存在多器官同时炎症[3,4]。在患有炎症性肠病的猫中，约50%同时患有胰腺炎，这支持了这些炎症过程的相互关联性[4]。三体炎的解剖学基础在于猫的导管结构，80%的猫有一条胰腺导管，该导管与胆管连续进入，形成一个共同的通道，促进器官系统之间的反流[5]。

**年龄和品种易感性**
主要影响中老年至老年猫，根据炎症成分的不同，报告的中位年龄范围为3.3至7岁[1,2]。家养短毛猫似乎比例过高，但这可能反映了它们在总体种群中的较高患病率[6]。尚未确定明确的性别易感性，尽管一些研究表明在某些炎症性肝胆疾病形式中存在轻微的雄性倾向[1]。

### Sources
[1] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease
[2] Hepatic lipidosis: Winning strategies (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-winning-strategies-proceedings
[3] Diagnosing and managing feline pancreatitis (Sponsored by IDEXX Laboratories): https://www.dvm360.com/view/diagnosing-and-managing-feline-pancreatitis-sponsored-idexx-laboratories
[4] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[5] Disorders of the Stomach and Intestines in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-stomach-and-intestines-in-cats
[6] Update on managing inflammatory bowel disease and intestinal lymphoma in cats (Proceedings): https://www.dvm360.com/view/update-managing-inflammatory-bowel-disease-and-intestinal-lymphoma-cats-proceedings

## 病因学与临床表现

**三体炎**代表了影响猫的一种复杂疾病综合征，特征是肝脏（胆管性肝炎）、胰腺（胰腺炎）和肠道（炎症性肠病）同时发生炎症[1]。这种三联征的发生是由于这些器官在猫体内的解剖位置接近和共享引流系统。

### 常见病原体

**细菌病原体**常与中性粒细胞性胆管性肝炎有关，其中大肠杆菌是最常见的分离株[4]。其他重要的细菌原因包括梭菌属、拟杆菌属、放线菌属和α-溶血性链球菌种[4]。这些细菌通常通过胆管从肠道上行或通过血行传播。

**引起猫腹泻的传染性病原体**包括弯曲杆菌属、梭菌属、沙门氏菌属、贾第鞭毛虫属、隐孢子虫属、冠状病毒、猫泛白细胞减少症病毒、弓形虫和三毛滴虫属[5]。**非传染性原因**包括淋巴细胞性胆管性肝炎中的免疫介导过程和导致肝脂质沉积症的代谢紊乱[1][4]。病理生理学涉及脂质代谢紊乱，特别是肝细胞中甘油三酯积累超过肝脏含量的80%[3]。

### 临床症状

**典型表现**包括体重减轻、厌食、呕吐、嗜睡和黄疸[3][4]。猫可能出现显著的体重减轻（>25%体重）、脱水和肝肿大[1]。**物种特异性模式**显示中年雌性猫患肝脂质沉积症的风险更高，而中性粒细胞性胆管性肝炎常见于较年轻的猫[2][3]。肥胖猫在厌食期后易患继发性肝脂质沉积症[2]。

### Sources

[1] Disorders of the Liver and Gallbladder in Cats - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats

[2] Hepatic lipidosis: Winning strategies (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-winning-strategies-proceedings

[3] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies

[4] Feline hepatobiliary disease: What's new in diagnosis and therapy? (Proceedings): https://www.dvm360.com/view/feline-hepatobiliary-disease-whats-new-diagnosis-and-therapy-proceedings

[5] Feline diarrhea: Let the diagnostic clues flow: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow

## 诊断方法与鉴别诊断

三联病诊断需要系统的临床表现评估结合特定的实验室和影像学方法。临床症状通常包括嗜睡、食欲下降、体重减轻和呕吐，尽管猫可能仅出现与十二指肠病变相关的慢性发作性呕吐[1]。体格检查结果通常不特异，在猫患者中检测腹部疼痛可能具有挑战性[2]。

实验室评估应包括全血细胞计数、血清生化学和尿液分析，尽管结果通常不特异。关键诊断检测包括猫胰腺脂肪酶免疫反应性（fPLI），对中重度胰腺炎具有100%的敏感性和92%的总特异性[2]。钴胺素水平经常降低，表明肠道吸收不良，而肝脏酶可能升高，提示并发胆管炎[3]。胰蛋白酶样免疫反应性（TLI）检测有助于排除外分泌胰腺功能不全[4]。

由经验丰富的医师进行的腹部超声检查对中重度胰腺疾病具有80%的敏感性，并可显示肠壁增厚、胆管异常和胰周液体积聚[2]。影像学检查还允许评估并发器官受累情况，这对三联病诊断至关重要。

无论何种形式，都需要活检和组织病理学来明确诊断胆管炎，肝组织和/或胆汁培养有助于抗生素选择[6]。关键的鉴别诊断包括炎症性肠病与小细胞淋巴瘤，它们在形态上可能无法区分。可能需要进行组织病理学结合免疫组织化学和PARR检测，因为高达80%的疑似IBD病例实际上可能是淋巴瘤[4]。其他鉴别诊断包括饮食超敏反应、传染性肠炎、外分泌胰腺功能不全以及原发性肝或胆道疾病[5,8]。明确诊断通常需要多器官系统的组织病理学评估，以确认三联病特有的并发炎症过程。

### Sources
[1] Management of inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/management-inflammatory-bowel-disease-proceedings
[2] Diagnosing and managing feline pancreatitis (Sponsored by IDEXX Laboratories): https://www.dvm360.com/view/diagnosing-and-managing-feline-pacreatitis-sponsored-idexx-laboratories
[3] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-1
[4] Feline diarrhea: Let the diagnostic clues flow: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow
[5] Feline Cholangitis / Cholangiohepatitis Syndrome - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[6] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings

## 治疗方案

三联病的治疗需要全面管理，既要解决潜在的病理生理学问题，也要处理相关并发症。治疗主要是症状性和支持性的，广谱抗菌药物对继发性细菌感染有用(2)。对于慢性疾病，由于细菌性鼻炎会导致软骨炎和骨髓炎，抗生素治疗应根据影像学严重程度和治疗反应持续4-8周(1)。

多西环素仍是一线治疗方法（每12小时口服5 mg/kg，或每24小时口服10 mg/kg），因为其对主要呼吸道病原体具有广谱活性(5)。对于慢性病例，克林霉素、阿莫西林-克拉维酸或甲硝唑是首选，因为它们能有效穿透骨骼和软骨(1)。当其他抗生素不可用时，阿奇霉素（每24-72小时10 mg/kg）可用于治疗慢性疾病(5)。

抗炎治疗起着至关重要的作用。吡罗昔康（每48-72小时0.5-1 mg/猫）可以控制患有鼻部疾病的猫的炎症和临床症状(1)。对于具有嗜酸性粒细胞成分的慢性病例，可能需要糖皮质激素，尽管建议间歇性而非连续使用(6)。

免疫抑制治疗可能适用于免疫介导成分。环孢素（最初每12小时5 mg/kg，减少至每日）可全身使用，而硫唑嘌呤（每日1.5-2 mg/kg）是另一种选择(3)。

### Sources

[1] DVM 360 Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings

[2] Merck Veterinary Manual Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

[3] Merck Veterinary Manual Immunosuppressive Drugs in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/immunosuppressive-drugs-in-animals

[4] DVM 360 What are the best practices for antibiotic use in feline upper respiratory tract disease?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease

[5] Snots and snuffles: chronic feline upper respiratory ... - dvm360 Successful correction of stenotic nares using combined Alar ... Outcome of permanent tracheostomy Outcome of permanent ... Chronic upper respiratory disease in cats (Proceedings) - dvm360 Feline Respiratory Disease Complex (Feline Viral ...: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings

## 预防与预后

猫胆管炎/胆管性肝炎综合征的预防措施侧重于处理并发疾病和实施支持性营养策略。治疗建议包括类固醇、抗氧化剂和饮食管理[1]。使用低过敏性饮食治疗相关的炎症性肠病可能提供额外益处[2]。营养支持应确保充分摄入以预防继发性肝脂质沉积症，输液疗法应补充B族维生素[4]。许多患有胰腺炎和肝胆疾病的猫最终可以过渡回商业维持饮食，前提是没有显著的合并症[10]。

预期的临床结果因疾病形式和严重程度而异。对于猫胆管炎，急性和慢性形式的猫报告的平均生存时间为29个月[7]。该疾病通常表现为自发周期和临床急性发作，需要长期医疗管理[2]。大约50%患有非化脓性胆管炎的猫可能实现长期生存，尽管大约30%接受糖皮质激素治疗的破坏性胆管炎猫会发展为糖尿病 mellitus[2]。

影响恢复的预后因素包括早期诊断、及时治疗实施和并发疾病管理。积极的营养支持对于良好结果至关重要[5]。多器官受累（三体炎）的存在如果不治疗通常会导致生存时间缩短，尽管通过适当的治疗干预，猫可以在初次诊断后存活数年[2]。

### Sources
[1] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings
[2] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[4] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies
[5] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-1
[7] Feline liver disease (Proceedings) - dvm360: https://www.dvm360.com/view/feline-liver-disease-proceedings
[10] Nutritional management of pancreatitis and concurrent disease: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.11.0641.xml
