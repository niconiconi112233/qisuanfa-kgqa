# 伴侣动物鞭虫病：综合兽医指南

鞭虫病主要由犬鞭虫（*Trichuris vulpis*）引起，是兽医实践中的一种重要寄生虫病，具有显著的诊断和管理挑战。虽然全国范围内有14.3%的收容所犬受到影响，但由于卵子的间歇性排出和诊断技术不足，这种情况常常未被诊断。本报告全面检查了伴侣动物鞭虫感染的各个方面，从流行病学模式和临床表现到循证治疗方案和预防策略。重点关注领域包括使用离心浮聚法和抗原检测的先进诊断方法、芬苯达唑和月度预防药物的综合治疗方案，以及在兽医实践中对长期控制至关重要的关键环境管理实践。

## 摘要

对鞭虫病的全面检查揭示了一种需要多方面管理方法的复杂寄生虫病。犬鞭虫在犬群中显示出显著流行率（收容所犬为14.3%），临床表现从无症状的轻度感染到重度感染时的严重血性腹泻和贫血不等。70-90天的潜伏前期和环境中卵子长达5年的持久性带来了重大的诊断和管理挑战。

关键临床见解表明，使用硫酸锌的离心浮聚法明显优于简单浮聚法，而商业抗原检测可在潜伏前期检测到感染。治疗成功取决于芬苯达唑（50 mg/kg，连续3天）结合月度米尔贝霉素或莫昔克丁预防药物，由于持续的环境暴露需要重复治疗。

| 管理组成部分 | 关键成功因素 |
|---------------------|-------------------------|
| 诊断 | 离心浮聚法 + 7-10天内多次采样 |
| 治疗 | 芬苯达唑3天疗程 + 月度预防药物 |
| 预防 | 环境消毒 + 混凝土饲养表面 |
| 预后 | 经治疗预后良好；如持续环境暴露则预后谨慎 |

有效的鞭虫病控制需要整合先进诊断、循证治疗和综合环境管理。兽医应优先考虑早期月度预防方案和强调长期环境策略的客户教育，以获得最佳的患者结果。

## 疾病概述

鞭虫病是由伴侣动物鞭虫感染引起的寄生虫病。在犬中，主要病原体是犬鞭虫（*Trichuris vulpis*），而猫很少受到鞭虫影响[1]。这些线虫寄生虫具有独特的形态，其细长的鞭状前端嵌入盲肠粘膜，较粗的后端游离于肠腔中[2]。

犬鞭虫在犬群中显示出显著流行率，全国调查表明，在14.3%的收容所犬和14.54%的常见蛔虫（*Toxocara canis*）中观察到犬鞭虫[3]。按年龄分层的数据显示，鞭虫流行率因发育阶段而异：6月龄以下犬为7.84%，6-12月龄犬为16.83%，1-3岁犬为15.38%[4]。2024年的最新监测发现，在美国超过1370万只接受检测的犬中，有0.4%鞭虫检测呈阳性[5]。

该寄生虫表现出直接生活周期，卵子需要在环境中大约两周时间进行胚胎发育。这些已胚胎化的卵子显示出显著的环境持久性，在半保护性栖息地中可存活数年[2]。存在地区差异，美国东南部特别是肯塔基州和西弗吉尼亚州的流行率较高[5]。从流行病学角度看，鞭虫病主要影响饲养在有土壤基质的犬舍中的户外犬，这些基质为长寿命卵子提供了保护[2]。

### Sources

[1] Parasitic diseases you should know about (Proceedings): https://www.dvm360.com/view/parasitic-diseases-you-should-know-about-proceedings

[2] Total parasite control: Piecing the puzzle together (Proceedings): https://www.dvm360.com/view/total-parasite-control-piecing-puzzle-together-proceedings

[3] Just how common are canine and feline intestinal parasites?: https://www.dvm360.com/view/just-how-common-are-canine-and-feline-intestinal-parasites

[4] Toxocara canis and Trichuris vulpis - Common dog parasites (Proceedings): https://www.dvm360.com/view/toxocara-canis-and-trichuris-vulpis-common-dog-parasites-proceedings

[5] What to know about canine whipworm infection: https://www.dvm360.com/view/what-to-know-about-canine-whipworm-infection

## 临床表现和病理生理学

犬鞭虫病的临床表现因虫体负荷和宿主因素而异。轻度感染通常无症状[1]。然而，随着虫体负荷增加以及盲肠和结肠的炎症反应变得明显，会出现临床症状，包括体重减轻、腹泻以及排便紧迫感和频率增加[1,2]。

重度感染产生更严重的表现。粪便中可能出现鲜血，并且可能因胃肠道失血而发生贫血[1,2]。犬可能经历里急后重、粪便中有粘液和血便[2]。病理生理机制涉及成年鞭虫用其前端牢固地附着在结肠壁上，嵌入粘膜中，导致脱水、血性腹泻和体重减轻[2,3]。

成年犬鞭虫（*Trichuris vulpis*）生活时，其前端穿过粘膜内的细胞合胞体，而后端游离于肠腔中[4]。这种附着模式导致组织损伤和炎症。潜伏前期持续70-90天，在此期间幼虫在盲肠和结肠中发育成熟前发育[1,4]。

临床疾病严重程度与虫体负荷、失血程度、免疫状态、营养状况以及并发感染的存在相关[2]。重度感染可导致体液流失和胃肠道损伤[3]。

### Sources
[1] Whipworms in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/whipworms-in-small-animals
[2] What's new with boxer colitis and other large bowel disorders: https://www.dvm360.com/view/whats-new-with-boxer-colitis-and-other-large-bowel-disorders-proceedings
[3] What to know about canine whipworm infection: https://www.dvm360.com/view/what-to-know-about-canine-whipworm-infection
[4] Toxocara canis and Trichuris vulpis - Common dog parasites: https://www.dvm360.com/view/toxocara-canis-and-trichuris-vulpis-common-dog-parasites-proceedings

## 诊断方法

鞭虫病诊断依赖于多种互补的诊断方法，因为卵子的间歇性排出模式和个体检测的相对低敏感性。最基本的方法包括全面的粪便检查技术，其中离心浮聚法优于简单浮聚法[1]。

**粪便浮聚技术**

使用硫酸锌（比重1.18）的离心浮聚法代表检测犬鞭虫卵的金标准[1]。这种方法明显优于简单浮聚技术，研究表明使用直接涂片法对犬鞭虫的假阴性率为100%，静置粪便技术的假阴性率为20%，而离心法在所有病例中都实现了阳性检测[4]。特征性的厚壳、对称卵，两端有极塞，大小为72-90 × 32-40微米[6]。

**抗原检测**

商业粪便抗原检测已成为有价值的诊断工具，即使在潜伏前期或卵子排出最小时也能检测犬鞭虫抗原[6]。这些检测显示出比单次粪便浮聚检查更高的敏感性，并在较长时间内保持阳性，这使它们适用于初步诊断，但不适合治疗后监测[1]。

**诊断挑战**

卵子排出的间歇性性质需要在连续几天或7-10天期间检查多个样本以排除寄生虫感染[1]。单次阴性粪便检查不足以排除鞭虫病。此外，鞭虫感染经常被常规粪便浮聚法漏检，导致对出现大肠腹泻的犬推荐经验性芬苯达唑治疗[3]。

### Sources
[1] Parasitology in Veterinary Practice - Clinical Pathology and ...: https://www.merckvetmanual.com/clinical-pathology-and-procedures/parasitology/parasitology-in-veterinary-practice
[2] Diagnostic approach to chronic diarrhea in dogs and cats ...: https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[3] Parasitic and infectious causes of vomiting and diarrhea in ...: https://www.dvm360.com/view/parasitic-and-infectious-causes-vomiting-and-diarrhea-dogs-and-cats
[4] Accurate evaluation of fecal samples critical to patient: https://www.dvm360.com/view/accurate-evaluation-fecal-samples-critical-patient
[5] Intestinal parasites: screening & prevention best practices: https://www.dvm360.com/view/intestinal-parasites-screening-prevention-best-practices
[6] Whipworms in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/whipworms-in-small-animals

## 治疗选择

驱虫治疗代表鞭虫病管理的基石。**芬苯达唑**仍然是金标准治疗，以50 mg/kg剂量连续三天给药[1]。这种苯并咪唑化合物对成年鞭虫显示出可靠的疗效，在寄生虫逃避粪便检测时特别有价值[1]。默克兽医手册确认芬苯达唑对犬鞭虫、犬弓蛔虫、狮弓蛔虫和钩虫种类具有活性[5]。

**米尔贝肟**以0.5 mg/kg剂量提供月度预防，提供心丝虫预防和鞭虫控制的双重益处[1][5]。几种含米尔贝霉素的复方产品显示出对犬鞭虫的活性，包括与鲁芬奴隆、吡喹酮和多杀菌素的配方[5]。这些月度大环内酯类预防药物提供针对再感染的持续保护。

**基于莫昔克丁的产品**提供额外的治疗选择。局部莫昔克丁/咪康唑配方以2.5 mg/kg月度剂量给药显示出疗效[5]。注射用莫昔克丁微球配方提供延长保护，但具体的鞭虫疗效数据因配方而异。

**治疗方案**需要重复，因为鞭虫的潜伏前期长达74-90天且环境中卵子持久存在[8]。大多数权威机构建议每月间隔治疗三次，以应对持续的环境暴露[1]。支持性护理针对胃肠道并发症、脱水和与重度感染相关的常见营养缺陷。

### Sources
[1] Whipworms in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/whipworms-in-small-animals
[5] Drugs for Intestinal Helminths of Dogs Approved in the US and UK: https://www.merckvetmanual.com/multimedia/table/drugs-for-intestinal-helminths-of-dogs-approved-in-the-us-and-uk
[8] Challenges in parasite management: https://www.dvm360.com/view/challenges-parasite-management

## 预防措施

有效的鞭虫预防需要综合的环境管理和预防性药物治疗方案。卵子对干燥敏感，因此清洁和消除潮湿区域对感染控制至关重要[1]。及时清除和妥善处理粪便至关重要，因为鞭虫卵在适宜环境中可保持活力长达5年[1]。

全年含有米尔贝霉素、莫昔克丁或其他批准化合物的心丝虫广谱预防药物为犬鞭虫感染提供出色的持续控制[1]。月度给药有助于即使在重复环境暴露的情况下也维持亚临床寄生虫负荷[2]。早期干预至关重要 - 所有宠物应在6-8周龄时开始接受月度预防药物[2]。

环境修改显著降低再感染风险。犬舍中的犬应饲养在混凝土地面上，而不是泥土或砾石基质上[4][5]。阳光充足的粘土或沙土区域可以用硼酸钠消毒[4]。在重度感染的环境中，可能需要完全更换土壤或用混凝土覆盖污染区域[1]。

客户教育强调，对于持续环境暴露的犬，鞭虫可能需要终身管理[3]。通过年度检查进行定期粪便监测有助于检测突破性感染并指导治疗调整。

### Sources

[1] Whipworms in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/whipworms-in-small-animals
[2] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[3] Challenges in parasite management: https://www.dvm360.com/view/challenges-parasite-management
[4] Gastrointestinal Parasites of Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs
[5] Gastrointestinal Parasites of Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs

## 鉴别诊断和预后

**鉴别诊断**

鞭虫病必须与其他表现出相似临床症状的胃肠道疾病相鉴别。关键的鉴别诊断包括其他肠道寄生虫，如钩虫（犬钩口线虫）、蛔虫（犬弓蛔虫）和贾第虫属，它们通常引起血性腹泻和体重减轻[1]。钩虫感染可引起与鞭虫病相似的出血性肠炎，但通常表现为贫血和黑色柏油样粪便，而不是新鲜血液[1]。

炎症性肠病，特别是浆细胞性淋巴细胞性结肠炎，表现出与鞭虫病相似的慢性大肠腹泻[2]。产气荚膜梭菌肠毒素血症和纤维反应性腹泻也引起伴有粘液血便的慢性结肠炎症[2]。鉴别因素包括粪便检查中的鞭虫卵和内窥镜评估中成年蠕虫的特征性盲肠位置[1]。

**预后**

鞭虫病的预后在适当治疗下通常良好[1]。轻度感染通常无症状，健康成年犬能够很好地耐受[1][3]。然而，如果不治疗，重度感染可导致危及生命的并发症，包括严重脱水、血性腹泻和贫血[1][3]。

幼犬和免疫功能低下动物的预后更为谨慎，因为它们对严重疾病表现更易感[3]。环境因素显著影响预后，因为鞭虫卵在土壤中可保持活力数年，在没有适当环境管理的情况下导致高再感染率[1][4]。月度广谱预防药物提供出色保护，并显著改善高危患者的长期结果。

### Sources

[1] Gastrointestinal Parasites of Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs
[2] Diagnostic approach to chronic diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[3] Toxocara canis and Trichuris vulpis - Common dog parasites (Proceedings): https://www.dvm360.com/view/toxocara-canis-and-trichuris-vulpis-common-dog-parasites-proceedings
[4] Combatting unseen parasites: A closer look at tapeworms and whipworms: https://www.dvm360.com/view/combatting-unseen-parasites-a-closer-look-at-tapeworms-and-whipworms
