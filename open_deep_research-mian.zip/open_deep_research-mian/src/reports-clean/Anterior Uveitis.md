# 犬猫前葡萄膜炎：兽医综合指南

前葡萄膜炎是小动物眼科中最具挑战性且可能威胁视力的疾病之一。这种虹膜和睫状体的炎症性疾病同时影响犬和猫，常作为潜在全身性疾病的窗口。该疾病的复杂性在于其多样的病因--从猫传染性腹膜炎和犬瘟热等传染性病原到免疫介导过程和肿瘤。本报告为兽医从业者提供识别临床表现、实施系统诊断方案和提供有效治疗策略的基本知识。重点关注领域包括物种特异性病原体谱、包括前房穿刺术在内的先进诊断技术、多模式治疗方法以及预防继发性青光眼和永久性视力丧失等破坏性并发症的长期管理方案。

## 疾病概述与临床表现

前葡萄膜炎，又称虹膜睫状体炎，定义为虹膜和睫状体--葡萄膜前部成分的炎症[1]。前葡萄膜由虹膜、睫状体和前房角组成[2]。葡萄膜高度血管化和色素化，作为眼球的中层，对全身性炎症过程特别敏感[4]。从解剖学上讲，当虹膜和睫状体发炎时，这构成前葡萄膜炎，区别于影响脉络膜的后葡萄膜炎（脉络膜炎）[1]。

前葡萄膜炎在犬和猫中均常见诊断，可能与其他角膜或结膜炎症性疾病混淆[2]。流行病学在物种间存在差异。在猫中，葡萄膜炎是一种常见且疼痛的眼部疾病，最终可导致失明，尽管它通常继发于获得性眼部或全身性疾病[8]。在犬中，一项回顾性研究显示，47%的前葡萄膜炎病例无法确定诊断，18%诊断为传染病，25%诊断为肿瘤，10%诊断为葡萄膜皮肤综合征或疫苗反应[4]。

猫的临床表现可能差异很大，且可能不如其他物种明显[1][8]。急性前葡萄膜炎表现为瞳孔缩小、前房内蛋白质和细胞增加（前房闪辉）、眼内压降低、球结膜充血、巩膜外层血管注射、虹膜肿胀、畏光和眼睑痉挛[6]。其他临床表现包括角膜水肿、角膜后沉着物、前房积脓、前房积血、虹膜肿胀以及慢性病例中的虹膜色素沉着增加[7]。疼痛通常与急性葡萄膜炎相关，临床上表现为眼睑痉挛、畏光、眼球内陷、第三眼睑抬高或流泪[1][8]。

### Sources

[1] Anterior Uveitis in Small Animals - Emergency Medicine: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/anterior-uveitis-in-small-animals

[2] The Anterior Uvea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-anterior-uvea-in-animals

[3] Current approaches to uveitis in the dog and cat: https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings

[4] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment

## 常见病原体与病因学

前葡萄膜炎由多种传染性和非传染性原因引起，可大致分为几类[1]。一项回顾性研究显示，传染性疾病约占前葡萄膜炎病例的18%，而免疫介导/特发性原因占57.8%，肿瘤占24.5%[1]。

**犬的传染性原因**
病毒病原体包括犬瘟热病毒、犬腺病毒-1（CAV-1）和疱疹病毒[1][3][4]。CAV-1感染可导致免疫复合物介导的葡萄膜炎和角膜混浊，约25%康复犬在急性临床症状消失后7-10天出现角膜混浊[4]。细菌病原体包括犬布鲁氏菌、伯氏疏螺旋体和钩端螺旋体属[1][3]。真菌感染如皮炎芽生菌、新型隐球菌、荚膜组织胞浆菌和粗球孢子菌是重要原因[1][3]。立克次体生物包括犬埃立克体和立氏立克次体常引起葡萄膜炎[1][6]。原生动物病原体如刚地弓形虫和利什曼虫属也被涉及[1][3][6]。

**猫的传染性原因**
四种病毒性疾病特别与猫葡萄膜炎相关：猫白血病病毒（FeLV）、猫免疫缺陷病毒（FIV）、猫传染性腹膜炎（FIP）和猫疱疹病毒-1[1][2][3]。FIP引起的前葡萄膜炎可能是单侧或双侧，表现包括前房闪辉、前房积血、前房积脓、纤维蛋白渗出物、瞳孔缩小和角膜后沉着物[1]。其他病原体包括汉氏巴尔通体、刚地弓形虫和各种真菌生物[2][4][6]。

**非传染性原因**
这些包括免疫介导性疾病如葡萄膜皮肤综合征、晶状体诱导性葡萄膜炎、外伤、肿瘤（特别是淋巴肉瘤）、代谢性疾病和特发性原因[1][3][4]。

### Sources
[1] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[2] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[3] Evaluation of four drugs for inhibition of paracentesis-induced anterior uveitis in cats: https://avmajournals.avma.org/view/journals/ajvr/72/6/ajvr.72.6.826.xml
[4] Infectious Canine Hepatitis: https://www.merckvetmanual.com/infectious-diseases/infectious-canine-hepatitis/infectious-canine-hepatitis

## 诊断方法与流程

前葡萄膜炎的综合诊断需要系统的检查方案和策略性检测。首先进行全面的眼科检查，使用荧光素染色排除角膜溃疡，并在表面麻醉后使用压平眼压计测量眼内压[1]。应始终进行荧光素染色以评估是否并发角膜溃疡[2]。

前段评估使用手持式裂隙灯检查或直接检眼镜评估前房闪辉、细胞积聚和虹膜变化。逆照技术有助于识别房水、晶状体或玻璃体中的混浊[1]。使用20-28屈光度镜片的间接检眼镜提供更佳的眼底筛查以评估后段受累情况[1]。

对于双侧葡萄膜炎的猫，进行全血细胞计数、血清生化分析和尿液分析以确定全身性原因。根据地区流行病学和临床表现，可能需要进行额外的传染性疾病血清学检测[1][6]。在犬中，诊断检测应包括评估常见全身性疾病，包括高血压、代谢性疾病和传染性病原体[3][6]。PCR检测现已可用于许多与葡萄膜炎相关的病因学因子[6。

在全身麻醉下进行前房穿刺等专门操作可提供PCR检测、细胞学检查和细菌培养的样本[1][2]。然而，这些操作存在眼内出血风险，应保留用于其他诊断方法无结果的病例[1]。

### Sources
[1] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[2] Anterior Uveitis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/anterior-uveitis-in-small-animals
[3] Ocular manifestations of systemic disease--when the eye is not the primary disease: https://www.dvm360.com/view/ocular-manifestations-systemic-disease-when-eye-not-primary-disease-proceedings
[6] Current approaches to uveitis in the dog and cat (Proceedings): https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings

## 治疗策略与管理

前葡萄膜炎的治疗需要针对炎症控制、疼痛管理和并发症预防的综合多模式治疗。主要治疗目标包括稳定血-房水屏障、减少炎症介质、防止后粘连形成和管理继发性青光眼[1]。

**局部抗炎治疗**
皮质类固醇仍是前葡萄膜炎治疗的基石。1%醋酸泼尼松龙每4-6小时应用一次提供良好的角膜穿透性和强效抗炎作用[1][3]。0.1%地塞米松具有相当的疗效和良好的组织穿透性[3]。对于皮质类固醇禁忌或不足的病例，局部NSAIDs如0.03%氟比洛芬或0.1%双氯芬酸提供替代抗炎选择[1][3]。

**散瞳治疗**
睫状肌麻痹性散瞳药防止后粘连并减少睫状痉挛相关疼痛。在猫中首选1%阿托品，因为与溶液相比唾液分泌减少，而当存在继发性青光眼风险时，托吡卡胺提供较短的作用持续时间[3]。在散瞳药使用期间必须仔细监测眼内压[1]。

**全身治疗**
后葡萄膜炎或严重前部炎症需要全身抗炎治疗。口服泼尼松0.25-0.5 mg/kg每日一次有效控制炎症[1][4]。某些病例可能需要免疫抑制剂如硫唑嘌呤治疗免疫介导性疾病[1]。特定的抗微生物治疗针对已识别的传染性病原体，多西环素5 mg/kg提供广谱覆盖[1]。

**手术干预**
复杂病例可能需要手术治疗，包括虹膜切开术缓解虹膜膨隆、结膜瓣修复角膜缺损，或对疼痛失明眼球进行眼球摘除术[4]。

### Sources
[1] Current approaches to uveitis in the dog and cat: https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings
[2] Corneal disease in dogs: https://www.dvm360.com/view/corneal-disease-dogs-there-hole-my-cornea-proceedings  
[3] Nonspecific therapy for uveitis: https://www.dvm360.com/view/nonspecific-therapy-uveitis
[4] A challenging case: Uveitis and secondary glaucoma in a cat: https://www.dvm360.com/view/challenging-case-uveitis-and-secondary-glaucoma-cat

## 预防、预后与长期管理

**预防措施**

前葡萄膜炎的特定预防策略有限，因为大多数病例继发于潜在全身性疾病或外伤[1]。一级预防侧重于通过常规疫苗接种方案控制诱发疾病，包括猫传染性腹膜炎、猫白血病病毒和猫免疫缺陷病毒[1][7]。媒介控制至关重要，特别是跳蚤预防以降低汉氏巴尔通体感染风险[7]。环境管理包括通过适当监督防止外伤并避免已知毒素[1]。定期筛查猫的病毒性疾病（FeLV、FIV、FIP）可能有助于早期识别高风险患者[1][7]。

**鉴别诊断**

关键鉴别包括青光眼（眼内压升高vs葡萄膜炎眼内压降低）、结膜炎（仅外部炎症）、角膜炎（角膜受累）和原发性晶状体疾病[1]。必须通过仔细检查和诊断测试将肿瘤性疾病，特别是猫的淋巴肉瘤和虹膜黑色素瘤，与炎症性葡萄膜炎区分开来[1][7]。在幼年动物中，需要考虑先天异常和品种特异性疾病。

**预后与长期管理**

预后根据潜在病因学和早期干预差异显著[1]。继发性青光眼是最严重的并发症，当房水排出受损时发生[1][7]。慢性病例需要终身抗炎治疗，一些患者每周一到两次低剂量类固醇维持数年[1]。定期眼内压监测至关重要。免疫介导病例通常需要免疫抑制剂如硫唑嘌呤进行长期控制[1]。早期积极治疗显著改善结果，而延迟干预可能导致不可逆并发症，包括白内障、视网膜脱离和永久性视力丧失[1][7]。

### Sources
[1] Current approaches to uveitis in the dog and cat (Proceedings): https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings
[7] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
