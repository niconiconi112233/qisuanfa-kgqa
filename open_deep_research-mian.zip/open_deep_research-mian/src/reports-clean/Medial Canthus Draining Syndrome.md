# 伴侣动物内侧眦引流综合征

虽然"内侧眦引流综合征"未被正式认定为一种独立的兽医疾病实体，但内侧眦引流在犬猫中代表了一个重要的临床表现，值得进行系统评估。这种情况主要通过泪囊炎、鼻泪管阻塞和相关泪膜疾病表现出来，导致特征性的泪溢和面部染色。本报告探讨了涉及葡萄球菌属和假单胞菌属等细菌病原体的潜在病理生理学，回顾了包括荧光素测试和鼻泪管冲洗在内的诊断方法，并详细介绍了从药物治疗到内侧眦成形术等手术干预的治疗方案。理解这些相互关联的状况对于在伴侣动物临床实践中有效管理内侧眦引流至关重要。

## 预后

内侧眦引流的预后因潜在病因和解剖因素而有显著差异。涉及单纯鼻泪管阻塞的病例通常对冲洗和药物治疗反应良好，在早期恢复通畅的情况下，成功率超过80%。然而，伴有不可逆瘢痕形成的慢性泪囊炎可能需要结膜鼻腔造口术等重建手术，这些手术具有中等成功率，但能改善生活质量结果。

短头颅品种面临更为谨慎的预后，因为其固有的结构异常易导致复发。内侧眦成形术在合适的候选病例中显示出优异的效果，能同时有效解决综合征的多个组成部分。早期干预显著提高长期成功率，而延迟治疗往往导致进行性角膜黑变症和永久性鼻泪管损伤。

关键预后因素包括：
- 鼻泪管阻塞的可逆性
- 继发性角膜病变的程度
- 品种特异性的解剖限制
- 主人对术后护理的依从性

及时的诊断和适当的手术干预提供最佳结果，当潜在解剖异常得到充分处理时，大多数动物在舒适度和外观方面都能获得显著改善。

## 疾病概述

对现有兽医文献的最新更新证实，"内侧眦引流综合征"在伴侣动物中并非一个已确立的兽医疾病实体。对可信兽医来源的全面检索显示，没有专门用此术语定义的公认综合征[1][2]。

然而，几种影响内侧眦区域的合法疾病可在犬猫中产生引流症状。泪囊炎的特征是泪囊炎症，通常表现为内侧眦引流，并可在内侧下眼睑内或下方形成引流瘘管[2]。这种情况通常由炎症碎片、异物或占位性病变引起的鼻泪管阻塞所致。

鼻泪器疾病是影响内侧眦引流的最具临床相关性的疾病。这些包括幼犬的泪点闭锁、马和骆驼类动物的鼻孔闭锁以及各种阻塞性病理[2]。此外，表皮样囊肿等眶周肿块已在犬的内侧眦区域有文献记载[1]。

由于缺乏"内侧眦引流综合征"的特定流行病学数据，临床医生应专注于对公认的鼻泪管疾病进行鉴别诊断。相关疾病显示物种和品种差异--短头颅品种易患泪膜异常，某些品种鼻泪管畸形发生率较高。年龄相关因素包括成熟动物泪囊炎发生率较高和幼年动物先天性鼻泪管缺陷[2]。

### Sources

[1] Periorbital epidermoid cyst in the medial canthus of three dogs: https://avmajournals.avma.org/view/journals/javma/198/2/javma.1991.198.02.271.xml
[2] Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals

## 常见病原体

根据当前兽医文献，内侧眦引流综合征主要与细菌继发感染相关，而非特定的病毒病因学。从内侧眦引流中最常分离出的细菌病原体包括葡萄球菌属和铜绿假单胞菌，这些被认为是伴侣动物皮肤和软组织感染的主要病原体[1]。

继发性细菌感染通常在鼻泪管阻塞或泪囊炎后发生。在猫中，猫疱疹病毒-1型(FHV-1)可能导致慢性泪管瘢痕形成和随后的细菌定植，特别是在伴有干性角膜结膜炎的病例中[1]。其他细菌原因包括猫衣原体和支原体属，它们可影响结膜上皮，并可能导致内侧眦炎症[1]。

在犬中，泪囊炎通常由炎症碎片阻塞引起，这为细菌增殖创造了有利环境[2]。虽然病毒感染与内侧眦引流的直接关联较少，但在伴有鼻分泌物的慢性病例中，特别是猫，应考虑隐球菌属等真菌病原体[3]。

发病机制通常涉及原发性阻塞或解剖异常，这些异常损害了正常的泪液引流，随后发生继发性细菌入侵和鼻泪系统内生物膜形成。

### Sources
[1] Upper respiratory tract disease in cats (Proceedings): https://www.dvm360.com/view/upper-respiratory-tract-disease-cats-proceedings
[2] Disorders of the Nasal Cavity and Tear Ducts in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs
[3] Clinical approach to nasal discharge (Proceedings): https://www.dvm360.com/view/clinical-approach-nasal-discharge-proceedings

## 临床症状和体征

**泪溢和泪液溢出**是内侧眦引流综合征最具特征性的表现。患病动物表现为泪液过度溢出到面部，形成从内侧眦延伸到面部毛发的可见湿润痕迹[1]。当正常鼻泪管引流受损时，泪液被迫沿皮肤表面寻找替代路径，就会发生这种溢出。

**棕色泪液染色**通常作为继发性体征发展，在浅色犬猫中尤为明显。持续的湿润为细菌和酵母菌增殖创造了理想环境，导致面部毛发特征性的红棕色变色[2]。主人经常报告受影响区域散发相关的霉味或酵母样气味。

**品种特异性模式**很明显，短头颅犬由于解剖易感性而显示更高的易感性。哈巴狗、西施犬和波士顿梗等品种由于眼窝浅、眼睛突出和眼睑解剖异常干扰正常泪膜分布而表现出更高的患病率[1]。类似地，某些猫品种可能经历内侧眼睑内翻，导致倒睫和泪液积聚。

**相关眼部分泌物**模式根据潜在原因而异。在急性泪囊炎病例中，内侧下眼睑可能肿胀和疼痛，可能从泪点挤出炎性渗出物[2]。继发性结膜炎经常发展，特征是充血和黏液性分泌物，在不解决潜在引流阻塞的情况下，对标准抗菌治疗变得难治。

### Sources
[1] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[2] Nasolacrimal and Lacrimal Apparatus in Animals - Eye: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals

## 诊断方法

内侧眦疾病的诊断评估需要结合临床检查、专业测试和成像方式的系统方法[1]。Schirmer泪液测试(STT)是基础，测量水样泪液产生，犬正常值超过15mm/分钟，猫正常值超过10mm/分钟[1,3]。

荧光素染色对于通过Jones测试评估泪膜稳定性和鼻泪管通畅性至关重要，染料通常在5-15分钟内出现在鼻孔[1,6]。玫瑰红染色识别死亡或变性的上皮细胞，在干性角膜结膜炎诊断中特别有价值[6]。

通过上泪点插管进行鼻泪管冲洗确定系统通畅性并有助于治疗计划[1]。冲洗显示阻塞，黏液脓性分泌物回流表明泪囊炎[1]。

高级成像包括对比泪囊鼻腔造影术，以确定慢性病例的阻塞位置和预后[1]。当不透明性妨碍可视化时，使用10-20 mHz探头的超声检查允许检查[7]。

细胞学检查和细菌培养及敏感性测试适用于对治疗无反应的慢性或严重病例[7,8]。应在局部用药前收集样本，以避免抑菌剂污染[7]。

使用眼压计测量眼内压是必要的，因为某些内侧眦疾病可能与继发性青光眼相关[6,7]。当使用丙美卡因等局部麻醉剂时，TonoPen提供准确读数[7]。

### Sources
[1] Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] Disorders of the Nasal Cavity and Tear Ducts in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs
[3] Diagnostic Tests Pertaining to Ocular Medications in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/diagnostic-tests-pertaining-to-ocular-medications-in-animals
[4] Ocular diagnostic testing: what, when, how?: https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings
[5] Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[6] Ophthalmic Examination Made Ridiculously Simple: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=11196&catId=30760&id=3854142

## 治疗选项

内侧眦引流综合征的治疗需要多模式方法，既针对原发性眼睑异常，也针对继发性并发症。主要手术干预是**内侧眦成形术**，它同时解决综合征的多个组成部分[1]。该手术减小睑裂大小，切除内侧泪阜，并矫正下内侧眼睑内翻，有效减少角膜暴露和倒睫引起的摩擦刺激[1]。

**药物治疗干预**侧重于管理继发性疾病。泪囊炎需要通过鼻泪管冲洗进行积极治疗以重建通畅性，结合局部抗菌溶液和可能的全身性抗菌药物及抗炎剂[2]。当冲洗未能恢复功能时，可在导管中暂时插入聚乙烯或硅胶管以在愈合期间保持通畅[2]。

**护理方案**包括术后部位每日伤口管理和受影响区域的定期清洁。环境调整应尽量减少可能加重症状的灰尘和刺激物。必须教育主人正确的眼部卫生和监测技术。

**管理潜在疾病**对长期成功至关重要。角膜黑变症进展需要立即手术干预[1]。当鼻泪器遭受不可逆损伤时，结膜鼻腔造口术或结膜口腔造口术等重建手术创造替代引流路径[2]。

### Sources
[1] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery
[2] Nasolacrimal and Lacrimal Apparatus in Animals - Eye: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals

## 预防措施和鉴别诊断

**预防措施**

内侧眦引流问题的预防集中在选择性繁殖实践和环境管理上。繁殖建议包括避免交配具有结构异常的动物，如浅眼窝、眼睛突出或易患泪膜疾病的眼睑畸形[2][3]。短头颅品种由于其固有的解剖易感性需要特别关注[2]。

环境控制侧重于维持最佳泪膜稳定性。保持内侧眦周围面部毛发修剪短可防止泪液芯吸，同时避免暴露在风和通风口下可减少泪膜蒸发[1]。使用温热敷和稀释的无泪洗发水进行定期眼睑卫生有助于预防可能加重引流问题的继发性睑缘炎[1]。

**鉴别诊断**

内侧眦引流的主要鉴别诊断包括眼睑内翻，它导致眼睑边缘向内卷曲引起角膜刺激，可通过直接观察眼睑位置来区分[2]。鼻泪管阻塞表现为泪溢，但通过Jones测试可区分，正常动物中荧光素染料应在15-30秒内出现在鼻孔[1]。泪阜倒睫涉及从内侧眦生长的毛发接触角膜表面，而眼睑切迹则造成异常泪液流动模式[1]。原发性干性角膜结膜炎表现为Schirmer泪液测试值降低，与引流阻塞中见到的泪液溢出形成对比[1][4]。

### Sources
[1] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[2] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery
[3] Eyelids in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals
[4] Nasolacrimal and Lacrimal Apparatus in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
