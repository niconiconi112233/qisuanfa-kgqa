# 猫传染性腹膜炎：综合兽医指南

猫传染性腹膜炎（FIP）是小动物兽医实践中最具挑战性且历史上最具破坏性的疾病之一。这种由猫冠状病毒突变引起的致命性疾病，因其复杂的发病机制、难以诊断以及曾经不良的预后，长期以来一直困扰着兽医。然而，近期的治疗突破已经改变了治疗格局，为受影响的猫及其主人带来了新的希望。

本报告探讨了FIP的流行病学模式和风险因素，阐述了涉及免疫介导机制的复杂病毒发病机制，详细介绍了当前诊断方法及其局限性，并回顾了革命性的抗病毒治疗，这些治疗已将治疗病例的生存率从接近零显著提高到75-100%。

## 摘要

通过开创性的抗病毒疗法，猫传染性腹膜炎已从普遍致命的疾病转变为可治疗的疾病。该疾病影响5-12%的冠状病毒感染猫，其中多猫环境中的年轻纯种公猫面临最高风险。FIP的复杂发病机制涉及冠状病毒突变，使其获得巨噬细胞嗜性，并随后引发免疫介导的血管炎。

诊断仍然具有挑战性，需要结合临床表现、渗出液分析和分子检测的多模式方法。Rivalta测试是一个极好的筛查工具，而RT-qPCR和免疫组织化学在适当应用时可提供确定性确认。

| 治疗时代 | 生存率 | 关键干预措施 |
|---------------|---------------|------------------|
| 2019年前 | <5% | 仅支持性护理 |
| 2024年至今 | 75-100% | GS-441524/瑞德西韦 |

通过Stokes Pharmacy合法获得GS-441524代表了FIP管理的范式转变。通过适当的抗病毒治疗，存活最初48小时的猫显示出96%的生存率。兽医现在应将FIP视为一种需要及时诊断和立即抗病毒干预的可治疗疾病，而不是死刑。

## 疾病概述与流行病学

猫传染性腹膜炎（FIP）是一种严重的、通常致命的疾病，由猫冠状病毒（FCoV）引起[1]。FCoV在世界范围内普遍存在，单猫家庭血清阳性率达15%，而猫舍和收容所等高密度环境中达50-90%[2]。然而，只有5-12%的FCoV感染猫会发展为FIP[2][3]。

该疾病是由于通常良性的猫肠道冠状病毒（FECV）在个体猫体内突变为强毒力的FIP病毒（FIPV）所致[3][4]。这种突变在每个受影响的猫体内独立发生，使得FIPV的水平传播不常见[4]。

关键风险因素包括年轻（6个月至2岁）、纯种状态（特别是波斯猫、阿比西尼亚猫、孟加拉猫、缅甸猫、喜马拉雅猫和布偶猫品种）、雄性、多猫饲养环境、近期应激事件以及并发逆转录病毒感染[1][2][5]。英国短毛猫显示出特别高的风险，比值比为2.81[6]。共同饲养六只或更多猫会显著增加FIP风险，因为病毒传播压力和应激因素增加[7]。

潜伏期在初次FCoV感染后从几天到几个月或几年不等[2]。在全球兽医机构检查的所有猫中，FIP导致的死亡率为0.3-1.4%[2]。

### Sources

[1] Feline Infectious Peritonitis (FIP) - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-infectious-peritonitis-fip
[2] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[3] An update on feline infectious peritonitis: https://www.dvm360.com/view/update-feline-infectious-peritonitis
[4] FIP: More complex than we thought! (Proceedings): https://www.dvm360.com/view/fip-more-complex-we-thought-proceedings
[5] Feline infectious peritonitis: what's new? (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-whats-new-proceedings
[6] Insights on feline infectious peritonitis risk factors and sampling strategies from polymerase chain reaction analysis of feline coronavirus in large-scale nationwide submissions: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.03.0208.xml
[7] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.04.0201.xml

## 病因学与发病机制

猫传染性腹膜炎由猫冠状病毒（FCoV）引起，这是一种被归类为α冠状病毒属的大型包膜RNA病毒[1]。FCoV存在两种血清型：I型（最普遍）和II型（与犬冠状病毒的重组体）。由于RNA聚合酶错误率和持续复制，该病毒表现出高度遗传变异性，导致受感染的猫脱落称为准种的异质病毒群体[1]。

发病机制涉及通过内部突变假说从肠道FCoV（FECoV）到强毒力FIPV的关键突变[1]。这种生物型转换使病毒获得巨噬细胞嗜性，刺突蛋白融合肽中的两个核苷酸变化（M1058L和S1060A）可能促进全身播散[1]。然而，决定毒力的确切突变仍然未知，可能涉及包括3c在内的多个病毒基因[1]。

当FIPV感染的单核细胞全身播散时，疾病表现为免疫介导的血管炎[1][2]。抗体依赖性增强促进巨噬细胞对病毒的摄取，而补体固定和免疫复合物形成导致血管损伤和富含蛋白质的渗出液[1]。在感染细胞聚集的地方发生血管周围化脓性肉芽肿性炎症，产生广泛的肉芽肿性病变[1][3]。T淋巴细胞耗竭，特别是CD8+细胞毒性T细胞，损害细胞介导的免疫并促进病毒复制[2]。

### Sources
[1] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[2] Update on feline infectious peritonitis (Proceedings): https://www.dvm360.com/view/update-feline-infectious-peritonitis-proceedings-0
[3] Update on feline infectious peritonitis (Proceedings): https://www.dvm360.com/view/update-feline-infectious-peritonitis-proceedings-1

## 诊断方法

FIP诊断需要结合临床表现、实验室检测和影像学研究的多模式方法[6]。没有单一的诊断测试能提供确定性确认，这使得FIP成为生前最具挑战性的猫科疾病之一[2]。

**实验室检测方法**
常规血液检查显示特征性模式，包括淋巴细胞减少症、中性粒细胞增多症、高球蛋白血症和低白蛋白血症[6]。白蛋白：球蛋白比值低于0.8强烈提示FIP，比值低于0.4则高度支持[4][6]。急性期蛋白如α-1-酸性糖蛋白（>1.5 mg/mL）在血浆和渗出液中均升高[6]。

**渗出液分析和Rivalta测试**
当存在时，渗出液分析提供最高的诊断价值[2]。FIP渗出液特征为黄色、粘稠、富含蛋白质（>35 g/L）且细胞数量低（<5×10⁹细胞/L）[6]。Rivalta测试是一个极好的筛查工具--阳性结果（液滴在稀醋酸中保持形状）提高FIP怀疑，而阴性结果有效排除FIP[6]。

**先进分子技术**  
RT-qPCR在各种样本中检测FCoV RNA，其中渗出液测试比血液样本显示出更高的可靠性[2][3]。免疫组织化学代表诊断金标准，使用特异性抗体证明巨噬细胞内的病毒抗原[1]。当在适当的组织样本上进行时，该技术达到97-100%的敏感性和高达100%的特异性[1][6]。

**诊断挑战**
基于血液的PCR测试显示出较差的特异性，在一些研究中超过一半的健康猫测试呈阳性[2]。样本选择严重影响准确性，腹膜液、肾脏和淋巴结样本比血液样本产生更高的检出率[3]。

### Sources
[1] Pathology in Practice in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.04.0201.xml
[2] Feline infectious peritonitis: Strategies for diagnosing and: https://www.dvm360.com/view/feline-infectious-peritonitis-strategies-diagnosing-and-treating-deadly-disease-young-cats
[3] Insights on feline infectious peritonitis risk factors and: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.03.0208.xml
[4] Fever of unknown origin in cats (Proceedings): https://www.dvm360.com/view/fever-unknown-origin-cats-proceedings
[5] Viral diagnostics: What do the results mean? (Proceedings): https://www.dvm360.com/view/viral-diagnostics-what-do-results-mean-proceedings
[6] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis

## 治疗选择与管理

随着美国有效抗病毒疗法的可用性，猫传染性腹膜炎的治疗格局发生了革命性变化。GS-441524以前只能通过黑市来源获得，现在通过Stokes Pharmacy与Bova集团的独家合作伙伴关系于2024年6月合法获得[1][3]。这种口服制剂可作为主要治疗使用，在具有正常吞咽反射的猫中无需初始注射治疗[1]。

推荐的GS-441524剂量因FIP类型和猫体重而异，最低治疗疗程为84天[1]。药物应在空腹时服用，服药前1-2小时禁食[1]。在前六周内每周监测临床反应和体重至关重要，随着猫体重增加，剂量需定期重新计算[1]。

瑞德西韦仍然可用于兽医用途，但面临重大的可及性挑战，每100mg小瓶成本约775美元[3]。这种注射用抗病毒药物在给药后24小时内显示出快速的临床改善[3]。研究表明，存活治疗最初48小时的猫有96%的生存率和六个月时86%的生存率[1]。

Austin Pets Alive!已成功治疗超过250只猫，在六个月治疗期间达到75%的生存率，FeLV合并感染对治疗结果无影响[3]。临床研究表明，当前抗病毒疗法的生存率在50-100%之间[3]。

### Sources
[1] DVM 360 Step up your practice: Start treating FIP today: https://www.dvm360.com/view/step-up-your-practice-start-treating-fip-today
[2] DVM 360 A kitten's fight against FIP: https://www.dvm360.com/view/a-kitten-s-fight-against-fip
[3] DVM 360 Updates in treating FIP: https://www.dvm360.com/view/updates-in-treating-fip

## 预防、鉴别诊断和预后

### 预防
根据AAFP指南，目前可用的FIP疫苗"通常不推荐"，因为其疗效可疑且保护有限[1]。预防主要依靠环境管理，包括适当的饲养实践以最小化应激、足够的猫砂盆并彻底每日清洁以减少病毒传播，以及仅将FCoV血清阴性猫引入猫舍[1]。

在多猫环境中，6周龄早期断奶、严格隔离协议和育种系的遗传淘汰有助于降低传播风险[1]。使用稀释漂白剂、加热或紫外线照射的环境消毒可有效灭活病毒[1]。

### 鉴别诊断
FIP多变的临床表现需要与多种疾病进行鉴别。关键鉴别包括脓毒性腹膜炎或胸膜炎、逆转录病毒疾病（FIV/FeLV）、淋巴瘤、脓胸、充血性心力衰竭和弓形虫病[1]。其他鉴别包括渗出型的新生物、胆管炎和肠破裂相关腹膜炎[2]。

富含蛋白质的渗出物可能出现在其他疾病中，使诊断具有挑战性[2]。Rivalta测试有助于排除FIP--如果渗出液在稀醋酸中消散，则不太可能是FIP[1]。

### 预后
历史上被认为普遍致命，FIP的预后随着抗病毒疗法已显著改善。不经治疗，中位生存时间为9天，渗出型病例存活几天到几周[1]。使用GS-441524或瑞德西韦治疗，生存率达到75-100%，存活最初两天的猫有80%的长期生存机会[3]。治疗通常持续84天，尽管复发仍有可能[3]。

### Sources
[1] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[2] Diagnosis of FIP: Facing the challenge: https://www.dvm360.com/view/diagnosis-fip-facing-challenge
[3] A kitten's fight against FIP: https://www.dvm360.com/view/a-kitten-s-fight-against-fip
