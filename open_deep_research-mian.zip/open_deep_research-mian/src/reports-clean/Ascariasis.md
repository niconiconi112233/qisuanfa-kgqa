# 伴侣动物蛔虫病

蛔虫病是全球影响犬和猫的最重要寄生虫感染之一，主要由三种蛔虫引起：犬弓首蛔虫（犬）、猫弓首蛔虫（猫）和狮弓蛔虫（两种宿主均可感染）。这份综合性兽医报告探讨了伴侣动物临床实践中蛔虫病的临床管理，涉及复杂的生命周期模式、年龄相关的疾病严重程度以及人畜共患意义，这些因素使该疾病对兽医从业者构成特殊挑战。

本报告综合了当前诊断方案，包括先进的粪便漂浮技术和抗原检测，基于证据的批准驱虫药治疗方案，以及将驱虫计划与心丝虫预防项目相结合的综合预防策略。特别强调幼犬/幼猫感染与成年动物表现之间的关键差异、鉴别诊断考虑因素，以及伴侣动物适当寄生虫控制的公共卫生意义。

## 预后

犬和猫蛔虫病的预后通常极好，只要及时诊断并适当治疗，大多数病例使用现代驱虫方案可实现完全清除寄生虫。3个月以下的幼龄动物面临严重并发症的最高风险，包括蠕虫性肺炎、营养不良和大量虫体负荷引起的肠梗阻，但通过及时干预和支持性治疗反应良好。

| 年龄组 | 预后 | 关键因素 |
|-----------|-----------|-------------|
| 幼犬/幼猫（<3个月） | 治疗后良好 | 肺炎、营养不良风险；需要强化方案 |
| 成年动物 | 极好 | 常为亚临床；单次治疗疗程反应迅速 |
| 繁殖动物 | 良好 | 因再感染风险需要持续预防 |

使用适当驱虫药并遵循正确给药间隔时，治疗成功率超过95%。然而，没有适当的环境管理和预防方案，再感染仍然常见。整合了控制蛔虫的月度心丝虫预防药物已显著改善长期结局并降低人畜共患传播风险。

兽医从业者应强调全年预防计划和常规粪便监测，以维持无寄生虫状态，并通过全面的寄生虫控制策略保护动物和人类健康。

## 常见病原体

犬和猫的蛔虫病由三种主要蛔虫引起，它们具有不同的宿主特异性和地理分布[1]。**犬弓首蛔虫**仅感染犬，全球分布，由于其人畜共患潜力和在幼犬中的常见性，被认为是临床意义最大的物种[1]。**猫弓首蛔虫**是猫特异性物种，也分布全球，由于其流行性和人畜共患风险，被认为是猫最重要的蛔虫[1]。

**狮弓蛔虫**与弓首蛔虫不同，因为它可以感染犬和猫，尽管在犬中通常比犬弓首蛔虫少见[1]。与弓首蛔虫不同，狮弓蛔虫不是人畜共患病，其迁移模式仅限于肠壁而非全身组织迁移[1]。所有物种的成虫都是粗壮的乳白色线虫，寄生于小肠，通常长3-15厘米[1]。

第四个物种，**马来西亚弓首蛔虫**，已在东亚部分地区（包括中国、马来西亚和越南）的猫中被发现[1]。然而，其完整生命周期和人畜共患潜力仍不清楚，需要进一步研究[1]。所有物种都表现出形态学相似性，犬弓首蛔虫、狮弓蛔虫和马来西亚弓首蛔虫具有渐细的末端，而猫弓首蛔虫以其特征性的箭形前端而区别[1]。

### Sources

[1] Roundworms in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals

## 临床症状和体征

犬和猫蛔虫病的临床表现因年龄而异，幼龄动物比成年动物表现出更严重的体征[1]。幼犬和幼猫感染的最初迹象通常是生长停滞和身体状况下降[1,2]。受感染动物通常毛发暗淡，由于腹部膨胀而经常呈现"大腹便便"的外观[1,2]。

胃肠道体征常见，包括带粘液的腹泻、呕吐，以及粪便或呕吐物中排出完整虫体[1,2]。在早期幼虫迁移阶段，受感染动物可能因幼虫穿过肺部而发展为伴有咳嗽的肺炎[1,2]。

年龄相关差异在蛔虫病中很明显。疾病在3个月以下的幼犬和幼猫中最严重[2,3]。新生儿的严重感染可引起蠕虫性肺炎、腹水、脂肪肝和粘液性肠炎[2]。成年动物通常无症状或表现出较轻微的体征[3,4]。

特征性的"大腹便便"外观结合生长不良、毛发暗淡以及粪便或呕吐物中可见虫体，构成了典型表现[1,2]。然而，许多感染，特别是在成年动物中，可能是亚临床的，没有明显的外部体征[2,4]。

### Sources
[1] Gastrointestinal Parasites of Dogs: https://www.merckvetmanual.com/en-au/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs
[2] Roundworms in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals
[3] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[4] Zoonotic diseases (Proceedings): https://www.dvm360.com/view/zoonotic-diseases-proceedings

## 诊断方法

伴侣动物蛔虫病的诊断主要依靠全面的粪便检查技术，几种诊断方法提供不同水平的敏感性和特异性。最基本和广泛使用的方法是用于检测虫卵的**粪便漂浮**，可采用简单或离心技术进行[1][2]。

**离心粪便漂浮**代表蛔虫病诊断的金标准，在检测寄生虫卵方面显著优于简单漂浮方法[3]。该技术通过在650g下离心10分钟浓缩虫卵，然后加入漂浮介质形成正弯月面并进行盖玻片检查[6]。有各种漂浮溶液可用，包括硫酸锌（比重1.18）、氯化钠和Sheather's糖溶液，维持适当的比重对获得最佳结果至关重要[4][5]。

**时间考虑**对准确诊断至关重要。新鲜粪便样本应在排出后2小时内收集或立即冷藏，因为超过6小时的样本由于虫卵发育和孵化而不再适用[6]。可能需要多次粪便检查，因为虫卵排出可能是间歇性的，建议连续三天收集三个样本以排除感染[6]。

**抗原检测**已成为有价值的补充诊断工具。商业粪便抗原检测可检测弓首蛔虫抗原，比单次粪便漂浮检查更敏感，约相当于进行三次离心漂浮[3]。然而，这些检测在治疗后长时间内仍保持阳性，因此不适合治疗后监测[6]。

**在呕吐物或粪便中目视识别成虫**提供确定性诊断，蛔虫呈现为通常长3-15厘米的乳白色线虫[9]。结果解释必须考虑标准技术常出现假阴性结果，强调尽管初步结果为阴性，但当临床怀疑仍然很高时重复检测的重要性[3]。

### Sources

[1] Toxocara canis and Trichuris vulpis - Common dog parasites: https://www.dvm360.com/view/toxocara-canis-and-trichuris-vulpis-common-dog-parasites-proceedings
[2] Problems associated with intestinal parasites in cats: https://www.dvm360.com/view/problems-associated-with-intestinal-parasites-cats
[3] Intestinal parasites: screening & prevention best practices: https://www.dvm360.com/view/intestinal-parasites-screening-prevention-best-practices
[4] Accurate evaluation of fecal samples critical to patient: https://www.dvm360.com/view/accurate-evaluation-fecal-samples-critical-patient
[5] Diagnosing internal parasites in cats: https://www.dvm360.com/view/diagnosing-internal-parasites-cats
[6] Merck Veterinary Manual Parasitology in Veterinary Practice: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/parasitology
[7] Merck Veterinary Manual Serologic Test Kits: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/serologic-test-kits
[8] Merck Veterinary Manual Giardiasis in Animals: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[9] Merck Veterinary Manual Roundworms in Small Animals: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals

## 治疗选择

犬和猫蛔虫病的治疗涉及几种批准的驱虫药物，具有针对不同年龄组的特定给药方案。存在多种有效选择来消除蛔虫感染和管理严重受影响的动物[1]。

**批准的驱虫药**包括芬苯达唑（50 mg/kg，每日一次，连用3天）、米尔贝肟（0.5 mg/kg，每月一次）、莫昔克丁（2.5 mg/kg，每月一次外用）、哌嗪（48-66 mg/kg，一次，10天后重复）和双羟萘酸噻嘧啶（5 mg/kg，一次）[1]。对于仅针对成虫的药物，间隔10-14天给药两次应能消除感染，在第二次治疗后7-14天进行粪便检查以确认疗效[1,3]。

**年龄特异性方案**对有效治疗至关重要。幼犬应早在2周龄开始治疗，每2周重复一次直至3个月大，然后每月一次至6个月大[1]。哺乳母犬需要与幼犬相同间隔的同步治疗以防止再感染[1]。对于猫，幼猫需要从2周龄开始治疗，每2周继续一次至12周龄，然后每月一次至6个月大[1]。

**护理考虑**包括对脱水和营养不良的支持性液体治疗，监测严重感染中的蠕虫性肺炎等并发症，以及管理并发的继发感染[1]。环境卫生至关重要，因为虫卵在环境中2-4周后具有传染性并可存活很长时间[1]。

**预防计划**使用含有米尔贝肟、莫昔克丁或伊维菌素组合的月度心丝虫预防药物，当定期给药时也提供有效的蛔虫控制[1]。

### Sources
[1] Roundworms in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals
[2] Canine and feline lungworms (Proceedings): https://www.dvm360.com/view/canine-and-feline-lungworms-proceedings
[3] Roundworms in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals

## 预防措施

有效预防犬和猫蛔虫病需要综合方法，结合战略性驱虫计划、环境管理与心丝虫预防产品的整合[1]。

### 幼犬和幼猫驱虫方案

伴侣动物寄生虫委员会（CAPC）建议幼犬在2周龄时初次驱虫，之后每两周重复一次直至8周龄[1]。幼猫应在3周龄开始驱虫，每两周重复一次直至9周龄[1]。在适当年龄，所有幼犬和幼猫应开始使用对蛔虫有活性的月度心丝虫预防药物[1]。

### 成年动物维持计划

对于成年犬和猫，应至少每年通过粪便检查进行常规监测[2]。许多兽医寄生虫学家建议全年使用对胃肠道寄生虫有效的驱虫药治疗，以防止环境被传染性虫卵污染[4]。控制肠道蛔虫的月度心丝虫预防药物提供极好的持续保护[2]。

### 环境控制和粪便管理

环境中蛔虫卵污染对再感染和人畜共患传播构成重大风险[1]。及时清除和妥善处置粪便至关重要，因为虫卵可存活多年[4]。由于弓首蛔虫卵会粘附在表面并与土壤和灰尘混合，在接触可能污染的区域时应严格遵守卫生措施[10]。

### 与心丝虫预防整合

多种含有米尔贝肟、莫昔克丁、伊维菌素组合或塞拉菌素的心丝虫预防药物也可控制蛔虫感染[2]。这种整合方法提供对心丝虫病和肠道寄生虫的全年保护，同时提高主人依从性[1]。

### Sources

[1] Deworming: Next steps in disease prevention: https://www.dvm360.com/view/deworming-next-steps-disease-prevention
[2] Roundworms in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals
[3] Toxocara cati (Proceedings): https://www.dvm360.com/view/toxocara-cati-proceedings
[4] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[5] Zoonotic diseases (Proceedings): https://www.dvm360.com/view/zoonotic-diseases-proceedings
[6] Overview of Gastrointestinal Parasites of Ruminants: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-ruminants/overview-of-gastrointestinal-parasites-of-ruminants
[7] Parasitology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/parasitology
[8] Parasitology diagnostics in your practice (Proceedings): https://www.dvm360.com/view/parasitology-diagnostics-your-practice-proceedings
[9] CAPC releases new parasite guidelines: https://www.dvm360.com/view/capc-releases-new-parasite-guidelines
[10] Gastrointestinal Parasites of Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs

## 鉴别诊断

几种情况可模拟犬和猫的蛔虫病，需要仔细的临床和诊断鉴别。主要鉴别包括其他肠道寄生虫、营养不良和胃肠道吸收不良障碍[1]。

**其他肠道寄生虫**表现出重叠症状。钩虫（*Ancylostoma caninum*、*A. braziliense*、*Uncinaria stenocephala*）引起幼犬贫血和生长不良，但在严重感染中可通过黑色柏油样粪便和皮肤皮炎来区分[1]。鞭虫（*Trichuris vulpis*）导致体重减轻和粪便带鲜血，但虫卵需要更长时间才具有传染性（4-8周，而蛔虫为2-4周）[1]。胃线虫（*Physaloptera*物种）引起呕吐和食欲丧失，但通常在呕吐物中发现完整虫体时才被诊断[1]。

**营养不良和吸收不良障碍**可表现出与蛔虫病相似的生长迟缓和身体状况不良。然而，这些情况缺乏蛔虫感染特有的"大腹便便"外观以及粪便或呕吐物中存在虫体的特征[2]。

**蛔虫病的关键鉴别特征**包括弓首蛔虫的特征性球形、带凹痕壳的虫卵（犬弓首蛔虫为80-90 × 75微米；猫弓首蛔虫为65 × 75微米）与狮弓蛔虫的卵形、光滑壳虫卵（75-85 × 60-75微米）的区别[5]。猫弓首蛔虫独特的箭形前端有助于将其与其他蛔虫区分[3]。显微镜粪便检查仍然是确定性诊断工具，尽管商业抗原检测也可用[5]。

### Sources
[1] Gastrointestinal Parasites of Dogs: https://www.merckvetmanual.com/en-au/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs
[2] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[3] Central Nervous System Disorders Caused by Parasites in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/central-nervous-system-disorders-caused-by-parasites-in-dogs
[4] Roundworms in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals
[5] Roundworms in Small Animals: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/roundworms-in-small-animals
