# 伴侣动物中性粒细胞减少症

中性粒细胞减少症是犬猫中一种重要的血液学疾病，特征为中性粒细胞计数异常低下，使动物易发生危及生命的细菌感染。这种情况通过多种机制影响伴侣动物，包括病毒性骨髓抑制、免疫介导的破坏和药物诱导的毒性。本报告探讨了中性粒细胞减少症的复杂病理生理学，从细小病毒引起的骨髓损伤到灰色柯利犬特有的周期性造血。关键诊断挑战包括区分感染性原因与免疫介导疾病，而治疗方法从支持性抗生素治疗到免疫抑制方案和新兴的G-CSF疗法。

## 疾病概述

中性粒细胞减少症定义为绝对中性粒细胞计数低于正常参考范围：犬<3,000/μl，猫<2,500/μl（默克兽医手册）。这种情况由骨髓产生减少、外周消耗增加或通过免疫介导机制增强中性粒细胞破坏所致。

流行病学模式在不同品种和年龄组间显示显著差异。4周至2岁的幼年动物表现出易感性增加，特别是德国牧羊犬、罗威纳犬和杜宾犬，它们对细小病毒感染表现出更高的易感性（默克兽医手册）。某些品种表现出特定的遗传易感性：灰色柯利犬发展为周期性造血，具有典型的12天严重中性粒细胞减少周期，而比利时特弗伦犬表现出中性粒细胞减少相关疾病频率增加（DVM 360）。

严重程度分类通常将中性粒细胞减少症分为轻度（1,000-2,500/μl）、中度（500-1,000/μl）或重度（<500/μl），患有重度中性粒细胞减少症的动物面临致命性细菌感染的最高风险，需要立即干预。

## 常见病原体

伴侣动物的中性粒细胞减少症由多种感染性病原体引起，这些病原体损害骨髓或增加中性粒细胞消耗。几种关键病毒病原体通过直接骨髓抑制引起严重中性粒细胞减少。

**病毒病原体**是犬猫中性粒细胞减少症的最重要原因。犬细小病毒靶向快速分裂的骨髓细胞，引起严重中性粒细胞减少症并伴有胃肠道症状[1]。在猫中，猫泛白细胞减少症病毒（FPV）通过破坏造血祖细胞导致严重的白细胞减少症，中性粒细胞减少通常在淋巴细胞减少之前发生[2]。猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）是额外的病毒性原因，FeLV破坏造血干细胞并导致中性粒细胞成熟障碍[3]。

**细菌感染**通常通过多种机制导致中性粒细胞减少。败血症增加中性粒细胞边缘化和消耗，而严重的细菌过程可能超过骨髓产生能力[3]。由犬埃立克体引起的埃立克体病影响单核细胞并可能损害骨髓增殖，特别是在骨髓变为增生低下的慢性病例中[4]。

**其他感染性病原体**包括立克次体生物和机会性病原体。全身性真菌感染如组织胞浆菌病和隐球菌病在真菌生物取代正常骨髓组织时可引起骨髓痨[3]。这些感染在接受免疫抑制方案的免疫受损动物中尤其令人担忧[5]。

### Sources
[1] Merck Veterinary Manual Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[2] Merck Veterinary Manual Feline Panleukopenia: https://www.merckvetmanual.com/infectious-diseases/feline-panleukopenia/feline-panleukopenia
[3] DVM 360 Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[4] Merck Veterinary Manual Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/infectious-diseases/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[5] Opportunistic Fungal Infections in Small Animals: https://meridian.allenpress.com/jaaha/article/54/6/327/184123/Opportunistic-Fungal-Infections-in-Small-Animals

## 临床症状和体征

犬猫的中性粒细胞减少症通常表现为非特异性临床表现，反映了潜在的免疫受损状态。最常见的临床体征是持续性发热，常伴有嗜睡、厌食和精神状态抑郁的迹象[1]。一些动物可能出现转移性跛行、呕吐、腹泻或流涎过多[4]。

体格检查结果各不相同，但可能包括感染迹象，如脓皮病、口腔溃疡、鼻衄、结膜炎或局部脓肿。关节积液、面部水肿和阴囊炎症也有记录[4]。临床体征的严重程度通常与中性粒细胞减少的程度相关，患有重度中性粒细胞减少症（<500/μl）的动物面临致命性细菌感染的最高风险。

**品种特异性模式**在某些疾病中特别值得注意。灰色柯利犬发展为周期性造血，特征为12天周期，在此期间所有血细胞类型减少，中性粒细胞受影响最严重[2][3]。这些犬表现为广泛的中性粒细胞减少、反复发作的严重细菌感染、因并发血小板减少症引起的出血并发症，以及独特的被毛苍白和鼻色素沉着[3]。受影响的幼犬通常发育迟缓和虚弱，在中性粒细胞减少期间发生严重细菌感染。

比利时特弗伦犬是另一个被记录经常受中性粒细胞减少相关疾病影响的品种[5]。此外，患有猫胞子虫病的猫通常表现为非特异性体征，包括抑郁、嗜睡和厌食[6]。

大多数患有周期性造血的犬在6个月大时因暴发性感染死亡，而存活的犬通常在3岁前因淀粉样变性而死亡[2][3]。

### Sources
[1] Findings and prognostic indicators of outcomes for queens: https://avmajournals.avma.org/downloadpdf/view/journals/javma/260/S2/javma.20.12.0712.pdf
[2] Merck Veterinary Manual Bleeding Disorders of Dogs: https://www.merckvetmanual.com/dog-owners/blood-disorders-of-dogs/bleeding-disorders-of-dogs
[3] Merck Veterinary Manual White Blood Cell Disorders of Dogs: https://www.merckvetmanual.com/dog-owners/blood-disorders-of-dogs/white-blood-cell-disorders-of-dogs
[4] DVM 360 Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[5] Ophthalmology Challenge: A greyhound with red eyes: https://www.dvm360.com/view/ophthalmology-challenge-greyhound-with-red-eyes
[6] Cytauxzoonosis in Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/blood-parasites/cytauxzoonosis-in-cats

## 诊断方法

中性粒细胞减少症诊断需要通过临床表现评估、全面实验室检测和靶向诊断程序进行系统评估。全血细胞计数（CBC）与分类计数构成诊断的基石，测量低于参考范围（犬<3,000/μl，猫<2,500/μl）的绝对中性粒细胞计数[1]。血涂片检查提供关键的形态学信息，揭示中性粒细胞的毒性变化提示严重感染，或识别可能表明免疫介导过程的聚集模式[2]。

当外周血发现提示产生障碍或需要区分消耗和产生减少时，骨髓评估变得必不可少[5]。骨髓抽吸显示在外周破坏病例中骨髓增生伴髓系增生但缺乏成熟中性粒细胞，而增生低下骨髓表明产生衰竭[5]。应在抗生素治疗前采集血培养，建议从不同部位采集至少三个样本以识别菌血症或败血症[2]。

特异性感染原检测包括病毒病原体（细小病毒、FeLV、FIV）的PCR检测、从适当部位进行的细菌培养，以及常见引起中性粒细胞减少的蜱传疾病的血清学检测[6]。流式细胞术可在疑似免疫介导病例中检测中性粒细胞相关抗体，尽管标准化检测在兽医医学中仍然有限[3]。额外的影像学检查方法包括放射学和超声检查，有助于识别导致中性粒细胞减少的潜在感染灶或肿瘤过程[8]。

### Sources

[1] Clinical Hematology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[2] White Blood Cell Disorders of Dogs: https://www.merckvetmanual.com/en/dog-owners/blood-disorders-of-dogs/white-blood-cell-disorders-of-dogs
[3] Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[4] Complete blood count interpretation: https://www.dvm360.com/view/complete-blood-count-interpretation-cells-and-numbers-proceedings
[5] Skills Laboratory: How to collect diagnostic bone marrow samples: https://www.dvm360.com/view/skills-laboratory-how-collect-diagnostic-bone-marrow-samples
[6] Managing and preventing feline febrile diseases: https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings
[7] Feline infectious diseases-a collection of interesting cases: https://www.dvm360.com/view/feline-infectious-diseases-collection-interesting-cases-proceedings
[8] Fever of unknown origin: https://www.dvm360.com/view/fever-unknown-origin-proceedings-3

## 治疗选择

中性粒细胞减少症治疗侧重于解决潜在原因，同时提供支持性护理和在适当时进行免疫抑制。抗生素治疗仍然是初始管理的基石，推荐对发热性中性粒细胞减少患者使用广谱杀菌抗生素（β-内酰胺类、氟喹诺酮类）[1]。当绝对中性粒细胞计数降至1.0 x 10^9/L以下时，预防性抗菌药物是必要的，通常选择氟喹诺酮类，因为其覆盖范围广且能保留厌氧菌群[2]。

对于免疫介导的中性粒细胞减少症，免疫抑制治疗是必不可少的。泼尼松龙以2-4 mg/kg每日剂量通常在数天至数周内启动反应，尽管中性粒细胞恢复可能需要长达三周[3]。在犬中，可添加硫唑嘌呤（初始2 mg/kg每日，然后隔日）作为类固醇节约治疗，而猫通常单独对皮质类固醇有反应[4]。

粒细胞集落刺激因子（G-CSF）疗法对严重病例显示出希望。非格司亭在治疗猫中硫唑嘌呤诱导的中性粒细胞减少症中显示出疗效，尽管重组G-CSF仍处于实验阶段且价格昂贵[1][5]。人G-CSF在动物中存在安全隐患，通常保留用于极端情况。

支持性护理包括监测继发感染和管理并发的血细胞减少症。对于药物诱导的中性粒细胞减少症，立即停用致病药物至关重要。治疗持续时间各不相同，但患者通常需要延长治疗，并仔细监测副作用和疾病复发。

### Sources
[1] Filgrastim Use in the Treatment of Azathioprine-Induced Neutropenia: https://meridian.allenpress.com/jaaha/article/60/3/105/500367/Filgrastim-Use-in-the-Treatment-of-Azathioprine
[2] Antibiotic prophylaxis in veterinary chemotherapy: When its worth the risk: https://www.dvm360.com/view/antibiotic-prophylaxis-veterinary-chemotherapy-when-it-s-worth-risk
[3] Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[4] Immunosuppressive therapy (Proceedings): https://www.dvm360.com/view/immunosuppressive-therapy-proceedings
[5] Use of recombinant human granulocyte colony-stimulating factor: https://avmajournals.avma.org/view/journals/ajvr/73/6/ajvr.73.6.894.xml

## 预防措施

疫苗接种仍然是伴侣动物中性粒细胞减少症预防的基石。针对细小病毒的核心疫苗应遵循WSAVA和AAHA指南进行接种，从6-8周龄开始，每3-4周加强一次，直到16-20周龄[1]。对于猫白血病病毒（FeLV），对风险猫的疫苗接种至关重要，特别是那些有户外活动机会或生活在多猫环境中的猫[2]。

环境控制措施对中性粒细胞减少患者至关重要。必须实施严格的隔离方案，包括专用住房、处理人员的防护设备和彻底的消毒程序[1]。有效消毒剂包括稀释漂白剂（1:30-1:32）、过氧单硫酸钾或加速过氧化氢，因为季铵盐产品对细小病毒无效[1]。

风险品种需要加强监测策略。德国牧羊犬、罗威纳犬和杜宾犬对细小病毒感染和随后的中性粒细胞减少症表现出增加的易感性[3]。幼年动物（4周至2岁）需要特别警惕，在收容所环境中收容时立即接种疫苗[1]。

生物安全措施超出诊所范围延伸到家庭环境。密切关注卫生、适当的废物处理和限制接触未接种疫苗的动物可降低传播风险[1]。在疫情爆发情况下，对整个群体进行及时重新接种疫苗至关重要，因为即使在暴露前不完全的免疫反应也可能提高生存结果[1]。

### Sources
[1] Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia
[2] Managing and preventing feline febrile diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings  
[3] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/en/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

## 鉴别诊断

中性粒细胞减少症提出了一个具有挑战性的诊断难题，需要仔细与几种具有重叠临床表现的疾病进行鉴别。免疫介导的血小板减少症（IMTP）代表了一个关键的鉴别诊断，与中性粒细胞减少症具有相似的病理生理学和临床特征[1][2]。

IMTP通常表现为瘀点性出血、粘膜出血和全身性症状如嗜睡和发热，这些可以模仿免疫介导的中性粒细胞减少症的临床表现[2]。关键鉴别因素在于全血细胞计数结果：IMTP表现为严重血小板减少（通常<30,000/μl）同时维持正常中性粒细胞计数，而中性粒细胞减少症则显示相反模式[2][3]。

药物诱导的血细胞减少症构成了另一个重大的诊断挑战。多种药物可通过免疫介导机制同时诱发中性粒细胞减少症和血小板减少症，包括磺胺类药物、甲巯咪唑和化疗药物[3][5]。药物诱导的反应通常在初始治疗后数周至数月发展，并在停药后两周内解决，为鉴别提供了重要的时间线索[3]。

当多个细胞系受影响时，骨髓疾病需要仔细考虑。骨髓痨、再生障碍性贫血和造血肿瘤等情况可表现为全血细胞减少，使其与孤立性中性粒细胞减少症可区分[1][6]。在这些情况下，骨髓抽吸对于评估细胞度和识别浸润过程变得至关重要。

并发临床发现的存在有助于区分感染性原因与免疫介导疾病。立克次体感染、病毒性疾病和全身性细菌感染通常表现出额外的临床体征、血清学阳性或特征性血涂片发现如桑葚状体，从而提供与原发性免疫介导的中性粒细胞减少症的诊断清晰度[1][5]。

### Sources
[1] DVM 360 Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[2] DVM 360 Diagnosis and treatment of immune-mediated thrombocytopenia (Proceedings): https://www.dvm360.com/view/diagnosis-and-treatment-immune-mediated-thrombocytopenia-proceedings
[3] DVM 360 Overcoming the diagnostic and therapeutic challenges of canine immune-mediated thrombocytopenia: https://www.dvm360.com/view/overcoming-diagnostic-and-therapeutic-challenges-canine-immune-mediated-thrombocytopenia
[4] Merck Veterinary Manual Platelet Disorders in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/platelet-disorders-in-animals
[5] DVM 360 Immune-mediated neutropenia (Proceedings): https://www.dvm360.com/view/immune-mediated-neutropenia-proceedings
[6] Merck Veterinary Manual Leukogram Abnormalities in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
