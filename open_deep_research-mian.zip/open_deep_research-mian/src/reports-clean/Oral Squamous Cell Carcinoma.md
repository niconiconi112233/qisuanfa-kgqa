# 伴侣动物口腔鳞状细胞癌

口腔鳞状细胞癌是兽医肿瘤学中最具挑战性的恶性肿瘤之一，在犬和猫之间表现出明显不同的临床表现和结局。这种侵袭性癌症每年影响数千只伴侣动物，猫的预后尤其严重，一年生存率低于10%。该疾病倾向于侵犯骨结构并对常规治疗产生耐药性，这使得早期检测和针对物种的治疗方法对于获得最佳患者结局至关重要。本报告探讨了定义两个物种口腔SCC的流行病学模式、诊断挑战、治疗方式和预后因素，强调了改进治疗策略和提高主人对这种棘手疾病认识的迫切需求。

## 摘要

口腔鳞状细胞癌是一种毁灭性的恶性肿瘤，具有物种特异性特征，这些特征从根本上影响临床管理和结局。猫的预后特别严峻，中位生存时间为三个月，一年生存率低于10%，而犬通过手术干预可获得更好的结局，当完全切除可能时，一年生存率达到84-91%。该疾病表现出明显的解剖学偏好，猫的病例主要影响舌下区域，而犬的病例更常见地涉及前侧牙龈。

| 特征 | 犬 | 猫 |
|---|---|---|
| **中位年龄** | 8-10年 | 11-13年 |
| **主要位置** | 前侧牙龈 | 舌下区域 |
| **品种易感性** | 德国牧羊犬、贵宾犬 | 未发现 |
| **1年生存率** | 84-91%（手术病例） | <10% |
| **治疗反应** | 完全切除效果良好 | 无论何种方式反应均差 |

包括烟草烟雾暴露和饮食模式在内的环境因素显著影响猫的风险，而成功治疗需要采用广泛边缘的激进手术方法。物种之间的显著差异强调了为每个患者群体制定定制诊断和治疗协议的关键重要性。

## 疾病概述和流行病学

口腔鳞状细胞癌（SCC）是一种起源于口腔腔上皮细胞的恶性肿瘤。它是猫最常见的口腔恶性肿瘤，占所有猫口腔肿瘤的70-80%[1][2][3]。在犬中，SCC是第二常见的口腔恶性肿瘤，占犬口腔肿瘤的17-25%，仅次于恶性黑色素瘤[4]。

流行病学模式在物种间差异显著。在猫中，口腔SCC通常影响中年至老年动物，中位年龄为12.5岁，范围为3至21岁[2]。患有口腔SCC的犬在诊断时的中位年龄为8-10岁[4]。最近的犬类研究显示总体发病率为每1000名患者4.59个口腔肿瘤，诊断时的中位年龄为9.66岁[5]。

在犬中已发现品种易感性，德国牧羊犬、贵宾犬和拉布拉多寻回犬对SCC表现出易感性增加[5]。大型犬似乎比小型犬更常患口腔SCC[4]。在猫中，没有记录到明显的性别或品种偏好[2]。存在地区地理差异，瑞士的研究显示SCC prevalence在州与州之间有所不同，表明环境因素可能影响肿瘤发展[6][7]。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[3] Finding and treating oral melanoma, squamous cell ...: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[4] Understanding canine oral neoplasia - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.xml
[5] Understanding canine oral neoplasia: intrinsic rather than ...: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.pdf
[6] A retrospective study of oral tumors in cats in Switzerland ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.05.0161/ajvr.25.05.0161.xml
[7] A retrospective analysis of oral tumors in dogs in Switzerland ...: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.06.0414.xml

I'll synthesize the existing section content with the provided source material to enhance the Etiology and Pathogenesis section for oral squamous cell carcinoma in cats.

## 病因学和发病机制

伴侣动物口腔鳞状细胞癌的病因学在很大程度上仍然是特发性的，多种因素可能促进致癌作用。与许多其他癌症不同，尽管乳头瘤病毒在人类头颈癌中很重要，但尚未在猫的口腔SCC中明确建立病毒关联[1]。

环境因素可能在疾病发展中发挥重要作用。被动吸烟暴露似乎会增加风险，生活在主人每天吸烟1-19支香烟的家庭中的猫，与不吸烟家庭中的猫相比，显示出统计学上显著的四倍风险增加[2]。此外，暴露于环境烟草烟雾的猫过度表达p53肿瘤抑制蛋白的可能性是4.5倍，表明与致癌物相关的突变[2]。

跳蚤控制产品呈现相互矛盾的结果。虽然使用跳蚤项圈与五倍风险增加相关，可能是由于杀虫剂接近口腔，但定期使用跳蚤香波显示风险降低90%，可能是通过减少皮毛上的化学污染物积累[2]。

饮食因素也影响风险。经常食用罐头食品的猫显示三倍风险增加，而食用金枪鱼罐头的猫与干粮消费者相比有五倍更高风险。这可能与营养含量差异或干粮消费者更好的口腔卫生有关[2]。

慢性炎症和刺激已被认为是促成因素。一些研究者提出慢性牙龈口腔炎和口腔SCC发展之间可能存在联系，因为两者都涉及慢性炎症过程[3]。

致癌作用的分子机制仍在研究中，由于猫和人类口腔SCC之间的相似性，猫被认为是人类头颈癌研究的潜在模型[1][4]。

### Sources
[1] Oral squamous cell carcinoma in cats - dvm360: https://www.dvm360.com/view/oral-squamous-cell-carcinoma-cats
[2] Feline oral squamous cell carcinoma: An overview - dvm360: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[3] Dental radiographic findings in cats with chronic gingivostomatitis: https://avmajournals.avma.org/view/journals/javma/244/3/javma.244.3.339.xml
[4] DVM 360 Feline oral cancer is the focus of a new study: https://www.dvm360.com/view/feline-oral-cancer-is-the-focus-of-a-new-study

## 临床表现和诊断

口腔鳞状细胞癌的临床表现常常模仿牙科疾病，使早期检测具有挑战性[1,2]。最常见的临床症状包括口腔出血（鼻衄）、水碗中带血、进食困难、流涎（唾液过多）、口臭以及牙齿松动或缺失[1,2,3]。晚期疾病可能出现面部畸形[2,3]。在猫中，主人最常注意到可见的肿块，即使没有明显的肿块，溃疡和松动的牙齿也特别可疑[2,10]。

体格检查通常显示溃疡、易碎的肿块，颜色可能与周围粘膜不同，并且常常越过牙齿线[3]。世界卫生组织TNM分期系统根据原发肿瘤直径和骨侵犯进行分类，区域淋巴结参与分为N0-N3[1]。

使用计算机断层扫描（CT）的先进成像在评估骨侵犯程度和软组织疾病扩展方面优于常规放射学[1,4]。CT通常显示广泛的鼻甲破坏，可能涉及鼻中隔、额窦和筛板的侵蚀性病理[1]。牙科X光片可以显示明显的骨质溶解，影响比单独基于体格检查怀疑的更大区域[1]。

无论淋巴结大小如何，都应进行区域淋巴结（下颌和咽后）的细针抽吸，因为微转移可能发生在正常大小的淋巴结中[3,4]。为了明确诊断，需要镇静或麻醉进行切开活检和组织病理学检查[2,10]。建议进行三视图胸部X光检查以筛查远处转移，尽管肺转移很少见[2,3]。

### Sources
[1] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[2] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[3] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[4] Get armed to the teeth about veterinary oral tumors: https://www.dvm360.com/view/get-armed-teeth-about-veterinary-oral-tumors
[5] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses
[6] Managing oral tumors (Proceedings): https://www.dvm360.com/view/managing-oral-tumors-proceedings
[7] Managing canine oral tumors: https://www.dvm360.com/view/managing-canine-oral-tumors
[8] Update on canine melanoma (Proceedings): https://www.dvm360.com/view/update-canine-melanoma-proceedings
[9] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors
[10] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings

## 治疗选择

手术切除仍然是伴侣动物口腔鳞状细胞癌的主要治疗方式。由于这些肿瘤涉及骨组织和侵犯，通常需要区域性下颌骨切除术或上颌骨切除术，尽管它们呈现软组织外观[1]。完全手术切除需要整块切除肿瘤和相关骨结构，因为保守手术导致复发率超过70%[3]。

放射治疗作为重要的辅助或主要治疗选择。大分割粗放射治疗方案对口腔肿瘤显示出疗效，立体定向放射治疗在1-5次分割中提供消融剂量[7]。当手术边缘不完全时，可以使用常规分割（18-19次治疗）的确定性放射治疗[4]。当使用立体定向技术进行时，外束放射治疗对鼻肿瘤的中位生存时间为8-18个月[3]。

口腔SCC的化疗选择作为单一治疗的效果仍然有限[6]。然而，使用米托蒽醌、卡铂或吉西他滨等放射增敏剂的联合方法已显示出生存时间的适度改善[6,8]。包括靶向PD-1/PD-L1等检查点分子的单克隆抗体在内的新型免疫治疗方法代表了正在研究中的新兴治疗选择[10]。卟啉体纳米技术与光疗结合正在被研究作为猫口腔SCC的潜在非手术选择[2]。

姑息治疗策略侧重于疼痛管理和生活质量优化。使用4-6次分割的姑息性放射治疗方案可以提供肿瘤缩小和疼痛缓解[6,8]。通过食管造口管进行营养支持在激进口腔手术后至关重要[8]。抗炎药物和镇痛药有助于管理无法手术肿瘤的不适[4,8]。

### Sources
[1] Merck Veterinary Manual Oral Tumors in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] DVM 360 Feline oral cancer is the focus of a new study: https://www.dvm360.com/view/feline-oral-cancer-is-the-focus-of-a-new-study
[3] Merck Veterinary Manual Radiation Therapy in Animals - Therapeutics - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/radiation-therapy/radiation-therapy-in-animals
[4] Journal of the American Veterinary Medical Association Outcomes associated with local treatment of nasal planum squamous cell carcinoma in dogs: 89 cases (2003-2020): https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0642.xml
[5] DVM 360 Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[6] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 预后和结局

口腔鳞状细胞癌在犬和猫中均预后不良，在生存结局方面存在物种特异性差异。患有口腔SCC的猫生存率特别差，一年生存率通常低于10%，大多数治疗方式的中位生存时间约为三个月[1]。大多数患有口腔肿瘤的猫死于局部疾病而非远处转移[1]。相比之下，接受手术治疗的下颌或上颌SCC犬显示出更好的结局，中位无病间隔为26个月，一年生存率为84-91%[2][5]。

治疗方式显著影响预后。当完全切除可行时，手术提供最佳结局，特别是对于小的前侧肿瘤[1][2][6]。作为主要治疗的放射治疗在猫中产生2-6个月的中位生存时间[3]。对于患有无法手术的口腔SCC的犬，患有无法手术疾病的猫在姑息治疗下中位生存时间为1-3个月，姑息治疗最为有益[3]。

影响生存的预后因素包括肿瘤大小、位置、诊断时分期以及手术切除的完整性[2][5]。越过口腔中线或位于后部区域的肿瘤预后更差[1][3]。大多数患有SCC的猫不会活到经历晚期放射副作用[1]。

生活质量考虑至关重要，因为像下颌骨切除术这样的激进治疗导致98%的猫出现急性发病率，76%经历长期影响，包括吞咽困难和梳理困难[2]。尽管存在这些挑战，83%的主人报告对其宠物术后生活质量满意[2]。

### Sources
[1] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[2] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[3] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[4] Canine and feline oral tumors: Earlier is better: https://www.dvm360.com/view/canine-and-feline-oral-tumors-earlier-better
[5] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[6] Managing canine oral tumors: https://www.dvm360.com/view/managing-canine-oral-tumors

## 比较分析：犬 vs 猫

现有部分内容为比较犬和猫口腔SCC提供了全面的基础。根据来源材料，可以整合额外的品种特异性模式和治疗考虑因素以增强此分析。

**品种易感性：** 最近的研究揭示了犬的特定品种易感性，德国牧羊犬显示口腔SCC的最高易感性（占病例的28%），其次是贵宾犬（23%）和拉布拉多寻回犬[1]。这与猫形成对比，猫中没有明显的品种偏好，尽管暹罗猫在某些口腔肿瘤类型中可能比例过高[2]。

**解剖分布：** 来源材料证实了物种间明显的解剖偏好。在犬中，口腔SCC通常影响牙龈，特别是犬齿前侧区域，甲床是另一个常见的皮肤位置[3][4]。猫口腔SCC表现出对舌下区域的强烈偏好，舌头受累占病例的24%，并代表了舌下区域识别的所有肿瘤[5]。

**年龄和人口统计学：** 犬通常在8-10岁中位年龄时发展为口腔SCC，而猫在11-13岁时稍晚出现，尽管范围在两个物种中都从3个月延伸到21岁[6]。猫中更广泛的年龄范围可能反映了不同的致病机制或环境暴露。

**临床表现：** 两个物种都表现出相似的临床症状，包括口臭、体重减轻、吞咽困难和口腔肿块，但猫更常见地表现出不停咀嚼和过度流涎[6]。猫病例特有的广泛骨侵犯通常导致比犬更明显的面部不对称。

犬和猫口腔SCC在生物学行为、解剖偏好和治疗反应方面的根本差异强调了临床实践中物种特异性诊断和治疗方法的重要性。

### Sources

[1] Understanding canine oral neoplasia: intrinsic rather than ...: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.pdf
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[3] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[4] Cutaneous lumps and bumps: The good, the bad and ...: https://www.dvm360.com/view/cutaneous-lumps-and-bumps-good-bad-and-ugly-proceedings
[5] A retrospective study of oral tumors in cats in Switzerland ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.05.0161/ajvr.25.05.0161.pdf
[6] Feline dental problems (Proceedings): https://www.dvm360.com/view/feline-dental-problems-proceedings
