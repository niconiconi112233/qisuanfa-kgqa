# 猫上呼吸道感染

猫上呼吸道感染是小动物临床实践中最常见的临床疾病之一，影响所有年龄段的猫，尤其在幼猫和免疫功能低下的个体中病情更为严重。本综合报告探讨了导致猫呼吸道疾病的病毒和细菌病原体之间复杂的相互作用，其中猫疱疹病毒-1和猫杯状病毒占病例的80-90%。该分析涵盖了病原体鉴定、临床识别模式、循证诊断方法和治疗干预措施的关键方面。特别关注了管理慢性携带者的挑战、实施有效的疫苗接种方案，以及通过系统的鉴别诊断区分上呼吸道感染与其他呼吸道疾病。理解这些多方面的内容有助于兽医为个体患者和群体环境提供最佳护理，同时防止疾病传播。

## 摘要

猫上呼吸道感染是一种多方面的疾病复合体，需要全面了解病毒和细菌的相互作用。FHV-1和FCV作为主要病原体的主导地位，加上猫衣原体和支原体属引起的继发性细菌并发症，导致了从轻度结膜炎到严重全身性疾病的不同临床表现。诊断准确性在很大程度上依赖于PCR检测结合临床模式识别，因为传统方法往往无法在混合感染中识别特定的致病因子。

治疗成功取决于早期实施支持性护理，并结合针对继发性细菌感染的靶向抗菌治疗。包括泛昔洛韦和L-赖氨酸补充剂在内的抗病毒干预措施在管理FHV-1复发方面显示出前景，而阿奇霉素则提供了延长的抗菌覆盖范围。通过适当的疫苗接种方案、环境管理和压力降低进行预防仍然至关重要，特别是在高密度群体中，过度拥挤是严重爆发的最大风险因素。

鉴别诊断的复杂性需要对慢性病例进行仔细评估，区分传染性原因与肿瘤性、真菌性或异物相关疾病。有效的管理需要整合病原体特异性治疗、支持性护理和综合预防策略，以优化患者预后，同时最小化猫群体内的疾病传播。

## 常见病原体

猫上呼吸道感染主要由两种主要病毒病原体和几种细菌病原体引起，它们可以单独或联合作用[1]。猫疱疹病毒-1（FHV-1）和猫杯状病毒（FCV）占猫病毒性上呼吸道疾病病例的80-90%[2][3]。这些病毒属于不同家族，具有影响其致病性和传播模式的不同特征。

**病毒病原体**

FHV-1是一种属于α疱疹病毒科的包膜DNA病毒[4]。该病毒在三叉神经节中建立终身潜伏感染，在压力或免疫抑制期间会重新激活[5]。该病毒在环境中相对脆弱，在潮湿条件下存活时间不超过18小时[3]。FHV-1主要靶向上呼吸道上皮和结膜，引起特征性的树枝状角膜溃疡[4][5]。

FCV是来自杯状病毒科的非包膜RNA病毒，使其比FHV-1在环境中更稳定[1][4]。由于病毒的高突变率，存在多种遗传多样性菌株[1]。多达25%的临床健康种猫和10%的家庭猫是FCV携带者，持续从口咽部排毒[2][3]。一些强毒全身性菌株可导致严重疾病，死亡率高达60%[1]。

**细菌病原体**

猫衣原体是一种主要引起结膜炎的细菌物种，在英国等一些地区的流行率估计达到30%[2][3]。该生物主要通过猫与猫之间的直接接触传播，可引起慢性低度结膜炎[6]。

支原体属，特别是猫支原体，经常从患有呼吸道疾病的猫中分离出来，尽管它们作为主要病原体的作用仍有争议[4][6]。支气管败血波氏杆菌可引起猫的原发性呼吸道感染，并且可在狗和猫之间传播[9]。

### Sources
[1] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[2] Feline viral upper respiratory infection: Why it persists (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[3] Feline viral upper respiratory disease: why it persists! (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[4] Diagnosing and managing feline respiratory disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-feline-respiratory-disease-proceedings
[5] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings
[6] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[7] A retrospective analysis of canine, feline, and equine ...: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.11.0755/javma.24.11.0755.pdf
[8] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[9] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings

## 临床症状和体征

猫上呼吸道感染的临床表现通过特征性的眼部、鼻腔和口腔体征表现出来[1]。发病时表现为体温高达105°F（40.5°C）的发热、频繁打喷嚏和从浆液性发展为粘液脓性的鼻分泌物[1]。伴有流泪的结膜炎突出，常伴有流涎和口腔溃疡[1]。

猫疱疹病毒（FHV-1）主要影响结膜和鼻腔通道，引起严重的结膜炎、鼻炎和流涎过多[1]。可能发展为角膜并发症，包括溃疡性角膜炎、流泪、结膜水肿和眼睑痉挛[1]。严重虚弱的猫可能发展为溃疡性口炎[1]。

猫杯状病毒（FCV）通常靶向口腔粘膜和下呼吸道，在舌头、硬腭或鼻孔上产生口腔溃疡[1]。某些菌株在8-12周龄的小猫中引起特征性的"跛行综合征"，表现为短暂发热、交替性跛行和关节疼痛，而无呼吸道症状[1]。

轻度病例体征可能持续5-10天，严重病例可达6周[1]。猫衣原体感染通常产生伴有粘液脓性分泌物和结膜水肿的严重结膜炎[1]。幼年或老年猫最易感，短头品种猫患慢性疾病的风险更高[1]。

### Sources
[1] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 诊断方法

诊断猫上呼吸道感染涉及临床评估结合特定的实验室检测，以识别致病病原体并指导治疗决策。

**临床诊断方法**
初步诊断基于典型的临床症状，包括打喷嚏、结膜炎、鼻炎、流泪、流涎、口腔溃疡和呼吸窘迫[1]。FHV-1感染往往影响结膜和鼻腔通道，而杯状病毒通常影响口腔粘膜和下呼吸道[1]。然而，在混合感染中这些特征可能变得模糊，使特定诊断具有挑战性。

**实验室检测选项**
吉姆萨染色结膜刮片的细胞学检查对识别衣原体和支原体很有价值[1]。呼吸道病原体的PCR检测已广泛可用，并提供快速、敏感的检测[2]。最近开发的PCR组合检测可同时检测常见的URI病因，包括FHV-1、FCV、猫衣原体、猫支原体和支气管败血波氏杆菌[2]。对于怀疑有细菌参与的慢性病例，抗菌药物选择应基于鼻组织样本的细菌培养和抗菌药物敏感性测试[3]。

**样本采集和运输**
口咽粘膜、外鼻孔和结膜囊是首选的采样部位[1]。应采集眼、鼻或咽后分泌物的样本进行PCR分析[1]。适当的运输介质和处理至关重要，特别是对于像FHV-1这样的脆弱生物[2]。与临床微生物实验室合作可优化诊断准确性[4]。

**解释挑战**
诊断可能很困难，因为FHV-1是间歇性排毒，而且FHV-1和FCV都可以从临床正常的猫中分离出来[1]。检测结果必须始终在临床背景下解释，因为阳性结果不一定表示活动性疾病[2]。由于各种因素包括样本采集时间，真正受感染的猫可能出现阴性结果[2]。

### Sources
[1] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[3] What are the best practices for antibiotic use in feline upper respiratory tract disease?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease
[4] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml

## 治疗选择

猫上呼吸道感染的治疗侧重于支持性护理、管理继发性细菌感染和处理特定的病毒病因。继发性细菌感染很常见，需要经验性抗菌治疗[1]。推荐使用广谱抗生素，包括阿莫西林-克拉维酸、甲硝唑和多西环素，其中阿奇霉素以5 mg/kg每日一次给药10-14天显示出比传统抗菌药物更长的有效性[1]。

对于病毒特异性治疗，存在几种抗病毒选择。L-赖氨酸（250-500 mg每日一次随食物服用）与疱疹病毒复制所需的精氨酸竞争，可能有助于预防FHV-1复发，但需要每日两次全剂量给药才能有效[1][2]。泛昔洛韦显示出前景，以125 mg片剂的四分之一到八分之一每日一次给药至少10天，以减少FHV-1复发[1]。每日两次局部使用西多福韦比其他眼部疗法更方便且刺激性更小，适用于FHV-1角膜炎[2]。

支持性护理仍然至关重要，包括充分的水合、营养、湿化和鼻腔减充血措施[3]。大多数病例在7-10天内无需特定治疗即可恢复，基础护理最好在家中提供，以最小化压力和继发感染[4]。免疫调节疗法包括口服人重组干扰素，尽管反应率不一[1][2]。鼻内改良活疫苗可能对常规治疗未能改善的猫有益，特别是在收容所环境中[2]。

### Sources

[1] Feline viral upper respiratory disease: why it persists!: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[2] WVC 2017: Managing Cats with Upper Respiratory Infection - Viral Causes: https://www.dvm360.com/view/wvc-2017-managing-cats-with-upper-respiratory-infection--viral-causes
[3] Nasal disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/nasal-disorders-dog-and-cat-proceedings
[4] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings

## 预防措施

**疫苗接种方案**仍然是猫上呼吸道感染预防的基础。AAFP建议使用含有猫疱疹病毒-1、杯状病毒和猫泛白细胞减少症的FVRCP疫苗进行常规接种。核心疫苗应在6周龄时开始，每3-4周加强一次直到16周龄，然后进行一次一年加强接种，之后每三年一次[7]。与灭活产品相比，改良活疫苗提供更快速的保护（胃肠外给药5-7天，鼻内给药3-5天）[7]。

**环境管理**侧重于压力减少和适当卫生。过度拥挤是严重呼吸道疾病爆发的最大风险因素[1]。减少种群密度、保持充分通风，并在猫居住期间实施点清洁方案有助于最小化传播[1][2]。FCV在干燥分泌物中可存活长达一个月，需要用1:32稀释的漂白剂溶液消毒[1]。

**隔离方案**对疾病控制至关重要。有活动性呼吸道症状的猫需要与健康群体分离，因为它们排出的病原体数量显著更高[2]。只有在能够维持真正分离和适当屏障护理的情况下，笼内隔离才是可接受的[2]。

## 鉴别诊断

**关键鉴别诊断**包括猫支气管哮喘，其通常表现为慢性咳嗽和喘息而非鼻分泌物[9]。慢性鼻窦炎通常涉及鼻腔肿瘤（癌、淋巴瘤）、真菌感染（隐球菌病、曲霉菌病）、牙科疾病或异物[8][9]。**模式识别**有助于鉴别：FHV-1主要影响结膜和鼻腔通道，而FCV通常涉及口腔粘膜并伴有特征性溃疡[2]。

### Sources
[1] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[2] Feline infectious respiratory disease (Proceedings): https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[7] Fungal Infections in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/fungal-infections-in-cats
[8] Chronic upper respiratory disease in cats (Proceedings): https://www.dvm360.com/view/chronic-upper-respiratory-disease-cats-proceedings
[9] Upper airway troubles (Proceedings): https://www.dvm360.com/view/upper-airway-troubles-proceedings
