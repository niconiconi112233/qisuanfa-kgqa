# 犬猫浅表性细菌性毛囊炎：综合兽医指南

浅表性细菌性毛囊炎是小动物临床中最常见的皮肤病之一，在犬中的发病率显著高于猫。这种细菌性皮肤感染涉及表皮浅层毛囊的炎症，主要由假中间型葡萄球菌和其他葡萄球菌属引起。该病具有独特的诊断和治疗挑战，特别是耐甲氧西林菌株的出现使治疗方案复杂化。本报告探讨了兽医实践中成功管理所必需的临床表现、诊断方法、循证治疗策略和预后因素。

## 疾病概述和常见病原体

现有内容提供了浅表性细菌性毛囊炎（SBF）的全面概述。本节综合了这些信息并补充了流行病学背景。SBF是犬类临床中最常见的皮肤病之一，在不同地理区域和环境条件下的发病率各不相同[1]。

从流行病学角度看，SBF在不同物种间表现出明显的差异模式。与猫相比，犬表现出显著更高的易感性，这主要是由于细菌对角质形成细胞粘附机制的差异[1]。环境因素也影响疾病患病率，在阳光照射较多的温暖气候地区报告的发病率较高，但不同地区的具体流行病学数据仍然有限[2]。

病理生理学涉及正常皮肤稳态的破坏，使共生葡萄球菌能够侵入更深的表皮和毛囊结构。当正常屏障功能因潜在疾病受损时，这些微生物增殖并增强炎症反应，导致特征性的临床表现[7]。

抗菌素耐药性的出现是一个关键的流行病学问题。耐甲氧西林菌株通过mecA基因机制进化，产生对β-内酰胺类亲和力降低的青霉素结合蛋白[1][4]。这种耐药性发展发生在任何抗生素暴露情况下，对细菌的生存和适应产生选择性压力[7]。

### Sources
[1] Managing superficial pyoderma with light therapy: https://www.dvm360.com/view/managing-superficial-pyoderma-with-light-therapy
[2] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Antibiotic Selection in Pyoderma: https://www.dvm360.com/view/antibiotic-selection-in-pyoderma
[4] When topical treatment for pyoderma fails: https://www.dvm360.com/view/when-topical-treatment-for-pyoderma-fails
[5] The epidemiology of antimicrobial resistance and ...: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0557.xml

## 临床症状和体征

浅表性细菌性毛囊炎通常表现为多灶性脱毛、毛囊性丘疹或脓疱、表皮领状物和影响躯干和腹部的结痂(1)。标志性病变包括含有多根毛干的小脓疱，这有助于将该病与其他脓疱性疾病区分开来(1)。短毛品种可能因多个浅表性毛囊丘疹而呈现独特的"虫蛀状"外观(7)。

瘙痒程度从轻微到剧烈不等，取决于潜在原因。该病通常影响温暖潮湿的部位，如腋窝区域、趾间背侧空间和皮肤褶皱(6)。一些品种特异性表现包括可卡犬的增生性斑块，这可能被误诊为脂溢性病变(7)。

鉴别诊断包括蠕形螨病、皮肤真菌病和落叶型天疱疮(7)。必须通过深度皮肤刮片或毛发检查排除蠕形螨病，而皮肤真菌病需要进行真菌培养检查(1)。落叶型天疱疮可通过脓疱中存在棘层松解的角质形成细胞来鉴别(8)。

诊断方法包括脓疱内容的细胞学检查，显示非变性中性粒细胞和球菌细菌(1)。细菌培养和药敏测试对于复发性病例或怀疑耐甲氧西林感染的情况至关重要(6)。最有用的测试包括用于识别蠕形螨的毛发检查和印片细胞学评估(4)。

### Sources
[1] Diagnosis of Skin Diseases in Small Animals: https://www.merckvetmanual.com/en-au/integumentary-system/integumentary-system-introduction/diagnosis-of-skin-diseases-in-animals
[4] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs
[6] Pyoderma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[7] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[8] Canine and feline pemphigus foliaceus: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome

## 治疗策略和抗菌素耐药性

浅表性细菌性毛囊炎的治疗需要一种平衡疗效与抗菌素管理原则的战略方法。局部治疗是局部和浅表感染的首选一线治疗方法[1][2]。

**局部治疗方案**
每周两次应用2-4%氯己定洗发水，其疗效与全身性阿莫西林-克拉维酸治疗泛发性病变相当[4]。1-2分钟的接触时间证明与传统10-15分钟方案同样有效[4]。对于局灶性病变，每日两次应用氯己定喷雾、湿巾或泡沫可提供靶向抗菌活性[2]。

**全身性抗菌素选择**
当需要全身治疗时，基于最低抑菌浓度（MIC）和临界值的一线抗生素指导选择[5]。疗效比（临界值/MIC）决定最佳抗生素选择，较高的比率表明细菌易感性更强[5]。

**耐甲氧西林感染**
耐甲氧西林假中间型葡萄球菌（MRSP）和MRSA需要谨慎选择抗生素[6]。对于复发性或无反应性病例，培养和药敏测试变得至关重要[5]。在红霉素耐药菌株中应避免使用克林霉素，因为存在诱导性耐药机制[5]。

**治疗持续时间指南**
浅表性细菌性毛囊炎需要至少治疗3周或临床痊愈后1周，以时间较长者为准[7][5]。这一持续时间考虑了21天的皮肤更新周期，确保细菌完全清除[4]。

**预防措施**
成功管理需要解决潜在疾病，如过敏、内分泌疾病或免疫抑制[5]。定期使用抗菌洗发水可预防易感患者的复发，每月应用2-4次进行维持治疗[2]。

### Sources
[1] Antimicrobial susceptibility testing reporting style: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.25.01.0045.pdf
[2] Topical therapies in veterinary dermatology: https://www.dvm360.com/view/topical-therapies-in-veterinary-dermatology
[3] Topical therapy for canine pyoderma: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0001.xml
[4] Time for topicals: https://www.dvm360.com/view/time-for-topicals-a-spot-on-guide-to-treating-dermatologic-diseases
[5] Antibiotic Selection in Pyoderma: https://www.dvm360.com/view/antibiotic-selection-in-pyoderma
[6] Nationwide analysis of methicillin-resistant staphylococci: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.24.09.0253/ajvr.24.09.0253.pdf
[7] Questioning the duration of systemic antimicrobial therapy: https://avmajournals.avma.org/view/journals/javma/260/10/javma.22.03.0113.xml

## 预后和临床结局

现有章节内容提供了关于浅表性细菌性毛囊炎预后的优秀全面信息。根据原始资料，我可以综合额外的临床见解来加强本节内容。

犬猫的浅表性细菌性毛囊炎在正确诊断和治疗的情况下通常具有极好的预后[2]。对于无并发症的病例，在适当的全身性抗生素治疗下通常在3-4周内完全痊愈，而更复杂的感染可能需要延长治疗至6周[1][2]。最新证据表明，单独局部治疗对浅表性脓皮病有效，新指南推荐将局部治疗作为许多病例的一线疗法[3]。

几个因素影响预后和恢复结果。免疫系统受损、患有过敏性皮炎或内分泌疾病的犬猫可能经历较长的愈合时间和较高的复发率。患者完全遵循抗生素疗程至关重要，因为过早停药经常导致治疗失败和细菌耐药性发展[2][6]。

复发率根据潜在易感因素差异很大。由跳蚤侵染或接触过敏引起的继发性病例在解决主要原因后复发率较低。然而，患有特应性皮炎或脂溢性疾病的患者如果不适当管理基础疾病过程，可能会经历反复发作[2][6]。

未经治疗的浅表性细菌性毛囊炎的并发症包括进展为更深层的脓皮病、毛囊炎和蜂窝织炎。抗生素耐药性感染带来日益增加的治疗挑战，多重耐药生物需要培养指导的治疗和延长的治疗方案[1][2]。长期管理策略侧重于识别和控制易感因素，保持适当的皮肤卫生，并实施适当的局部治疗以预防复发[2][3]。

### Sources
[1] Questioning the duration of systemic antimicrobial therapy for superficial pyoderma: https://avmajournals.avma.org/view/journals/javma/260/10/javma.22.03.0113.xml
[2] Pyoderma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[3] Topical treatments for pyoderma - dvm360: https://www.dvm360.com/view/topical-treatments-for-pyoderma
[4] Topical therapy for canine pyoderma: what is new?: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0001.xml
[5] Pyoderma in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/pyoderma-in-cats
[6] Why didn't that antibiotic treatment work? Overview of bacterial skin disease: https://www.dvm360.com/view/why-didnt-antibiotic-treatment-work-overview-bacterial-skin-disease-proceedings
