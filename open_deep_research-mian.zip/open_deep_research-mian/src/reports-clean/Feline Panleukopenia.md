# 猫泛白细胞减少症：综合兽医指南

猫泛白细胞减少症是影响家猫的最严重且具有历史意义的病毒性疾病之一。这种高度传染性的细小病毒感染继续对全球未接种疫苗的猫群构成重大威胁，特别是在收容所和多猫环境中的幼猫。尽管通过疫苗接种完全可以预防，但由于其毁灭性的临床病程和一旦出现临床症状后的不良预后，猫泛白细胞减少症在现代兽医实践中仍然具有重要意义。

本报告全面探讨了猫泛白细胞减少症的各个方面，从其病毒病因和环境持久性到临床表现、诊断方法和治疗方案。重点关注的领域包括特征性的严重白细胞减少症（住院病例存活率仅为20-51%）、基于证据的支持性护理策略、通过疫苗接种方案进行的全面预防，以及兽医在临床实践中管理疑似病例时必须考虑的关键鉴别诊断。

## 疾病概述

猫泛白细胞减少症是由猫细小病毒（FPV）引起的高度传染性病毒性疾病，也称为猫泛白细胞减少症病毒[1]。这种单链DNA病毒属于细小病毒科，与犬细小病毒密切相关，具有抗原相似性，可提供交叉保护[2]。FPV是已知最古老的猫病毒性疾病之一，仍然是全球未接种疫苗猫群的重大威胁[3]。

从流行病学角度看，猫泛白细胞减少症主要影响2-6个月龄的年轻未接种疫苗的猫，但任何年龄缺乏保护性免疫力的猫仍然易感[4]。该病毒表现出显著的环境持久性，在受污染环境中可存活数月至数年，使得完全根除具有挑战性[5]。传播通过与受感染猫或受污染物体的直接接触发生，粪-口途径是主要的传播方式[4]。

收容所、猫舍和繁殖设施等多猫环境由于接触机会增加和应激引起的免疫抑制而经历更高的患病率[4]。该疾病在某些地区表现出季节性模式，在繁殖活动增加的温暖月份发病率较高[1]。母源抗体在生命的前几周为幼猫提供临时保护，但这种免疫力在8-12周龄时减弱，创造了一个关键的易感窗口期[6]。

### Sources
[1] Canine parovirus and feline panluekopenia: New ideas for prevention, risk assessment, and treatment (parts 1 & 2) (Proceedings): https://www.dvm360.com/view/canine-parovirus-and-feline-panluekopenia-new-ideas-prevention-risk-assessment-and-treatment-parts-1
[2] Vaccination of Exotic Mammals: https://www.merckvetmanual.com/exotic-and-laboratory-animals/vaccination-of-exotic-mammals/vaccination-of-exotic-mammals
[3] Vaccines and vaccination: Issues and controversies (Part 2) (Proceedings): https://www.dvm360.com/view/vaccines-and-vaccination-issues-and-controversies-part-2-proceedings
[4] Managing and preventing feline febrile diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings
[5] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[6] Vaccine-Associated Feline Sarcoma Task Force: Roundtable Discussion: https://avmajournals.avma.org/view/journals/javma/226/11/javma.2005.226.1821.pdf

## 病因学和发病机制

**致病因子**

猫泛白细胞减少症由猫细小病毒（FPV）引起，这是一种单链无包膜DNA病毒，与犬细小病毒2型（CPV-2）密切相关[1]。FPV被认为是已知最古老的猫病毒性疾病之一，早于20世纪70年代末CPV的出现[2]。目前流行的CPV毒株（CPV-2a、-2b和-2c）也可在家猫中引起具有临床意义的疾病，尽管FPV仍然是全球猫病毒性肠炎的主要原因[1]。

**病毒特性和病理生理学**

作为无包膜病毒，细小病毒对环境灭活具有高度抵抗力，在有利条件下可存活数月至数年[1]。FPV需要宿主细胞机制进行复制，特异性靶向骨髓、淋巴组织和肠道上皮中的活跃分裂细胞[1]。这种对快速分裂细胞的趋向性解释了特征性的临床表现，包括严重的白细胞减少症、淋巴细胞减少症和胃肠道症状。

**传播和靶组织**

猫通过接触受感染动物、其分泌物和受污染物体而经口鼻感染[1]。潜伏期通常为2-7天，但在某些情况下可能延长至14天[1]。在怀孕母猫中，经胎盘感染可导致胚胎吸收、胎儿木乃伊化以及存活幼猫的小脑发育不全[1]。

### Sources

[1] Feline Panleukopenia - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia

[2] Canine parovirus and feline panluekopenia: New ideas for prevention, risk assessment, and treatment: https://www.dvm360.com/view/canine-parovirus-and-feline-panluekopenia-new-ideas-prevention-risk-assessment-and-treatment-parts-1

## 临床表现和诊断方法

猫泛白细胞减少症表现出随年龄组而异的不同临床模式。超急性病例在幼猫中常见，突然死亡可能是第一个临床症状[1]。急性病例通常表现为高热（40-41.7°C）、深度抑郁、导致休克的严重脱水和完全厌食[1]。呕吐通常为胆汁性且与进食无关，在发热开始后1-2天出现[1]。

与犬细小病毒性肠炎不同，猫泛白细胞减少症并不总是出现腹泻，且出现时通常不带血[1]。体格检查显示深度抑郁、脱水和有时腹部不适，触诊可能诱发立即呕吐，并显示增厚的肠袢和肿大的肠系膜淋巴结[1]。

诊断测试结合临床评估和实验室方法。细小病毒ELISA检测呕吐物、粪便或直肠拭子中的FPV抗原，灵敏度为50-80%[1]。对于抗原检测，呕吐物可能比直肠拭子更可靠[1]。强和弱颜色变化都应视为阳性，而有症状幼猫的阴性结果需要确认测试[1]。

PCR测试提供增强的诊断能力。实时PCR与传统PCR相比提供更高的灵敏度和特异性，结果更快速且具有基于计算机的检测系统[2]。这些分子分析可以高分析灵敏度检测遗传物质，但需要仔细解释关于近期疫苗接种或亚临床感染的情况[2]。

全血细胞计数结果具有特征性，显示特征性的严重中性粒细胞减少症和淋巴细胞减少症，总白细胞计数通常低于2,000个/mcL[1]。中性粒细胞减少症在淋巴细胞减少症之前发展，计数低于2,000个/mcL表明预后不良[1]。血小板减少症可能发生在进展为弥散性血管内凝血的猫中，而恢复的猫可能显示反弹性中性粒细胞增多症伴显著左移[1]。

### Sources

[1] Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia
[2] Molecular diagnostics: understanding assays for infectious diseases (Proceedings): https://www.dvm360.com/view/molecular-diagnostics-understanding-assays-infectious-diseases-proceedings

## 治疗方案

猫泛白细胞减少症治疗主要依靠强化支持性护理，因为没有特定的抗病毒疗法。成功的管理需要积极的液体治疗作为治疗基础[1]。静脉平衡等渗晶体溶液如乳酸林格氏液配合计算的钾补充对处于休克状态的猫和幼猫至关重要[2]。

止吐治疗提供重要的患者缓解并使早期肠内喂养成为可能。马罗匹坦（1 mg/kg，皮下或静脉注射，每24小时）由于其安全性和有效性是首选止吐药[2]。对于严重受影响的猫，昂丹司琼可与马罗匹坦联合使用[2]。

广谱抗菌治疗适用于所有有症状的猫，以对抗胃肠道细菌移位。选择抗菌药物时，厌氧菌和革兰氏阴性需氧菌是最重要的目标[2]。增效青霉素联合氟喹诺酮类或第三代头孢菌素是常用药物[2]。

电解质紊乱、低血糖、低蛋白血症和贫血经常发生，需要及时干预[2]。新鲜冷冻血浆输注可支持胶体渗透压并提供凝血因子[2]。早期少量多次喂养促进胃肠道黏膜愈合[2]。一旦呕吐得到控制，应开始使用广谱驱虫药，因为肠道寄生虫感染常使FPV复杂化[2]。

### Sources
[1] Merck Veterinary Manual Feline Panleukopenia - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-panleukopenia
[2] Merck Veterinary Manual Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia

## 预防和控制策略

猫泛白细胞减少症预防主要依靠全面的疫苗接种方案和有效的环境管理[1]。核心疫苗接种建议包括在6-9周龄开始使用改良活病毒（MLV）疫苗，每3-4周加强一次，直到16-20周龄，然后根据风险评估每年或每3年接种一次[1][2]。

母源抗体干扰显著影响幼猫疫苗接种成功。在高风险收容所环境中首选MLV疫苗，因为它们提供快速保护并且可以克服一些母源抗体，而灭活病毒疫苗推荐用于怀孕母猫以防止胎儿感染[1]。疫苗接种方案的目标应该是为更多猫群接种疫苗，同时减少个体接种频率，选择基于个体风险评估[2]。

环境消毒需要特定方案，因为FPV对常用消毒剂具有高度抵抗力。有效消毒剂包括1:32稀释的家庭漂白剂10分钟，1:100稀释的过氧单硫酸钾，或1:16稀释的加速过氧化氢5分钟[1]。尽管标签声称有效，但季铵盐产品无效[1]。

收容所疫情管理需要立即采取种群控制措施，包括停止接收、严格的生物安全协议和对所有暴露动物进行积极疫苗接种。在疫情情况下，应在接收时立即接种MLV疫苗，并在动物留在设施期间每2周加强一次[1]。即使不完全的免疫反应也可能提高存活率。

### Sources
[1] Merck Veterinary Manual Feline Panleukopenia: https://www.merckvetmanual.com/infectious-diseases/feline-panleukopenia/feline-panleukopenia
[2] Current vaccine controversies (Proceedings): https://www.dvm360.com/view/current-vaccine-controversies-proceedings

## 鉴别诊断和预后

### 鉴别诊断

猫泛白细胞减少症的主要鉴别诊断包括沙门氏菌病、猫传染性腹膜炎、弓形虫病、败血症和严重胃肠道寄生虫感染[1]。对于患有临床FPV感染的已接种疫苗成年猫，应调查猫白血病病毒的合并感染，因为FPV感染在并发病毒或寄生虫疾病时变得更加严重[1]。由于FPV的高死亡率，社区猫疫情可能被误认为集体中毒[1]。

### 预后和存活率

**急性泛白细胞减少症猫的预后不良**[1]。对于接受支持性治疗的住院猫，据报道存活率仅为20-51%[1]。这些比率不包括治疗前发生的超急性死亡。相比之下，犬细小病毒性肠炎的存活率高达90%[1]。

### 预后因素

不良预后指标包括低温、低体重、严重白细胞减少症（特别是<2,000个/mcL）、血小板减少症、低蛋白血症和低钾血症[1]。积极预后指标包括白细胞反弹和食欲恢复[1]。住院后的中位生存时间约为三天[1]。

### 长期后遗症

围产期感染的幼猫可能发展出小脑发育不全，这是由于病毒在关键新生儿发育期间破坏快速分裂的小脑细胞所致[1][2]。这导致终生持续的不协调、震颤和共济失调[1][2]。这种情况发生在感染在小脑细胞快速分裂的出生前后期间破坏小脑组织时[1][2]。

### Sources

[1] Feline Panleukopenia - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia
[2] Feline Panleukopenia - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-panleukopenia
