# 犬猫肠套叠：一种兽医急症

肠套叠是伴侣动物中一种严重的胃肠道急症，特征是一段肠管套入另一段肠管，形成危及生命的肠梗阻。这种情况主要影响一岁以下的幼犬和幼猫，德国牧羊犬表现出特别的品种易感性。大多数病例发生在回盲结肠交界处，如果不及时识别和治疗，可能迅速从部分梗阻发展为完全血管损害、组织坏死和潜在穿孔。

本综合报告探讨了肠套叠的多方面性质，从67%病例的特发性原因到包括细小病毒和内寄生虫感染的寄生虫和感染性触发因素。分析涵盖了利用超声特征性"靶征"的关键诊断方法，包括手动复位与切除吻合术的手术管理策略，以及影响适当管理时术后14天94%存活率的预后因素。

## 疾病概述

肠套叠是一种胃肠道急症，定义为一段肠管套入相邻肠段，产生类似可折叠望远镜的套叠效应[1]。当蠕动收缩将近端肠段（套入部）拉入远端肠段（套鞘部）时，就会发生这种情况，导致机械性肠梗阻[2]。

解剖机制涉及正常蠕动的紊乱，通常由"导引点"触发，如肠肿块、异物或作为局灶牵引点的解剖异常[2]。**胃肠道梗阻最常见的管腔外原因是肠套叠**，这可能是继发于内寄生虫感染、细小病毒感染、异物摄入或肿瘤，但通常是特发性的[6]。肠套叠最常见于回盲结肠交界处[6]。

从流行病学角度看，肠套叠表现出显著的年龄易感性，最常见于幼犬和幼猫（<1岁）[1][6]。德国牧羊犬表现出特别的品种易感性，可能易患胃食管套叠[5][6]。雄性受影响的频率是雌性的2-4倍[4]。这种情况需要立即兽医干预，因为长时间的肠套叠如果不治疗会导致肠缺血、坏死、穿孔和潜在的致命并发症[2]。

### Sources

[1] Diagnosis and management of GI motility disorders: https://www.dvm360.com/view/diagnosis-and-management-of-gi-motility-disorders
[2] Intussusception (medical disorder) - Wikipedia: https://en.wikipedia.org/wiki/Intussusception_(medical_disorder)
[3] Intussusception: What It Is, Symptoms, Diagnosis & Treatment: https://my.clevelandclinic.org/health/diseases/10793-intussusception
[4] Intussusception: Definition, Symptoms, Treatment, and More: https://www.verywellhealth.com/intussusception-4800911
[5] Acute-on-chronic vomiting in a German shepherd: https://www.dvm360.com/view/challenging-case-acute-chronic-vomiting-german-shepherd
[6] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals

## 病因学和病理生理学

犬猫的肠套叠可能继发于各种潜在原因或特发性发生。常见的易感因素包括慢性内寄生虫感染，如蛔虫、钩虫和鞭虫[1][3]、细小病毒感染[2]、异物摄入以及老年动物的肿瘤[2]。然而，大多数病例（约67%）是特发性的，没有可识别的潜在原因[2]。

慢性寄生虫感染代表了一个重要的易感因素，特别是在幼年动物中。蛔虫（犬弓蛔虫）、钩虫（犬钩口线虫）和鞭虫（犬鞭虫）可导致肠道蠕动增加和炎症，可能引发肠套叠[1][3]。此外，像泡翼线虫属这样的胃蠕虫可能导致胃肠道刺激和改变的蠕动模式[2]。

病理生理过程始于一段肠管（套入部）套入相邻肠段（套鞘部），最常见于回盲结肠交界处[2]。这造成了机械性梗阻，如果不治疗会从部分发展为完全性梗阻[2]。

随着病情进展，静脉回流受损而动脉血流最初保持通畅，导致受影响肠段的充血和血液供应受损[2]。进行性扩张和血管损害导致粘膜损伤、组织坏死，如果不及时处理可能发生穿孔[2]。受损的肠道屏障可能允许细菌移位和内毒素吸收，可能导致败血性并发症[2]。

### Sources
[1] Intussusception calls for exploratory laparotomy: https://www.dvm360.com/view/intussusception-calls-exploratory-laparotomy
[2] MSD Veterinary Manual Gastrointestinal Obstruction in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[3] Gastrointestinal Parasites of Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs

## 临床表现和诊断

犬猫肠套叠的临床表现因位置和持续时间而异。肠套叠通常引起腹痛、呕吐和腹泻，伴有或不伴有血便[2]。幼犬最常受影响，特别是那些一岁以下的[2]。临床症状从急性严重症状到慢性间歇性表现不等，有些病例显示周期性模式[1,3]。

体格检查可能发现腹部膨大或鼓音、腹痛，偶尔可触及肠肿块[2]。在严重病例中可能出现低血容量性休克的迹象，包括脉搏微弱、心动过速和粘膜苍白[2]。

诊断影像学检查对确认诊断至关重要。普通X线片可能显示梗阻近端有液体和气体的肠管扩张，尽管发现不具有特异性[2,5]。腹部超声对诊断肠套叠高度准确，在横断面上显示特征性的"靶征"或"环征"[2,6,9]。这由代表肠套入肠管配置的同心圆高回声和低回声环组成[6]。套入的肠系膜脂肪在中心内产生额外的回声结构[6]。

实验室检查发现包括白细胞增多伴轻度左移、低氯血症、代谢性碱中毒和可能的高乳酸血症[2,5]。这些变化反映了继发于梗阻的液体流失和电解质失衡。

### Sources
[1] Diagnosis and management of acute and chronic vomiting in dogs and cats: https://www.dvm360.com/view/diagnosis-and-management-acute-and-chronic-vomiting-dogs-and-cats-proceedings
[2] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[3] Diagnostic strategy for vomiting in dogs and cats: https://www.dvm360.com/view/diagnostic-strategy-vomiting-dogs-and-cats-proceedings
[4] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[5] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[6] Ultrasound of the gastrointestinal tract: https://www.dvm360.com/view/ultrasound-gastrointestinal-tract-proceedings
[7] Ultrasonographic Signs of Intestinal Intussusception: https://meridian.allenpress.com/jaaha/article/39/1/57/176373/Ultrasonographic-Signs-of-Intestinal
[8] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/248/4/javma.248.4.373.xml
[9] Intussusception calls for exploratory laparotomy: https://www.dvm360.com/view/intussusception-calls-exploratory-laparotomy
[10] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/259/10/javma.19.10.0489.xml

## 治疗选择

手术干预仍然是犬猫肠套叠管理的金标准。当套叠肠段看起来有活力时，首先尝试手动复位，涉及轻柔牵引以恢复正常解剖位置[1]。然而，如果组织显示坏死、血管丧失或穿孔迹象，则需要切除吻合术[1]。

手术方法决策标准包括通过评估动脉搏动、组织颜色、测试切口血液特征、壁质地和蠕动来评估肠道活力[1]。动脉搏动的存在是组织活力最可靠的指标[1]。

手术技术包括外露和隔离受影响肠段、结扎肠系膜血管，并使用3-0或4-0合成可吸收缝线进行全层吻合[1]。可同时进行肠固定术，通过在相邻肠袢之间形成控制性粘连来防止复发[1]。这种技术涉及在肠系膜对侧边缘附近放置多个缝线，以纳入每个肠袢的粘膜下层[1]。

围手术期护理包括使用大量温热等渗溶液进行术中腹腔灌洗以去除污染物并温暖患者[1]。术后管理侧重于液体治疗、疼痛控制和必要时抗生素给药[2]。在恢复期间监测吻合口裂开、腹膜炎或复发等并发症至关重要。

### Sources
[1] Intestinal surgery (part 2) (Proceedings): https://www.dvm360.com/view/intestinal-surgery-part-2-proceedings
[2] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 鉴别诊断

由于临床表现重叠，特别是胃肠道症状和腹痛，必须将几种关键疾病与肠套叠区分开来。异物梗阻是最常见的鉴别诊断，特别是在幼猫和大型犬中，引起类似的呕吐和厌食模式[1]。

肠道肿瘤，包括淋巴瘤和腺癌，可产生相同的临床症状，当肿块较小或症状间歇性时可能特别具有挑战性[2]。炎症性肠病表现为慢性呕吐和腹泻，通常需要组织病理学检查以明确区分与肠套叠相关的炎症[3]。

其他肠梗阻原因包括粘连、狭窄和肠扭转，在影像学和临床上可模拟肠套叠[1]。猫的线性异物产生特征性的肠折叠，必须使用影像学技术与肠套叠区分[4]。

其他鉴别诊断包括蛋白丢失性肠病，可引起伴有低白蛋白血症的类似胃肠道症状，以及各种导致继发性胃肠道功能障碍的全身性疾病[5]。胃动力障碍和慢性胃炎可能呈现类似肠套叠发作的间歇性呕吐模式[6]。

仔细的影像学评估，特别是超声显示特征性的"靶征"或"甜甜圈征"，有助于将肠套叠与其他肠梗阻原因区分开来，并指导适当的手术干预。

### Sources

[1] MSD Veterinary Manual Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals

[2] DVM 360 Difficult canine vomiting cases: https://www.dvm360.com/view/difficult-canine-vomiting-cases-proceedings

[3] DVM 360 Inflammatory bowel disease: https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings

[4] DVM 360 Diagnostic imaging for linear foreign bodies in cats: https://www.dvm360.com/view/diagnostic-imaging-linear-foreign-bodies-cats

[5] DVM 360 Care of dogs with protein-losing enteropathy: https://www.dvm360.com/view/care-dogs-with-protein-losing-enteropathy-proceedings

[6] DVM 360 Diagnosis and management of acute and chronic vomiting: https://www.dvm360.com/view/diagnosis-and-management-acute-and-chronic-vomiting-dogs-and-cats-proceedings
