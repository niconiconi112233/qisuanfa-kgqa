# 伴侣动物动脉血栓栓塞

动脉血栓栓塞（ATE）是小动物临床中最具破坏性的心血管急症之一，尤其影响患有潜在心脏病的猫。本综合报告探讨了犬猫ATE的病理生理学、临床表现和管理策略。虽然ATE主要被视为猫肥厚型心肌病的并发症，但其独特的诊断和治疗挑战显著影响患者预后。该报告综合了当前关于紧急稳定方案、抗血小板治疗进展（包括氯吡格雷和利伐沙班）以及不断发展的治疗方法，这些方法已将生存率从历史上低于35%的基线提高到现代管理策略下更为乐观的结果。

## 摘要

动脉血栓栓塞是一种关键的心血管急症，主要影响患有心脏病的猫，特别是肥厚型心肌病。该病症表现出明显的物种偏好性，与犬相比，猫具有独特的易感性，这反映了心血管解剖学和疾病进展模式的基本差异。

当前证据显示，通过精细的管理方法，结果有了适度但有意义的改善。保守治疗达到35-39%的出院生存率，新型抗血小板药物显示出更优的疗效。与阿司匹林的6.8个月相比，氯吡格雷将中位生存期延长至一年以上，而利伐沙班在二级预防中显示出同等的保护效益。

| 管理策略 | 生存率 | 中位生存时间 |
|---------------------|---------------|---------------------|
| 保守治疗 | 35-39% | 117-345天 |
| 氯吡格雷治疗 | 相似的出院率 | >365天 |
| 溶栓治疗 | 43% | 相比保守治疗无改善 |

预后仍然谨慎，但随着循证抗凝方案和支持性护理的改进已有所改善。未来研究应关注高危患者的早期识别策略和更有效溶栓方法的开发，以进一步改善这一挑战性病症的结果。

## 疾病概述

动脉血栓栓塞（ATE）是一种潜在破坏性的心血管并发症，其特征是血栓形成，通常在心脏左心房，然后脱落并通过动脉循环移动，直到卡在无法通过的过小血管中[1]。这种情况代表小动物医学中的主要急症，影响猫的程度远大于犬。

ATE主要发生在患有潜在心脏病的猫中，特别是肥厚型心肌病（HCM），超过90%的猫科病例中可发现心脏病[1][6]。该病症影响12-28%的HCM猫和27%未分类心肌病猫[1]。雄性猫比雌性猫更常受影响[1]。在犬中，主动脉血栓极为罕见，仅占住院病例的0.0005%[4]。

病理生理学涉及Virchow三联征：血液淤滞（特别是在扩张的左心房中）、高凝状态（在心脏病猫中有记录）和内皮损伤[1][7]。随着左心房扩张，血流速度降低，导致红细胞聚集，在超声心动图上可见自发性回声对比或"烟雾"[1]。大多数血栓（约90%）卡在主动脉三分叉处，导致双侧后肢瘫痪[1][6]。

### Sources

[1] How to handle feline aortic thromboembolism: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism
[2] Feline aortic thromboembolism with and without congestive: https://avmajournals.avma.org/view/journals/ajvr/85/8/ajvr.24.03.0065.xml
[3] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[4] Aortic thrombosis in dogs: 31 cases (2000-2010) in: https://avmajournals.avma.org/view/journals/javma/241/7/javma.241.7.910.xml
[5] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[6] Merck Veterinary Manual Arterial Thromboembolism in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/arterial-thromboembolism-in-dogs-and-cats
[7] Merck Veterinary Manual Thrombosis, Embolism, and Aneurysm in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/thrombosis-embolism-and-aneurysm/thrombosis-embolism-and-aneurysm-in-animals
[8] Merck Veterinary Manual Pathologic Thrombosis in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/pathologic-thrombosis-in-animals
[9] Merck Veterinary Manual Pulmonary Thromboembolism in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pulmonary-thromboembolism-in-dogs-and-cats

## 病因学和临床表现

伴侣动物的动脉血栓栓塞主要源于潜在的心脏病，特别是心肌病[1]。在猫中，肥厚型心肌病（HCM）是主要原因，影响高达七分之一的猫，并经常进展为全身性血栓栓塞[1]。高达15%的猫受HCM影响，缅因猫和布偶猫表现出遗传易感性[2]。血栓形成最常见于严重扩大的左心房，由于血流淤滞，左心耳是血栓形成的主要部位[1]。

其他潜在病因包括肿瘤、蛋白丢失性肾病和肠病、免疫介导性溶血性贫血、败血症以及胰腺炎等全身性炎症性疾病[8]。甲状腺功能亢进和肢端肥大症等继发性心脏肥大原因也可能易导致血栓事件[4]。与通常涉及特定病原体的传染病不同，动脉血栓栓塞主要是潜在心血管或全身性疾病的继发并发症，而非原发性感染过程。

**临床表现**因血栓位置而异，但通常包括当影响末端主动脉时出现急性后肢瘫痪/轻瘫，股动脉搏动消失[1]。猫表现为典型的"5P"征：无脉、苍白、体温异常（四肢冰冷）、疼痛和腓肠肌僵硬[1]。一些猫可能只有单侧肢体受累或经历影响其他动脉分支的血栓。

**物种差异**显著，与犬相比，猫具有独特的易感性[1]。猫科患者可能表现出非特异性体征，包括嗜睡和食欲减退，而约50%没有可检测到的心脏杂音，使诊断具有挑战性[4]。

### Sources
[1] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Veterinary Medicine Essentials: Congestive heart failure: https://www.dvm360.com/view/veterinary-medicine-essentials-congestive-heart-failure
[3] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[4] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

## 诊断方法和鉴别诊断

动脉血栓栓塞的诊断主要基于临床检查结果和支持性诊断测试。体格检查揭示特征性体征，包括股动脉搏动消失、无脉肢体、脚垫苍白或紫色变色、体温异常（四肢冰冷）和腓肠肌僵硬[1]。受影响的猫通常表现为急性后肢轻瘫或瘫痪，最初伴有极度疼痛[1]。

受影响肢体的多普勒血流研究有助于确认血管闭塞，而超声检查可以识别末端主动脉中的血栓栓子[1]。然而，未成熟的栓子可能相对呈低回声，与成熟血栓相比难以可视化[4]。后肢与中心循环之间的差异葡萄糖和乳酸测量可支持诊断，受影响肢体葡萄糖显著降低和乳酸升高[2]。

实验室发现包括肌肉坏死导致的血清肌酸激酶和AST升高，再灌注后可能出现危及生命的高钾血症和酸中毒[2]。超声心动图识别潜在心脏病和可能的心内血栓[2]。胸部X线片可能在超过50%的病例中显示充血性心力衰竭证据[4]。

关键鉴别诊断包括神经系统疾病，这些疾病在猫中常被误诊为动脉血栓栓塞[1]。对于有呼吸道症状、X线片正常但临床恶化的猫，应考虑肺血栓栓塞[3]。其他鉴别诊断包括创伤、脊髓疾病和导致急性后肢无力的代谢性疾病。

### Sources
[1] Merck Veterinary Manual Arterial Thromboembolism in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/arterial-thromboembolism-in-dogs-and-cats
[2] Merck Veterinary Manual Thrombosis, Embolism, and Aneurysm in Animals: https://www.merckvetmanual.com/circulatory-system/thrombosis,-embolism,-and-aneurysm/thrombosis,-embolism,-and-aneurysm-in-animals
[3] Merck Veterinary Manual Pulmonary Thromboembolism in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pulmonary-thromboembolism-in-dogs-and-cats
[4] DVM 360 Aortic thromboembolism in cats: https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings

## 治疗策略和预防措施

### 急性管理方案

初始管理侧重于在特定抗血栓治疗前进行稳定。使用阿片类药物如氢吗啡酮（0.1-0.2 mg/kg静脉注射，每4-6小时）或丁丙诺啡（0.01-0.03 mg/kg，每6-8小时）进行疼痛控制至关重要[1]。如果存在充血性心力衰竭，必须用氧疗和呋塞米治疗。应谨慎给予液体治疗以维持灌注，同时避免心脏病患者过载[1,2]。

### 药物干预

**抗凝剂**：肝素仍然是标准的急性抗凝剂，以250-300 U/kg皮下注射，每6小时一次，通过aPTT监测（目标1.5-1.7×基线）[1]。低分子量肝素如依诺肝素（0.75-1 mg/kg皮下注射，每6-12小时）或达肝素（75 U/kg皮下注射，每6小时）提供替代抗凝[1]。

**溶栓剂**：组织纤溶酶原激活剂和链激酶已被研究，但未显示生存获益，并存在显著的出血并发症和高钾血症风险。当前证据不支持其常规使用[1,2]。

### 手术选择

使用支架取栓装置的机械血栓切除术已在急性主动脉血栓栓塞的犬中有报道[5]。然而，与允许血栓栓塞自然溶解的保守管理相比，传统手术切除、溶栓剂给药和流变溶栓术在很大程度上未取得成功[6]。

### 长期管理和预防

**一级预防**：基于FATCAT研究证明显著延长生存时间（>365天 vs 阿司匹林的192天），目前推荐氯吡格雷（18.75 mg/猫，每日口服）而非阿司匹林用于动脉血栓栓塞风险猫[1,4,7]。利伐沙班（2.5 mg/猫，每日口服）在SUPERCAT研究中显示出与氯吡格雷相当的二级预防效果[4]。

保守治疗导致约35-39%的出院生存率，生存者的中位生存时间为117-345天[3]。

### Sources

[1] Thrombosis, Embolism, and Aneurysm in Animals: https://www.merckvetmanual.com/circulatory-system/thrombosis-embolism-and-aneurysm/thrombosis-embolism-and-aneurysm-in-animals

[2] Aortic thromboembolism in cats (Proceedings): https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings

[3] How to handle feline aortic thromboembolism: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism

[4] the SUPERCAT study in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0584.xml

[5] Mechanical Thrombectomy of Acute Aortic Thromboembolism Using ...: https://meridian.allenpress.com/jaaha/article/61/3/61/506758/Mechanical-Thrombectomy-of-Acute-Aortic

[6] Arterial Thromboembolism in Dogs and Cats - Circulatory ...: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/arterial-thromboembolism-in-dogs-and-cats

[7] How much protection does clopidogrel provide to cats with ...: https://avmajournals.avma.org/view/journals/javma/262/10/javma.24.04.0269.xml

## 预后和结果

动脉血栓栓塞猫的预后仍然谨慎，大型回顾性研究显示住院生存率为33-39%[1][2]。保守治疗产生约37-39%的生存率，而溶栓治疗和血栓切除术显示相似的结果，无显著改善[1][2]。

对于存活初次发作的猫，中位生存时间根据二级预防治疗而有显著差异。接受阿司匹林单药治疗的猫中位生存期为6.8个月（范围2.9个月），而接受华法林治疗的猫生存11.4个月（中位数9个月）[2]。然而，华法林带来显著风险，12.5%的猫死于出血并发症[2]。

最近的研究显示新型抗血小板药物改善了结果。接受氯吡格雷治疗的猫显示ATE复发的中位时间为443-663天，远长于历史阿司匹林治疗（192天）[2][4]。默克兽医手册确认溶栓治疗反应率与保守治疗相似，43%的猫存活组织纤溶酶原激活剂治疗[5]。

在犬中，预后似乎更有利，中位生存时间更长。研究表明，慢性发作的动脉血栓犬的中位生存时间（30天；范围0-959天）显著长于急性发作[1]。最新数据显示所有犬的总生存时间为356天，根据潜在病理学有所不同[1]。

### Sources

[1] Aortic thromboembolism in cats (Proceedings): https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings-0
[2] Aortic thromboembolism in cats (Proceedings): https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings
[3] Thromboembolic disease (Proceedings): https://www.dvm360.com/view/thromboembolic-disease-proceedings
[4] the SUPERCAT study in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0584.xml
[5] Thrombosis, Embolism, and Aneurysm in Animals: https://www.merckvetmanual.com/circulatory-system/thrombosis-embolism-and-aneurysm/thrombosis-embolism-and-aneurysm-in-animals
