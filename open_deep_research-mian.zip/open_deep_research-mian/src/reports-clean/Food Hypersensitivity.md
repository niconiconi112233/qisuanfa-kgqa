# 伴侣动物的食物超敏反应

食物超敏反应在小动物兽医临床实践中代表着一个重要的临床挑战，影响约1-2%的犬和不到1%的猫，但在患有皮肤病表现的动物中比例要高得多。与传染性疾病不同，这种非致病性状况是由对膳食蛋白质的异常免疫反应引起的，需要系统性的诊断方法来与其他过敏性疾病相鉴别。本综述全面探讨了临床表现模式、诊断方案和基于证据的管理策略，这些对于成功治疗受影响的犬和猫至关重要。

## 疾病概述

伴侣动物的食物超敏反应被定义为对通常无害的食物蛋白质或糖蛋白的异常免疫介导反应[1]。这种情况包括真正的食物过敏（涉及免疫系统激活）和食物不耐受（非免疫介导反应）[1]。食物超敏反应是兽医皮肤病学和胃肠病学中的重要鉴别诊断，在确诊前需要系统性地排除其他瘙痒性疾病[2]。

食物超敏反应的真实患病率仍然未知，但根据就诊人群的不同而有显著差异[2]。最近的系统评价显示，在所有就诊接受常规兽医护理的犬中，患病率约为1-2%，在猫中不到1%[2]。然而，在有特定临床表现的动物中，患病率大幅增加：0-24%患有皮炎的犬、9-40%患有瘙痒的犬以及3-6%患有皮炎的猫表现出食物反应性疾病[1][2]。

发病年龄差异很大，这与环境过敏原引起的特应性皮炎形成对比[2]。虽然大多数病例在1-4岁之间发病，但犬的发病年龄范围可从小于6个月到13岁，猫的发病年龄范围可从4个月到15岁[2]。某些品种表现出易感性，包括德国牧羊犬、拉布拉多寻回犬、法国斗牛犬和西部高地白梗[2]。在两个物种中都没有明显的性别偏好[2]。

### Sources
[1] Prevalence of Cutaneous Adverse Food Reactions in Dogs and Cats: https://www.dvm360.com/view/prevalence-of-cutaneous-adverse-food-reactions-in-dogs-and-cats
[2] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals

## 常见病原体

食物超敏反应与传染性疾病根本不同，因为它是一种非传染性疾病，不涉及病毒、细菌或寄生虫等传统病原体[1]。相反，这种情况是由对膳食抗原的异常免疫反应引起的，这些抗原是引发超敏反应的特定食物成分[2]。

食物超敏反应代表了对膳食蛋白质或其他食物成分的I型、III型或IV型超敏反应[3]。这种情况是免疫介导的，需要事先对致敏过敏原产生致敏作用，这将其与缺乏免疫学成分的食物不耐受区分开来[1]。

犬中最常见的食物过敏原包括牛肉、鸡肉、奶制品、小麦、大豆、玉米和羊肉[4][5]。在猫中，主要的膳食抗原是鸡肉、鱼和奶制品[6]。这些蛋白质的分子量通常在10-70 kDa之间，并且通常是耐热的、水溶性的糖蛋白[7]。相关蛋白质之间可能发生交叉反应，例如鸡肉和火鸡之间或牛肉和鹿肉之间，这是由于它们共享分子结构[8]。

### Sources
[1] Food hypersensitivity in dogs and cats: Elimination veterinary diet trial pitfalls: https://www.dvm360.com/view/food-hypersensitivity-dogs-and-cats-elimination-veterinary-diet-trial-pitfalls
[2] Dermatologic manifestations and nutritional management of adverse food reactions: https://www.dvm360.com/view/dermatologic-manifestations-and-nutritional-management-adverse-food-reactions
[3] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings
[4] Food hypersensitivity in the dog and cat: now what do I feed? (Proceedings): https://www.dvm360.com/view/food-hypersensitivity-dog-and-cat-now-what-do-i-feed-proceedings
[5] Foiling food allergy frustrations in dogs and cats: https://www.dvm360.com/view/foiling-food-allergy-frustrations-dogs-and-cats
[6] Now what do I feed? Identifying food hypersensitivity in dogs and cats: https://www.dvm360.com/view/now-what-do-i-feed-identifying-food-hypersensitivity-dogs-and-cats
[7] Your food allergy questions answered: https://www.dvm360.com/view/your-food-allergy-questions-answered
[8] Identifying food allergies: The veterinary elimination diet trial: https://www.dvm360.com/view/identifying-food-allergies-veterinary-elimination-diet-trial

## 临床症状和体征

**皮肤表现**

食物超敏反应在犬和猫中最常见的皮肤临床症状是瘙痒[2]。在犬中，瘙痒可以是全身性或局灶性/多灶性的，通常影响耳廓、足部、腹部，较少影响肛周/生殖器周围皮肤[2]。分布区域常涉及与特应性皮炎相似的区域，包括口鼻部、眼周区域、腋窝、腹股沟以及掌面或跖面趾间皮肤[8]。临床症状包括持续性瘙痒和过度舔舐，导致皮肤红肿和发炎[1]。

在猫中，标志性症状是面部和头部的剧烈瘙痒，特别是眼外眦与耳廓基部之间的耳前区域[2][6]。猫的其他表现包括自发性脱毛、粟粒状皮炎以及嗜酸性肉芽肿复合体的表现[8]。

**其他临床症状**

继发性并发症在两个物种中都很常见。犬经常发展为复发性外耳道炎（56-80%的病例）以及葡萄球菌属或马拉色菌引起的继发感染[2][8]。其他表现包括荨麻疹、复发性脓皮病、皮脂溢和嗜酸性血管炎[3][4]。近一半的食物过敏患者伴有胃肠道症状，如呕吐、腹泻、胀气或排便频率增加[3][8]。

**时间模式**

临床症状通常是非季节性的，但可能因间歇性膳食摄入而呈发作性[3][4]。瘙痒的严重程度可能与犬疥螨引起的瘙痒相当[2]。

### Sources
[1] Food hypersensitivity in dogs and cats: Elimination ...: https://www.dvm360.com/view/food-hypersensitivity-dogs-and-cats-elimination-veterinary-diet-trial-pitfalls
[2] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[3] Diagnosing food allergies in dogs and catsBring your case ...: https://www.dvm360.com/view/diagnosing-food-allergies-dogs-and-cats-bring-your-case-trial
[4] Food hypersensitivity in the dog and cat now what do I feed ...: https://www.dvm360.com/view/food-hypersensitivity-dog-and-cat-now-what-do-i-feed-proceedings-0
[5] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings
[6] Dermatologic manifestations and nutritional management ...: https://www.dvm360.com/view/dermatologic-manifestations-and-nutritional-management-adverse-food-reactions

## 诊断方法

食物超敏反应的诊断主要依靠临床表现评估和正确进行的排除性饮食试验[1]。诊断的金标准是排除性饮食试验，需要严格遵循新型蛋白质或水解蛋白饮食8-12周[2]。在开始饮食试验之前，必须排除寄生虫和继发性皮肤感染[2]。

血液检测和其他实验室方法在食物过敏诊断方面存在显著局限性。针对食物过敏原的血清IgE检测可靠性差，假阳性和假阴性结果常见[3]。这些检测测量IgE水平，但不能区分致敏和临床相关的过敏[4]。皮内试验不评估食物过敏，不适合这种情况[3][5]。

正确的排除性饮食方案包括选择动物从未食用过的新型蛋白质，限制所有其他食物和零食，并维持试验至少6-10周[1][6]。大多数出现改善的猫在3周内表现出显著反应，但完整评估需要整个试验期[1]。成功排除后，用原始食物进行饮食激发试验，通过重现临床症状来确认诊断[4]。可能需要使用不同蛋白质进行多次试验，因为非处方食品通常含有未列出的蛋白质，可能干扰准确诊断[3][5]。

### Sources
[1] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[2] VMX 2020-Tips and tricks for managing feline allergies: https://www.dvm360.com/view/vmx-2020-tips-and-tricks-for-managing-feline-allergies/1000
[3] The CSI approach to pruritic pets: an overview and flowchart: https://www.dvm360.com/view/csi-approach-pruritic-pets-overview-and-flowchart-proceedings
[4] Foiling food allergy frustrations in dogs and cats: https://www.dvm360.com/view/foiling-food-allergy-frustrations-dogs-and-cats
[5] Diagnosing food allergies in dogs and cats: https://www.dvm360.com/view/diagnosing-food-allergies-dogs-and-cats-bring-your-case-trial
[6] Seven tips for optimizing an elimination diet trial: https://www.dvm360.com/view/seven-tips-for-optimizing-an-elimination-diet-trial

## 治疗选择

犬和猫的食物超敏反应治疗涉及多模式方法，结合药物干预、饮食管理和长期营养规划[1][2][3]。主要治疗目标是在建立安全、长期喂养策略的同时控制急性症状。

**药物干预**用于急性症状管理，包括皮质类固醇作为主要治疗方法，快速缓解瘙痒和炎症[3][4]。免疫抑制替代药物如环孢素（Atopica）以平均25毫克/天的剂量在猫中提供有效控制，而奥拉替尼（Apoquel）可以超标签使用，剂量为1-2毫克/公斤，每日两次[4]。抗组胺药如氯苯那敏（每只猫2-4毫克，每8-24小时一次）提供辅助支持，尽管疗效各异[3][5]。

**饮食管理**代表确定性治疗方法。使用兔肉、袋鼠肉或鱼类等原料的新型蛋白质饮食提供患者先前未接触过的蛋白质[6]。水解蛋白饮食通过将蛋白质分解成小于10 kDa的片段提供替代选择，使其致敏性降低[6][8][9]。这些饮食消除了识别特定新型蛋白质的需要，并降低了长期喂养期间产生新过敏的可能性[8]。

**继发感染管理**至关重要，因为细菌和马拉色菌感染通常会使食物超敏反应病例复杂化[10]。应在监测基础过敏反应的同时，给予适当疗程的抗菌治疗。

**长期营养考虑**包括确保长期喂养期间的饮食平衡，特别是对需要适合生长配方的幼年动物[9]。成功通过排除性饮食管理的患者可以无限期继续这些饮食，或进行控制性激发试验以扩大饮食选择，同时维持症状控制[10]。

### Sources
[1] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals
[2] Allergies of Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/allergies-of-cats
[3] Management of the pruritic cat: Topical and systemic: https://www.dvm360.com/view/management-pruritic-cat-topical-and-systemic-proceedings
[4] VMX 2020-Tips and tricks for managing feline allergies: https://www.dvm360.com/view/vmx-2020-tips-and-tricks-for-managing-feline-allergies
[5] "Wheal of Fortune": Approaching and managing the allergic patient: https://www.dvm360.com/view/wheal-fortune-approaching-and-managing-allergic-patient-proceedings
[6] Food hypersensitivities: Performing an elimination diet trial: https://www.dvm360.com/view/food-hypersensitivities-performing-elimination-diet-trial
[7] Food allergy in dogs and cats; current perspectives on: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0548.xml
[8] Hydrolyzed protein diets: https://www.dvm360.com/view/when-pieces-are-better-whole-hydrolyzed-protein-diets-sponsored-nestl-purina
[9] Your food allergy questions answered: https://www.dvm360.com/view/your-food-allergy-questions-answered
[10] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals

## 预防措施

目前，犬和猫的食物超敏反应没有特定的疫苗，因此管理策略集中在环境控制和饮食管理上[1,2]。预防的重点是仔细的饮食管理和环境调整，以减少过敏原暴露并最大限度地降低交叉污染风险。

交叉污染在排除性饮食期间构成重大挑战[2]。许多非处方"新型蛋白质"食品含有未列出的蛋白质--研究发现四分之三的鹿肉食品含有未申报的大豆、牛肉或鸡肉[2]。来自信誉良好制造商的处方食品具有严格的质量控制，仍然是首选，以防止无意中接触过敏原。

环境控制措施包括在试验期间消除所有食物类物品，包括生皮咀嚼物、调味药物和零食[2,4]。调味的心丝虫预防药物通常含有牛肉、猪肉或大豆蛋白质，无论标签如何[4]。家庭方案应防止接触其他宠物的食物和共用水碗，以避免交叉污染[2,4]。

对于易感品种，包括拉布拉多寻回犬、德国牧羊犬和西部高地白梗[4]，早期饮食管理可能有益。长期给易感患者喂食水解蛋白饮食可能会降低产生新致敏的风险[5]。对饲主进行有关正确喂养方案和识别早期临床症状的教育，能够及时干预并防止过敏反应的进展。

### Sources

[1] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings-0
[2] Food hypersensitivity in the dog and cat now what do I feed?: https://www.dvm360.com/view/food-hypersensitivity-dog-and-cat-now-what-do-i-feed-proceedings-0
[3] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[4] Cutaneous Food Allergy in Animals: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[5] Hydrolyzed protein diets: https://www.dvm360.com/view/when-pieces-are-better-whole-hydrolyzed-protein-diets-sponsored-nestl-purina

## 鉴别诊断

食物超敏反应必须与其他表现为类似瘙痒症状的过敏性和炎症性皮肤病相鉴别。主要的鉴别诊断包括特应性皮炎、跳蚤过敏性皮炎、疥螨病、接触性皮炎以及细菌/真菌皮肤感染[1][2]。

**特应性皮炎**是主要的鉴别诊断，影响环境过敏原而非膳食成分。两种情况都表现为剧烈瘙痒，但特应性皮炎通常显示季节性模式并影响特定解剖部位，如面部、耳朵和足部。皮内皮肤测试有助于识别环境过敏原[1]。

**跳蚤过敏性皮炎**在犬中表现为背腰骶区、尾根和后大腿的丘疹结痂性病变，与食物超敏反应的更广泛分布形成对比。肉眼观察到跳蚤或跳蚤粪便支持这一诊断[2]。

**疥螨病**引起与食物过敏类似的剧烈瘙痒，但通常最初影响耳缘、肘部和腹部。皮肤刮片检查和对抗疥螨治疗的反应有助于区分这种寄生虫性疾病[2][3]。

**食物超敏反应的关键鉴别因素**包括非季节性瘙痒、50%病例对皮质类固醇反应不佳、20-30%患者伴有胃肠道症状以及特征性的"耳朵和臀部"表现[4]。对严格排除性饮食试验的反应仍然是金标准诊断测试，因为皮内测试和血清学检测对食物过敏不可靠[3]。

### Sources

[1] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings
[2] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[3] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[4] Diagnosing adverse food reactions in canine and feline patients: https://www.dvm360.com/view/diagnosing-adverse-food-reactions-in-canine-and-feline-patients

## 预后

当实施并维持适当的饮食管理时，患有食物超敏反应的犬和猫的预后极好[1]。大多数动物在适当的排除性饮食上4-6周内显示出显著改善，有些动物继续改善长达8-10周，特别是如果存在继发感染。

**长期结果**
严格遵守饮食限制，受影响的动物可以过上正常、舒适的生活而没有临床症状[1][2]。低过敏饮食可以终身喂食，或者主人可以选择通过控制性激发试验来识别特定过敏原以扩大饮食选择。大多数商业限制抗原和水解蛋白饮食为长期喂养提供全面营养。

**预后因素**
主人依从性是影响成功的最关键因素，依从性差是治疗失败的主要原因[2][5]。必须适当管理细菌或马拉色菌感染等继发并发症以获得最佳结果[2]。患有并发环境过敏的动物可能需要额外的管理，但仍能保持良好的生活质量。

**新致敏发展**
一旦确诊，对选定的排除性饮食产生新的食物致敏的情况很少见[2]。然而，这种情况可能很少发生，如果在成功管理后临床症状复发，应予以考虑。在这种情况下，转换为具有不同蛋白质和碳水化合物来源的替代饮食通常可以解决问题。

### Sources
[1] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals
[2] Allergies in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/allergies-in-dogs
[3] Common causes and signs of food intolerance in veterinary patients: https://www.dvm360.com/view/common-causes-and-signs-food-intolerance-veterinary-patients
[4] Adverse food reactions (Proceedings): https://www.dvm360.com/view/adverse-food-reactions-proceedings
[5] Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals
