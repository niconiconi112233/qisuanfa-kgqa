# 猫上呼吸道感染综合征

猫上呼吸道感染综合征（FURIS）是全球范围内最常见的猫呼吸道疾病，影响多猫环境中高达100%的猫。本综合报告探讨了导致该综合征的病毒和细菌病原体之间复杂的相互作用，包括猫疱疹病毒1型、猫杯状病毒和继发性细菌入侵者。通过对流行病学模式、临床表现和循证治疗方法的详细分析，本报告为兽医从业者提供了管理影响全球数百万只猫的急性感染和慢性携带状态的重要见解。

## 摘要

猫上呼吸道感染综合征是一种多因素疾病复合体，主要由病毒病原体FHV-1和FCV主导，占病例的80-90%。该综合征表现出明显的流行病学模式，在收容所环境中，感染率在一周内从4%增加到50%以上，而幼猫面临继发性细菌并发症的最高死亡风险。

临床管理需要针对特定病原体的方法，多西环素作为需要抗菌治疗病例的一线经验性治疗。预防策略集中在核心疫苗接种方案上，达到75%的有效率，减少环境压力，并使用1:32稀释的漂白剂溶液进行适当消毒，这对包膜和非包膜病毒都有效。

长期预后揭示了一个关键挑战：100%的FHV-1存活者成为慢性携带者并存在潜伏感染，而80%的FCV存活者发展为持续排毒模式。这种携带现象确保了猫群中持续的传播循环，需要持续的管理策略，专注于提高生活质量而非完全治愈。

有效的FURIS控制需要综合方法，结合疫苗接种、环境管理和根据个体患者表现和居住情况量身定制的支持性护理方案。

## 疾病概述与流行病学

猫上呼吸道感染综合征（FURIS）是一种高度流行的呼吸系统疾病，特征为鼻分泌物、结膜炎、眼部分泌物、鼻窦炎、呼吸困难、咳嗽、食欲不振和嗜睡[1]。它是猫临床上最常见的呼吸道疾病，也是全球猫群发病的主要原因[2]。

FURIS在不同人群中表现出显著的流行病学模式。在全球的多猫家庭和动物收容所中，传染性上呼吸道疾病是高危猫中最普遍的临床状况[3]。在多猫环境中发病率可达100%，但死亡主要集中在六个月以下有继发性细菌感染的幼猫中[3]。

个体病原体的流行率因地理区域和检测方法而异。80-90%的病例归因于病毒原因，主要是猫疱疹病毒1型（FHV-1）和猫杯状病毒（FCV）[4]。环境因素显著影响传播动态，收容所饲养使FHV-1排毒从入院时的4%在一周内增加到50%以上[5]。在收容所环境中的停留时间是发生上呼吸道感染（URI）的最大风险因素[6]。幼猫是严重疾病和死亡的最高风险人群，而成年猫通常经历较轻的临床过程并有较高的存活率。

### Sources
[1] Diagnosing and managing feline respiratory disease: https://www.dvm360.com/view/diagnosing-and-managing-feline-respiratory-disease-proceedings
[2] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[3] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[4] Feline infectious respiratory disease: https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[5] Controlling disease transmission in animal shelters: Part 1: https://www.dvm360.com/view/controlling-disease-transmission-animal-shelters-part-1-proceedings
[6] Managed intake and capacity for care: https://www.dvm360.com/view/managed-intake-and-capacity-care-tools-remarkable-population-management-parts-1-2-proceedings

我注意到现有部分内容已经全面涵盖了猫上呼吸道感染综合征的病因学和病理生理学。但是，我可以通过结合所提供来源的额外信息来增强这部分内容，特别是关于FHV-1眼部表现和疫苗接种考虑的内容。

## 病因学与病理生理学

猫上呼吸道感染综合征涉及多种病原体，它们通过不同但常常重叠的机制靶向上呼吸道。主要病毒病原体包括猫疱疹病毒1型（FHV-1）和猫杯状病毒（FCV），它们通过直接粘膜接触和呼吸道飞沫传播建立感染[2]。

FHV-1表现出嗜上皮特性，最初在鼻和结膜上皮中复制，然后在三叉神经节中建立潜伏状态。这种潜伏机制允许在压力或免疫抑制期间周期性再激活，导致反复的临床发作[4]。该病毒引起呼吸道上皮的溶细胞性破坏并损害粘膜纤毛清除机制。除呼吸道症状外，FHV-1通常表现为结膜炎和角膜炎，前葡萄膜炎偶尔被报告为眼部并发症[5]。

FCV表现出高遗传变异性以及对口腔和呼吸道组织的嗜性。与FHV-1不同，FCV不建立潜伏状态，而是引起急性上皮坏死和溃疡[2]。某些菌株表现出影响多个器官系统的全身毒力特性，毒力株杯状病毒（VS-FCV）需要特殊的疫苗接种考虑[6]。

继发性细菌入侵者包括猫衣原体和支原体属，它们利用病毒感染造成的受损上皮屏障[1]。猫衣原体通过细胞内复制特异性靶向结膜上皮，而支原体属缺乏细胞壁，使它们能够逃避某些抗菌治疗并建立慢性感染[3]。

病理生理学进展包括初始的病毒细胞病变，随后是炎症细胞浸润和局部免疫防御受损。这为细菌定植和继发性并发症创造了有利条件。环境压力源和免疫抑制条件，特别是在收容所或多猫环境中，显著影响疾病的严重程度和进展[2]。

### Sources
[1] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[2] Canine infectious respiratory disease complex: management and prevention in canine populations (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[3] Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings
[4] Living with FeLV-infected cats: A guide for veterinarians and their clients: https://www.dvm360.com/view/living-with-felv-infected-cats-guide-veterinarians-and-their-clients
[5] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[6] Current vaccine controversies (Proceedings): https://www.dvm360.com/view/current-vaccine-controversies-proceedings

## 临床表现与诊断

猫上呼吸道感染综合征的临床表现涉及多个器官系统，主要影响呼吸道、眼睛和口腔。初始表现包括体温达105°F（40.5°C）、频繁打喷嚏和从浆液性到粘液脓性的鼻分泌物[2]。伴有流泪的结膜炎、鼻炎、流涎和口腔溃疡是特征性体征，体温通常在正常到103°F（39°C）之间波动[2]。

在临床评估期间出现病原体特异性模式。FHV-1感染主要影响结膜和鼻腔通道，常引起溃疡性角膜炎、流泪和睑痉挛[2]。杯状病毒主要靶向口腔粘膜和下呼吸道，表现为舌头和硬腭溃疡，而某些菌株引起幼猫交替性跛行的短暂"跛行综合征"[2]。猫衣原体特征性地产生结膜炎，呼吸系统体征很少[2]。

诊断方法最初依赖于临床表现，包括打喷嚏、结膜炎、鼻炎和口腔病变的典型体征[2]。实验室诊断包括口咽、鼻腔或结膜样本的PCR检测，但由于间歇性排毒以及健康猫和患病猫中相似的病毒分离率，FHV-1的诊断可能具有挑战性[2]。吉姆萨染色的结膜刮片细胞学检查有助于识别衣原体和支原体生物[2]。

鉴别诊断必须排除慢性疾病，如真菌感染、肿瘤形成、鼻咽息肉和牙科疾病，特别是对于有持续性鼻分泌物的猫[7]。诊断工作流程可能需要颅骨X光检查、带活检的鼻镜检查和麻醉下的牙科检查，以排除可治疗的基础疾病[7]。

### Sources
[1] A retrospective analysis of canine, feline, and equine upper respiratory samples: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.11.0755.xml
[2] Feline Respiratory Disease Complex - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[3] Feline upper respiratory syndrome (Proceedings) - DVM360: https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[4] Upper respiratory tract disease in cats (Proceedings) - DVM360: https://www.dvm360.com/view/upper-respiratory-tract-disease-cats-proceedings
[5] Managing and preventing feline respiratory diseases (Proceedings) - DVM360: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[6] How are you managing chronic rhinosinusitis? - DVM360: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[7] Collaboration with the clinical microbiology laboratory - AVMA Journal: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml

## 治疗与管理

猫上呼吸道感染的治疗侧重于支持性护理和基于疾病持续时间和严重程度的靶向抗菌治疗[1]。对于急性疾病（≤10天），不建议常规使用抗菌治疗，除非猫表现出发热、嗜睡或伴有粘液脓性鼻分泌物的厌食[1]。

当需要抗菌治疗时，多西环素作为一线经验性治疗，剂量为5 mg/kg口服每12小时一次或10 mg/kg每日一次，持续7-10天，因为它对常见的猫呼吸道病原体具有广谱活性[1]。当不怀疑衣原体或支原体感染时，阿莫西林（每12小时22 mg/kg）提供替代选择[1]。对于慢性疾病（>10天），建议根据培养和敏感性试验指导的延长抗菌治疗[1]。

支持性护理仍然至关重要，包括维持水合作用、环境加湿和确保充足的营养[3]。当猫出现呼吸困难、发绀或张口呼吸迹象时，应提供氧气补充[2]。对于病毒感染，L-赖氨酸（每日两次250-500 mg）可能通过干扰病毒复制帮助管理FHV-1感染[2][7]。泛昔洛韦以40-90 mg/kg每8-12小时的剂量为严重的疱疹病毒病例提供抗病毒治疗[7]。

猫呼吸道感染的治疗需要仔细的支持性管理，因为如果涉及继发性细菌感染，广谱抗生素是有用的[8]。慢性细菌性鼻炎的管理需要数周的延长治疗，因为可能发展为软骨炎和骨髓炎[5]。阿奇霉素以5 mg/kg每24-72小时的剂量已被证明对管理慢性病例的临床症状有效[2]。

### Sources
[1] What are the best practices for antibiotic use in feline upper respiratory tract disease: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease
[2] Initially treating fading puppies and kittens: https://www.dvm360.com/view/initially-treating-fading-puppies-and-kittens
[3] Optimal veterinary care for feline trauma patients: https://www.dvm360.com/view/optimal-veterinary-care-feline-trauma-patients
[5] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[7] WVC 2017: Managing Cats with Upper Respiratory Infection - Viral Causes: https://www.dvm360.com/view/wvc-2017-managing-cats-with-upper-respiratory-infection--viral-causes
[8] feline calicivirus - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus

## 预防与控制策略

疫苗接种是猫上呼吸道感染预防的基石。含有猫疱疹病毒1型（FHV-1）和猫杯状病毒（FCV）的核心疫苗应在6-8周龄时开始接种，每3-4周加强一次直到16周龄，然后每年再次接种[1]。改良活疫苗比灭活疫苗提供更快速的保护，鼻内制剂在3-5天内提供免疫力，而胃肠外疫苗需要5-7天[2]。然而，FHV-1/FCV疫苗的有效率约为75%，提供对疾病严重程度的保护而非完全预防感染[3]。

环境管理对疾病控制至关重要。压力减轻显著影响疱疹病毒再激活，需要提供隐藏处的舒适住房、最小化处理和减少噪音暴露[2]。必须避免过度拥挤，因为它增加传播风险和压力水平。适当的通风和笼子级别的空气质量是必不可少的，多侧开放的住房比封闭单元提供更好的被动通风[2]。停留时间应最小化，因为它与感染风险直接相关[4]。

有效消毒需要针对不同病原体的特定方案。FHV-1在环境中很脆弱，在潮湿条件下仅存活18小时，而FCV在干燥分泌物中可持续存在长达4周[1]。1:32稀释的家庭漂白剂、过一硫酸钾和加速过氧化氢能有效灭活这些病原体，而季铵化合物对非包膜病毒不可靠[2][4]。

在多猫环境和收容所中，博德特氏菌疫苗接种应主要考虑用于有确诊爆发的高风险情况而非常规使用[3]。针对猫衣原体的疫苗应保留给有地方性流行病的高风险环境[1]。

### Sources

[1] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Feline infectious respiratory disease (Proceedings): https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[3] Feline vaccine update (Proceedings): https://www.dvm360.com/view/feline-vaccine-update-proceedings
[4] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings

## 预后与长期结果

猫上呼吸道感染综合征的预后因猫是发展为急性还是慢性疾病而有显著差异。大多数患有急性URI的猫通过支持性护理恢复良好，因为死亡主要见于六个月以下有继发性细菌感染的幼猫[1]。

然而，长期前景涉及慢性携带状态。100%从急性FHV-1感染恢复的幼猫成为慢性携带者，而约80%从急性FCV感染存活的猫发展为携带者状态[1]。FCV携带者从口咽部持续排毒，而FHV-1携带者有潜伏感染，在压力触发下间歇性排毒[1]。约25%临床健康的种猫和10%健康的家庭猫是FCV携带者[1]。

生活质量考虑包括在存在时管理慢性体征。这些可能表现为阵发性打喷嚏伴有粘液脓性鼻分泌物，对抗生素暂时有反应但在停止治疗后几天内复发[1]。某些猫发展为口炎、慢性牙龈炎和伴有过早牙齿脱落的牙周病[1]。

对于患有慢性鼻炎的猫，重要的是客户理解这些患者永远不会被完全治愈[5]。然而，通过持续管理，包括适当的抗菌药物、抗炎药和支持性护理，患者的生活质量可以显著改善，打喷嚏和鼻分泌物减少[5]。

### Sources

[1] Feline viral upper respiratory disease: why it persists!: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[5] Snots and snuffles: chronic feline upper respiratory syndromes: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
