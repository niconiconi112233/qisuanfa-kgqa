# 伴侣动物耳部血肿

耳部血肿是小动物兽医实践中的一种重要临床疾病，其特征是耳廓软骨与皮肤之间血液积聚。这种情况主要影响犬和猫，通常继发于外耳炎、过敏性疾病或寄生虫感染等因素导致的过度摇头或抓挠创伤。其病理生理学涉及耳廓软骨内血管破裂，形成特征性的液性肿胀，需要及时的兽医干预。

本综述全面探讨了耳部血肿管理的多方面内容，包括聚己内酯夹板应用等现代外科技术、微创引流程序和保守性皮质类固醇治疗。报告分析了近期兽医研究的治疗效果数据，探讨了侧重于基础疾病管理的预防策略，并评估了影响犬猫患者长期预后的预后因素。

## 摘要

伴侣动物耳部血肿需要全面的治疗方法，既要处理即时血肿，也要解决潜在致病因素。现代外科技术，特别是聚己内酯夹板应用，与传统方法相比显示出更优的结果和更低的复发率。使用皮质类固醇灌注的保守管理取得约50%的成功率，而当与原发性耳部疾病的适当管理相结合时，外科干预显示出良好的预后。

| 治疗方法 | 成功率 | 主要优势 | 局限性 |
|-------------------|--------------|---------------|-------------|
| PCL夹板手术 | 高效 | 并发症少，无需缝合 | 需要特殊材料 |
| 传统手术 | 不定（67-71%） | 技术成熟 | 复发风险较高 |
| 保守治疗 | ~50% | 非侵入性 | 效果有限 |

通过定期耳部检查、及时治疗外耳炎和管理过敏性疾病进行预防仍然至关重要。该疾病的整体良好预后关键在于识别和解决潜在的耳部病理，因为未能处理原发性原因会显著增加复发风险。兽医从业者应强调全面的耳部疾病管理，而不是孤立治疗血肿，以确保受影响患者的最佳长期结果。

## 疾病概述

耳部血肿定义为耳廓（耳瓣）软骨与皮肤之间的血液聚集[1]。当摇头导致耳瓣内血管破裂时发生，造成血液部分或完全性肿胀[1]。该病症源于与瘙痒相关的摇头或耳部抓挠相关的创伤，确切发病机制仍不清楚[2]。

这种情况在犬中比猫更常见[1]。在一项53个病例的回顾性研究中，犬的平均年龄为7.6岁，猫为5岁[3]。常见的犬种包括16只混种犬、10只德国牧羊犬和3只法国斗牛犬，而大多数猫是家养短毛猫[3]。雄性动物更常受影响，31只雄性犬对比17只雌性犬，3只雄性猫对比2只雌性猫[3]。

该病症经常与潜在的耳部疾病相关，特别是外耳炎，在一项研究中23只犬和3只猫被诊断出此病[3]。并发皮肤病也在11只犬和1只猫中被发现[3]。耳瓣通常感觉波动且充满液体，类似水气球[1]。

### Sources

[1] VIN Aural Hematoma in Dogs and Cats: https://www.vin.com/apputil/project/defaultadv1.aspx?pId=17256&SAId=1&catId=93555&id=4951446&ind=429&objTypeID=1007

[2] Merck Veterinary Manual Auricular Hematomas in Dogs, Cats, and Pigs: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs

[3] VIN Management of Aural Hematoma with Penrose Drainage: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=20539&catId=113409&id=8506165&ind=259&objTypeID=17

## 病因学和发病机制

耳部血肿通过涉及创伤和潜在易感条件的复杂病理生理过程发展[1]。主要机制涉及耳廓凹侧皮肤与软骨分离，导致血管破裂、出血和随后的血肿形成[2]。这种分离通常继发于潜在耳部病理引发的剧烈摇头和抓挠行为。

由外耳炎、寄生虫或过敏性疾病引起的摇头会造成重复性创伤，破坏耳廓软骨内的血管[2]。发病机制尚未完全了解，提出的理论包括直接创伤、过敏性疾病、体外寄生虫感染和血管脆性增加[3]。确切的病理生理机制涉及由瘙痒引起的摇头或耳部抓挠造成的创伤，这几乎总是涉及其中[5]。

在犬中，这种情况常见于特应性皮炎和食物过敏，其中耳道是过敏性炎症、瘙痒和继发感染的主要部位[5]。潜在疾病如外耳炎、耳螨、食物过敏和特应性皮炎作为主要诱发因素，触发导致血肿形成的自伤行为。

由此产生的出血性液体在耳廓的皮肤和软骨层之间积聚，形成特征性的液性肿胀[1]。尽管血肿发展的确切原因仍不清楚，但与瘙痒性耳部疾病和头部创伤的一致关联表明涉及耳廓组织内重复性血管损伤的机械性病因[4]。

### Sources

[1] 51 dogs with 71 aural hematomas (2000-2017): https://avmajournals.avma.org/view/journals/javma/260/S1/javma.20.12.0672.xml
[2] Clinical features, treatment, and outcome of aural hematomas: https://avmajournals.avma.org/view/journals/javma/258/6/javma.258.6.654.xml
[3] Disorders of the Outer Ear in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/ear-disorders-of-cats/disorders-of-the-outer-ear-in-cats
[4] Auricular Hematomas in Dogs, Cats, and Pigs: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs

## 临床表现和诊断

耳部血肿表现为耳软骨层间的波动性液性肿胀，最常影响耳廓的凹侧（内侧）表面[1]。肿胀通常急性发展，并可能因重量导致耳朵下垂[1]。发病机制涉及由瘙痒引起的摇头或耳部抓挠造成的创伤，特应性皮炎和食物过敏是犬中常见的潜在原因[3]。

体格检查显示特征性的柔软、波动性肿块，可触诊并可透照[1]。最近的研究将表现分为全身性或局部性血肿，全身性形式影响耳廓较大区域[2]。摇头、耳部抓挠和潜在的外耳炎是经常观察到的并发情况[1]。

诊断确认包括针吸穿刺，产生含有血液和血清的血性浆液性液体[1]。细胞学检查通常显示红细胞、炎症细胞和蛋白质[1]。对于简单病例，很少需要先进影像学检查，但当怀疑有中耳炎等并发情况时可能需要进行[1]。

该病症必须与其他耳部肿胀区分，包括脓肿、肿瘤或炎性息肉。在猫中，息肉表现为光滑、粉色、肉质、有蒂的肿块，需要组织学检查进行明确诊断[3]。

### Sources
[1] Clinical features, treatment, and outcome of aural hematomas: https://avmajournals.avma.org/view/journals/javma/258/6/javma.258.6.654.xml
[2] Successful surgical management of aural hematoma with the polycaprolactone splint: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.09.0571.xml
[3] Auricular Hematomas in Dogs, Cats, and Pigs: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs

## 治疗方法

耳部血肿的治疗包括外科、微创和保守方法[2]。主要目标是引流和防止液体重新积聚，同时保持耳朵美观。

**外科技术**包括传统切口引流和褥式缝合以消除血肿"囊腔"[2]。使用聚己内酯（PCL）夹板应用的新方法已在犬和猫中显示出成功，提供压缩而无需广泛缝合[1]。外侧放置的真空引流提供另一种外科选择，利用耳廓凸面的小切口定位引流系统[6]。

**微创选择**专注于引流技术。蝶形连接或静脉导管提供有效的引流通道[2]。使用真空引流的主动引流系统可通过最小切口定位，而被动引流依靠重力辅助液体排出[6]。使用耳形硅胶垫和锁定夹的商业系统无需缝合或包扎即可提供均匀压缩[5]。

**保守治疗**涉及引流结合糖皮质激素灌注，取得约50%的成功率[2]。腔内充满皮质类固醇而不引起皮肤扩张。通常伴随抗炎剂量的短期口服糖皮质激素治疗。

**护理**需要监测引流输出量并在适用时维持适当的包扎管理。解决潜在的瘙痒状况对预防复发至关重要[2]。

### Sources
[1] Journal of the American Veterinary Medical Association - Successful surgical management of aural hematoma with the application of polycaprolactone splint: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.09.0571/javma.24.09.0571.xml
[2] Merck Veterinary Manual - Auricular Hematomas: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs
[3] Dvm360 - Hematoma repair starter kit: http://marketplace.dvm360.com/product/hematoma-repair-starter-kit
[4] AVMA Journals - Use of laterally placed vacuum drains: https://avmajournals.avma.org/view/journals/javma/246/1/javma.246.1.112.xml

## 预防和鉴别诊断

### 预防措施

耳部血肿的预防侧重于识别和管理导致过度摇头和耳部创伤的潜在原因[1][2]。定期耳部检查和及时治疗外耳炎至关重要，因为耳部炎症引起的摇头是导致血肿形成的创伤主要原因[2]。

常规耳部清洁和维护有助于预防继发性细菌感染并减少炎症引起的瘙痒[3]。对过敏性疾病（包括特应性皮炎和食物过敏）的早期干预可防止慢性耳道炎症[2][3]。控制体外寄生虫，特别是耳螨（Otodectes cynotis），对防止引发血肿发展的剧烈抓挠和摇头至关重要[2][5]。

### 鉴别诊断

几种情况可能表现为类似的耳廓肿胀，必须与耳部血肿区分[2]。主要鉴别包括耳部肿瘤，通常表现为坚实、非波动性肿块，而血肿则为柔软的液性肿胀[2]。

耳部脓肿表现为脓性分泌物和感染的全身性体征，与血肿中的无菌血液收集形成对比[2]。伴有耳道狭窄的严重外耳炎可能导致耳廓肿胀，但保持耳朵的正常轮廓[3]。异物反应造成局部炎症，但缺乏特征性的波动性肿胀[2]。解决潜在原因对预防复发至关重要，因为成功引流血肿而不管理诱发的外耳炎很可能导致再形成[2]。

### Sources

[1] Successful surgical management of aural hematoma with the application of polycaprolactone splint in 7 dogs and 3 cats: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.09.0571/javma.24.09.0571.xml

[2] Auricular Hematomas in Dogs, Cats, and Pigs - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs

[3] Otitis Externa in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

[4] Otitis Media and Interna in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

[5] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis

## 预后

当正确识别和治疗耳部炎症的潜在原因时，犬猫耳部血肿的总体预后良好[1]。现代外科技术，包括PCL夹板应用，对局部性和全身性血肿以及初发和复发病例均显示出高效[2]。

**影响预后的因素：**
成功主要取决于解决诱发血肿的潜在耳部疾病。未能解决原发性耳部状况会显著增加复发风险。

**潜在并发症：**
虽然结果通常良好，但可能发生并发症。最近的研究显示复发率因治疗方法而异，外侧通道切口程序比其他外科方法显示出更高的复发率（33%）[3]。PCL夹板方法显示出较低的并发症，只有20%在术后早期经历复发[1]。

美容畸形，包括"菜花耳"形成，可能在耳软骨永久性增厚或变形时发展。一些外科干预具有更高的并发症率，先前报告的范围从29%到82%，可能包括面神经缺陷和轻瘫。

**长期管理：**
成功的长期结果需要通过适当的药物治疗、定期监测和主人遵守治疗方案来持续管理潜在的耳部状况。如果主要原因仍未解决，复发是可能的，这强调了全面的耳部疾病管理而非孤立治疗血肿的重要性。

### Sources
[1] Successful surgical management of aural hematoma with the: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.09.0571.xml
[2] Clinical features, treatment, and outcome of aural hematomas: https://avmajournals.avma.org/view/journals/javma/258/6/javma.258.6.654.xml
[3] 51 dogs with 71 aural hematomas (2000-2017) in: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.20.12.0672.xml
