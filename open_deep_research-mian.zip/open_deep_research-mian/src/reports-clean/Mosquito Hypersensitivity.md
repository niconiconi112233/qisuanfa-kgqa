# 伴侣动物蚊虫超敏反应

蚊虫超敏反应是小动物兽医实践中一种重要的过敏性皮肤病，主要影响有户外暴露史的猫，偶尔也会影响狗。这种对蚊唾液抗原的I型超敏反应在毛发稀疏区域（包括鼻梁、耳部和脚垫）造成炎症性皮肤病变。该疾病表现出与蚊虫活动和地理分布相关的明显季节性模式，使环境因素对诊断和管理都至关重要。本综合报告探讨了蚊虫超敏反应的发病机制、临床表现、诊断方法和治疗策略，强调了环境控制的重要性以及变应原特异性免疫疗法在长期管理这一具有挑战性的皮肤病方面的前景。

## 疾病概述

蚊虫超敏反应是一种影响小型伴侣动物的过敏性皮肤病，其特征是对蚊唾液抗原的炎症性皮肤反应[1][3]。这种情况代表一种I型超敏反应，蚊虫叮咬毛发稀疏区域，引发即时和延迟性炎症反应[3][6]。

该疾病表现出明显的物种偏好，主要影响有户外暴露史的猫，尽管狗也可能发展出超敏反应[1][3]。地理和季节变化影响疾病流行率，临床症状通常与不同地区的蚊虫活动模式相关[4][6]。

从流行病学角度看，蚊虫超敏反应在温带气候中季节性发生，但在蚊虫种群持续存在的较温暖地理区域可能全年出现[4][6]。该疾病影响任何年龄的动物，兽医文献中未报告特定的品种偏好[6]。支持蚊虫繁殖的环境因素，如积水源头和潮湿条件，增加了流行地区的疾病风险。

### Sources

[1] Nose-itis (Proceedings): https://www.dvm360.com/view/nose-itis-proceedings
[2] a retrospective study of 38 cases (1997-2022) in: https://avmajournals.avma.org/view/journals/javma/261/S2/javma.23.06.0312.xml
[3] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[4] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[5] Infectious skin disease in cats, more than you realized (Proceedings): https://www.dvm360.com/view/infectious-skin-disease-cats-more-you-realized-proceedings
[6] ACVC 2017: Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats

## 常见病原体

在伴侣动物的蚊虫超敏反应中，主要致病因子是蚊虫种类而非传统传染性病原体[1]。影响狗和猫的最具临床相关性的蚊虫属包括*伊蚊属*、*库蚊属*、*Psorophora属*、*按蚊属*和*Coquillettidia属*物种[2]。这些吸血节肢动物通过其唾液中存在的蛋白质成为超敏反应的媒介。

虽然蚊虫本身在传统意义上不是病原体，但它们可以携带继发性传染性病原体。蚊虫是已知的心丝虫（*Dirofilaria immitis*）和各种虫媒病毒的媒介，尽管这些与超敏综合征不同[2]。此外，*裂谷热病毒*已从多个属的30多种蚊虫中分离出来[4]。

继发性细菌和真菌病原体经常使蚊虫超敏反应复杂化。当原发性超敏反应为微生物过度生长创造有利条件时，*葡萄球菌属*和*马拉色菌属*生物通常引起继发性皮肤感染[3][7]。这些继发性感染往往加重临床表现，可能需要同时进行抗微生物治疗和管理潜在的超敏反应。

由蚊唾液蛋白引发的炎症反应可损害皮肤的屏障功能，使受影响的动物易受机会性细菌和真菌定植，从而将最初的过敏反应转变为更复杂的皮肤病。

### Sources

[1] Merck Veterinary Manual Flies and Mosquitoes of Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/flies-and-mosquitoes-of-dogs
[2] Mosquitoes of Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/flies/mosquitoes-of-animals
[3] Merck Veterinary Manual Insect Bite Dermatitis in Dogs, Cats, Horses, and Rabbits - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/insect-bite-dermatitis-in-dogs-cats-horses-and-rabbits
[4] Rift Valley fever virus in: Journal of the American ... - AVMA: https://avmajournals.avma.org/view/journals/javma/234/7/javma.234.7.883.xml
[7] Atopic Dermatitis in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals

## 临床症状和体征

狗和猫的蚊虫超敏反应表现出不同的临床症状[1]。特征性病变分布影响毛发稀疏区域，包括鼻镜、耳廓、面部、头部和脚垫[1][2]。

在猫中，蚊虫叮咬超敏反应通常表现为严重瘙痒、丘疹和结痂性皮疹，主要影响面部、耳朵、头部和脚垫[1][2]。初始叮咬在20分钟内发展为风团，随后在24小时内形成丘疹，约48小时内结痂[2]。患有慢性蚊虫超敏反应的猫会出现继发性病变，包括鳞屑、脱毛和色素变化[2]。

狗表现为影响面部和头部的嗜酸性粒细胞性毛囊炎，病变定位于毛发覆盖最少的区域[1]。主人经常报告观察到他们的狗被蚊虫或小昆虫包围，临床症状通常与昆虫孵化期重合[1]。

该疾病在许多地理区域表现出季节性模式，但这可能因当地蚊虫种群而异[1][2]。当动物被饲养在室内时，病变通常会消退，这支持了环境触发因素[1]。组织病理学检查显示受影响的猫出现高度嗜酸性粒细胞性皮炎，这是确诊的特征性表现[2]。

并非所有被蚊虫叮咬的动物都会发展出超敏反应，而变得超敏的猫通常会反复受到影响[2]。这种情况涉及对蚊唾液抗原的即时和晚期超敏反应[5]。

### Sources

[1] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis

[2] ACVC 2017: Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats

[3] VMX 2020-Tips and tricks for managing feline allergies: https://www.dvm360.com/view/vmx-2020-tips-and-tricks-for-managing-feline-allergies

[4] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis

[5] CVC Highlight: Getting to the bottom of feline facial dermatitis: https://www.dvm360.com/view/cvc-highlight-getting-bottom-feline-facial-dermatitis

## 诊断方法

诊断猫的蚊虫超敏反应需要一种系统方法，结合临床评估、实验室测试和组织病理学评估。临床表现作为主要诊断标准，特别是对于有户外暴露史、在毛发稀疏区域（包括鼻梁、耳廓和脚垫）出现特征性病变的猫[1]。

诊断过程始于识别病变的典型时间进展。初始蚊虫叮咬在20分钟内发展为风团，24小时内形成丘疹，约48小时内结痂[1]。慢性受影响的猫会出现继发性变化，包括鳞屑、脱毛和色素改变[1]。

组织病理学检查提供确诊证据，显示高度嗜酸性粒细胞性皮炎，这使蚊虫超敏反应与其他过敏性疾病区分开来[1]。皮肤细胞学显示显著的嗜酸性粒细胞浸润，支持反应的过敏性质[2]。

皮内过敏测试通常显示受影响的猫对多种昆虫的反应性，尽管这可能反映交叉反应性而非特定的蚊虫敏感性[2]。使用1:1000浓度的跳蚤过敏原测试可在超过75%的测试猫中提供即时风团和潮红反应，尽管这主要识别跳蚤敏感性[2]。

额外的诊断考虑包括排除鉴别诊断，如落叶型天疱疮或红斑狼疮，特别是在面部脱色素和瘢痕形成的病例中。全血细胞计数可能显示外周嗜酸性粒细胞增多，但这一发现对蚊虫超敏反应并不特异。

### Sources
[1] Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats
[2] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings

## 治疗选择

蚊虫超敏反应管理需要一种综合方法，结合药理学和非药理学干预措施[1,2]。变应原特异性免疫疗法（ASIT）代表最有前景的长期治疗选择，提供唯一可能治愈过敏性疾病或防止疾病进展的疗法[1,8]。ASIT涉及施用逐渐增加量的蚊虫抗原以减少未来的超敏反应[1]。皮下和舌下给药途径均可用于实施[3]。

皮质类固醇仍然是急性管理的主要治疗方法，在猫中优选泼尼松龙而非泼尼松，因为其转化为活性形式的效果更佳[2]。口服泼尼松龙剂量从2.2-4.4 mg/kg开始，分两次每日给药用于诱导，然后减少至0.5-2.2 mg/kg隔日一次用于维持[2]。

免疫抑制剂提供有价值的替代方案。环孢素（Atopica）提供有效控制，需要30-90天起效，初始剂量为5 mg/kg每日一次[2,7]。在猫中，每周两次给药对嗜酸性粒细胞肉芽肿复合体病变达到63%的疗效[7]。奥拉替尼（Apoquel）可在猫中标签外使用，剂量为1-2 mg/kg每日两次[7]。

环境控制仍然至关重要。含有氯菊酯的驱虫剂提供最有效的保护，每日低浓度应用（<1%）或每周高浓度处理（2%）[5]。在蚊虫活动高峰期（黎明和黄昏）将动物饲养在室内可显著减少暴露[5]。

### Sources

[1] Allergen-specific immunotherapy for canine atopic dermatitis: Making it work: https://www.dvm360.com/view/allergen-specific-immunotherapy-canine-atopic-dermatitis-making-it-work

[2] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings

[3] Another itchy cat, now what (Proceedings): https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings

[5] Insect bite allergy: Fleas, mosquitoes and Culicoides (Proceedings): https://www.dvm360.com/view/insect-bite-allergy-fleas-mosquitoes-and-culicoides-proceedings

[7] VMX 2020-Tips and tricks for managing feline allergies: https://www.dvm360.com/view/vmx-2020-tips-and-tricks-for-managing-feline-allergies

[8] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis

## 预防措施

环境控制策略对于减少易患超敏反应的猫和狗的蚊虫暴露至关重要。初级预防侧重于通过消除物业周围的积水源头（包括花盆托盘、雨水槽和装饰性水景）来减少繁殖地[1]。

物理屏障在蚊虫活动高峰期提供有效保护。窗户和门纱、户外宠物的防护服装以及在蚊虫最活跃的黎明和黄昏时段限制户外活动显著降低暴露风险[1]。在高风险季节将动物饲养在室内为严重受影响的动物提供最可靠的保护。

时间考虑对预防成功至关重要。蚊虫活动在温暖潮湿的月份达到高峰，需要从春季到秋季季节加强保护措施[1]。在蚊虫种群全年持续的流行地区建议全年预防[2]。

结合环境改造和化学控制的综合虫害管理提供全面保护。针对蚊虫繁殖地的专业虫害控制应用，结合批准用于伴侣动物的宠物安全驱虫剂，创造多层防御系统[1]。定期物业检查以识别和消除潜在繁殖地仍然是长期预防成功的基础。

### Sources

[1] Managing fleas, ticks and vector-borne diseases: https://www.dvm360.com/view/managing-fleas-ticks-and-vector-borne-diseases-proceedings
[2] CAPC releases 2025 Pet Parasite Forecast: https://www.dvm360.com/view/capc-releases-2025-pet-parasite-forecast

## 鉴别诊断

蚊虫超敏反应与几种其他皮肤病具有相似的临床表现，需要根据分布模式、季节发生和对治疗的反应进行系统鉴别[1]。

**跳蚤叮咬超敏反应**代表最常见的鉴别诊断，因为跳蚤过敏性皮炎是狗和猫中最普遍的过敏性皮肤病[1]。与蚊虫超敏反应的面部和耳部偏好不同，跳蚤过敏性皮炎通常影响狗的背腰骶区域和后肢近端，猫则表现为颈部和背部的粟粒状皮炎[3]。两种情况都引起剧烈瘙痒，但跳蚤过敏在温带气候中通常全年出现，而蚊虫超敏反应则呈季节性模式[1]。

**特应性皮炎**通常与昆虫叮咬超敏反应同时发生，使诊断复杂化。特应性皮炎通常呈现腹侧分布模式，影响足部、面部、耳朵和屈曲区域，与蚊虫超敏反应专注于毛发稀疏、暴露区域形成对比[1]。发病年龄不同，特应性皮炎通常在1-3岁之间发展，而蚊虫超敏反应可在任何暴露开始的年龄发生[1]。

**落叶型天疱疮**代表一个关键的鉴别诊断，特别是在表现为面部结痂和糜烂的猫中[4]。这种自身免疫性疾病通常影响鼻梁、耳廓和脚垫，与蚊虫超敏反应的分布重叠[4]。然而，落叶型天疱疮通常表现为破裂形成结痂的脓疱，涉及甲床和乳腺区域，并在细胞学上显示特征性棘层松解细胞[4]。与蚊虫超敏反应不同，落叶型天疱疮呈波浪式发作，伴有全身症状，并对免疫抑制治疗而非环境控制有反应。

**其他昆虫叮咬超敏反应**包括蜱虫叮咬反应和其他节肢动物敏感性，必须根据地理位置和季节性昆虫活动进行考虑[1]。这些通常在叮咬部位引起更局部化的反应，而不是蚊虫超敏反应中看到的全身性丘疹性皮疹[2]。

**鉴别因素**包括在蚊虫活动高峰期户外暴露的临床史、动物饲养在室内时病变快速消退、毛发稀疏区域偏好以及与当地昆虫种群的季节相关性[1]。

### Sources

[1] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis

[2] Dermatological Problems in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

[3] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats

[4] CVC Highlight: Getting to the bottom of feline facial dermatitis: https://www.dvm360.com/view/cvc-highlight-getting-bottom-feline-facial-dermatitis

## 预后

蚊虫叮咬超敏反应的预后因疾病严重程度和管理方法而有很大差异[1]。对于急性发作的猫，如果动物能被限制在无蚊环境中，临床症状可能自行消退[1]。然而，这种情况的管理选择通常预后谨慎，因为大多数治疗方法是支持性的而非治愈性的[1]。

发展为慢性蚊虫叮咬超敏反应的猫面临更具挑战性的前景[2]。这些动物通常发展为持续性病变，包括鳞屑、脱毛和色素变化，这些可能变为永久性[2]。一旦建立超敏反应，猫倾向于反复受到影响，表明对未来反应的持续易感性[2]。

蚊虫暴露的地理和季节性特征显著影响长期预后。在蚊虫流行地区有持续户外暴露史的猫面临反复发作的持续风险。对于室内猫或蚊虫季节明确的地区的猫，在传播高峰期限制饲养可显著改善结果。

环境控制代表最有效的预后因素。成功的长期管理需要避免蚊虫，这可能需要生活方式改变，如室内饲养或从高风险环境搬迁。当环境控制不可行时，全身性皮质类固醇治疗提供症状缓解但需要持续给药并伴随相关风险[1][2]。

### Sources

[1] ACVC 2017: Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats

[2] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
