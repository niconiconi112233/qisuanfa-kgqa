# 犬慢性支气管炎：综合兽医指南

犬慢性支气管炎是小动物临床实践中的一项重要呼吸道挑战，其特征为持续至少两个月的咳嗽和进行性气道炎症。这种特发性疾病主要影响8岁以上的小型和玩具犬种，形成一个自我持续的炎症、黏液过度分泌和呼吸功能受损的循环。本综合指南探讨了该疾病复杂的病理生理学，从环境触发因素和继发性细菌并发症到约克夏梗、吉娃娃和博美犬等特定品种的易感性。报告涵盖了重要的诊断方法，包括先进影像学和支气管镜检查；结合皮质类固醇和支持性治疗的循证治疗方案；以及关键的鉴别诊断，如气管塌陷和心脏病，为兽医从业者提供有效长期疾病管理所需的知识。

## 预后和管理总结

犬慢性支气管炎是一个复杂的临床挑战，需要终身管理而非治愈。该疾病的治疗反应各异，当通过结合皮质类固醇、支气管扩张剂和环境改变的多模式治疗进行适当管理时，预后从一般到良好不等。小型和玩具犬种由于结构性气道脆弱性而面临特殊挑战，晚期病例可能出现支气管扩张和继发性细菌感染等并发症，显著恶化预后。

| 预后因素 | 良好结局 | 不良结局 |
|-------------------|-------------------|--------------|
| 疾病阶段 | 早期干预，轻微症状 | 晚期支气管扩张，肺叶不张 |
| 品种类型 | 气道稳定的大型犬种 | 伴有气道塌陷的小型/玩具犬种 |
| 并发症 | 炎症控制良好 | 继发性肺炎，结构性损伤 |
| 治疗反应 | 对皮质类固醇反应良好 | 对标准治疗难治 |

成功取决于早期识别、积极的初始治疗和致力于解决药物治疗和环境因素的长期管理。兽医从业者应强调主人教育，设定合理期望，通过体重管理、避免刺激物和坚持用药来优化生活质量，以实现最佳疾病控制。

## 疾病概述和流行病学

犬慢性支气管炎被定义为一种复杂的进行性呼吸系统综合征，其特征为气道内黏液过度分泌和支气管结构增厚，慢性咳嗽持续至少连续两个月[1]。临床定义要求咳嗽发作排除其他支气管肺疾病，如呼吸道真菌病、肿瘤和细菌感染[1]。

该疾病表现出明显的流行病学模式，具有强烈的品种易感性。小型和玩具犬种最常受影响，特别是玩具贵宾犬、北京犬、约克夏梗、吉娃娃和博美犬[1]。慢性支气管炎通常发生在8岁或以上的小型和玩具犬种中，尽管年轻犬很少受影响[1][2]。除了品种特异性易感性外，年龄和性别似乎都不是易感因素[1]。

几个风险因素促成疾病的发展和严重程度。肥胖和晚期牙齿/牙周病是受影响的小型和玩具犬种中常见的独立发现，被视为额外的复杂因素[1]。玩具犬种的气道完整性受损，可能是由于遗传性软骨发育不良，可能进一步使老年犬的临床过程复杂化[1]。环境因素与人类慢性支气管疾病中确定的相似，包括年龄、吸入颗粒物（特别是烟草烟雾）和细菌成分[1]。

### Sources
[1] Chronic cough in the dog (Proceedings): https://www.dvm360.com/view/chronic-cough-dog-proceedings
[2] Small airway disease: Bronchitis in dogs and cats (Proceedings): https://www.dvm360.com/view/small-airway-disease-bronchitis-dogs-and-cats-proceedings

## 病因学和病理生理学

犬慢性支气管炎主要是特发性的，在大多数情况下确切的潜在原因仍然未知[1]。环境因素起着重要的促成作用，包括暴露于烟雾吸入、化学烟雾、灰尘和其他空气传播刺激物[1][6]。其他易感因素包括寄生虫感染、口腔和咽部疾病，以及与并发心脏或肺部疾病相关的慢性咳嗽[1][6]。

病理生理学围绕一个自我持续的炎症-黏液-咳嗽循环[4]。慢性气道炎症导致通过平滑肌和上皮增生引起黏液过度分泌和支气管壁增厚[4]。这种炎症过程遵循典型模式，从急性血管扩张和毛细血管通透性增加开始，随后是中性粒细胞、嗜酸性粒细胞和巨噬细胞的浸润[3]。如果未解决，慢性炎症会发展，伴有持续的组织破坏和纤维化[3]。

继发性细菌感染通常使慢性支气管炎复杂化，特别是支气管败血波氏杆菌和其他革兰氏阴性生物体[4][5]。这些机会性病原体利用受损的呼吸道防御机制，包括黏液纤毛运输减少和免疫反应受损[8]。浓稠、黏稠的黏液存在为细菌定植创造了理想环境，进一步加剧炎症循环和气道损伤。

### Sources
[1] Tracheobronchitis (Bronchitis) in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[2] Merck Veterinary Manual Bronchitis in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/bronchitis-in-dogs
[3] Merck Veterinary Manual Pathophysiology of Inflammation in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/inflammation/pathophysiology-of-inflammation-in-animals
[4] DVM 360 Chronic cough in the dog (Proceedings): https://www.dvm360.com/view/chronic-cough-dog-proceedings-0
[5] Merck Veterinary Manual Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[6] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[7] Chronic cough in the dog (Proceedings): https://www.dvm360.com/view/chronic-cough-dog-proceedings
[8] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings

## 临床表现和症状

犬慢性支气管炎的标志性临床症状是持续性慢性咳嗽，通常持续至少连续两个月[1]。这种咳嗽的特征被描述为"鹅鸣"声，通常因活动、兴奋或环境触发因素而加剧[1]。咳嗽常以干呕告终，表明是排痰性的，尽管犬通常吞咽咳出物而非将其排出体外[5]。

随着疾病进展，运动不耐受逐渐发展[2]。犬可能在用力时出现呼吸急促，严重受影响的犬在活动期间可能发绀[1]。在晚期病例中，犬表现出明显的呼气用力，呼吸的呼气期延长[5]。呼吸急促常伴随严重疾病或当肺纤维化发展时出现[1]。

慢性支气管炎患者的特征性发现是气管触诊时的敏感性，这常引发阵发性咳嗽发作[1]。检查时可能闻及喘鸣声，特别是在呼气时[1]。在严重病例中，犬可能在剧烈咳嗽发作后出现咳嗽相关的晕厥或虚脱[1][4]。

品种易感性值得注意，小型和玩具犬种过度受影响，特别是可卡犬、玩具贵宾犬、约克夏梗、吉娃娃和博美犬[4]。该疾病主要影响5岁以上的成年犬[4]。重要的是，食欲通常不受影响，身体状况评分通常正常或增加，这与其他引起全身性疾病的呼吸系统疾病不同[1]。

### Sources

[1] Canine chronic bronchitis and pulmonary fibrosis: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[2] Species Approach to Inflammatory Airway Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/species-approach-to-inflammatory-airway-disease-in-animals
[3] Managing the coughing dog: https://www.dvm360.com/view/managing-coughing-dog-proceedings
[4] Chronic cough in the dog: https://www.dvm360.com/view/chronic-cough-dog-proceedings
[5] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings

## 诊断方法

犬慢性支气管炎的明确诊断需要使用多种模式的综合诊断方法[1]。兽医通过临床表现、体格检查和系统排除其他呼吸系统疾病来建立诊断[1]。

**胸部X线摄影**作为基本诊断工具，揭示特征性支气管壁增厚模式并排除其他肺部疾病[1]。然而，在早期病例中，放射学变化可能很细微。

**先进影像技术**提供更高的诊断准确性。计算机断层扫描（CT）检查提供支气管壁变化的增强可视化，尽管准确性中等，为57%，敏感性46%，特异性90%[2]。CT还有助于识别在健康犬呼气期间可能表现正常的支气管塌陷模式[3]。

**支气管镜检查和支气管肺泡灌洗**代表下呼吸道评估的金标准[4]。该技术允许直接观察支气管炎症并收集细胞学样本进行分析。替代采样方法包括经气管抽吸和经口气管冲洗，当支气管镜检查禁忌时特别有用[4]。

**呼吸道样本的细胞学检查**有助于描述炎性细胞群和识别继发性细菌感染。当需要时，细菌培养和药敏试验指导适当的抗生素选择[4]。

血气分析和脉搏血氧测定评估严重受影响患者的氧合状态，帮助确定是否需要补充氧气治疗[1]。

### Sources
[1] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[2] Accuracy of and interobserver agreement regarding thoracic ...: https://avmajournals.avma.org/view/journals/javma/253/6/javma.253.6.757.xml
[3] Prevalence of bronchial wall thickening and collapse in ...: https://avmajournals.avma.org/view/journals/javma/261/1/javma.21.10.0448.xml
[4] Diagnostic evaluation of the respiratory tract (Proceedings): https://www.dvm360.com/view/diagnostic-evaluation-respiratory-tract-proceedings

## 治疗策略

犬慢性支气管炎治疗需要多模式药物方法结合支持性非药物措施[1,2]。

**药物干预**构成治疗的基石。皮质类固醇代表非细菌性支气管炎最有效的治疗方法，口服泼尼松作为一线治疗[1,2]。0.5-1 mg/kg每日的抗炎剂量有助于控制气道炎症并减少临床症状[2]。吸入性皮质类固醇如丙酸氟替卡松提供较少的全身效应，但对大型犬而言仍然成本过高[3]。

支气管扩张剂通过多种机制提供症状缓解。β2-激动剂如沙丁胺醇（通过定量吸入器给药）为急性发作提供快速支气管扩张[3,4]。甲基黄嘌呤衍生物包括茶碱（每12小时10-20 mg/kg）不仅松弛支气管平滑肌，还能增强呼吸肌并改善呼吸效率[5]。

**镇咳治疗**针对令人痛苦的咳嗽循环。可待因（每6-12小时1-2 mg/kg）和氢可酮（每6-12小时0.25 mg/kg）提供有效的咳嗽抑制[4]。然而，抑制排痰性咳嗽可能损害气道清除，应谨慎使用[2]。

**非药物方法**补充医疗治疗。体重管理减少呼吸工作量，而环境控制消除烟草烟雾和灰尘等刺激物[5,8]。用无菌盐水雾化（15-30分钟，每天3-4次）有助于液化分泌物并改善气道清除[6,7]。雾化后，轻度运动或叩击鼓励排痰[8]。

治疗成功需要基于临床严重程度的个体化方案，定期监测以实现最佳症状控制同时最小化不良反应[1,2]。

### Sources
[1] Merck Veterinary Manual Corticosteroids in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/inflammation/corticosteroids-in-animals
[2] MSD Veterinary Manual Tracheobronchitis (Bronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[3] Merck Veterinary Manual Inhalation Treatment of Airway Disease in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/inhalation-treatment-of-airway-disease-in-animals
[4] Merck Veterinary Manual Antitussive Drugs in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/antitussive-drugs-in-animals
[5] Merck Veterinary Manual Drugs Used to Treat Lung and Airway Disorders - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/drugs-and-vaccines/drugs-used-to-treat-lung-and-airway-disorders
[6] Inhalant drug therapy (Proceedings): https://www.dvm360.com/view/inhalant-drug-therapy-proceedings
[7] Inhalant therapy: Finding its place in small-animal practice: https://www.dvm360.com/view/inhalant-therapy-finding-its-place-small-animal-practice
[8] Managing of bronchial disease in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings

## 鉴别诊断

犬慢性支气管炎必须与几种表现出相似呼吸道症状的疾病进行鉴别。最重要的鉴别诊断包括气管塌陷、传染性气管支气管炎、心脏病、寄生虫感染和肿瘤[1]。

**气管塌陷**产生特征性干性、鹅鸣样咳嗽，主要影响玩具犬和迷你犬。通过透视和吸气/呼气X线片上可见的动态气道狭窄来区分，而慢性支气管炎则表现为持续性咳嗽和支气管间质模式[1][3]。

**传染性气管支气管炎（犬窝咳）**通常表现为近期接触其他动物的犬急性发作的剧烈干咳。与慢性支气管炎不同，犬窝咳通常在10-20天内消退，胸部X线片正常[2]。

**引起肺水肿的心脏病**可模拟慢性支气管炎，特别是当左心房扩大压迫主支气管时。关键鉴别特征包括心脏杂音、心脏扩大的放射学证据和肺静脉充血[4][5]。

**肺纤维化**表现为明显呼吸急促、响亮的肺部啰音（最明显在腹侧）和无实变的"重"间质性放射学模式。与慢性支气管炎不同，除非同时存在支气管炎，否则咳嗽轻微或不存在[6][7][8]。

**寄生虫感染**包括肺丝虫和心丝虫病可能引起嗜酸性炎症的慢性咳嗽。寄生虫可通过支气管肺泡灌洗细胞学、使用贝尔曼技术的粪便检查和心丝虫检测来识别[9]。

当慢性咳嗽对标准治疗无反应或当X线片显示肿块病变或非典型肺部模式时，应考虑**肿瘤**[6]。

### Sources

[1] Tracheal Collapse in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheal-collapse-in-dogs
[2] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[3] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings
[4] Management of acquired canine heart disease: part 1 & 2 (Proceedings): https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings
[5] The approach to dyspneic dogs (Proceedings): https://www.dvm360.com/view/approach-dyspneic-dogs-proceedings
[6] Canine chronic bronchitis and pulmonary fibrosis (Proceedings): https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[7] Managing pulmonary fibrosis in dogs (Proceedings): https://www.dvm360.com/view/managing-pulmonary-fibrosis-dogs-proceedings
[8] The approach to dyspneic dogs (Proceedings): https://www.dvm360.com/view/approach-dyspneic-dogs-proceedings
[9] Small airway disease: Bronchitis in dogs and cats (Proceedings): https://www.dvm360.com/view/small-airway-disease-bronchitis-dogs-and-cats-proceedings

## 预后

犬慢性支气管炎的预后因疾病严重程度和并发症存在而有显著差异[1]。治疗反应各不相同，一些犬实现接近完全康复，而其他犬则需要积极的终身医疗管理[1]。

当适当管理时，总体预后一般到良好，尽管治疗目标侧重于控制而非治愈[1][2]。许多犬通过适当治疗可以多年保持良好的生活质量，尽管治疗通常是终身的[2]。患有晚期疾病的犬，特别是那些患有支气管扩张或肺叶不张的犬，通常对医疗管理反应不佳[1]。

**预后因素和并发症**

患有包括支气管扩张在内的结构性气道变化的犬面临继发性细菌感染的风险增加[3]。获得性气道塌陷的发展显著使临床过程复杂化，特别是在小型和玩具犬种中[2]。如果不治疗，慢性支气管炎可能进展为支气管扩张和肺气肿（慢性阻塞性肺疾病）[2]。

**生活质量考虑**

环境压力如突然的天气变化可能加剧临床症状[4]。体重管理、避免环境刺激物和使用胸带而非项圈有助于优化患者舒适度[1]。疾病的进行性性质需要主人接受治疗目标是控制而非治愈[2]。

### Sources
[1] Canine chronic bronchitis and pulmonary fibrosis: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[2] Chronic cough in the dog: https://www.dvm360.com/view/chronic-cough-dog-proceedings
[3] Lower respiratory infections in dogs: https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[4] Tracheobronchitis in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
