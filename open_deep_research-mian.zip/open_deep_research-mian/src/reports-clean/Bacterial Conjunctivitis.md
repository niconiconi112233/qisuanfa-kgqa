# 伴侣动物细菌性结膜炎

细菌性结膜炎是影响犬猫的一种重要眼部疾病，特征为脓性分泌物和结膜炎症。虽然通常是继发于病毒感染或环境刺激物，但原发性细菌性结膜炎需要准确诊断以区别于病毒性和过敏性原因。本报告考察了主要细菌病原体，包括犬的假中间型葡萄球菌和猫的猫衣原体，主要依赖临床表现和细胞学诊断方法，以及使用局部和全身抗生素的循证治疗方案。了解物种特异性模式、适当的治疗干预和预后因素，使兽医能够优化受影响伴侣动物的临床结果并预防并发症。

## 摘要

这篇综合综述表明，伴侣动物的细菌性结膜炎需要基于物种特异性病原体模式的目标性诊断和治疗方法。犬主要发展为假中间型葡萄球菌感染，而猫对猫衣原体和支原体物种表现出更高的易感性。临床诊断主要依赖表现模式和细胞学而非培养，细菌病例以黏液脓性分泌物为特征，区别于病毒感染的浆液性分泌物。

治疗成功取决于适当的抗生素选择，氟喹诺酮类药物提供广谱覆盖，而多西环素对支原体和衣原体感染至关重要。大多数病例在适当管理后1-2周内痊愈，尽管衣原体感染可能需要延长治疗并显示复发潜力。

* 环境管理和压力减轻作为关键的预防措施
* 早期干预可预防继发并发症并改善结果
* 物种特异性治疗方案优化治疗成功

兽医应优先进行快速诊断、适当的抗菌治疗并解决潜在的易感因素，以确保最佳的患者结果并预防复发。

## 疾病概述和流行病学

细菌性结膜炎是由细菌病原体引起的结膜炎症性疾病，特征为脓性眼分泌物、结膜充血和不同程度的结膜水肿[1]。这种情况代表了影响伴侣动物的更广泛结膜炎谱系的一个组成部分。

结膜炎在所有家养物种中都很常见，细菌原因既可以是原发性传染源，也可以是继发性机会性感染[1]。原发性和继发性细菌性结膜炎的区别具有临床意义。原发性细菌性结膜炎是指细菌直接侵入健康的结膜组织，而继发性细菌性结膜炎则是在结膜黏膜因潜在疾病（如病毒感染、干性角膜结膜炎或环境刺激物）而受损后，细菌变得具有致病性时发生[1]。

双眼同时发生的结膜炎通常由细菌感染引起[3]。局部抗菌药物应用是治疗引起结膜疾病的细菌感染的主要方法[1]。这些感染可以单独使用或与其他抗菌药物联合使用。具有革兰氏阳性和革兰氏阴性谱的局部眼用药物家族包括氨基糖苷类、氟喹诺酮类、氯霉素、四环素类和大环内酯类[1]。

短头颅犬对结膜细菌定植表现出更高的易感性，33%的病例结膜表面存在口腔细菌，显著高于非短头颅品种[2]。风险因素包括异物、环境刺激物、结构性眼睑缺陷和损害正常结膜防御机制的并发眼部疾病[1]。

### Sources
[1] Antimicrobial Use in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[2] Oral bacteria may affect conjunctival microorganisms in ...: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.11.0260.xml
[3] Disorders of the Conjunctiva in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-conjunctiva-in-dogs

## 常见细菌病原体和临床表现

犬猫的细菌性结膜炎主要由机会性细菌引起，这些细菌利用受损的眼表防御机制。**假中间型葡萄球菌**是犬细菌性结膜炎最常见的病原体，通常表现为脓性分泌物伴有结膜充血和结膜水肿[1]。这种革兰氏阳性生物经常在病毒性结膜炎或机械创伤后引起继发感染。

**链球菌属**也会在两个物种中引起细菌性结膜炎，通常表现为急性发作的黏液脓性分泌物伴有明显的结膜炎症[2]。这些感染可能与上呼吸道受累有关，特别是在多种病原体同时传播的收容所环境中。

**猫衣原体**是猫结膜炎的重要细菌病原体，引起具有持续性浆液性至黏液脓性分泌物的慢性感染[2][7]。这种生物表现出延长的脱落模式，通常最初表现为单侧，然后进展为双侧受累[2]。*C. felis* 优先靶向结膜上皮细胞，与其他病原体相比产生更明显的结膜水肿[8][9]。

**支原体属**，包括*猫支原体*，引起以慢性、低度炎症和间歇性分泌物为特征的结膜炎[2]。这些感染在猫中更常见，通常伴有上呼吸道症状[7]。与其他病原体相比，支原体结膜炎通常产生严重的结膜水肿和较轻的鼻炎[7]。

物种特异性模式值得注意，猫对*衣原体*和*支原体*感染表现出更高的易感性，而犬更常见发展为*葡萄球菌*和*链球菌*结膜炎[1][2]。继发性细菌感染经常使原发性病毒性结膜炎复杂化，特别是在猫疱疹病毒病例中[7]。

### Sources
[1] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[2] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-animal-shelters
[3] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[4] Chlamydiosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/chlamydiosis/chlamydiosis-in-animals
[5] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-

## 诊断方法和鉴别诊断

诊断猫的细菌性结膜炎需要系统的方法，以区别于病毒性和过敏性疾病。临床检查显示结膜充血、眼分泌物和眼睑水肿，细菌病例通常表现为黏液脓性分泌物，而病毒感染则表现为浆液性分泌物[1]。

细胞学作为主要的诊断工具，帮助区分疱疹病毒与细菌性或嗜酸性粒细胞性浸润性疾病[1]。然而，结膜培养通常被认为对常规诊断不可靠[1]。疱疹病毒或猫衣原体的PCR检测由于高假阳性和假阴性率而具有有限的诊断价值[1]。

大多数临床医生基于患者信号数据、暴露史和临床症状而非明确的实验室检测进行诊断[2]。对治疗的反应通常确认诊断，细菌性结膜炎对局部抗生素有反应，而病毒病例需要抗病毒治疗[2]。

关键鉴别诊断包括猫疱疹病毒1型，表现为更严重的结膜充血并可能导致角膜溃疡，以及猫衣原体，特征为严重结膜水肿[2]。复发性疾病和睑球粘连形成表明既往疱疹病毒感染[2]。继发性细菌感染通常使病毒性结膜炎复杂化，分泌物从浆液性变为黏液脓性[1]。

### Sources
[1] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings
[2] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-

## 治疗和预防策略

### 治疗选择

**局部抗生素**：细菌性结膜炎的一线治疗包括广谱局部抗生素[1]。氟喹诺酮类药物提供出色的革兰氏阳性和革兰氏阴性覆盖，第二代化合物如环丙沙星对假单胞菌有效，而第三代药物如莫西沙星提供增强的革兰氏阳性活性[2]。氨基糖苷类如庆大霉素和妥布霉素对革兰氏阴性细菌有杀菌作用，但频繁给药可能导致上皮毒性[2]。

**全身抗生素**：对于支原体属感染，建议使用全身多西环素至少2周[1]。猫衣原体病例对局部四环素、氯霉素或红霉素反应良好，每天4次，持续14天[3]。最近的研究建议用口服多西环素（10 mg/kg，每天一次，持续3周）补充或替代局部治疗[4]。

**治疗持续时间和监测**：抗生素治疗通常在临床症状消退后继续10-14天[3]。反应监测包括评估分泌物减少、结膜充血改善和患者舒适度。初始反应不良需要进行培养和药敏测试以指导治疗选择。

### 预防策略

**环境管理**：适当的卫生方案，包括定期清洁床上用品、食碗和居住区域，可减少病原体传播[2]。多宠物家庭需要隔离受影响的动物，直到临床症状消退。

**解决易感因素**：减轻压力至关重要，特别是在收容所环境中，过度拥挤会增加疾病传播风险[9]。保持适当的通风、温度控制并最小化环境压力源，支持免疫功能并降低感染易感性[9]。

### Sources

[1] Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases
[2] Antimicrobial Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[3] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[9] Controlling disease transmission in animal shelters: Part 1 (Proceedings): https://www.dvm360.com/view/controlling-disease-transmission-animal-shelters-part-1-proceedings

## 预后和临床结果

猫和犬的细菌性结膜炎在及时诊断和适当治疗的情况下通常预后良好。大多数病例在适当的抗菌治疗后1-2周内痊愈[1][2]。然而，特定病原体和个体因素显著影响恢复结果。

对于猫的衣原体结膜炎，使用多西环素治疗通常产生快速消退，当开始全身治疗时通常在几天内[1]。症状在发病后9-13天最严重，然后在2-3周内变得轻微，尽管一些猫尽管治疗仍可能持续数周的临床症状[1]。

几个因素影响预后。幼年动物，特别是1岁以下的猫，感染率较高，但对治疗通常反应良好[1]。免疫功能不全的患者面临并发症风险增加和恢复期延长。并发疾病如角膜溃疡或继发性青光眼可能使治疗复杂化并恶化结果[3]。

复发仍然是一个重大问题。在衣原体感染中，症状复发并不少见，未经治疗的猫可能在感染后数月携带病原体[1]。这强调了完成完整治疗疗程和解决潜在易感因素的重要性。

长期管理考虑包括环境控制和压力减轻，因为这些因素可能触发复发发作。定期监测确保早期发现并发症，主人教育关于治疗依从性对成功结果至关重要。

### Sources
[1] Chlamydial Conjunctivitis in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals
[2] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[3] Allergic Conjunctivitis in Dogs and Cats - Veterinary Partner - VIN: https://veterinarypartner.vin.com/doc/?id=10517463&pid=19239
