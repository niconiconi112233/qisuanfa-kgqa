# 伴侣动物眼睑内翻：综合兽医指南

眼睑内翻是影响伴侣动物的最重要遗传性眼睑疾病之一，尤其在具有强烈品种易感性的犬中。这种结构异常导致眼睑边缘向内翻卷，引起慢性角膜刺激、继发感染以及潜在的威胁视力的并发症。了解眼睑内翻的临床表现、诊断方法和治疗方案对于管理患病动物的兽医从业者至关重要。

本报告探讨了眼睑内翻在犬品种中的流行病学模式，探讨了继发性细菌并发症，并详细介绍了基于证据的手术干预措施，包括金标准Hotz-Celsus手术。分析涵盖了从荧光素染色到眼压测量的诊断技术，同时解决了关键的鉴别诊断问题，如痉挛性与结构性眼睑内翻。预防性繁殖建议和术后管理协议为优化小动物临床实践中的患者预后提供了实用指导。

## 疾病概述

眼睑内翻定义为全部或部分眼睑边缘向眼球方向内翻，导致睫毛和面部毛发接触结膜和角膜[1]。这种结构异常是许多犬品种中最常见的遗传性眼睑缺陷[1]。

当眼睑向内翻时，睫毛和皮肤摩擦眼球表面，导致结膜炎、角膜炎和潜在的角膜溃疡[2]。眼睑内翻可能涉及一个或两个眼睑，并可能影响眼眦[1]。这通常是先天性或遗传性疾病，通常需要手术矫正[5]。

从流行病学角度看，眼睑内翻影响许多具有强烈品种易感性的犬种。最常受影响的品种包括英国斗牛犬、拉布拉多寻回犬、沙皮犬、金毛寻回犬、松狮犬、圣伯纳犬、罗威纳犬、大丹犬和切萨皮克湾寻回犬[2]。在短头颅犬中，结构性眼睑内翻通常影响内侧下眼睑，而在大型、宽头颅犬中，通常涉及外侧下眼睑和外侧眼眦[2]。

就诊时的中位年龄为7个月（范围1.5-34个月）[4]。虽然结构性眼睑内翻可能在睁眼后不久就表现出来，但随着面部结构的成熟，通常在后期才变得临床明显[2]。眼睑内翻可作为幼犬的原发性结构缺陷出现，或继发于损伤、角膜疼痛或球后脂肪萎缩[6]。

### Sources

[1] Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals

[2] DVM360: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery

[3] Merck Veterinary Manual - Dog Owners: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-eyelids-in-dogs

[4] AVMA Journal: https://avmajournals.avma.org/downloadpdf/view/journals/javma/262/2/javma.23.05.0273.pdf

[5] DVM360: https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings

[6] DVM360: https://www.dvm360.com/view/everyday-answers-common-conditions-eyelidconjunctiva-proceedings

## 常见病原体

眼睑内翻本质上是一种解剖结构性疾病，而非传染性疾病[1]。该疾病本身没有原发性病毒或细菌病因。然而，由于内翻的睫毛和毛发接触角膜表面引起的机械刺激，经常发生继发性细菌感染[1][2]。

与眼睑内翻相关并发症相关的最常见继发性细菌病原体包括葡萄球菌属和链球菌属[2]。当这些细菌涉及上下眼睑的睑板腺时，通常会引起睑板腺炎[2]。此外，当眼睑内翻导致角膜溃疡时，可能发生继发性细菌污染，病原体如铜绿假单胞菌和β-溶血性链球菌，这些是伴侣动物深基质溃疡的常见原因[2][4]。

当眼睑内翻继发角膜溃疡或伴有黏脓性分泌物的结膜炎时，需要使用局部眼用抗生素[1]。细菌感染通常表现为溃疡边缘密集的白色浸润，表明强烈的白细胞趋化性和活动性感染[4]。

虽然病毒病因与眼睑内翻的发生无关，但猫和马的疱疹病毒感染可引起复发性角膜溃疡，可能通过继发性眼部疼痛和眼睑痉挛导致痉挛性眼睑内翻[4]。

### Sources
[1] Topical ophthalmic antibiotics are warranted: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0187/javma.25.03.0187.pdf
[2] Eyelids in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals

## 临床症状和体征

眼睑内翻表现出特征性的临床体征，这些体征根据眼睑内翻的类型、位置和严重程度而异。主要体征是眼睑边缘可见的向内翻卷，导致面部毛发和睫毛接触结膜和角膜[1]。

**主要临床表现**

患病动物通常表现为从浆液性到黏脓性的眼部分泌物、结膜充血、眼睑痉挛和流泪[1][2]。毛发接触角膜表面的持续刺激导致结膜炎、角膜炎和潜在的角膜溃疡[7]。在严重情况下，慢性刺激可能导致角膜瘢痕形成和色素沉着[4]。

**年龄和品种特异性模式**

原发性结构性眼睑内翻通常作为先天性/发育性疾病影响幼犬[1][4]。在短头颅品种中，眼睑内翻通常表现为内侧下眼睑受累，而大型、宽头颅犬通常表现为外侧下眼睑和外侧眼眦受累[7]。上眼睑内翻主要发生在有过量眉部组织的品种中，包括松狮犬、沙皮犬、巴吉度犬和寻血猎犬[7]。

**继发性眼睑内翻体征**

通过应用局部麻醉剂可以区分继发于眼部疼痛的痉挛性眼睑内翻与原发性眼睑内翻[1]。在老年动物中，眼睑松弛和眶隔脂肪垫萎缩可能导致年龄相关性眼睑内翻，通常在眼球内陷后影响外侧上眼睑或下眼睑[6]。猫可能发生与眼睑或角膜炎症疾病相关的眼睑内翻，尽管手术修复通常较简单[2]。

### Sources
[1] Everyday answers for common conditions of the eyelid/conjunctiva (Proceedings): https://www.dvm360.com/view/everyday-answers-common-conditions-eyelidconjunctiva-proceedings
[2] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings
[4] Common eye diseases for veterinary technicians (Proceedings): https://www.dvm360.com/view/common-eye-diseases-veterinary-technicians-proceedings
[6] Geriatric eyes: Old dogs new tricks (Proceedings): https://www.dvm360.com/view/geriatric-eyes-old-dogs-new-tricks-proceedings
[7] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery

## 诊断方法

伴侣动物眼睑内翻的诊断主要依靠系统的临床检查技术结合专门的眼科测试。检查应在良好光线下从2-3英尺远开始评估，评估对称性、正常结构和明显病变[1]。

基本的基础诊断测试包括希林泪液试验（STT）、荧光素染色和眼压测量以测量眼内压[1]。STT必须在任何滴眼液应用于眼睛之前进行，测量水样泪膜产生，犬的正常值≥15 mm/min[1,2]。低于此阈值的值可能表明干性角膜结膜炎，这可能使动物易患继发性眼睑内翻。

荧光素钠染色是检测与眼睑内翻相关的角膜上皮损伤的关键诊断工具[1]。当亲脂性上皮因内翻眼睑的机械刺激而丧失时，亲水性染料会结合暴露的角膜基质[1]。在钴蓝光（450-500 nm）下，荧光素产生强烈荧光，揭示角膜溃疡模式，这可能表明眼睑-角膜接触的严重程度和位置[1]。

综合方法需要通过应用局部麻醉剂消除痉挛性眼睑内翻[3]。这区分了原发性结构性眼睑内翻与由眼部疼痛引起的继发性痉挛性眼睑内翻，确保准确评估需要手术矫正的真实解剖缺陷[3]。

眼压测量应在瞳孔扩张之前进行，因为升高的眼内压是瞳孔扩张的禁忌症[1]。检查顺序必须遵循这种系统方法，以防止诊断错误并确保为眼睑内翻病例制定适当的治疗计划。

### Sources

[1] Merck Veterinary Manual - Physical Examination of the Eye in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals
[2] JAVMA - What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/260/9/javma.21.01.0016.xml
[3] DVM360 - Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery

## 治疗选择

眼睑内翻治疗需要手术干预结合支持性护理方案。**透明质酸注射**代表了一种新兴的治疗选择，研究表明其在组织愈合和炎症调节方面具有前景[1][2]。虽然主要在人类医学中研究，但透明质酸的伤口愈合特性和减轻炎症的能力使其成为术后恢复的潜在辅助治疗[3]。

**Hotz-Celsus手术**仍然是金标准手术技术，涉及在距离眼睑边缘2-3mm处切除新月形皮肤条带以实现适当的外翻[4][5]。**临时缝合固定**使用缝线或手术钉为幼年动物提供临时管理，直到面部成熟或用于解决继发于角膜刺激的痉挛性眼睑内翻[6]。

**术后管理**包括使用卡洛芬（2.2 mg/kg口服）和曲马多进行系统性疼痛控制、局部抗生素和冷敷以最小化肿胀[4]。伊丽莎白圈约束在关键的2周愈合期间防止自伤[5]。缝线在10-14天时拆除，仔细监测过度矫正并发症[6]。

在生长中的动物中可能需要多次缝合固定程序，而痉挛性眼睑内翻病例需要在考虑永久性手术矫正之前解决潜在的角膜病理[6]。

### Sources
[1] Hyaluronic acid : Uses, side effects, and risks - Medical News: https://www.medicalnewstoday.com/articles/326385
[2] Hyaluronic acid - Wikipedia: https://en.wikipedia.org/wiki/Hyaluronic_acid
[3] Hyaluronic Acid: What It Is, Benefits, How To Use & Side Effects: https://my.clevelandclinic.org/health/articles/22915-hyaluronic-acid
[4] Palpebral reconstruction after entropion surgery in a dog: https://www.dvm360.com/view/clinical-exposures-palpebral-reconstruction-after-entropion-surgery-dog
[5] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings
[6] Eyelids in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals

## 预防措施和鉴别诊断

### 预防措施

**繁殖建议**对于控制眼睑内翻传播至关重要。患有眼睑内翻的犬应排除在繁殖计划之外，因为该疾病具有已知的遗传成分，具有多基因遗传模式[1]。患病动物的双亲都应被视为携带者，特别是在易感品种中，包括罗威纳犬、大丹犬、獒犬、拉布拉多犬、波斯猫和缅因猫[2]。短头颅品种通常因面部褶皱结构而发生内侧眼睑内翻[2]。

**环境管理**侧重于早期干预策略。幼年动物（4-7个月）可受益于临时缝合固定或基于透明质酸的填充物，以便在永久性手术矫正前实现适当的面部发育[2]。环境控制包括保持清洁的生活条件和监测继发性并发症，如角膜溃疡。

### 鉴别诊断

**眼睑外翻**（眼睑外翻）表现为眼睑边缘向外翻卷，与眼睑内翻的向内翻卷形成对比[6]。**痉挛性眼睑内翻**继发于严重结膜炎或角膜溃疡等疾病引起的眼部疼痛，使用局部麻醉剂后暂时缓解[2]。**瘢痕性眼睑内翻**由创伤或慢性炎症疾病（如猫疱疹性结膜炎）后的瘢痕组织发展而来[2]。

**樱桃眼**（第三眼睑腺脱垂）表现为内侧眼眦处的红色肉质肿块，与眼睑内翻的眼睑边缘翻卷不同[3]。**退行性眼睑内翻**由衰老、体重减轻或甲状腺功能亢进引起的眶组织丢失导致，需要与结构性眼睑内翻不同的治疗方法[2]。

### Sources

[1] The Breeding Soundness Examination in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/the-breeding-soundness-examination-in-dogs-and-cats

[2] Answer to identifying an eye condition: https://www.dvm360.com/view/answer-to-identifying-an-eye-condition

[3] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings

[4] Canine corneal diseases: secrets for transparency greater: https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings

[5] Ocular emergencies (Proceedings): https://www.dvm360.com/view/ocular-emergencies-proceedings-0

[6] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery
