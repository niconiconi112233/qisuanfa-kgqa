# 伴侣动物的慢性胰腺炎

慢性胰腺炎在小动物兽医实践中代表一项重大的临床挑战，其特征为不可逆的胰腺组织损伤和进行性功能丧失。与急性胰腺炎不同，这种疾病涉及永久性结构改变，包括纤维化和腺泡萎缩，这些改变深刻影响患者的生活质量。本综合报告探讨了犬猫慢性胰腺炎的多面性，研究其复杂的病理生理学、多变的临床表现和诊断挑战。分析涵盖了循证治疗策略、长期管理方案和影响临床结果的预后考虑因素。特别关注了品种易感性、犬猫表现之间的物种特异性差异，以及受影响动物中常见发展的外分泌胰腺功能不全和糖尿病的严重并发症。

## 疾病概述与流行病学

慢性胰腺炎是一种进行性炎症性疾病，其特征为不可逆的组织学改变，包括纤维化、胰腺腺泡萎缩和淋巴细胞性炎症[1]。与急性胰腺炎不同，后者在去除根本原因后炎症可完全逆转，而慢性胰腺炎则导致胰腺组织的永久性结构损伤[2]。

该疾病影响犬和猫，具有不同的流行病学模式。在犬中，慢性胰腺炎通常作为反复急性胰腺炎发作的后遗症发生，约克夏梗显示易感性增加，而迷你贵宾犬和拉布拉多寻回犬则风险降低[3]。患病犬的平均年龄为8岁，与未绝育雌性相比，雄性和绝育雌性风险更高[3]。

猫慢性胰腺炎没有公认的年龄、性别或品种易感性[2]。由于猫独特的胰腺解剖结构，该疾病常与并发性肝胆疾病或炎症性肠病相关，其中胰管和总胆管在进入十二指肠前汇合[2]。

风险因素包括超重体况、糖尿病、肾上腺皮质功能亢进、甲状腺功能减退和既往胃肠道疾病[3]。发病机制涉及胰腺实质内消化酶原的不适当激活，导致自身消化和进行性组织损伤[1][2]。

### Sources
[1] Exocrine pancreatic insufficiency in dogs and cats in: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[2] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-2
[3] Canine pancreatic disease: What's new in diagnosis and therapy? (Proceedings): https://www.dvm360.com/view/canine-pancreatic-disease-whats-new-diagnosis-and-therapy-proceedings

## 病因学与病理生理学

犬猫慢性胰腺炎的大多数病例为特发性，但已确定了几种风险因素[1]。在犬中，迷你雪纳瑞犬表现出显著的高发病率，怀疑有遗传易感性，类似于人类的遗传性胰腺炎。其他易感品种包括约克夏梗、可卡犬和腊肠犬[1]。

饮食不当被认为是犬的常见风险因素。严重高甘油三酯血症（≥500 mg/dL）被认为是犬的风险因素，但猫不是[1]。肾上腺皮质功能亢进以及糖皮质激素或孕激素引起的胰岛素抵抗可使动物易患糖尿病，而糖尿病常继发于慢性胰腺炎发展[1][2]。妊娠和发情间期也通过孕酮介导的生长激素释放使犬易患糖尿病[1]。

病理生理机制涉及胰腺腺泡细胞内酶原的过早激活。这通过酶原颗粒和溶酶体的共定位发生，导致在共定位的细胞器内胰蛋白酶原激活为胰蛋白酶[1]。胰蛋白酶随后激活其他酶原，导致局部胰腺损伤，伴有水肿、出血、炎症和坏死。

慢性胰腺炎的特征为不可逆的改变，包括纤维化、胰腺腺泡萎缩和持续性淋巴细胞性炎症[6][8]。活化的酶和炎症细胞因子全身循环，可能引起远处并发症，包括弥散性血管内凝血、肾衰竭和多器官衰竭[1]。

### Sources
[1] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[2] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[6] Pancreatitis: More common than you think (Proceedings): https://www.dvm360.com/view/pancreatitis-more-common-you-think-proceedings
[8] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-2

## 临床表现与诊断方法

慢性胰腺炎在犬和猫中表现出多变的临床症状。犬常见表现为厌食、呕吐、嗜睡和腹痛，而猫则表现出更非特异性的症状，包括厌食和嗜睡[1]。在患有严重胰腺炎的猫中，临床症状包括厌食（87%）、嗜睡（81%）、脱水（54%）、体重减轻（47%）、体温过低（46%）、呕吐（46%）、黄疸（37%）、发热（19%）和腹痛（19%）[1]。体格检查结果可能非特异性，大多数犬显示脱水、流涎和前腹部疼痛[1][2]。

某些品种显示对胰腺疾病的易感性增加。迷你雪纳瑞犬、约克夏梗、骑士查理王小猎犬和玩具贵宾犬特别易患胰腺炎[1]。在一些研究中，迷你雪纳瑞犬显著高发，约克夏梗、可卡犬、腊肠犬和贵宾犬也显示发病率增加[1]。

诊断测试主要依赖胰腺特异性检测。血清胰蛋白酶样免疫反应性（TLI）是诊断外分泌胰腺功能不全的金标准，犬浓度≤2.5 mcg/L，猫浓度≤8.0 mcg/L具有诊断意义[3]。对于胰腺炎诊断，胰腺脂肪酶免疫反应性（PLI）代表目前可用最敏感和特异的检测[4][5]。传统标志物如血清淀粉酶和脂肪酶活性对胰腺炎诊断缺乏敏感性和特异性[1]。

超声作为主要影像学检查方式，显示特征性表现包括胰腺增大伴低回声实质、由于皂化作用导致周围脂肪高回声和腹腔积液[2]。最近的研究显示超声检查结果与特异性胰腺标志物之间存在中度至低度一致性[1]。

### Sources
[1] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[2] Pancreatitis in dogs (Proceedings): https://www.dvm360.com/view/pancreatitis-dogs-proceedings
[3] Exocrine Pancreatic Insufficiency in Dogs and Cats: https://www.merckvetmanual.com/en-au/digestive-system/the-exocrine-pancreas/exocrine-pancreatic-insufficiency-in-dogs-and-cats
[4] Clinical Biochemistry - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-biochemistry
[5] Is it pancreatitis?: https://www.dvm360.com/view/it-pancreatitis

## 治疗与管理策略

慢性胰腺炎的综合管理侧重于支持性护理、营养支持、疼痛管理和并发症监测[1]。治疗应根据疾病严重程度和并发情况进行个体化。

**饮食管理与营养支持**

早期肠内营养至关重要，推荐高消化性、低残留饮食[1]。犬应接受超低脂饮食（干物质基础2-4%脂肪），而猫仅需要中度限制脂肪的饮食[2]。喂食应从静息能量需求的20-30%开始，每6-24小时逐渐增加[10]。营养支持有助于预防脂肪肝并支持恢复[7]。

**疼痛管理**

应假定存在腹痛并积极治疗[3,9]。阿片类镇痛药包括吗啡、芬太尼或美沙酮是内脏疼痛的首选药物[7,10]。严重病例可能需要恒速输注。非甾体抗炎药在脱水患者中因胃肠道和肾脏风险而禁用[10]。

**液体疗法与支持性护理**

平衡等渗溶液（乳酸林格氏液）纠正脱水并维持胰腺灌注[10]。止吐药如马罗匹坦或昂丹司琼控制呕吐和恶心[3,7]。质子泵抑制剂可减少胃酸[7]。

**并发症管理**

继发于慢性胰腺炎的外分泌胰腺功能不全（EPI）中，>60%的犬和77-100%的猫发生钴胺素缺乏[1]。口服和肠外补充均有效[1]。并发糖尿病需要胰岛素治疗，尽管随着胰腺炎缓解这可能是暂时性的[8]。长期监测包括如果发生外分泌胰腺功能不全时的胰腺酶替代治疗[3]。

### Sources

[1] Exocrine pancreatic insufficiency in dogs and cats in: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[2] Can diet help in managing pancreatic diseases: https://www.dvm360.com/view/can-diet-help-managing-pancreatic-diseases-proceedings
[3] Exocrine Pancreatic Insufficiency in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/exocrine-pancreatic-insufficiency-in-dogs-and-cats
[7] Feline pancreatitis: underdiagnosed or overdiagnosed?: https://www.dvm360.com/view/feline-pancreatitis-underdiagnosed-or-overdiagnosed-proceedings
[8] Diagnosing and managing feline pancreatitis: https://www.dvm360.com/view/diagnosing-and-managing-feline-pancreatitis-sponsored-idexx-laboratories
[9] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[10] Management of pancreatitis in dogs and the role: https://www.dvm360.com/view/management-of-pancreatitis-in-dogs-and-the-role-of-panoquell-ca1-fuzapladib-sodium-for-injection-

## 预防与鉴别诊断

### 预防措施

目前，对于猫和犬的慢性胰腺炎没有特定的经证实的预防策略[1]。在猫中，积极的液体疗法和营养支持仍然是管理的基石，但"目前没有已知的治疗或饮食策略可以预防未来的胰腺炎发作"[1]。对于易复发的犬，长期喂食超低脂饮食（2-4%脂肪）可能有益[2]。

体重管理代表重要的预防考虑因素，因为肥胖与犬胰腺炎相关，这是由于脂肪组织的炎症作用[2]。避免饮食不当、餐桌残羹和突然的食物变化可以帮助减少风险因素[2][6]。通过饮食脂肪限制管理高甘油三酯血症在易感犬中至关重要，特别是当血清甘油三酯超过500-600 mg/dL时[2][6]。

### 鉴别诊断

慢性胰腺炎必须与几种症状重叠的疾病进行鉴别。急性胰腺炎表现相似，但缺乏慢性疾病中见到的进行性纤维化改变[6]。外分泌胰腺功能不全（EPI）有体重减轻和脂肪泻等相似症状，但通过低血清胰蛋白酶样免疫反应性诊断[5]。

胰腺肿瘤虽然罕见，但表现非特异性症状，需要细胞学或组织病理学确认。在猫中，猫三体炎（并发胰腺炎、胆管炎和炎症性肠病）发生在17-39%的患病转诊猫中，由于共享的临床表现而使诊断复杂化[2]。其他胃肠道疾病包括慢性肠病、糖尿病和脂肪肝可能表现相似症状，需要包括胰腺脂肪酶免疫反应性测试在内的全面诊断评估以进行明确鉴别[6]。

### Sources

[1] Managing pancreatitis in cats (Proceedings): https://www.dvm360.com/view/managing-pancreatitis-cats-proceedings
[2] Nutritional management of pancreatitis and concurrent disease in dogs and cats: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.11.0641.xml
[5] Exocrine pancreatic insufficiency in dogs and cats in: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[6] Pancreatitis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats

## 预后与长期结果

犬猫慢性胰腺炎的预后为谨慎至一般，根据疾病严重程度、并发情况和治疗反应差异显著。虽然由于永久性胰腺组织损伤该疾病不可逆，但适当的管理可使受影响动物维持合理的生活质量[1][2]。

生存结果在很大程度上取决于胰腺炎的形式和严重程度。患有急性胰腺炎和胆道梗阻的犬显示80-94%的生存率，手术管理显示出比单纯药物治疗更优的结果（94%生存率）[1][2]。然而，慢性胰腺炎由于其进行性性质带来持续的挑战。

长期并发症显著影响预后。患有慢性胰腺炎的猫常发展为外分泌胰腺功能不全（EPI），77-100%发生钴胺素缺乏[3]。当提供高质量的酶替代治疗和钴胺素补充时，EPI的预后通常良好[3][4]。患有EPI的犬和猫通常能快速增加体重，在适当管理下可正常寿命生活[4][5]。

糖尿病代表另一个主要并发症，特别是在患有慢性胰腺炎的猫中。当多个器官系统受影响时，预后变得更加谨慎。包括DIC、急性肾衰竭、呼吸衰竭和心肌炎在内的全身性并发症可在严重病例中发展[6]。

预后因素包括疾病严重程度、治疗依从性和并发情况。早期干预、适当的营养支持、必要时酶补充和并发症管理对于最佳结果至关重要[3][4]。

### Sources

[1] Features, management, and long-term outcome in dogs with ...: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.03.0155.xml
[2] Management of acute-onset pancreatitis in dogs: a Narrative ...: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.02.0107.xml
[3] Exocrine pancreatic insufficiency in dogs and cats in: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[4] Exocrine Pancreatic Insufficiency in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/exocrine-pancreatic-insufficiency-in-dogs-and-cats
[5] Exocrine pancreatic insufficiency (Proceedings): https://www.dvm360.com/view/exocrine-pancreatic-insufficiency-proceedings
[6] Pancreatitis in dogs and cats (Proceedings): https://www.dvm360.com/view/pancreatitis-dogs-and-cats-proceedings
