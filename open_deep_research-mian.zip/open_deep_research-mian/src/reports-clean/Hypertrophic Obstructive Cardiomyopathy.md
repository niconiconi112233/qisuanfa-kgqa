# 伴侣动物中的肥厚性梗阻型心肌病

肥厚性梗阻型心肌病（HCM）是猫最常见的心脏病，大约影响七分之一的猫，其中绝大多数保持亚临床状态。这种遗传性疾病导致左心室壁进行性增厚，在兽医实践中提出了重大的诊断和管理挑战。该病在缅因猫和布偶猫等品种中的家族性特征，加上其可能突然临床恶化的风险，使得全面了解对兽医专业人员至关重要。本报告探讨了猫和狗HCM管理的病理生理学、临床表现、诊断方法和治疗策略，综合了当前兽医知识以指导循证实践决策并改善患者预后。

## 摘要

肥厚性梗阻型心肌病是一种复杂的遗传性心脏病，主要影响猫，超声心动图作为确诊工具要求左心室壁厚度>6毫米。该病在缅因猫和布偶猫中的遗传基础与其缺乏传染性病因形成对比，而临床表现从无症状病例到急性心力衰竭和血栓栓塞不等。紧急处理遵循F-O-N-S方案，长期治疗则结合呋塞米和ACE抑制剂用于充血性心力衰竭病例。

| 方面 | 无症状HCM | 伴CHF的HCM | 伴血栓栓塞的HCM |
|--------|------------------|--------------|--------------------------|
| 预后 | 良好，可存活多年 | 92-654天生存期 | 61-184天生存期 |
| 治疗 | 监测，可能使用雷帕霉素 | 呋塞米、ACE抑制剂 | 紧急抗凝治疗 |
| 诊断优先级 | 基因筛查 | NT-proBNP >180 pmol/L | 立即超声心动图检查 |

预防策略侧重于基因筛查和繁殖管理而非疫苗接种，而鉴别诊断必须排除甲状腺功能亢进和高血压。显著的预后差异强调了通过定期筛查进行早期检测的重要性，特别是在易感品种中，以优化长期结果和生活质量。

## 疾病概述

肥厚性心肌病（HCM）是猫最常见的心脏病，大约影响七分之一的猫，绝大多数病例为亚临床[1]。HCM的特征是由于内在心肌疾病引起的原发性向心性左心室肥厚，乳头肌增大是猫的一个一致特征[1]。

该病主要发生在家猫中，很少见于小型犬[1]。HCM并非出生时就存在，而是随时间发展，代表一种进行性疾病[1]。在缅因猫和布偶猫中，该病具有已知的遗传基础，由肌节基因突变引起，特别是心肌肌球蛋白结合蛋白C基因[1]。

病理生理学涉及严重肥厚，常伴有细胞坏死和由此导致的替代性纤维化（心肌瘢痕）[1]。患病率显示HCM影响高达14%的家猫[2]。

从流行病学角度看，各年龄段的猫都可能受影响，从6个月到17岁不等，尽管大多数猫在就诊时处于中年[1]。雄性和雌性猫的易感性相同；然而，雄性猫往往在更早年龄发展成更严重的疾病[1]。该病在许多品种中呈家族性，包括波斯猫、斯芬克斯猫、挪威森林猫、孟加拉猫、土耳其梵猫以及美短和英短[1]。

### Sources
[1] Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Delayed-release rapamycin halts progression of left ventricular hypertrophy: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.04.0187.xml

## 常见病原体

肥厚性心肌病本质上是一种遗传性心脏病而非传染性疾病，通常不是由病毒、细菌或其他传染性病原体引起的[1]。该病的特征是由于内在心肌疾病引起的原发性向心性左心室肥厚[1]。

在人类中，HCM由肌节基因突变引起，类似的突变已在猫中被发现。具体来说，在缅因猫和布偶猫中发现了心肌肌球蛋白结合蛋白C基因的突变，纯合子缅因猫最有可能发展成临床显著的HCM[1]。

然而，某些传染性因素可能导致猫的继发性心脏并发症。心肌炎在伴侣动物中很少见，可由几种病毒和细菌引起，包括犬细小病毒、脑心肌炎病毒和马传染性贫血病毒[2]。虽然心肌炎与HCM不同，但它代表心肌的局灶性或弥漫性炎症，伴有肌细胞变性和坏死[2]。

克氏锥虫通过锥蝽传播，可引起动物查加斯心肌炎，导致急性心电图异常和可能的猝死[2]。虽然治疗方案有限，但这种情况表明某些病原体如何影响心肌，尽管它与肥厚性心肌病的遗传基础仍有区别。

### Sources

[1] Hypertrophic Cardiomyopathy in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

[2] Myocarditis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myocarditis-in-dogs-and-cats

## 临床症状和体征

许多患有肥厚性梗阻型心肌病（HOCM）的猫，特别是那些患有轻度至中度疾病的猫，保持无症状[1]。然而，至少三分之一的HCM猫没有明显的心脏杂音，使得体格检查结果不可靠用于检测[1]。

**典型临床表现**

发展成严重疾病的猫通常表现为呼吸异常，包括由于肺水肿或胸腔积液引起的呼吸急促和呼吸困难[1]。咳嗽在心力衰竭猫中不常见[1]。体格检查经常揭示异常心音，包括轻度至明显的收缩期心脏杂音和/或奔马律[1]。

**听诊发现**

大多数良性杂音相对较轻，而响亮杂音在肥厚性梗阻型心肌病中最常见[2]。在胸骨中部或左心尖处听到的最佳收缩期杂音很常见，通常由二尖瓣收缩期前向运动（SAM）引起[3]。这些杂音通常是动态的，当猫因心率和心肌收缩力增加而兴奋时强度增加[3]。

**品种和年龄模式**

该病发生在6个月至17岁的猫中，尽管大多数猫在就诊时处于中年[1]。雄性猫往往比雌性猫在更早年龄发展成更严重的疾病，尽管两性易感性相同[1]。HCM在许多品种中呈家族性，包括波斯猫、斯芬克斯猫、挪威森林猫、孟加拉猫、土耳其梵猫以及美短和英短[1]。

**进行性体征**

早期舒张功能障碍以心房奔马律为标志，而进行性疾病导致响亮的心室或叠加奔马律和充血性心力衰竭[3]。一些猫可能表现为后肢轻瘫/瘫痪急性发作，伴有急性疼痛以及股动脉脉搏减弱或消失，表明全身性血栓栓塞[1]。

### Sources

[1] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

[2] Back to basics: clinical cardiovascular exam and diagnostic testing: https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings

[3] Hypertrophic cardiomyopathy--getting into the thick of it: https://www.dvm360.com/view/hypertrophic-cardiomyopathy-getting-thick-it-proceedings

## 诊断方法

超声心动图是诊断猫HOCM的金标准[1]。明确的超声心动图标准是舒张末期左心室壁或室间隔厚度>6毫米[1]。多种超声心动图技术是必需的，包括用于检测不对称肥厚的二维成像、用于壁厚测量的M模式以及用于评估二尖瓣收缩期前向运动（SAM）的多普勒研究[1]。

胸部X光片的诊断效用有限，因为它们对检测轻度心脏病不敏感，无法显示向心性心室肥厚[1]。然而，X光片对于评估充血性心力衰竭和计算椎体心脏评分（猫正常值：7.4 ± 0.3）仍然有价值[1]。

心脏生物标志物提供重要的诊断价值。NT-proBNP浓度>180 pmol/L在检测呼吸困难猫的心力衰竭方面显示出高灵敏度（94%）和特异性（86%）[1]。对于患有心肌病的无症状猫，NT-proBNP >70 pmol/L显示87.5%灵敏度和100%特异性[1]。46 pmol/L的临界值可以以86%灵敏度和91%特异性区分正常猫与患有隐匿性心肌病的猫[9]。

心电图对检测HOCM猫的心室肥厚不敏感，但对于评估心律失常仍然必不可少[1]。额外检测必须排除继发性原因，包括收缩压测量和血清甲状腺素浓度以排除高血压和甲状腺功能亢进作为左心室肥厚的原因[1]。缅因猫和布偶猫可进行基因检测以检测特定的肌球蛋白结合蛋白C突变[1]。

### Sources
[1] Current strategies on diagnosis and treatment of feline cardiomyopathy: https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings
[2] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[3] Diagnosis of Cardiovascular Disease in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/diagnosis-of-cardiovascular-disease-in-cats
[4] Hot Literature: Plasma BNP as a screening test for occult cardiomyopathy in cats: https://www.dvm360.com/view/hot-literature-plasma-bnp-screening-test-occult-cardiomyopathy-cats

## 治疗方案

**紧急处理**

对于急性心力衰竭发作，初始紧急治疗遵循F-O-N-S方案：呋塞米用于利尿（猫初始静脉注射2-4 mg/kg，然后每4-6小时静脉或肌肉注射1-2 mg/kg）、氧气补充、硝酸甘油软膏（每4-6小时在无毛区域涂抹¼英寸）以及必要时镇静[3][4]。对于严重收缩功能障碍，可能需要紧急多巴酚丁胺输注（0.5-5 mcg/kg/min静脉注射）[3]。血压监测至关重要，维持平均动脉压高于60 mmHg[2]。

**长期药物治疗**

患有CHF的猫的慢性治疗主要包括呋塞米和ACE抑制剂[1][3]。呋塞米的维持剂量通常是1-2 mg/kg口服，每12-24小时一次[3]。匹莫苯丹（0.25 mg/kg口服，每日两次）可能对没有显著左心室流出道梗阻的猫有益[3]。地尔硫卓（每日三次7.5 mg或每日一到两次30 mg缓释剂）可以改善心肌舒张[4]。当存在严重收缩期前向运动时，阿替洛尔等β受体阻滞剂可能有用[1]。

### Sources
[1] Merck Veterinary Manual Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Blood pressure: a critical factor (Proceedings): https://www.dvm360.com/view/blood-pressure-critical-factor-proceedings
[3] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[4] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings

## 预防措施

肥厚性梗阻型心肌病在猫中主要是一种遗传性疾病，使得传统疫苗接种方案无效[1]。相反，预防策略侧重于基因筛查、繁殖管理和环境调整。

**基因筛查和繁殖指南**

基因检测可用于易患HCM的特定品种，包括缅因猫、布偶猫和英短[1]。繁殖猫应定期进行超声心动图筛查，在繁殖前识别亚临床疾病。主要目标是选择不携带致病基因的繁殖个体，特别是针对肌球蛋白结合蛋白C的突变[4]。

**环境管理**

虽然HCM无法通过环境控制预防，但压力减轻在管理高风险猫方面起着关键作用。环境丰富化、保持平静环境以及避免突然压力源有助于预防亚临床病例的急性发作[3]。定期兽医监测至关重要，建议对老年猫和患有慢性疾病的猫进行更频繁的检查[3]。

**体况管理**

体重监测代表了一种关键的预防策略。每次就诊都应进行体重监测和体况评分，以检测可能表明疾病进展的变化[2]。维持最佳体重可减少心血管压力并改善高风险患者的整体心脏功能[2]。

HCM预防没有特定的疫苗接种方案，因为这不是一种传染病。

### Sources
[1] Should we be screening cats for cardiomyopathy? If so, how?: https://avmajournals.avma.org/downloadpdf/journals/javma/260/13/javma.22.06.0257.xml
[2] Is that cat too fat? Feline obesity and a program for weight loss (Proceedings): https://www.dvm360.com/view/cat-too-fat-feline-obesity-and-program-weight-loss-proceedings
[3] How to make your practice feline friendly (Proceedings): https://www.dvm360.com/view/how-make-your-practice-feline-friendly-proceedings
[4] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

## 鉴别诊断

肥厚性梗阻型心肌病的临床表现与几种其他心脏和全身性疾病有重叠。主要鉴别诊断包括其他形式的猫心肌病、左心室肥厚的继发性原因以及全身性疾病[1]。

**其他心肌病**是最重要的鉴别诊断。限制性心肌病引起类似的舒张功能障碍，但通常显示局灶性心肌纤维化而非向心性肥厚[1]。扩张型心肌病虽然在牛磺酸补充开始后在猫中很少见，表现为收缩力降低和心腔扩张而非增厚[1]。

**继发性肥厚**必须通过综合诊断排除。甲状腺功能亢进常见于中老年猫引起向心性左心室肥厚，使得总甲状腺素测量必不可少[2,3]。全身性高血压，通常继发于慢性肾病或甲状腺功能亢进，也可导致心肌增厚[2,3]。体格检查可能揭示小肾脏或甲状腺结节，提示这些潜在疾病[1]。

**鉴别特征**对于准确诊断至关重要。超声心动图仍然是明确的诊断工具，揭示HCM的特征性向心性肥厚和乳头肌增大[6]。在患有心肌病的猫中，特别是肥厚性心肌病，由于左心室僵硬，可以听到第三和第四心音[2]。仅凭病史和临床发现无法区分心肌病形式，需要超声心动图进行明确分类[1]。

### Sources
[1] ECG remains key diagnostic for cardiomyopathy in cats: https://www.dvm360.com/view/ecg-remains-key-diagnosticfor-cardiomyopathy-cats
[2] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[3] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[6] Hypertrophic Cardiomyopathy in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

## 预后

HCM猫的预后根据疾病严重程度和临床状态差异很大[1]。患有无症状和轻度疾病的猫预后良好，可能多年没有问题[1]。然而，一旦猫发展成充血性心力衰竭（CHF）或动脉血栓栓塞，预后会显著恶化。

患有CHF的猫的生存时间从92到654天不等，而患有HCM和动脉血栓栓塞的猫的平均生存时间从61到184天不等[1]。患有CHF的HCM猫的中位生存时间约为3个月[3]。左心房扩大的程度是一个非常重要的预后指标，并用于指导治疗决策[1]。

高达15%的猫受HCM影响，在9岁以上的猫中发现三分之一，是成年猫死亡的主要原因[2]。一些无症状猫永远不会发展成严重疾病，使得难以预测哪些患者会进展[1]。对于患有心脏病包括HCM的狗，在出现临床症状后的预期寿命通常约为12个月[4]。

生活质量仍然是一个重要考虑因素，因为药物给药可能对主人具有挑战性并可能影响患者福利[1]。最近的治疗进展，包括缓释雷帕霉素治疗，在预防或延迟亚临床HCM猫的进行性左心室肥厚方面显示出前景，可能改善长期结果[2]。

### Sources

[1] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[2] Rapamycin therapy for subclinical HCM in cats is now available through telemedicine: https://www.dvm360.com/view/rapamycin-therapy-for-subclinical-hcm-in-cats-is-available-through-telemedicine
[3] Merck Veterinary Manual Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[4] Top 5 ailments in senior dogs: https://www.dvm360.com/view/top-5-ailments-in-senior-dogs
