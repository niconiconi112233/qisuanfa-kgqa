# 犬猫胸腔积液

胸腔积液是指清晰、非炎性液体在胸腔内的积聚，在伴侣动物中代表一种重要的呼吸系统急症。这种情况主要源于心血管疾病，特别是心力衰竭，而非感染过程。理解胸腔积液对兽医从业者至关重要，因为它需要立即进行干预治疗，同时解决潜在的病理生理问题。本报告探讨了成功治疗结果所必需的临床表现、诊断方法和治疗策略。重点领域包括紧急胸腔穿刺技术、区分胸腔积液与其他胸腔积液的液体分析参数，以及可在危及生命的液体积聚发生前识别高危患者的预防性心脏监测方案。

## 疾病概述

胸腔积液被定义为犬猫胸腔内清晰、低蛋白液体的积聚，代表一种漏出性胸腔积液（默克兽医手册）。当正常的液体产生和吸收机制受到干扰时，通常通过干扰静脉回流、淋巴引流或改变胶体渗透压梯度而发生这种情况。

其病理生理学涉及调节液体跨胸膜运动的斯达林力失衡。在正常情况下，约0.1-0.2 ml/kg的胸腔积液维持胸膜表面润滑（DVM360）。当产生超过吸收能力时，胸腔积液开始发展，最常见于导致静脉压力升高的心血管疾病继发。

从流行病学角度看，胸腔积液影响犬猫，无明显品种偏好，但患有肥厚型心肌病的猫表现出更高的易感性（DVM360）。年龄分布与潜在心脏疾病患病率相关，通常影响中老年动物。在小动物临床实践中，该病症约占所有胸腔积液的15-20%，心脏衰竭是两个物种的主要潜在原因（DVM360）。临床表现通常表明潜在的疾病已进展，因为需要显著的液体积聚（50-60 ml/kg）才会出现呼吸窘迫。

## 常见病原体

资料来源显示，犬猫的胸腔积液本质上是一种非感染性疾病，代表清晰液体的积聚而非微生物入侵。如前所述，胸腔积液主要由"血流或淋巴引流干扰"引起，而非直接的病原性原因[1]。

然而，当检查可能使胸腔积液复杂化的胸腔液体感染时，兽医文献中出现了几种关键的细菌生物。猫传染性腹膜炎（FIP）由突变的猫冠状病毒引起，是导致猫胸腔积液的重要病毒病原体。其发病机制涉及"转化为强毒生物型"，病毒在巨噬细胞内复制，引发显著的炎症反应和积液发展[1]。

当发生继发感染时，细菌病原体变得相关。从胸腔感染中最常分离的好氧细菌包括马链球菌兽瘟亚种、巴斯德菌属、大肠杆菌和放线杆菌属[2]。厌氧细菌的参与虽然较少见，但具有预后意义，通常涉及拟杆菌属、梭菌属和消化链球菌属[2]。

特别在猫中，最近的证据表明，胸腔感染通常源于上呼吸道感染后"口咽细菌的副肺炎感染"，而非之前认为的穿透性创伤[3]。这种理解的转变强调了正常口腔菌群在发展继发并发症中的作用。

### Sources
[1] Merck Veterinary Manual Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[2] Merck Veterinary Manual Pleuropneumonia in Horses: https://www.merckvetmanual.com/en-au/respiratory-system/respiratory-diseases-of-horses/pleuropneumonia-in-horses
[3] DVM 360 Working up pleural effusions in cats (Proceedings): https://www.dvm360.com/view/working-pleural-effusions-cats-proceedings

## 临床症状和体征

胸腔积液表现出特征性呼吸体征，这是由于胸腔积液影响肺扩张所致。主要临床表现为吸气性呼吸困难，因为受压的肺部产生限制性呼吸模式[1]。猫通常表现出呼吸急促，可能进展为张口呼吸、发绀，在严重情况下偏好胸卧位[1][2]。

体格检查显示依赖性肺野的心音和呼吸音减弱或消失，通常在液体积聚开始处有明显的分界线[1]。少量积液可能不会产生可检测的体格变化，需要约30 ml/kg的液体才能改变检查结果[2]。当液体积聚达到50-60 ml/kg时，呼吸窘迫通常变得严重[2]。

单纯性胸腔积液很少出现咳嗽，但当疾病扩展到气道或肺部时可能发生[2]。其他发现取决于潜在病因，可能包括心脏异常、颈静脉扩张或表明全身疾病的腹水[1]。犬猫都会受到影响，尽管临床表现在物种间保持一致[2][3][4]。

### Sources
[1] Working up pleural effusions in cats (Proceedings): https://www.dvm360.com/view/working-pleural-effusions-cats-proceedings
[2] White pleural effusion: Pyothorax and chylothorax (Proceedings): https://www.dvm360.com/view/white-pleural-effusion-pyothorax-and-chylothorax-proceedings
[3] Video cases: ER management of cats in respiratory distress (Proceedings): https://www.dvm360.com/view/video-cases-er-management-cats-respiratory-distress-proceedings
[4] Small animal thoracic radiology: Pulmonary edema vs. pleural effusion (lines and buckets) (Proceedings): https://www.dvm360.com/view/small-animal-thoracic-radiology-pulmonary-edema-vs-pleural-effusion-lines-and-buckets-proceedings

## 诊断方法

犬猫胸腔积液的诊断需要结合临床评估、影像学和液体分析的系统方法。体格检查显示特征性发现，包括心音和呼吸音减弱、吸气性呼吸窘迫以及可能的腹部叩诊浊音[1]。胸腔穿刺既是挽救生命的治疗干预，也是关键的诊断程序，特别是在出现严重呼吸窘迫的猫中，此时放射学约束可能加重病情[2]。

**胸腔穿刺技术**
该操作在第7-9肋间进行，在肋骨前缘插入针头以避免肋间血管[3]。设备包括20-22号针头或蝶形导管、三通开关、延长管和适当的注射器。在大型猫和犬中需要更长的针头[4]。如果时间允许，建议使用利多卡因（1-2 mg/kg）进行局部麻醉[3]。

**液体分析参数**
收集的液体应使用EDTA管进行细胞学分析，并在无菌管中留取额外样本进行生化分析，包括甘油三酯和胆固醇水平。液体分类包括漏出液（<3 g/dl蛋白，<1000个细胞/µl）、改良漏出液（3-5 g/dl蛋白，500-5000个细胞/µl）和渗出液（>3 g/dl蛋白，>5000个细胞/µl）[2]。

**影像学方法**
胸部X光片通过胸膜间隙增宽、可见裂隙线、扇形肺边缘和心脏轮廓模糊来显示胸腔积液[5]。经胸超声检查提供胸腔积液的敏感检测，并可在复杂病例中引导胸腔穿刺[2]。包括CT在内的先进影像学检查可能需要用于完整的胸部评估[6]。

### Sources
[1] Practical critical care techniques (Proceedings): https://www.dvm360.com/view/practical-critical-care-techniques-proceedings
[2] Diagnostic Techniques for Respiratory Disease in Animals: https://www.merckvetmanual.com/respiratory-system/respiratory-system-introduction/diagnostic-techniques-for-respiratory-disease-in-animals
[3] "Stick a needle in it"-How to perform a thoracocentesis: https://www.dvm360.com/view/stick-needle-it-how-perform-thoracocentesis
[4] Managing pleural effusions (Proceedings): https://www.dvm360.com/view/managing-pleural-effusions-proceedings
[5] Radiographic interpretation of the mediastinum and pleural space (Proceedings): https://www.dvm360.com/view/radiographic-interpretation-mediastinum-and-pleural-space-proceedings
[6] Working up pleural effusions in cats (Proceedings): https://www.dvm360.com/view/working-pleural-effusions-cats-proceedings

## 治疗选择

胸腔积液治疗侧重于通过液体移除进行即时稳定和处理潜在原因[1][2]。紧急胸腔穿刺是主要的治疗干预措施，使用蝶形导管或胸管在第7和第9肋间之间进行，同时保持患者处于胸卧位[1]。在操作过程中应提供氧气补充以最小化患者压力[1]。

当大量液体积聚或需要重复胸腔穿刺时，胸管置入变得必要[1][2]。一种更安全的外科技术涉及在置管前进行软组织解剖，以减少对重要胸腔内结构的医源性损伤[2]。胸管通常放置在第8肋间，并向头侧推进沿胸骨放置[2]。

药物治疗包括用于心力衰竭相关积液的利尿剂，特别是呋塞米和螺内酯组合[3]。使用血管扩张剂治疗潜在心脏疾病也可能适用[3]。对于乳糜性积液，当保守治疗失败时，可能需要定期胸腔穿刺或手术胸导管结扎[3][4]。

先进干预措施包括特发性病例的芦丁补充（250-500 mg PO TID）和某些情况的奥曲肽治疗[4]。支持性护理包括保持患者胸卧位以优化肺扩张，并监测并发症如医源性气胸，这在慢性胸膜增厚的患者中更常见[3]。术后X光检查对于确认管位置和监测并发症至关重要[2]。

### Sources
[1] "Stick a needle in it"-How to perform a thoracocentesis - dvm360: https://www.dvm360.com/view/stick-needle-it-how-perform-thoracocentesis
[2] A safer way to place chest tubes - dvm360: https://www.dvm360.com/view/safer-way-place-chest-tubes
[3] Managing pleural effusion (Proceedings): https://www.dvm360.com/view/managing-pleural-effusion-proceedings
[4] White pleural effusion: Pyothorax and chylothorax (Proceedings): https://www.dvm360.com/view/white-pleural-effusion-pyothorax-and-chylothorax-proceedings

## 预防措施

胸腔积液的预防主要集中在管理潜在心血管状况和实施早期检测方案。由于胸腔积液最常见于心脏病继发，特别是猫的肥厚型心肌病，预防工作集中在心血管健康监测上[1]。

定期心脏筛查对高危人群至关重要。有心脏杂音、奔马律或品种倾向的猫应接受超声心动图评估，以在临床症状出现前检测早期结构变化[1]。早期识别肥厚型心肌病允许在心力衰竭和随后的胸腔积液发生前进行干预[2]。

潜在疾病的管理是预防的基石。对于已确诊心肌病的猫，实施适当的心脏药物，包括ACE抑制剂、β受体阻滞剂或钙通道阻滞剂，有助于预防进展为充血性心力衰竭[2][4]。定期监测心脏参数，包括血压、心率和可用时的心脏生物标志物，能够及时调整治疗[4]。

环境改变支持心血管健康。心脏病患者的钠限制和运动限制有助于减少心脏负荷[4]。压力最小化对肥厚型心肌病猫特别重要，因为交感神经刺激可诱发急性心力衰竭发作[1]。

已知心脏病患者的常规监测方案应包括定期评估呼吸频率、体重变化和活动水平[4]。系列超声心动图允许追踪疾病进展并在胸腔积液发展前优化医疗管理[2]。

### Sources
[1] Managing feline cardiomyopathies (Proceedings): https://www.dvm360.com/view/managing-feline-cardiomyopathies-proceedings
[2] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[3] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[4] Treating heart failure (Proceedings): https://www.dvm360.com/view/treating-heart-failure-proceedings

## 鉴别诊断

胸腔积液表现为几种可引起相似临床体征和影像学发现的状况，需要仔细鉴别以准确诊断[1]。主要鉴别诊断包括其他胸腔积液原因和各种胸腔疾病。

**脓胸（肺脓肿）**是最关键的鉴别诊断，特征是脓性胸腔积液，呈现灰白色到"番茄汤"色并有恶臭[1]。细胞学上，脓胸显示变性中性粒细胞和胞内细菌，而胸腔积液主要包含间皮细胞和巨噬细胞，细胞数量极少[1]。

**乳糜胸**表现为乳白色液体，甘油三酯含量超过血清水平[1]。与胸腔积液的清晰外观不同，乳糜胸在发病机制早期显示淋巴细胞为主，随时间推移转变为中性粒细胞和巨噬细胞增加[1]。

**血胸**呈现为红色至浆液血性液体，真正的出血与血液污染的区别在于红细胞吞噬作用和含铁血黄素载巨噬细胞[2]。胸腔积液的改良漏出液缺乏这些出血指标。

**心力衰竭引起的胸腔积液**外观上与胸腔积液相似，但需要心脏评估来区分病因[2]。两种情况都可能表现为具有相似物理特征的改良漏出液[3]。

**慢性膈疝、心包积液、胸腔恶性肿瘤和右中肺叶扭转**代表慢性胸腔积液的重要鉴别诊断，不应被忽视[3]。这些情况可能产生相似的影像学改变，但需要特定的影像学或手术干预才能明确诊断。

单侧积液通常表明由于纵隔隔膜阻塞导致的渗出性过程，有助于与双侧胸腔积液区分[3]。

### Sources
[1] White pleural effusion: Pyothorax and chylothorax: https://www.dvm360.com/view/white-pleural-effusion-pyothorax-and-chylothorax-proceedings
[2] Fluid lesions: Cytology of effusions: https://www.dvm360.com/view/fluid-lesions-cytology-effusions-proceedings
[3] Small animal thoracic radiology: Pulmonary edema vs. pleural effusion: https://www.dvm360.com/view/small-animal-thoracic-radiology-pulmonary-edema-vs-pleural-effusion-lines-and-buckets-proceedings
