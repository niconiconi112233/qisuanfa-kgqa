# 伴侣动物气胸概述

气胸是小动物兽医医学中最危重的呼吸系统急症之一，需要立即识别和干预以防止危及生命的并发症。这种以胸膜腔内异常积气为特征的疾病，可迅速损害犬和猫的呼吸功能及心血管稳定性。其临床意义不仅限于急诊情况，因为不同类型的气胸--创伤性、自发性和医源性--需要不同的诊断方法和治疗方案。本报告探讨了伴侣动物气胸的综合管理，涵盖流行病学模式（包括西伯利亚哈士奇的品种易感性）、急诊诊断技术（如T-FAST方案）、一年生存率达91%的手术干预，以及对稳定病例保守治疗与呼吸功能受损病例立即胸腔穿刺术的关键区别。

## 疾病概述与流行病学

气胸定义为胸膜腔内存在游离空气，破坏正常呼吸功能[1]。正常情况下，胸膜内压力约为-5 cmH2O，但当空气进入此腔隙时，压力迅速平衡，导致肺塌陷和呼吸功能障碍[1]。胸膜腔是肺与胸壁之间的空间，正常情况下不应存在空气[3]。

气胸可分为三大类：创伤性、自发性和医源性[1]。创伤性气胸被认为是犬和猫中最常见的原因，通常由钝性创伤（如车祸）或穿透性伤口（如咬伤）引起[1]。犬似乎比猫更常发生胸部创伤[1]。

自发性气胸在犬中比猫更常见，原发性自发性气胸（由肺大疱或肺疱破裂引起）在犬中有报道，但在猫中未见记录[1]。西伯利亚哈士奇品种被认为对自发性气胸有易感性[4]。继发性自发性气胸可发生于两个物种，在犬中最常与肿瘤相关，在猫中可能与哮喘或心丝虫病相关[1][2]。

医源性气胸是一个未被充分重视的类型，可在兽医操作后发生，特别是在患有慢性渗出的动物中进行胸腔穿刺术后[1]。患有慢性胸腔积液的动物在胸腔穿刺术后发生气胸的可能性要大得多，因为增厚的胸膜在穿刺后可能无法自行封闭[3]。此外，肺吸虫可导致肺大疱形成，从而在受感染动物中引起自发性气胸[5]。

### Sources
[1] DVM 360 Managing pneumothorax (Proceedings): https://www.dvm360.com/view/managing-pneumothorax-proceedings
[2] DVM 360 Coughing cats: Asthma or heartworm? (Proceedings): https://www.dvm360.com/view/coughing-cats-asthma-or-heartworm-proceedings
[3] DVM 360 Pleural space disease (Proceedings): https://www.dvm360.com/view/pleural-space-disease-proceedings
[4] Allen Press Pneumothorax: A Review: https://meridian.allenpress.com/jaaha/article/46/6/385/176642/Pneumothorax-A-Review
[5] Merck Veterinary Manual Lung Flukes in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/lung-flukes-in-dogs-and-cats

## 病因学与分类

伴侣动物的气胸可根据根本原因系统性地分为三大类[1]。

**创伤性气胸**是犬和猫中最常见的类型，由胸部损伤引起，可进一步细分为开放性（连接胸腔与大气的外部伤口）或闭合性形式[1]。钝性创伤如车祸很少需要手术干预，而咬伤等穿透性损伤可能需要手术治疗[1][5]。

**自发性气胸**无创伤发生，进一步分为原发性或继发性。原发性自发性气胸最常见于犬，由肺大疱或肺疱破裂引起，特别影响大型深胸犬，西伯利亚哈士奇占比过高[1][3]。继发性自发性气胸由既存肺部病理发展而来--在犬中，肿瘤是最常见原因；在猫中，炎性气道疾病、哮喘和心丝虫感染是主要原因[1][4]。

**医源性气胸**由兽医操作引起，特别是对患有慢性胸腔积液的患者进行胸腔穿刺术，增厚的胸膜在穿刺后无法自行封闭[1][3]。患有慢性渗出的动物在胸腔穿刺术后发生气胸的可能性要大得多，可能是一种毁灭性并发症[3]。

真菌感染很少导致继发性自发性气胸，特别是当肺实质感染导致受感染组织或囊肿破裂时[6]。

### Sources

[1] Managing pneumothorax (Proceedings): https://www.dvm360.com/view/managing-pneumothorax-proceedings
[2] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[3] Pleural space disease (Proceedings): https://www.dvm360.com/view/pleural-space-disease-proceedings
[4] Causes of Respiratory Disease in Animals: https://www.merckvetmanual.com/respiratory-system/respiratory-system-introduction/causes-of-respiratory-disease-in-animals
[5] Emergency approach to thoracic trauma (Proceedings): https://www.dvm360.com/view/emergency-approach-thoracic-trauma-proceedings
[6] Fungal Pneumonia in Small Animals: https://www.merckvetmanual.com/respiratory-system/fungal-pneumonia-in-small-animals/fungal-pneumonia-in-small-animals

## 临床表现与诊断

犬和猫气胸的临床体征包括呼吸急促、呼吸困难、心动过速和明显疼痛[1]。体格检查发现肺音减弱、呼吸用力增加，在开放性创伤性气胸病例中，可见穿透胸部的明显伤口[1]。许多宠物同时伴有肺挫伤，使确定呼吸窘迫的具体来源变得困难[1]。

诊断基于体格检查怀疑，并通过胸腔穿刺术或放射学检查确认[1]。胸部X线摄影显示胸腔积液、皮下气肿、气胸、纵隔气肿，偶尔可见肋骨骨折[4]。使用超声的T-FAST（创伤胸部聚焦超声评估）方案可快速识别气胸[1]。

放射学上，气胸表现为放射透明度增加，肺从胸壁回缩[2]。使用分布模式细化鉴别诊断：颅腹侧分布提示创伤性原因，而弥漫性分布表示血源性播散[2]。CT成像虽然很少用于气胸的临床诊断，但可提供确诊依据[1]。

只有当宠物出现呼吸功能受损时才应进行胸腔穿刺术，因为稳定的空气会迅速自行吸收而无需干预[1]。鉴别诊断包括肺挫伤、膈疝和低血容量性休克，通过临床表现和影像学发现进行区分[1]。

### Sources
[1] Managing pneumothorax (Proceedings): https://www.dvm360.com/view/managing-pneumothorax-proceedings
[2] Radiographic evaluation of pulmonary patterns and disease (Proceedings): https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[4] Managing dogs with thoracic impalement injuries: A review of nine cases: https://www.dvm360.com/view/managing-dogs-with-thoracic-impalement-injuries-review-nine-cases

## 治疗与管理

急诊稳定首先对出现呼吸功能受损的动物进行胸腔穿刺术[1]。该操作涉及在患者舒适体位下，通过第七肋间隙插入18号针头[3]。当针座内的盐水气泡被胸腔内压力移动时，表明已进入胸膜腔[3]。

保守治疗包括对无呼吸体征的动物进行胸腔穿刺术，因为空气会迅速吸收[1]。对于严重表现（抽吸量>1升）或根据"三振出局"原则复发的气胸，需放置胸腔引流管[1]。

**手术干预**是自发性气胸的确定性治疗方法[9]。原发性自发性气胸需要手术治疗，而未观察到的创伤病例则采用内科治疗[1]。正中胸骨切开术优于肋间开胸术，可提供双侧肺检查的通路，因为75%的犬存在双侧病变[6]。

**疼痛管理**包括布托啡诺（0.2-0.4 mg/kg 静脉注射）联合乙酰丙嗪（0.02-0.05 mg/kg 静脉注射）用于镇静和缓解焦虑[4]。使用布比卡因（犬<2 mg/kg，猫<1 mg/kg）进行局部麻醉阻滞，可有效实现肋间和胸膜内麻醉[9]。

**支持性护理**包括通过流氧、鼻导管或氧舱进行氧疗，维持O2、CO2、湿度和温度的环境监测[4]。术后监测包括胸腔引流管管理，直至空气停止逸出[9]。

### Sources
[1] Managing pneumothorax (Proceedings): https://www.dvm360.com/view/managing-pneumothorax-proceedings
[2] Initial Triage and Resuscitation of Small Animal Emergency Patients: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/evaluation-and-initial-treatment-of-small-animal-emergency-patients/initial-triage-and-resuscitation-of-small-animal-emergency-patients
[3] Emergency thoracentesis: https://www.dvm360.com/view/emergency-thoracentesis
[4] "Stick a needle in it"-How to perform a thoracocentesis: https://www.dvm360.com/view/stick-needle-it-how-perform-thoracocentesis
[5] Surgical management and outcome of dogs with primary spontaneous pneumothorax: https://avmajournals.avma.org/view/journals/javma/258/11/javma.258.11.1229.xml
[6] Thoracic surgery (part 2) (Proceedings): https://www.dvm360.com/view/thoracic-surgery-part-2-proceedings

## 预防与预后

**预防**
气胸的预防措施有限，因为大多数病例是创伤性或自发性，没有可识别的可预防风险因素[1]。对于创伤性病例，避免高风险活动（如猫无人看管的户外活动）和运输时对犬进行适当约束可能降低发生率[2]。在手术病例中，在初次手术时仔细胸部探查以识别所有大疱病变可防止早期复发[3]。

**预后**
预后因气胸类型而异[2][3]。创伤性气胸预后良好，因为它通常随时间和内科治疗而消退，结果往往更多地取决于并发损伤而非气胸本身[2]。

对于手术治疗的自发性气胸，长期预后通常良好。在一项对110只原发性自发性气胸犬的大型研究中，一年生存率为91%，两年和五年生存率均为90%[3]。然而，复发显著影响预后--无复发的犬中位生存期为77个月，而复发的犬仅为5.5个月[3]。

手术治疗的病例中有13%发生复发，主要在术后30天内（可能反映了初次病变切除不完全而非新病变发展）。30天后的长期复发率很低，仅为3%[3]。

### Sources
[1] Managing pneumothorax (Proceedings): https://www.dvm360.com/view/managing-pneumothorax-proceedings
[2] Managing thoracic trauma (Proceedings): https://www.dvm360.com/view/managing-thoracic-trauma-proceedings-0
[3] Surgical management and outcome of dogs with primary spontaneous pneumothorax: 110 cases (2009-2019): https://avmajournals.avma.org/view/journals/javma/258/11/javma.258.11.1229.xml
