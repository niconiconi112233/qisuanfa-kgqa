# 伴侣动物低蛋白血症

低蛋白血症是兽医医学中的一个重要综合征，其特征是血液蛋白浓度异常降低，可能导致犬和猫出现危及生命的并发症。这种情况是影响蛋白质生成、吸收或通过胃肠道、肾脏或肝脏等各种途径丢失的潜在疾病的临床指标。

本综合报告探讨了低蛋白血症的多方面性质，涵盖了感染性和非感染性原因、包括专门检测方案在内的诊断方法以及循证治疗策略。关键领域包括品种特异性易感性、胶体疗法和免疫抑制方案的作用，以及影响生存结果的预后因素，为兽医从业者提供了管理这种复杂临床综合征的基本知识。

## 预后

低蛋白血症的预后因潜在病因和干预时机而有很大差异。虽然蛋白丢失性肾病历史上的中位生存期仅为一个月，但ACE抑制剂治疗已将无肾衰竭犬的生存期延长至1-2年。在蛋白丢失性肠病中，75%的犬能够度过关键的第一个月，尽管严重的低白蛋白血症并不一定比轻度病例预示更差的结果。

| 疾病 | 生存率 | 关键预后因素 |
|-----------|---------------|------------------------|
| 蛋白丢失性肠病 | 1个月时75% | 对治疗的反应，潜在原因 |
| 蛋白丢失性肾病 | 使用ACE抑制剂1-2年 | 是否存在肾衰竭 |
| 猫肝脂质沉积症 | 50-85% | 年龄，神经系统症状，代谢参数 |
| 肠道淋巴瘤 | 2周-2个月 | 肿瘤负荷，治疗反应 |

早期诊断和针对潜在原因的靶向治疗仍然是决定患者结果的最关键因素。患有食物反应性肠病的犬比需要长期免疫抑制治疗的犬显示出更好的预后，强调了识别可治疗潜在疾病的重要性。

## 疾病概述

低蛋白血症定义为血液中蛋白质浓度异常降低，特别是影响白蛋白和球蛋白水平[1]。这种情况代表的是一种综合征而非疾病本身，由多种病理生理机制引起，包括蛋白质生成减少、蛋白质丢失增加或蛋白质分解增加[1]。

流行病学背景显示，低蛋白血症通常继发于蛋白丢失性肠病（PLE）和蛋白丢失性肾病（PLN）。PLN在犬中可能相当常见，而猫的发病率较低[2]。常见原因包括肠道淋巴管扩张症、炎症性肠病、吸收不良综合征和肝病[3]。在犬中，与肾小球肾炎相关的疾病包括心丝虫病、埃里希体病、莱姆病和细菌感染，而慢性炎症性疾病也可导致低蛋白血症[2]。

病理生理机制涉及通过多种途径的蛋白质丢失。在蛋白丢失性肠病中，肠道黏膜屏障的破坏使血浆蛋白，特别是白蛋白，泄漏到肠腔中[3]。在蛋白丢失性肾病中，肾小球损伤使蛋白质过滤到尿液中[2]。结果是全蛋白减少症，这降低了血管内胶体渗透压并导致液体在血管外积聚[3]。

### Sources

[1] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[2] Protein losing nephropathy (Proceedings): https://www.dvm360.com/view/protein-losing-nephropathy-proceedings
[3] Care of dogs with protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/protein-losing-enteropathy-proceedings

## 常见病原体

犬和猫的低蛋白血症由各种传染性病原体引起，这些病原体破坏胃肠道屏障，导致蛋白质丢失。了解这些病原体对于正确诊断和治疗至关重要。

**病毒病原体**是蛋白丢失性疾病的重要贡献者。犬细小病毒（CPV）引起严重的肠隐窝上皮破坏，导致伴有低白蛋白血症的蛋白丢失性肠病[2]。该病毒优先 targeting 快速分裂的细胞，导致绒毛萎缩和肠道屏障功能受损。猫泛白细胞减少症病毒同样影响猫，引起肠上皮坏死并通过受损黏膜导致随后的蛋白质丢失[7]。

**细菌原因**包括致病菌株如沙门氏菌属和空肠弯曲杆菌，它们通过直接入侵和毒素产生损害肠上皮[1][4]。小肠细菌过度生长也可通过胆汁盐去结合和细菌对营养物质的竞争导致蛋白质吸收不良。当原发性病毒或炎症性疾病损害肠道屏障时，会发生继发性细菌移位[2][6]。

**真菌感染**，特别是荚膜组织胞浆菌，可通过肠组织的肉芽肿性炎症引起蛋白丢失性肠病[8][9]。这种生物体产生慢性炎症病变，破坏正常的蛋白质吸收并增加肠道通透性。

**寄生虫生物**通常通过各种机制导致低蛋白血症。钩虫引起直接失血和肠道炎症，而贾第鞭毛虫属损害绒毛结构并损害蛋白质吸收[4][6]。并发寄生虫感染常常加剧其他原因的蛋白质丢失，并且经常与细小病毒等病毒感染同时发现。

### Sources
[1] Probioticcs and GI health (Proceedings): https://www.dvm360.com/view/probioticcs-and-gi-health-proceedings
[2] Treatment of severe parvoviral enteritis (Proceedings): https://www.dvm360.com/view/treatment-severe-parvoviral-enteritis-proceedings
[3] Specialty feedings tubes for nutritional support in critically ill...: https://www.dvm360.com/view/specialty-feedings-tubes-nutritional-support-critically-ill-patients-proceedings
[4] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[5] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[6] Merck Veterinary Manual Canine Parvovirus Infection: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/canine-parvovirus
[7] Merck Veterinary Manual Feline Panleukopenia: https://www.merckvetmanual.com/infectious-diseases/feline-panleukopenia/feline-panleukopenia
[8] DVM 360 Care of dogs with protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/care-dogs-with-protein-losing-enteropathy-proceedings
[9] DVM 360 Protein-losing enteropathies (Proceedings): https://www.dvm360.com/view/protein-losing-enteropathies-proceedings-0

## 临床症状和体征

犬和猫的低蛋白血症表现出多样的临床表现，这些表现因严重程度和潜在病因而有显著差异。典型的临床症状主要源于胶体渗透压降低和蛋白质丢失[1]。

**典型临床表现**

最一致的发现是体重减轻和嗜睡，通常伴有可变的胃肠道症状，包括呕吐和腹泻[1][6]。然而，腹泻并非普遍存在，其 absence 不应排除蛋白丢失性疾病[1]。许多犬表现出非特异性症状如厌食，而其他犬可能 paradoxically 表现出多食[1]。

**液体积聚体征**

当血清白蛋白降至1.5 g/dl以下时，通常会出现腹水、皮下水肿和胸腔积液，尽管纯漏出液可能在较高的白蛋白浓度时发生[1][6]。这些积液通常表现为低蛋白含量和少量有核细胞的纯漏出液。乳糜胸可能继发于肠道淋巴管扩张症[1]。

**品种特异性模式**

某些品种对蛋白丢失性疾病表现出易感性。巴仙吉犬、伦德猎犬、软毛麦色梗、中国沙皮犬、罗威纳犬、德国牧羊犬和约克夏梗对蛋白丢失性肠病表现出易感性增加[1][6]。值得注意的是，巴仙吉犬可能发展为伴有高胃泌素血症的严重溃疡性胃肠结肠炎，而麦色梗通常伴有并发的蛋白丢失性肾病[6]。

**物种差异**

尽管组织学诊断有重叠，但犬比猫更常受影响。在猫中，低蛋白血症可能仅表现为呕吐作为唯一的胃肠道症状，而不伴有腹泻[7]。

**并发症**

严重病例可能发展为血栓栓塞性疾病，表现为因肺血栓栓塞引起的呼吸急促和呼吸困难[1]。50-85%的蛋白丢失性肾病犬会出现高血压[3]。

### Sources

[1] Protein-losing enteropathies (Proceedings): https://www.dvm360.com/view/protein-losing-enteropathies-proceedings
[2] Chronic Enteric Disease and Hypoproteinemia in 9 Dogs: https://avmajournals.avma.org/view/journals/javma/163/3/javma.1973.163.03.262.xml
[3] Protein losing nephropathy (Proceedings): https://www.dvm360.com/view/protein-losing-nephropathy-proceedings
[4] Glomerular Disease in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/glomerular-disease-in-small-animals
[5] Exocrine pancreatic insufficiency in dogs and cats: https://avmajournals.avma.org/downloadpdf/view/journals/javma/262/2/javma.23.09.0505.pdf
[6] Protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/protein-losing-enteropathy-proceedings
[7] Inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings
[8] Description of clinical findings, diagnosis, and treatment of: https://avmajournals.avma.org/view/journals/javma/263/8/javma.24.08.0560.xml

## 诊断方法

低蛋白血症的诊断需要系统定位以确定潜在原因[1]。初步检查从全面的血液检查开始，包括全血细胞计数（CBC）、含电解质的生化面板和尿液分析[1]。尿液分析是定位的基石 - 如果尿蛋白:肌酐比值（UPC）超过1.5，肾脏可能是来源，而较低的值提示肠道或肝脏原因[1]。

额外的实验室检测包括胆汁酸刺激试验，水平超过50表明肝脏疾病[1]。血清总蛋白和白蛋白浓度应同时测量，因为白蛋白或球蛋白浓度降低并不总是导致总蛋白的可检测变化[3]。应通过肝酶评估和尿液分析来研究肝脏或肾脏蛋白质丢失[5]。

影像学研究提供有价值的诊断信息。腹部超声可以显示肠壁增厚、表现为高回声模式的扩张乳糜管和肿块[1][4]。内窥镜检查允许可视化胃肠道黏膜并从胃、十二指肠、回肠和结肠收集多个活检样本[4]。对于确诊，腹腔镜或手术活检可能更受青睐，特别是在较小的患者中[1]。组织样本应提交用于组织病理学检查和培养，并保存额外样本以备需要时进行专门检测[1]。

### Sources
[1] A stepwise approach to hypoalbuminemia: https://www.dvm360.com/view/a-stepwise-approach-to-hypoalbuminemia
[2] Choosing the best tests to diagnose feline hyperthyroidism: https://www.dvm360.com/view/choosing-best-tests-diagnose-feline-hyperthyroidism
[3] Interpreting protein concentrations takes investigative work: https://www.dvm360.com/view/interpreting-protein-concentrations-takes-investigative-work
[4] Care of dogs with protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/care-dogs-with-protein-losing-enteropathy-proceedings
[5] Plugging the protein faucet in dogs with PLE: https://www.dvm360.com/view/plugging-the-protein-faucet-in-dogs-with-ple

## 治疗选择

低蛋白血症的治疗需要多方面的方法，既针对潜在原因，也包括支持性管理。胶体疗法构成急性管理的基石，在许多情况下，合成胶体优于血浆。胶体溶液可以以犬5 mL/kg和猫2-5 mL/kg的剂量在5分钟内给药，以快速恢复血管内容量[1]。合成胶体如羟乙基淀粉特别有价值，因为它们在血管内停留时间比白蛋白更长，并且与血浆蛋白相比，不太可能通过受损的肠黏膜泄漏[2]。

当炎症性肠病是蛋白质丢失的基础时，免疫抑制治疗是必不可少的。犬使用泼尼松龙1 mg/kg，每日两次，提供一致的抗炎效果[3]。最近的研究表明，对于治疗伴有蛋白丢失性肠病的慢性肠病，苯丁酸氮芥-泼尼松龙组合可能比硫唑嘌呤-泼尼松龙方案更有效[6]。布地奈德提供了一种替代选择，具有减少全身吸收和较少副作用的特点[7]。替代性免疫抑制药物包括环孢素，5 mg/kg每12小时一次，持续2周，然后如果临床改善则每24小时一次；以及霉酚酸酯，7-20 mg/kg每12小时一次，持续3-4周[8]。

在严重的低蛋白血症病例中可能需要手术干预。当白蛋白水平≤2.0 g/dL时，应使用不可吸收的缝线如聚丙烯或尼龙进行肠切开术闭合，因为低蛋白血症患者的愈合受损[9]。黏膜下层提供肠修复的主要保持强度，使正确技术至关重要[9]。

饮食管理起着关键作用，专门的低脂饮食对淋巴管扩张症病例有益，而低过敏性饮食对炎症性疾病有帮助[7]。支持性护理包括使用甲硝唑或泰乐菌素的抗生素治疗，特别是当存在腹泻时[7]。维生素补充，特别是钴胺素（维生素B12），解决常见的缺乏症，这些缺乏症可能损害肠道愈合并持续蛋白质丢失[6]。

### Sources

[1] The Fluid Resuscitation Plan in Animals - Therapeutics: https://www.merckvetmanual.com/therapeutics/fluid-therapy/the-fluid-resuscitation-plan-in-animals
[2] Approach to hypoalbuminemia (Proceedings): https://www.dvm360.com/view/approach-hypoalbuminemia-proceedings
[3] Guidelines for augmentation of circulating blood vome: https://www.dvm360.com/view/guidelines-augmentation-circulating-blood-vome-shock-fluid-therapy-proceedings
[4] IVECCS 2017: Treating Hypoalbuminemia in Dogs: https://www.dvm360.com/view/iveccs-2017-treating-hypoalbuminemia-in-dogs
[5] Practical tips for fluid and colloid therapy (Proceedings): https://www.dvm360.com/view/practical-tips-fluid-and-colloid-therapy-proceedings
[6] Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals
[7] Plugging the protein faucet in dogs with PLE: https://www.dvm360.com/view/plugging-the-protein-faucet-in-dogs-with-ple
[8] Immunosuppressive Drugs in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/immunosuppressive-drugs-in-animals
[9] Enterotomy: Small intestinal anastomosis (Proceedings): https://www.dvm360.com/view/enterotomy-small-intestinal-anastomosis-proceedings

## 预防措施

在现有的全面疫苗接种和饮食管理协议基础上，低蛋白血症的预防策略扩展到增强监测方案和针对通常进展为蛋白质丢失的特定疾病的靶向干预。由于低蛋白血症通常表现为继发性疾病，预防的重点是在发生显著蛋白质耗竭之前管理潜在疾病。

**高风险疾病的增强监测**

除了品种特异性监测外，患有蛋白丢失性肠病的患者需要钴胺素监测和补充方案。血清钴胺素缺乏在PLE患者中常见，并可能导致持续性腹泻[1]。每周钴胺素注射（50 μg/kg至1000 μg皮下）持续六周，然后每两周一次，有助于预防营养并发症[1]。在接受免疫抑制治疗的患者中定期监测白蛋白有助于在临床表现发展前检测早期蛋白质丢失。

**血栓栓塞预防方案**

患有严重低蛋白血症的犬面临增加的血栓栓塞风险，特别是那些白蛋白水平低于1.5 g/dl且有活动性炎症证据的犬[1]。低剂量阿司匹林（0.5-1 mg/kg，每日两次）提供抗血小板作用作为预防性治疗[1]。氯吡格雷等替代药物提供理论上的益处，但需要个体病例评估[1]。

**专门的营养管理**

对于肠道淋巴管扩张症病例，中链甘油三酯补充可能减少淋巴流量，同时保持热量摄入和脂溶性维生素吸收[1]。然而，中链甘油三酯在减少淋巴容量方面的有效性在犬中尚未确定[1]。低蛋白血症的最佳治疗仍然是通过及时诊断和靶向治疗解决潜在原因[2]。

### Sources
[1] Protein-losing enteropathies (Proceedings): https://www.dvm360.com/view/protein-losing-enteropathies-proceedings-0
[2] A stepwise approach to hypoalbuminemia: https://www.dvm360.com/view/a-stepwise-approach-to-hypoalbuminemia

## 鉴别诊断

将低蛋白血症与其他具有重叠症状的疾病区分开来需要系统评估蛋白质丢失模式和实验室检查结果[1]。主要鉴别诊断包括蛋白丢失性肠病（PLE）、蛋白丢失性肾病（PLN）和肝功能不全[1]。

**蛋白丢失性肠病**通常表现为影响白蛋白和球蛋白的全蛋白减少症[8]。血清球蛋白水平在PLE中往往降低[5]。临床症状可能包括腹泻、呕吐和体重减轻，尽管一些PLE犬可能没有胃肠道症状[1]。约克夏梗、软毛麦色梗和挪威伦德猎犬表现出品种易感性[1]。

**蛋白丢失性肾病**特征性地引起低白蛋白血症，而血清球蛋白保持正常[5]。尿蛋白:肌酐比值大于2.0表明显著的尿蛋白丢失[4]。患有PLN的犬可能发展为高血压和血栓栓塞并发症[4]。

**肝功能衰竭**通常表现为伴有高球蛋白血症的低白蛋白血症[5]。额外的实验室变化包括高胆红素血症、肝酶升高、低血糖和低血清尿素[5]。当其他标志物不确定时，胆汁酸测试有助于确认肝功能不全[5]。

**区分性实验室因素**包括尿液分析结果、蛋白:肌酐比值、血清球蛋白模式和肝功能测试[9]。正常尿液分析且UPC小于1.5排除PLN，而胆汁酸超过50提示肝脏原因[9]。蛋白质丢失模式 - 全蛋白减少症与选择性低白蛋白血症 - 提供关键的诊断方向[8]。

### Sources
[1] Care of dogs with protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/care-dogs-with-protein-losing-enteropathy-proceedings
[4] Protein losing nephropathy (Proceedings): https://www.dvm360.com/view/protein-losing-nephropathy-proceedings
[5] Hypoalbuminemia (Proceedings): https://www.dvm360.com/view/hypoalbuminemia-proceedings
[8] Diagnostic approach to chronic diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[9] A stepwise approach to hypoalbuminemia: https://www.dvm360.com/view/a-stepwise-approach-to-hypoalbuminemia

## 预后

犬和猫低蛋白血症的预后因潜在原因、蛋白质丢失严重程度和干预时机而有显著差异。在蛋白丢失性肾病（PLN）中，历史中位生存时间以前被认为较差，约为1个月[1]。然而，随着ACE抑制剂治疗的出现，无肾衰竭的PLN犬的生存期已经延长，目前在临床实践中1到2年的生存时间很常见[1]。

对于蛋白丢失性肠病（PLE），大约75%的犬能够度过关键的第一个月，尽管低白蛋白血症的程度与生存结果没有直接相关性[2]。轻度低蛋白血症的犬不一定比严重蛋白质丢失的犬表现更好[2]。继发于肠道淋巴瘤的低白蛋白血症犬的生存时间明显缩短，范围从2周到2个月[2]。

在猫肝脂质沉积症中，生存率从50%到85%不等，住院期间血清β-羟丁酸降低与生存相关[3]。不良预后发现包括年龄较大、精神沉郁、虚弱、流涎、低蛋白血症、低白蛋白血症、肌酸激酶升高、低胆固醇血症、就诊时肝功能衰竭、贫血和低钾血症[3]。

几个因素影响预后，包括是否存在肾衰竭、对治疗的反应以及识别和治疗潜在原因的能力。患有食物反应性肠病的犬通常比需要免疫抑制治疗的犬有更好的结果[2]。在潜在原因可以成功管理的情况下，蛋白质丢失的解决是可能的，尽管这种情况不常见[1]。

### Sources

[1] Protein losing nephropathy (Proceedings): https://www.dvm360.com/view/protein-losing-nephropathy-proceedings
[2] Plugging the protein faucet in dogs with PLE: https://www.dvm360.com/view/plugging-the-protein-faucet-in-dogs-with-ple
[3] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies
