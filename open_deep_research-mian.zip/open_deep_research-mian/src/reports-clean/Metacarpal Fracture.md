# 伴侣动物掌骨骨折

掌骨骨折是影响犬猫前肢骨骼（连接腕骨与趾骨）的严重创伤性损伤。这些骨折通常由汽车创伤、挤压伤和跌倒引起，小型犬种因其骨骼尺寸较小而特别易感。掌骨骨折的临床管理已显著发展，近期证据表明，保守治疗方法可能取得与手术干预相当的效果，同时提供更快的愈合率和更少的并发症。本报告探讨了掌骨骨折的全面临床处理方法，涵盖诊断策略、从外部固定到内部固定的治疗方式，以及影响小动物患者成功恢复的预后因素。

## 疾病概述

掌骨骨折是影响犬猫前肢掌骨的创伤性骨骼损伤。这些骨折是指前爪中连接腕骨与指骨的五根长骨发生断裂[1]。由于骨骼尺寸较小且与大型犬种相比更脆弱，掌骨骨折常见于小型犬种和猫[2]。

掌骨骨折是犬类常见损伤，通常由汽车创伤、被踩踏或爪子被卡在硬物下引起[4]。掌指关节在正常活动期间承受高负荷，使其容易发生过载损伤，特别是在赛跑和运动动物中[1]。在运动犬中，掌骨损伤可因跌倒而急性发生，也可因飞球和敏捷等活动的重复应力而慢性发生[3]。

掌骨骨折比跖骨骨折更常见，涉及四根或更多掌骨的骨折比单骨骨折更频繁[4]。这些骨折通常影响承重骨（第3和第4掌骨），并且由于骨骼尺寸微小，在小动物中呈现独特的手术挑战[2][4]。

### Sources
[1] Structural characterization of subchondral bone in the metacarpophalangeal joint: https://avmajournals.avma.org/view/journals/ajvr/69/11/ajvr.69.11.1413.pdf
[2] Fracture Repair in Toy Breed Dogs & Cats: https://www.dvm360.com/view/fracture-repair-toy-breed-dogs-cats
[3] Chronic injury and poor performance in sporting dogs with forelimb injuries: https://www.dvm360.com/view/chronic-injury-and-poor-performance-sporting-dogs-with-forelimb-injuries-proceedings
[4] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management

## 临床症状和体征

犬猫掌骨骨折表现出不同的临床表现，这些表现因骨折严重程度、位置和慢性程度而异。最常见的表现体征是急性发作的跛行，从轻度承重到完全不能承重不等[1]。动物通常表现出不愿行走，有些出现急性嗜睡和全身性疼痛[1]。

体格检查显示受影响的掌骨上有局部肿胀和疼痛。直接触诊骨折部位会引起疼痛反应，活动腕骨通过活动范围可能会加剧不适[1]。在严重情况下，爪子可能出现明显畸形，特别是移位性骨折[2]。

跛行程度与骨折严重程度和位置相关。单根掌骨骨折通常表现为轻度至中度跛行，而多根掌骨骨折或涉及承重骨（第III和第IV掌骨）的骨折通常引起更严重的临床症状[3]。慢性病例可能出现继发性并发症，包括关节僵硬和肌肉萎缩[2]。

常见的创伤原因包括汽车事故、被踩踏或爪子被卡在硬物下[3]。创伤性掌骨骨折的品种特异性模式尚未得到充分记录，尽管某些品种在先天性掌骨异常方面表现出易感性。大型犬在影响掌骨的发育性疾病中似乎更常见受影响[4]。

### Sources

[1] Juvenile orthopedic diseases (Proceedings): https://www.dvm360.com/view/juvenile-orthopedic-diseases-proceedings
[2] Merck Veterinary Manual Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[3] DVM 360 Surgery STAT: Metacarpal and metatarsal fractures: conservative or surgical management?: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[4] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings

## 诊断方法

犬猫掌骨骨折的诊断依赖于临床评估和影像技术的系统结合[1]。患有掌骨损伤的犬通常表现出不同程度的跛行，从急性不能承重到慢性进行性跛行，取决于骨折严重程度[1]。

体格检查显示关键发现，包括软组织肿胀、触诊疼痛、操作时骨擦音、活动范围减小以及在伸展、屈曲或旋转运动时应力下的关节不稳定[1]。将受影响的肢体与对侧正常肢体进行比较有助于区分异常和正常的运动模式。

放射学评估仍然是主要的诊断影像模式。标准正交视图（背掌位和侧位投影）可有效识别骨折、脱位和移位模式[2]。骨折的临床体征总是包括跛行、疼痛和肿胀，放射学检查有助于描绘骨折模式[3]。应力放射照片可以通过在操作肢体时显示异常关节间隙张开来证明韧带完整性[1]。

当标准放射照片不确定时，先进影像技术提供了增强的诊断能力。荧光透视允许实时评估关节运动，并可检测静态放射照片上不可见的细微半脱位或异常滑动[1]。CT成像为复杂骨折模式提供卓越细节，并可识别放射学上不明显的软组织肿胀和骨骼变化[4]。CT在描绘关节骨折和复杂创伤模式方面特别有用[4]。

当腕骨或掌骨疼痛存在但没有明显的放射学异常时，MRI证明是有价值的，特别是用于诊断轻微韧带扭伤或软组织损伤[1]。

### Sources
[1] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings
[2] Surgery STAT: Metacarpal and metatarsal fractures: conservative or surgical management?: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[3] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[4] Joint Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 治疗选择

掌骨骨折的治疗涉及保守管理和手术方法，选择基于骨折特征和患者因素。保守管理采用闭合复位和外部固定，使用软垫绷带和刚性夹板[1]。放置在掌侧的勺形夹板为掌骨骨折提供刚性支撑，而放射照片确认复位后的解剖对齐[1]。

手术干预适用于特定病例，包括远端和关节内骨折、单独固定无法充分对齐、单肢上两根或更多掌骨骨折，或涉及主要承重骨（第3和第4掌骨）[1]。内固定技术包括顺行穿过远端段的髓内针、用于斜行骨折的拉力螺钉固定，以及使用1.5-2.0mm系统的小骨板稳定[1]。

外骨骼固定常用于复杂病例，提供良好的稳定同时允许伤口处理[3]。术后管理无论固定方法如何都需要外部固定6-8周，每10-14天更换绷带，每四周进行放射学监测[1][3]。近期研究表明，保守管理通常取得与手术修复相当的结果，且可能具有更快的愈合率[1]。

### Sources

[1] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[2] Joint Trauma in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[3] Postoperative management of external fixators in dogs and cats: https://www.dvm360.com/view/postoperative-management-external-fixators-dogs-and-cats

## 预防措施

环境管理策略对于预防小动物掌骨骨折至关重要。创伤预防应侧重于控制高风险活动和环境，因为骨折通常发生在年轻健康的犬猫发生机动车事故后[1]。限制无人监督的户外活动，特别是在道路附近，代表了主要的预防措施。

对于工作犬和运动动物，适当的训练计划和渐进性活动进展有助于加强支撑结构。环境危害识别和清除，包括尖锐物体和不稳定表面，可降低受伤风险[3]。具有适当地面的安全运动区域可最大限度地减少玩耍和训练活动中的创伤事件。

创伤损伤的初始管理旨在缓解焦虑、固定骨折或脱位以便运输、防止进一步组织损伤并实现安全运输[10]。应建立紧急固定协议，以便在发生骨折时立即稳定。

## 鉴别诊断

掌骨区域跛行需要与几种骨科疾病进行鉴别。籽骨疾病表现出类似的承重跛行，但通常在掌侧/跖侧籽骨上显示特征性的放射学变化[6]。趾垫损伤和趾间异物引起局部疼痛，但缺乏放射学上显示的特定掌骨变化。

其他鉴别诊断包括软组织创伤、肌腱损伤和影响掌指关节的炎症性疾病[10]。肿瘤过程，特别是侵袭性骨病变，在具有进行性跛行和放射学骨破坏的病例中必须考虑[6]。仔细的放射学评估和临床检查有助于区分这些疾病和真正的掌骨骨折。

### Sources
[1] Assessment and management of pelvic fractures in dogs and cats: https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[2] Combined intramedullary and external skeletal fixation of metatarsal and metacarpal fractures in 12 dogs and 19 cats: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[3] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/249/10/javma.249.10.1135.xml
[4] Trauma and First Aid in Horses - Emergency Medicine: https://www.merckvetmanual.com/en-au/emergency-medicine-and-critical-care/equine-emergency-medicine/equine-trauma-and-first-aid

## 预后和并发症

犬猫掌骨骨折的预后通常良好，通过保守和手术管理方法均可取得成功结果[1]。恢复取决于几个关键预后因素，包括骨折模式、涉及的骨骼数量、患者年龄和健康状况以及选择的治疗方式。

单独使用外部固定的保守管理在正确应用时表现出良好的临床结果和最小并发症。一项比较研究显示，保守管理和内固定之间的临床结果和并发症率几乎没有差异，保守治疗显示出更快的愈合率[1]。在涉及1-4根掌骨骨折且具有充分解剖对齐的病例中，成功率特别有利。

常见并发症包括延迟愈合、畸形愈合以及使用内固定时的植入物相关问题。手术方法可能损害血液供应，可能导致延迟愈合、感染和植入物上皮肤坏死[1]。不良骨愈合并发症（延迟愈合、畸形愈合和再骨折）在小动物骨折病例中报告约为10.9%[2]。开放性骨折带来额外的感染风险，需要延长抗生素治疗。

通过适当的治疗和康复，长期功能结果通常优秀。物理治疗对于恢复肢体功能和整体健康至关重要[3]。每四周间隔的定期放射学监测确保适当的愈合进展和早期发现并发症[1]。

### Sources
[1] Surgery STAT: Metacarpal and metatarsal fractures - dvm360: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[2] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[3] Bone Trauma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
