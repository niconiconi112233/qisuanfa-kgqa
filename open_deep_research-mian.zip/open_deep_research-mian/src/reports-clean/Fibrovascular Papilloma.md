# 伴侣动物中的纤维血管乳头状瘤

纤维血管乳头状瘤是影响老年犬的良性皮肤生长物，表现为具有花椰菜样表面的独特带蒂病变。与年轻动物中观察到的病毒性乳头状瘤不同，这些皮肤标签（软垂疣）代表非传染性结缔组织肿瘤，治疗后预后极佳。本报告探讨了小动物临床实践中纤维血管乳头状瘤的临床表现、诊断方法和治疗策略，强调其与恶性口腔和皮肤肿瘤的鉴别。主要发现包括大型犬的品种易感性、无恶性转化潜力，以及通过各种手术干预（包括切除术、电外科手术和冷冻治疗）取得的高成功率。

## 疾病概述

**定义**

纤维血管乳头状瘤，也称为软垂疣、皮肤标签或软纤维瘤，是独特的良性皮肤病变，特征为具有丰富纤维结缔组织和血管的带蒂外生性生长物[1]。这些良性成纤维细胞肿瘤是伴侣动物中常见的皮肤生长形式，特别影响老年犬。

**流行病学背景**

纤维血管乳头状瘤是犬的常见病变，通常出现在没有特定性别偏好的老年动物中[1]。大型犬品种发生这些病变的风险可能增加，但任何品种都可能发生[1]。病变可能是单个或多个，可在身体任何部位发展，但最常表现为具有疣状表皮表面的带蒂生长物[1]。

相比之下，猫的纤维血管乳头状瘤在兽医文献中很少报道。该病表现出明显的年龄倾向，主要影响老年犬，使其成为老年犬患者皮肤肿块的重要鉴别诊断[1]。发生一个纤维血管乳头状瘤的犬倾向于随时间发展出更多病变，这表明存在遗传易感性或促进其形成的共同潜在因素[1]。

### Sources

[1] Connective Tissue Tumors in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 常见病原体

犬和猫的纤维血管乳头状瘤由乳头瘤病毒科内的种特异性乳头瘤病毒引起[1]。这些无包膜的双链DNA病毒表现出严格的宿主特异性，并对快速分裂的上皮细胞具有特殊的嗜性。

在犬中存在多种犬乳头瘤病毒类型，包括犬口腔乳头瘤病毒和犬乳头瘤病毒2型[1]。这些病毒株可通过分子技术如聚合酶链反应（PCR）和DNA测序进行区分[1]。该病毒主要影响口腔黏膜、黏膜皮肤交界处和嘴唇周围的皮肤[2]。

猫乳头瘤病毒在猫中引起类似病变，尽管口腔乳头状瘤病的发生频率低于犬。严格的种特异性阻止了犬猫之间的跨种传播[2]。

乳头瘤病毒很少与犬的口腔和皮肤鳞状细胞癌进展相关，也可能在猫中引起皮肤鳞状细胞癌和基底细胞癌[2]。病毒通过与感染病变或污染表面的直接接触传播。当发生自伤性创伤时，继发性细菌感染可能使乳头状瘤病变复杂化[2]。

### Sources

[1] Pathology in Practice in: Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.12.0688.xml
[2] Oral Papillomas in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs

## 临床症状和体征

乳头状瘤通常表现为手指状或丝状生长物，具有独特的花椰菜样表面外观[1]。在犬中，口腔乳头状瘤主要影响幼年和青少年动物，突然出现并快速生长和扩散到多个部位[1]。病变通常涉及口腔黏膜、黏膜皮肤交界处和嘴唇周围的皮肤[1]。

当多个病变干扰摄食、咀嚼或吞咽时，临床症状变得明显[1]。犬在咀嚼过程中偶尔会咬伤较大的乳头状瘤，导致出血和继发性细菌感染[1]。对于出现多个乳头状瘤的成年老年犬，临床医生应怀疑潜在免疫缺陷，如淋巴瘤[1]。

皮肤乳头状瘤也可能出现在口腔外。这些非病毒性乳头状瘤病变表现为皮肤上的深色突起状肿块，偶尔呈线性排列[2]。表皮错构瘤在幼犬中特别明显，可卡犬可能具有遗传易感性[2]。

纤维血管乳头状瘤，也称为软垂疣或皮肤标签，代表一种影响老年犬的独特临床表现[3]。这些良性皮肤病变通常表现为具有疣状表皮表面的带蒂外生性生长物[3]。大型品种发生这些独特病变的风险可能增加[3]。

重要的是，该病通常是自限性的，乳头状瘤在数周至数月内无需干预即可自发消退[1]。然而，非典型表现需要仔细评估，因为乳头瘤病毒很少与犬猫的鳞状细胞癌进展相关[1]。

### Sources

[1] Oral Papillomas in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs

[2] Tumors of the Skin in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

[3] Connective Tissue Tumors in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 诊断方法

纤维血管乳头状瘤的诊断依赖于全面的临床评估结合先进的实验室技术。体格检查形成初始诊断步骤，重点识别特征性病变，这些病变表现为边界清晰、局限性的角化过度生长物，具有中心角质核心[1]。这些病变在触诊时通常引起明显疼痛，并表现为趾部、掌部或跖部足垫上的坚硬、疼痛性角质生长物。

组织病理学检查代表 definitive 诊断的金标准。组织样本显示正角化性角化过度，伴有局限于真皮层的致密瘢痕样组织[1]。显微镜外观有助于区分纤维血管乳头状瘤与其他皮肤病况，并确认病变内存在特征性纤维血管核心。

分子诊断技术提供重要的确认证据。抗乳头瘤病毒免疫组织化学结合乳头瘤病毒聚合酶链反应（PCR）检测有效识别病毒病因[1][2]。这些测试必须与组织学发现结合使用，以排除乳头瘤病毒作为致病因子，并排除病变形成的其他病毒原因[1]。

对于猫，乳头瘤病毒相关病变的诊断需要组织病理学来区分结节性病变与由真菌、细菌或肿瘤性疾病引起的更常见结节性皮肤病[2]。诊断过程必须区分各种乳头瘤病毒相关疾病，包括鲍文病和猫肉瘤。

### Sources
[1] Using a dental root elevator to remove footpad corns in dogs: https://www.dvm360.com/view/using-dental-root-elevator-remove-footpad-corns-dogs-two-practitioners-experience
[2] Feline viral skin diseases (Proceedings): https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings

## 治疗选择

纤维血管乳头状瘤的治疗方法侧重于手术干预作为主要方式，有几种有效技术可用于这些良性皮肤生长物。手术切除术仍然是金标准治疗，提供明确切除且效果极佳[3]。

通过监测的保守管理通常是合适的，因为这些病变是良性的，可能随时间保持稳定[3]。然而，当病变干扰正常功能、受到创伤或引起美观问题时，需要积极治疗。

主要手术技术包括完全切除术、电外科手术和冷冻手术，所有这些方法对带蒂纤维血管乳头状瘤都显示出极好的疗效[3]。这些方法特别适用于较小病变或由于解剖位置传统切除术可能具有挑战性的情况。

免疫调节方法对纤维血管乳头状瘤的应用有限，因为这些良性结缔组织肿瘤在发病机制和行为上与病毒性乳头状瘤不同[2]。与病毒性乳头状瘤不同，纤维血管乳头状瘤通常不会自发消退[2]。

适当治疗后的预后极佳，手术部位复发不常见[3]。然而，发生纤维血管乳头状瘤的犬倾向于随时间发展出更多病变，需要持续监测[3]。具有适当边缘的完全切除术提供最佳结果和最低复发率。

### Sources

[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.12.0688.xml
[2] Oral pathology and anatomic abnormalities: https://www.dvm360.com/view/oral-pathology-and-anatomic-abnormalities-proceedings
[3] Connective Tissue Tumors in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 预防措施

目前，伴侣动物的纤维血管乳头状瘤没有特定疫苗可用。这些良性皮肤生长物似乎不会在动物之间传染，与其他物种中某些病毒诱导的乳头状瘤不同[1]。

环境控制措施主要侧重于减少易感皮肤区域的创伤和刺激。由于纤维血管乳头状瘤通常在易受反复摩擦或轻微损伤的部位发展，宠物主人应尽量减少接触粗糙表面、不合身项圈或其他慢性皮肤刺激源[1]。

主要预防策略包括尽可能避免使用佐剂疫苗。特别是对于猫，疫苗接种部位纤维肉瘤（可包括纤维血管变异型）与含铝化合物的佐剂疫苗相关[1]。当前兽医指南建议在可用时使用非佐剂或鼻内疫苗，避免多价疫苗，并根据个体风险评估定制疫苗接种计划[1]。

建议定期监测新生长物，特别是在软垂疣最常见的老年犬中。这些良性病变的治疗是可选的，但发生一个纤维血管乳头状瘤的犬倾向于随时间发展出其他病变[1]。早期识别可以在外观变化或快速生长时及时进行干预。

隔离指南通常不必要，因为纤维血管乳头状瘤不被认为是传染性疾病[1]。

### Sources
[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 鉴别诊断

纤维血管乳头状瘤必须与几种具有相似临床特征的口腔和皮肤肿瘤区分开来。主要鉴别诊断包括鳞状细胞癌、其他良性肿瘤和炎症性疾病[1][3]。

**鳞状细胞癌**是最关键的鉴别诊断，特别是在猫中，它占恶性口腔肿瘤的60%[3]。与纤维血管乳头状瘤不同，鳞状细胞癌通常表现为溃疡性、局部侵袭性病变，伴有骨溶解和向区域淋巴结转移的潜力[3]。鉴别特征包括快速生长、组织坏死和侵袭性局部侵袭，与纤维血管乳头状瘤的良性、乳头状外观形成对比。

**需要区分的其他口腔肿瘤**包括纤维肉瘤（猫第二常见的恶性口腔肿瘤）、淋巴瘤、黑色素瘤、腺癌和颗粒细胞瘤[3]。良性鉴别包括纤维瘤性龈瘤、牙龈增生和嗜酸性肉芽肿[3]。最近的研究表明，组织病理学特征可以可靠地区分良性和恶性病变[2]。

**皮肤鉴别诊断**包括其他乳头瘤病毒相关疾病，如鲍文病和猫肉瘤（以前称为纤维乳头状瘤病）[5]。默克兽医手册将纤维血管乳头状瘤（也称为软垂疣或皮肤标签）描述为老年犬的独特良性病变，表现为具有疣状表面的带蒂生长物[6]。

definitive 诊断需要组织病理学检查，因为仅凭临床表现无法可靠地区分这些疾病[3]。活检应包括足够的组织取样，以避免因口腔病变常见的继发性炎症或坏死导致的误诊。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.12.0688.xml
[2] A retrospective analysis of oral tumors in dogs: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.06.0414.xml
[3] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[5] Feline viral skin diseases: https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings
[6] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 预后

纤维血管乳头状瘤（皮肤标签/软垂疣）在伴侣动物中具有极佳的预后，完全手术切除始终具有治愈性[1]。这些良性病变没有恶性转化潜力，对受影响的犬和猫构成最小的健康风险。

该病表现出可预测的临床过程。发生一个软垂疣的犬倾向于随时间发展出更多病变[1]。然而，这种倾向不影响总体有利结果，因为每个病变在成为问题时都可以成功治疗。

治疗结果无论选择何种干预措施都是一致的阳性。手术切除、电外科手术和冷冻手术都提供有效解决[1]。尚未记录品种特异性预后差异，尽管大型犬品种在不同部位发展新病变的复发率可能略高。

即使多发性病变病例，预后仍然极佳，因为没有全身受累或转移潜力。长期生存不受纤维血管乳头状瘤存在的影响。影响治疗决策的主要因素是美观问题或机械刺激，而不是危及生命的并发症。

并发症罕见，通常限于带蒂病变的创伤性损伤，可能导致出血或继发性细菌感染。这些并发症通过适当的局部护理容易解决，并且不会改变这种良性皮肤病况的总体有利预后。

### Sources
[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
