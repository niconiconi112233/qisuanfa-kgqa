# 伴侣动物的慢性心力衰竭

慢性心力衰竭（CHF）是兽医实践中最重要的心血管疾病之一，影响着全球数百万只犬和猫。这种进行性综合征发生在心脏无法维持足够的心输出量以满足机体代谢需求时，导致代偿机制最终恶化病情。早期识别和适当管理对于优化患者的预后和生活质量至关重要。

本报告探讨了伴侣动物CHF的多面性，涵盖疾病机制和流行病学、潜在病因（包括黏液瘤性二尖瓣疾病和心肌病）、从轻微运动不耐受到急性呼吸窘迫的临床表现、利用生物标志物和先进影像学的诊断方法、以匹莫苯丹和ACE抑制剂为特征的治疗方案、强调基因筛查和心丝虫控制的预防策略、特别是慢性支气管炎的鉴别诊断，以及影响接受治疗患者生存期和生活质量的预后因素。

## 疾病概述与流行病学

慢性心力衰竭（CHF）被定义为尽管存在代偿机制，心脏仍无法维持正常的心输出量、体循环血压和静脉/毛细血管压力的状态[1]。它代表了严重心脏疾病的终末期表现，此时心血管系统无法维持足够的组织灌注。

CHF通过两种主要的病理生理机制发生：收缩功能障碍和舒张功能障碍[1]。收缩功能障碍涉及心肌收缩力受损，如扩张型心肌病中所见，而舒张功能障碍则由于顺应性降低导致心室充盈受损，常见于肥厚型心肌病[2]。

流行病学在犬和猫之间存在显著差异。在犬中，扩张型心肌病是CHF的主要原因，品种特异性患病率差异巨大--从杜宾犬的5.8%到美国可卡犬的0.34%[3]。雄性受影响程度几乎是雌性的两倍（0.66% vs 0.34%）[3]。在猫中，肥厚型心肌病是最常见的心脏病，影响多达七分之一的猫，尽管大多数病例保持亚临床状态[2]。

年龄分布显示中年动物最常受影响，患DCM的犬通常在4-10岁之间[3]。某些品种表现出遗传易感性，包括HCM的缅因猫和布偶猫，以及DCM的大型犬种[2][3]。

### Sources

[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

[2] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

[3] Managing dilated cardiomyopathy (Proceedings): https://www.dvm360.com/view/managing-dilated-cardiomyopathy-proceedings

## 常见病原与病因学

犬和猫的慢性心力衰竭（CHF）主要源于结构性心脏病而非传统的感染性病原体。**黏液瘤性二尖瓣疾病（MMVD）和扩张型心肌病（DCM）是导致犬CHF的最常见心脏病**[1]。在犬中，**二尖瓣和/或三尖瓣的黏液瘤性退变占所有心脏病的≥75%**[2]。

**肥厚型心肌病（HCM）在猫中最常见，占猫心脏病病例的85%以上**[3]。DCM主要发生于大型犬种，但也影响牛磺酸缺乏或处于其他心肌病终末期的猫[3]。**包括动脉导管未闭、室间隔缺损和房室瓣发育不全在内的先天性缺陷**是幼年动物的重要病因[4]。

**主要的寄生虫病因是心丝虫病（恶丝虫）**，可导致肺动脉高压和右侧心力衰竭[4]。肺血管中的成虫加上诱导的动脉变化阻碍肺血流，可能导致肺源性心脏病[2]。虽然不是传统病原体，但营养缺乏（牛磺酸、左旋肉碱）和某些无谷物饮食已与DCM的发展相关[3]。

### Sources
[1] New perspectives on diagnosis and treatment of canine congestive heart failure (Proceedings): https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings
[2] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[3] Therapy of CHF: choices and controversies (Proceedings): https://www.dvm360.com/view/therapy-chf-choices-and-controversies-proceedings
[4] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 临床症状与体征

现有章节内容全面概述了慢性心力衰竭在不同物种中的表现。根据额外的资料来源，可以增强几个重要的临床细节，以提供更完整的症状进展和识别图景。

**传导异常**经常伴随慢性心力衰竭并导致临床表现[1]。**晕厥**是需要紧急关注的关键症状，特别是在有心律失常、完全性心脏传导阻滞或突然血流动力学受损的犬中[1][3]。这与运动不耐受不同，因为晕厥代表由于脑灌注不足导致的意识急性丧失。

**额外的呼吸注意事项**包括认识到许多患有轻度心源性肺水肿的犬在听诊时可能不会表现出明显的附加肺音[2]。**睡眠呼吸频率（SRR）**监测变得特别有价值，频率>30次/分钟表示需要进一步评估的异常呼吸急促[2]。这种家庭监测工具有助于在明显呼吸困难发展之前检测早期失代偿。

**品种特异性表现**超出先前提到的模式。**大型犬种**如大丹犬通常发展为**孤立性心房颤动**而无潜在结构性疾病，产生可能耐受良好的不规则节律[2][6]。**拳狮犬**经常表现为**心律失常性右心室心肌病**，表现为室性心律失常、晕厥或突然虚弱[6]。

现有对早期与晚期症状、物种差异和主要临床体征（呼吸急促、运动不耐受、腹水、晕厥、动脉血栓栓塞）的全面覆盖仍然准确和完整。资料来源证实了既定的理解，即猫通常表现更隐匿，并且容易因胸腔积液而突然失代偿。

### Sources

[1] Heart Disease: Conduction Abnormalities in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[2] Back to basics: clinical cardiovascular exam and diagnostic testing (Proceedings): https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings
[3] Clinical usefulness of cardiac event recording in dogs and cats examined because of syncope, episodic collapse, or intermittent weakness: 60 cases (1997-1999): https://avmajournals.avma.org/view/journals/javma/216/7/javma.2000.216.1110.xml

## 诊断方法

犬和猫慢性心力衰竭的诊断需要结合临床检查、实验室检测和先进影像技术的系统方法。心脏体格检查从仔细听诊开始，以检测心脏杂音、奔马律或心律失常[1]。同时进行脉搏触诊有助于识别脉搏缺失并评估动脉脉搏强度，在心输出量低的患者中可能微弱，在动脉导管未闭的病例中可能洪大[1]。

实验室评估包括心脏生物标志物，特别是N末端B型利钠肽前体（NT-proBNP）和心肌肌钙蛋白I，这些已得到充分研究用于临床建议[1]。NT-proBNP从受牵拉的心肌细胞释放，其浓度随疾病严重程度成比例增加，使其在区分心脏与呼吸原因引起的呼吸困难方面有价值，特别是在猫中[1,2]。该生物标志物作为筛查工具也很有用，可在充血性心力衰竭发作前检测隐匿性扩张型心肌病[1]。

超声心动图作为评估心脏结构和功能的金标准无创诊断工具[4]。该模式允许评估心腔扩大、量化收缩和舒张功能、评估瓣膜疾病严重程度以及识别先天性缺陷[4]。胸部X线摄影仍然是诊断充血性心力衰竭的基础，显示特征性模式，如犬的肺门至尾背侧肺水肿和猫的变异模式[4,8]。心电图主要用于节律评估，尽管它提供关于结构性心脏病的信息有限[4,9]。

### Sources
[1] Heart Failure in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] NT-proBNP Testing: An important tool for veterinary practitioners: https://www.dvm360.com/view/nt-probnp-testing-an-important-tool-for-veterinary-practitioners
[3] Clinical usefulness of an assay for measurement of circulating: https://avmajournals.avma.org/view/journals/javma/243/1/javma.243.1.71.xml
[4] Diagnosis of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/en/circulatory-system/cardiovascular-system-introduction/diagnosis-of-cardiovascular-disease-in-animals
[5] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[6] Diagnosis of Heart Disease in Animals: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[7] Diagnostic Cardiology: https://www.dvm360.com/view/diagnostic-cardiology
[8] Back to basics: clinical cardiovascular exam and diagnostic testing: https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings
[9] Performing a cardiovascular physical examination: https://www.dvm360.com/view/performing-cardiovascular-physical-examination
[10] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure

## 治疗选择

犬和猫慢性心力衰竭的治疗需要结合药物干预、非药物措施和支持性护理的多模式方法[1]。主要目标是改善心输出量、减少充血并提高生活质量。

**药物治疗构成治疗的基石。** ACE抑制剂（依那普利、贝那普利、赖诺普利）通过降低后负荷和预防心脏重塑作为一线治疗[1][2][3]。这些药物与其他心血管药物联合使用时是安全的，并且在管理心力衰竭方面已证实有效[3]。

袢利尿剂，特别是呋塞米，对于清除液体积聚和缓解肺水肿至关重要[1][2]。对于轻度至中度衰竭，典型剂量为犬每8-12小时口服1-6 mg/kg，而晚期病例可能需要静脉给药[1]。

**匹莫苯丹代表了心力衰竭管理的关键进展。**这种正性肌力血管扩张剂通过钙增敏提供正性肌力作用，并通过磷酸二酯酶抑制提供血管舒张作用[1][4]。研究表明，在标准治疗中加入匹莫苯丹可改善扩张型心肌病和二尖瓣疾病犬的生存期和生活质量[4]。

β受体阻滞剂如卡维地洛可能通过预防疾病进展而使某些病例受益，尽管由于负性肌力作用需要仔细监测[1]。

**非药物方法同样重要。**氧疗为呼吸困难患者提供即时呼吸支持[1][5]。饮食钠限制有助于减少液体潴留，而牛磺酸补充可能有益于有记录缺乏的猫[6]。

**手术干预**仍然有限，但可能包括对难治性积液进行胸腔穿刺术或腹腔穿刺术[5][8]。当心力衰竭导致心包积液时，像心包穿刺术这样的紧急程序很少需要[8]。

### Sources
[1] Treating heart failure (Proceedings): https://www.dvm360.com/view/treating-heart-failure-proceedings
[2] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[3] Angiotensin-converting Enzyme Inhibitors for Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/angiotensin-converting-enzyme-inhibitors-for-use-in-animals
[4] Pimobendan: Understanding its cardiac effects in dogs with myocardial disease: https://www.dvm360.com/view/pimobendan-understanding-its-cardiac-effects-dogs-with-myocardial-disease
[5] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings
[6] Heart Failure in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/heart-failure-in-cats
[7] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings
[8] Keys to managing end-stage heart failure: https://www.dvm360.com/view/keys-managing-end-stage-heart-failure

## 预防措施

预防犬和猫的慢性心力衰竭需要针对根本原因和风险因素的多方面方法。心丝虫预防代表最关键的预防策略，因为心丝虫病是可预防心力衰竭的主要原因[1]。每月心丝虫预防药物有效阻断传播，应在流行地区全年使用。

基因筛查在易感品种中起着重要作用。包括杜宾犬、拳狮犬和大丹犬在内的大型犬由于扩张型心肌病风险增加而需要定期心脏评估[1]。育种计划应纳入基因检测以识别遗传性心脏病的携带者[2]。

早期检测方案包括所有宠物的年度心脏检查，对高风险品种进行更频繁监测。心脏生物标志物如NT-proBNP可在临床症状出现前检测隐匿性心脏病，特别适用于筛查扩张型心肌病[3]。宠物主人应监测睡眠呼吸频率，因为频率升高可能表明早期心力衰竭。

管理易患条件同样重要。通过定期血压监测和适当治疗控制高血压可防止心脏损伤[4]。维持最佳体重减少心脏负荷，而解决潜在疾病如肾病或甲状腺功能亢进有助于预防继发性心脏并发症。

### Sources

[1] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[2] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[3] Breed-specific variations of cardiomyopathy in dogs: https://www.dvm360.com/view/breed-specific-variations-cardiomyopathy-dogs
[4] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals

## 鉴别诊断

现有章节内容全面概述了慢性心力衰竭的关键鉴别诊断。我将结合额外的资料来源来增强慢性支气管炎鉴别讨论。

**慢性支气管炎**代表犬中最具挑战性的CHF鉴别诊断之一。患有慢性支气管炎的犬通常表现为持续性咳嗽，常伴有干呕，在兴奋或活动时加重[1]。与CHF患者不同，患有慢性支气管炎的犬通常保持正常食欲和身体状况，提供重要的临床区别[1]。心脏杂音缺失加上明显的窦性心律不齐强烈提示原发性呼吸系统疾病而非心脏病理[1]。

**体格检查结果**有助于区分这些疾病。慢性支气管炎患者在咳嗽发作之间通常显示正常心脏听诊，而CHF病例通常显示特征性杂音并可能在休息时持续呼吸窘迫[2]。患有慢性支气管炎的犬可能在胸部听诊时表现出喘息和爆裂音，但这些呼吸声音与CHF肺水肿相关的爆裂音不同[2]。

**诊断影像学**提供关键区分。慢性支气管炎在X光片上特征性地显示支气管模式改变，增厚的支气管壁在端视时呈现为"甜甜圈"状，在纵视时呈现为"铁轨"状[3]。相比之下，CHF病例显示心脏肿大、肺静脉充血，并且通常显示与肺水肿一致的肺泡模式[3]。

关键区分因素仍然是结构性心脏病的存在与否，超声心动图作为确认心脏与原发性呼吸系统病因的明确诊断工具。

### Sources
[1] Canine chronic bronchitis and pulmonary fibrosis: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[2] Managing the coughing dog: https://www.dvm360.com/view/managing-coughing-dog-proceedings
[3] Radiographic evaluation of pulmonary patterns and disease: https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings

## 预后

关于伴侣动物慢性心力衰竭预后的现有内容提供了全面概述。最近的研究证实，预后根据根本病因和疾病阶段而有显著差异，特别是猫类研究出现了重要见解[5]。

CHF发展后，疾病进展显著加速，最近兽医文献报告的平均生存时间通常少于12个月[3]。然而，现代治疗方法已显著改善了结果。QUEST研究结果仍然至关重要，表明匹莫苯丹治疗将中位生存期延长至267天，而单用ACE抑制剂治疗为140天，代表了91%的显著改善[8]。

患有心力衰竭的猫，最近的多中心研究确认在CHF诊断后中位生存期约为一年，尽管个体猫在适当管理下可能存活数年[5][10]。经历动脉血栓栓塞的猫面临特别具有挑战性的预后，SUPERCAT研究显示根据抗凝治疗不同，血栓栓塞复发的中位时间为513-663天[10]。

生活质量考虑已成为越来越重要的预后因素。评估患者和主人生活质量的研究表明，主人和犬的生活质量评分之间存在显著相关性，睡眠中断、担忧和不愿离家是主人的主要担忧[7]。这些因素显著影响治疗决策和整体预后，因为由于感知生活质量差而由主人选择安乐死代表常见终点，无论潜在心脏状况如何。

### Sources
[1] New perspectives on diagnosis and treatment of canine congestive heart failure (Proceedings): https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings
[2] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings
[3] Key nutrients important in the management of canine: https://avmajournals.avma.org/view/journals/javma/260/S3/javma.22.07.0319.xml
[4] Acquired cardiac diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings
[5] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[6] ACVIM 2017: Measuring Quality of Life in Owners of Dogs with Heart Disease: https://www.dvm360.com/view/acvim-2017-measuring-quality-of-life-in-owners-of-dogs-with-heart-disease
[7] New perspectives on diagnosis and treatment of canine congestive heart failure (Proceedings): https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings
[8] the SUPERCAT study: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0584.xml
