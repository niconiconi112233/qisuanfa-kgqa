# 犬传染性性病肿瘤

犬传染性性病肿瘤（TVT）代表了自然界最非凡的生物现象之一--一种通过直接细胞转移而非传统病原体传播的癌症。这种独特的传染性癌症影响全球犬只，特别是在热带和亚热带地区，自由放养的种群通过交配和社交接触促进传播。

这本综合兽医指南探讨了TVT作为克隆传播细胞系的独特特征，研究了从典型生殖器肿块到生殖器外表现的临床表现，并详细介绍了基于证据的诊断方法，包括细胞学和PCR方法。该报告涵盖了经过验证的治疗方案，长春新碱化疗达到超过90%的治愈率，通过种群控制的预防策略，鉴别诊断考虑因素，以及适当管理时的良好预后。

## 摘要

传染性性病肿瘤作为一种独特的兽医挑战而脱颖而出，其中活癌细胞本身充当传染源，需要直接接触才能传播。该疾病在全球范围内分布，在自由放养犬种群数量大的地区流行率最高。

临床识别集中在特征性的花椰菜状生殖器肿块上，这些肿块容易出血，尽管生殖器外表现可能发生在鼻腔、口腔或皮肤位置。揭示具有点状空泡的圆形细胞的细胞学检查提供快速诊断，而基于PCR的方法通过检测特定遗传标记提供更高的准确性。

治疗结果异常有利，长春新碱化疗方案在5-7次治疗内使超过90%的病例完全缓解。替代方案包括用于耐药病例的多柔比星和具有相似高成功率的放射治疗。

| 管理方面 | 关键策略 | 成功率 |
|-------------------|--------------|--------------|
| 治疗 | 每周长春新碱0.025 mg/kg | >90%缓解 |
| 预防 | 生殖腺切除术和种群控制 | 高度有效 |
| 诊断 | 细针穿刺细胞学 | 主要方法 |
| 预后 | 适当治疗完全治愈 | 优秀 |

兽医应通过常规繁殖检查优先早期识别，对受影响动物实施积极治疗方案，并倡导在流行地区采取种群控制措施以防止传播。

## 疾病概述

犬传染性性病肿瘤（TVT）是一种影响犬科动物的自然传染性癌症，代表了高等动物中已知的三种传染性癌症之一[1]。与传统癌症不同，TVT通过活癌细胞的直接转移传播，而非通过传染源或遗传易感性。

TVT被描述为具有强细胞遗传学特征的圆形细胞肿瘤，代表了一个已连续传播数千年的克隆细胞谱系[1]。肿瘤细胞本身充当传染源，需要与肿瘤块直接接触并转移足够数量的肿瘤细胞才能成功移植[1]。

该疾病在全球范围内分布，临床病例来自除南极洲外的所有大陆[1]。虽然在北欧、中欧和北美不常见，但TVT在中美洲和南美洲、东亚、中东和非洲部分地区等热带和亚热带地区呈地方性流行[1]。它代表了巴哈马、日本和印度等国家最常见的犬类肿瘤[1]。

TVT传播主要通过交配发生，尽管该疾病并非 exclusively 性传播[1]。肿瘤也可以通过嗅闻、舔舐、抓挠或咬伤等社交行为传播，母犬到幼犬的传播可能通过梳理行为发生[1]。

### Sources
[1] Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

## 常见病原体

传染性性病肿瘤代表了一种独特的生物现象，因为它不是由病毒或细菌等传统病原体引起的。相反，TVT是一种自然发生的克隆传染性癌症，其中肿瘤细胞本身充当传染源[1][2]。

TVT细胞被描述为具有强细胞遗传学特征的圆形细胞肿瘤，代表了一个已传播数千年的连续细胞谱系[2]。肿瘤细胞本身就是传染源，需要将活肿瘤细胞从一只犬直接转移到另一只犬才能成功传播[2]。与典型的传染病不同，TVT不能通过无细胞滤液或死细胞传播[1]。

独特的细胞特征包括均质的大圆形细胞群体，具有特征性的中心核仁和多个清晰的细胞质空泡[2]。这些细胞含有插入myc基因上游的特定长散布核元件（LINEs），作为区分TVT与其他肿瘤的诊断标记[2]。

传播通过在交配或嗅闻、舔舐、抓挠或咬伤等社交行为期间与肿瘤块直接接触发生[2]。这些细胞只能在磨损的粘膜上移植，一定数量的肿瘤细胞对于成功建立肿瘤至关重要[2]。

### Sources
[1] Clinical Exposures: Canine transmissible venereal tumor: https://www.dvm360.com/view/clinical-exposures-canine-transmissible-venereal-tumor-cytologic-clues
[2] Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

Looking at the provided source material, I notice that the sources are not about Transmissible Venereal Tumor (TVT) in dogs. Instead, they contain information about Japanese car dealerships and general canine family (Canidae) information, which is not relevant to the veterinary topic requested.

Since the existing section content already provides comprehensive coverage of TVT clinical symptoms and signs based on the Merck Veterinary Manual, and the new source material does not contain any veterinary information about TVT, I cannot add any new information to this section.

The existing content already thoroughly covers:
- Typical appearance and characteristics of TVT lesions
- Anatomical locations (genital and extragenital)
- Clinical presentations in males and females
- Metastasis patterns and frequency
- Secondary complications like bacteriuria
- Growth patterns in different populations

## 临床症状和体征

犬TVT表现出兽医必须识别的独特临床特征以进行准确诊断[1]。肿瘤呈现为花椰菜状、带蒂、结节状、乳头状或多叶状肿块，范围从小结节（5 mm）到大肿块（>10 cm）[1]。这些生长物通常坚硬但易碎，表面经常溃疡、发炎，操作时容易出血[1]。

**TVT几乎总是位于生殖器上**，代表最常见的表现模式[1]。然而，肿瘤可能起源于包皮、阴道或鼻腔深处，在常规检查中难以检测[1]。在雌性中，深部阴道肿瘤通常最初表现为地板或地毯上的血斑，可能被错误地归因于血尿或其他出血性疾病[1]。患有深部包皮受累的雄性犬通常以包茎嵌顿为主要临床表现[1]。

**转移不常见**（仅发生在5%的病例中），发生时通常影响区域淋巴结[1]。然而，转移扩散可涉及肾脏、脾脏、眼睛、大脑、垂体、皮肤和皮下组织、肠系膜淋巴结和腹膜[1]。

生殖器外TVT表现因解剖位置而异，当没有并发生殖器病变时，可能包括打喷嚏、鼻出血、流泪、眼球突出、皮肤肿块、口臭、牙瘘或面部变形[1]。患有生殖器TVT的犬经常继发菌尿[1]。

最初，TVT表现出快速生长，特别是在新生和免疫抑制犬中，早期识别对于最佳治疗结果至关重要[1]。

### Sources
[1] Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

## 诊断方法

TVT诊断依赖于临床表现评估和特定诊断技术的结合。细针穿刺（FNA）配合细胞学检查作为主要诊断方法，由于TVT细胞的圆形细胞肿瘤特征，易于脱落[1]。细胞学检查通常显示细胞丰富的样本，主要群体为均质、离散的圆形细胞，表现出轻度细胞大小和核大小不均[2]。

TVT的独特细胞学特征包括具有中等淡蓝色细胞质的大圆形细胞，含有特征性的小点状空泡、粗染色质的圆形核和单个突出的核仁[2]。这些细胞质空泡有助于将TVT与其他圆形细胞肿瘤（如淋巴瘤、浆细胞瘤或组织细胞瘤）区分开来[2]。

可以进行组织病理学检查，但当细胞学特征和临床表现具有特征性时，通常不需要常规进行[5]。先进的基于PCR的检测方法可以识别插入myc基因上游的特定长散布核元件（LINEs），与细胞学或组织学诊断相比提供更高的诊断准确性[5]。先进的成像技术通常不需要用于诊断，尽管在怀疑转移的情况下它们可能有助于评估疾病程度[3]。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0253.xml
[2] Clinical Exposures: Canine transmissible venereal tumor: https://www.dvm360.com/view/clinical-exposures-canine-transmissible-venereal-tumor-cytologic-clues
[3] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.09.0535.xml
[4] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[5] Canine Transmissible Venereal Tumor - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

## 治疗选择

硫酸长春新碱仍然是犬传染性性病肿瘤的化疗首选[1]。标准方案涉及每周静脉注射0.025 mg/kg，持续2周，直到肿瘤肿块完全消失，无论肿瘤大小或程度如何[1]。该方案通常在5-7次剂量内实现完全缓解，第一次治疗后通常观察到肿瘤大小显著减少[2]。

对于对长春新碱无反应的患者，多柔比星代表有效的替代化疗选择。该方案包括10公斤以上犬30 mg/m²或较小犬1 mg/kg，每3周静脉注射一次，共5-6剂[1]。

放射治疗为传染性性病肿瘤提供了极好的结果，即使在相对低剂量下控制率也超过90%。这种方式对于化疗耐药或复发病例特别有价值，在这些病例中手术切除不可行[1]。

手术切除可能适用于局部病变，但由于解剖位置（特别是在生殖器区域内）通常具有挑战性。没有辅助放疗或化疗来预防复发，通常无法实现完全手术切除[1]。当单独尝试生殖器病变手术时，复发率从20-60%不等[2]。

适当治疗完全缓解的预后极好，除非转移累及皮肤以外的器官[1]。使用长春新碱和多柔比星的联合化疗方案并不比单药长春新碱具有治疗优势，但会增加毒性[1]。

### Sources
[1] Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor
[2] Clinical Exposures: Canine transmissible venereal tumor: https://www.dvm360.com/view/clinical-exposures-canine-transmissible-venereal-tumor-cytologic-clues

## 预防措施

传染性性病肿瘤的主要预防策略包括通过种群管理控制交配行为。生殖腺切除术（绝育和去势）通过减少犬种群内的交配活动显著降低TVT发生率[1]。这种手术干预代表最有效的长期预防方法，特别是在社区和自由放养犬种群中，TVT最常被诊断。

预繁殖健康检查对用于繁殖的犬至关重要。繁殖前彻底检查动物以排除活动性感染的动物将控制疾病[2]。这些评估应包括在繁殖活动前仔细检查外部生殖器是否有可疑肿块或病变。通过常规兽医筛查早期发现可以防止交配期间传播。

当诊断出TVT时，隔离方案至关重要。受影响的动物必须与潜在繁殖伙伴分开，直到通过治疗实现肿瘤完全消失。这可以防止在繁殖设施或社区种群内进一步传播。

种群控制措施，包括持续动物节育计划和流浪犬的捕捉-绝育-放归计划，通过限制不受控制的繁殖帮助降低总体TVT流行率[2]。在存在大量流浪犬种群的地区，这些计划结合受影响犬的化疗将在很大程度上控制TVT病例。

向犬主人宣传负责任的繁殖实践和定期兽医护理的教育也有助于预防工作。

### Sources
[1] Merck Veterinary Manual - Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor
[2] Merck Veterinary Manual - Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

## 鉴别诊断

传染性性病肿瘤必须与其他可能表现出相似细胞学特征的圆形细胞肿瘤区分开来[1]。主要鉴别诊断包括肥大细胞瘤、淋巴瘤、组织细胞瘤和浆细胞瘤[1][3]。这些肿瘤具有形态学相似性，因为它们都脱落为具有不同核和细胞质特征的圆形细胞群体。

肥大细胞瘤通常含有特征性的细胞质颗粒，在分化不良的变体中可能被掩盖，使 differentiation 具有挑战性[1]。淋巴瘤呈现为具有不同核形态的均质细胞群，从小的成熟淋巴细胞到具有突出核仁的大淋巴母细胞[1]。组织细胞瘤在幼犬中常见，显示个体化的圆形细胞，具有中等嗜碱性细胞质和凹陷的核[1]。

TVT的一个关键区别特征是存在许多点状细胞质空泡和特征性的仅59条染色体，而正常犬核型为78条[1]。在流行地区，利什曼病由于与TVT的视觉相似性，特别是当利什曼原虫可能寄生在肿瘤细胞中时，构成了关键的鉴别诊断[6]。针对特定遗传标记的基于PCR的检测分析与单独组织学检查相比提供了更高的诊断准确性[6]。

### Sources

[1] Differentiating the round cell tumors (Proceedings): https://www.dvm360.com/view/differentiating-round-cell-tumors-proceedings

[2] Pathology in Practice in: Journal of the American Veterinary ...: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.09.0535.xml

[3] Neoplastic skin disorders (Proceedings): https://www.dvm360.com/view/neoplastic-skin-disorders-proceedings

[4] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors

[5] Lymphocytic, Histiocytic, and Related Cutaneous Tumors ...: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/lymphocytic-histiocytic-and-related-cutaneous-tumors-in-animals

[6] Canine Transmissible Venereal Tumor: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

## 预后

犬传染性性病肿瘤在适当治疗时具有极好的总体预后。化疗或放疗完全缓解的预后良好，除非有皮肤以外器官的转移累及[1]。使用长春新碱方案治疗的超过90%患者可以预期完全肿瘤缓解[2]。

化疗通常在5-7个治疗周期内实现完全缓解，使用标准长春新碱方案时完全治愈率超过90%[1]。放射治疗显示出卓越的疗效，即使在相对低剂量下控制率也超过90%[3]。然而，免疫功能不全状态的犬可能需要延长治疗时间或降低反应率。

转移累及显著影响预后。虽然转移仅发生在5%的病例中，但中枢神经系统和眼部累及预后不良[1]。区域淋巴结转移通常对治疗反应良好，而远处器官累及则造成治疗挑战。

犬的免疫反应在确定结果中起着关键作用。TVT具有高度抗原性，免疫正常的动物可能经历自发消退[2]。然而，免疫抑制犬可能发展为需要积极干预的进行性疾病。与较差治疗反应相关的因素包括较大的肿瘤大小、年龄较大以及在炎热潮湿季节治疗[1]。

适当治疗的长期生存率极好，完全治疗后复发不常见。大多数患者在成功完成化疗后无限期保持无病状态。

### Sources
[1] Canine Transmissible Venereal Tumor - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor
[2] Clinical Exposures: Canine transmissible venereal tumor: https://www.dvm360.com/view/clinical-exposures-canine-transmissible-venereal-tumor-cytologic-clues
[3] What to irradiate and what not (Proceedings): https://www.dvm360.com/view/what-irradiate-and-what-not-proceedings
