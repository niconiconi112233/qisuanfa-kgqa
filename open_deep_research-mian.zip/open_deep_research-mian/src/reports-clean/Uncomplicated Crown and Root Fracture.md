# 伴侣动物单纯性牙冠与牙根骨折

单纯性牙冠与牙根骨折在兽医牙科中是一个重要问题，影响可见的牙冠和下方的牙根结构，但不暴露牙髓腔。这些损伤通常通过创伤或不适当的咀嚼行为发生在犬和猫身上，其中犬齿和裂齿最常受影响。虽然患者最初可能表现出最小的临床症状，但未经治疗的骨折可能发展为牙髓炎、通过暴露的牙本质小管的细菌入侵，并最终导致牙齿脱落。本报告探讨了这些复杂牙科损伤的流行病学、诊断方法和循证治疗策略，强调了早期干预和适当病例选择对于伴侣动物实践成功结果的重要性。

## 疾病概述

单纯性牙冠与牙根骨折（UCRF）定义为涉及牙齿牙冠和牙根部分但不暴露牙髓腔的骨折[1]。根据2007年成立的美国兽医牙科学院（AVDC）分类系统，UCRF代表基于受影响解剖结构的五种标准化牙科骨折类别之一[1]。

在伴侣动物中，牙冠和牙根之间的解剖区别至关重要。在犬和猫的牙列中，牙冠从尖端延伸到釉牙骨质界，而牙根位于此交界处下方[3]。猫具有独特的解剖学考虑因素，因为它们的牙髓腔延伸至牙冠尖端几毫米内，这使它们即使在看似轻微的骨折中也特别容易发生牙髓暴露[2]。

从流行病学角度看，牙科骨折在犬和猫中很常见，犬齿和裂齿最常受影响[4]。在成年犬中，上颌犬齿和上颌第四前臼齿最常受到创伤，其次是下颌犬齿和门齿[3]。在猫中，上颌和下颌犬齿最容易骨折，其次是门齿[3]。这些骨折源于包括打斗、跌倒、咀嚼硬物和事故等创伤[4]。最近的研究表明，单纯性牙冠-牙根骨折约占犬骨折牙齿的6.7%，在猫中为0%，表明在犬患者中患病率更高[1]。

### Sources

[1] Prophylactic antibiotic use is common in dogs and cats: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.08.0524.pdf
[2] Are there alternatives to surgery for a fractured tooth?: https://www.dvm360.com/view/just-ask-expert-are-there-alternatives-surgery-fractured-tooth
[3] Examining new classifications of tooth fractures: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures
[4] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth

## 病因学与临床表现

伴侣动物中的单纯性牙冠与牙根骨折主要由创伤相关原因引起。来自车祸、打斗、跌倒或体育活动的直接力创伤占大多数病例[1]。此外，咀嚼硬物如骨头、尼龙玩具、牛蹄或笼条经常导致牙科骨折[2]。

病理生理学涉及牙本质小管暴露于口腔环境。当釉质骨折暴露牙本质时，会发生牙本质敏感的流体动力学机制，由于暴露小管内液体流动增加而刺激牙髓中的A-δ神经纤维[2]。尽管在单纯性骨折中牙髓保持未暴露状态，但口腔细菌可以通过牙本质小管入侵，随着时间的推移可能导致牙髓炎和牙髓坏死。

临床症状包括口腔不适，但许多患者最初可能不会表现出明显的临床症状，食欲通常保持不变[2]。然而，骨折牙齿可能是慢性疼痛的来源，如果未经治疗，可能发展为牙髓炎、骨炎、引流窦道和牙齿脱落。犬能够用其裂齿产生巨大的咬合力，这使得在咀嚼与牙齿一样硬或更硬的物体时更容易发生骨折[2]。

上颌第四前臼齿（裂齿）在宠物犬中最常受影响，而在野猫中，上颌犬齿和裂齿风险最大[2]。在小动物实践中，据报道有10-29%的患者存在骨折牙齿[2]。

### Sources
[1] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[2] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats

## 诊断方法

临床检查仍然是诊断犬和猫单纯性牙冠与牙根骨折的基础。视觉检查应识别无牙髓暴露的牙冠缺陷，而用牙科探针轻柔探查可以确认没有牙髓参与[1][2]。

口腔内牙科X线摄影对于全面评估至关重要。X线片有助于评估牙根完整性、检测并发根尖病理，并评估与对侧牙齿相比的牙髓腔宽度[2][3]。无活力牙齿可能表现为扩大的根管，表明过去存在牙髓损伤，即使没有明显暴露[2]。

使用锥形束计算机断层扫描（CBCT）的先进成像与传统X线摄影相比提供更高的诊断率，特别是用于检测异常牙根形态和细微的根尖变化[4]。当标准X线片显示正常但临床怀疑有并发症时，CBCT证明特别有价值。

牙髓活力评估涉及评估牙齿变色，因为在87-92%的病例中，内源性染色牙齿表示无活力[10]。面部肿胀、肉芽肿形成或牙周异常等临床症状可能表明需要立即关注的继发并发症。

鉴别诊断必须排除伴有牙髓暴露的复杂性骨折、牙周病、牙齿吸收和牙髓-牙周联合病变[3][10]。对整个牙齿结构（包括多根牙的分叉区域）进行系统性X线评估，确保全面评估。

### Sources
[1] Diagnostic Imaging in Veterinary Dental Practice: https://avmajournals.avma.org/view/journals/javma/261/1/javma.22.03.0114.xml
[2] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[3] The ABCs of veterinary dentistry: When waiting is wishful thinking: https://www.dvm360.com/view/the-abcs-of-veterinary-dentistry-when-waiting-is-wishful-thinking
[4] Evaluation of the diagnostic yield of dental radiography and CBCT: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[10] Endodontic Disease in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals

Looking at this source material, I see that none of these sources contain relevant veterinary information about uncomplicated crown and root fractures in pets. All the sources are about real estate listings in Coral Springs, Florida, with a few dental-related sources (sources 6-10) that discuss general veterinary dentistry procedures but don't specifically address uncomplicated crown and root fractures.

Since the existing section content already provides comprehensive information about treatment options for uncomplicated crown and root fractures, and the provided source material doesn't contain relevant veterinary information to add to or modify this content, I cannot write a meaningful update to this section.

## 治疗选择

现有内容已经全面涵盖了单纯性牙冠与牙根骨折的治疗选择，包括粘接密封修复、疼痛管理方案、监测程序、预防措施和主人教育。提供的资料完全由房地产列表和一般牙科拔牙程序组成，这些与伴侣动物单纯性牙冠与牙根骨折的特定治疗无关。

没有关于单纯性牙冠与牙根骨折治疗的相关兽医资料来源，我无法提供额外的循证信息来增强本节内容。

### Sources
The provided sources do not contain relevant information about uncomplicated crown and root fracture treatment in companion animals.
