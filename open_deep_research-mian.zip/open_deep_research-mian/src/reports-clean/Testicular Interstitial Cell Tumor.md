# 伴侣动物睾丸间质细胞瘤

睾丸间质细胞瘤是影响未去势公犬的三种主要睾丸肿瘤之一，起源于睾丸内产生睾酮的莱迪希细胞。与其他可能导致显著临床并发症的睾丸肿瘤不同，这些良性肿瘤通常在激素上无活性，很少产生明显症状，因此常在常规检查或去势手术中被偶然发现。

这份全面的兽医报告 examines 伴侣动物临床实践中间质细胞瘤的临床意义，涵盖其非传染性病因、微妙的临床表现、使用超声检查和组织病理学的诊断挑战、通过去势手术的治疗方法，以及完全切除后的良好预后。该报告强调通过早期去势进行预防，并与其他睾丸疾病进行鉴别诊断。

## 疾病概述

睾丸间质细胞瘤是起源于犬睾丸内产生睾酮的莱迪希细胞的良性肿瘤[1]。这些肿瘤是犬类三种常见睾丸肿瘤类型之一，与支持细胞瘤和精原细胞瘤并列[7]。据报道，老年性成熟犬的睾丸肿瘤患病率为16%，年龄和睾丸异位是主要风险因素[1]。

睾丸肿瘤在未去势的老年公犬中最常见，通常影响7岁以上的动物[7]。有一个或两个睾丸未下降（隐睾）的犬患睾丸肿瘤的可能性比正常睾丸下降的犬高13倍[7]。然而，间质细胞瘤本身与隐睾症相关的发病率没有增加，因为温度不影响间质细胞[2]。

与其他睾丸肿瘤类型不同，间质细胞瘤被认为在临床上无意义，因为它们在激素上无活性且几乎总是良性的[2]。这些肿瘤通常作为常规检查或去势手术期间的偶然发现出现，很少引起临床症状或并发症。此外，睾丸间质细胞瘤偶尔可能导致犬的高钙血症，尽管这种情况不常见[3]。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/241/1/javma.241.1.55.xml
[2] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[3] Diseases of the parathyroid glands (Proceedings): https://www.dvm360.com/view/diseases-parathyroid-glands-proceedings
[7] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease

## 常见病原体

睾丸间质细胞瘤是非传染性肿瘤，在没有病原体参与的情况下自发发生[1]。与某些可能由细菌或病毒引起的其他睾丸疾病不同，间质细胞瘤通过莱迪希细胞的细胞转化发展，而不是通过传染过程。

目前包括间质细胞瘤在内的睾丸肿瘤病因仍不清楚[1]。尚未确定病毒、细菌或其他病原体是这些肿瘤的致病因素。隐睾症显著增加肿瘤风险，隐睾犬患睾丸肿瘤的可能性比正常睾丸下降的犬高13倍[1]。

虽然睾丸肿瘤本身是非传染性的，但继发性细菌感染偶尔可能使病例复杂化。间质细胞瘤通常不产生临床症状或易导致感染，与其他睾丸肿瘤类型不同[2]。这些肿瘤被认为在激素上无活性，很少引起全身效应或继发性并发症[3]。

非传染性病因使间质细胞瘤区别于其他生殖道疾病，如附睾炎或前列腺炎，这些疾病可能有细菌原因。这种非传染性性质意味着抗菌治疗在治疗原发性肿瘤中不起作用，但如果手术后出现继发感染，可能需要使用。

### Sources

[1] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
[2] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings
[3] Overview of endocrine skin diseases (Proceedings): https://www.dvm360.com/view/overview-endocrine-skin-diseases-proceedings

## 临床症状和体征

睾丸间质细胞瘤在犬中通常表现为多变的临床表现。许多病例无症状，使得在常规检查期间检测具有挑战性。

最具特征性的发现是单侧睾丸肿大，通常在体格检查中偶然发现[1]。受影响的睾丸在触诊时可能感觉坚实或有结节，尽管在早期阶段大小变化可能很微妙。细针抽吸可以帮助区分肿瘤类型，包括间质细胞瘤与其他睾丸肿瘤[2]。

激素影响是最重要的临床表现。过量的雌激素产生通常导致双侧对称性脱毛，特别影响躯干、胁腹和会阴区域[1]。额外的皮肤病学体征包括悬垂腹、皮肤萎缩、色素沉着过度以及干燥、脆弱的被毛[1]。

雌性化综合征可能发展，特征为男性乳腺发育、包皮肿胀和吸引公犬靠近受影响的患犬。一些犬表现出行为变化，包括性欲减退和改变领地标记模式。

间质细胞瘤被认为在激素上无活性且几乎总是良性的[3]。与支持细胞瘤不同，间质细胞瘤不依赖温度，并且与隐睾症相关的发病率没有增加[3]。发病率不受睾丸位置影响，因为温度不影响间质细胞[3]。

间质细胞瘤的品种易感性尚未明确，与其他睾丸肿瘤不同。年龄相关模式显示在中年至老年未去势公犬中发生率增加。猫很少发展这些肿瘤，使其主要是犬类疾病。

### Sources
[1] Endocrine skin diseases (Proceedings): https://www.dvm360.com/view/endocrine-skin-diseases-proceedings
[2] Abnormal reproductive ultrasononography in dogs and toms (Proceedings): https://www.dvm360.com/view/abnormal-reproductive-ultrasononography-dogs-and-toms-proceedings
[3] Surgery of the urogenital system (Proceedings): https://www.dvm360.com/view/surgery-urogenital-system-proceedings

## 诊断方法

诊断睾丸间质细胞瘤需要系统的方法，结合临床评估和先进的诊断技术。体格检查包括仔细的睾丸触诊以识别肿块、不对称或质地变化[1]。然而，仅靠触诊可能无法检测较小的肿瘤或区分肿瘤类型。

超声检查对于评估睾丸结构和识别肿瘤特有的低回声或异质性肿块至关重要[7]。彩色多普勒血流可以评估血管模式，并帮助与其他疾病如扭转或炎症区分。

细针抽吸提供细胞学样本用于初步肿瘤表征，尽管它可能并不总是区分不同的睾丸肿瘤类型[2,7]。激素分析，特别是睾酮水平，可以揭示功能性犬的升高浓度[1]。在引用的病例中，基础睾酮显著升高至2,747 pg/ml（正常去势范围<50 pg/ml）。

组织病理学检查仍然是明确诊断的金标准[1]。检查显示间质（莱迪希）细胞增殖，具有特征性细胞形态。额外检测可能包括人绒毛膜促性腺激素（HCG）刺激试验以评估激素反应性[1]。

全血细胞计数和血清生化谱有助于评估全身效应并排除并存疾病。全面的诊断检查至关重要，因为间质细胞瘤通常是良性的，但可能通过激素效应引起继发性并发症。

### Sources

[1] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[2] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0231.xml
[7] Orchitis and Epididymitis in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/orchitis-and-epididymitis-in-dogs-and-cats

## 治疗选择

犬睾丸间质细胞瘤（莱迪希细胞瘤）的主要治疗方法是通过睾丸切除术或去势手术切除[1][7][8]。如果保持生育能力不重要，去势是首选治疗方法，因为它消除了激素产生并解决了相关的临床症状，如前列腺增生[1]。

对于单侧受累，半去势可能在有价值的育种动物中保持生育能力。然而，必须保护未受影响的睾丸免受热损伤和疾病进展[1]。在可行时建议完全手术切除，具有5厘米侧缘和去除两个筋膜层以获得最佳结果[2]。

间质细胞瘤通常在激素上无活性且几乎总是良性的，转移潜力极罕见[7][8]。术后护理包括监测手术并发症和评估激素相关体征。在肿瘤产生过量雄激素的情况下，去势解决了临床表现，包括皮肤病学变化和前列腺增大[7][8]。

使用葡萄糖酸锌（Neutersol、EsterilSol、Infertile）进行化学去势提供了一种非手术替代方案，通过睾丸内注射导致永久性睾丸硬化[2]。这种方法可能适用于全身麻醉有风险的犬，尽管手术去势仍然是完全肿瘤切除和确定性治疗的金标准。

### Sources
[1] Orchitis and Epididymitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-male-small-animal/orchitis-and-epididymitis-in-dogs-and-cats
[2] Nonsurgical methods of contraception in dogs and cats: https://www.dvm360.com/view/nonsurgical-methods-contraception-dogs-and-cats-where-are-we-now
[7] A dog with an enlarged prostate and bloody preputial: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[8] Can you rule out a steroid hepatopathy?: https://www.dvm360.com/view/can-you-rule-out-steroid-hepatopathy

## 预防措施

睾丸间质细胞瘤最有效的预防措施是早期去势[1]。由于这些肿瘤不依赖雄激素，常见于老年未去势雄性，常规去势完全消除了风险，同时提供额外的健康益处[1]。

隐睾动物需要特殊的管理考虑。有滞留睾丸的犬应接受双侧睾丸的及时手术切除，因为隐睾睾丸的肿瘤风险增加[2]。在探查手术期间切除的所有腹腔内睾丸都应提交进行组织病理学检查以评估睾丸肿瘤[2]。

育种计划应避免使用已知有睾丸肿瘤家族倾向的动物[3]。虽然间质细胞瘤本身通常是良性的且在激素上无活性，但仔细的谱系分析有助于减少遗传风险因素[3]。受影响犬的治疗通常仅限于去势，并且由于该疾病的遗传性质，不鼓励受影响个体繁殖[4]。

常规健康筛查方案应包括未去势育种雄性的年度种用检查，进行彻底的阴囊触诊以评估睾丸大小、对称性和质地[5]。早期诊断对于预防可能损害剩余正常睾丸的温度和压力变化至关重要[5]。随着犬年龄增长，定期兽医检查变得越来越重要，因为间质细胞瘤常见于老年患者。

### Sources

[1] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[2] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[3] Bladder and reproductive ultrasonography: the good the bad and the really ugly (Proceedings): https://www.dvm360.com/view/bladder-and-reproductive-ultrasonography-good-bad-and-really-ugly-proceedings
[4] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[5] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings

## 鉴别诊断

睾丸间质细胞瘤的主要鉴别诊断包括其他睾丸肿瘤和非肿瘤性睾丸疾病。犬的原发性睾丸肿瘤起源于生殖细胞（精原细胞瘤）或性索基质成分（支持细胞瘤和间质莱迪希细胞瘤）[1]。这三种肿瘤类型代表了犬患者中最常见的睾丸肿瘤[2]。

精原细胞瘤起源于生殖细胞，通常表现为睾丸实质内边界清晰的肿块。支持细胞瘤常发生在隐睾睾丸中，并经常引起雌激素过多症的迹象，包括雌性化综合征、男性乳腺发育和吸引公犬[3]。这种激素活性使支持细胞瘤与间质细胞瘤区分开来，后者很少产生激素过量的临床症状。

需要鉴别的非肿瘤性疾病包括睾丸炎、附睾炎、睾丸扭转和脓肿[4]。这些炎症性疾病通常表现为疼痛、急性发作和疾病全身性体征，与睾丸肿瘤通常无痛、缓慢进展的性质形成对比。

彩色多普勒超声检查有助于区分肿瘤肿块和非肿瘤性疾病，如睾丸扭转、嵌顿性阴囊疝或血肿[4]。细针抽吸进行细胞学检查和组织病理学检查对于明确区分肿瘤类型和确认诊断仍然是必不可少的。

### Sources
[1] Primary testicular neoplasms in dogs originate from either the germ cells (seminoma), sex-cord stromal elements (SCT and interstitial Leydig: https://avmajournals.avma.org/view/journals/javma/241/1/javma.241.1.55.xml
[2] Sertoli cell tumor is 1 of the 3 most common primary testicular tumors: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0231.xml
[3] Dogs with Sertoli cell tumors often have signs of hyperestrinism: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.19.07.0336.xml
[4] Ultrasonography with color flow Doppler can also help rule out differential diagnoses, such as testicular torsion, incarcerated scrotal hernia, hematoma, and neoplastic mass: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-male-small-animal/orchitis-and-epididymitis-in-dogs-and-cats

## 预后

患有睾丸间质细胞瘤的犬预后极佳[1]。这些肿瘤通常是良性的，临床意义最小，没有转移潜力。与其他睾丸肿瘤类型不同，间质细胞瘤显示很少的临床症状，不产生雌激素，并且不转移[1]。它们通常作为常规检查期间的偶然发现，而不是引起明显的健康问题。

手术去势提供了具有出色结果的治愈性治疗。低转移率使手术去势在大多数犬中非常成功[1]。通过去势完全切除肿瘤消除了局部复发或进展的任何可能性。接受治疗的睾丸癌犬的预后通常非常好[1]。

对于转移病例，预后变得更加谨慎，结果根据位置、类型和治疗而差异很大[1]。然而，考虑到间质细胞瘤的良性性质，这种情况极其罕见。

手术治疗后的长期管理考虑因素很少。动物通常完全恢复，没有持续的并发症或需要额外的治疗干预。间质细胞瘤的良性性质意味着受影响的犬在手术后保持正常的预期寿命和生活质量。

### Sources
[1] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
