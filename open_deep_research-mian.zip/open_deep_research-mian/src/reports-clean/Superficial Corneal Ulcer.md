# 伴侣动物浅表性角膜溃疡

## 疾病概述

**定义**

浅表性角膜溃疡是指角膜上皮层的缺损，未穿透浅基质层，特征为覆盖角膜的保护性上皮层丧失（Merck兽医手册，2024年）。这些溃疡是小动物兽医临床中最常见的眼科疾病之一，需要及时诊断和适当治疗，以防止发展为更深层的、威胁视力的病变。

**流行病学背景**

浅表性角膜溃疡影响犬和猫，具有明显的种属和品种易感性。在猫中，猫疱疹病毒-1型（FHV-1）是主要潜在病因，估计80%的猫存在潜伏感染，约40%会经历复发性感染，可表现为溃疡性角膜炎（DVM360，2024年）。短头颅犬种包括西施犬、哈巴狗和波士顿梗犬由于眼球位置突出和可能存在的角膜神经感觉减退而表现出易感性增加（DVM360，2024年）。拳师犬对惰性角膜溃疡或复发性角膜糜烂表现出特殊易感性，这些非愈合性溃疡代表了一种品种特异性综合征（DVM360，2024年）。年龄易感性因潜在病因而异，创伤性溃疡可发生于所有年龄段，而某些品种特异性疾病如自发性慢性角膜上皮缺损（SCCED）通常影响中老年动物（Merck兽医手册，2024年）。

## 常见病原体

**病毒性病因**

猫疱疹病毒-1型（FHV-1）仍然是与猫浅表性角膜溃疡相关的最重要的病毒病原体[1]。估计80%的猫潜伏感染FHV-1，约40%会经历复发性感染，可表现为溃疡性角膜炎[2]。该病毒引起直接的细胞病变效应，导致浅表、不规则的角膜溃疡。特征性的树枝状溃疡可通过荧光素或玫瑰红染色检测，被认为是疱疹病毒感染的特征性表现[2]。对于原因不明的角膜溃疡猫，应将疱疹病毒感染作为主要鉴别诊断[1]。

**细菌病原体**

继发性细菌感染通常使伴侣动物的浅表性角膜溃疡复杂化[6]。在犬和马中，大多数溃疡源于机械性损伤，但继发性细菌污染经常发生并可能导致快速恶化[6]。角膜溃疡的病因包括创伤、干燥性角膜结膜炎、暴露性角膜炎、异物和眼睑异常[2]。细菌参与的标志是溃疡边缘出现致密白色浸润[6]。从严重的传染性角膜溃疡中已分离出口腔常驻细菌，特别是在短头颅犬中[1]。

**真菌病原体**

真菌感染在伴侣动物中较为少见，但仍是角膜溃疡的重要病因[2][3]。曲霉菌属是犬中最常见的相关真菌病原体[2]。其他与角膜溃疡相关的真菌包括镰刀菌属、枝顶孢属、弯孢属、假阿利什菌属和链格孢属[2]。在马中，白色念珠菌和曲霉菌均在角膜上皮下被发现，从角膜溃疡中分离出至少七至九种不同真菌[6]。真菌性角膜炎通常表现为角膜溃疡伴有白色蓬松的基质浸润或斑块，偶尔由暗色真菌引起棕色角膜色素沉着[2][3]。

### Sources

[1] Oral bacteria may affect conjunctival microorganisms in ...: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.11.0260.xml
[2] Ophthalmology Challenge: Aggressive ulcerative keratitis ...: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[3] Bugs! Identifying common infectious agents (Proceedings): https://www.dvm360.com/view/bugs-identifying-common-infectious-agents-proceedings
[4] Ocular diseases of nontraditional and exotic pets ...: https://www.dvm360.com/view/ocular-diseases-nontraditional-and-exotic-pets-proceedings
[5] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings-0
[6] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

## 临床症状和体征

浅表性角膜溃疡在犬和猫中都表现出特征性的疼痛表现。临床症状包括**睑痉挛**（眼睑不自主痉挛）、**流泪**（过度流泪）和不同程度的**结膜充血**[1][2]。动物通常表现出**畏光**，并可能因不适而不愿睁开患眼[1]。

**角膜变化**是浅表溃疡的特征性表现。受影响的角膜可能外观不规则，并出现不同程度的**水肿**，使其呈现混浊外观[2]。**角膜新生血管**经常发生，浅表血管从角膜缘向溃疡区域延伸[1]。荧光素染色确认上皮缺损，阳性染色保留表明保护性上皮层受损的区域[2]。

**非典型表现**可能发生，特别是在自发性慢性角膜上皮缺损（SCCED）病例中。这些病例可能表现为轻微至无角膜新生血管，并可能具有特征性的**"晕环"染色模式**，其中荧光素在松散的上皮边缘下扩散，在较亮绿色染色中心周围形成暗绿色边缘[1]。

**种属差异**在犬和猫之间很明显。在猫中，**角膜坏死**可能作为并发症发展，表现为角膜表面深棕色至黑色斑块[5]。猫的病例常涉及**疱疹病毒感染**，可能表现为树枝状溃疡模式，这被认为是该病的特征性表现[9][10]。

**品种特异性模式**包括**短头颅品种**如西施犬、哈巴狗和波士顿梗犬的较高易感性，原因是眼球位置突出和可能存在的角膜神经感觉减退[8]。拳师犬对惰性角膜溃疡或复发性角膜糜烂表现出特殊易感性[6][7]。

### Sources
[1] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[2] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[3] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings
[4] The dos and don'ts of treating ocular disease in cats (Proceedings): https://www.dvm360.com/view/dos-and-donts-treating-ocular-disease-cats-proceedings
[5] The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

## 诊断方法

浅表性角膜溃疡的诊断依赖于系统的临床检查结合必要的眼科诊断测试[1]。基础包括全面的病史采集和视觉评估不适迹象，包括睑痉挛、流泪和角膜混浊[1]。

**荧光素染色**代表角膜溃疡诊断的金标准[1]。这种水溶性染料附着于暴露的角膜基质而非完整上皮，在钴蓝光下产生亮绿色荧光[4]。在浅表溃疡中，特征性染色模式可能显示上皮边缘下陷，在较亮中央区域周围有暗绿色晕环[7]。后弹力层膨出可能显示中央清亮区域，荧光素无法穿透后弹力膜[3]。

**希尔默泪液测试（STT）**必须在任何局部用药前进行以评估泪液产生[8]。正常值在犬中为>15毫米/分钟，<10毫米表明干燥性角膜结膜炎作为潜在病因[8]。STT应始终在双眼进行以供比较[10]。

**附加诊断程序**包括眼压测量以测量眼内压，在排除青光眼时特别重要[9]。当荧光素阴性时，玫瑰红染色可检测部分厚度上皮缺损和定性泪膜异常[10]。对于更深或感染的溃疡，应在荧光素应用前进行角膜细胞学检查和细菌培养及药敏试验[1][9]。

**高级诊断**可能包括在需要时对病毒病原体进行PCR检测，尽管这在常规实践中较少进行[2]。泪膜破裂时间评估可识别导致复发性溃疡的定性泪液缺乏[4]。

### Sources
[1] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[2] javma.25.03.0187.pdf: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0187/javma.25.03.0187.pdf
[3] Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers
[4] Turning up your ocular exam techniques for better diagnosis (Proceedings): https://www.dvm360.com/view/turning-your-ocular-exam-techniques-better-diagnosis-proceedings
[5] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[6] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[7] Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[8] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings

## 治疗选择

浅表性角膜溃疡治疗侧重于预防感染和疼痛管理[1]。局部抗生素如妥布霉素、氧氟沙星或新霉素-多粘菌素-短杆菌肽最初每4-8小时给药一次[1]。1%阿托品滴眼液控制睫状肌痉挛引起的疼痛，通常每天一到两次给药[2]。

对于复杂的深部溃疡，需要更密集的治疗。氟喹诺酮类药物如氧氟沙星或环丙沙星在治疗初期每1-2小时给药一次[2]。每小时局部应用血清为溶解性溃疡提供抗胶原酶特性[1]。口服抗生素包括多西环素（5mg/kg）和阿莫西林克拉维酸提供全身支持[1]。

疼痛管理包括局部阿托品和口服药物。曲马多和加巴喷丁有效控制角膜疼痛[2]。口服抗炎药物有益，但应避免局部非甾体抗炎药，因为它们可能增加感染风险[2]。

非愈合性惰性溃疡需要手术干预。金刚砂磨削清创去除松散上皮并促进愈合[6]。使用25号针头进行网格角膜切开术制造浅基质划痕以改善上皮粘附[6]。这些手术通常需要2-3周才能完全愈合[7]。

超过角膜深度50%的深基质溃疡需要手术修复[10]。结膜蒂瓣提供结构支持和血管化[2]。替代方案包括角膜结膜转位瓣、生物合成移植物或角膜移植，取决于溃疡严重程度[8]。

### Sources
[1] Ocular emergencies (Proceedings): https://www.dvm360.com/view/ocular-emergencies-proceedings-1
[2] Medical treatment options for corneal ulcers in dogs: https://www.dvm360.com/view/medical-treatment-options-for-corneal-ulcers-in-dogs
[6] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[7] Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers
[8] Corneal surgical techniques: Conjunctival pedicle grafts and beyond (Proceedings): https://www.dvm360.com/view/corneal-surgical-techniques-conjunctival-pedicle-grafts-and-beyond-proceedings
[10] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

## 预防措施

浅表性角膜溃疡的预防侧重于病毒疫苗接种、减少创伤和环境管理[1][2]。对于病毒病因，使用改良活疫苗鼻内接种猫疱疹病毒（FHV-1）比胃肠外疫苗接种提供更优越的细胞介导免疫，可在四天内诱导保护[2]。

减少环境创伤对于预防角膜损伤至关重要。这包括从宠物环境中移除潜在危险物，避免粗暴玩耍活动，并保护短头颅品种免于增加眼创伤风险的情况[3]。应从环境中消除粘土猫砂、香烟烟雾、发胶和地毯清洁剂作为潜在角膜刺激物[2]。

品种特异性预防护理对高危人群至关重要。短头颅品种需要特别关注，因为它们对角膜创伤和溃疡的易感性增加[3][6]。这些患者受益于定期眼科检查和活动中的保护措施。

高危患者监测方案应包括泪液产生、眼睑结构和睫毛异常的常规评估[3]。患有慢性FHV-1感染的猫可能受益于预防性L-赖氨酸补充，口服250-500毫克每天两次，它竞争性抑制病毒复制[2][5]。定期眼科筛查允许在浅表溃疡发展为更深、更严重的角膜缺陷之前进行早期检测和干预。

### Sources
[1] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings
[2] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[3] Understanding how the cornea heals offers insights into treatment: https://www.dvm360.com/view/understanding-how-cornea-heals-offers-insights-treatment
[4] How study of naturally occurring ocular disease in animals: https://avmajournals.avma.org/view/journals/javma/260/15/javma.22.08.0383.xml
[5] Canine ocular manifestations of systemic disease: https://www.dvm360.com/view/canine-ocular-manifestations-systemic-disease-when-primary-problem-isnt-eye-proceedings
[6] Handling ocular emergencies (Proceedings): https://www.dvm360.com/view/handling-ocular-emergencies-proceedings

## 鉴别诊断

几种疾病可能模拟浅表性角膜溃疡，需要仔细鉴别以进行适当治疗。**自发性慢性角膜上皮缺损（SCCED）**是最重要的鉴别诊断，表现为慢性、浅表、非感染性溃疡，伴有松散上皮边缘和不同程度的角膜血管化[1]。这些惰性溃疡在没有明显原因的情况下持续超过7-10天，其特征是上皮与基底膜粘附不良[2]。

**角膜内皮营养不良**表现为进行性角膜水肿，呈蓝白色外观，通常从侧方开始并扩散至整个角膜[1]。与浅表溃疡不同，内皮营养不良缺乏溃疡且最初不显示荧光素摄取，尽管大疱最终可能破裂导致继发性溃疡[2]。

**角膜营养不良和变性**表现为基质内白色、不规则沉积物，通常双侧且在特定品种中遗传[2]。这些疾病通常缺乏溃疡特有的上皮缺损，除非发生继发性溃疡，否则不保留荧光素染色。

**干燥性角膜结膜炎（KCS）**常伴随角膜溃疡，必须使用希尔默泪液测试排除，因为泪液产生不足易导致溃疡形成[1]。腊肠犬的**点状角膜炎**显示多灶性角膜混浊，保留荧光素但代表免疫介导疾病而非真正溃疡[1]。

**嗜酸性粒细胞性角膜炎**是猫特有的，表现为进行性角膜血管化，角膜表面有白色斑块，常表现为非愈合性溃疡[3]。这种免疫介导疾病对局部皮质类固醇而非常规溃疡治疗有反应。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/en/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
