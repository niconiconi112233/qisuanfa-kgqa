# 伴侣动物抗凝剂中毒

抗凝剂中毒是小动物兽医实践中最关键的急症之一，由摄入通过维生素K拮抗作用破坏凝血级联反应的灭鼠剂引起。尽管监管变化限制了住宅区对第二代化合物的获取，这些强效抗凝剂仍然是犬猫中毒的主要原因。本报告提供了全面的临床指导，涵盖维生素K依赖性凝血因子耗竭的病理生理学、使用凝血测试的诊断方法、强调维生素K1治疗和血液制品支持的循证治疗方案，以及预防策略。摄入后3-7天临床症状出血的延迟发作带来了独特的诊断挑战，需要系统评估和监测，以实现通过适当干预可能达到的优异存活率。

## 疾病概述与流行病学

抗凝剂中毒是犬猫中一种可能危及生命的情况，由摄入抗凝性灭鼠剂引起[1]。这些化合物抑制维生素K环氧化物还原酶，阻断维生素K依赖性凝血因子II、VII、IX和X的合成，导致凝血病[2]。

抗凝性灭鼠剂根据效力和作用持续时间分为两类。第一代化合物包括华法林、敌鼠、氯鼠酮和杀鼠酮，通常需要多次摄食才会引起毒性[2]。第二代抗凝剂，如溴敌隆、溴鼠灵、杀它仗和鼠得克，具有显著更低的致死剂量，通常只需一次摄食即可导致毒性[2]。这些第二代产品仍然是最危险的，其中溴敌隆是最强效的之一[7]。

抗凝性灭鼠剂是伴侣动物中最常见的中毒之一[1]。尽管美国环保署在2012年对第二代抗凝剂的住宅使用进行了限制，但这些产品仍可用于商业害虫控制和农业用途，维持了显著的暴露风险[1]。暴露通过直接摄入诱饵产品、饲料污染、摄入含有灭鼠剂的猎物（继发性毒性），或罕见的恶意行为发生[2]。与犬相比，猫对抗凝效应具有显著更强的抵抗力，很少发生中毒[1][2]。

### Sources

[1] The most common poisons for pets: https://www.dvm360.com/view/the-most-common-poisons-for-pets

[2] Anticoagulant Rodenticide (Warfarin and Congeners) Poisoning in Animals: https://www.merckvetmanual.com/toxicology/rodenticide-poisoning/anticoagulant-rodenticide-warfarin-and-congeners-poisoning-in-animals

[3] Toxicology Brief: The 10 most common toxicoses in cats: https://www.dvm360.com/view/toxicology-brief-10-most-common-toxicoses-cats

[4] ABCDs of rodenticides (Proceedings): https://www.dvm360.com/view/abcds-rodenticides-proceedings

[5] Toxicology Brief: The 10 most common toxicoses in dogs: https://www.dvm360.com/view/toxicology-brief-10-most-common-toxicoses-dogs

[6] Top 10 Pet Poisons of 2024 are announced: https://www.dvm360.com/view/top-10-pet-poisons-of-2024-are-announced-thc-pet-exposure-shows-decrease

[7] Rodenticides: Top 4 ingredients that kill pets: https://www.dvm360.com/view/rodenticides-top-4-ingredients-kill-pets

## 病理生理学与临床表现

抗凝性灭鼠剂通过机制抑制维生素K环氧化物还原酶，这是负责再循环和产生维生素K1的关键酶[1]。这破坏了肝脏对维生素K依赖性凝血因子II、VII、IX和X（"K因子"）的合成，阻止了凝血酶原向凝血酶的充分转化，导致凝血病[1][4]。

受影响的凝血因子的血清半衰期范围为6.2至16.5小时，循环供应通常在毒性摄入后24-64小时内耗尽[1]。这创造了一种特征性的延迟发作模式，其中凝血参数在摄入后2-5天升高，而临床出血证据通常在暴露后3-7天出现[1]。

临床表现反映了凝血病和出血，包括食欲不振、嗜睡、虚弱、鼻衄和继发于胸腔或肺出血的呼吸窘迫[1]。患者可能出现血肿、伴有苍白的瘀点、腔隙出血、呕血、黑便、便血和血尿[1]。非典型体征取决于出血部位，可能包括关节疼痛、共济失调、癫痫发作、咽部肿胀或引起呼吸窘迫的气管压迫[1]。

由于因子VII的半衰期短，犬猫的凝血酶原时间（PT）首先升高，随后部分凝血活酶时间（PTT）升高[1][4]。到临床出血发生时，PT和PTT通常都延长[1]。物种特异性差异很小，尽管猫可能对某些第二代抗凝剂更敏感[1]。严重程度取决于特定灭鼠剂的效力、摄入剂量和个体患者因素[1]。

### Sources

[1] Anticoagulant Rodenticide (Warfarin and Congeners) Poisoning in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/rodenticide-poisoning/anticoagulant-rodenticide-warfarin-and-congeners-poisoning-in-animals

[2] VIN Anticoagulant Rodenticides: https://www.vin.com/vin_ce/abvp/html/anticoagulant_rodenticides.html

## 诊断方法

诊断抗凝剂中毒需要结合临床表现、凝血测试和确认性检测的系统评估[1]。初始评估侧重于凝血酶原时间（PT）和活化部分凝血活酶时间（aPTT）测量，它们分别评估外源性/共同和内源性/共同凝血途径[1][2]。

由于因子VII的半衰期短，犬猫的PT首先升高，在摄入后36-48小时内延长[1][2]。一种监测方法涉及在疑似摄入后48小时检查PT - 如果摄入了毒性剂量，PT将在出血发展前延长[2]。aPTT在PT延长后不久升高，到临床出血发生时，PT和aPTT通常都升高[1]。

实验室测试显示出血患者的凝血时间严重延长[1]。活化凝血时间（ACT）是最不敏感的测试，需要因子降至正常水平的10%以下[3]。PIVKA测试检测维生素K依赖性凝血因子缺乏，但对抗凝性灭鼠剂中毒不具有特异性[1]。

影像学检查包括胸部X光和腹部超声有助于识别出血部位和评估失血严重程度[1]。胸腔出血可能显示叶间裂隙线和气管腔外偏移，而腹腔出血导致浆膜细节丢失[1]。

鉴别诊断包括弥散性血管内凝血、肝脏疾病和遗传性因子缺乏[1][2]。确认性检测涉及专门的实验室分析，以鉴定特定的抗凝化合物（当可用时）[1]。

### Sources
[1] Transfusion support of the bleeding patient: Part II: https://www.dvm360.com/view/transfusion-support-bleeding-patient-part-ii-proceedings
[2] Anticoagulant Rodenticide (Warfarin and Congeners) Poisoning in Animals: https://www.merckvetmanual.com/toxicology/rodenticide-poisoning/anticoagulant-rodenticide-warfarin-and-congeners-poisoning-in-animals
[3] Practical coagulation and coagulation monitoring (Proceedings): https://www.dvm360.com/view/practical-coagulation-and-coagulation-monitoring-proceedings

## 治疗方案

紧急稳定始于处理心血管休克和出血控制[1]。立即以1.5-2倍维持速率进行静脉液体复苏对凝血病患者至关重要，避免含钙溶液[2]。氧气治疗和疼痛管理在初始稳定期间提供基本支持护理。

**去污程序**仅在摄入后前4-12小时内有效[1][3]。如果摄入发生在6小时内，应使用阿扑吗啡（犬）或甲苯噻嗪（猫）诱导呕吐，然后给予活性炭（1-3 g/kg）[2][4]。多次炭剂量可能对溴鼠灵暴露有益。

**维生素K1治疗**仍然是抗凝治疗的基石[1][2]。标准方案涉及每12-24小时口服2.5-5 mg/kg，持续28天[2]。与脂肪餐一起口服可增强吸收，比单独给药高4-5倍[1]。皮下注射在初期是可以接受的，但应避免静脉注射，因为有过敏反应风险[2][4]。

**血液制品输注**在PT/PTT延长且发生活动性出血时适用[2]。新鲜冷冻血浆以10-20 mL/kg（犬）或6-10 mL/kg（猫）的剂量提供所有凝血因子[6]。当同时存在贫血时，新鲜全血是首选[9]。如果出血严重，可能需要浓缩红细胞，输注决定应基于临床症状而非仅PCV。

凝血因子在维生素K1开始治疗后6-12小时内产生，PT/PTT在12-24小时内改善[2]。应继续每周监测凝血时间，直到治疗停止后5-6天值保持正常[1]。

### Sources
[1] Rodenticide Poisoning - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/poisoning/rodenticide-poisoning
[2] Anticoagulant Rodenticide (Warfarin and Congeners) Poisoning in Animals: https://www.merckvetmanual.com/toxicology/rodenticide-poisoning/anticoagulant-rodenticide-warfarin-and-congeners-poisoning-in-animals
[3] ABCD's of rodenticides (Proceedings) - dvm360: https://www.dvm360.com/view/abcds-rodenticides-proceedings-0
[4] Clinical pearls for managing anticoagulant rodenticide intoxication (Proceedings): https://www.dvm360.com/view/clinical-pearls-managing-anticoagulant-rodenticide-intoxication-proceedings
[6] Blood Transfusions in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/blood-groups-and-blood-transfusions-in-dogs-and-cats/blood-transfusions-in-dogs-and-cats
[9] Canine and feline transfusion medicine (Proceedings): https://www.dvm360.com/view/canine-and-feline-transfusion-medicine-proceedings

## 预防与预后

**预防以环境管理为中心**

预防抗凝剂灭鼠剂中毒的最有效方法涉及严格的环境控制措施[1]。宠物主人应将灭鼠剂储存在宠物无法接触的安全容器中，并遵循符合EPA标准的诱饵站协议。由于中毒通常是由直接摄入诱饵而非食用中毒老鼠引起，因此将诱饵放置在远离宠物接触区域的适当位置至关重要[1]。

2008年后EPA法规要求防篡改站并限制公众获取第二代抗凝剂，无意中增加了溴鼠灵暴露，使预防策略复杂化[2][3]。溴鼠灵现在在犬中排名第三大最常见毒素，近年来从第五位上升[5]。

**预后因素和预期结果**

当进行积极和适当的治疗时，抗凝性灭鼠剂中毒具有极好的预后，80-90%的患者即使在出现活动性出血时也能存活[4]。在临床出血发展前早期干预显著改善结果[1]。

关键预后因素包括治疗开始的时间、就诊时出血严重程度以及主人对延长维生素K1治疗的依从性[4][1]。重要器官（脑、心包）大量出血的动物预后更为谨慎[1]。

**长期监测要求**

第二代抗凝剂的治疗时间通常为2-4周，有些需要长达6周[1][2]。应在维生素K1治疗停止后48-72小时重新检查凝血酶原时间，以确保足够的治疗持续时间[2][6]。活动限制仍然至关重要，直到凝血参数完全正常化[4]。

### Sources
[1] Rodenticides: The old and the new (Proceedings): https://www.dvm360.com/view/rodenticides-old-and-new-proceedings
[2] Veterinary neurology alert: Bromethalin toxicosis on the rise in pets: https://www.dvm360.com/view/veterinary-neurology-alert-bromethalin-toxicosis-rise-pets
[3] New rodenticide without antidote alarms pet toxicology experts: https://www.dvm360.com/view/new-rodenticide-without-antidote-alarms-pet-toxicology-experts
[4] Clinical pearls for managing anticoagulant rodenticide intoxication (Proceedings): https://www.dvm360.com/view/clinical-pearls-managing-anticoagulant-rodenticide-intoxication-proceedings
[5] Top 10 Pet Poisons of 2024 are announced: https://www.dvm360.com/view/top-10-pet-poisons-of-2024-are-announced-thc-pet-exposure-shows-decrease
[6] Transfusion support of the bleeding patient: Part II (Proceedings): https://www.dvm360.com/view/transfusion-support-bleeding-patient-part-ii-proceedings
