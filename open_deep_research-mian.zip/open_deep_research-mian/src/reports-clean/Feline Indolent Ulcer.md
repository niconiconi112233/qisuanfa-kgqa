# 猫惰性溃疡

猫惰性溃疡是嗜酸性粒细胞肉芽肿复合体最典型的表现之一，这是一种显著影响猫健康的皮肤综合征。这些特征性的"啮齿动物溃疡"表现为隆起性糜烂性病变，主要影响上唇，形成独特的"融化"外观，兽医在临床实践中经常遇到这种情况。

本综合报告探讨了猫惰性溃疡的多方面性质，从涉及跳蚤、食物和环境触发因素的复杂过敏病因学，到其特征性的无痛表现（这使其与其他口腔病变区分开来）。分析涵盖了基本诊断方法，包括细胞学和组织病理学；利用皮质类固醇和免疫抑制疗法的循证治疗方案；以及识别潜在过敏原因对成功长期管理的关键重要性。

## 摘要

猫惰性溃疡是一种复杂的皮肤疾病，需要全面了解其过敏发病机制和战略管理方法。该疾病主要由对跳蚤、食物过敏原或环境触发因素的过敏反应引起，遗传易感性在早发病例中起作用。临床表现特征为无痛性糜烂性唇部病变，具有特征性隆起边缘，通过其非瘙痒性质和通常缺乏全身性嗜酸性粒细胞增多症与其他口腔病理相区分。

治疗成功很大程度上取决于通过系统方法识别和控制潜在过敏原因，包括严格的跳蚤控制、饮食排除试验和环境管理。虽然皮质类固醇提供有效的症状缓解，但长期管理需要解决根本原因以防止复发。

| 预后因素 | 良好结局 | 不良结局 |
|-------------------|------------------|--------------|
| 发病年龄 | 晚发性（过敏相关） | 早发性（遗传基础） |
| 潜在原因 | 可识别的过敏原 | 特发性病例 |
| 治疗反应 | 对过敏原控制有反应 | 类固醇依赖 |

早期干预和系统评估潜在过敏提供了最佳结果，尽管兽医必须让大多数病例的主人做好终身管理的准备，对于难治性病例建议转诊至皮肤科。

## 疾病概述

猫惰性溃疡是嗜酸性粒细胞肉芽肿复合体（EGC）的三种经典表现之一，该疾病特征是嗜酸性粒细胞浸润皮肤和/或口腔组织[1]。也称为啮齿动物溃疡，这些病变通常表现为影响猫上唇的隆起性溃疡区域，尽管它们也可能发生在口腔和其他皮肤区域[2][3]。

嗜酸性粒细胞肉芽肿复合体是一种最常见于猫的皮肤疾病，代表一种综合征而非特定诊断[2]。EGC没有年龄或品种易感性，尽管报告表明雌性猫可能易患该疾病[2]。

虽然当前文献中关于猫惰性溃疡患病率和品种易感性的具体流行病学数据仍然有限，但该疾病被认为与环境因素有关，如跳蚤侵染、食物过敏和特应性皮炎[2][4]。与惰性唇溃疡相关的主要基础疾病是跳蚤过敏、食物过敏和特应性皮炎；当这些得到控制时，唇部病变就会消退[4]。

### Sources
[1] a retrospective study of 38 cases (1997-2022) in: https://avmajournals.avma.org/view/journals/javma/261/S2/javma.23.06.0312.xml
[2] Having a complex over eosinophilic granuloma complex?: https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[3] Feline dermatology (Proceedings): https://www.dvm360.com/view/feline-dermatology-proceedings
[4] Diverse group of diseases culprits for feline eosinophilic granulomas: https://www.dvm360.com/view/diverse-group-diseases-culprits-feline-eosinophilic-granulomas

## 病因学和发病机制

猫惰性溃疡，也称为嗜酸性粒细胞溃疡或啮齿动物溃疡，是嗜酸性粒细胞肉芽肿复合体（EGC）的一部分。病因是多因素的，涉及过敏超敏反应作为主要潜在机制[1]。

最常见的识别触发因素包括跳蚤过敏性皮炎、食物过敏和特应性皮炎（环境过敏）[1,2]。当这些潜在的过敏状况得到控制时，唇部病变通常会消退[1]。此外，传染性病原体如犬小孢子菌偶尔可能引起类似的唇部溃疡[1]。

遗传或遗传因素也在疾病发展中起作用[2,3]。一些病例发生在特定无病原体猫群中，表明存在独立于环境过敏原的遗传易感性[1]。寄生虫、细菌、异物反应和病毒原因已被记录为促成因素[5]。

发病机制涉及复杂的免疫学机制，以嗜酸性粒细胞脱颗粒和炎症介质释放为中心[1]。嗜酸性粒细胞脱颗粒产物覆盖胶原纤维而不改变其结构，形成特征性的组织学外观[1]。然而，与其他EGC形式相比，惰性溃疡的血液和组织嗜酸性粒细胞增多症较少见[1,3]。

无法识别潜在过敏原因的病例被归类为特发性[3]。该疾病代表一种反应性炎症皮肤模式而非原发性疾病实体，强调了识别和处理潜在触发因素对有效管理的重要性。

### Sources
[1] Eosinophilic granuloma complex in cats and dogs: https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings
[2] Eosinophilic Granuloma Complex in Cats - Cat Owners: https://www.merckvetmanual.com/en/cat-owners/skin-disorders-of-cats/eosinophilic-granuloma-complex-in-cats
[3] Having a complex over eosinophilic granuloma complex?: https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[4] Feline dermatology: https://www.dvm360.com/view/feline-dermatology-proceedings

## 临床症状和体征

猫惰性溃疡表现出独特的临床特征，有助于诊断[1]。这些病变表现为界限清晰的、单侧或双侧的糜烂性至溃疡性结节，具有隆起边缘，最常见于上唇[2]。特征性外观包括唇缘"融化"，形成可能延伸至口腔的糜烂表面[1]。

值得注意的是，惰性溃疡通常无瘙痒且无痛，这与其他口腔病变不同[3]。与嗜酸性粒细胞肉芽肿复合体的其他组成部分不同，惰性溃疡很少出现全身性嗜酸性粒细胞增多症[3]。一些猫可能发展区域性淋巴结病，特别是在更晚期的病变中[5]。

诊断工作从临床表现评估开始，然后是几个关键程序[2]。基本诊断步骤包括毛发检查以评估蠕形螨、印片、伍德灯检查以及在风险病例中进行皮肤真菌培养[2]。病变的细胞学检查通常显示嗜酸性粒细胞和中性粒细胞[3]。

如果病变对适当治疗无反应或突然发展并具有破坏性特征，则建议通过活检进行组织病理学确认[2]。组织学通常显示增生性溃疡性浅表血管周围皮炎，伴有嗜酸性粒细胞、中性粒细胞、单核细胞和纤维化[6]。

重要的鉴别诊断包括鳞状细胞癌（特别是在白猫中）、皮肤真菌感染、细菌感染、病毒感染和其他肿瘤性疾病[1][4]。单侧病变特别需要调查口腔肿瘤[2]。

### Sources

[1] Feline facial skin diseases (Proceedings): https://www.dvm360.com/view/feline-facial-skin-diseases-proceedings
[2] Eosinophilic Skin Diseases in Cats - Integumentary System: https://www.merckvetmanual.com/en-au/integumentary-system/eosinophilic-inflammatory-skin-diseases/eosinophilic-skin-diseases-in-cats
[3] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[4] Approach to the pruritic cat (Proceedings): https://www.dvm360.com/view/approach-pruritic-cat-proceedings
[5] When steroids quit workingfor eosinophilic granuloma complex in cats: https://www.dvm360.com/view/when-steroids-quit-workingfor-eosinophilic-granuloma-complex-cats
[6] Eosinophilic granuloma complex in cats and dogs (Proceedings): https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings

## 治疗和预防

### 药物干预

皮质类固醇仍然是猫惰性溃疡的主要治疗方法[1]。首选口服泼尼松龙，剂量为1 mg/kg，每12小时一次，持续一周，然后在4-6周内逐渐减量至最低有效剂量[1,2]。可注射甲基强的松龙醋酸酯（4 mg/kg）每2-3周注射一次，共三次注射，但频繁使用可能导致糖尿病[1,2]。

环孢素提供了一种替代性免疫抑制方法，剂量为每只猫25 mg，每日一次，持续4-6周，然后减至隔日一次[1,4]。研究表明口腔嗜酸性粒细胞肉芽肿反应良好，但惰性唇溃疡效果较差[1]。必需脂肪酸在某些病例中显示出有效性，四个嗜酸性粒细胞肉芽肿中有四个对治疗有反应[1]。

### 非药物方法

识别和控制潜在过敏对长期管理至关重要[6]。应实施严格的跳蚤控制，对所有家庭宠物每14天使用有效的杀寄生虫剂[4]。持续8-12周的饮食排除试验有助于使用新型或水解蛋白饮食识别食物过敏[4,8]。

### 环境管理和预防

环境过敏原控制包括限制特应性皮炎猫的户外暴露[4]。定期监测继发性细菌感染至关重要，并在适当时进行抗生素治疗[1,6]。预防措施集中在流行地区全年一致的跳蚤控制，以及一旦识别就避免已知的饮食过敏原[4,6]。

大多数病变不可预测地反复发作，需要持续监测，并在病变消退后将药物剂量逐渐减至最低可能水平[2]。

### Sources

[1] Eosinophilic granuloma complex in cats and dogs (Proceedings): https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings
[2] Diverse group of diseases culprits for feline eosinophilic granulomas: https://www.dvm360.com/view/diverse-group-diseases-culprits-feline-eosinophilic-granulomas
[3] VMX 2020-Tips and tricks for managing feline allergies: https://www.dvm360.com/view/vmx-2020-tips-and-tricks-for-managing-feline-allergies
[4] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[5] Fatal skin diseases in dogs and cats: What veterinary professionals need to know: https://www.dvm360.com/view/fatal-skin-diseases-dogs-and-cats-what-veterinary-professionals-need-know
[6] Eosinophilic Granuloma Complex in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/eosinophilic-granuloma-complex-in-cats
[7] Diagnosing food allergies in dogs and cats: Bring your case to trial: https://www.dvm360.com/view/diagnosing-food-allergies-dogs-and-cats-bring-your-case-trial
[8] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings

## 预后

猫惰性溃疡的预后因潜在原因和发病年龄而有显著差异。早发病例往往基于遗传因素，通常无法治愈，需要终身管理[1]。然而，因潜在过敏而发展的晚发病例在识别和控制主要原因时往往有更良好的预后[1]。

大多数猫对适当治疗反应良好，全身性糖皮质激素在许多病例中提供有效的症状缓解[2]。通过适当治疗和管理潜在过敏，预后被认为是良好的，但重要的是要理解猫嗜酸性粒细胞肉芽肿复合体（惰性溃疡是其组成部分）通常是终身管理问题，很少永久消退[2]。

不幸的是，对于嗜酸性粒细胞肉芽肿复合体病变，没有不涉及寻找潜在过敏病因的标准疗法，这需要大量的侦查工作[5]。当类固醇变得无效时，成功的长期管理需要系统评估和治疗潜在原因，包括体外寄生虫、食物过敏、食物储存螨虫过敏、接触过敏或特应性皮炎[5]。

早期治疗通常比延迟干预产生更好的结果，全身性糖皮质激素在慢性病例中通常无效[3]。对于难治性病例，转诊至委员会认证的皮肤科医生可能有助于实现最佳患者结果[4]。

### Sources
[1] A clinical approach to feline atopic dermatitis: https://www.dvm360.com/view/a-clinical-approach-to-feline-atopic-dermatitis
[2] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[3] ACVC 2017: Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats
[4] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis
[5] When steroids quit workingfor eosinophilic granuloma complex in cats: https://www.dvm360.com/view/when-steroids-quit-workingfor-eosinophilic-granuloma-complex-cats
