# 伴侣动物椎骨骨折与脱位

椎骨骨折和脱位是犬猫的危急重症，主要由车祸、坠落和咬伤等创伤事件引起。这些脊髓损伤可导致毁灭性的神经后果，从轻微的步态异常到完全瘫痪。胸腰段是最常受影响的部位，深痛知觉的存在与否是最重要的预后指标。本综述全面探讨了小动物临床实践中椎骨骨折和脱位的病理生理学、临床表现、诊断方法和治疗选择。该报告综合了当前关于急诊处理方案、手术稳定技术、保守治疗方法和长期预后的兽医知识，为这些疑难病例的临床决策提供指导。

## 疾病概述

犬猫的椎骨骨折和脱位代表脊柱的急性创伤性破坏，涉及骨骨折、关节脱位或两者兼有。这些损伤通常由车祸、咬伤和坠落引起，猫常受高楼综合征和犬攻击的影响[1]。胸腰段（T11-L6）最常受累，占脊髓创伤病例的50-60%[2]。

病理生理学涉及初始创伤的原发性机械损伤和继发性生化损伤级联反应。原发性损伤通过压缩、剪切、切割、弯曲和牵拉力发生，这些力量破坏椎骨结构并压迫脊髓[2]。继发性损伤通过缺血、出血、水肿和炎症介质（包括自由基、白三烯和前列腺素）的释放发展，这些介质损害脊髓血流并导致进行性组织损伤[1][2]。

脊柱稳定性使用三柱概念进行评估，当两个或更多解剖柱（背侧、中间、腹侧）受损时发生不稳定[2]。神经损伤的严重程度与脊髓压迫的速度、力量和持续时间相关[1][2]。

### Sources
[1] Trauma of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/en-au/nervous-system/diseases-of-the-spinal-column-and-cord/trauma-of-the-spinal-column-and-cord-in-animals
[2] Acute spinal cord injury - The first hour can make the difference (Proceedings): https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings

## 常见病原体

犬猫的椎骨骨折和脱位不是由传统传染性病原体引起的，而是由损害脊柱完整性的不同病因因素引起的。了解这些主要原因对于正确的诊断和管理至关重要。

**创伤性原因**
椎骨骨折和脱位的最常见原因是外部创伤[1]。猫可能从高处坠落、被犬攻击或被各种物体撞击导致椎骨骨折和脱位[1]。犬猫常见的创伤性原因包括车祸、咬伤和枪伤[2]。这些急性创伤事件直接导致椎柱和相关脊髓结构的机械性损伤。

**病理性骨折**
病理性骨折代表一个次要类别，其中潜在的疾病过程削弱了椎骨结构[2]。细菌性骨髓炎常涉及葡萄球菌属、链球菌属、大肠杆菌、变形杆菌属、巴斯德菌属、假单胞菌属和犬布鲁氏菌[3]。真菌感染，包括新生隐球菌、皮炎芽生菌、荚膜组织胞浆菌、粗球孢子菌和曲霉菌属，也可导致椎骨 weakening[4]。原发性或转移性肉瘤和癌可累及椎柱，可能导致病理性骨折[1]。

**品种易感性**
某些品种表现出对脊髓损伤的易感性增加。玩具品种犬，包括约克夏梗、吉娃娃和博美犬，常受先天性寰枢椎不稳定的影响，这可能易导致椎骨脱位[5]。此外，软骨发育不良品种可能因其改变的脊柱解剖结构而具有增加骨折风险的结构性易感因素。

### Sources
[1] Managing paraparetic cats (Proceedings): https://www.dvm360.com/view/managing-paraparetic-cats-proceedings
[2] Trauma of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/en-au/nervous-system/diseases-of-the-spinal-column-and-cord/trauma-of-the-spinal-column-and-cord-in-animals
[3] Osteomyelitis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/osteomyelitis-in-dogs-and-cats
[4] Inflammatory and Infectious Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/inflammatory-and-infectious-diseases-of-the-spinal-column-and-cord-in-animals
[5] Congenital and Inherited Anomalies of the Musculoskeletal System in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats

## 临床症状和体征

椎骨骨折和脱位表现为明显的神经功能缺损，其表现因脊髓损伤的位置和严重程度而异。最突出的临床体征是**急性发作的瘫痪或轻瘫**，当损伤发生在胸腰交界处时通常影响后肢（截瘫/后肢轻瘫）[2]。在颈椎损伤中，所有四肢都可能受累（四肢瘫痪/四肢轻瘫）[6]。

**疼痛表现**始终存在且通常严重。动物在移动或触诊受累椎骨节段时表现出**脊柱痛觉过敏**并伴有发声[6]。深痛知觉评估至关重要 - 其缺失表明脊髓完全横断，功能恢复的预后极差[6]。

**步态异常**从轻度病例的轻微共济失调到严重损伤中完全无法支撑体重不等[4]。受影响的动物可能表现出不规则、不可预测的步态模式，这有助于区分神经性和骨科疾病[4]。在严重的胸腰段损伤中可能观察到**Schiff-Sherrington姿势**，其特征为前肢僵硬伸展而后肢松弛[6]。

**物种特异性表现**包括猫倾向于隐藏神经功能缺损，使检查变得困难[2]。猫常表现为双侧对称性缺损，如果周围神经受累可能显示**跖行姿势**[2]。犬更常见地表现出明显的跛行或不愿移动[6]。

**严重程度分级系统**将患者从1级（可行走且缺损轻微）到5级（截瘫且深痛知觉缺失）进行分类[6]。初始神经状态可能在立即稳定后改善，强调了重复神经评估的重要性[6]。

### Sources

[1] Congenital and Inherited Anomalies of the Musculoskeletal System in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats
[2] Managing paraparetic cats (Proceedings): https://www.dvm360.com/view/managing-paraparetic-cats-proceedings
[3] Understanding canine intervertebral disc disease: https://www.dvm360.com/view/understanding-canine-intervertebral-disc-disease
[4] Ortho or neuro? A guide to deciphering gait abnormalities: https://www.dvm360.com/view/ortho-or-neuro-guide-deciphering-gait-abnormalities
[5] Exercise intolerance in retrievers: https://www.dvm360.com/view/exercise-intolerance-retrievers
[6] Traumatic spinal cord injury (Proceedings): https://www.dvm360.com/view/traumatic-spinal-cord-injury-proceedings

## 诊断方法

现有内容全面涵盖了椎骨骨折和脱位评估的神经系统检查方案和先进影像学检查方法。为了将源材料与现有信息综合，可以增加对不同影像学检查方法比较优势的额外强调。

神经系统检查仍然是定位椎骨损伤和确定严重程度的基础[2][3]。深痛知觉评估至关重要，因为超过48小时缺乏此知觉的动物行走预后极差[2][3]。完整的神经系统评估包括脊髓反射、本体感觉和解剖定位，以指导治疗决策。

普通X线摄影是初始的影像学检查方法，尽管解剖结构的重叠可能掩盖细微骨折[2][6]。两个正交视图有助于识别椎骨移位和明显不稳定，但复杂骨折可能需要先进影像学检查进行完整评估。

计算机断层扫描（CT）在评估骨结构和创伤性损伤方面表现出色[6][9][10]。与X线摄影相比，CT提供了骨折模式、椎管侵犯和三维重建能力的更佳可视化[9][10]。现代多层CT扫描仪可在几秒内获取数千张图像，使其成为需要最少麻醉时间的不稳定患者的理想选择[9]。CT脊髓造影结合了两种检查方法的优点，在保持良好骨细节的同时增强病变的显著性[6]。

磁共振成像（MRI）提供无与伦比的软组织对比度分辨率，用于评估脊髓实质、检测水肿、出血和并发病理[6][8]。虽然传统上更昂贵且需要更长的采集时间，MRI在评估髓内脊髓病变和非压迫性脊髓病方面仍然优越[6][8]。当神经功能缺损超过影像学发现时，该检查方法特别有价值。

### Sources
[1] Assessment and management of pelvic fractures in dogs and cats: https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[2] Acute spinal cord injury - The first hour can make the difference: https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[3] Neurological emergencies: https://www.dvm360.com/view/neurological-emergencies-proceedings-0
[4] Advanced imaging modalities in veterinary medicine: https://www.dvm360.com/view/advanced-imaging-modalities-in-veterinary-medicine
[5] Magnetic Resonance Imaging in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/magnetic-resonance-imaging-in-animals
[6] Computed Tomography in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/computed-tomography-in-animals
[7] Computed tomography and its uses in veterinary medicine: https://www.dvm360.com/view/computed-tomography-and-its-uses-veterinary-medicine-proceedings

## 治疗选择

犬猫椎骨骨折和脱位的治疗方法包括保守管理、手术稳定和全面的疼痛管理方案。患者选择标准主要取决于神经状态、骨折稳定性和整体临床表现。

**保守管理**
保守治疗涉及严格的笼内限制6-8周，允许脊柱骨折的生理性愈合[1]。该方法适用于神经功能缺损轻微、椎骨移位最小且无显著脊髓压迫的患者[1]。外部固定可为颈椎损伤提供额外支撑，尽管它不能有效抵抗轴向压缩[1]。患有颈椎柱损伤的犬可能对外部固定技术反应良好[2]。

**手术稳定**
手术干预侧重于复位、减压和稳定，直到生理性融合发生[1]。常见的内固定技术包括针和聚甲基丙烯酸甲酯（PMMA）、椎体钢板固定和脊柱钉固定[1]。聚甲基丙烯酸甲酯配合Steinmann针是首选的稳定方法，螺纹针将PMMA锚定到骨上[1]。有多种手术技术可用，包括将塑料板固定到背侧棘突、针/螺钉配合PMMA、关节突稳定和脊柱钉固定[1]。脊柱稳定在技术上具有挑战性，有多种治疗选择可用，包括钢板和螺钉、针或螺钉的应用[3]。

**疼痛管理和患者选择**
多模式镇痛对于成功结果至关重要，初始管理包括注射阿片类药物联合抗炎药物[4]。手术与保守管理的患者选择标准取决于神经进展、难治性疼痛、伤害感受丧失、通气不足和脊柱柱不稳定[1]。

### Sources
[1] Acute spinal cord injury - The first hour can make the difference (Proceedings): https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[2] Cervical disorders of small breed dogs (Proceedings): https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
[3] Improving the safety of spinal fracture fixation in dogs in: https://avmajournals.avma.org/view/journals/ajvr/85/1/ajvr.23.10.0245.xml
[4] Saved from the sidelines: Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease

## 预防措施

预防伴侣动物的椎骨骨折和脱位需要一种综合方法，侧重于环境管理、主人教育和针对高风险品种的靶向干预。由于创伤是主要原因，预防策略主要通过系统修改解决损伤风险因素[1][5]。

环境修改构成预防的基础。具有防滑地板材料的安全运动区域、移除潜在危险和适当的车辆约束系统显著减少创伤相关的脊髓损伤[1]。对于易患肌肉骨骼疾病的品种，通过体重管理保持最佳身体状况至关重要，因为超重增加了脊柱结构的压力并导致退行性变化[2]。

主人教育代表预防护理的基石。教授正确的处理技术至关重要，特别是对于较小品种和兔子，它们较轻的骨骼结构使它们容易因不当约束而发生椎骨骨折[5]。主人必须学会在抬起时支撑后躯并避免给腰骶连接施加压力的扭转动作。

治疗后康复方案对于预防继发并发症和优化恢复结果至关重要。物理康复通过包括控制性牵引行走、被动关节活动度练习和水疗在内的方式帮助患者实现最大功能恢复[6][7]。在适当疼痛管理下的早期活动可防止肌肉挛缩并改善长期预后，而手术稳定后6-8周的严格活动限制仍然至关重要[3]。

### Sources

[1] Physical rehabilitation: Improving the outcome in dogs with orthopedic problems: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems
[2] Osteoarthritis in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats
[3] Acute spinal cord injury - The first hour can make the difference: https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[4] Emergency Care for Dogs and Cats - Special Pet Topics: https://www.merckvetmanual.com/special-pet-topics/emergencies/emergency-care-for-dogs-and-cats
[5] Congenital and Inherited Anomalies of the Musculoskeletal System in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats
[6] Canine rehabilitation: Getting orthopedic patients back on their feet: https://www.dvm360.com/view/canine-rehabilitation-getting-orthopedic-patients-back-their-feet
[7] Rehabilitation and canine osteoarthritis: a multimodal approach: https://www.dvm360.com/view/rehabilitation-and-canine-osteoarthritis-a-multimodal-approach

## 鉴别诊断

椎骨骨折和脱位必须与几种表现相似神经体征的脊柱疾病相鉴别。最常见的鉴别诊断包括椎间盘疾病（IVDD）、纤维软骨栓塞（FCE）、椎间盘炎和脊柱肿瘤[1]。

**椎间盘疾病**是小动物最常见的脊柱疾病，特别影响3-6岁的软骨发育不良品种。与创伤性椎骨骨折不同，IVDD通常表现为背痛和神经功能缺损的逐渐发作[2]。脊柱疼痛的存在提示急性IVDD、硬膜外肿瘤或脊柱骨折，而慢性IVDD可能无痛[3]。

**纤维软骨栓塞**发生在纤维软骨物质进入脊柱血管时，引起急性神经体征而无脊柱疼痛。FCE在剧烈活动期间突然发作，表现为不对称缺损和非进行性体征 - 与椎骨骨折的疼痛、通常对称的表现形成对比[4]。

**椎间盘炎**涉及椎间盘和相邻椎骨终板的感染性破坏，引起严重脊柱疼痛、发热和全身性疾病。先进影像学检查显示溶骨性病变，而不是创伤性损伤中看到的急性骨折线[5]。

**脊柱肿瘤**通常表现为慢性、进行性神经功能恶化。原发性或转移性肿瘤导致逐渐的脊髓压迫，与创伤性椎骨损伤相关的急性发作不同[6]。

椎骨骨折的鉴别因素包括急性创伤史、严重局部脊柱疼痛和显示骨折线或椎骨移位的特征性影像学改变。

### Sources
[1] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified
[2] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals
[3] A pain in the neck: diagnosing and treating neck and back pain: https://www.dvm360.com/view/pain-neck-diagnosing-and-treating-neck-and-back-pain-proceedings
[4] Cervical disorders of large breed dogs: https://www.dvm360.com/view/cervical-disorders-large-breed-dogs-proceedings
[5] Cervical disorders of small breed dogs: https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
[6] Acute spinal cord injury - The first hour can make the difference: https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings

## 预后

椎骨骨折和脱位的预后根据就诊时的神经状态和深痛知觉的存在而有显著差异[1]。后肢无伤害感受且伴有移位骨折或脱位的截瘫猫恢复预后谨慎[1]。深痛知觉丧失超过48小时表明预后极差，而表现为脊柱骨折且深部伤害感受缺失的动物行走预后无望[2][4]。

在几项回顾性研究中，保守管理与手术干预相比显示出相似的长期结果[2][3]。怀疑患有椎间盘疾病且深部伤害感受丧失少于24小时的犬约有60%的机会恢复行走状态[2][4]。然而，维持伤害感受的患者可能仍需要数月才能恢复，并且常有残留的神经功能缺损，包括尿和/或大便失禁[2][4]。

就诊时神经功能缺损的严重程度和从创伤到治疗的时间间隔显著影响结果[3][4]。不能行走的状态和从创伤到转诊的5天或更长时间间隔与较差的结果相关[2][3]。长期并发症可包括永久性神经功能恶化、失禁和自残[3]。尽管有显著的椎骨移位，如果尾部和骨盆肢趾部的深部伤害感受保持完整，稳定结果往往是有利的[2][4]。

### Sources
[1] Managing paraparetic cats (Proceedings): https://www.dvm360.com/view/managing-paraparetic-cats-proceedings
[2] Acute spinal cord injury - The first hour can make the difference (Proceedings): https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[3] Traumatic spinal cord injury (Proceedings): https://www.dvm360.com/view/traumatic-spinal-cord-injury-proceedings
[4] Long-term neurologic outcome of hemilaminectomy and disk: https://avmajournals.avma.org/view/journals/javma/241/12/javma.241.12.1617.xml
