# 伴侣动物皮脂腺腺瘤

皮脂腺腺瘤是小动物兽医临床中最常见的良性皮肤肿瘤之一，尤其影响老年犬和猫。这些产油腺体肿瘤给兽医从业者带来了独特的诊断和管理挑战，因为它们常多发，且仅凭细胞学检查难以与相关的皮脂腺增生性疾病区分。

本综合报告通过详细分析皮脂腺腺瘤的流行病学模式、诊断方法和治疗结果，探讨其临床意义。主要发现包括可卡犬和萨摩耶犬的品种易感性、组织病理学在确诊中的关键作用，以及完全手术切除后的良好预后。了解这些良性肿瘤对兽医从业者至关重要，以便为患者提供适当的护理并向主人准确说明长期管理预期。

## 疾病概述

皮脂腺腺瘤是一种起源于皮脂腺的良性肿瘤，皮脂腺是与皮肤中的毛囊相关的产油腺体[1]。该肿瘤属于皮脂腺肿瘤这一大类中的几种类型之一，包括皮脂腺增生、皮脂腺腺瘤和罕见的恶性皮脂腺腺癌[2]。

皮脂腺腺瘤是影响犬和猫的常见良性肿瘤，具有明显的年龄倾向性[1]。犬通常在8-13岁之间发生这些肿瘤，年龄较大的动物风险最高[2]。某些品种表现出易感性增加，包括可卡犬、英国可卡犬和萨摩耶犬[1]。在猫中，波斯猫最容易发生皮脂腺腺瘤[2]。

这些肿瘤发生时通常存在于多个部位，最常见于头部，但它们可以在身体的任何部位发生[2]。肿瘤表现为小病变，表面可能有光泽并带有小凸起，可能变得结痂或发炎[2]。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Tumors of the Skin in Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[3] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0

## 临床表现和诊断方法

皮脂腺腺瘤表现为隆起的结节性肿块，直径通常从0.5厘米到数厘米不等[1]。这些良性肿瘤通常表现为隆起、无毛的病变，外观呈花椰菜状，常具有乳头状表面[2]。肿块最常见于头部，但它们可以发生在身体的任何部位[2]。

临床检查显示质地坚实、边界清晰的真皮结节，外观可能光滑或分叶状。未染色时，抽吸物常呈油性或油腻感[3]。细针抽吸是主要的诊断方法，使用21号或25号针头，最小化吸力以防止细胞损伤[1]。

从细胞学上看，皮脂腺腺瘤由大圆形细胞的小聚集物组成，这些细胞具有均匀的偏心核和独特的泡沫状细胞质，内含丰富的分泌液滴[2]。细胞显示出明显的凝聚力和中等量的泡沫状细胞质，伴有小中央核[3]。也可能存在少量外观类似基底的储备细胞[3]。

虽然细胞学检查可以提示皮脂腺腺瘤，但确诊需要组织病理学检查，因为皮脂腺增生和腺瘤在细胞学上无法区分[3]。两种情况主要由成熟的、均匀的皮脂腺上皮细胞簇组成，具有相似的形态特征[3]。

### Sources

[1] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0
[2] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[3] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings

## 治疗选择

现有内容为皮脂腺腺瘤治疗提供了全面的基础。我将在保持字数限制的前提下，结合现有资料整合信息以增强本节内容。

皮脂腺腺瘤的管理主要基于手术切除，这既是确定性的治疗方法也是诊断方法。这些肿瘤的良性性质意味着干预决策必须在美容关注与医疗必要性之间取得平衡。

**手术切除作为主要治疗方法**

完全手术切除仍然是皮脂腺腺瘤的金标准治疗方法[1]。该手术涉及切除整个肿瘤及周围健康组织的边缘，以确保完全切除并防止复发。手术既提供治疗益处，也允许进行明确的组织病理学诊断以确认生长物的良性性质[2]。兽医可能会咨询兽医肿瘤学家或皮肤科医生以协助处理复杂病例[1]。

**手术干预的适应症**

几个因素决定何时需要进行手术切除。医疗适应症包括肿瘤发生溃疡、感染或引起动物不适[1]。美容考虑也可能影响决策，特别是当多个病变影响动物外观或主人对生长物表示担忧时[2]。肿瘤引起的局部刺激需要治疗，这通常是成功的[3]。

**术后护理和管理**

手术切除后，常规术后伤口护理至关重要。这包括监测手术部位是否有感染迹象，确保正常愈合，并在必要时通过适当的约束方法防止自伤[1]。大多数病例通过标准伤口管理方案顺利愈合。

**多发性肿瘤的管理**

当犬出现多个皮脂腺腺瘤时，治疗策略可能需要调整。发生一处皮脂腺增生的犬通常会在其他部位发生新肿瘤[1]。除非它们引起临床问题，否则完全切除所有病变可能不切实际或不必要[2]。在这些情况下，选择性切除最大或最麻烦的肿瘤可能更合适。

### Sources
[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] Physiology, Sebaceous Glands - StatPearls - NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/books/NBK499819/
[3] Ocular Neoplasia in Dogs - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/neoplasia-of-the-eye-and-associated-structures/ocular-neoplasia-in-dogs

## 鉴别诊断和相关疾病

将皮脂腺腺瘤与相关的皮脂腺增生性疾病区分开来具有挑战性，特别是仅使用细胞学检查时。皮脂腺腺瘤必须与皮脂腺增生、皮脂腺上皮瘤和皮脂腺腺癌进行鉴别[1][4]。

**皮脂腺增生与腺瘤**是最常见的诊断难题。两种情况在细胞学上表现相同，由均匀的成熟皮脂腺上皮细胞簇组成，具有丰富的泡沫状细胞质和小中央核[1][4]。关键区分因素是皮脂腺腺瘤和皮脂腺增生在细胞学上无法区分[1]。需要组织病理学评估进行明确区分，尽管这种区分的临床意义有限，因为两种情况都表现为良性[4]。皮脂腺增生在老年犬中更常见，通常表现为隆起、无毛的花椰菜外观病变[1]。

**皮脂腺上皮瘤**本质上是具有皮脂腺分化区域的基底细胞癌，含有基底细胞（有时有色素）和皮脂腺上皮细胞的混合物[4]。这创造了比腺瘤中见到的均匀皮脂细胞更多样的细胞群体。

**皮脂腺腺癌**很罕见，可能缺乏皮脂腺分化的细胞学特征，使诊断特别具有挑战性[4]。这些恶性肿瘤需要组织病理学检查以识别侵袭性特征和细胞异型性。

**具有皮脂腺分化的基底细胞瘤**在细胞学上可能相似，含有排列成紧密簇的均匀立方形细胞，胞质少且嗜碱性。然而，它们通常缺乏皮脂腺腺瘤特有的丰富泡沫状细胞质。

**眼睑睑板腺腺瘤**在细胞学上可能类似于皮脂腺腺瘤，表现为具有泡沫状细胞质和小中央核的细胞簇[1][4]。位置有助于区分这些情况。

临床意义是，皮脂腺肿瘤的明确诊断需要组织病理学评估以确定恶性潜力并指导适当的治疗决策[4]。

### Sources
[1] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[2] Clinical Exposures: Canine circumanal gland adenoma: The cytologic clues: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[3] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[4] Cytologic diagnoses that every practicing veterinarian should be able to make: https://www.dvm360.com/view/cytologic-diagnoses-every-practicing-veterinarian-should-be-able-make-proceedings

## 预后和长期展望

皮脂腺腺瘤在手术切除后具有极好的预后。这些良性肿瘤对完全手术切除反应非常好，大多数犬能够完全康复且无并发症[1]。

皮脂腺腺瘤的主要问题是如果手术边缘不完整，它们倾向于复发。然而，当实现足够边缘的完全切除时，复发率非常低。一项关于犬趾部肿块的研究（包括甲下鳞状细胞癌）显示，当病变起源于适当位置时，截肢后1年生存率为95%[1]。虽然这一具体统计数据涉及不同类型的肿瘤，但它证明了完全手术切除对获得最佳结果的重要性。

发生一处皮脂腺腺瘤的犬随着年龄增长倾向于发生额外的肿瘤[2]。多个肿瘤可能同时存在，新的生长物通常会随时间出现，特别是在老年动物中[2]。这种新肿瘤发展的倾向需要在宠物的一生中进行持续监测。

受影响动物的生活质量通常极好。除非肿瘤发生溃疡或感染，否则这些肿瘤很少引起不适。大多数犬在手术恢复后继续正常活动而不受限制[2]。

长期监测应包括定期体格检查，特别注意皮肤检查。应教育主人监测新生长物并报告现有病变的任何变化。由于这些肿瘤与年龄相关，随着犬进入老年期，警惕性变得越来越重要。

### Sources

[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
