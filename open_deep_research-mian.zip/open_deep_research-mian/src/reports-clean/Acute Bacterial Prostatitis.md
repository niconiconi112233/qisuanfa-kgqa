# 伴侣动物的急性细菌性前列腺炎

急性细菌性前列腺炎是未去势雄性犬的一种危急急症，其特征是突发性前列腺炎症，可迅速发展为危及生命的败血症。该疾病影响所有年龄段的性成熟犬，大肠杆菌通过上行性尿道感染成为主要病原体。急性炎症期间血液-前列腺屏障的破坏创造了一个独特的治疗窗口，在此期间大多数抗生素能够达到有效的前列腺浓度，这与慢性前列腺疾病中见到的治疗挑战形成鲜明对比。本报告探讨了在兽医实践中成功管理这种潜在致命疾病所必需的病理生理学、临床表现、诊断方法和循证治疗方案。

## 疾病概述与流行病学

急性细菌性前列腺炎是性成熟雄性犬由细菌感染引起的前列腺腺体突发性炎症性疾病[1]。它是犬类第二常见的前列腺疾病，仅次于良性前列腺增生（BPH）[1]。

该疾病仅发生于未去势雄性犬，因为前列腺组织具有激素依赖性[1]。超过60%的四岁以上未去势雄性犬会发展为前列腺问题，且比例随年龄增长而增加[3]。细菌性前列腺炎影响性成熟犬，通常在病原体通过逆流从膀胱上行或从尿道迁移时发生，尽管血源性传播也可能发生[1][6]。

常见细菌病原体包括大肠杆菌、葡萄球菌、链球菌、假单胞菌、变形杆菌、支原体和犬布鲁氏菌[1][6]。该疾病可发展为急性暴发性全身性疾病，或与复发性尿路感染相关的慢性问题[7]。大多数患有尿路感染的性成熟雄性犬应被认为前列腺内存在微生物[2][7]。

风险因素包括预先存在的良性前列腺增生，它通过创造有利于细菌定植的条件使犬易患细菌性前列腺炎[1]。与其他前列腺疾病不同，急性细菌性前列腺炎一旦性成熟可影响任何年龄的犬，尽管它常见于中老年未去势雄性犬[10]。

### Sources

[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] Therapeutic caveats: Difficult urinary tract infections: https://www.dvm360.com/view/therapeutic-caveats-difficult-urinary-tract-infections
[3] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings
[6] Merck Veterinary Manual Prostatitis in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats
[7] Pharmacotherapeutics in Bacterial Prostatitis in Dogs and Cats: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-prostatitis-in-dogs-and-cats
[10] VIN Management of Prostatic Disorders: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3846300&pid=11147

## 常见病原体

现有章节内容对犬急性细菌性前列腺炎的细菌病原体和病理生理学提供了极好的覆盖。根据默克兽医手册提供的可用资料材料，我可以通过补充感染机制的临床背景来增强本节内容。

大肠杆菌仍然是主要病原体，是尿路和前列腺感染中最常分离的微生物[1]。肠杆菌科，包括克雷伯菌属、肠杆菌属、变形杆菌属和沙雷菌属，构成了源自正常肠道菌群的主要革兰氏阴性病原体[1]。

革兰氏阳性微生物对前列腺感染有显著贡献，特别是凝固酶阳性葡萄球菌属和肠球菌属[1]。其他病原体包括链球菌和支原体属[2]。在常规培养阴性但持续存在脓尿或尿液持续呈碱性的病例中，应考虑支原体[1]。

上行性感染是主要的致病机制，微生物从会阴部通过尿道迁移到前列腺[1]。血源性传播主要发生在急性前列腺炎病例中[2]。在急性炎症期间，血液-前列腺屏障被破坏，促进细菌穿透，同时改善抗生素进入[2]。

特定的大肠杆菌毒力因子增强尿路上皮附着，促进定植和随后的前列腺侵袭[1]。在急性炎症期间，正常的前列腺pH梯度和屏障功能被破坏，创造有利于细菌增殖的条件[2]。

### Sources
[1] Managing routine and difficult urinary tract infections in dogs (Proceedings): https://www.dvm360.com/view/managing-routine-and-difficult-urinary-tract-infections-dogs-proceedings
[2] Merck Veterinary Manual Prostatitis in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats

## 诊断方法

急性细菌性前列腺炎的诊断评估需要结合临床评估、实验室检查和影像学研究的系统方法[1,2]。体格检查显示直肠触诊时前列腺特征性疼痛肿大，这与良性前列腺增生中通常无痛的肿大形成对比[1]。操作过程中必须小心，因为在急性病例中剧烈的前列腺按摩可能引发败血症[1]。

实验室诊断包括全血细胞计数，通常显示中性粒细胞白细胞增多，伴或不伴左移[1,3]。尿液分析通常显示血尿、脓尿和菌尿[1,3]。尿液培养应使用通过膀胱穿刺术收集的样本进行，但必须避免包皮分泌物的污染[1]。

影像学研究在诊断中起着关键作用。放射学上，除了颅侧边界不清外，前列腺可能表现正常[1]。超声检查显示前列腺实质弥漫性至局灶性高回声，伴有与小液囊一致的低回声区域[1,2]。在无菌操作下进行的超声引导细针抽吸可提供细胞学和培养样本[1,2]。由于细菌传播的风险，急性病例禁忌前列腺按摩[1]。

### Sources
[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] Prostatic Diseases in Small Animals - Reproductive System: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-diseases-in-small-animals

## 治疗策略与管理

犬急性细菌性前列腺炎需要积极的抗生素治疗结合支持性护理。急性病例中受损的前列腺-血液屏障允许大多数抗生素有效穿透，需要根据培养和药敏试验选择抗生素治疗3-4周[1]。在等待微生物学结果期间，恩诺沙星以5 mg/kg每日两次口服作为优秀的经验性选择[1]。

最佳抗生素选择侧重于具有优异前列腺穿透力的药物。氟喹诺酮类（恩诺沙星、马波沙星、环丙沙星）代表大肠杆菌感染的最佳经验性选择，而红霉素、克林霉素、甲氧苄啶-磺胺和氯霉素提供良好的前列腺浓度[2][3]。这些药物比青霉素类、氨苄西林、头孢菌素类或氨基糖苷类更有效地穿透前列腺-血液屏障，后几类药物应避免使用[2]。

对于全身性患病患者，最初可能需要肠道外抗生素给药，随后进行口服治疗[2]。系统监测需要在治疗开始后5-7天进行尿液培养以确认体内疗效，并在完成后7-10天进行随访培养[4]。当存在脱水和休克时，静脉输液疗法可应对[1]。

大的前列腺脓肿需要手术引流和囊内网膜固定术，当多个微脓肿融合成单一病变时[1]。去势在治疗成功中起着关键作用，建议在抗生素开始使用且患者临床稳定后进行[1][2]。这种手术干预促进感染消退并通过消除前列腺疾病的激素刺激来防止复发。

### Sources
[1] Prostatitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats
[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[3] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[4] How to manage recurrent urinary tract infections: https://www.dvm360.com/view/how-to-manage-recurrent-urinary-tract-infections

## 预防、鉴别诊断和预后

### 预防措施

急性细菌性前列腺炎的一级预防侧重于对不用于繁殖的犬进行去势[1]。去势消除了良性前列腺增生，这是细菌感染的易感因素[1]。对于未去势的种用雄性犬，保持良好卫生并及时治疗尿路感染可能降低风险[3]。

二级预防包括通过去势或药物治疗处理良性前列腺增生等易感因素[1]。对未去势雄性犬进行定期尿液分析有助于检测可能上行至前列腺的无症状菌尿[6]。

### 鉴别诊断

关键鉴别诊断包括慢性前列腺炎，它通常缺乏全身性症状，表现为复发性尿路感染而非急性发热和疼痛[6]。前列腺脓肿表现相似，但超声检查可能显示空腔病变和更严重的全身性疾病[1]。

应考虑前列腺肿瘤，特别是在老年犬中，尽管它通常引起不对称肿大，并且可能发生在未去势和已去势的雄性犬中[1]。良性前列腺增生引起对称性肿大，无急性全身性症状[4]。

### 预后

通过适当的抗生素治疗3-4周，预后通常良好[6]。如果治疗不充分，急性前列腺炎可能发展为慢性前列腺炎和复发性尿路感染[1]。严重病例可能发展为前列腺脓肿、败血症或休克，恶化预后[6]。

感染控制后早期去势通过防止复发显著改善长期结果[6]。如果不解决潜在的前列腺增生，慢性细菌性前列腺炎通常发展并可能需要长期管理[1]。

### Sources

[1] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[2] Canine prostate disease - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/204/10/javma.1994.204.10.1561.pdf
[3] Reproductive Disorders of Male Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-male-dogs
[4] Abnormal reproductive ultrasononography in dogs and toms (Proceedings): https://www.dvm360.com/view/abnormal-reproductive-ultrasononography-dogs-and-toms-proceedings
[5] Approach to the acute abdomen (Proceedings): https://www.dvm360.com/view/approach-acute-abdomen-proceedings
[6] Prostatitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/en-au/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats
