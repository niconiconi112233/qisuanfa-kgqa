# 伴侣动物乳腺炎：兽医临床指南

乳腺炎是哺乳期犬猫的一项重大健康问题，通过细菌感染影响乳腺，并可能威胁母体和后代的健康。这种炎症性疾病若不及时进行兽医干预，可能迅速从局部感染发展为危及生命的败血症。本报告探讨了小动物临床实践中乳腺炎的多方面特性，涵盖从乳汁细胞学到细菌培养的基本诊断方法、包括抗菌药物选择和支持性治疗的循证治疗方案，以及全面的预防策略。主要发现包括：金黄色葡萄球菌和链球菌属作为主要致病菌占主导地位，通过乳腺发热和脓性乳汁等临床症状进行早期识别至关重要，以及适当的干预治疗通常预后良好。

## 总结与临床意义

这项全面综述表明，伴侣动物的乳腺炎需要立即进行兽医诊治，金黄色葡萄球菌和大肠杆菌等细菌病原体可导致从局部炎症迅速发展为潜在败血症。主要诊断发现包括乳腺发热、疼痛和脓性乳汁变化，即使乳汁外观正常，细胞学检查仍显示退行性中性粒细胞增多。治疗成功取决于及时使用广谱抗菌药物治疗，头孢氨苄和阿莫西林-克拉维酸钾作为一线选择。

| 方面 | 主要发现 | 临床影响 |
|--------|-------------|-----------------|
| **诊断** | 即使乳汁外观正常，乳汁细胞学仍显示中性粒细胞增多 | 在出现可见变化前实现早期检测 |
| **治疗** | 抗菌药物治疗通常在1-3天内恢复 | 支持积极的早期干预方法 |
| **预防** | 修剪幼犬指甲和保持垫料清洁可减少创伤相关感染 | 简单的管理措施显著降低风险 |
| **预后** | 及时治疗通常预后良好；不治疗则预后差 | 强调治疗干预的关键时机 |

兽医从业者应优先通过乳汁细胞学和细菌培养进行快速诊断，立即实施广谱抗菌药物治疗，并教育客户预防性管理措施，以优化这一潜在严重生殖急症的治疗效果。

## 疾病概述与流行病学

伴侣动物的乳腺炎是一个或多个乳腺的炎症，最常见于产后哺乳期母犬母猫 [1]。该疾病可分为三种主要类型：急性乳腺炎（突发严重炎症）、慢性乳腺炎（持续性低度炎症）和坏疽性乳腺炎（因严重细菌感染导致的组织死亡）[2]。

乳腺炎在犬猫中偶发，细菌病原体是主要致病因素。常见细菌原因包括葡萄球菌属和链球菌属 [2]。患病率在哺乳期母犬和母猫中似乎更高，特别是在产后最初几周，此时产奶量达到顶峰，哺乳需求最大 [3]。

多种流行病学因素影响乳腺炎的发生发展。环境污染起着重要作用，产仔区卫生条件差会增加感染风险。易感因素包括哺乳后代造成的乳腺组织创伤、卫生不良和环境细菌污染 [2]。年龄分布通常与生殖活动相关，影响生殖年龄的成熟雌性。虽然兽医文献中尚未明确确定特定品种易感性，但任何品种的哺乳期雌性都可能患病。

### Sources

[1] Management of the Neonate in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-the-neonate/management-of-the-neonate-in-dogs-and-cats
[2] Pediatric and reproductive emergency room pearls: https://www.dvm360.com/view/pediatric-and-reproductive-emergency-room-pearls-proceedings

## 常见病原体与病理生理学

现有章节内容全面涵盖了小动物乳腺炎的细菌病原体和病理生理学。《默克兽医手册》来源证实，乳腺炎是由细菌通过哺乳、创伤或血源性传播进入乳腺组织引起的 [1]。最常见的分离细菌包括大肠杆菌、葡萄球菌属和链球菌属，它们是正常皮肤菌群 inhabitants [1]。金黄色葡萄球菌仍然是临床病例中最常分离的微生物 [1]。

病理生理过程始于细菌通过三种主要途径入侵：哺乳期间通过乳头管的上行感染（最常见）、创造入口点的直接创伤，或从远处部位的血源性传播 [1]。一旦细菌建立定植，它们会触发涉及中性粒细胞募集和激活的炎症级联反应，导致特征性组织水肿、血管充血、乳腺肿胀、发热和疼痛 [1]。

疾病进展取决于宿主免疫反应和细菌毒力因子。局部感染可能仅限于单个腺体，但治疗不足会使细菌扩散到邻近乳腺组织 [1]。在严重病例中，细菌毒素和炎症介质进入体循环，可能导致危及生命的败血症。慢性乳腺炎发生在细菌清除不完全时，导致持续性低度炎症和进行性纤维化，损害未来的乳腺功能和产奶量。

### Sources
[1] Mastitis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/mastitis-in-small-animals

## 临床症状与体征

犬猫急性乳腺炎表现出独特的早期指标，若不干预会迅速进展 [1]。初始临床症状包括厌食和对后代母性兴趣降低，随后发展为坚硬、疼痛和发热的乳腺 [1]。患病动物通常表现出发热和不适的一般症状 [1]。

乳汁外观差异显著，从外观正常到血染或明显脓性 [1]。随着病情进展，乳腺逐渐增大并可触及水肿 [1]。犬常见发热和哺乳行为减少，而中重度病例可迅速出现全身性表现 [1]。

猫乳腺炎表现出更明显的进展模式。一个记录病例显示有8周乳腺增生史，在产后7天内迅速发展为乳腺炎和脓肿形成 [2]。患病猫表现出明显厌食、发热和明显不适，而幼猫显得虚弱，哺乳困难 [2]。体格检查发现受影响乳头皮肤溃疡和脓肿乳腺区域皮肤坏死 [2]。

对两种动物而言，对哺乳行为的影响是关键的临床指标。患病母亲对后代的兴趣降低，导致哺乳模式受损 [1]。当这种行为变化与可见乳腺异常同时出现时，通常促使主人寻求兽医诊治。

慢性或亚临床乳腺炎通常表现更隐匿，通常仅在幼犬幼猫在环境条件充足的情况下仍无法茁壮成长时才被怀疑 [1]。

### Sources
[1] Mastitis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/mastitis-in-small-animals
[2] Management of mastitis and abscessation of mammary glands: https://avmajournals.avma.org/view/journals/javma/236/3/javma.236.3.326.xml

## 诊断方法

犬猫乳腺炎的诊断需要结合临床评估和实验室测试的系统方法。体格检查显示坚硬、疼痛和发热的乳腺，常伴有发热和对后代母性兴趣降低 [1]。乳汁外观可能从正常到血染或脓性不等。

**乳汁细胞学**是基石诊断工具。显微镜检查显示退行性中性粒细胞增多，即使乳汁外观正常也可作为诊断依据 [1]。**细菌培养和抗菌药物敏感性测试**应在受影响腺体的乳汁上进行，因为这指导适当的治疗选择 [1]。

**样本采集**需要严格的无菌技术。对于乳汁采集，必须清洁乳头，预浸泡，干燥，并在弃掉最初2-3把奶前进行抗菌处理 [2]。**全血细胞计数**可能显示贫血和低蛋白血症，反映蛋白质和血液流失，而嗜酸性粒细胞增多可能表明炎症过程 [3]。

**超声检查**可评估乳腺结构并识别脓肿等并发症。虽然超声不常规用于乳腺炎诊断，但有助于评估组织变化并在需要时指导细针穿刺 [4]。

**细胞学评估**使用瑞氏或革兰氏染色提供细菌类型（革兰氏阳性或革兰氏阴性，球菌或杆菌）的快速评估，以指导初始抗菌药物治疗 [2]。适当的样本处理包括如果在24-48小时内进行分析则冷藏，否则建议冷冻 [2]。

### Sources
[1] Mastitis in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/mastitis-in-small-animals
[2] Microbiology Testing for Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/antimicrobials/microbiology-testing-for-animals
[3] Diagnostic approach to chronic diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[4] Diagnostic Imaging - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging

## 治疗选择与管理

乳腺炎的治疗需要结合抗菌药物治疗、支持性治疗和仔细监测的综合方法。覆盖革兰氏阳性和革兰氏阴性生物的广谱抗生素至关重要 [1]。常见的经验性选择包括头孢氨苄（15-30 mg/kg，口服，每8小时一次）和阿莫西林-克拉维酸钾（14 mg/kg，口服，每8-12小时一次）[1]。

支持性治疗措施包括在受影响腺体上应用热敷或冷敷，以及轻柔挤奶以排出乳汁 [1]。疼痛管理需要特别考虑，因为药物会通过乳汁转移给哺乳幼崽。阿片类药物通常是哺乳动物最安全的镇痛选择，氢吗啡酮和吗啡优于更多亲脂性替代品 [5]。非甾体抗炎药应谨慎使用，哺乳动物最好不用 [5]。

对于伴有脓肿或坏疽的严重病例，可能需要手术清创坏死组织 [1]。幼崽可以继续从未受影响的腺体哺乳，但如果母亲不愿哺乳，可能需要补充奶制品 [1]。应密切监测治疗反应，因为未经治疗的急性乳腺炎可迅速发展为败血症 [1]。

### Sources
[1] Mastitis in Small Animals: https://www.merckvetmanual.com/en-au/reproductive-system/reproductive-diseases-of-the-female-small-animal/mastitis-in-small-animals
[5] Tips on Analgesia in Pregnant and Lactating Dogs and Cats: https://www.dvm360.com/view/tips-on-analgesia-in-pregnant-and-lactating-dogs-and-cats

## 预防、预后与结局

**预防措施**
初级预防侧重于在产仔区维持最佳卫生方案 [1]。垫料应保持清洁干燥，频繁更换以减少细菌污染 [1]。修剪幼犬指甲对于防止哺乳期间乳腺创伤至关重要，这可为机会性细菌创造入口点 [1][2]。

环境管理包括母畜居住区的适当通风和卫生 [2]。断奶考虑涉及逐渐停止泌乳以防止充血和随后的感染风险。对于猫，乳腺炎较少见，但风险因素包括卫生条件差和后代造成的创伤 [3]。

**预后因素与恢复**
犬乳腺炎的预后通常良好，只要及时治疗 [1]。及时进行适当的抗菌药物治疗可显著改善结局。预后因素包括就诊时严重程度、受影响腺体数量和致病微生物 [1]。

恢复时间通常显示在开始广谱抗菌药物治疗后1-3天内改善 [1][2]。适当治疗通常在1-2周内完全恢复。

**潜在并发症**
若不立即治疗，急性乳腺炎可迅速从一个腺体扩散到另一个腺体 [1][2]。严重并发症包括脓肿形成、腺体坏疽和全身性败血症 [1][2]。受影响腺体破裂可能需要手术清创坏死组织 [1][2]。

早期治疗的长期结局极佳，尽管可能存在一些腺体纤维化。慢性或复发性病例可能影响育种动物未来的泌乳能力。

### Sources

[1] Mastitis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/mastitis-in-small-animals
[2] Reproductive Disorders of Female Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-female-dogs
[3] Reproductive Disorders of Female Cats - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/reproductive-disorders-of-cats/reproductive-disorders-of-female-cats
