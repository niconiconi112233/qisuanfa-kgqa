# 伴侣动物中的胆管肝炎

胆管肝炎是一种影响犬猫的重要肝胆疾病，其特征为胆管和周围肝组织的炎症。本综合报告探讨了该疾病的多面性，从其细菌性和病毒性病因到复杂的诊断挑战。分析涵盖了关键的临床表现，包括嗜睡、呕吐和肝酶升高的特征性三联征，以及从超声引导取样到组织病理学确认的先进诊断方法。治疗策略包括多模式方法，如三联抗生素方案、利胆剂和在适应症下的手术干预。报告还讨论了预防措施、包括脂肪肝和慢性肝炎在内的鉴别诊断，以及影响临床结果和长期管理成功的预后因素。

## 疾病概述

**定义**

胆管肝炎定义为胆管（胆管炎）和周围肝实质（肝炎）的炎症，代表影响伴侣动物肝内和肝外胆道的一系列炎症性疾病（默克兽医手册）。该疾病包括以中性粒细胞浸润为特征的急性化脓性形式和以单核细胞为主的慢性淋巴细胞性形式。

**流行病学背景**

胆管肝炎表现出明显的物种偏好和流行病学模式。在猫中，它是继脂肪肝之后第二常见的肝脏疾病，其中中性粒细胞性胆管肝炎比淋巴细胞性形式更为常见（默克兽医手册）。该疾病表现出强烈的猫科动物偏好，在猫中的发生率约为犬的2.5倍。

年龄分布因形式而异，急性中性粒细胞性胆管肝炎通常影响中年猫（平均年龄7-8岁），而慢性淋巴细胞性形式则倾向于发生在老年动物中。各项研究中未一致记录显著的性别偏好。

与其他肝胆疾病相比，胆管肝炎的品种偏好性尚未得到充分证实。然而，波斯猫可能对慢性形式表现出易感性增加，这可能与它们易患炎症性肠病有关，而炎症性肠病常与猫胆管肝炎同时发生（默克兽医手册）。

## 常见病原体

伴侣动物的胆管肝炎涉及多种致病机制，其中细菌感染是主要原因。原发性细菌感染通常由胆道上行定植引起，而继发性感染则通过胃肠道细菌从肠道易位而发生。

最常见的鉴定出的细菌病原体包括大肠杆菌和肠球菌属，它们代表正常肠道菌群，在病理条件下可以易位到胆道系统[1]。这些革兰氏阳性和革兰氏阴性细菌经常从患病猫犬的胆汁培养中分离出来。在患有急性中性粒细胞性胆管炎的猫中，大肠杆菌最常从胆汁或肝组织中培养出来[2]。

其他与胆管肝炎有关的细菌物种包括梭菌属、拟杆菌属、肠杆菌属、葡萄球菌属、链球菌属、克雷伯氏菌属、假单胞菌属以及源自肠道微生物群的各种厌氧细菌[2]。发病机制通常涉及胆道-肠道屏障受损，使正常肠道细菌能够进入并定植胆道。

胆管肝炎的病毒病因有记载但不如细菌性病因常见。传染性病原体包括猫传染性腹膜炎病毒（引起化脓性肉芽肿性炎症和血管炎）和猫的强毒全身性杯状病毒[3]。大多数病例表现出细菌参与，无论是作为主要病原体还是在初始肝胆炎症后的继发性机会性感染。

### Sources
[1] Bacterial culture and immunohistochemical detection of ...: https://avmajournals.avma.org/view/journals/javma/260/2/javma.20.10.0552.xml
[2] Treatment of hepatobiliary disease in dogs and cats: https://www.dvm360.com/view/treatment-hepatobiliary-disease-dogs-and-cats
[3] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals

我注意到所提供的来源材料没有包含关于犬猫胆管肝炎临床症状和体征的具体信息。现有部分内容写得很好且全面，涵盖了犬胆管肝炎的关键临床表现、体格检查结果、实验室异常和品种模式。

来源材料包括关于犬作为物种的一般信息、一些一般的肝胆疾病以及胆囊黏液囊肿，但缺乏胆管肝炎所需的特定临床症状学数据。

鉴于现有内容已经完整、准确且来源充分（来自默克兽医手册），并且新的来源材料没有提供关于胆管肝炎症状的其他相关信息，我将保持现有部分不变。

## 临床症状和体征

犬胆管肝炎的临床症状通常是非特异性的，表现各异[1]。按频率递减，最常见的体征包括嗜睡和呕吐（>70%）、食欲减退（~65%）和腹泻（~30%）[1]。这些胃肠道体征反映了胆管肝炎与胆囊和肠道疾病的重叠性质。

体格检查发现显示发热（~30%）、黄疸（~25%）、嗜睡（26%）和可触及的肝肿大（10%）[1]。一些犬可能表现为多尿/多饮和腹水作为其他表现[1]。急性表现更常见于化脓性形式，而慢性病例可能表现为更微妙、间歇性的体征。

实验室异常支持临床表现。大多数犬显示碱性磷酸酶（ALP）显著升高，98%的病例中位数升高约10倍，ALT在88%的病例中升高约5倍，总胆红素在约64%的病例中升高约5倍[1]。血液学特征可能包括中性粒细胞白细胞增多伴左移和中毒性中性粒细胞，特别是在化脓性病例中[1]。

### Sources
[1] Canine Cholangiohepatitis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis

## 诊断方法

胆管肝炎的诊断需要全面的临床评估、实验室检测和先进的影像学方法。临床表现评估从评估病史和体格检查结果开始，包括发热、黄疸、腹痛和肝肿大[1]。

实验室检测构成诊断基础。血液学异常可能包括中性粒细胞白细胞增多伴左移和中毒性中性粒细胞，或化脓性病例中的退行性变化[1]。大多数犬显示肝酶活性增加，其中ALP在98%的病例中升高，ALT在88%的病例中升高，AST在79%的病例中升高，γ-谷氨酰转移酶（GGT）在42%的病例中升高[1]。总胆红素升高发生在约64%的病例中[1]。在猫中，GGT对炎症性胆道疾病特别敏感，在胆管炎病例中通常比ALP显示更高的升高[8]。

影像学方法提供关键诊断信息。放射学特征可能显示正常至轻度增大的肝脏大小，罕见腹腔积液[1]。超声检查发现包括可变的肝实质回声（正常、高回声或混合）、主观肝肿大以及胆囊扩张伴可能的胆管扩张[1,3]。超声还可以识别胆囊黏液囊肿、胆囊炎或胆石症[1]。腹部X光和超声提供支持性证据，并有助于排除其他鉴别诊断[2]。

确定性诊断需要组织取样。细菌培养应包括胆汁沉淀物、胆道碎屑、胆囊壁部分和肝活检作为组合提交以获得最佳结果[1]。超声引导细针抽吸和经皮胆囊穿刺术可收集细胞学检查和培养样本[2]。然而，肝炎或胆管肝炎、纤维化、肝硬化和过量铜积累只能通过肝活检确认[5]。

### Sources
[1] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis
[2] Cholangiohepatitis (Proceedings): https://www.dvm360.com/view/cholangiohepatitis-proceedings
[3] Imaging in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/imaging-in-hepatic-disease-in-small-animals
[4] Liver disease and treatment in dogs and cats (Proceedings): https://www.dvm360.com/view/liver-disease-and-treatment-dogs-and-cats-proceedings
[5] Diagnosis of liver disease in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnosis-liver-disease-dogs-and-cats-proceedings
[6] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[7] Feline hepatobiliary disease: What's new in diagnosis and ...: https://www.dvm360.com/view/feline-hepatobiliary-disease-whats-new-diagnosis-and-therapy-proceedings
[8] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings

## 治疗选择

犬胆管肝炎的治疗需要多模式方法，针对根本原因、炎症和支持性护理[1]。

**药物干预**

当存在化脓性炎症时，抗生素治疗至关重要。通常最初使用三联抗生素方案，结合甲硝唑（7.5 mg/kg每12小时一次）、氟喹诺酮类和广谱青霉素[1]。抗生素持续时间从已解决病例的2-4周到需要持续管理的慢性病例的数月不等[1]。

利胆剂有助于清除细胞碎片和炎症介质。熊去氧胆酸（10-15 mg/kg分次每12小时一次）增加胆汁酸依赖性流量，而高剂量S-腺苷甲硫氨酸（SAMe，40 mg/kg每24小时一次空腹服用）增强非胆汁酸依赖性流量[1]。

抗氧化剂发挥支持作用，SAMe改善肝谷胱甘肽状态，低剂量维生素E（10 U/kg每日）提供膜保护作用[1]。免疫抑制治疗可能适用于罕见的淋巴细胞性病例，使用利胆剂、抗氧化剂和免疫调节，类似于慢性肝炎治疗[1]。

**手术干预**

当胆囊疾病涉及脓毒症过程或生存分析显示强烈积极结果时，胆囊切除术是适应症[1]。对于胆囊黏液囊肿、坏死性胆囊炎或胆道梗阻病例，手术特别有必要[8]。

**护理**

支持性护理包括液体治疗、营养支持以及监测脓毒症或胆汁性腹膜炎等并发症[1]。临床状态和实验室参数的连续评估指导治疗调整[1]。

### Sources

[1] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[2] Treatment of hepatobiliary disease in dogs and cats (Proceedings): https://www.dvm360.com/view/treatment-hepatobiliary-disease-dogs-and-cats
[3] Update on hepatoprotective therapies (Proceedings): https://www.dvm360.com/view/update-hepatoprotective-therapies-proceedings
[4] Management of chronic liver disease in dogs (Proceedings): https://www.dvm360.com/view/management-chronic-liver-disease-dogs-proceedings
[5] Cholelithiasis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholelithiasis-in-small-animals
[6] Canine Gallbladder Mucocele - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele
[7] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings
[8] Surgery of the liver (Proceedings): https://www.dvm360.com/view/surgery-liver-proceedings

## 预防措施

现有证据表明，预防犬猫胆管肝炎的特定疫苗接种策略有限。疫苗接种计划主要集中在通过核心疫苗预防传染性肝炎，包括犬腺病毒疫苗，这些疫苗可预防可能导致慢性肝炎和肝纤维化的传染性犬肝炎[1]。

环境控制集中在管理传染性病原体的暴露。对于钩端螺旋体病相关的肝炎，由于人畜共患潜力，在处理疑似动物及其尿液样本时建议采取特殊预防措施[1]。减少与受污染环境的接触并保持适当的卫生有助于最小化可能导致胆管肝炎的细菌暴露。

饮食管理起着关键的预防作用。当易患铜相关性肝病时，应给犬喂食限制铜的处方肝脏饮食[2]。生食饮食带来特殊风险，因为研究表明食用生食会增加超广谱β-内酰胺酶（ESBL）细菌的定植，可能导致细菌性胆管肝炎[3]。

战略性驱虫计划可预防寄生虫对胆管肝炎发展的贡献。对于所有小猫，应在3、5、7和9周龄时进行驱虫治疗，双羟萘酸噻嘧啶和芬苯达唑是有效选择[6]。像塞拉菌素这样的每月心丝虫预防药物通过控制跳蚤提供额外保护，从而减少可能影响肝脏健康的巴尔通体属感染的机会[6]。

对于易患慢性肝病的犬，肝保护性补充剂可能提供预防益处。每日20 mg/kg剂量的S-腺苷甲硫氨酸（SAMe）有助于维持肝谷胱甘肽水平并支持肝功能[4]。通过胆汁酸检测和肝酶评估进行定期监测，可在临床症状出现前实现早期发现[5]。

### Sources
[1] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/infectious-diseases-of-the-liver-in-small-animals
[2] Nutrition in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/nutrition-in-hepatic-disease-in-small-animals
[3] Evaluation of canine raw food products for the presence of: https://avmajournals.avma.org/view/journals/ajvr/83/9/ajvr.21.12.0205.xml
[4] Update on hepatoprotective therapies (Proceedings): https://www.dvm360.com/view/update-hepatoprotective-therapies-proceedings
[5] Management of chronic liver disease in dogs (Proceedings): https://www.dvm360.com/view/management-chronic-liver-disease-dogs-proceedings
[6] Management and prevention of feline infectious gastrointestinal diseases (Proceedings): https://www.dvm360.com/view/management-and-prevention-feline-infectious-gastrointestinal-diseases-proceedings

## 鉴别诊断

胆管肝炎必须与几种具有重叠临床表现的肝胆疾病进行鉴别。脂肪肝是最常见的猫肝脏疾病，也是主要的鉴别诊断[1]。两种疾病都表现为黄疸、厌食和肝酶升高，但脂肪肝通常显示更高的胆红素浓度和更明显的ALP升高[2]。细针抽吸显示脂肪肝中特征性的重度空泡化肝细胞，而胆管肝炎中则为炎症浸润。

猫的慢性肝炎表现出相似的临床体征，但组织学上缺乏胆管肝炎特有的以胆道为中心的炎症[4]。原发性胆道畸形，包括导管板畸形和胆总管囊肿，由于并发细菌感染和炎症变化，可能模拟胆管肝炎[4]。这些先天性疾病需要手术评估，通常显示独特的超声发现。

肿瘤过程，特别是淋巴瘤和腺癌，必须考虑，因为它们可引起胆道梗阻和继发性炎症[4]。小细胞淋巴瘤可能与淋巴细胞性胆管肝炎特别难以区分，需要免疫组织化学染色和分子检测进行确定性诊断[4]。

关键鉴别因素包括胆管肝炎活检组织病理学显示以胆管为中心的炎症，化脓性形式中细胞学鉴定细菌，以及对适当抗菌治疗的反应。确定性诊断需要肝活检同时进行培养[1][4]。

### Sources

[1] Cholangiohepatitis (Proceedings): https://www.dvm360.com/view/cholangiohepatitis-proceedings
[2] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[3] Hepatic lipidosis maximizing a successful outcome (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-maximizing-successful-outcome-proceedings
[4] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
