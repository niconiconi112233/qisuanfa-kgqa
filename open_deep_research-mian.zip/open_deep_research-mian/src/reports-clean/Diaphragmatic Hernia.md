# 伴侣动物的膈疝

膈疝是小动物临床中的一种危急状况，指腹部器官通过膈肌缺陷突入胸腔。本综述全面探讨了影响犬猫的外伤性和先天性两种类型，其中外伤性病例占犬膈疝的80%，而先天性腹膜心包膈疝在猫中占主导地位。该疾病带来重大的诊断和治疗挑战，需要及时识别和干预，以防止危及生命的心肺功能受损。本报告系统性地涵盖了流行病学、病理生理学、临床表现、诊断方法、治疗方案和预后因素，这些都是在兽医实践中成功管理该疾病所必需的。

## 摘要

本综述表明，膈疝的管理需要系统性的方法，结合快速稳定、准确诊断和及时手术干预。外伤性病例主要由汽车事故引起，急性表现为呼吸困难和特征性姿势，而先天性腹膜心包膈疝通常多年无症状。关键的病理生理学变化包括通气-灌注不匹配、心输出量减少以及胃疝入后可能出现的快速恶化。

| 方面 | 外伤性 | 先天性 |
|--------|-----------|------------|
| **病因** | 汽车外伤 (80%) | 胚胎发育失败 |
| **临床表现** | 急性呼吸困难，坐姿 | 通常无症状/偶然发现 |
| **诊断** | 急诊X光片 | 常规影像学发现 |
| **预后** | 手术后存活率80-90% | 矫正后预后良好 |

紧急稳定治疗，包括氧气疗法和液体支持，必须在12-24小时内进行手术修复之前完成。成功的预后取决于早期识别、适当的麻醉方案（包括手动通气）和精细的手术技术。适当管理后的良好预后强调了兽医专业知识在识别这种可能致命但高度可治疗的疾病中的重要性。

## 疾病概述与流行病学

膈疝被定义为腹部器官通过膈肌缺陷异常突入胸腔 [1]。这种情况有两种主要形式：先天性和外伤性膈疝。

先天性膈疝是由膈肌形成过程中的胚胎发育失败引起的。最常见的类型是腹膜心包膈疝，这是由于横隔发育不良所致 [1]。外伤性膈疝是获得性损伤，通常由钝力创伤如车辆事故或跌落引起 [1][2]。

从流行病学角度看，外伤性疝在犬中更为常见，约占该物种膈疝的80%，而先天性形式在猫中更为常见 [1][3]。在小动物中，与汽车相关的创伤是外伤性膈疝最常见的原因 [2][3]。撞击时腹压的突然增加向头侧消散，导致膈肌破裂 [3]。

关于年龄和性别分布，腹膜心包膈疝没有明确的性别倾向 [1]。然而，已发现品种易感性，研究发现31%的受影响犬是魏玛犬，26%的受影响猫是波斯猫 [1]。这些疝在常规检查中经常是偶然发现，并可能与其他先天异常相关，包括脑积水、脐疝和心内缺陷 [1]。

### Sources

[1] Peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[2] Diaphragmatic Hernia in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/diaphragmatic-hernia/diaphragmatic-hernia-in-animals
[3] Diaphragmatic Hernia in Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/diaphragmatic-hernia-in-cats

## 病因学与病理生理学

**病因学**

伴侣动物的膈疝有两个主要病因。外伤性破裂约占病例的80%，其中与汽车相关的创伤是犬猫中最常见的原因 [2]。外伤机制通常发生在声门开放时，腹压突然增加使肌肉性膈肌向前拉伸，使其容易撕裂 [2]。先天性缺陷代表第二大类别，其中腹膜心包疝是犬猫最常见的先天性膈肌缺陷 [1,5]。这些先天性病例通常多年无症状，可能在常规X线检查中偶然发现 [1]。

**病理生理学**

膈疝发生后，几种病理生理学变化严重损害心肺功能 [2,6]。由于膈肌收缩丧失和胸肺耦合破坏，通气功能受损。气体交换因肺不张和静息肺容量减少而恶化，造成通气-灌注不匹配和肺内分流 [2]。疝入的腹部器官在胸腔内形成占位性病变，进一步降低功能性肺容量。

心血管损害通过静脉回流受压发生，减少心输出量和氧气输送 [2]。当胃疝入并扩张时，由于胸腔结构严重受压，可在数分钟内发生快速恶化 [2]。这些病理生理学变化产生呼吸和循环功能障碍的级联反应，如不及时手术干预，可迅速发展为危及生命的心肺衰竭。

### Sources
[1] Incidental finding of a peritoneopericardial hernia in a cat: https://www.dvm360.com/view/clinical-exposures-incidental-finding-peritoneopericardial-hernia-cat/1000
[2] Managing diaphragmatic hernias (Proceedings): https://www.dvm360.com/view/managing-diaphragmatic-hernias-proceedings
[3] Clinical diagnosis and surgical management of diaphragmatic: https://avmajournals.avma.org/view/journals/javma/248/12/javma.248.12.1399.xml
[4] Congenital and Inherited Disorders of the Cardiovascular System of Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/congenital-and-inherited-disorders-of-the-cardiovascular-system-of-cats
[5] Diaphragmatic Hernia in Animals: https://www.merckvetmanual.com/respiratory-system/diaphragmatic-hernia/diaphragmatic-hernia-in-animals
[6] AVMA 2017: Respiratory Complications of Trauma: https://www.dvm360.com/view/avma-2017-respiratory-complications-of-trauma

## 临床表现与诊断方法

膈疝的临床症状根据急性程度、疝入范围和并发损伤而有显著差异 [1]。在急性外伤性病例中，呼吸困难是最常观察到的体征，常伴有犬采取肘部外展的特征性坐姿 [2]。体格检查可能发现胸部听诊时肺音消失或存在胃肠音，以及心音沉闷 [1]。

慢性病例表现不同，全身性症状如体重减轻比呼吸道症状更为突出 [1]。许多慢性疝动物表现为非特异性症状，如间歇性呕吐、厌食或运动耐力降低，这些症状可能在创伤后数周至数年发展 [2]。

**诊断影像学**对确诊至关重要。胸部X光片通常具有诊断价值，显示膈肌轮廓消失、腹腔内脏器位于胸腔内以及腹腔内脏器移位 [1]。X线证据可能包括在胸膜腔内清晰可见的肝叶、肠袢、脾脏或胃 [2]。当标准X光片不确定时，对比X线摄影、超声检查和CT等先进影像学技术可能有助于诊断 [1][3]。

**诊断挑战**包括并发胸腔积液影响X线片解读和延迟就诊，后者可能最初没有临床症状 [1][2]。在先天性病例中，特别是猫的腹膜心包膈疝，该疾病通常是偶然发现 [4]。

### Sources
[1] Diaphragmatic Hernia in Animals - Respiratory System: https://www.merckvetmanual.com/respiratory-system/diaphragmatic-hernia/diaphragmatic-hernia-in-animals
[2] Diaphragmatic, inguinal, & perinial hernia repair (Proceedings): https://www.dvm360.com/view/diaphragmatic-inguinal-perinial-hernia-repair-proceedings
[3] Emergency approach to thoracic trauma (Proceedings): https://www.dvm360.com/view/emergency-approach-thoracic-trauma-proceedings
[4] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat

## 治疗选择

医疗稳定是膈疝管理的基础 [1][5]。初始紧急治疗重点是通过鼻导管（50-100 ml/kg/分钟）补充氧气，使用晶体液进行液体治疗以维持灌注，以及仔细调整患者体位以优化呼吸功能 [5]。术前稳定应在12-24小时内进行，但胃疝入需要立即手术干预，因为胃扩张有损害通气的风险 [6][7]。

**手术修复**仍然是所有类型膈疝的确定性治疗方法 [6][7]。腹中线开腹手术入路提供最佳视野和通路 [6][7]。小心复位疝入的器官，使用钝性分离松解粘连，使用3-0至4-0不可吸收或可吸收缝线以单纯间断缝合或Ford缝合模式单层缝合关闭膈肌缺陷 [1][6][7]。对于需要网片修复的慢性病例，可使用合成材料 [1]。在完全关闭前放置胸导管进行空气排出至关重要 [6][7]。

**麻醉注意事项**需要特殊方案，因为存在呼吸功能受损 [2][5]。整个手术过程中必须维持手动正压通气，初始吸气压力限制在<25 cmH2O以防止气压伤 [5]。使用芬太尼输注（0.2-2.0 ug/kg/min）的平衡麻醉有助于维持心血管稳定性，同时减少吸入麻醉剂需求 [5]。

**术后管理**包括监测胸导管24小时、使用阿片类药物进行疼痛管理、氧气补充和限制活动 [6][7]。最严重的并发症是肺不张肺快速复张后的复张性肺水肿，特别是在慢性疝入的猫中 [8]。其他并发症包括气胸、血胸和再疝 [7][8]。

### Sources
[1] Congenital retrosternal (Morgagni) diaphragmatic hernias in ...: https://avmajournals.avma.org/view/journals/javma/231/3/javma.231.3.427.xml
[2] Emergency anesthesia: What should we do? (Proceedings): https://www.dvm360.com/view/emergency-anesthesia-what-should-we-do-proceedings
[3] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[4] Managing diaphragmatic hernias (Proceedings): https://www.dvm360.com/view/managing-diaphragmatic-hernias-proceedings
[5] Specific surgical emergencies (Proceedings): https://www.dvm360.com/view/specific-surgical-emergencies-proceedings

## 鉴别诊断与预后

### 鉴别诊断

外伤性膈疝必须与其他引起相似呼吸道症状的胸部疾病相鉴别。主要鉴别诊断包括食管裂孔疝、膈膨升和其他胸部创伤并发症 [1,2]。对于外伤性病例，约50%的犬猫就诊时没有已知的创伤史，使诊断具有挑战性 [2]。

腹膜心包膈疝必须与引起全心肿大和心脏轮廓增大的其他原因相鉴别。关键鉴别诊断包括心包积液、先天性心脏缺陷（动脉导管未闭、室间隔缺损、心内膜垫缺损）、心肌病和获得性心脏病 [3]。

鉴别特征包括没有心脏杂音和X线片上肺血管大小正常，这与许多先天性心脏缺陷不同 [3]。超声心动图通过识别心包囊内存在腹部器官而非液体积聚，有助于与心包积液鉴别。阳性对比腹膜造影术通过显示心脏周围的造影剂提供确诊依据。

### 预后

膈疝相关的死亡率根据手术时间而变化，据报道在损伤后不到24小时或超过一年进行手术时死亡率较高 [4]。最近的文献质疑这一理论，据报道手术矫正后的存活率在80-90%之间 [4]。

对于腹膜心包膈疝，手术矫正后的预后通常良好，在没有并发症因素的情况下预期寿命正常 [3]。早期手术干预可预防并发症并优化结果。

### Sources
[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/257/7/javma.257.7.697.xml
[2] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/235/9/javma.235.9.1041.xml
[3] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[4] Specific surgical emergencies (Proceedings): https://www.dvm360.com/view/specific-surgical-emergencies-proceedings
