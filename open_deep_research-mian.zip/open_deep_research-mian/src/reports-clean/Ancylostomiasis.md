# 伴侣动物钩虫病：综合兽医指南

钩虫病是影响全球犬猫的最重要寄生虫病之一，可导致严重贫血并在幼年动物中引发潜在的致命并发症。本综合报告探讨了伴侣动物钩虫感染的多方面性质，专门聚焦于兽医实践应用。分析涵盖了主要致病物种，包括*犬钩虫*（*Ancylostoma caninum*）、*管形钩虫*（*A. tubaeforme*）和*狭头钩虫*（*Uncinaria stenocephala*），它们独特的地理分布和临床表现。探讨的关键领域包括新出现的诊断挑战，如驱虫药耐药性、先进的分子检测方法以及结合多类药物的 evolving 治疗方案。该报告通过每月心丝虫预防药物和环境管理解决了关键的预防策略，同时审视了使这种寄生虫感染临床识别复杂化的鉴别诊断。

## 摘要

对钩虫病的综合分析揭示了一种复杂的寄生虫病，需要多方面的兽医管理方法。*犬钩虫*（*Ancylostoma caninum*）成为临床上最重要的病原体，导致严重的失血性贫血，对幼犬尤其构成威胁，而*管形钩虫*（*A. tubaeforme*）和*狭头钩虫*（*U. stenocephala*）等物种则表现出更细微的临床模式。诊断领域已从传统的粪便浮选法发展到 incorporating 基于PCR的耐药性筛查和抗原检测，解决了严重贫血动物需要推定治疗时的关键潜伏期挑战。

治疗方案已通过联合驱虫疗法适应新出现的耐药性，其中依莫德赛/吡喹酮对难治性感染显示出前景。通过从6-8周龄开始全年每月预防药物进行预防仍然至关重要，同时结合环境管理策略，包括及时清除粪便和预防母体传播方案。

| 管理方面 | 关键方法 | 关键考虑因素 |
|---|---|---|
| 诊断 | 离心浮选 + PCR | 幼年动物的潜伏期 |
| 治疗 | 多药联合 | 新出现的耐药模式 |
| 预防 | 每月预防药物 | 环境污染控制 |

兽医从业者必须对这种不断演变的寄生虫威胁保持高度警惕，实施全面的预防方案，同时准备通过先进的诊断和治疗方法管理耐药性感染。

## 疾病概述

钩虫病是由属于钩虫属（*Ancylostoma*）和狭头钩虫属（*Uncinaria*）的钩虫引起的犬猫寄生虫感染[1]。这些线虫寄生虫寄生于伴侣动物的小肠中，是全球影响宠物最常见的胃肠道寄生虫之一。

**地理分布和流行病学**

多种钩虫物种在全球感染犬猫，具有不同的地理分布。*犬钩虫*（*Ancylostoma caninum*）是全球热带和亚热带地区犬钩虫病的主要原因，被认为是致病性最强的犬钩虫[1]。在美国，有四个主要物种影响伴侣动物：*犬钩虫*（常见犬钩虫）、*管形钩虫*（*Ancylostoma tubaeforme*，常见猫钩虫）、*巴西钩虫*（*Ancylostoma braziliense*，影响东南部州的犬猫）和*狭头钩虫*（*Uncinaria stenocephala*，主要在较冷的北部地区）[1][2]。

历史上，*狭头钩虫*（*U. stenocephala*）在加拿大和美国北部各州占主导地位，主要是狐狸寄生虫。然而，*犬钩虫*（*A. caninum*）最近在这些地区变得更加普遍[1]。患病率因地理位置、年龄和提供给动物的护理水平而异。

**基本病理生理学**

成虫钩虫附着于小肠黏膜，主要通过失血引起疾病[1][2]。不同物种根据其吸血行为表现出不同程度的致病性。*犬钩虫*（*A. caninum*）造成最显著的失血（每条虫每天高达0.1 mL），而*巴西钩虫*（*A. braziliense*）和*狭头钩虫*（*U. stenocephala*）等物种则不太热衷于吸血，很少引起贫血[1]。相反，这些物种可能通过附着点周围的血清渗漏导致低蛋白血症，可能使血液蛋白降低超过10%[1]。

### Sources

[1] Hookworms in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals

[2] The nuances of hookworm biology in dogs and cats - dvm360: https://www.dvm360.com/view/nuances-hookworm-biology-dogs-and-cats-proceedings

## 常见病原体

犬猫的钩虫病由多种钩虫物种引起，它们具有不同的地理分布和致病特征[1]。在犬中，*犬钩虫*（*Ancylostoma caninum*）是全球热带和亚热带地区的主要病原体，由于其吸血行为被认为是最具致病性的钩虫物种[1]。*狭头钩虫*（*Uncinaria stenocephala*）是较冷地区的主要犬钩虫，历史上在加拿大和美国北部占主导地位，尽管*犬钩虫*（*A. caninum*）最近在这些地区变得更加常见[1]。

*巴西钩虫*（*Ancylostoma braziliense*）影响犬和猫，在美国从佛罗里达州到北卡罗来纳州分布稀疏，延伸至整个中美洲、南美洲和非洲[1]。新出现的物种*锡兰钩虫*（*Ancylostoma ceylanicum*）感染亚洲和南部非洲的犬猫，代表了一个值得注意的人畜共患病问题，其公共卫生意义日益增加[1]。

在猫中，*管形钩虫*（*Ancylostoma tubaeforme*）是全球发现的主要钩虫物种[1]。成虫钩虫寄生于小肠，*犬钩虫*（*A. caninum*）雄虫长约12毫米，雌虫15毫米，而其他物种略小[1]。

这些病原体表现出物种特异性的致病模式。*犬钩虫*（*A. caninum*）导致显著的失血（每条虫每天高达0.1 mL），而*巴西钩虫*（*A. braziliense*）、*管形钩虫*（*A. tubaeforme*）、*锡兰钩虫*（*A. ceylanicum*）和*狭头钩虫*（*U. stenocephala*）则不太热衷于吸血，但可能通过附着点的血清渗漏导致低蛋白血症[1]。

### Sources
[1] Hookworms in Small Animals: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals

## 临床症状和体征

钩虫病表现出广泛的临床表现，从无症状感染到危及生命的贫血，特别是在幼年动物中[1]。在犬中，最具特征性的体征是急性正细胞正色素性贫血，在严重病例中进展为低色素性小细胞性贫血，主要由*犬钩虫*（*Ancylostoma caninum*）感染引起[1]。幼犬尤其脆弱，常因小肠中成虫失血而发展为致命性贫血[1]。

典型的临床体征包括虚弱、黑便（黑色柏油样便）、低蛋白血症和患病动物生长不良[1]。贫血直接由吸血活动和*犬钩虫*（*A. caninum*）更换取食部位时发生的出血性溃疡引起，单条虫在24小时内可能造成高达0.1 mL的失血[1]。成熟、营养良好的犬可能亚临床携带感染，作为宿主储源[1]。

在猫中，大多数钩虫感染保持无症状，但重度感染时可能出现体重减轻和轻度贫血[9]。与*犬钩虫*（*A. caninum*）不同，其他钩虫物种包括*巴西钩虫*（*A. braziliense*）、*管形钩虫*（*A. tubaeforme*）和*狭头钩虫*（*Uncinaria stenocephala*）很少引起显著贫血，但可能通过蛋白丢失导致低蛋白血症[1]。

其他表现可能包括粘液性腹泻、被毛质量差以及幼虫皮肤穿透引起的皮炎，特别是*狭头钩虫*（*U. stenocephala*）感染时发生在趾间[1]。严重感染的幼犬可能因幼虫通过肺部迁移而发展为肺炎[1]。

### Sources
[1] Hookworms in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals
[9] Gastrointestinal Parasites of Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/gastrointestinal-parasites-of-cats

## 诊断方法

钩虫病的准确诊断依赖于临床表现评估结合实验室技术检测钩虫卵或幼虫。临床表现通常包括苍白黏膜、虚弱和腹泻，特别是在幼年动物中，感染可能危及生命[1]。然而，仅凭临床症状不足以做出明确诊断。

**粪便浮选技术**

钩虫诊断的金标准是离心浮选法，与简单浮选法相比，它显著提高了诊断灵敏度[1][2]。离心浮选浓缩虫卵并通过显微镜检查进行检测，研究表明其回收率优于被动浮选技术[2]。浮选溶液的推荐比重范围为1.18-1.20，硫酸锌对钩虫卵回收特别有效，同时保持标本完整性[1]。

**分子诊断**

基于PCR的检测已成为有价值的诊断工具，特别是用于检测驱虫药耐药性标记。KeyScreen GI寄生虫PCR可以检测*钩虫属*（*Ancylostoma*）物种，同时鉴定β-微管蛋白基因密码子F167Y处的苯并咪唑耐药性多态性[6]。这种双重功能允许从单个粪便样本中进行诊断和耐药性筛查。

**粪便抗原检测**

市售的钩虫粪便抗原检测可检测*钩虫属*（*Ancylostoma* spp）和*狭头钩虫属*（*Uncinaria* spp）产生的抗原[1]。这些检测可以识别活动性感染，即使粪便虫卵计数可能较低或常规浮选方法结果不一致时。

**潜伏期考虑因素**

一个关键的诊断挑战是潜伏期，在此期间钩虫存在但尚未产卵[1]。感染后15-20天首次排出虫卵，这意味着严重贫血的幼年动物即使粪便检查结果为阴性也可能需要推定治疗[1]。此外，足够的粪便样本量（最少1克）对于准确诊断至关重要，因为样本量不足可能导致假阴性结果[7]。

### Sources
[1] Hookworms in Small Animals: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals
[2] Just Ask the Expert: What fecal analysis method do you use?: https://www.dvm360.com/view/just-ask-expert-what-fecal-analysis-method-do-you-use
[3] Emergence of canine hookworm treatment resistance: Novel detection of Ancylostoma caninum anthelmintic resistance markers by fecal PCR in 11 dogs from Canada: https://avmajournals.avma.org/view/journals/ajvr/84/9/ajvr.23.05.0116.xml
[4] Accurate evaluation of fecal samples critical to patient: https://www.dvm360.com/view/accurate-evaluation-fecal-samples-critical-patient

## 治疗选择

钩虫病的治疗需要多种批准的驱虫剂，具体方案因寄生虫物种和感染严重程度而异。芬苯达唑、莫昔克丁和吡喃酮被批准用于治疗犬的*犬钩虫*（*A. caninum*）和*狭头钩虫*（*U. stenocephala*）感染[1]。米尔贝霉素肟对*犬钩虫*（*A. caninum*）感染也有效[1]。治疗方案通常涉及重复给药以解决迁移幼虫并防止再感染。

支持性护理在严重病例中至关重要，特别是当存在贫血时。可能需要输血或补充铁剂，随后给予高蛋白饮食直至血红蛋白水平恢复正常[1]。这种支持性方法对于预防有显著失血的幼年动物致命结局至关重要。

耐药性感染代表了一个新出现的挑战，需要联合治疗方法。使用芬苯达唑、双羟萘酸噻嘧啶和莫昔克丁同时给药的多类驱虫药物组合已显示出对耐药菌株的有效性[1]。对于难治性病例，依莫德赛/吡喹酮组合已证明有效。当使用1 mg/kg的依莫德赛剂量口服给药时，依莫德赛加吡喹酮实现了对多种耐药*犬钩虫*（*A. caninum*）的100%粪便虫卵计数减少[2]。

建议进行定期粪便监测以评估治疗效果，治疗后14天进行粪便检查以确认寄生虫清除[1]。当怀疑耐药时，应进行粪便虫卵计数减少检测以指导治疗决策并防止进一步传播。

### Sources

[1] Hookworms in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals
[2] Multiple anthelmintic drug resistance in hookworms (Ancylostoma caninum) in a Labrador breeding and training kennel in Georgia, USA: https://avmajournals.avma.org/view/journals/javma/261/3/javma.22.08.0377.xml

## 预防措施和鉴别诊断

**预防措施**

具有广谱肠道寄生虫控制活性的每月心丝虫预防药物代表了钩虫预防的基石[1]。伴侣动物寄生虫委员会（CAPC）建议全年使用这些产品，最早从6-8周龄开始[2]。对于幼犬，驱虫应从2周龄开始，每2周治疗一次直到8周，然后过渡到每月预防药物[3]。

环境管理同样至关重要。及时从院子里清除粪便可防止幼虫在受污染的土壤中发育[4]。可定期清洗的混凝土表面优于土壤跑道，受污染区域可以用每2平方米1公斤的硼酸钠处理[8]。预防母体传播需要用芬苯达唑治疗怀孕母犬，从妊娠第40天到分娩后2天[8]。

**鉴别诊断**

钩虫病必须与几种表现出相似临床症状的疾病进行鉴别。其他寄生虫感染包括鞭虫（*Trichuris vulpis*）、蛔虫（*弓蛔虫属*物种）和其他钩虫物种引起重叠的胃肠道症状[7]。炎症性肠病可以模拟慢性钩虫感染，表现为持续性腹泻和体重减轻[6]。

急性出血性腹泻综合征（AHDS）表现为突发性血性腹泻，类似于严重钩虫病，但通常显示血液浓缩而非贫血[7]。鉴别因素包括钩虫病特征性的失血性贫血与AHDS的血液浓缩模式。明确诊断依赖于粪便检查显示特征性的薄壳卵形钩虫卵以及对特异性驱虫疗法的反应[8]。

### Sources
[1] Parasite control in pets requires year-round vigilance: https://www.dvm360.com/view/parasite-control-pets-requires-year-round-vigilance
[2] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[3] CAPC primary guidelines: https://www.dvm360.com/view/capc-primary-guidelines
[4] Challenges in parasite management: https://www.dvm360.com/view/challenges-parasite-management
[5] Deworming: Next steps in disease prevention: https://www.dvm360.com/view/deworming-next-steps-disease-prevention
[6] MSD Veterinary Manual Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[7] Merck Veterinary Manual Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[8] MSD Veterinary Manual Hookworms in Small Animals: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/hookworms-in-small-animals
