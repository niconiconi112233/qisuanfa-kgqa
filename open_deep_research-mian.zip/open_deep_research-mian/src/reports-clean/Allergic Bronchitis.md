# 犬猫过敏性支气管炎

过敏性支气管炎是伴侣动物中的一种重要呼吸系统疾病，其特征为由环境过敏原而非传染性病原体引发的慢性炎症性气道疾病。这种超敏反应介导的疾病影响约1-5%的猫，常见于中老年犬，小型犬和暹罗猫表现出特殊易感性。本报告探讨涉及I型超敏反应反应的复杂病理生理学，探索包括屋尘螨和花粉在内的环境触发因素，并详述物种特异性临床表现，从犬的慢性咳嗽到猫的发作性呼吸困难。治疗策略包括皮质类固醇、支气管扩张剂和全面的环境管理，而鉴别诊断需要与传染性气管支气管炎和嗜酸性粒细胞性支气管肺炎进行仔细区分。

## 摘要

伴侣动物的过敏性支气管炎需要对其多方面性质进行全面理解，从I型超敏反应机制到物种特异性管理方法。该疾病表现出明确的流行病学模式，城市猫的患病率为1-5%，中老年小型犬最易感。环境过敏原作为主要触发因素，而当呼吸道防御功能受损时，继发性细菌感染会使管理复杂化。

| 方面 | 犬 | 猫 |
|--------|------|------|
| 主要体征 | 慢性湿咳伴终末干呕 | 发作性呼吸困难和喘息 |
| 品种易感性 | 小型犬 | 暹罗猫和喜马拉雅猫 |
| 治疗反应 | 皮质类固醇治疗逐渐改善 | 吸入药物治疗反应迅速 |
| 预后 | 可变，取决于环境控制 | 适当管理下通常良好 |

成功的结果取决于早期诊断、持续的抗炎治疗和严格的环境管理。吸入皮质类固醇与全面过敏原规避策略的结合提供了最佳的长期预后，尽管一些患者需要终身管理以防止气道重塑并维持生活质量。

## 疾病概述和流行病学

伴侣动物的过敏性支气管炎是一种慢性炎症性呼吸系统疾病，特征为可逆性支气管收缩和嗜酸性粒细胞气道炎症[1]。其病理生理学涉及由环境过敏原触发的I型超敏反应，导致Th2细胞因子优先产生、IgE合成以及随后的嗜酸性粒细胞气道浸润[2]。这种免疫级联反应导致气道炎症、高反应性、黏液过度分泌和进行性气道重塑。

在犬中，慢性过敏性支气管炎表现为一种炎症性慢性肺部疾病，特征为干燥、刺耳、剧烈的咳嗽，易由运动或气管压力诱发[3][4]。该疾病最常见于中老年犬，小型犬表现出更高的易感性，但在大型犬中也会发生[2][5]。慢性支气管炎涉及持续至少2个月的咳嗽，而无其他可识别的呼吸系统疾病[2]。

流行病学数据显示，猫过敏性哮喘影响约1-5%的宠物猫群体[2]。与农村环境的猫相比，城市猫表现出更高的发病率，表明环境因素起着重要作用[1][2]。年龄分布显示对青年至中年猫的偏好，该疾病很少在10岁以上的老年患者中发展[2]。品种易感性包括暹罗猫和可能雌性猫的比例过高[2]。风险因素包括接触环境过敏原如屋尘螨和花粉、吸烟家庭、幼猫期严重呼吸道感染以及城市生活环境[1][2]。

### Sources
[1] Feline lower airway disease (Proceedings): https://www.dvm360.com/view/feline-lower-airway-disease-proceedings
[2] Managing allergic asthma in cats (Proceedings): https://www.dvm360.com/view/managing-allergic-asthma-cats-proceedings
[3] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[4] Hypersensitivity Diseases in Animals - Immune System - Merck Veterinary Manual: https://merckvetmanual.com/immune-system/immunologic-diseases/excessive-adaptive-responses?qt=immune-mediated
[5] Breed-specific canine respiratory diseases: https://www.dvm360.com/view/breed-specific-canine-respiratory-diseases

## 常见病原体和触发因素

伴侣动物的过敏性支气管炎涉及环境过敏原而非传染性病原体作为主要触发因素[1][2]。最重要的环境过敏原包括屋尘螨、花粉、霉菌孢子以及各种吸入性刺激物如灰尘、气溶胶、二手烟和清洁产品[2][3]。这些过敏原在遗传易感动物中诱导不适当的IgE介导的免疫反应[1]。

尽管存在潜在的过敏病因，其机制仍知之甚少。没有足够证据表明临床症状与肺肥大细胞增加、组胺释放或IgE产生相关[2]。呼吸道分泌物中嗜酸性粒细胞的存在或缺失本身不足以证明过敏起源[2]。

当呼吸道防御机制因初始过敏性炎症而受损时，继发性细菌感染常使过敏性支气管炎复杂化[6]。机会性细菌包括多杀性巴氏杆菌、支气管败血波氏杆菌、链球菌和葡萄球菌通常存在于上呼吸道，但当气道防御功能减弱时可引起继发感染[6]。

支原体感染可能在某些猫中作为继发触发因素，加剧现有的过敏性气道疾病[1]。虽然不是主要原因，但这些生物可以在患有潜在过敏性支气管炎的猫中触发哮喘反应。

### Sources

[1] Bronchopulmonary disease in cats-is it really asthma? (Proceedings): https://www.dvm360.com/view/bronchopulmonary-disease-cats-it-really-asthma-proceedings
[2] Asthma (Proceedings): https://www.dvm360.com/view/asthma-proceedings
[3] Managing allergic asthma in cats (Proceedings): https://www.dvm360.com/view/managing-allergic-asthma-cats-proceedings
[4] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals
[5] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[6] Allergic Pneumonitis in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/allergic-pneumonitis-in-dogs-and-cats

## 临床表现和诊断方法

### 临床症状

过敏性支气管炎在犬和猫中的表现不同[1]。在犬中，慢性咳嗽是标志性症状，通常进行性发展且为湿咳伴终末干呕[5]。咳嗽在活动和兴奋时加重，常可通过气管触诊诱发[5]。体格检查显示呼气性呼吸困难、喘息和在晚期病例中出现捻发音[4][5]。

猫过敏性支气管炎（支气管哮喘）表现为可能时有时无的呼吸急促、咳嗽或喘息[2]。青年猫和暹罗/喜马拉雅品种最常受影响[2]。体格检查异常包括咳嗽、呼吸困难以及肺组织中的捻发音和喘息音[4]。支气管肺泡音增强可能是唯一的听诊异常[4]。如果呼吸困难严重，可能观察到表明缺氧的蓝色黏膜[2]。

### 诊断方法

诊断基于病史、体格检查、胸部X光片、气道检查和气道细胞学[5]。胸部X光检查对于确定疾病严重程度和排除其他咳嗽原因很重要[1]。胸部X光片通常显示支气管型，在一些呼吸困难的猫中可见过度充气和气体滞留[4]。

支气管镜检查显示支气管黏膜充血和不规则、黏液过度分泌和渗出物[5]。气管冲洗样本显示黏液增加和可变的炎症细胞[4]。对于具有嗜酸性粒细胞细胞学的猫，应进行丝虫病评估和寄生虫粪便检查[4]。

### Sources
[1] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[2] Tracheobronchitis (Bronchitis, Bronchial Asthma) in Cats: https://www.merckvetmanual.com/en-au/cat-owners/lung-and-airway-disorders-of-cats/tracheobronchitis-bronchitis-bronchial-asthma-in-cats
[3] Introduction to Lung and Airway Disorders of Dogs: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/introduction-to-lung-and-airway-disorders-of-dogs
[4] Small airway disease: Bronchitis in dogs and cats (Proceedings): https://www.dvm360.com/view/small-airway-disease-bronchitis-dogs-and-cats-proceedings
[5] Canine chronic bronchitis and pulmonary fibrosis (Proceedings): https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings

## 治疗策略和管理

犬猫过敏性支气管炎的有效管理需要多模式方法，结合药物干预、环境控制和长期监测方案。治疗成功取决于控制急性支气管收缩和潜在的气道炎症[1]。

**皮质类固醇**仍然是治疗炎症性气道疾病的基石。口服泼尼松龙通常以1-2 mg/kg每12小时一次的剂量开始用于犬，然后逐渐减量至隔日给药[2]。在猫中，应使用泼尼松龙而非泼尼松，因为其生物利用度更好，采用类似的给药方案[2]。吸入性皮质类固醇如氟替卡松（110-200 μg每12小时）可减少全身副作用，对长期管理特别有益[1][6]。

**支气管扩张剂**在急性发作期间提供必要的缓解。β-2激动剂如特布他林（0.01 mg/kg皮下注射）或通过定量吸入器给予的沙丁胺醇可在5-15分钟内提供快速支气管扩张[1][2]。甲基黄嘌呤类药物如茶碱（犬：5-7 mg/kg每8小时；猫：3 mg/kg每12小时）提供额外的支气管扩张和呼吸肌支持[2]。

**环境管理**对长期控制至关重要。过敏原规避包括消除香烟烟雾、灰尘猫砂、空气清新剂和改善通风[6][7]。体重管理和压力减轻有助于减少急性加重[4]。

**长期方案**需要每3-6个月定期监测，并训练主人识别呼吸窘迫。治疗方案应根据个体患者量身定制，较简单的方案可提高主人依从性[9]。

### Sources

[1] Use of Inhaled Medications to Treat Respiratory Diseases in Animals: https://meridian.allenpress.com/jaaha/article/42/2/165/176024/Use-of-Inhaled-Medications-to-Treat-Respiratory
[2] Systemic Treatment of Inflammatory Airway Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/systemic-treatment-of-inflammatory-airway-disease-in-animals
[3] Managing of bronchial disease in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[4] Update of therapies for feline asthma (Proceedings): https://www.dvm360.com/view/update-therapies-feline-asthma-proceedings
[5] Medical therapy of feline asthma (Proceedings): https://www.dvm360.com/view/medical-therapy-feline-asthma-proceedings
[6] Coughing and wheezing cats: Diagnosis and treatment of feline asthma (Proceedings): https://www.dvm360.com/view/coughing-and-wheezing-cats-diagnosis-and-treatment-feline-asthma-proceedings

## 预防和鉴别诊断

**预防措施**

环境控制仍然是犬猫过敏性支气管炎预防的基石。关键预防策略包括避免环境刺激物如烟草烟雾、化学烟雾、屋尘、蒸汽和多尘环境[6]。通过充分通风和使用空气过滤系统维持适当的空气质量有助于减少接触空气传播的过敏原[1]。

疫苗接种方案应针对可能使动物易患慢性支气管炎症的传染性呼吸系统疾病，包括犬的犬瘟热、副流感、犬腺病毒-2和支气管败血波氏杆菌疫苗[1]。然而，过敏性支气管炎本身没有特定的疫苗，因为管理主要侧重于环境控制和触发因素规避[6]。

**主要鉴别诊断**

几种重要疾病必须与过敏性支气管炎相区分。在犬中，犬窝咳（传染性气管支气管炎）表现为刺耳的干咳，但通常发生在最近接触过其他犬的年轻动物中，并在10-20天内缓解[1][9]。心丝虫疾病应通过适当检测排除，因为它可引起类似的呼吸系统症状和嗜酸性粒细胞炎症[3][4]。

嗜酸性粒细胞性支气管肺炎代表一种更严重的超敏反应，与过敏性支气管炎的不同之处在于引起弥漫性肺浸润，通常影响伴有明显外周嗜酸性粒细胞增多的年轻犬[3][4]。老年犬的慢性支气管炎可能通过其非过敏病因和不同的炎症细胞群来区分[6][9]。

**鉴别特征**

对皮质类固醇和支气管扩张剂的反应有助于确认过敏病因，而气道样本的细菌培养可排除传染性病因[6][9]。支气管分泌物中嗜酸性粒细胞为主支持过敏性疾病，尽管也可能出现混合性炎症模式[9]。

### Sources

[1] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[2] Allergic Pneumonitis in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/allergic-pneumonitis-in-dogs-and-cats
[3] Diagnosing and managing canine eosinophilic bronchopneumopathy: https://www.dvm360.com/view/diagnosing-and-managing-canine-eosinophilic-bronchopneumopathy
[4] Canine chronic bronchitis and pulmonary fibrosis: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[5] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[6] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals

## 预后和长期结果

猫的过敏性支气管炎在适当管理时通常预后良好，尽管结果取决于几个关键因素。支气管炎的急性阶段通常在2-3天内缓解，尽管咳嗽可能持续数周[1]。大多数猫对适当治疗反应良好，许多在早期开始治疗时达到显著的症状减轻。

青年猫和某些品种如暹罗猫和喜马拉雅猫比老年猫有更好的治疗反应，在老年猫中慢性咳嗽更常与肺炎而非过敏性支气管炎相关[1]。环境管理在长期成功中起着关键作用 - 避免接触气溶胶刺激物如香烟烟雾、香水、花粉、霉菌和灰尘的猫通常经历更好的结果[1,2]。

使用吸入性皮质类固醇如氟替卡松的治疗显示出良好的临床有效性，最佳效果在1-2周内出现[3]。对于严重发作，肠胃外糖皮质激素通常提供快速缓解[4]。长期管理策略侧重于持续的抗炎治疗而非间歇性治疗急性发作。接受适当吸入药物治疗的猫可以维持良好的生活质量，与口服皮质类固醇相比全身副作用最小[3]。

当存在并发疾病或环境触发因素无法充分控制时，预后变得更加谨慎。一些猫需要终身治疗，持续的亚临床炎症可能导致永久性结构改变，包括气道重塑[5]。最佳结果的关键在于早期诊断、持续的治疗依从性和全面的环境管理以最小化过敏原暴露。

### Sources

[1] Merck Veterinary Manual Tracheobronchitis (Bronchitis, Bronchial Asthma) in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/tracheobronchitis-bronchitis-bronchial-asthma-in-cats

[2] Merck Veterinary Manual Feline Bronchial Asthma - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-bronchial-asthma

[3] DVM 360 Treating feline bronchial disease: https://www.dvm360.com/view/treating-feline-bronchial-disease

[4] Merck Veterinary Manual Systemic Treatment of Inflammatory Airway Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/systemic-treatment-of-inflammatory-airway-disease-in-animals

[5] DVM 360 Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings
