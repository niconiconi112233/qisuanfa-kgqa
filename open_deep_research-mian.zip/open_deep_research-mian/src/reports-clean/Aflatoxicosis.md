# 犬猫黄曲霉毒素中毒：综合兽医指南

黄曲霉毒素中毒是伴侣动物健康面临的最严重的真菌毒素相关威胁之一，可导致犬猫急性肝衰竭且死亡率高。这种中毒是由于摄入了在炎热潮湿储存条件下由*曲霉菌属*产生的黄曲霉毒素污染的饲料所致。由于临床症状不特异、缺乏特异性解毒剂以及临床症状一旦出现预后不良，该疾病在兽医临床中带来了特殊挑战。本报告探讨了在小动物临床中管理黄曲霉毒素中毒病例所需的病理生理学、临床表现、诊断方法、治疗方案和预防策略，强调了早期识别和积极支持性治疗的至关重要性。

## 疾病概述与流行病学

黄曲霉毒素中毒是一种全球性的真菌毒素中毒症，由产毒菌株*黄曲霉*、*寄生曲霉*和*_nomius曲霉*在高温高湿条件下于动物饲料上产生的强效肝毒素引起[1]。这种真菌毒素中毒对伴侣动物，特别是犬和猫构成了重大威胁。

该疾病在全球范围内发生并影响多种动物物种，其中犬尤为易感。伴侣动物中大多数确诊的黄曲霉毒素中毒病例见于犬，尽管实验研究表明猫也易感[2]。与成年动物相比，幼年动物面临特别风险。

环境因素强烈影响黄曲霉毒素的产生和随后的疾病发生。包括干旱、持续高于21.1°C（70°F）的炎热天气以及农作物虫害在内的气候条件显著增加黄曲霉毒素的形成[1]。谷物水分超过15%、相对湿度超过75%的储存条件促进真菌生长和毒素产生。

流行病学模式显示出与天气条件和作物储存实践相关的季节性变化。污染通常发生在田间生长或储存期间的玉米、花生、坚果、大米和棉籽中，这使得宠物食品召回成为伴侣动物行业反复出现的问题。

### Sources

[1] Aflatoxicosis in Animals - Toxicology: https://www.merckvetmanual.com/en-au/toxicology/mycotoxicoses/aflatoxicosis-in-animals

[2] Moldy food and mycotoxins potential problems for pets: https://www.dvm360.com/view/moldy-food-and-mytoxins-potential-problems-pets

## 病因学与病理生理学

犬猫黄曲霉毒素中毒是由于摄入了由产毒菌株*黄曲霉*、*寄生曲霉*和*_nomius曲霉*产生的黄曲霉毒素污染的食物所致[1][2]。这些真菌在储存期间当水分含量超过15%且温度持续保持在21.1°C（70°F）以上时，会在玉米、花生、棉籽和其他谷物上繁殖[2]。

在四种主要黄曲霉毒素（B1、B2、G1、G2）中，黄曲霉毒素B1是最具毒性和致癌性的代谢物[1][2]。大多数病例发生在动物食用发霉饲料而非直接接触真菌时[1]。

摄入后，黄曲霉毒素通过细胞色素P450酶进行肝脏代谢，产生与大分子（特别是核酸和核蛋白）结合的毒性环氧化物代谢物[1][2]。这种生物活化过程耗竭肝脏谷胱甘肽（GSH）储备并产生活性氧，引起剂量依赖性氧化损伤[1]。

肝脏通过多种机制承受主要损伤：自由基形成导致的直接肝细胞坏死、导致突变和潜在致癌的DNA烷基化、影响必需代谢酶的蛋白质合成受损以及免疫抑制[1][2]。环氧化物代谢物可与循环白蛋白结合长达两个月，导致毒性延长[1]。

伴侣动物特别易感，饮食浓度低于50 ppb被认为对犬是可耐受的，而大约两倍于此的水平通常会导致临床疾病[2]。

### Sources
[1] The critical care of aflatoxin-induced liver failure in dogs: https://www.dvm360.com/view/toxicology-brief-critical-care-aflatoxin-induced-liver-failure-dogs
[2] Merck Veterinary Manual Aflatoxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/mycotoxicoses/aflatoxicosis-in-animals

## 临床表现与诊断

### 临床体征与症状

犬猫黄曲霉毒素中毒表现为符合急性肝衰竭的非特异性体征[1]。在犬中，临床表现包括厌食、嗜睡、呕吐和黄疸[1]。其他体征可能包括血便、黑便、呕血以及黏膜或广泛性瘀点和瘀斑[1]。患者常出现外周水肿、腹水、多尿和多饮[1]。

该疾病通常起病隐匿，初始表现模糊[1]。有些病例可能在临床症状明显之前进展为急性死亡[1]。亚急性表现在暴发中更为典型，特征为消瘦、虚弱、厌食、生长减慢和偶发性突然死亡[2]。

### 实验室检查结果

实验室异常反映严重的肝细胞损伤和合成功能受损[1]。血清生化显示肝脏酶极度升高，ALT活性常超过参考上限的10倍[1]。碱性磷酸酶、AST和胆红素浓度显著升高[2]。

凝血异常显著，包括活化的部分凝血活酶时间和凝血酶原时间延长，抗凝血酶和蛋白C浓度降低[1]。其他发现包括低胆固醇血症、低白蛋白血症、BUN降低和不同程度的血小板减少[2]。

### 诊断方法

诊断依赖于临床症状、实验室异常以及通过饲料黄曲霉毒素分析进行确诊[2]。可疑食物的化学分析至关重要，因为临床症状不特异[1]。组织黄曲霉毒素代谢物分析不太容易获得，但可在尿液、肝脏或肾脏样本中鉴定黄曲霉毒素M1[2]。

任何出现急性肝衰竭的犬都应考虑黄曲霉毒素中毒，特别是当有提示性病史时，如同一个家庭中多只动物受影响或近期饮食改变[1]。

### Sources

[1] Toxicology Brief: The critical care of aflatoxin-induced liver failure in dogs: https://www.dvm360.com/view/toxicology-brief-critical-care-aflatoxin-induced-liver-failure-dogs
[2] Aflatoxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/mycotoxicoses/aflatoxicosis-in-animals

## 治疗选项

黄曲霉毒素中毒没有特异性解毒剂，因此支持性治疗是治疗的基石[1]。立即停止污染饲料至关重要，随后提供具有适当蛋白质水平（避免可能加重肝损伤的极端情况）、维生素和微量矿物质的优质饮食以支持肝脏恢复[1]。

肝保护药物在管理黄曲霉毒素中毒中至关重要。N-乙酰半胱氨酸（140 mg/kg静脉负荷剂量，然后50-70 mg/kg每4-6小时一次）有助于补充毒素代谢所需的谷胱甘肽储备[4]。S-腺苷甲硫氨酸（17-20 mg/kg每日）和水飞蓟素（7-150 mg/kg每日）提供额外的肝脏支持和抗氧化作用[4]。

补充葡萄糖的液体疗法可解决脱水和低血糖，而血液成分疗法（新鲜冷冻血浆或全血）可管理严重凝血病和贫血[4]。维生素K1（1-5 mg/kg皮下注射）有助于纠正凝血缺陷，尽管它能改善而非解决凝血异常[4]。

其他支持措施包括使用止吐药控制呕吐、胃肠道保护剂治疗溃疡以及由于免疫抑制和肠道屏障功能受损而使用预防性抗生素[4]。在整个治疗过程中密切监测肝脏酶、凝血参数和肝功能至关重要[1][4]。

恢复时间通常较长，一些动物尽管接受了重症监护，也永远无法恢复正常生产状态[1]。

### Sources
[1] Merck Veterinary Manual Aflatoxicosis in Animals: https://www.merckvetmanual.com/toxicology/mycotoxicoses/aflatoxicosis-in-animals
[4] DVM 360 Toxicology Brief: https://www.dvm360.com/view/toxicology-brief-critical-care-aflatoxin-induced-liver-failure-dogs

## 预防与预后

### 预防措施

黄曲霉毒素中毒的预防以饲料安全和环境控制为中心[1]。宠物食品制造商必须监测黄曲霉毒素浓度，并将食品储存在清洁干燥的条件下以防止曲霉菌生长[1]。通过监测批次黄曲霉毒素含量和清洁去除轻质或破碎谷物，可以避免污染饲料，这显著降低了真菌毒素浓度[2]。

应监测当地作物状况，包括干旱和虫害，作为黄曲霉毒素形成的预测指标[2]。幼年、新断奶、怀孕和哺乳动物由于易感性增加，需要特别保护免受疑似毒性饲料的影响[2]。没有可用于预防黄曲霉毒素中毒的疫苗。

### 预期结果与预后

犬黄曲霉毒素中毒的预后通常较差，病例死亡率高[3]。恢复可能延长，严重肝损伤的动物可能永远无法恢复正常生产状态[2]。患有低白蛋白血症、低血糖和凝血病的犬预后非常谨慎，许多在诊断后一周内死亡[3]。

器官和乳制品中的黄曲霉毒素残留通常在暴露结束后1-3周内消除[2]。有黄曲霉毒素摄入史的犬可能发展为慢性肝病，并可能易患肝肿瘤性疾病[3]。

### Sources

[1] Moldy food and mycotoxins potential problems for pets: https://www.dvm360.com/view/moldy-food-and-mytoxins-potential-problems-pets

[2] Aflatoxicosis in Animals - Toxicology: https://www.merckvetmanual.com/en-au/toxicology/mycotoxicoses/aflatoxicosis-in-animals

[3] The critical care of aflatoxin-induced liver failure in dogs: https://www.dvm360.com/view/toxicology-brief-critical-care-aflatoxin-induced-liver-failure-dogs

## 鉴别诊断

黄曲霉毒素中毒需要与许多表现出相似临床症状和实验室异常的肝毒性疾病进行鉴别[1]。最重要的鉴别诊断包括由对乙酰氨基酚、酮康唑、卡洛芬和其他非甾体抗炎药引起的药物性肝毒性[2]。生物毒素暴露如蓝绿藻、*鹅膏菌属*蘑菇和苏铁棕榈种子可引起相同的肝细胞坏死模式。

必须排除传染性原因，包括*梭菌属*感染、传染性犬肝炎和全身性真菌疾病[1]。重金属中毒同样表现为急性肝衰竭。*青霉菌属*（黄天精、环氯素）和其他真菌毒素中毒以及*千里光属*中毒显示出可比较的肝脏病变[2]。

关键鉴别特征包括发霉饲料的存在或同一家庭中多只受影响的动物，这强烈提示黄曲霉毒素中毒[1]。确诊需要对可疑饲料进行黄曲霉毒素污染的化学分析或在肝脏、尿液或牛奶中检测黄曲霉毒素代谢物（M1）[2]。组织病理学检查显示特征性门静脉周围坏死、胆管增生和胆小管被铸型堵塞--这些发现有助于与其他肝毒素区分[1]。

缺乏药物或毒素暴露史，结合饲料分析和特征性组织学模式，有助于将黄曲霉毒素中毒与伴侣动物其他急性肝衰竭原因区分开来。

### Sources
[1] Toxicology Brief: The critical care of aflatoxin-induced liver failure in dogs: https://www.dvm360.com/view/toxicology-brief-critical-care-aflatoxin-induced-liver-failure-dogs
[2] Aflatoxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/mycotoxicoses/aflatoxicosis-in-animals
