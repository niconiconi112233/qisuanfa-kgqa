# 伴侣动物的肝性脑病

肝性脑病是一种影响患有肝病或门体分流的犬和猫的重要代谢性神经系统疾病。这种情况显著影响生活质量，如果未能得到识别或充分管理，可能导致危及生命的并发症。该综合征范围从细微的行为变化到严重的神经功能障碍，包括癫痫和昏迷。

本报告探讨了以氨中毒为中心的病理生理学、不同严重程度的临床表现、包括胆汁酸检测和影像学模式的诊断方法，以及全面的治疗策略。涵盖的关键领域包括犬的品种易感性、猫的物种特异性表现（如流涎）、使用乳果糖和饮食调整的医疗管理，以及影响患者预后的预后因素。

## 摘要

伴侣动物的肝性脑病是一种需要及时识别和积极管理的复杂代谢性疾病。该疾病的病理生理学以氨中毒为中心，当肝病或门体分流损害正常解毒途径时发生。临床表现差异很大，从1级的轻微嗜睡到4级的昏迷和癫痫，猫通常表现为流涎，而犬可能表现出品种特异性易感性。

诊断成功依赖于将临床评估与胆汁酸检测、影像学研究和用于分流检测的核素显像相结合。治疗效果取决于多模式方法，包括乳果糖治疗、抗生素方案、改良蛋白质饮食和肝保护剂补充。

| 治疗组成部分 | 主要作用 | 临床益处 |
|-------------------|---------------|-----------------|
| 乳果糖 | 结肠酸化 | 减少氨吸收 |
| 甲硝唑 | 减少细菌 | 减少氨产生 |
| 蛋白质改良 | 易消化来源 | 维持营养，减少毒素负荷 |
| SAMe补充剂 | 谷胱甘肽支持 | 肝细胞保护 |

预后因根本原因而异，从成功结扎分流的良好结果到终末期肝病的谨慎预后。早期识别和全面管理对于优化患者预后和防止进展到危及生命的脑病发作至关重要。

## 疾病概述与流行病学

肝性脑病（HE）是一种继发于犬和猫肝病的代谢性神经系统疾病[1]。该疾病代表一种与严重肝功能衰竭（暴发性肝功能衰竭或肝硬化）或门体分流（先天性或获得性门体分流伴功能性肝质量减少）相关的神经行为综合征[1]。

病理生理学以氨中毒为主要机制[1]。氨主要由胃肠道产生，来自肠细胞将谷氨酰胺转化为谷氨酸和细菌蛋白质降解[1]。在健康动物中，门静脉血将氨直接输送到肝细胞，通过尿素循环或谷氨酰胺合成进行解毒[1]。然而，在门体分流或肝功能衰竭的情况下，血氨浓度升高，因为氨绕过了肝脏解毒[1]。

HE分为三种类型：A型（急性肝功能衰竭）、B型（主要是门体分流）和C型（肝硬化伴有分流和肝质量减少）[1]。该疾病可以是发作性、复发性或持续性[1]。肝病在犬和猫中都很常见，尽管急性肝病比慢性肝病发生频率低[2]。

从流行病学角度看，某些品种对与肝性脑病相关的慢性肝炎存在易感性，包括比格犬、贝灵顿梗、可卡犬、大麦町犬、杜宾犬、德国牧羊犬、拉布拉多寻回犬、苏格兰梗、斯凯梗、标准贵宾犬和西部高地白梗[3]。其中许多品种也表现出肝铜积累增加[3]。

未能识别和有效管理HE会显著影响生活质量，并可能导致安乐死或死亡[1]。肝脏的大量功能储备意味着只有在肝功能严重受损时才会出现临床症状[2]。

### Sources
[1] Merck Veterinary Manual Hepatic Encephalopathy in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-encephalopathy-in-small-animals
[2] DVM 360 Acute liver disease and hepatoencephalopathy (Proceedings): https://www.dvm360.com/view/acute-liver-disease-and-hepatoencephalopathy-proceedings
[3] DVM 360 Inflammatory liver diseases in the dog (Proceedings): https://www.dvm360.com/view/inflammatory-liver-diseases-dog-proceedings

## 常见病原体与临床表现

犬和猫的肝性脑病（HE）不是由传染性病原体引起的，而是作为继发于潜在肝病或门体分流的代谢性神经系统疾病发展而来[1]。该疾病是由于通常由肝脏解毒的神经毒素积累引起的，其中氨是主要元凶，此外还有硫醇、短链脂肪酸、芳香族氨基酸和γ-氨基丁酸（GABA）[2]。

临床症状在不同严重程度间差异显著，从轻微的行为变化到危及生命的神经功能障碍[1]。1级HE表现为轻微嗜睡和精神警觉性下降，而2级涉及嗜睡增加、性格改变、轻度共济失调和不适当行为如室内排泄[1]。3级HE表现为明显的运动不协调、精神错乱、流涎、头抵墙、无目的游走和皮质盲[1]。4级代表严重HE，表现为无反应性卧倒、癫痫和昏迷[1]。

物种特异性表现包括猫特别常见的流涎，而两个物种在慢性复发性HE中可能表现出推进性转圈、虚弱和罕见的震颤[1]。可能加剧HE的诱发因素包括脱水、碱血症、低血糖、高蛋白餐（尤其是红肉）、胃肠道出血、便秘以及包括苯二氮卓类药物和巴比妥类药物在内的各种药物[1]。病理生理学涉及肝脏无法解毒氨，导致包括谷氨酸和GABA通路在内的多种神经递质系统紊乱[3]。

### Sources
[1] Hepatic Encephalopathy in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-encephalopathy-in-small-animals
[2] Portosystemic shunt in dogs and cats (Proceedings): https://www.dvm360.com/view/portosystemic-shunt-dogs-and-cats-proceedings
[3] Acute liver disease and hepatoencephalopathy (Proceedings): https://www.dvm360.com/view/acute-liver-disease-and-hepatoencephalopathy-proceedings

## 诊断方法与鉴别诊断

### 临床表现评估

肝性脑病表现为可能轻微或显著的神经系统体征[1]。常见表现包括精神沉郁、转圈、头抵墙、无目的游走、虚弱、协调性差、失明、过度流涎、行为改变（攻击性）、痴呆、虚脱、癫痫和昏迷[6]。在猫中，流涎特别突出[4]。体征经常波动，没有明显模式地时好时坏，尽管25%的患者可能在餐后经历加重[1][4]。

### 实验室检测

**氨和胆汁酸**：高氨血症常见，但与神经系统体征严重程度无相关性[1]。空腹和餐后两小时的胆汁酸测量仍然是依赖门静脉血流的最重要肝功能测试[1]。正常空腹值<5 μmol/L（犬）和<2 μmol/L（猫），餐后值<20 μmol/L（犬）和<10 μmol/L（猫）[1]。

**标准实验室参数**：全血细胞计数可能显示小红细胞性贫血（犬50%，猫15%）[7]。生化面板通常显示碱性磷酸酶和ALT轻度升高、BUN降低（64%病例）、低血糖、低胆固醇血症（65%）和白蛋白降低（犬90%）[7]。尿液分析经常显示尿酸铵晶体[1]。

### 影像学检查

**放射摄影**：腹部X光片显示由于腹部脂肪减少导致的普遍对比度降低，通常伴有肝脏缩小和肾脏肿大[1]。

**超声检查**：诊断高度敏感，在90%的病例中可显示门体分流，甚至是肝外分流[1]。CT和MRI已被用于识别和定位分流[1]。

**核素显像**：使用99m锝高锝酸盐的门脉显像是一种极好的无创筛查测试，正常犬的分流分数<10%，而患病犬>50%[1]。

### 鉴别诊断

主要鉴别诊断包括微血管发育不良、获得性肝病、毒素暴露和其他神经功能障碍原因[4]。原发性肝肿瘤比转移性疾病更可能引起低血糖和低蛋白血症[2]。鉴别因素包括就诊年龄、品种易感性和特定的实验室模式，特别是胆汁酸浓度和肝功能参数。

### Sources

[1] Managing portosystemic shunts (Proceedings): https://www.dvm360.com/view/managing-portosystemic-shunts-proceedings-0
[2] Primary hepatic and biliary tract tumors in dogs and cats: https://www.dvm360.com/view/primary-hepatic-and-biliary-tract-tumors-dogs-and-cats-overview
[4] Portosystemic shunts: more common and more confusing: https://www.dvm360.com/view/portosystemic-shunts-more-common-and-more-confusing-most-realize-proceedings
[6] Disorders of the Liver and Gallbladder in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats
[7] Portosystemic shunt in dogs and cats (Proceedings): https://www.dvm360.com/view/portosystemic-shunt-dogs-and-cats-proceedings

## 治疗选择与预防措施

肝性脑病的治疗侧重于减少氨产生、支持肝功能和管理诱发因素[1]。乳果糖作为基础治疗，口服剂量为0.5-1.5 mL/kg每8-12小时一次，或作为保留灌肠（3份乳果糖对7份水）[1]。这种合成双糖酸化结肠，减少氨吸收和细菌产生。

抗生素治疗使用甲硝唑（7.5 mg/kg每8-12小时一次）或新霉素靶向产氨细菌，但需谨慎剂量以防止神经毒性[1]。含有乳酸杆菌和双歧杆菌的益生菌可能减少有害肠道细菌[1]。

饮食管理涉及蛋白质改良而非限制，除非存在临床脑病[2][3]。犬需要最少2.5 g蛋白质/kg，而猫由于专性食肉动物需求需要更高量[1]。处方肝脏饮食提供更好耐受的蛋白质来源（乳制品、植物基），同时限制铜含量[1]。

肝保护剂包括S-腺苷-蛋氨酸（SAMe）用于谷胱甘肽补充和熊去氧胆酸（15 mg/kg每日）作为利胆剂[2]。水溶性维生素补充解决了肝病中常见的缺乏症[1]。

护理包括频繁喂食少量易消化食物，并监测诱发因素如脱水、电解质失衡或胃肠道出血[1]。环境控制包括避免高蛋白零食和管理可能引发脑病发作的压力因素。

### Sources

[1] Hepatic Encephalopathy in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-encephalopathy-in-small-animals

[2] Treatment of liver disease: Medical and nutritional aspects: https://www.dvm360.com/view/treatment-liver-disease-medical-and-nutritional-aspects-sponsored-nestle-purina

[3] Nutrition in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/nutrition-in-hepatic-disease-in-small-animals
