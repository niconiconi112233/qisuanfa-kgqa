# 伴侣动物牙齿折断

牙齿折断是小动物临床中最常见的牙科急症之一，影响10-29%的犬猫。这些创伤性损伤发生在机械力超过牙齿强度时，导致结构性损伤，范围从轻微的釉质碎片到伴有牙髓暴露的完全冠根折断。其临床意义不仅限于直接创伤，因为折断的牙齿容易受到细菌侵袭和慢性疼痛。本报告探讨了牙齿折断的综合兽医处理方法，涵盖诊断方案、从活髓治疗到手术拔牙的治疗方式以及预防策略。主要发现包括：及时进行牙髓手术成功率很高；影响犬齿和裂齿的物种特异性折断模式；以及48小时内早期干预对最佳结果的关键重要性。

## 摘要

犬猫牙齿折断呈现复杂的临床挑战，需要系统性的诊断和治疗方法。报告表明，及时干预显著改善结果，在受伤后48小时内进行活髓治疗成功率可达80%，而超过7天的延迟治疗成功率接近0%。对于有牙髓暴露的成熟牙齿，根管治疗显示出极佳的预后，成功率为94-95%。

**关键治疗考虑因素：**

| 因素 | 最佳方法 | 成功率 |
|--------|------------------|--------------|
| 新鲜牙髓暴露（<48小时，<18个月） | 活髓治疗 | 80% |
| 有牙髓暴露的成熟牙齿 | 根管治疗 | 94-95% |
| 广泛创伤/牙周病 | 手术拔牙 | 不定 |

物种特异性模式显示犬齿和上颌第四前臼齿为最高风险部位，猫由于牙髓腔延伸接近牙冠尖端而表现出特别的脆弱性。通过选择适当的咀嚼玩具和环境改造进行预防是最具成本效益的方法。定期牙科检查可实现早期发现，而向客户教育创伤识别知识可确保及时干预，以最佳保留功能性齿列。

## 疾病概述

牙齿折断是一种影响伴侣动物牙齿结构完整性的创伤性牙科疾病。当机械力超过牙齿承受应力的能力时发生，导致釉质、牙本质或两种结构断裂[1]。

在小动物临床中，10%至29%的患者和25%的工作军犬被报告有牙齿折断[1]。这使得牙科折断成为兽医医学中最常见的口腔病理之一。患病率在不同群体中有所差异，工作犬和从事高风险行为的犬只显示出更高的发生率。

美国兽医牙科学院已为兽医医学中的牙齿折断建立了标准化分类系统[2]。该系统根据解剖学累及情况和牙髓暴露对折断进行分类。关键诊断区别在于单纯性折断（无牙髓暴露）和复杂性折断（有牙髓暴露）之间，因为这决定了治疗方案和预后。

在犬中，上颌第四前臼齿（裂齿）和犬齿最容易折断[1]。在猫中，上颌犬齿和裂齿均显示出最高的折断风险[3]。猫科犬齿特别脆弱，因为牙髓腔几乎延伸至牙冠尖端[1]。了解这些物种特异性模式有助于兽医适当集中进行牙科检查和客户教育工作。

### Sources
[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[2] Examining new classifications of tooth fractures: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures
[3] Managing fractured and worn teeth (Proceedings): https://www.dvm360.com/view/managing-fractured-and-worn-teeth-proceedings

## 常见病原体

虽然牙齿折断本身不是由传染性病原体引起，但当折断使牙髓暴露于口腔环境时，继发性细菌感染必然发生[1]。牙髓腔通过折断部位被口腔细菌污染，导致牙髓炎、牙髓坏死和根尖周感染[2]。

口腔支持丰富的细菌微生物群，健康口腔中的牙菌斑细菌主要由非运动性革兰氏阳性需氧菌组成，包括葡萄球菌属和链球菌属[1]。然而，当牙菌斑变厚且氧气耗尽时，细菌种群会转向更具致病性的物种[1]。

在与牙齿折断相关的牙周病和牙髓感染病例中，常见几种致病菌：脆弱拟杆菌、消化链球菌属、牙龈卟啉单胞菌、唾液卟啉单胞菌、犬齿卟啉单胞菌、中间普雷沃菌、密螺旋体属和内脏拟杆菌[1]。厌氧菌较少被分离，但可能是骨髓炎病例中多微生物感染的一部分[3]。

暴露的牙髓为细菌增殖提供了理想环境。由于坏死牙髓组织没有血液供应，细菌可以建立持续性感染，通过根尖孔渗出，维持慢性根尖周炎症[4]。这个过程形成一个循环，其中坏死牙髓充当细菌储存库，类似于异物感染[4]。

### Sources
[1] Periodontal Disease in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[2] 2019 AAHA Dental Care Guidelines for Dogs and Cats: https://meridian.allenpress.com/jaaha/article/55/2/49/184243/2019-AAHA-Dental-Care-Guidelines-for-Dogs-and-Cats
[3] Osteomyelitis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/osteomyelitis-in-dogs-and-cats
[4] Endodontic Disease in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals

## 临床症状和体征

犬猫牙齿折断通常表现为细微的临床表现，可能掩盖显著 underlying 疼痛和病理[1]。许多有折断牙齿的患者没有表现出明显的临床体征，尽管存在慢性不适但仍保持正常食欲[2]。

**疼痛和行为表现**

当出现临床体征时，通常包括在口腔一侧咀嚼、进食时掉落食物、过度流涎、磨牙和用爪子抓脸[3]。其他行为变化可能包括拒绝接受硬质食物、零食或玩具、头部躲避行为，在某些情况下还可能出现异常攻击行为[3]。这些体征反映了动物试图避免触发暴露牙髓或受损牙齿结构的疼痛。

**物种特异性表现**

在猫中，复杂性牙冠折断需要特别关注，因为猫科犬齿的牙髓腔几乎延伸至牙冠尖端[2]。这一解剖特征使得猫犬齿的任何牙冠丢失量都高度怀疑有牙髓暴露。犬可能在创伤后出现牙齿变色，随着血液在牙本质小管内退化，从粉色变为蓝灰色，最终变为棕灰色[3]。

**品种易感性**

某些解剖易感性影响折断模式。在工作军犬中，犬齿最容易折断，而在宠物犬中，上颌第四前臼齿（裂齿）显示出更大的折断风险[2]。小型犬由于牙齿结构和咀嚼行为而表现出增加的易感性[4]。短头颅品种面临拥挤齿列带来的额外挑战，这可能造成创伤倾向条件[5]。

### Sources

[1] DVM 360 Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats

[2] DVM 360 Tooth fracture: Should you ever just "wait and see?" (Proceedings): https://www.dvm360.com/view/tooth-fracture-should-you-ever-just-wait-and-see-proceedings

[3] DVM 360 Tooth fracture: Should you ever just "wait and see?" (Proceedings): https://www.dvm360.com/view/tooth-fracture-should-you-ever-just-wait-and-see-proceedings

[4] DVM 360 Tooth eruption and exfoliation in dogs and cats: https://www.dvm360.com/view/tooth-eruption-and-exfoliation-dogs-and-cats

[5] DVM 360 Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics

## 诊断方法

准确诊断犬猫牙齿折断需要系统的方法，结合临床检查和先进的影像学技术。彻底的清醒口腔检查应作为每次体格检查的一部分，建议每12至18个月或当发现异常时进行全面的麻醉口腔检查[1]。

**临床检查技术**
临床评估从视觉检查明显的折断、变色或缺失牙齿结构开始。患有牙髓疾病的牙齿通常出现内在染色，呈现粉色、紫色、灰色、绿色或外观暗淡[2]。最明显的指征是有牙髓腔暴露的折断牙齿，如果牙髓仍然存活可能呈现为红点，如果坏死则呈现为黑洞[2]。

**牙科X线摄影**
牙科X线片提供基本诊断信息，是准确评估所必需的[1]。高质量影像需要使用分角线或平行技术进行正确定位，定位根据所拍摄的特定牙齿而有显著差异[1]。即使没有可见牙髓暴露的单纯性折断也可能显示根尖周透射区，表明存在牙髓疾病，这说明了为什么即使牙髓没有直接暴露，X线摄影也至关重要[3]。

**折断分类系统**
美国兽医牙科学院于2007年建立了基于受影响解剖结构的五类标准化分类系统[5]。这些分类有助于确定适当的治疗方法，从需要最小干预的单纯性釉质折断到需要立即牙髓治疗或拔牙的复杂性冠根折断[5]。

**先进影像学和专门检查**
锥形束计算机断层扫描（CBCT）与小动物牙科疾病综合评估相比，提供了比标准牙科X线摄影更优越的诊断能力[4]。标准头颅X线片不足；全口腔牙科X线片对于完整的口腔评估和诊断至关重要[1]。

### Sources
[1] How to obtain the best dental radiographs: https://www.dvm360.com/view/how-obtain-best-dental-radiographs
[2] Endodontic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
[3] Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[4] Evaluation of the diagnostic yield of dental radiography and cone-beam computed tomography: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[5] Examining new classifications of tooth fractures: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures

## 治疗选择

犬猫牙齿折断的治疗包括药物和非药物干预，根据折断类型和患者因素进行定制[1]。对于有牙髓暴露的复杂性牙冠折断，立即干预至关重要，对于小于18个月的患者，建议在创伤后24-48小时内进行活髓治疗[1][2]。

**牙髓手术**
根管治疗是成熟牙齿牙髓暴露或慢性折断的主要牙髓治疗方法[1][2]。该手术涉及完全去除牙髓、抗菌准备和使用X线可检测的水泥封闭[2]。最近的研究表明犬根管治疗成功率为94%[4]。活髓治疗涉及部分牙冠牙髓切除术和三氧化物凝聚体牙髓盖髓术，在犬中保持80%的成功率[4][5]。

**手术干预**
当由于严重牙周病、活动性感染或患者因素而禁止牙髓治疗时，手术拔牙仍是适应症[2]。拔牙手术需要手术瓣、牙槽骨去除和仔细的组织管理以防止并发症[6]。像犬齿和裂齿这样的战略性牙齿优先选择牙髓治疗而非拔牙[2]。

**修复选项**
粘接复合修复保护暴露的牙本质并封闭牙本质小管[3]。牙冠修复为结构受损的牙齿提供额外保护，金属牙冠表现出优异的耐用性[3]。通过多模式方案进行疼痛管理，包括非甾体抗炎药、阿片类药物和局部神经阻滞，对于治疗期间和治疗后的患者舒适至关重要[9]。

### Sources
[1] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[2] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
[3] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[4] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[5] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.pdf
[6] Extractions in cats: indications, techniques and complications (Proceedings): https://www.dvm360.com/view/extractions-cats-indications-techniques-and-complications-proceedings

## 预防措施

环境改造是伴侣动物牙齿折断预防的基石。宠物主人应实施全面的安全措施，包括移除构成折断风险的硬物，如骨头、鹿角、冰块和不适当的咀嚼玩具[1]。互动游戏应受到监督，以防止跌倒或碰撞造成的创伤。

适当的咀嚼玩具选择需要仔细考虑相对于牙齿结构的硬度。兽医应推荐专为牙科健康设计的较软替代品，如橡胶玩具，避免比牙釉质更硬的产品[1]。"拇指指甲测试"提供了实用指南--如果物体不能用指甲压出凹痕，则构成折断风险。

行为管理涉及训练宠物避免破坏性咀嚼习惯和爬栅栏，这些行为通常导致牙科创伤[1]。通过益智喂食器和适当的精神刺激进行环境丰富化可以重定向破坏性行为，同时通过自然咀嚼动作促进口腔健康[1]。

客户教育策略应强调早期识别牙科创伤体征和对疑似折断立即进行兽医咨询。定期牙科检查可以早期发现易折断的薄弱牙齿，能够在并发症发展前进行主动干预[1]。

### Sources
[1] Merck Veterinary Manual - Dentofacial Trauma in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/dentofacial-trauma-in-small-animals

## 鉴别诊断

牙齿折断必须与几种可能模拟或与折断牙齿共存的情况进行区分。牙齿吸收是最重要的鉴别诊断，影响高达75%的猫和53.6%的犬在其一生中[1]。吸收性病变表现为矿化牙组织进行性丧失，从釉牙骨质界开始并向冠方延伸。

与折断不同，吸收病变显示特征性的X线影像模式，包括2型病变中的牙周韧带间隙狭窄或1型病变中的局灶性透射区[2]。犬的外部炎性吸收通常影响前臼齿和臼齿，而猫通常发展为替代性吸收。

釉质发育不全表现为发育性缺陷，具有粗糙、凹坑表面，可能类似于折断的釉质[3]。然而，发育不全对称地影响多个牙齿，并且是由于釉质形成过程中的发育性损害引起的，通常发生在有发热或全身疾病的幼年动物中。

牙科磨损和磨耗导致渐进性牙齿磨损而非急性结构丧失[4]。磨损由外部力量如过度咀嚼引起，而磨耗源于错颌病例中的牙齿与牙齿接触。

鉴别特征包括创伤的折断史、折断中的锐利釉质边缘与磨损/磨耗中的光滑磨损表面，以及复杂性折断中的牙髓暴露X线证据。牙科X线片对于准确鉴别和治疗计划制定仍然必不可少。

### Sources

[1] Classifying tooth resorption in cats and dogs: https://www.dvm360.com/view/classifying-tooth-resorption-in-cats-and-dogs
[2] Tooth Resorption in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals
[3] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
[4] Recognizing dental and oral abnormalities: https://www.dvm360.com/view/recognizing-dental-and-oral-abnormalities

## 预后

犬猫牙齿折断的预后根据折断类型、治疗方式和干预时机而有显著差异。活髓治疗和根管治疗在适当应用时均显示出高成功率[1]。

对于活髓治疗，成功率取决于时间和年龄。最佳结果发生在小于18个月动物的牙髓暴露后48小时内进行，报告成功率约为80%[1][2]。当治疗延迟超过7天时，成功率急剧下降，接近0%[3]。

根管治疗显示出优异的长期预后，在兽医患者中报告的成功率为94-95%[3][4]。然而，治疗后可能发生自发性牙齿折断等并发症，特别是在上颌第四前臼齿中[2]。

对预后产生负面影响的因素包括晚期牙周病、广泛创伤、延迟治疗和患者年龄。并发牙周-牙髓病变的预后谨慎[8]。长期并发症可能包括牙齿吸收、继发性牙周病和可能需要拔牙[3]。

生活质量考虑在可行情况下倾向于保牙手术而非拔牙。功能性牙齿如犬齿和上颌第四前臼齿由于其正常口腔功能的重要性而成为挽救优先考虑的对象[7]。每6-12个月定期X线监测对于检测治疗失败或并发症至关重要[3]。

### Sources

[1] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[2] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.pdf
[3] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[4] Radiographic outcome of root canal treatment in dogs: https://avmajournals.avma.org/view/journals/javma/260/5/javma.21.03.0127.xml
[5] Six common pitfalls in veterinary dentistry and how to avoid them: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them
[6] Vital pulp therapy in dogs: 190 cases (2001-2011): https://avmajournals.avma.org/view/journals/javma/244/4/javma.244.4.449.xml
[7] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[8] Vital pulpotomy, root canal therapy, avulsion, luxation: https://www.dvm360.com/view/vital-pulpotomy-root-canal-therapy-avulsion-luxation-proceedings
