# 阻塞性猫特发性膀胱炎：猫医学中的临床急症

阻塞性猫特发性膀胱炎是小动物临床中最为危急的急症之一，主要影响年轻公猫，需要立即干预以防止危及生命的并发症。当尿道栓子或痉挛完全阻塞尿液流动时，这种疾病从可控制的下泌尿道疾病转变为医疗危机，导致高钾血症、氮质血症和代谢性酸中毒的迅速发展。本报告探讨了阻塞性FIC的综合管理方法，从紧急稳定方案和导尿技术到使用多模式环境改造的长期预防策略。内容综合了当前兽医知识中关于病理生理学、诊断方法、治疗方案和预后因素，这些因素影响着患病猫的即时生存率和长期复发率。

## 摘要

阻塞性猫特发性膀胱炎需要一种结合紧急稳定、确定性治疗和长期预防策略的综合方法。该疾病主要影响年轻去势公猫，即时危及生命的并发症包括高钾血症（占病例的12%）和严重氮质血症，在尝试导尿前需要快速纠正。紧急管理方案强调减压性膀胱穿刺术、使用葡萄糖酸钙和葡萄糖-胰岛素疗法进行代谢稳定，随后进行温和的尿道导尿术并持续生理盐水冲洗。

| 管理阶段 | 关键干预措施 | 关键监测 |
|------------------|-------------------|-------------------|
| 紧急稳定 | 静脉导管，葡萄糖酸钙治疗高钾血症，减压性膀胱穿刺术 | 心电图监测心律失常，电解质，血液生化 |
| 导尿 | 软质5Fr导尿管，大量生理盐水冲洗，无菌技术 | 尿道创伤，成功减压 |
| 术后梗阻管理 | 解痉药，利尿匹配液体，疼痛管理 | 术后梗阻利尿（占病例的46%） |
| 预防 | MEMO方案，湿粮过渡，减压 | 复发率（14-57%） |

尽管生存率极佳（90-95%），主要挑战在于预防复发，超过50%的猫在一年内经历重复发作。多模式环境改造仍然是长期管理的基石，强调减压、有利于湿粮的饮食调整和全面的环境丰富化。兽医必须优先快速识别和积极早期干预，同时实施持续的预防方案，以优化患病猫的长期结果。

## 疾病概述

阻塞性猫特发性膀胱炎（FIC）是一种危及生命的疾病，代表猫下泌尿道疾病（FLUTD）的梗阻形式[1]。FIC被定义为一种无菌性、炎症性膀胱疾病，主要影响10岁以下的猫，约60-70%有下泌尿道症状的年轻猫没有特定的可识别原因[1]。

这种疾病几乎仅发生在公猫身上，因为它们的尿道直径狭窄，这使它们容易因尿道栓子或含有血清蛋白、晶体、细胞和碎屑的粘液而阻塞[2]。该疾病影响1.5%接受初级保健兽医诊治的猫，是年轻猫FLUTD的最常见诊断[1]。

关键流行病学风险因素包括2-6岁的去势公猫，波斯猫和喜马拉雅猫品种显示易感性增加[1]。其他风险因素包括室内生活方式、肥胖、活动减少、多猫家庭、纯干粮饮食和环境压力源[1]。该疾病似乎是一种现代疾病，最早在1990年代初被认识，自1980年以来频率下降与配方的改进相平行[2]。

### Sources

[1] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings

[2] Management of urethral obstruction in cats: https://www.dvm360.com/view/management-urethral-obstruction-cats-proceedings

## 病理生理学和临床表现

阻塞性猫特发性膀胱炎（FIC）涉及导致尿道阻塞和全身并发症的复杂机制[1]。尿道栓子是最常见的阻塞原因，由含有血清蛋白、晶体（主要是鸟粪石）、细胞和碎屑的蛋白质基质组成[1]。下泌尿道炎症先于栓子形成，血浆蛋白通过尿道下血管渗漏进入尿液[3]。

病理生理学涉及交感神经系统反应过度，儿茶酚胺释放增加和皮质醇反应减少[1]。这种炎症级联反应增加膀胱通透性，允许尿液成分进入膀胱黏膜下层并持续炎症[1]。功能性阻塞也可能通过特发性尿道痉挛发生，其中神经源性或肌源性过程引起尿道肌肉收缩，与物理阻塞无关[1]。

临床进展通常始于非梗阻性症状，包括排尿困难、尿频、血尿和异位排尿[2]。当基质栓子在狭窄的阴茎尿道中形成时，公猫可能发展为完全尿道阻塞[2]。尿道基质栓子可能在雌猫和非梗阻性公猫中开始形成，但会顺利通过而不滞留[2]。

完全阻塞后，全身并发症迅速发展。肾后性氮质血症由于管内压力增加和肾小球滤过率降低而发生[4]。高钾血症在约12%的病例中发展，从轻度到危及生命的水平，引起心律失常和心动过缓[5]。其他并发症包括代谢性酸中毒、低钙血症和导尿后的术后梗阻利尿[5]。

### Sources
[1] Disorders of Micturition in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/disorders-of-micturition-in-dogs-and-cats
[2] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[3] Management of male cats with urethral obstruction: https://www.dvm360.com/view/management-male-cats-with-urethral-obstruction-proceedings
[4] Urethral Obstruction in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urethral-obstruction-in-small-animals
[5] Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction

## 诊断方法和鉴别诊断

尿道阻塞的猫需要立即紧急评估，因为阻塞48小时以上的猫可能病情严重并需要危机管理[1]。体格检查应侧重于检测电解质异常引起的心血管损害迹象。严重心动过缓发生在5%的病例中，低体温和心动过缓对严重高钾血症的预测性为98-100%[3]。

实验室评估必须包括血液生化面板以评估危及生命的并发症。需要纠正的常见异常包括氮质血症、高钾血症（约12%的病例中出现[4]）、代谢性酸中毒和低钙血症[1]。高钾血症可能危及生命，是尿道阻塞的常见并发症[5]。严重尿道阻塞的猫通常表现为严重氮质血症（中位血清肌酐>17 mg/dL）、代谢性酸中毒和高钾血症[2]。

X线平片对于检测不透射线的尿石和评估膀胱大小非常有用，而系列超声检查提供额外的诊断信息[2]。在一项研究中，X线和超声结合在90%的患病猫中检测到输尿管结石[2]。

关键鉴别诊断包括尿石症、尿道狭窄和肿瘤。虽然只有18%的尿道阻塞涉及尿道栓子，但其他原因包括尿道结石、尿道痉挛、创伤、先天性缺陷和肿瘤[3]。年轻猫下泌尿道疾病的鉴别诊断包括特发性膀胱炎（最常见）、尿石症、细菌性尿路感染和肿瘤[6]。

紧急稳定包括立即放置静脉导管、液体治疗和在尝试解除阻塞前纠正代谢异常[3]。应进行减压性膀胱穿刺术以缓解膀胱压力并促进随后的导尿尝试[1][3]。

### Sources
[1] Management of urethral obstruction in cats (Proceedings): https://www.dvm360.com/view/management-urethral-obstruction-cats-proceedings
[2] Acute ureteral obstruction (Proceedings): https://www.dvm360.com/view/acute-ureteral-obstruction-proceedings
[3] Managing urethral obstruction in male cats (Proceedings): https://www.dvm360.com/view/managing-urethral-obstruction-male-cats-proceedings
[4] Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction
[5] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[6] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0

## 紧急治疗和管理

出现尿道阻塞的猫需要立即紧急稳定，因为危及生命的并发症发展迅速[1]。初始稳定侧重于在尝试尿道导尿前处理代谢紊乱。静脉导管放置对于液体给药和药物输送至关重要[1][2]。

关键稳定包括处理高钾血症，这种情况发生在约12%的阻塞猫中，可从临床无关紧要到致命[3]。严重高钾血症（>7.5-8.0 mEq/L）需要立即静脉注射葡萄糖酸钙（0.5-1.5 mL/kg，20分钟以上），并进行心电图监测以对抗心脏毒性作用[2][6]。其他降低钾的治疗包括葡萄糖（1 mL/kg 50%葡萄糖1:4稀释静脉注射）和常规胰岛素（0.25 U/kg静脉注射）以促进细胞内钾转移[6]。

减压性膀胱穿刺术在初始稳定后进行，以缓解膀胱压力并促进随后的导尿[1][2]。尿道导尿使用无菌技术和大量生理盐水冲洗以清除阻塞物质[1][5]。软质留置导管（5Fr红橡胶）优于刚性聚丙烯导管，以减少尿道创伤，并使用封闭收集系统维持[1][5]。

术后梗阻管理包括监测利尿，这种情况发生在46%的猫中，可导致显著的液体丢失，需要仔细的液体速率匹配[2][3]。使用乙酰丙嗪、哌唑嗪或酚苄明进行解痉治疗可防止尿道痉挛引起的再阻塞[1][2]。治疗继续使用镇痛药、过渡到湿粮和减压措施[2][5]。

### Sources
[1] Management of urethral obstruction in cats (Proceedings): https://www.dvm360.com/view/management-urethral-obstruction-cats-proceedings
[2] Managing urethral obstruction in male cats (Proceedings): https://www.dvm360.com/view/managing-urethral-obstruction-male-cats-proceedings
[3] Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction
[4] Renal and cardiorespiratory effects of treatment with lactated: https://avmajournals.avma.org/view/journals/ajvr/71/7/ajvr.71.7.840.xml
[5] Urethral obstruction in cats: catheters and complications: https://www.dvm360.com/view/urethral-obstruction-cats-catheters-and-complications-proceedings-1
[6] Merck Veterinary Manual Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats

## 预防和长期管理

阻塞性猫特发性膀胱炎的长期预防需要针对减压、饮食调整和环境管理的综合多模式方法。多模式环境改造（MEMO）代表预防的基石，侧重于实施改变以减少激活应激反应系统的环境压力源[1]。MEMO包括提供遵循健康猫环境五大支柱的充足资源：安全领地、多个资源位置、积极的人猫互动、尊重猫的感觉以及玩耍和捕食行为的机会[2]。

饮食管理在预防复发中起着关键作用。增加饮水量以促进尿比重降低是一个关键治疗目标，最好通过饲喂罐装泌尿道饮食而非干粮来实现[4]。这种方法有助于降低尿液浓度和过饱和度，减少尿道栓子形成的风险[6]。

通过合成猫面部信息素和环境丰富化进行减压在管理FIC复发方面显示出前景[2]。体重管理至关重要，因为肥胖是FIC发作的重要风险因素[4]。

尿道松弛剂可用于预防易再阻塞的猫。α-肾上腺素能拮抗剂如酚苄明或哌唑嗪可以帮助降低尿道平滑肌张力，尽管最近的研究表明哌唑嗪实际上可能增加再阻塞率[8]。解痉药物如乙酰丙嗪可能对管理尿道痉挛有益[6]。

对于复发性机械性阻塞的猫，应考虑会阴尿道造口术作为最后手段，尽管它不能解决潜在的FIC病理生理学，并发症包括狭窄形成和感染风险增加[6]。

### Sources
[1] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[2] Nonobstructive idiopathic feline lower urinary tract disease: https://www.dvm360.com/view/nonobstructive-idiopathic-feline-lower-urinary-tract-disease-how-approach-puzzling-disorder
[3] Feline interstitial cystitis: Its not about the bladder: https://www.dvm360.com/view/feline-interstitial-cystitis-it-s-not-about-bladder
[4] Feline idiopathic cystitis: https://www.dvm360.com/view/feline-idiopathic-cystitis
[5] Management of cats with urethral obstruction (Proceedings): https://www.dvm360.com/view/management-cats-with-urethral-obstruction-proceedings
[6] Prazosin administration increases the rate of recurrent urethral: https://avmajournals.avma.org/view/journals/javma/260/S2/javma.21.10.0469.xml

## 预后和并发症

当及时开始适当治疗时，阻塞性猫特发性膀胱炎的总体预后通常良好。尿道阻塞猫的生存率很高，研究报告适当治疗时生存率为90-95%[1]。然而，在某些病例中记录了约16%的死亡率[3]。

短期结果通常良好，近94%的患病猫在初始治疗后存活并出院[3]。主要的预后挑战在于高复发率。超过50%的特发性膀胱炎猫将在一年内经历复发性临床症状[2]。对于尿道阻塞的猫，复发率在14-57%之间，研究表明36%的猫在中位17天后再次阻塞[3,6]。

几个因素影响预后，包括年龄，老年猫复发性尿道阻塞的可能性显著更高[5]。影响长期结果的并发症包括再阻塞、膀胱无张力、尿道狭窄形成（发生在11%的病例中）和潜在的细菌性尿路感染发展[3,6]。术后梗阻利尿、脱水、氮质血症和电解质失衡代表需要仔细监测的急性并发症[6]。

通过适当的多模式环境改造和持续管理，约80%的猫在复发性症状上显示出临床显著改善[2]。

### Sources
[1] Feline urethral obstruction alters the urinary microbiota and: https://avmajournals.avma.org/view/journals/ajvr/86/2/ajvr.24.07.0213.xml
[2] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[3] Managing urethral obstruction in male cats (Proceedings): https://www.dvm360.com/view/managing-urethral-obstruction-male-cats-proceedings
[4] Dysuria and stranguria in a 2-year-old neutered male cat: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.05.0321/javma.25.05.0321.xml
[5] Evaluation of risk factors associated with recurrent obstruction: https://avmajournals.avma.org/view/journals/javma/243/8/javma.243.8.1140.xml
[6] Unblock that cat, STAT!: https://www.dvm360.com/view/unblock-cat-stat
