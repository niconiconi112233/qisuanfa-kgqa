# 伴侣动物的昆虫和蛛形纲动物超敏反应

昆虫和蛛形纲动物超敏反应是犬猫中一个重要的皮肤科问题，引起剧烈瘙痒和继发并发症，显著影响生活质量。这种情况是由节肢动物叮咬时引入的唾液蛋白和其他过敏原引起的过敏反应所致，其中跳蚤（*Ctenocephalides*属）、蜱虫、蚊子和叮咬蝇是主要传播媒介。

本报告探讨了涉及速发和迟发性超敏反应的复杂病理生理学，从局限性皮炎到全身性湿疹性皮疹的独特临床表现，以及包括皮内测试和血清IgE分析在内的综合诊断方法。治疗策略包括药物干预、环境控制措施和长期免疫治疗方案，而预防则侧重于综合害虫管理和全年寄生虫控制计划。

## 常见病原体和节肢动物传播媒介

引起伴侣动物超敏反应的主要节肢动物传播媒介包括几种具有不同生物学特征和季节模式的关键物种。跳蚤，特别是*猫栉首蚤*（猫蚤），是最重要的传播媒介，无论宿主特异性如何，都会影响犬猫[1]。这些无翅昆虫在最佳条件（80°F，80%相对湿度）下2-3周内完成其复杂的生活周期，成虫从茧中的出现受到潜在宿主的热量、压力和二氧化碳的刺激[2]。

*犬栉首蚤*、*禽角头蚤*和*相似蚤*是可能引起超敏反应的较不常见的跳蚤种类[2]。雌性跳蚤是 prolific 的产卵者，平均每天产27个卵，50天内最多产1,350个卵，卵的孵化在1-10天内发生，取决于温度和湿度条件[2]。

蜱虫是第二重要的节肢动物类群，其中硬蜱（硬蜱科）是主要传播媒介。重要种类包括*血红扇头蜱*（棕色狗蜱）、*肩突硬蜱*（黑腿蜱）、*变异革蜱*（美国狗蜱）和*美洲花蜱*[2]。影响伴侣动物的大多数蜱虫种类是三宿主蜱，在每个发育阶段利用不同的宿主物种，但*血红扇头蜱*独特地在整个生命周期中寄生在犬身上[2]。

蚊子作为节肢动物传播媒介带来额外关注，其中*库蠓*属与超敏反应反应特别相关[3]。这些叮咬蠓通过唾液蛋白引起显著的瘙痒反应，在敏感动物中触发速发和迟发性超敏反应。虽然提供的资料主要关注马科病例，但类似机制也影响伴侣动物。

### Sources

[1] Another itchy cat, now what (Proceedings): https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings
[2] Managing fleas, ticks and vector-borne diseases (Proceedings): https://www.dvm360.com/view/managing-fleas-ticks-and-vector-borne-diseases-proceedings
[3] Approach to the pruritic horse in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.10.0444.xml

## 临床症状和体征

犬猫的昆虫和蛛形纲动物超敏反应表现出独特的瘙痒模式和病变分布，每个物种各不相同。**在犬中，跳蚤过敏性皮炎表现为剧烈瘙痒，主要影响背腰骶区、尾根和后大腿**[1]。典型病变包括丘疹鳞屑性皮疹、红斑、抓痕和继发性脱毛，在慢性病例中常进展为苔藓化和色素沉着[1]。

**猫表现出不同的表现模式**，通常在面部、颈部和背部发展粟粒状皮炎，而不是局限性病变[1]。猫科患者可能出现嗜酸性斑块、惰性溃疡或因过度梳理引起的双侧对称性脱毛[3]。粟粒状病变代表全身性过敏反应，而不是直接叮咬部位，导致全身性瘙痒和湿疹性皮疹[1]。

**继发并发症在两个物种中都很常见**。犬经常在受影响区域发展细菌性脓皮症，特别是腹股沟和腹部区域[5]。严重超敏反应的动物可能发展创伤性湿性皮炎（"热点"）[1]。两个物种都可能表现为复发性外耳炎作为过敏性疾病的表现[7]。

**非典型表现包括蚊子叮咬超敏反应**，在犬中表现为面部和头部的嗜酸性毛囊炎，而猫在面部区域和脚垫上发展严重瘙痒的丘疹性皮疹[2]。物种特异性因素影响严重程度，极高度超敏反应的动物因过度自我梳理常显示极少的寄生虫证据，使诊断更具挑战性[1]。

### Sources
[1] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[2] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[3] A clinical approach to feline atopic dermatitis: https://www.dvm360.com/view/a-clinical-approach-to-feline-atopic-dermatitis/1000
[4] Dermatological Problems in Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals
[5] Flea allergy dermatitis: What's new?: https://www.dvm360.com/view/flea-allergy-dermatitis-whats-new-proceedings
[6] Differential diagnoses for the itchy and scratchy: https://www.dvm360.com/view/differential-diagnoses-itchy-and-scratchy-proceedings
[7] Canine Atopic Dermatitis: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis

## 诊断方法

昆虫和蛛形纲动物超敏反应的诊断依赖于结合临床病史、体格检查结果和过敏测试方法的系统方法[1]。第一个关键步骤是建立详细病史，记录暴露于特定昆虫或蛛形纲动物与临床症状出现之间的时间关系，包括季节性模式和环境因素[2]。

体格检查侧重于识别与昆虫叮咬超敏反应一致的分布模式，这种模式通常影响毛发稀疏区域，如面部、耳朵和腹部腹侧[3]。在某些涉及蛛形纲动物的病例中，耳廓-足爪反射可能呈阳性，但这并非对所有昆虫超敏反应都具有特异性[4]。

皮内皮肤测试仍然是兽医皮肤科医生进行的传统诊断方法，对识别特定昆虫和蛛形纲动物过敏原的反应具有高敏感性和特异性[1]。这种测试需要患者准备，包括停用皮质类固醇至少30天和抗组胺药5-7天[2]。阳性速发反应的特征是风团直径比阴性对照大3-5毫米，建议观察速发（15-20分钟）和迟发（24小时）反应[5]。

血清IgE测试（ELISA/液相）提供了一种替代诊断方法，通过简单的血液抽血提供便利，无需镇静或剃毛[2][4]。两种测试模式都应将阳性反应与患者的临床病史和暴露模式相关联，以进行有意义的解释[2]。与跳蚤过敏性皮炎一样，使用1:1000浓度过敏原溶液进行的皮内跳蚤测试在超过75%的受试猫中提供速发反应，伴有风团和潮红反应[6]。

### Sources
[1] Allergy specific immunotherapy: how to maximize the results: https://www.dvm360.com/view/allergy-specific-immunotherapy-how-maximize-results-proceedings
[2] Update on canine atopy: Diagnosis and management: https://www.dvm360.com/view/update-canine-atopy-diagnosis-and-management-proceedings
[3] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[4] Differential diagnoses for the itchy and scratchy: https://www.dvm360.com/view/differential-diagnoses-itchy-and-scratchy-proceedings
[5] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[6] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings

## 治疗选择

昆虫和蛛形纲动物超敏反应的治疗需要一种综合方法，既针对即时症状缓解，又针对长期管理[1]。糖皮质激素仍然是控制瘙痒最有效的一线疗法，泼尼松或泼尼松龙以0.5-1.0 mg/kg每日一次使用3-10天，然后隔日治疗[3]。注射用醋酸甲泼尼龙可用于猫，但皮下给药可能引起结节[5]。

抗组胺药作为单一药物效果有限，但可作为皮质类固醇或免疫治疗的辅助治疗[1]。局部治疗起着关键作用，使用含有胶体燕麦、普拉莫辛或曲安奈德（0.015%）等成分的药用洗发水频繁洗澡，提供抗瘙痒效果[4]。

环孢素提供了一种有效的类固醇节约替代方案，犬每日5-10 mg/kg，猫每日25 mg，尽管最大益处可能需要4-8周[1,5]。必需脂肪酸很少提供单一控制，但作为辅助治疗可能有益[6]。

体外寄生虫控制是基础，最初每14天使用一次含有吡虫啉、氟虫腈、塞拉菌素或新型异噁唑啉类产品[5,10]。使用适当的抗生素（阿莫西林-克拉维酸、头孢氨苄）治疗继发性细菌感染2-4周是必不可少的[5]。过敏原特异性免疫治疗为特应性动物提供长期管理，大约75%的动物在治疗数月后显示瘙痒减轻[1]。

### Sources

[1] Multi-facet approach offers best results for allergy patients: https://www.dvm360.com/view/multi-facet-approach-offers-best-results-allergy-patients
[2] A systematic review of allergen immunotherapy, a successful ...: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0576.xml
[3] Autoimmune diseases (Proceedings): https://www.dvm360.com/view/autoimmune-diseases-proceedings
[4] The role of topical therapy in the successful treatment ...: https://www.dvm360.com/view/role-topical-therapy-successful-treatment-allergic-dermatitis
[5] Itchy cat: Don't want that! (Proceedings): https://www.dvm360.com/view/itchy-cat-dont-want-proceedings
[6] Dermatological Problems in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

## 预防措施

有效预防犬猫的昆虫和蛛形纲动物超敏反应需要全面的环境管理和综合害虫控制策略[1]。全年跳蚤控制计划至关重要，因为跳蚤即使在冬季也能在室内生存[3]。伴侣动物寄生虫理事会建议持续进行寄生虫预防，以保护宠物免受体外寄生虫和相关超敏反应的影响[1]。

环境控制是预防的基石。定期吸尘地毯、清洗宠物寝具和保持湿度水平低于50%有助于破坏跳蚤生命周期[1]。同时治疗所有家庭宠物可防止再次感染，因为未经治疗的动物会成为持续的寄生虫来源[2]。

局部驱虫剂和全身性预防剂提供针对多种节肢动物的有效保护。含有吡虫啉、氟虫腈或塞拉菌素的产品提供针对跳蚤的残留活性，同时提供更广谱的控制[3,5]。含有吡虫啉和氟氯苯菊酯的Seresto项圈提供长达8个月的保护，在蜱虫滋生的环境中特别有价值[3]。

综合害虫管理结合多种方法以获得最佳结果。这包括使用昆虫生长调节剂如烯虫酯或吡丙醚进行场所处理、定期梳理以早期发现寄生虫以及环境改造以减少节肢动物栖息地[5]。室内猫需要保护，因为跳蚤可以通过衣物或其他宠物进入家中[2]。

### Sources
[1] Fleas: Fables, facts, and proven solutions (Sponsored by Merial): https://www.dvm360.com/view/fleas-fables-facts-and-proven-solutions-sponsored-merial
[2] New strategies for successful feline parasite control: https://www.dvm360.com/view/new-strategies-successful-feline-parasite-control
[3] Fighting fleas: An update on preventive options: https://www.dvm360.com/view/fighting-fleas-an-update-on-preventive-options
[4] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[5] Fleas be gone: Current treatment strategies (Proceedings): https://www.dvm360.com/view/fleas-be-gone-current-treatment-strategies-proceedings

## 鉴别诊断

在将昆虫和蛛形纲动物超敏反应与其他瘙痒性皮肤病区分开来时，必须系统地考虑几个关键疾病。最重要的鉴别诊断包括特应性皮炎、食物过敏、跳蚤过敏性皮炎、接触性皮炎和其他体外寄生虫疾病[1]。

特应性皮炎是主要的鉴别诊断，因为它具有相似的瘙痒模式，并且可能表现为影响耳朵、脚爪和腋窝的腹侧分布[1]。然而，特应性皮炎通常在1-3岁之间发展，具有品种易感性，而昆虫超敏反应常与季节性户外暴露相关[1]。

必须通过饮食排除试验排除食物过敏，特别是当面部瘙痒突出时[2]。与昆虫超敏反应不同，食物过敏表现为非季节性瘙痒，可能包括胃肠道症状[2]。犬中最常见的食物过敏原包括牛肉、乳制品、鸡肉和小麦，而猫主要对牛肉、鱼和鸡肉产生反应[4]。

跳蚤过敏性皮炎需要仔细区分，特别是因为两种疾病都涉及节肢动物超敏反应[7]。跳蚤过敏性犬通常显示背侧尾部和股内侧受累，而猫表现为粟粒状皮炎[7]。重要的是，超敏反应动物可能因过度梳理而几乎没有跳蚤[7]。

接触性皮炎发生在过敏原接触皮肤的部位，特别是毛发稀疏区域，但由于保护性毛发覆盖，在小动物中仍然罕见[10]。其他体外寄生虫疾病包括疥螨病、蠕形螨病和啮螨病必须通过适当的皮肤刮片和诊断测试排除[1][7]。

### Sources

[1] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings
[2] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings
[4] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[7] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[10] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
