# 伴侣动物的遗传性白内障

## 疾病概述

遗传性白内障是遗传性晶状体混浊，是犬和猫视力损害的重要原因。这些遗传性疾病影响超过60个犬种，其发病率高于基线水平，包括美国可卡犬、波士顿梗、玩具贵宾犬、西伯利亚哈士奇和迷你雪纳瑞（默克兽医手册，2024年）。大多数遗传性白内障遵循常染色体隐性遗传模式，通常在成年早期动物中表现，并在几年内缓慢双侧进展。

**流行病学背景**
该疾病表现出强烈的品种易感性和独特的遗传模式。在犬中，遗传性白内障通常影响成年犬，并随时间缓慢进展，而猫科动物中报告的大多数病例发生在幼年动物中（DVM360，2024年）。不同品种之间的患病率差异显著，由于集中繁育实践，某些品系的发病率较高。通过基因筛查计划进行早期检测已成为负责任繁育实践和受影响品种群体健康管理的关键。

## 常见病原体

犬和猫的遗传性白内障主要是遗传性疾病，不是由传染性病原体引起的。然而，某些传染性因子可通过眼部炎症和晶状体损伤导致继发性白内障形成 [1]。

**导致白内障的传染性原因：**
虽然遗传性白内障本身不具有传染性，但传染性疾病引起的葡萄膜炎可导致晶状体诱导的并发症。在猫中，猫疱疹病毒-1（FHV-1）影响超过90%的猫，可引起角膜疾病和葡萄膜炎，可能导致继发性晶状体变化 [3]。猫衣原体和支原体也是猫结膜炎和眼部炎症的常见原因 [2]。

**全身性传染性疾病：**
各种全身性病原体可引起葡萄膜炎，可能影响晶状体透明度。这些包括细菌感染（巴尔通体、伯氏疏螺旋体、犬布鲁氏菌）、立克次体病（埃里希体、立克次体）、真菌生物（芽生菌、组织胞浆菌、隐球菌）和原生动物寄生虫（弓形虫、新孢子虫）[4]。这些感染占葡萄膜炎原因的17.6%，可能导致继发性晶状体并发症 [1]。

**重要提示：**
真正的遗传性白内障是由遗传因素引起，而非传染性因子所致。上述提到的病原体导致继发性眼部并发症，可能影响晶状体健康，但它们本身不会引起原发性遗传性白内障。

### Sources
[1] Veterinary ophthalmology for the technician (Proceedings): https://www.dvm360.com/view/veterinary-ophthalmology-technician-proceedings
[2] Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases
[3] Ocular manifestations of systemic disease--when the eye is not the primary disease (Proceedings): https://www.dvm360.com/view/ocular-manifestations-systemic-disease-when-eye-not-primary-disease-proceedings
[4] Ophthalmic Manifestations of Systemic Diseases in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/ophthalmic-manifestations-of-systemic-diseases-in-animals

## 临床症状和体征

遗传性白内障表现出独特的临床特征，因品种和进展阶段而异 [1]。大多数患有白内障的宠物被送医是因为主人注意到行为变化，例如撞到家具或在行走时表现出不寻常的犹豫 [1]。

**典型表现**

早期白内障呈现为白色碎冰块状，在晶状体内大小、形状和混浊程度各异 [1]。初期白内障占晶状体体积不足15%，可能不会显著影响视力 [1][2]。未成熟白内障表现为晶状体部分混浊，可见眼毯反射，而成熟白内障涉及整个晶状体结构，完全阻挡眼毯反射 [1][2]。

晚期白内障通常引起晶状体诱导性葡萄膜炎，特征为眼睑痉挛、结膜充血、瞳孔缩小和房水闪辉 [1]。过熟白内障可能显示小折射晶体、囊下斑块、前房深度增加和晶状体诱导性炎症的证据 [1]。

**品种特异性模式**

遗传性白内障表现出强烈的品种易感性，超过60个品种的发病率高于基线水平 [1]。常见受影响的品种包括美国可卡犬、波士顿梗、玩具贵宾犬、西伯利亚哈士奇和迷你雪纳瑞 [1][3]。在犬中，遗传性白内障通常遵循常染色体隐性遗传，影响成年早期动物，在几年内缓慢双侧进展 [1][2][3]。猫科动物中报告的大多数遗传性白内障发生在幼年动物，而马的白内障通常是继发于前葡萄膜炎 [2]。

### Sources
[1] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[2] The Lens in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
[3] Disorders of the Lens in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-lens-in-dogs

## 诊断方法

犬和猫遗传性白内障的诊断依赖于全面的眼科检查技术结合临床评估。基本诊断设备包括透照器、直接检眼镜、荧光素染料、希氏泪液测试仪、眼压计和放大镜 [1]。

**临床检查**
检查始于使用局部托吡卡胺（1%）进行瞳孔扩张，在15分钟内达到充分散瞳 [2]。使用裂隙灯评估的逆反射技术是表征晶状体变化的金标准。当存在遗传性白内障时，反射光被不同程度地阻挡，初期和未成熟白内障在眼毯反射背景下呈现棕色或黑色 [2]。

**生物显微镜技术**
五种基本生物显微镜技术有助于诊断：弥散照明、逆反射、直接照明、光学切面和镜面反射 [1][3]。直接检眼镜上的裂隙光束功能特别有价值，显示白内障为晶状体光束之间的明显混浊，而核硬化表现为雾度增加 [4]。

**鉴别诊断**
区分遗传性白内障和核硬化需要仔细评估。白内障呈现为白色块状，混浊程度不一，而核硬化呈现为均匀、珍珠状混浊，带有灰蓝色调 [2]。年龄和视力状态提供额外的诊断线索，因为8-10岁以上且没有明显视力缺陷的动物更可能患有核硬化 [2]。

### Sources
[1] Ocular examination techniques for private practitioners: https://www.dvm360.com/view/ocular-examination-techniques-private-practitioners-proceedings
[2] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[3] Getting ready for the eye patient: https://www.dvm360.com/view/getting-ready-eye-patient-and-earn-raise-proceedings-0
[4] Differentiating nuclear sclerosis from early cataracts: https://www.dvm360.com/view/differentiating-nuclear-sclerosis-from-early-cataracts-during-an-ophthalmic-exam

## 治疗选择

遗传性白内障的治疗侧重于两种主要方法：晶状体诱导性葡萄膜炎的药物管理和通过超声乳化术进行手术干预。所有晚期白内障都会引起晶状体诱导性葡萄膜炎（LIU），因为晶状体蛋白通过晶状体囊泄漏，免疫系统将其识别为外来抗原 [1]。这种炎症必须使用皮质类固醇或非甾体抗炎药的局部抗炎治疗进行控制，即使手术将被推迟 [1]。

超声乳化术代表了白内障摘除的金标准手术技术 [1][2]。该手术使用超声波技术通过小角膜切口破碎混浊的晶状体，同时保持眼球完整性 [1]。该技术允许通过小于5毫米的切口摘除晶状体，同时进行灌流、超声乳化和抽吸 [2]。晶状体摘除后，使用41.5屈光度镜片为犬和53屈光度为猫植入人工晶状体（IOL）[2][4]。

术后护理包括密集的局部抗炎药物治疗，以控制葡萄膜炎并预防并发症 [4]。早期进行时成功率可达90-95%，过熟白内障由于并发症风险增加而成功率降低 [1][3]。常见并发症包括24小时内术后眼压升高、青光眼（风险低于10%）和视网膜脱离 [1][4]。长期监测对于检测晚期并发症如青光眼或后囊混浊至关重要。

### Sources

[1] Cataract surgery in veterinary medicine today (Proceedings): https://www.dvm360.com/view/cataract-surgery-veterinary-medicine-today-proceedings
[2] Managing diseases of the lens-clarification of a cloudy type (Proceedings): https://www.dvm360.com/view/managing-diseases-lens-clarification-cloudy-type-proceedings
[3] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[4] Update on cataract surgery (Proceedings): https://www.dvm360.com/view/update-cataract-surgery-proceedings

## 预防措施

基因筛查计划构成了犬和猫遗传性白内障预防的基石。繁育动物应经过委员会认证的兽医眼科医生进行全面的眼科检查，并在纳入繁育计划前明确记录晶状体状态 [1]。许多受影响的品种已通过美国兽医眼科学会等组织建立了基因检测方案。

负责任的繁育实践要求将患有遗传性白内障的动物排除在繁育计划之外，因为大多数形式遵循常染色体隐性遗传模式 [2]。繁育者应保持详细的眼科健康记录，并与兽医眼科医生合作识别携带者动物。连续检查至关重要，因为某些遗传形式可能直到数岁才表现出来。

环境管理侧重于最小化继发性风险因素。通过适当的住房和运动管理防止创伤可减少获得性白内障的发展 [3]。及时治疗糖尿病、葡萄膜炎和眼外伤等易感条件有助于预防继发性白内障形成。

主人教育强调定期兽医眼科检查的重要性，特别是在高风险品种中。早期检测允许更好的手术计划并在需要干预时改善结果 [2]。遗传咨询帮助潜在宠物主人了解品种特异性风险，并就宠物选择做出明智决定。

### Sources

[1] Pediatric ophthalmology (Proceedings): https://www.dvm360.com/view/pediatric-ophthalmology-proceedings
[2] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[3] Managing diseases of the lens-clarification of a cloudy type: https://www.dvm360.com/view/managing-diseases-lens-clarification-cloudy-type-proceedings

## 鉴别诊断

遗传性白内障必须与其他几种可引起相似临床表现的晶状体和眼部疾病进行鉴别。最重要的鉴别诊断是核硬化，这是一种在犬和猫7-10岁左右发生的正常年龄相关变化 [1]。核硬化呈现为均匀的珍珠状混浊，带有灰蓝色调，双眼同等程度同时受累，但重要的是在逆反射下保留完整的眼底反射 [1]。

糖尿病性白内障代表另一个关键的鉴别诊断，特别是在患有糖尿病的中老年犬中 [2]。这些白内障在高血糖期间通过山梨醇途径迅速发展，通常变得膨胀并伴有宽缝合线裂隙 [2]。与遗传性白内障不同，糖尿病性白内障可在数周内从初期发展到成熟。

创伤性晶状体混浊也必须考虑，特别是有眼外伤病史时 [1]。这些白内障通常在前部和后部晶状体缝合线处呈现星形，并可能与晶状体囊破裂有关 [1]。由慢性葡萄膜炎引起的继发性白内障，特别是在猫中，表现为皮质混浊和相关炎症体征，包括房水闪辉和虹膜变化 [3]。

发病年龄、双侧对称性、品种易感性和逆反射发现有助于区分遗传性白内障与这些疾病。瞳孔扩张对于准确鉴别至关重要，因为核硬化将显示完整的眼底反射，而真正的白内障将表现出不同程度的光线阻挡 [1]。

### Sources

[1] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[2] Selected lens diseases and cataract treatment (Proceedings): https://www.dvm360.com/view/selected-lens-diseases-and-cataract-treatment-proceedings
[3] Update on cataract surgery (Proceedings): https://www.dvm360.com/view/update-cataract-surgery-proceedings
