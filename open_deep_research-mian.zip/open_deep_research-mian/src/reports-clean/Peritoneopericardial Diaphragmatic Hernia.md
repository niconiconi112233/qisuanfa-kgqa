# 伴侣动物腹膜心包膈疝：综合兽医参考

腹膜心包膈疝（PPDH）是犬猫中最常见的先天性膈肌缺损，但由于其通常无症状，因此经常被漏诊。这种先天性异常导致心包囊和腹膜腔之间形成通道，使腹腔器官疝入心包内。本综合参考资料整合了当前关于PPDH诊断和管理的兽医知识，涵盖了显示特征性心脏轮廓增大的诊断影像技术、包括腹侧膈肌推进术在内的手术矫正方法，以及影响患者预后的预后因素。报告探讨了魏玛犬和缅因猫的品种易感性，探讨了包括心包积液和创伤性疝在内的鉴别诊断，并为最佳患者护理提供了循证治疗方案。

## 疾病概述与病理生理学

腹膜心包膈疝（PPDH）是一种先天性异常，其特征是通过膈肌缺损导致心包囊和腹膜腔之间存在交通性缺损[1]。这种状况是由于胚胎发生期间横隔发育不良造成的，横隔通常形成膈肌的中心腱[2]。

PPDH是犬猫中最常见的先天性膈肌缺损[3][5]。该病症是由于背外侧横隔发育异常，或外侧胸腹膜褶与腹内侧胸骨部未能融合所致[5]。PPDH在犬猫中均可发生，具有明显的品种易感性。魏玛犬在犬类中风险较高，而长毛猫，特别是缅因猫，表现出更高的易感性[1]。

病理生理学涉及腹腔器官通过膈肌缺损疝入心包囊。肝脏是最常见的疝入器官，其次是小肠、脾脏和胃[5]。与创伤性膈疝不同，PPDH不是由产后创伤引起的，因为在伴侣动物中，腹膜腔和心包腔并不直接相连[2]。

许多病例保持无症状，是在常规X光检查中偶然发现的[1]。临床表现可从亚临床到严重呼吸窘迫不等，取决于疝入器官的体积和类型。

### Sources

[1] DVM 360: https://www.dvm360.com/view/clinical-exposures-incidental-finding-peritoneopericardial-hernia-cat
[2] DVM 360: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[3] DVM 360: https://www.dvm360.com/view/pericardial-disease-the-forgotten-cardiac-malady
[4] Allen Press: https://meridian.allenpress.com/jaaha/article/46/6/398/176624/Peritoneopericardial-Diaphragmatic-Hernia-A
[5] Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/uncommon-congenital-defects-of-the-cardiovascular-system-in-animals

## 诊断方法

PPDH的全面诊断评估需要结合临床检查、实验室检测和先进影像技术的系统方法[1]。胸部X光摄影仍然是诊断的基石，通常显示与膈肌重叠的心脏轮廓增大[2]。特征性的X光表现是膈肌轮廓消失，腹腔内脏器在心包囊内可见[3]。

体格检查可能发现心音减弱，特别是在右侧，这是由于心包内存在腹腔器官所致[1]。胸部听诊可能在胸腔内检测到胃肠音，而受影响区域肺音的缺失支持诊断[3]。在有症状的病例中，仔细评估心脏压塞的体征（包括颈静脉扩张）至关重要。

当X光检查结果不确定时，先进的影像学检查方法提供额外的诊断价值。超声检查和超声心动图可以有效区分真正的心脏轮廓与含有疝入器官的增大的心包囊[3]。对比研究，包括钡剂给药或腹腔内对比剂注射（腹腔造影术），在极少数情况下可能对明确诊断有必要[3]。

实验室异常通常是非特异性的，但可能包括轻度贫血、淋巴细胞增多、高磷血症和肝酶升高[1]。当疝伴有胸腔积液时，可能需要进行胸腔穿刺术，可能提供细胞学分析样本[3]。在需要详细解剖学评估的复杂病例中，可考虑先进的横断面成像（CT或MRI）。

### Sources

[1] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[2] Peritoneopericardial diaphragmatic hernia, cat: https://www.merckvetmanual.com/multimedia/image/peritoneopericardial-diaphragmatic-hernia-cat
[3] Diaphragmatic Hernia in Animals - Respiratory System: https://www.merckvetmanual.com/respiratory-system/diaphragmatic-hernia/diaphragmatic-hernia-in-animals

## 治疗方案

**医疗稳定化**
腹膜心包膈疝（PPDH）患者需要仔细的围手术期管理。初始稳定化重点是呼吸支持，因为在麻醉期间可能需要手动通气[2]。术前用药通常包括阿托品和布托啡诺，围手术期给予预防性抗生素如头孢唑林[2]。

**手术技术**
手术矫正仍然是PPDH的确定性治疗方法。该手术涉及腹侧中线剖腹术以进入疝入的器官[2]。腹侧膈肌推进术在修复这些复杂缺损方面显示出前景[1]。手术期间，小心地将疝入的器官操作回腹腔，特别注意分解镰状韧带与疝入肝叶之间的粘连[2]。使用不可吸收缝线以福特缝合模式关闭膈肌缺损，然后从心包囊中排出空气[2]。

**围手术期注意事项**
当器官被困在心包囊内时，可给予地塞米松以防止再灌注损伤[2]。当膈肌关闭后心包囊内残留空气时，心包积气可能作为术后并发症发生[4]。应在膈肌完全关闭之前放置胸腔引流管用于胸腔空间排空[6]。

**术后护理**
恢复包括使用布托啡诺进行镇痛管理，并监测呼吸或心血管并发症[2]。大多数患者恢复良好，术后三个月内胸部X光检查结果正常[2]。疝修补术已被证明通常能有效解决临床症状，无论治疗方法如何，长期生存率相似[3][4]。

### Sources
[1] A ventral diaphragmatic advancement technique to repair a peritoneopericardial diaphragmatic hernia: https://avmajournals.avma.org/view/journals/javma/262/8/javma.24.02.0098.xml
[2] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[3] Surgical and nonsurgical treatment of peritoneopericardial diaphragmatic hernia: https://avmajournals.avma.org/view/journals/javma/242/5/javma.242.5.643.xml
[4] Pneumopericardium associated with peritoneopericardial diaphragmatic hernia repair in a dog: https://www.dvm360.com/view/pneumopericardium-associated-with-peritoneopericardial-diaphragmatic-hernia-repair-dog
[5] Managing diaphragmatic hernias (Proceedings): https://www.dvm360.com/view/managing-diaphragmatic-hernias-proceedings

## 鉴别诊断与预后

**鉴别诊断**

腹膜心包膈疝必须与其他导致心脏轮廓增大的原因相鉴别[1]。主要鉴别诊断包括心包积液、先天性或获得性心脏病（动脉导管未闭、室间隔缺损）、心肌病和心内膜垫缺损[2]。创伤性膈疝是另一个重要的鉴别诊断，尽管它通常发生在不同位置，并有已知创伤史的急性发作[3]。

关键鉴别特征包括X光片上正常大小的肺血管伴有心脏轮廓增大、膈肌清晰轮廓消失以及胸腔内存在腹腔内脏器[1]。阳性对比腹腔造影术可以通过显示心脏周围的对比剂来明确确认诊断[2]。超声心动图有助于排除原发性心脏病。

**预后**

腹膜心包膈疝手术矫正后的预后通常极好。短期手术死亡率约为8.8%[4]。85.3%的手术治疗患者临床症状得到缓解[4]。不经手术，患者可能多年保持无症状，但有并发症风险，包括肝嵌顿、肠梗阻和心脏压塞[1]。

预后因素包括临床症状的存在、并发先天性异常以及粘连形成等手术并发症[2]。在没有并发症因素的情况下进行手术矫正时，正常预期寿命的预后良好[2]。

### Sources
[1] Incidental finding of a peritoneopericardial hernia in a cat: https://www.dvm360.com/view/clinical-exposures-incidental-finding-peritoneopericardial-hernia-cat/1000
[2] A peritoneopericardial diaphragmatic hernia in a cat: https://www.dvm360.com/view/clinical-exposures-peritoneopericardial-diaphragmatic-hernia-cat
[3] Diaphragmatic Hernia in Animals - Respiratory System: https://www.merckvetmanual.com/respiratory-system/diaphragmatic-hernia/diaphragmatic-hernia-in-animals
[4] Surgical and nonsurgical treatment of peritoneopericardial: https://avmajournals.avma.org/view/journals/javma/242/5/javma.242.5.643.xml
