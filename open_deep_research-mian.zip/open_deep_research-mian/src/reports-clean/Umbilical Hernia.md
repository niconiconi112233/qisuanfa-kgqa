# 伴侣动物的脐疝

脐疝是小动物兽医实践中最常见的先天性异常之一，影响犬和猫，原因是胎儿发育期间脐环闭合不完全。本综合报告检查了伴侣动物特有的临床表现、诊断方法和治疗策略，特别关注犬猫患者中观察到的品种易感性和遗传模式。分析涵盖了从初步识别到手术干预、鉴别诊断挑战以及影响兽医实践中治疗决策的长期预后因素等基本临床考量。

## 疾病概述

脐疝是指大网膜、与镰状韧带相关的脂肪或部分器官通过开放的脐环异常突出[1]。疝内容物被由皮肤、皮下组织和腹膜组成的可见囊袋包裹[1]。这种情况代表腹肌未能完全发育，导致脐环闭合不完全[1]。

脐疝在小动物中很常见，无性别偏好，但表现出品种和家族风险模式[1]。《默克兽医手册》证实，脐疝大小不一，可能仅含有脂肪或大网膜，或在更严重的情况下含有肠袢[2]。在犬中，魏玛猎犬、北京犬、巴辛吉犬和万能梗的发病率较高[2]。家猫的发病率低；然而，在柯尼斯卷毛猫中报告了高发病率[1]。

这些疝可能是先天性和遗传性的[1][2]。遗传病因被怀疑但尚未证实[2]。有证据表明，脐环的大小受两个或更多隐性基因控制[1]。

一些脐疝可能是通过创伤或不当的脐带管理获得的[1]。如果脐带在离腹壁太近处被切断，或母犬过度咀嚼脐带，脐部可能会扩大或变弱[1]。

### Sources
[1] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings
[2] Hernias in Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/hernias-in-animals

## 病因学和临床表现

犬和猫的脐疝是由于腹肌未能完全围绕脐环发育所致[1]。病因主要是遗传性的，有证据表明脐环的大小受两个或更多隐性基因控制[1]。在犬中，魏玛猎犬、北京犬、巴辛吉犬和万能梗的发病率较高，且脐疝常与隐睾症同时发生[1]。犬和猫都可能遗传发生疝的倾向[4]。

一些脐疝可能是由创伤性原因获得的，例如脐带在离腹壁太近处被切断或在剖腹产期间操作不当[6]。

**临床表现**在单纯性和复杂性疝之间差异显著。单纯性脐疝表现为脐部柔软、波动的肿块，通常无痛且可通过轻柔操作复位[6]。疝内容物可能包括大网膜、与镰状韧带相关的脂肪或肠袢[1]。

当组织粘连到皮肤或发生肠嵌顿时，复杂性疝表现为坚硬、不可复位的肿块[6]。当发生绞窄时，临床症状包括肠梗阻，需要立即进行放射学检查[6]。疝囊大小差异很大，大的疝需要手术矫正以防止绞窄，并出于美容原因[6]。

### Sources
[1] Hernias in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/hernias-in-animals
[2] Congenital and Inherited Disorders of the Digestive System in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/congenital-and-inherited-disorders-of-the-digestive-system-in-cats
[3] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings

## 诊断方法和鉴别诊断

体格检查仍然是脐疝的主要诊断工具。应系统触诊脐部区域以识别疝环并评估可复性[1][2]。疝内容物通常感觉柔软、波动且无痛，随内容和持续时间而变化[2]。轻柔操作通常可使疝复位，从而能够触诊疝环[1]。

当怀疑有肠管受累或需要与其他疾病鉴别时，应进行放射学检查[3]。造影研究可能显示充满气体的肠袢或有助于识别疝囊内的特定器官[1][2]。超声检查提供疝内容的详细可视化，并可评估器官受累情况，对于评估疝内的软组织特别有用[1][3]。

除非怀疑有绞窄或脓毒症等并发症，否则很少需要实验室检查[2]。脐部感染是新生儿败血症的常见来源[2]。

主要的鉴别诊断包括脐部的乳腺肿瘤、囊肿、血肿、脓肿和脂肪瘤[1]。脓肿通常表现为发热、白细胞增多和触诊时疼痛，这与可复位疝的自由活动、无痛性质不同[1]。囊肿和血肿质地坚硬，可能呈分叶状，且发展缓慢，无相关发热[1]。

### Sources

[1] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings
[2] Hernias in Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/hernias-in-animals
[3] Ultrasonography in Animals - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/ultrasonography-in-animals

## 治疗选择和预防措施

幼犬的大多数小型脐疝无临床意义，可能在成熟前自行消退[1]。保守治疗包括用绷带定期复位，尽管这种技术成功率有限[1]。大的疝需要手术矫正以防止绞窄，并出于美容原因[1]。

手术修复（疝修补术）在患者背卧位时进行，在疝囊上做正中切口[1]。对于小型疝，在切除和清创疝环边缘后，可将囊袋内翻入腹腔[1]。闭合使用单丝钢丝或PDS进行简单间断缝合或水平褥式缝合[1]。承受相当大张力的大型疝环可能需要不可吸收缝合材料，如不锈钢丝[1]。《默克兽医手册》证实，在大多数情况下，建议手术闭合体壁缺陷以降低未来肠嵌顿的风险[6]。

术后护理包括使用抗生素预防感染，并在第一周限制活动[1]。脐部感染可导致局部脓肿或败血症，需要引流、冲洗和抗生素治疗[3]。并发症包括腹膜炎、脏器脱出和复发[1]。

预防策略侧重于繁殖建议，因为脐疝表现出品种和家族易感性，并有遗传证据[1][2][6]。在犬中，魏玛猎犬、北京犬、巴辛吉犬和万能梗的发病率较高[6]。小型疝通常在绝育手术期间矫正[2]。剖腹产期间小心操作和正确管理脐带可防止获得性疝[1]。

### Sources

[1] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings

[2] Congenital and Inherited Disorders of the Digestive System in Cats: https://www.merckvetmanual.com/en-au/cat-owners/digestive-disorders-of-cats/congenital-and-inherited-disorders-of-the-digestive-system-in-cats

[3] Care of the canine and feline neonate: part 2 (Proceedings): https://www.dvm360.com/view/care-canine-and-feline-neonate-part-2-proceedings

[4] Merck Veterinary Manual Hernias in Animals: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/hernias-in-animals

## 预后和结果

在适当的手术管理下，犬和猫脐疝的预后通常极好[1]。幼犬的大多数小型脐疝可能在成熟前自行消退，因此在许多情况下不需要手术干预[1][2]。

**手术结果**在使用适当技术时非常有利。在卵巢子宫切除术等常规手术期间矫正的小型疝并发症最少，恢复率极佳[1]。需要专门手术矫正的大型疝在经验丰富的兽医治疗下也有良好的预后[1]。在适当的手术技术和术后护理下，存活率高且并发症罕见[1]。

**影响预后的风险因素**包括疝的大小、持续时间和并发症的存在。术后并发症可能包括腹膜炎、脏器脱出和复发，但在适当管理下这些情况很少见[1]。如果疝出的组织已经发生绞窄或坏疽，预后会显著恶化，这强调了及时干预的重要性[1]。

**长期考虑**包括某些品种（如魏玛猎犬、北京犬、巴辛吉犬和万能梗）中脐疝的遗传性质[2]。发生疝的倾向可能是遗传的，因此繁殖决策对受影响的动物很重要[3]。通过适当的手术管理和术后护理，大多数动物可恢复正常活动且无长期并发症。

### Sources
[1] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings
[2] Hernias in Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/hernias-in-animals
[3] Congenital and Inherited Disorders of the Digestive System in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/congenital-and-inherited-disorders-of-the-digestive-system-in-cats
