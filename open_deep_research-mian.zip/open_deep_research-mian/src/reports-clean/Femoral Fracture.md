# 伴侣动物股骨骨折

股骨骨折是小动物兽医实践中最重要的骨科挑战之一，影响所有年龄段的犬和猫。这些对身体最长最强壮骨骼的复杂损伤需要立即的兽医干预和复杂的治疗方法。本综合报告探讨了股骨骨折的临床谱系，从幼年动物的创伤性骨折到老年患者的病理性骨折。分析涵盖了使用先进成像技术的关键诊断方案、基于证据的手术管理选择（包括髓内针固定和外固定系统），以及可能显著影响患者结果和长期预后的并发症。

## 摘要

伴侣动物股骨骨折呈现复杂的临床挑战，需要先进的诊断和治疗方法。机动车事故仍然是创伤性骨折的主要原因，而病理性骨折则发生在潜在骨骼疾病的情况下。幼猫面临股骨头骨骺骨折的特殊风险，特别是肥胖、去势且骨骺闭合延迟的雄性。

诊断评估主要依赖正交放射线摄影视图，CT成像为复杂骨折提供更优越的细节。由于伴侣动物难以实现充分固定，保守治疗很少适用。手术选择包括动态加压钢板、交锁钉和外骨骼固定器，治疗选择基于骨折构型和患者因素。

| 并发症 | 发生率 | 处理 |
|--------|--------|------|
| 骨不连 | 最常见 | 线性外固定 |
| 针道感染 | ESF病例中19-50% | 抗菌治疗 |
| 股四头肌挛缩 | 幼犬 | 每日物理治疗 |
| 坐骨神经损伤 | 术后2-3周 | 通过正确针位预防 |

骨不连病例的平均愈合时间为57.8天，总体并发症率为11.5%。成功的预后取决于适当的手术稳定、细致的术后护理和早期识别并发症。当遵循基于证据的治疗方案时，长期功能恢复通常良好。

## 疾病概述与流行病学

股骨骨折表示犬和猫股骨连续性的完全或部分断裂。股骨是身体最长最强的骨骼，从髋关节延伸到膝关节[1]。这些骨折可发生在多个解剖位置，包括股骨头、股骨颈、骨干或髁部。

股骨骨折是小动物实践中最常见的骨科损伤之一[2]。发病率因物种、年龄和易感因素而有显著差异。在猫中，股骨头骨骺骨折对体重较重、去势且骨骺闭合延迟的雄性有特殊易感性[3]。股骨头骨骺通常在7.5至10个月龄时闭合，其他风险因素包括肥胖和雄性性别[4]。

从流行病学角度看，肥胖是股骨骨折的重要易感因素。在犬中，肥胖使前十字韧带断裂的风险增加四倍[5]，在终身研究中，超重犬比限制饮食的对照组更早出现骨关节炎的放射学证据[5]。股骨骨折的外骨骼固定在某些研究中导致不可接受的高骨不连率[6]。

青春期前接受性腺切除术的幼猫发生股骨头骨骺滑脱的风险增加，其中年轻肥胖雄性比例过高[3]。继发性骨关节炎通常由导致关节支持结构软组织损伤或关节表面骨折的创伤引起[1]。

### Sources
[1] Degenerative joint disease in the cat (Proceedings): https://www.dvm360.com/view/degenerative-joint-disease-cat-proceedings
[2] Orthopedic surgery in small mammals (Proceedings): https://www.dvm360.com/view/orthopedic-surgery-small-mammals-proceedings
[3] Juvenile orthopedic diseases (Proceedings): https://www.dvm360.com/view/juvenile-orthopedic-diseases-proceedings
[4] Early age altering of kittens (Proceedings): https://www.dvm360.com/view/early-age-altering-kittens-proceedings
[5] Obesity and orthopedic disease: a relationship to remember: https://www.dvm360.com/view/obesity-and-orthopedic-disease-relationship-remember
[6] Kirschner wire creates more microdamage than standard or ...: https://avmajournals.avma.org/view/journals/ajvr/86/1/ajvr.24.07.0198.xml

## 病因学与临床表现

伴侣动物股骨骨折由创伤性和病理性原因引起。创伤性骨折最常见的原因是机动车事故，这是年轻健康犬和猫的主要病因[2][4]。这些高能量创伤病例通常伴有重要器官的并发损伤，在骨折管理前需要立即处理。跌落、咬伤和其他钝力创伤也是创伤性股骨骨折的原因。

病理性骨折较少发生，但可由潜在的骨骼疾病、肿瘤或影响骨骼强度的代谢紊乱引起。在未成熟动物中，骨骺是骨骼-韧带结构中最薄弱的点，使骨骺骨折比韧带损伤更可能发生[3]。股骨头骨骺骨折是犬最常见的近端股骨骨折，特别影响9个月龄以下的动物，此时骨骺尚未闭合[4]。

临床表现通常包括受影响肢体的中度至重度不负重跛行。根据骨折严重程度和并发损伤，患者可能完全无法行走。股骨触诊疼痛、可见畸形、骨擦音和肿胀是特征性发现[2]。股骨干骨折可能伴随大量出血，导致筋膜间隔内包含的紧张疼痛性肿胀[4]。

由于坐骨神经创伤可能出现并发神经功能缺损，需要通过脚趾捏压试验仔细评估深部痛觉和运动功能[4]。品种特异性考虑包括德国牧羊犬和某些猎犬品种因构型因素或遗传易感性而具有较高风险。

### Sources

[1] Assessment and management of pelvic fractures in dogs: https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[2] Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[3] Managing physeal and articular fractures: https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[4] Fractures and luxations of the hind limb: https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings

## 诊断方法与影像学

股骨骨折的临床检查从步态分析和骨科评估开始。视觉跛行评估虽然常用，但与测力平台步态分析等客观方法相比敏感性有限[1]。体格检查显示负重异常、操作时疼痛以及可能的肢体畸形或短缩。

放射学评估仍然是股骨骨折诊断的基石。标准正交视图（腹背位和侧位）对骨折可视化和分类至关重要[2]。正确的定位至关重要，因为股骨旋转会显著影响放射学解释[3]。骨折分类使用Salter-Harris系统（I-V级）用于生长板损伤，每种类型表示生长并发症风险增加[5]。

计算机断层扫描（CT）为复杂骨折和术前规划提供优越的细节。CT提供股骨几何形状的准确测量和粉碎性骨折的更好可视化[2]。先进成像对严重粉碎的骨干和干骺端骨折特别有价值，精确的碎片评估指导手术方法选择[6]。

超声作为有价值的辅助诊断工具，特别适用于检测并发软组织损伤和监测骨折愈合[4]。数字放射系统现在提供出色的对比度分辨率，尽管与传统胶片相比空间分辨率略有降低，DICOM格式确保图像完整性和可传输性[7]。

### Sources
[1] Advanced diagnostics for orthopedic & sports related injury (Proceedings): https://www.dvm360.com/view/advanced-diagnostics-orthopedic-sports-related-injury-proceedings
[2] Radiographs acquired before total hip replacement in dogs: https://avmajournals.avma.org/view/journals/ajvr/86/7/ajvr.25.02.0045.xml
[3] Effects of femur position on radiographic assessment of: https://avmajournals.avma.org/view/journals/ajvr/67/1/ajvr.67.1.64.xml
[4] Ultrasound is an accurate imaging modality for diagnosing hip: https://avmajournals.avma.org/view/journals/javma/262/10/javma.24.05.0321.xml
[5] Managing physeal and articular fractures (Proceedings): https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[6] Severely comminuted femoral fractures (Proceedings): https://www.dvm360.com/view/severely-comminuted-femoral-fractures-proceedings
[7] Radiography of Animals - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/radiography-of-animals

## 治疗选择

股骨骨折的治疗需要仔细考虑骨折构型、患者因素和外科医生经验，以选择最佳固定方法[1][2]。由于无法在伴侣动物中维持充分固定，保守治疗很少适用于股骨骨折[4]。

**手术固定选择**包括多种方法，取决于骨折位置和复杂性[2]。对于简单骨干骨折，动态加压钢板、交锁钉或带外骨骼固定的髓内针提供稳定修复[2][5]。粉碎性骨折受益于使用交锁钉、钢板-钉组合或跨越骨折区域的外骨骼固定的桥接技术[2]。线性-圆形混合固定器在24例中有22例随访评估显示成功愈合[6]。

**髓内针固定**要求针占据髓腔的70%用于骨干骨折，并需要辅助固定来抵抗旋转和压缩力[5]。外骨骼固定在骨不连病例中显示出高成功率，特别是猫的线性构型[1][3]。

**术后管理**涉及骨骼愈合期间的严格活动限制[2]。围手术期镇痛药包括硬膜外吗啡、麻醉贴剂和非甾体抗炎药以缓解不适[4]。物理治疗预防股四头肌挛缩并恢复肢体功能[4][5]。

### Sources
[1] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[2] Severely comminuted femoral fractures (Proceedings): https://www.dvm360.com/view/severely-comminuted-femoral-fractures-proceedings
[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[4] Bone Trauma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[5] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[6] Management of Humeral and Femoral Fractures in Dogs and Cats: https://meridian.allenpress.com/jaaha/article/44/4/180/176405/Management-of-Humeral-and-Femoral-Fractures-in

## 并发症与预后

股骨骨折修复后可能出现几种常见并发症。报道的最常见并发症是骨不连，通常由骨折固定不足引起[1]。外骨骼固定（ESF）并发症影响19-50%的猫骨折病例，常见问题包括针道感染、植入物松动和过早移除植入物[2]。

特定并发症包括股四头肌挛缩，特别是在远端股骨操作后的幼犬中。这种可预防的疾病需要细致的术后物理治疗，每天进行10-15次膝关节屈伸运动，持续四周[3]。坐骨神经损伤可能在术后2-3周由于不当的髓内针置入而发生，导致纤维血管增生压迫神经[3]。最近研究报告总体并发症率为11.5%，包括灾难性和主要并发症[5]。

愈合时间因患者年龄和骨折管理方法而有显著差异。对于用线性外固定治疗的骨不连病例，骨愈合平均为57.8天（范围47-71天）[1]。在骨骼皮质较薄的干骺端区域，螺钉可能容易发生拔出失败，特别是在骨质疏松骨骼或老年患者中[6]。

预后因素包括骨折位置、患者年龄和手术技术质量。股骨颈骨折在获得稳定修复时预后良好，预期功能恢复[3]。当提供适当的手术稳定和术后护理时，长期功能结果通常良好[5]。

### Sources
[1] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.pdf
[2] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[3] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[4] Treating fracture disease and nonunion fractures (Proceedings): https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings
[5] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/85/3/ajvr.23.09.0207.xml
[6] Changes in fracture treatment which help practitioners: https://www.dvm360.com/view/changes-fracture-treatment-which-help-practitioners-proceedings
