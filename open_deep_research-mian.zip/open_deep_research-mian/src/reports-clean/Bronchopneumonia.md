# 伴侣动物支气管肺炎

支气管肺炎是犬猫中的一种重要呼吸系统疾病，其特征是肺实质炎症，始于终末细支气管并延伸至小气道、间质和肺泡。此病症通常继发于病毒感染或误吸事件，这些因素损害呼吸防御机制，使动物易受细菌侵袭。该疾病对幼年动物影响尤为严重，应激是一个重要的易感因素。本报告探讨了涉及病毒和细菌病原体的复杂病理生理学、从轻度呼吸道症状到严重全身性疾病的临床表现、包括放射影像学和细菌培养在内的诊断方法、结合抗菌治疗和支持性护理的综合治疗策略，以及通过疫苗接种和环境管理进行预防。

## 摘要

伴侣动物支气管肺炎是一种多因素疾病，需要对其复杂的病因和管理进行全面了解。该病症通常通过病毒-细菌相互作用发展，犬瘟热病毒和腺病毒等主要病毒病原体损害呼吸防御，使*支气管败血波氏杆菌*和革兰氏阴性需氧菌等有机体得以继发细菌侵袭。临床表现从持续性咳嗽和呼吸困难到严重全身性疾病不等，胸部放射影像学显示特征性的颅腹侧肺泡模式，这对诊断至关重要。

治疗成功取决于及时的抗菌治疗结合支持性护理，包括氧疗、雾化和气道清除技术。预防策略强调核心呼吸道疫苗接种、环境管理以减少拥挤和应激，以及在机构环境中立即实施隔离方案。

| 疾病方面 | 关键发现 |
|---|---|
| 主要风险因素 | 损害防御机制的病毒性呼吸道感染 |
| 诊断金标准 | 显示颅腹侧肺泡模式的胸部放射影像学检查 |
| 治疗基石 | 肠外抗生素联合全面支持性护理 |
| 预防重点 | 核心呼吸道疫苗接种和环境管理 |

吸入性肺炎预后尤其不良，死亡率高达25%，强调了早期识别和积极干预对于获得最佳临床结果的关键重要性。

## 疾病概述与流行病学

支气管肺炎是肺实质的炎症，特指始于终末细支气管并延伸至小气道、间质和肺泡的肺炎[1]。此病症代表伴侣动物中的一种重要呼吸系统疾病，其特征为炎症浸润和气体交换受损。

该疾病可由多种生物引起，包括细菌、病毒、真菌、寄生虫和原虫，也可由误吸事件引起[1]。细菌性肺炎，包括支气管肺炎，在猫中很少是原发性疾病，且在猫中的发生率低于犬[2]。该病症通常继发于免疫抑制性疾病、病毒感染或损害呼吸防御机制的误吸事件。

幼年动物尤其易感，应激是一个重要的易感因素[6]。风险因素包括由犬瘟热病毒、1型和2型腺病毒和副流感病毒等主要病毒病原体引起的呼吸防御机制受损，这些病毒导致气道损伤并易发细菌侵袭[1,7]。误吸事件、刺激性物质吸入以及充血性心力衰竭或免疫抑制等基础疾病也会增加患病风险[1,3]。包括通风不良、拥挤和应激在内的环境因素可促进疾病发展。

### Sources

[1] Pneumonia in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings
[3] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[4] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[5] Etiology and clinical outcome in dogs with aspiration pneumonia: https://avmajournals.avma.org/view/journals/javma/233/11/javma.233.11.1748.xml
[6] Bacterial Bronchopneumonia in Sheep and Goats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-sheep-and-goats/bacterial-bronchopneumonia-in-sheep-and-goats
[7] Pneumonia in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs

## 病因学：常见病原体与疾病机制

伴侣动物支气管肺炎由损害呼吸防御机制的病毒和细菌病原体之间的复杂相互作用引起。肺炎最常见的原因是下呼吸道病毒感染[1]。犬瘟热病毒、1型和2型腺病毒、犬流感病毒和副流感病毒导致气道损伤并使动物易患肺炎[1]。

**细菌病原体**

主要细菌病原体包括支气管败血波氏杆菌和马链球菌[2]。支气管败血波氏杆菌是少数原发性细菌性呼吸道病原体之一，通过牢固附着于纤毛上皮并诱导纤毛停滞引起肺炎[2]。大多数细菌性肺炎病例涉及机会性入侵者，包括大肠杆菌、多杀性巴氏杆菌、肺炎克雷伯菌和铜绿假单胞菌等革兰氏阴性需氧菌[2]。

支原体属是犬猫中的重要病原体，其中犬支原体是犬类中最常见的病原体[3]。当防御机制被原发性病毒感染损害时，继发性细菌感染通常会使病毒性呼吸道疾病复杂化[4]。

**病理生理学**

肺炎通过包括小气道、间质和肺泡在内的肺实质炎症发展[5]。吸入性肺炎通过吸入异物发生，其严重程度取决于吸入的物质和细菌污染[1]。丝状线虫、猫圆线虫或并殖吸虫属的寄生虫侵袭也可导致肺炎[5]。支气管黏膜损伤和刺激性物质吸入可直接引起肺炎，同时易发继发性细菌侵袭[1]。

### Sources
[1] Pneumonia in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[2] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[3] A retrospective analysis of canine, feline, and equine ...: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.11.0755/javma.24.11.0755.pdf
[4] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[5] Pneumonia in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats

## 临床表现与诊断

犬猫支气管肺炎临床表现多样，从轻度呼吸道症状到严重全身性疾病。常见临床症状包括持续性咳嗽、呼吸费力性呼吸困难、鼻分泌物（常为黏脓性）和发热[1]。犬可能比其他呼吸道感染更频繁地表现出嗜睡和脓性鼻分泌物[6]。体格检查通常在肺部听诊时发现支气管肺泡音增强、捻发音和喘鸣[7]。

**诊断影像学**对确诊至关重要。胸部放射影像学显示特征性的颅腹侧肺泡模式，伴有均匀软组织不透明度、空气支气管征以及与心脏和膈肌结构的边界消失[4][8]。肺泡模式通常在前叶和中叶内呈中区和外周分布[4]。当普通放射影像学检查不足时，可能需要计算机断层扫描等先进影像学检查，因为该疾病具有动态性质[3]。

**实验室诊断**包括全血细胞计数（注意只有一半的肺炎患者出现发热或白细胞增多症）[6]。细胞学检查可能显示中性粒细胞增多，伴有细胞内或细胞外细菌[1]。对于病情稳定的患者，应在抗生素治疗前进行气管冲洗细胞学检查和细菌培养[6]。需要进行细菌培养和药敏试验，可能包括厌氧菌和支原体培养，尤其是在难治性病例中[1]。

### Sources
[1] Merck Veterinary Manual Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] MSD Veterinary Manual Pneumonia in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[3] Thoracic imaging (Proceedings): https://www.dvm360.com/view/thoracic-imaging-proceedings
[4] Small animal thoracic radiology: Beyond pulmonary patterns (Proceedings): https://www.dvm360.com/view/small-animal-thoracic-radiology-beyond-pulmonary-patterns-proceedings
[5] DVM 360 Radiographic evaluation of pulmonary patterns and disease (Proceedings): https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[6] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings
[7] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[8] Pneumonia in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/en-au/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats

## 治疗策略

支气管肺炎的治疗需要多模式方法，结合抗菌治疗和全面支持性护理[1][3]。无论疾病严重程度如何，均建议对肺炎患者使用肠外抗生素，在吸入性病例中需考虑覆盖厌氧菌[3]。一线经验性治疗通常包括氟喹诺酮类药物联合氨苄西林-舒巴坦或克林霉素，直至培养结果指导具体疗法选择[3]。

**非药物干预**集中于气道清除和呼吸支持[7][8]。应提供氧疗以维持充分氧合，脉搏血氧饱和度读数低于90%时需立即补充[7]。生理盐水雾化有助于液化分泌物并提供湿化，而叩诊（胸部叩击）可刺激有效咳嗽并促进气道分泌物排出[6][7]。通过雾化器或带储雾罐的定量吸入器进行气溶胶给药，使药物直接递送至呼吸组织[9]。

**护理方案**强调维持水分以防止分泌物黏稠，因为超过90%的呼吸道黏液是水[6]。不应让患者长时间卧床，鼓励轻度运动以刺激咳嗽反射并改善通气[6]。N-乙酰半胱氨酸可作为黏液溶解剂口服或雾化给药，尽管在某些患者中可能引起支气管收缩[6][9]。

对于对药物治疗无反应的持续性局限性病变，可能需要手术干预，特别是当怀疑有肺脓肿或异物吸入时[6]。

### Sources
[1] Clinical course and radiographic resolution of pneumonia: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.04.0259.pdf
[3] What are the best practices for antibiotic use in pneumonia: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-pneumonia-bronchitis-and-pyothorax
[6] Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings
[7] Inhalation Treatment of Airway Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-respiratory-system/inhalation-treatment-of-airway-disease-in-animals
[8] Drugs Used to Treat Lung and Airway Disorders: https://www.merckvetmanual.com/special-pet-topics/drugs-and-vaccines/drugs-used-to-treat-lung-and-airway-disorders
[9] Inhalant therapy in small animals (Proceedings): https://www.dvm360.com/view/inhalant-therapy-small-animals-proceedings

## 预防与鉴别诊断

### 预防措施

**疫苗接种策略**
犬的核心呼吸道疫苗包括针对犬瘟热病毒、副流感病毒、犬腺病毒2型和*支气管败血波氏杆菌*的疫苗，这些疫苗有助于预防犬窝咳和相关呼吸道感染[1]。灭活犬流感疫苗可减少肺病变的发生率和严重程度以及咳嗽和病毒排毒的持续时间[1]。对于猫，接种FVRCP（猫疱疹病毒1型、杯状病毒和猫泛白细胞减少症）疫苗可提供对常见上呼吸道病原体的保护[3]。

**环境控制措施**
预防在很大程度上依赖于管理实践以减少暴露[1]。关键措施包括减少拥挤和应激、保持适当通风以及使用适当消毒剂进行常规消毒[1][3]。猫杯状病毒需要5%漂白剂溶液按1:32稀释或过一硫酸钾进行有效消毒[1][3]。应消除环境刺激物，如香烟烟雾、气雾除臭剂和多尘的寝具[7]。

**隔离指南**
在医院、收容所或寄养环境中，对急性咳嗽动物立即隔离至关重要[1][5]。犬可能排毒长达10天，包括无症状携带者[1]。标准隔离程序应包括个人防护装备以及对所有区域（包括办公桌空间、门把手和电话）的消毒[5]。

### 鉴别诊断

**重叠的呼吸系统疾病**
支气管肺炎必须与慢性支气管炎、哮喘和其他呼吸系统疾病相鉴别[8]。犬嗜酸性粒细胞性支气管肺病表现为持续性剧烈咳嗽后干呕，类似于细菌性肺炎，但特征是嗜酸性粒细胞气道浸润而非细菌感染[7]。鉴别诊断包括心脏病、异物、真菌感染和肿瘤[8]。

**关键鉴别因素**
细菌性支气管肺炎通常产生黏脓性分泌物和全身性疾病，而病毒感染通常表现为更急性发作，可能包括结膜炎[1]。诊断工具包括胸部放射影像学检查、气道样本细胞学检查和细菌培养，有助于区分各种疾病[7][8]。放射影像学模式从支气管浸润到肺泡浸润不等，取决于疾病进展[8]。

### Sources
[1] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings
[2] Breaking down the mysterious canine infectious respiratory disease: https://www.dvm360.com/view/breaking-down-the-mysterious-canine-infectious-respiratory-disease
[3] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[4] Diagnosing and managing canine eosinophilic bronchopneumopathy: https://www.dvm360.com/view/diagnosing-and-managing-canine-eosinophilic-bronchopneumopathy
[5] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs

## 预后与临床结局

犬猫支气管肺炎的预后差异很大，取决于潜在病因和患者因素。一般来说，病毒性呼吸道感染往往是自限性的，预后良好，特别是在已正确接种疫苗的成年猫中[1]。然而，可能发生胸膜炎或继发性细菌感染等并发症，影响整体结局[2]。

尽管进行积极治疗，吸入性肺炎预后尤其不良。死亡率仍然很高，康复动物经常发展为肺脓肿作为长期后遗症[2][3]。当吸入涉及胃酸或其他腐蚀性胃内容物时，这种不良预后尤为明显[8]。高达25%的吸入性肺炎犬死于该疾病，突显了早期诊断和治疗的重要性[8]。

几种临床症状作为不良预后指标。嗜睡、发热、呼吸困难和持续性打喷嚏预示患有急性犬传染性呼吸道疾病的犬预后不良[9]。需要氧疗支持的严重呼吸困难、表明低氧血症的发绀黏膜和呼吸窘迫代表需要立即重症监护的危重并发症[2][3]。

幼年动物、老年患者和免疫系统受损的患者面临严重疾病和并发症的更高风险[1][3]。真菌性肺炎病例通常需要在临床症状缓解后持续数月的长期抗生素治疗[2][3]。肺炎的预后因病因和就诊时的严重程度而异，通常难以逆转[6]。

### Sources
[1] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Pneumonia in Dogs: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[3] Pneumonia in Cats: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/pneumonia-in-cats
[4] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[5] Lower respiratory infections in dogs: https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[6] The pneumonias of small mammals: https://www.dvm360.com/view/pneumonias-small-mammals-proceedings
[7] Bacterial pneumonia: https://www.dvm360.com/view/bacterial-pneumonia-proceedings
[8] Aspiration Pneumonia in Pets and People: https://www.dvm360.com/view/aspiration-pneumonia-in-pets-and-people
[9] Observational survey of dogs: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0133/ajvr.25.04.0133.pdf
