# 伴侣动物肛门囊炎

肛门囊炎是兽医实践中影响犬猫最常见的肛周疾病之一。这种成对肛门囊的炎症性疾病显著影响患者的舒适度和生活质量，尤其是在小型犬中，其易感性明显增加。该疾病涵盖从单纯堵塞到严重脓肿的一系列病症，若不进行适当干预，通常会进一步恶化。

本综合报告探讨了肛门囊炎管理的病理生理学、临床表现和治疗方法。主要发现包括细菌病原体鉴定、与肛门囊腺癌的鉴别诊断，以及医疗与手术治疗方式的比较结果。了解这些临床方面有助于兽医实施循证治疗方案并优化患者预后。

## 总结

肛门囊炎主要影响小型犬，细菌病原体包括大肠杆菌、变形杆菌和葡萄球菌属，这些病原体驱动了炎症过程。临床表现通常包括擦地、肛周不适和排便疼痛，需要通过细胞学检查和超声检查与肛门囊腺癌进行鉴别。

治疗效果根据方法不同而有显著差异：

| 治疗方法 | 预后 | 复发率 | 关键考虑因素 |
|------------------|-----------|-----------------|-------------------|
| 医疗管理 | 谨慎至一般 | 高 | 抗菌效果有限 |
| 手术切除 | 良好 | 9% | 难治性病例的确定性治疗 |
| 双侧肛门囊切除术 | 长期极好 | 低 | 技术得当则并发症最少 |

通过手动挤压、局部抗菌剂和膳食纤维补充进行的医疗管理提供初始治疗，但经常失败。对于慢性病例，手术干预提供更优越的长期结果，双侧一期肛门囊切除术显示出极佳结果和最少的术后并发症。早期识别并根据严重程度和对保守治疗的反应选择适当的治疗方案，可优化患者预后，同时减少进展到更复杂手术需求的可能性。

## 疾病概述

肛门囊炎是位于肛门两侧约4-8点和8-10点位置的成对肛门囊的炎症[1]。这些囊含有特殊的顶泌腺，通常在排便期间通过开口于肛门附近的小导管排空。该疾病包括几个疾病实体，包括这些结构的堵塞、炎症（囊炎）和脓肿。

小型犬品种对肛门囊疾病有显著易感性，而大型和巨型品种很少受影响[1]。这是影响犬肛周区域最常见的疾病之一。在猫中，肛门囊疾病发生频率较低，其中堵塞是最常见的表现[1][2]。该疾病影响各年龄段的犬，但没有明显的性别偏好，尽管一些研究表明雌性犬可能更容易出现某些并发症如腺癌。

风险因素包括导致肌肉张力差的肥胖、阻止正常肛门囊排空的软便、引起腺体过度分泌的全身性皮脂溢，以及导致导管损伤的频繁手动挤压[1][2]。这些因素导致囊内容物滞留，易发细菌过度生长和随后的炎症。

### Sources

[1] Anal Sac Disease in Dogs and Cats - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/anal-sac-disease-in-dogs-and-cats

[2] Disorders of the Rectum and Anus in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-rectum-and-anus-in-dogs

## 发病机制和临床表现

肛门囊炎涉及复杂的病理生理机制，导致犬猫出现特征性临床表现。发病机制始于排便期间正常肛门囊排空失败，通常是由于肥胖动物的肌肉张力差或引起腺体过度分泌的全身性皮脂溢[1]。这种滞留创造了有利于细菌过度生长和随后的炎症的环境。

与肛门囊炎相关的最常见细菌病原体包括革兰氏阴性肠杆菌科，特别是大肠杆菌，以及变形杆菌、葡萄球菌和肠球菌属[3]。这些微生物在滞留的分泌物中繁殖，导致囊壁内感染和炎症变化。

临床症状主要与坐着或排便相关的疼痛和不适有关。受影响的动物通常表现出擦地、过度舔咬肛门区域以及排便疼痛和里急后重[1]。体格检查显示堵塞病例可触及硬块，而感染的囊则表现出严重疼痛和经常变色。正常的稀薄褐色分泌物变得粘稠糊状，只有施加显著压力才能挤出[1]。

小型犬品种对肛门囊疾病表现出增加的易感性，而大型和巨型品种很少受影响[1]。在猫中，堵塞代表肛门囊疾病的最常见形式，尽管总体发病率仍低于犬[2]。挤出材料中的血液总是异常的，表明感染或炎症[3]。

### Sources
[1] Anal Sac Disease in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/anal-sac-disease-in-dogs-and-cats
[2] Disorders of the Rectum and Anus in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-rectum-and-anus-in-cats
[3] Getting to the bottom of anal sac diseases: https://www.dvm360.com/view/getting-to-the-bottom-of-anal-sac-diseases

## 诊断方法和鉴别诊断

**临床检查发现**

体格检查通常在直肠指检期间可在肛门囊区域触及硬块[1]。肛门囊炎的诊断通过直肠指检确认，在此期间可以挤压囊[1]。在堵塞病例中，只有施加大量压力才能挤出细带状的粘稠糊状褐色分泌物[1]。当感染或脓肿时，存在严重疼痛和经常区域变色[1]。

**诊断方法**

挤出肛门囊内容的显微镜检查显示感染病例中有大量多形核白细胞和细菌[1]。超声检查可能有助于确定坚硬、无法挤出的肛门囊是由于感染/脓肿还是肿瘤[1]。在疑似肿瘤病例中，细针抽吸物通常显示密集的、常为乳头状细胞团块，伴有丰富的散在游离核[5]。完整细胞呈圆形至多边形，可能以腺泡样排列观察到[5]。

**鉴别诊断**

主要鉴别诊断包括肛门囊腺癌、肛周瘘和其他肛周肿块[1,3]。肛门囊肿瘤通常无痛，可能与会阴水肿、红斑或瘘管形成有关[1]。这些必须与肛周瘘区分，后者表现为慢性、化脓、恶臭的溃疡性窦道，最常见于德国牧羊犬[3]。在疑似肿瘤病例中，建议进行活检确认并通过血清钙测量评估区域/全身转移[1]。

### Sources
[1] Anal Sac Disease in Dogs and Cats - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/anal-sac-disease-in-dogs-and-cats
[2] Disorders of the Rectum and Anus in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-rectum-and-anus-in-dogs
[3] Perianal Fistula in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perianal-fistula-in-dogs
[4] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[5] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs

## 治疗选择和预防

肛门囊炎的管理侧重于保守医疗治疗和在必要时进行手术干预。堵塞的肛门囊应手动轻柔挤压，如果内容物太干，可注入盐水或耵聍溶解剂[1]。对于感染病例，使用抗菌溶液彻底清洁，然后注入类固醇-抗生素软膏提供有效的局部治疗[1]。

全身抗生素治疗针对常见细菌病原体，包括变形杆菌、大肠杆菌和肠球菌，通常给药3周以防止耐药性发展[2]。每8-12小时应用15-20分钟的热敷对脓肿病例有益[1]。在饮食中添加补充纤维增加粪便体积，促进肛门囊自然压迫和排空[1]。

当医疗治疗失败或存在肿瘤时，使用闭合技术的手术切除是适应症[1]。然而，并发症包括阴部神经损伤导致的大便失禁、切除不完全导致的慢性瘘管形成，以及括约肌瘢痕导致的里急后重[1]。

预防措施包括膳食纤维补充和管理可能导致反复发作的基础疾病，如肥胖、过敏或胃肠道疾病[2]。定期监测和早期干预有助于防止进展到需要手术管理的更严重形式。

### Sources
[1] Anal Sac Disease in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/anal-sac-disease-in-dogs-and-cats
[2] Getting to the bottom of anal sac diseases: https://www.dvm360.com/view/getting-to-the-bottom-of-anal-sac-diseases

## 预后

犬肛门囊炎的预后根据治疗方法和基础因素而有显著差异。对于医疗管理，预后通常谨慎至一般，全身抗菌剂显示效果有限，且频繁的治疗失败需要升级到手术干预[1]。

对于需要肛门囊切除术的难治性病例，预后显著改善。最近的研究表明手术干预有良好结果，当采用适当技术时术后并发症最少[2]。完全手术切除后的复发率相对较低，一个队列报告9%的复发率，但不完全切除显著增加复发的可能性[3]。

双侧一期肛门囊切除术可以安全进行，为对保守管理无反应的病例提供极好的长期结果[4]。该手术为慢性、复发性病例提供确定性治疗，这些病例对包括频繁手动挤压、膳食纤维补充和局部抗菌剂-皮质类固醇组合的标准医疗方案无反应[1]。

大多数术后并发症是自限性的或仅需要医疗管理，在最近的研究中所有切口均无重大并发症愈合[5]。长期并发症包括大便失禁、直肠瘘、肛门狭窄和局部复发，尽管当采用适当手术技术时这些并发症的发生率通常很低[6]。

影响恢复的预后因素包括手术切除的完整性、基础过敏状况、胃肠道健康和粪便稠度。与肛周瘘或并发胃肠道疾病相关的病例可能需要额外的管理考虑以获得最佳结果[1]。

### Sources
[1] Just Ask the Expert: Anal sacculitis refractory to standard treatment: https://www.dvm360.com/view/just-ask-expert-anal-sacculitis-refractory-standard-treatment/1000
[2] Minimal complications observed with a modified surgical: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.21.01.0008.xml
[3] Complications associated with modified closed anal: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0155/javma.25.03.0155.pdf
[4] How to perform an anal sacculectomy: https://www.dvm360.com/view/how-perform-anal-sacculectomy
[5] Complications associated with modified closed anal: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0155/javma.25.03.0155.pdf
[6] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0155/javma.25.03.0155.xml
