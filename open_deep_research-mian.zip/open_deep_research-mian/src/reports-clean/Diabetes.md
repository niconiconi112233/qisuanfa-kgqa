# 宠物疾病：糖尿病

糖尿病是影响伴侣动物最常见的内分泌疾病之一，对兽医临床实践和宠物主人管理具有重要意义。本综合报告探讨了犬猫糖尿病的多面性，从涉及犬类自身免疫破坏和猫类淀粉样变性的非传染性病因，到包括犬类白内障和猫类糖尿病神经病变在内的独特临床表现。分析涵盖了关键诊断方法，包括用于鉴别应激性高血糖的果糖胺检测；强调物种特异性饮食管理的循证治疗方案；以及专注于体重控制和早期绝育的预防策略。探讨了肾上腺皮质功能亢进和甲状腺功能亢进等关键鉴别诊断，以及影响糖尿病宠物长期预后和生活质量的预后因素。

## 疾病概述

伴侣动物糖尿病是一种复杂的内分泌疾病，其特征是由胰岛素分泌不足、胰岛素抵抗或两者共同导致的慢性高血糖。在犬类中，I型糖尿病占主导地位，主要由胰腺β细胞的自身免疫破坏引起，需要终身胰岛素治疗。猫类通常发展为II型糖尿病，通常与肥胖、胰腺炎和胰腺胰岛淀粉样变性相关。

**流行病学模式**显示，在临床实践中，糖尿病影响约0.32-1.5%的犬和0.5-2%的猫。犬的发病高峰在7-9岁，猫在8-13岁。母犬表现出更高的易感性，特别是未绝育母犬，因为发情间期的激素影响。在猫中，公猫更常受影响，其中去势公猫风险最高。

**品种易感性**在犬类中包括萨摩耶犬、迷你雪纳瑞犬、迷你贵宾犬、哈巴狗和玩具品种。缅甸猫相比其他猫品种表现出显著更高的糖尿病患病率。风险因素包括肥胖（影响58%的犬和60%的猫）、并发胰腺炎、肾上腺皮质功能亢进，以及使用致糖尿病药物如糖皮质激素和孕激素。

查看现有章节内容和新的参考资料，我将综合信息以加强章节内容，同时保持既定框架。

## 常见病原体

犬猫糖尿病本质上是非传染性的，源于非病原性病因因素而非微生物病原体[1]。在犬类患者中，主要原因是胰腺β细胞的自身免疫破坏，导致需要终身胰岛素治疗的I型糖尿病[2]。犬类其他重要的非传染性原因包括遗传易感性、慢性胰腺炎，以及由糖皮质激素或醋酸甲地孕酮引起的药物性糖尿病[1,3]。

在猫类患者中，最常见的原因是肥胖、胰腺炎，以及最常见的是胰腺β细胞淀粉样变性[2,3]。由胰岛相关多肽（IAPP）引起的淀粉样蛋白沉积导致胰岛素分泌减少和外周胰岛素抵抗，从而引起β细胞的物理破坏[4]。这些情况导致II型糖尿病，在某些情况下可通过饮食调整和口服降糖药物进行管理[2]。

继发感染代表糖尿病患者的重要并发症而非致病因素。由于高血糖诱导的免疫抑制和中性粒细胞功能受损，糖尿病犬猫对细菌和真菌感染的抵抗力降低[4]。常见的继发感染包括尿路感染、脓皮病、支气管肺炎和皮炎[4]。高达40%的糖尿病患者即使没有活动性尿沉渣也可能尿培养阳性[1]。这些继发感染可触发应激激素激活，导致胰岛素抵抗并使糖尿病管理复杂化[1]。

### Sources
[1] Diabetes in dogs- Acute care and long-term management: https://www.dvm360.com/view/diabetes-dogs-acute-care-and-long-term-management
[2] Dietary treatment of diabetes mellitus in dogs and cats: https://www.dvm360.com/view/dietary-treatment-diabetes-mellitus-dogs-and-cats-sponsored-nestle-purina
[3] Diabetes mellitus in dogs and cats (Proceedings): https://www.dvm360.com/view/diabetes-mellitus-dogs-and-cats-proceedings-0
[4] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats

## 临床症状和体征

犬猫糖尿病的临床表现涉及特征性主要症状和物种特异性表现。**临床症状的典型四联征包括多饮、多尿、多食和体重减轻**[1]。当血糖浓度超过肾阈值时（犬约180 mg/dL，猫约280 mg/dL），这些主要症状就会出现[1]。

**在犬类中，白内障经常发生**，代表控制不佳糖尿病的独特并发症[1]。这些晶状体混浊最初沿缝线呈星形模式出现，由葡萄糖通过山梨醇途径代谢引起[1]。白内障可导致失明，在糖尿病猫中很少见。

**猫类在约10%的病例中常见糖尿病神经病变**，表现为跖行姿态、后肢无力和跳跃能力受损[1][2][3]。这种神经病变影响股神经，可从轻微无力发展到完全无法用脚趾行走[3]。一些猫可能表现为食欲减退而非多食，与典型的犬类表现不同[1][2]。

**非典型表现**包括脂质沉积引起的肝肿大、嗜睡、被毛凌乱和肌肉萎缩[1][2]。两个物种都表现出**对细菌和真菌感染的易感性增加**，包括膀胱炎、皮炎和呼吸道感染，原因是中性粒细胞功能受损[1]。

**糖尿病酮症酸中毒（DKA）的并发症**表现为呕吐、厌食、脱水和潜在昏迷[1][3]。猫还可能因并发肝脂沉积症或胰腺炎而出现黄疸[4]。识别这些不同的表现对于及时诊断和管理至关重要。

### Sources
[1] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[2] Feline diabetes mellitus (Proceedings): https://www.dvm360.com/view/feline-diabetes-mellitus-proceedings
[3] Managing complications in diabetic cats: https://www.dvm360.com/view/managing-complications-diabetic-cats
[4] How I treat diabetes in cats: https://www.dvm360.com/view/how-i-treat-diabetes-cats

## 诊断方法

犬猫糖尿病诊断需要持续高血糖和糖尿，正常血糖浓度范围为75-120 mg/dL[1]。葡萄糖的肾阈值在犬中约为180 mg/dL，在猫中约为280 mg/dL[1]。

在猫中，应激性高血糖经常使诊断复杂化，需要多次样本以确认持续高血糖[1]。血清果糖胺浓度是关键诊断工具，反映1-3周的平均血糖水平，在应激性高血糖中保持正常，而在真性糖尿病中升高[2]。

血糖曲线对于监测糖尿病调节和检测并发症如Somogyi现象（低血糖诱导的反跳性高血糖）至关重要[3]。每2小时连续测量8-12小时有助于确定胰岛素有效性、持续时间和血糖最低点[4]。

实验室评估应包括全血细胞计数、血清生化分析、尿分析和尿培养。糖尿病猫通常表现为高血糖、肝酶升高、高胆固醇血症和糖尿[2]。尿培养至关重要，因为12%的糖尿病猫有细菌性尿路感染，许多没有临床症状[2]。

酮体检测对于识别糖尿病酮症酸中毒至关重要。β-羟基丁酸水平>25 mg/dL提示DKA，敏感性100%，特异性87%[5]。与仅检测丙酮和乙酰乙酸的尿试纸相比，便携式酮体仪可提供快速结果。

### Sources

[1] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats

[2] Feline diabetes mellitus (Proceedings): https://www.dvm360.com/view/feline-diabetes-mellitus-proceedings

[3] The latest management recommendations for cats and dogs with nonketotic diabetes mellitus: https://www.dvm360.com/view/latest-management-recommendations-cats-and-dogs-with-nonketotic-diabetes-mellitus

[4] What's new, what's old, and what works in diabetes mellitus (Proceedings): https://www.dvm360.com/view/whats-new-whats-old-and-what-works-diabetes-mellitus-proceedings

[5] Sweet pee new remedy in feline diabetes: https://www.dvm360.com/view/sweet-pee-new-remedy-in-feline-diabetes

## 治疗选择

饮食管理与胰岛素治疗一起构成糖尿病治疗的关键组成部分[1][2]。对于猫，高蛋白、低碳水化合物饮食至关重要，因为它们是专性食肉动物。罐头食品优于干粮，因为它们通常含有较低的碳水化合物含量（<10%干物质基础）和较高的水分含量[1][2]。与喂食高纤维饮食的猫相比，喂食低碳水化合物饮食的猫实现缓解并停用胰岛素的可能性要高两到三倍[1]。

犬类需要不同的饮食管理，高纤维、复合碳水化合物饮食是有益的。这些饮食通过延迟胃排空和葡萄糖吸收来帮助减少餐后高血糖[1]。对于并发胰腺炎或高甘油三酯血症的犬，建议限制脂肪（<12%干物质基础）[1]。

体重管理对两个物种都至关重要，控制性减重每周不应超过体重的2%[4]。饮食配方的一致性对于维持稳定的血糖控制至关重要，因此固定配方的商业饮食优于自制餐食[3]。

喂食时间表应与胰岛素给药协调。犬通常接受两次相等的餐食，间隔十二小时，与胰岛素注射时间一致[2]。猫可能需要更灵活的喂食方法，有些适应每日两次喂食，而其他则保持 grazing 模式[3][6]。

### Sources
[1] Dietary treatment of diabetes mellitus in dogs and cats (Sponsored by Nestle Purina): https://www.dvm360.com/view/dietary-treatment-diabetes-mellitus-dogs-and-cats-sponsored-nestle-purina
[2] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[3] Nutrition and the diabetic pet: https://www.dvm360.com/view/nutrition-and-diabetic-pet/1000
[4] What to feed patients with diabetes: https://www.dvm360.com/view/what-to-feed-patients-with-diabetes
[5] How I treat diabetes in cats: https://www.dvm360.com/view/how-i-treat-diabetes-cats
[6] The state of diabetes: An industry review of diabetes (Sponsored by Abbott Animal Health): https://www.dvm360.com/view/state-diabetes-industry-review-diabetes-sponsored-abbott-animal-health

## 预防措施

体重管理对于预防猫犬糖尿病至关重要。绝育显著降低能量需求20-25%，同时增加食欲，因此绝育后体重控制至关重要[1]。绝育后需要立即调整饮食（减少25-30%卡路里）并停止自由采食以预防肥胖[1]。对于猫，保持体况评分在1-5/9之间并喂食控制份量的餐食可预防与肥胖相关的胰岛素抵抗发展[2]。

在2.5岁前对未绝育母犬进行绝育可预防乳腺肿瘤并消除可能干扰糖尿病管理的生殖激素[3]。早期绝育（第一次发情前）可提供对激素相关并发症的最大保护作用，这些并发症会使糖尿病调节复杂化[3]。

饮食建议侧重于猫的高蛋白、低碳水化合物配方和犬的高纤维、低血糖指数饮食[5]。推荐低血糖指数碳水化合物如高粱和大麦，而应避免易吸收的碳水化合物如大米和玉米糖浆[5]。喂食高蛋白、低碳水化合物饮食的猫更接近专性食肉动物的自然饮食，可能有助于减少葡萄糖不耐受、胰岛素抵抗和肥胖[1]。

定期兽医监测包括每半年体况评估、空腹血糖测量，以及筛查可能诱发糖尿病发展的并发疾病如胰腺炎和尿路感染[4]。通过体重管理计划和饮食调整进行早期干预可防止从葡萄糖不耐受发展为临床糖尿病。

### Sources
[1] Diabetes in dogs- Acute care and long-term management: https://www.dvm360.com/view/diabetes-dogs-acute-care-and-long-term-management
[2] Is that cat too fat? Feline obesity and a program for weight loss: https://www.dvm360.com/view/cat-too-fat-feline-obesity-and-program-weight-loss-proceedings
[3] Performing an ovariectomy in dogs and cats: https://www.dvm360.com/view/performing-ovariectomy-dogs-and-cats
[4] What's new, what's old, and what works in diabetes mellitus: https://www.dvm360.com/view/whats-new-whats-old-and-what-works-diabetes-mellitus-proceedings
[5] Dietary treatment of diabetes mellitus in dogs and cats (Sponsored by Nestle Purina): https://www.dvm360.com/view/dietary-treatment-diabetes-mellitus-dogs-and-cats-sponsored-nestle-purina

## 鉴别诊断

鉴别诊断部分已更新，以综合现有内容与临床来源的其他鉴别特征。

伴侣动物糖尿病的临床表现与几种其他内分泌和代谢疾病重叠，需要通过临床评估和诊断测试进行仔细鉴别[1][2][3]。

**肾上腺皮质功能亢进（库欣综合征）**是主要鉴别诊断，特别是因为它通常在猫中引起胰岛素抵抗和继发性糖尿病[3][5]。患有库欣病的犬表现出多尿、多饮、多食和肌肉无力，与糖尿病患者相似[3][5]。然而，库欣病患者通常表现出特征性皮肤变化，包括脱毛、薄而脆弱的皮肤和皮肤钙质沉着，以及碱性磷酸酶水平升高[3][5]。

**慢性肾病**与糖尿病共享多尿和多饮，但通过升高的血尿素氮、肌酐和磷水平，以及等渗尿和蛋白尿来区分[1]。此外，慢性肾病患者通常表现为等渗尿（比重1.008-1.012），而糖尿病患者通常保持一定的浓缩能力[6]。

**甲状腺功能亢进**主要影响老年猫，表现为尽管多食但体重减轻，与未控制的糖尿病相似[1]。然而，甲状腺功能亢进的猫通常表现出多动、心动过速和甲状腺激素水平升高，与糖尿病患者常见的嗜睡形成对比[2]。

**外分泌胰腺功能不全**可模拟糖尿病的多食和体重减轻症状，特别是在犬中[7]。然而，EPI患者通常表现为脂肪泻、大量粪便和血清胰蛋白酶样免疫反应性低，这与糖尿病 mellitus 不同[7]。

**应激性高血糖**可能使诊断复杂化，特别是在猫中，住院或疾病引起的应激可暂时升高血糖水平[1][3]。这需要重复测试和果糖胺测量进行准确评估。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/downloadpdf/view/journals/javma/259/S2/javma.20.02.0094.pdf
[2] Diabetes Mellitus in Dogs and Cats: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[3] Cushing Syndrome in Animals: https://www.msdvetmanual.com/endocrine-system/the-adrenal-glands/cushing-syndrome-hyperadrenocorticism-in-animals
[4] Cushing Disease in Animals: https://www.merckvetmanual.com/endocrine-system/the-pituitary-gland/cushing-disease-pituitary-dependent-hyperadrenocorticism-in-animals
[5] Cushing's syndrome - Wikipedia: https://en.wikipedia.org/wiki/Cushing's_syndrome
[6] Polyuria and polydipsia: streamlining your veterinary diagnostics: https://www.dvm360.com/view/polyuria-and-polydipsia-streamlining-your-veterinary-diagnostics
[7] Exocrine pancreatic insufficiency in dogs and cats: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
