# 伴侣动物急性充血性心力衰竭

急性充血性心力衰竭是兽医实践中最严重的心血管急症之一，影响犬和猫，可能危及生命。当心脏的代偿机制不堪重负，导致液体在肺部和体腔内积聚时，就会发生这种情况。本报告探讨了急性充血性心力衰竭背后的复杂病理生理学，从细菌性心内膜炎和心丝虫病等感染性原因，到犬猫患者之间不同的独特临床表现。分析了包括NT-proBNP生物标志物和急诊治疗方案在内的关键诊断方法，以及针对高风险品种的预防性筛查计划和与原发性呼吸道疾病进行鉴别的挑战。

## 摘要

犬猫的急性充血性心力衰竭是一种需要立即识别和干预的多方面急症。该病症源于多种病因，包括细菌性心内膜炎、心丝虫病和潜在的心肌病，其物种特异性表现显著影响诊断方法。犬通常表现为咳嗽和运动不耐受，而猫很少咳嗽，可能在疾病晚期表现为更急性发作。

诊断成功很大程度上依赖于NT-proBNP生物标志物（>1725 pmol/L临界值）、用于检测心脏肥大的胸部X光片以及用于确定性心脏评估的超声心动图。急诊治疗以氧疗、呋塞米利尿和硝酸甘油等血管扩张剂为中心，并在有指征时进行胸腔穿刺术等程序性干预。

预防侧重于品种特异性筛查计划，特别是针对易患二尖瓣病的骑士查理王小猎犬和易患扩张型心肌病的杜宾犬。家庭监测睡眠呼吸频率超过30次/分钟，为主人提供了早期检测能力。

鉴别诊断需要与原发性呼吸道疾病进行仔细区分，X光片模式和生物标志物检测被证明是必不可少的。预后因根本原因而有很大差异，在二尖瓣病病例中，使用匹莫苯丹治疗的中位生存时间从140天延长到267天，尽管扩张型心肌病的前景更为谨慎，大多数犬存活6个月至2年。

## 疾病概述

犬猫的急性充血性心力衰竭（CHF）是一种心血管急症，其特征是心脏无法维持足够的血液循环，导致液体积聚和充血 [1]。当严重的、压倒性的心脏病使心脏的代偿机制不堪重负，导致静脉和毛细血管压力升高，引起水肿和渗出时，就会发生CHF [1]。

其病理生理学涉及对心输出量减少的复杂神经内分泌反应，包括肾素-血管紧张素-醛固酮系统激活和交感神经张力增加 [2]。这些代偿机制最初有助于维持血压和器官灌注，但最终导致容量过载和进一步的心功能障碍 [2]。在急性心力衰竭中，在代偿发生之前心源性休克可能占主导地位，其中急性腱索断裂是动物中最常见的原因，导致左心房压力升高和肺水肿 [1]。

虽然小动物急性CHF的具体流行病学数据有限，但充血性心力衰竭是犬猫中最常见的心脏相关急症 [2]。该疾病影响不同年龄的动物，对可能发展为急性CHF的潜在心脏病有明显的品种倾向性。预后因潜在病因、干预时机和治疗反应而有显著差异，从可管理的慢性疾病到需要立即稳定生命体征的危及生命的急症 [2][4]。

### Sources
[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] Cardiac emergencies (Proceedings): https://www.dvm360.com/view/cardiac-emergencies-proceedings
[3] Heart Failure in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/heart-failure-in-dogs
[4] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure

## 常见病原体

犬猫的急性充血性心力衰竭可由各种直接或间接损害心脏功能的传染性病原体引起。虽然病毒原因作为急性CHF的主要原因报道较少，但几种细菌和寄生虫病原体可导致心脏快速失代偿。

**细菌性心内膜炎**是急性CHF最重要的细菌原因。最常分离的细菌包括链球菌属、葡萄球菌属、克雷伯菌属和大肠杆菌 [1]。巴尔通体也被认为是犬主动脉瓣心内膜炎的原因 [1]。这些生物通常感染心脏瓣膜，导致进行性瓣膜破坏和关闭不全，可迅速发展为伴有肺水肿的左心衰竭 [1]。

由犬恶丝虫引起的**心丝虫病**是急性CHF的一个关键寄生虫原因，特别是在犬中 [2]。寄生虫线虫生活在肺动脉和心脏中，引起肺动脉高压和右侧心力衰竭 [2]。在严重情况下，可发展成腔静脉综合征，导致急性心血管衰竭，同时出现后向性和前向性心力衰竭体征 [2]。猫对心丝虫感染更具抵抗力，但可能发展为心丝虫相关呼吸系统疾病（HARD），进而进展为心脏并发症 [2]。

**病毒性心肌炎**可发生在幼年动物中，犬细小病毒在3-6周龄的幼犬中引起心肌炎 [3]。犬瘟病毒也可影响心脏组织，尽管神经系统表现更为常见 [4]。内共生菌沃尔巴克氏体（Wolbachia pipientis），生活在心丝虫内，通过内毒素产生和炎症反应促进发病机制 [2]。

### Sources

[1] Infectious Endocarditis in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats

[2] Heartworm Disease in Dogs, Cats, and Ferrets: https://www.merckvetmanual.com/circulatory-system/heartworm-disease/heartworm-disease-in-dogs-cats-and-ferrets

[3] Managing the sick neonate (Proceedings): https://www.dvm360.com/view/managing-sick-neonate-proceedings

[4] Infectious neurologic diseases of puppies and kittens (Proceedings): https://www.dvm360.com/view/infectious-neurologic-diseases-puppies-and-kittens-proceedings

## 临床症状和体征

伴侣动物的急性充血性心力衰竭表现出特征性的心肺体征，这些体征在物种和个体病例之间有所不同。最常见的临床表现包括呼吸窘迫、运动不耐受和咳嗽 [1]。

**典型体征**
当左心房压力超过20 mmHg形成肺水肿时，呼吸窘迫表现为呼吸急促和呼吸困难 [1]。犬通常表现为咳嗽、呼吸困难和运动不耐受作为最常见的体征 [4]。许多患有左侧充血性心力衰竭的犬也可能因流向大脑的血流和氧气输送不足而经历昏厥 [4]。

**物种特异性差异**
犬猫在临床表现上存在重要差异。虽然犬通常表现出呼吸急促，主人最初可能察觉不到，导致在呼吸困难发展时看似急性发作 [1]。在暴发性肺水肿病例中，犬也可能表现为从鼻部和口腔流出血性液体 [3]。相比之下，患有心脏病的猫很少表现为咳嗽，咳嗽更常与潜在的呼吸系统疾病相关 [6]。与犬隐匿性发病相比，猫更可能在疾病晚期表现为急性发作 [6]。此外，患有充血性心力衰竭的猫在听诊时并不总能听到湿啰音 [6]。

**非典型表现**
一些动物可能表现为运动能力或耐力下降的细微体征，而不是明显的呼吸窘迫。在代偿发生前的急性病例中，心源性休克可能占主导地位，尽管急性腱索断裂仍然是动物急性心力衰竭最常见的原因 [1]。猫可能表现出呼吸急促和低温，由于急性甲状腺毒症引起的血栓栓塞性疾病而检测到肢体运动功能丧失 [7]。

### Sources
[1] Merck Veterinary Manual Heart Failure in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure
[3] Merck Veterinary Manual Heart Failure in Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/heart-failure-in-cats
[4] Heart Failure in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/heart-failure-in-dogs
[5] Lecture Link: Feline cardiology review: https://www.dvm360.com/view/lecture-link-feline-cardiology-review
[6] Unusual manifestations of feline hyperthyroidism and thyroid storm: https://www.dvm360.com/view/unusual-manifestations-feline-hyperthyroidism-and-thyroid-storm-proceedings

## 诊断方法

急性充血性心力衰竭的诊断需要多模式方法，结合临床评估和特定的诊断测试。体格检查是基础，评估呼吸频率、脉搏质量、粘膜颜色以及听诊奔马律、杂音和肺湿啰音 [1]。

实验室检测包括心脏生物标志物，特别是NT-proBNP和心肌肌钙蛋白I，这些指标已有足够的研究支持临床推荐 [1]。NT-proBNP水平高于1725 pmol/L在区分呼吸困难犬的CHF和原发性呼吸系统疾病方面显示出高敏感性（88%）和特异性（77%）[2]。升高的NT-proBNP（>1500 pmol/L）结合胸部X光片变化可预测3-6个月内CHF风险增加 [2]。

胸部X光片对于使用椎体心脏评分评估心脏大小和检测肺水肿模式仍然是必不可少的 [3]。X光片可识别心脏肥大、肺静脉充血以及与左侧心力衰竭相关的特征性间质至肺泡浸润 [3]。

超声心动图提供确定性心脏评估，确认初步诊断并评估腔室扩大、壁厚、收缩/舒张功能和瓣膜异常 [3]。它区分不同类型的心肌病，并通过缩短分数等测量量化疾病严重程度。

心电图专门诊断心律失常，包括房颤、室性心动过速和与心力衰竭相关的传导障碍 [3]。血压测量完成心血管评估，因为低血压可能表明需要立即干预的心源性休克 [3]。

### Sources
[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] NT-proBNP Testing: An important tool for veterinary practitioners: https://www.dvm360.com/view/nt-probnp-testing-an-important-tool-for-veterinary-practitioners
[3] Diagnosis of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/diagnosis-of-cardiovascular-disease-in-animals

## 治疗选择

急性充血性心力衰竭需要立即稳定，采用多模式方法，结合氧疗、药物干预和支持性护理 [1]。

**氧疗**构成急诊治疗的基石。在检查期间应立即给予流氧，然后采用更有效的给药方法，包括鼻导管（50-100 ml/kg/min）、氧罩或氧舱 [1]。患有严重左侧CHF和肺水肿的犬可能需要通过面罩或鼻管补充氧气 [2]。

**药物干预**包括呋塞米作为主要利尿剂，以4-8 mg/kg静脉注射或肌肉注射推注给药，或以0.66-1 mg/kg/hr静脉注射持续输注 [1]。目标是每30-60分钟重复给药，通过减轻体重5-7%直到呼吸改善 [1]。 

**一氧化氮供体**提供立即的血管扩张益处。硝酸甘油软膏（根据患者大小0.25-1英寸）降低肺血管压力 [1]。对于难治性病例，硝普钠（2-10 μg/kg/min静脉注射）提供平衡的动脉和静脉扩张，但需要监测血压 [1]。

**正性肌力药物**如多巴酚丁胺（2-20 μg/kg/min）可改善扩张型心肌病病例的心脏收缩力，但由于心律失常风险，需要仔细的心电图监测 [1][2]。低剂量吗啡（0.025-0.05 mg/kg静脉注射）可为犬提供静脉扩张和焦虑减轻 [1]。

**程序性干预**包括胸腔穿刺术用于胸腔积液清除和心包穿刺术用于心包积液病例 [1]。这些程序通过改善通气提供立即的症状缓解。

**护理**强调通过轻柔处理和避免不必要的约束来最小化患者压力 [1][2]。

### Sources
[1] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure
[2] Heart Failure in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 预防措施

急性充血性心力衰竭的预防主要集中在管理易感条件上，而不是疫苗接种方案，因为CHF是由潜在心脏病引起的综合征，而不是传染性病原体 [1]。

**品种特异性筛查计划**
高风险品种需要定期心脏监测。骑士查理王小猎犬是最易患二尖瓣病的品种，贵宾犬、约克夏梗和吉娃娃也应接受常规超声心动图筛查 [1]。杜宾犬、大丹犬、爱尔兰猎狼犬和苏格兰猎鹿犬需要DCM筛查，因为大约50%的杜宾犬受影响 [1]。华盛顿州立大学已经开发了拳师犬心肌病的基因检测来筛查种犬 [1]。NT-proBNP检测可以在CHF发作前发现隐匿性DCM，特别是当与动态心电图监测结合时 [3]。

**家庭监测计划**
主人进行睡眠呼吸频率（SRR）监测的教育提供了有效的早期检测。正常犬的SRR<30次/分钟，因此超过此阈值的呼吸频率异常高 [3]。许多兽医心脏病专家建议对患有亚临床心脏病的犬进行家庭呼吸频率监测 [3]。如果升高的SRR对呋塞米给药有反应，则可以诊断心源性肺水肿 [3]。

**易感条件的管理**
预防集中在控制心脏肥大的继发原因。中老年猫需要定期监测高血压和甲状腺功能亢进，因为这些条件会加速心脏病进展 [2]。猫的牛磺酸补充已基本消除了扩张型心肌病 [2]。遵循预防健康方案的定期兽医检查能够早期发现心脏病 [4]。

### Sources
[1] Acquired cardiac diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings
[2] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[3] Heart Failure in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[4] Preventative Health Care for Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/management-and-nutrition/preventative-health-care-and-husbandry-in-small-animals/preventative-health-care-for-small-animals

## 鉴别诊断

在急诊实践中区分急性充血性心力衰竭与原发性呼吸系统疾病至关重要，因为治疗方法差异显著。原发性呼吸系统疾病经常模拟CHF，特别是小型犬的慢性支气管炎，表现为响亮的、鹅鸣样咳嗽，与柔和的心脏性咳嗽相比 [1] [7]。 

NT-proBNP生物标志物提供关键的诊断区分，临界值>1725 pmol/L在区分呼吸困难犬的CHF和原发性呼吸系统疾病方面显示出88%的敏感性和77%的特异性 [3]。X光片检查结果有助于区分病因：心源性肺水肿通常表现为肺门至背侧分布伴左心房增大，而原发性肺病显示不同的浸润模式 [4] [7]。

肺炎表现出与CHF的柔和、非生产性心脏性咳嗽不同的独特临床症状，包括发热、嗜睡和排痰性咳嗽 [8]。吸入性肺炎特别影响重力依赖性肺叶，在X光片上具有特征性的锥形实变 [8]。猫哮喘产生呼气性呼吸困难伴喘息，与CHF的吸气性窘迫形成对比 [9] [10]。在猫中，慢性支气管炎产生粗糙的湿啰音，而CHF的呼吸变化细微，胸腔积液通常伴随猫心力衰竭 [5]。

关键鉴别因素包括X光片上的心脏增大模式、肺静脉充血的存在以及对利尿剂治疗的反应 [4]。

### Sources
[1] Heart Failure in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] New perspectives on diagnosis and treatment of canine congestive heart failure (Proceedings): https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings
[3] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure
[4] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings
[5] Back to basics: clinical cardiovascular exam and diagnostic testing (Proceedings): https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings
[6] Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[7] Aspiration Pneumonia in Pets and People: https://www.dvm360.com/view/aspiration-pneumonia-in-pets-and-people
[8] Understanding and treating feline asthma (Proceedings): https://www.dvm360.com/view/understanding-and-treating-feline-asthma-proceedings
[9] Update on feline asthma (Proceedings): https://www.dvm360.com/view/update-feline-asthma-proceedings

## 预后

犬急性充血性心力衰竭的预后因潜在病因、疾病严重程度和治疗反应而有显著差异。在急性心力衰竭中，心源性休克在代偿发生之前可能占主导地位，尽管急性腱索断裂是最常见的原因，通常导致左心房压力升高引起肺水肿 [1]。

几个重要因素影响犬急性CHF的预后。患有严重左侧充血性心力衰竭和肺部液体（肺水肿）的犬可能无法获得足够氧气，需要立即干预 [5]。对于患有扩张型心肌病的犬，大多数受影响犬在心力衰竭诊断后6个月至2年内死亡，尽管一些病情非常严重的犬经治疗后显著改善，可以舒适地生活较长时间 [3]。

QUEST试验证明匹莫苯丹治疗改善了生存时间，在由黏液瘤性二尖瓣病引起CHF的犬中，将中位生存时间从140天延长到267天 [2]。在患有扩张型心肌病的犬中，历史上约65%在心力衰竭诊断后8周内死亡，但匹莫苯丹现在可能将某些病例的生存时间延长数月 [3]。与患有扩张型心肌病的犬相比，患有二尖瓣反流的犬显示出更好的整体预后 [3]。

早期识别和积极治疗可显著改善急性CHF病例的结果和生存时间。几项良好的对照临床试验表明，与标准治疗相比，ACE抑制剂治疗增加了生存率 [5]。然而，对于表现为急性CHF的动物，总体预后仍然谨慎至不良，特别是当发生动脉血栓栓塞等并发症时 [1]。

### Sources
[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[2] New perspectives on diagnosis and treatment of canine congestive heart failure (Proceedings): https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings
[3] Managing dilated cardiomyopathy (Proceedings): https://www.dvm360.com/view/managing-dilated-cardiomyopathy-proceedings
[4] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[5] CHF: What works and what doesn't? (Proceedings): https://www.dvm360.com/view/chf-what-works-and-what-doesnt-proceedings
