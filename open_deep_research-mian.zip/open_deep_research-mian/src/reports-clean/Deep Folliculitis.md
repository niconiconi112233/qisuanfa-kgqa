# 伴侣动物深部毛囊炎

深部毛囊炎是一种严重的细菌性皮肤感染，病变范围超出浅表毛囊，延伸至更深的真皮结构，主要影响犬类，偶见于猫类。当浅表感染通过受损的毛囊壁进展，导致细菌侵入周围组织时，就会发生此病。与浅表脓皮症不同，深部毛囊炎由于其可能导致瘢痕形成、全身性疾病和治疗抵抗，需要积极的治疗干预。本报告探讨了深部毛囊炎的病理生理学和临床管理，涵盖从细胞学到细菌培养的诊断方法、包括抗生素选择和疗程在内的治疗方案，以及专注于过敏和内分泌病等潜在诱发因素的预防策略。

## 疾病概述

深部毛囊炎是一种严重的细菌感染，病变范围超出浅表毛囊，延伸至更深的真皮结构，主要影响犬类，偶见于猫类[1][2]。当浅表毛囊感染通过破损的毛囊壁进展，导致细菌侵入周围真皮组织时，就会发生此病[2]。

当宿主防御机制失效或潜在诱发因素损害皮肤屏障时，深部毛囊炎会从浅表细菌性毛囊炎进展而来[2][3]。其病理生理学涉及细菌通过受损的毛囊上皮穿透，导致深部真皮炎症、毛囊破裂和潜在的蜂窝织炎[2][7]。这比浅表脓皮症表现为更严重的病症，需要积极的治疗干预。

该病主要由*伪中间葡萄球菌*（*Staphylococcus pseudintermedius*，前称*S. intermedius*）引起，这是犬类细菌性皮肤感染的主要病原体[2][3][7]。继发性细菌入侵者可能包括革兰氏阴性菌，如*铜绿假单胞菌*（*Pseudomonas aeruginosa*）、*大肠杆菌*（*Escherichia coli*）或*变形杆菌*属（*Proteus*），特别是在慢性或治疗抵抗性病例中[7]。

深部毛囊炎总是继发于潜在的诱发条件，包括蠕形螨病、过敏性皮炎、内分泌病（肾上腺皮质功能亢进、甲状腺功能减退）、免疫抑制或解剖因素[2][3][7]。如果管理不当，该病可能导致显著的发病率风险，包括瘢痕形成、全身性疾病和治疗抵抗。

### Sources
[1] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[2] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[3] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[7] Staphylococcal skin diseases-an update: https://www.dvm360.com/view/staphylococcal-skin-diseases-update-proceedings

查看现有内容和资料来源，我需要综合关于深部毛囊炎真菌病因和其他微生物罕见作用的信息，同时建立在已提供的全面细菌病原体信息基础上。

## 常见病原体

深部毛囊炎主要由细菌引起，其中伪中间葡萄球菌是犬类病例中最主要的病原体[1]。这种生物以前被归类为中间葡萄球菌，通常产生β-内酰胺酶，是大多数犬类皮肤感染的主要致病因子[1]。

其他涉及深部毛囊感染的葡萄球菌种类包括金黄色葡萄球菌（S. aureus）、施氏葡萄球菌（S. schleiferi）和猪葡萄球菌（S. hyicus）[1]。施氏葡萄球菌有凝固酶阳性（施氏葡萄球菌凝固酶亚种）和凝固酶阴性两种变种，后者具有人畜共患潜力[2]。这些种类表现出不同的抗菌素耐药性特征，其中伪中间葡萄球菌和金黄色葡萄球菌比施氏葡萄球菌凝固酶亚种表现出更强的耐药性[1]。

继发性细菌入侵者常定植于受损的毛囊环境。包括变形杆菌属、假单胞菌属和大肠杆菌在内的革兰氏阴性菌在皮肤感染中充当机会性病原体[1]。与铜绿假单胞菌相关的深部细菌性毛囊炎在耐药性脓皮症病例中已成为日益关注的问题[3]。在猫中，多杀性巴氏杆菌和β-溶血性链球菌是常见的表皮分离菌[1]。

真菌病原体偶尔也会导致深部毛囊感染。皮肤癣菌，特别是犬小孢子菌（Microsporum canis），可以侵入毛囊并引起深部炎症反应，尤其是在免疫功能低下的动物中[4]。皮肤癣菌的结节形式（脓癣）可能模拟细菌性深部毛囊炎，需要通过真菌培养进行明确鉴别[4]。

耐甲氧西林葡萄球菌的出现显著增加了治疗的复杂性[1]。耐甲氧西林伪中间葡萄球菌（MRSP）对所有β-内酰胺类抗菌药物表现出耐药性，并且通常呈现多重耐药模式[1]。

### Sources
[1] Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[2] Skin infections, MRSI, perpetuating factors,topicals, antibiotics and more (Proceedings): https://www.dvm360.com/view/skin-infections-mrsi-perpetuating-factorstopicals-antibiotics-and-more-proceedings
[3] Resistant pyoderma (Proceedings): https://www.dvm360.com/view/resistant-pyoderma-proceedings
[4] Clinical Exposures: Canine dermatophyte infection: https://www.dvm360.com/view/clinical-exposures-canine-dermatophyte-infection

## 临床症状和体征

深部毛囊炎表现为特征性的疼痛和炎症性病变，这使其与浅表感染相区别。犬类深部脓皮症的标志是疼痛、结痂、异味以及血液和脓液的渗出[3]。该病表现为明显的深部真皮炎症、渗出，并且在局部或区域常伴有引流窦道[1]。深部脓皮症的特点是中度至重度炎症伴有脓性渗出物，形成疼痛性病变，患者不愿触摸。

结痂和渗出是深部毛囊炎的显著特征。原发性病变包括结节、出血性大疱和由浆液血性至脓性渗出物组成的引流窦道[2]。还可能出现红斑、肿胀、溃疡、出血性痂皮和大疱、脱毛以及伴有浆液血性或脓性渗出物的引流窦道[3]。炎症过程在受影响区域形成厚痂，特别是当继发性细菌感染与毛囊炎症同时发生时。

深部毛囊炎通常影响特定的身体区域，具有可预测的分布模式。口鼻梁、下巴、肘部、跗部、趾间区和膝关节外侧更容易发生深部感染[3]。在某些情况下，病变可能扩展到其他躯干区域，造成更广泛的炎症变化。

虽然尚未明确确定深部毛囊炎本身有特定的品种易感性，但某些品种对导致深部感染的疾病表现出更高的易感性。金毛寻回犬和圣伯纳犬有一种独特的深部毛囊炎和毛囊破裂形式，影响面部，需要积极的抗生素治疗而非抗炎治疗[2]。

当潜在的诱发因素未得到控制时，深部毛囊炎常代表从浅表细菌感染的进展。该病通常与蠕形螨病[3]、内分泌疾病或损害皮肤自然防御机制的免疫抑制性疾病相关[2]。

### Sources

[1] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings

[2] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings

[3] Pyoderma in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats

## 诊断方法

深部毛囊炎的临床检查始于在强光下进行彻底的视觉和触觉评估[1]。原发性病变包括结节、出血性大疱和由浆液血性至脓性渗出物组成的引流窦道，通常分布在鼻梁、下巴、肘部、跗部和趾间区[2]。

**深层皮肤刮片**是必要的诊断工具，在所有出现毛囊病变的病例中进行，以排除蠕形螨病[2][4]。刮片应足够深以引起毛细血管出血，并针对多个病变部位[1]。使用镊子拔毛可以补充刮片检查，特别适用于面部和爪子等难以刮取的区域[1]。

**细胞学检查**通过印片涂片有助于区分感染性与免疫介导性原因。含有细胞内细菌的变性中性粒细胞表明存在需要抗生素治疗的细菌感染，而化脓性肉芽肿性炎症可能提示深部脓皮症或真菌感染[2][7]。

**细菌培养和药敏试验**对于反应不佳的病例、细胞学检查发现杆状菌的深部脓皮症或全身性患病动物至关重要[2][4]。应要求采用最低抑菌浓度（MIC）方法而非纸片扩散试验，以指导正确的抗生素剂量[2]。在取样前应停用全身性和局部药物至少72小时[1]。

**皮肤活检**适用于强烈怀疑蠕形螨病但皮肤刮片为阴性的情况，特别是对于沙皮犬或斗牛犬等皮肤增厚的品种[1]。当病变严重或对适当治疗无反应时，活检也有助于区分深部毛囊炎与其他疾病[1]。

### Sources

[1] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[2] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Resistant pyoderma: https://www.dvm360.com/view/resistant-pyoderma-proceedings
[4] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[5] Dermatologic diagnostics: maximizing results from skin scrapings to biopsies: https://www.dvm360.com/view/dermatologic-diagnostics-maximizing-results-skin-scrapings-biopsies-proceedings
[6] Diagnosis of Skin Diseases in Small Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/diagnosis-of-skin-diseases-in-small-animals
[7] "I can't believe it's not better!": Dermatology look-alikes: https://www.dvm360.com/view/i-cant-believe-its-not-better-dermatology-look-alikes-proceedings

## 治疗方案

深部毛囊炎的有效管理需要多方面的方法，结合全身性抗生素、局部治疗和纠正根本病因[1]。全身性抗生素的选择应基于细菌培养和药敏试验，一线选择包括头孢氨苄（10-15 mg/kg BID-TID）、头孢泊肟（5-10 mg/kg SID）或克林霉素（5-11 mg/kg BID）[2]。

治疗持续时间至关重要，深部脓皮症至少需要6周，或在临床症状完全消退后再持续21天，以时间较长者为准[2]。当存在多种敏感选择时，应使用效价比（折点/MIC）来指导抗生素选择[1]。

耐甲氧西林葡萄球菌（MRSA/MRSP/MRSS）感染带来特殊挑战。在显示红霉素耐药性的病例中应避免使用克林霉素，因为存在诱导性耐药机制[2]。替代抗生素可能包括甲氧苄啶-磺胺甲恶唑、氯霉素或利福平，具体取决于敏感性模式[5]。

局部抗菌治疗显著提高治疗效果。氯己定香波（仅需1-2分钟接触时间）或过氧化苯甲酰制剂应每2-3天使用一次[1][5]。积极的局部治疗有时可以在不使用全身性抗生素的情况下解决感染[5]。

解决潜在诱因对预防复发至关重要。这包括管理超敏反应、内分泌病和其他诱发因素[2]。如果不治疗根本原因，即使进行了适当的抗菌治疗，细菌感染也很可能复发。

### Sources
[1] Antibiotic Selection in Pyoderma - dvm360: https://www.dvm360.com/view/antibiotic-selection-in-pyoderma
[2] Diagnosing and treating canine bacterial pyodermas - dvm360: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[5] Managing MRSA, MRSP, and MRSS dermatologic infections in pets: http://veterinarymedicine.dvm360.com/managing-mrsa-mrsp-and-mrss-dermatologic-infections-pets

## 预防措施

预防深部毛囊炎需要全面的方法，重点在于控制基础疾病和实施适当的长期维持策略。最重要的预防措施是识别和管理基础过敏性疾病，因为这些是最常见的诱因[1]。

**过敏性疾病管理**

环境过敏约占导致脓皮症病例的60%，其次是食物过敏和跳蚤过敏性皮炎[2]。在流行地区，全年进行全面的跳蚤控制至关重要，利用异噁唑啉类等全身性产品提供长期保护[4]。食物过敏需要使用新蛋白或水解蛋白饮食进行饮食排除试验，并维持8-10周[2]。

**内分泌疾病控制**

内分泌疾病如甲状腺功能减退和肾上腺皮质功能亢进显著增加宠物复发性脓皮症的风险[2]。定期监测和适当的激素替代治疗有助于维持正常的皮肤屏障功能和免疫反应。

**环境和护理调整**

适当的护理习惯至关重要，特别是在温暖、潮湿且容易发生细菌过度生长的区域[2]。定期使用含有氯己定或过氧化苯甲酰的抗菌香波洗澡可以减少细菌定植[5]。局部抗菌治疗应每周使用1-2次以治疗感染，然后每月使用2-4次以预防复发[5]。当诊断为皮肤癣菌病时，环境消毒变得至关重要，需要机械清除有机物质，然后使用适当的消毒剂[3]。

**长期维持**

成功的预防需要解决整个皮肤环境，包括并发的马拉色菌皮炎管理和保持最佳营养[2]。对宠物主人进行关于长期管理方案依从性的教育对于预防复发至关重要。

### Sources
[1] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[2] Merck Veterinary Manual Pyoderma in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[3] Merck Veterinary Manual Dermatophytosis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[4] Merck Veterinary Manual Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[5] Topical therapies in veterinary dermatology: https://www.dvm360.com/view/topical-therapies-in-veterinary-dermatology

## 鉴别诊断

多种疾病表现出与深部毛囊炎相似的临床体征，需要通过临床表现、诊断测试和治疗反应进行仔细鉴别。最重要的鉴别诊断包括蠕形螨病、皮肤癣菌病、浅表脓皮症以及天疱疮等自身免疫性疾病[1]。

**蠕形螨病**常与深部脓皮症同时发生，特别是在涉及继发性细菌感染的病例中。深部毛囊炎可能与蠕形螨病相关，尤其是当有穿透性伤口或严重急性湿性皮炎病史时[1]。鉴别特征是通过深层皮肤刮片鉴定出蠕形螨，这在所有疑似深部毛囊炎病例中都必须进行[2]。

**皮肤癣菌病**的表现可能与细菌性毛囊炎相似，特别是由毛癣菌属引起的脓疱性皮肤癣菌病。这种真菌感染在临床和组织病理学上可能与深部毛囊炎完全相同[3]。鉴别需要进行皮肤癣菌培养和活检样本的PAS染色以识别真菌成分[4]。

**浅表与深部脓皮症**的区分对于适当治疗至关重要。浅表细菌性毛囊炎主要累及表皮和毛囊，在躯干和腹部表现为丘疹、脓疱和表皮领圈状病变[6]。深部脓皮症延伸至真皮，具有特征性的结节、出血性大疱、引流窦道，并影响鼻梁、下巴、肘部和趾间等区域[2]。

当存在脓疱和结痂时，应考虑**落叶型天疱疮**，特别是当影响面部、耳朵和脚垫时。这种自身免疫性疾病在临床和组织病理学上都难以与细菌性脓皮症区分[4]。细胞学涂片中存在棘层松解细胞以及对免疫抑制治疗的阳性反应有助于将天疱疮与感染性疾病区分开来[3]。

### Sources
[1] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings
[2] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Canine and feline pemphigus foliaceus: Improving your chances of successful outcome: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome
[4] Managing cats with facial pruritus: https://www.dvm360.com/view/managing-cats-with-facial-pruritus
[5] Diseases of the foot (Proceedings): https://www.dvm360.com/view/diseases-foot-proceedings
[6] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats

## 预后

当实施适当的抗菌治疗并控制潜在的诱发因素时，深部毛囊炎通常具有良好的预后[1]。然而，治疗持续时间对成功结果至关重要，全身性抗生素通常需要至少6周，或在临床症状完全消退后再持续21天，以时间较长者为准[1][4]。某些病例可能需要8-12周的延长治疗期，特别是患有并发全身性疾病的猫[8]。

最重要的预后因素包括识别和管理基础疾病，如过敏、内分泌病或免疫抑制[6]。未能解决诱发因素会显著增加复发率[1][4]。某些具有品种易感性的犬，包括杜宾犬、牛头梗和斯塔福德郡梗，可能发展出过度瘢痕形成，这会使病情复杂化并恶化长期预后[5]。

并发症可能包括严重深部感染中的全身性菌血症，特别是当涉及耐甲氧西林葡萄球菌菌株时[6]。显微镜下可能出现毛囊周围纤维化，而慢性病例在治疗疗程不足时有发展出抗生素耐药性的风险[1][4]。在猫中，复发性难愈性深部脓皮症可能表明存在由猫免疫缺陷病毒或猫白血病病毒等疾病引起的潜在免疫抑制，显著影响预后[8][9]。

### Sources

[1] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[2] Questioning the duration of systemic antimicrobial therapy: https://avmajournals.avma.org/view/journals/javma/260/10/javma.22.03.0113.xml
[3] Photobiomodulation with fluorescent light energy: https://avmajournals.avma.org/view/journals/javma/263/7/javma.24.12.0820.pdf
[4] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[5] Got a pyoderma? Step away from the systemics: https://www.dvm360.com/view/got-pyoderma-step-away-systemics
[6] Merck Veterinary Manual Pyoderma in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[7] Topical treatments for pyoderma: https://www.dvm360.com/view/topical-treatments-for-pyoderma
[8] Merck Veterinary Manual Pyoderma in Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/pyoderma-in-cats
[9] Infectious skin disease in cats: https://www.dvm360.com/view/infectious-skin-disease-cats-more-you-realized-proceedings
