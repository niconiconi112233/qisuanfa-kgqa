# 伴侣动物的急性结肠炎

急性结肠炎以大肠的快速发炎为特征，是伴侣动物临床实践中一种常见且具有临床重要性的疾病。这种炎症性疾病表现为带血、黏液性腹泻，伴有紧迫感和频率增加，通常给宠物和主人带来相当大的痛苦。虽然许多病例会自行缓解，但正确的识别和管理对于获得最佳结果和预防并发症至关重要。

本综述全面探讨了急性结肠炎的多因素性质，从弯曲杆菌和梭菌等传染性病原体到品种特异性疾病（如拳师犬的肉芽肿性结肠炎）。报告涵盖了基本诊断方法，包括先进的粪便检测和结肠镜检查；结合饮食管理和靶向治疗的循证治疗方案；以及影响恢复率的预后因素，在适当管理的病例中恢复率可达70-90%。

## 疾病概述

急性结肠炎是结肠（大肠）的快速发炎，其特征是大肠性腹泻伴有黏液、血液和排便紧迫感增加[1]。该病是结肠炎的一种形式，可根据持续时间分为急性或慢性，急性病例突然发生，慢性病例持续至少3周[1]。

结肠炎在犬和猫中都很常见[1]。大多数患病的犬是中年犬，无性别偏好[1]。然而，感染率因生活环境而异，在救援机构和寄养犬舍中的犬患病率最高[2]。患有细菌相关急性结肠炎的犬，特别是弯曲杆菌感染，在6个月以下、受应激、卫生条件差或伴有寄生虫以及食用自制饮食的动物中患病率增加[2]。

在大多数病例中，根本原因仍然未知[1]。可疑的诱发因素包括传染性病原体（细菌、寄生虫、真菌）、创伤性损伤、尿毒症毒素和过敏反应[1]。发病机制可能涉及黏膜免疫调节缺陷，即对肠腔内的饮食或细菌因素产生过度的免疫反应[1]。遗传倾向以及先前传染性或寄生虫疾病的后遗症也可能起作用[1]。炎症破坏了正常的结肠功能，减少水和电解质的吸收，同时改变运动模式[1]。

### Sources
[1] Colitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[2] Bacterial diarrhea and related public health concerns: https://www.dvm360.com/view/bacterial-diarrhea-and-related-public-health-concerns-proceedings

## 常见病原体

多种传染性病原体可引起犬和猫的急性结肠炎，其中细菌、病毒和寄生虫病原体最具临床意义。

**病毒病原体**包括犬细小病毒（CPV）和犬冠状病毒，主要影响年轻、未接种疫苗的犬[1]。CPV引起严重肠炎，临床症状在感染后5-7天内出现，常伴有出血性腹泻和全身性疾病[1]。猫泛白细胞减少症病毒可在猫中引起类似的胃肠道症状[2]。

**细菌原因**多种多样，包括几个重要菌种。产气荚膜梭菌，特别是产生netF毒素的菌株，与急性出血性腹泻综合征相关[4]。空肠弯曲杆菌通常影响生活在拥挤环境中的幼年动物，导致水性至出血性腹泻[6]。沙门氏菌可引起急性出血性胃肠炎，伴有发热和败血症等全身症状，尽管无症状携带者很常见[6]。大肠杆菌，特别是致病性菌株，可引起肉芽肿性结肠炎，尤其在年轻的拳师犬中[6]。

**寄生虫和原生动物病原体**经常导致急性结肠炎。贾第鞭毛虫属在犬和猫中都很常见，引起吸收不良和腹泻[2][6]。微小隐孢子虫和猫隐孢子虫可引起从无症状携带到严重吸收不良综合征的一系列疾病，尤其在幼年动物中[6]。球虫属，包括各种等孢球虫，通常影响4-12周龄的幼犬和幼猫[3]。肠道蠕虫如钩虫也可通过黏膜损伤导致结肠炎[7]。

### Sources

[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[2] Introduction to Digestive Disorders of Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/introduction-to-digestive-disorders-of-dogs
[3] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs
[4] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[5] Antibiotics in canine GI disease: when to use and when to ditch: https://www.dvm360.com/view/antibiotics-in-canine-gi-disease-when-to-use-and-when-to-ditch
[6] Parasitic and infectious causes of vomiting and diarrhea in dogs and cats: https://www.dvm360.com/view/parasitic-and-infectious-causes-vomiting-and-diarrhea-dogs-and-cats
[7] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 临床症状和体征

急性结肠炎最常见的临床症状是**大肠性腹泻**，其特征为黏液、血便（血便）和里急后重（排便不尽感）[1]。患病动物通常表现为**排便紧迫感和频率增加**，每次排便的粪便量减少[1]。

**典型表现**包括血性黏液性腹泻，在严重病例中常被描述为类似"覆盆子果酱"[1][5]。在急性出血性腹泻综合征中，犬可能表现出**突发性大量出血性腹泻**，伴有呕吐、厌食、嗜睡和腹痛[5]。排便时可能出现疼痛，并伴有腹部不适[1]。临床症状通常**初期时好时坏**，但如果不治疗通常会进展[1]。

**非典型表现**可能发生，约25%的病例中一些犬表现为非出血性腹泻[1]。**幼犬和小型或玩具品种犬**（约克夏梗、迷你杜宾犬、迷你雪纳瑞）在急性出血性腹泻综合征中比例过高[5]。体重减轻和呕吐在单纯结肠炎中不常见，但当小肠受累时可能出现[1]。

**品种特异性模式**在肉芽肿性结肠炎（组织细胞性溃疡性结肠炎）中很明显，该病主要影响4岁以下的年轻**拳师犬和法国斗牛犬**[1]。这种情况表现为慢性、治疗难治性大肠性腹泻，伴有明显的体重减轻和恶病质[1]。

**体格检查结果**在大多数结肠炎病例中通常不明显[1]。然而，严重受影响的动物可能显示脱水迹象，直肠检查可能发现增厚、疼痛的黏膜并出血[1]。

### Sources

[1] Merck Veterinary Manual Colitis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[2] Merck Veterinary Manual Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs

## 诊断方法

诊断急性结肠炎需要系统的方法，结合临床评估和适当的实验室及影像学技术[1]。初步评估应包括详细的病史采集、直肠触诊的体格检查和全面的粪便分析[1]。

**粪便检查**是诊断的基石。基本检查包括直接盐水涂片检测贾第鞭毛虫滋养体和真菌元素（荚膜组织胞浆菌、致病水霉），使用硫酸锌离心浮聚法鉴定寄生虫（犬中的鞭虫），以及猫中胎儿三毛滴虫的PCR检测[1]。粪便细胞学可揭示炎症细胞、肿瘤细胞和传染性病原体，高倍镜下每视野超过3-4个孢子提示产气荚膜梭菌肠毒素中毒[4]。

**实验室诊断**包括CBC、生化分析和尿液分析以排除全身性疾病。慢性结肠炎病例的结果通常正常，但外周嗜酸性粒细胞增多可能提示嗜酸性粒细胞性结肠炎或寄生虫感染[1]。猫的额外检测应包括FeLV/FIV状态和适龄甲状腺水平检测[1]。

**影像学检查**提供有价值的结构信息。常规腹部X线片通常正常，但造影研究可能显示肠腔狭窄提示浸润性疾病。超声检查允许观察结肠黏膜、局部病变和淋巴结评估[1]。

**高级诊断**包括结肠镜检查用于直接黏膜检查和活检采集。应从升结肠、横结肠和降结肠获取多个样本，无论肉眼外观如何，因为肉眼所见与组织学的相关性较差[1]。对于怀疑拳师犬和法国斗牛犬患有肉芽肿性结肠炎的情况，荧光原位杂交（FISH）在组织样本中提供优越的细菌鉴定[1]。

### Sources

[1] Colitis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[2] Feline inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/feline-inflammatory-bowel-disease-proceedings
[3] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[4] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t

## 治疗选择

急性结肠炎的治疗结合了药物干预、饮食管理和支持性护理，以解决炎症并恢复正常的结肠功能。

**药物干预**包括抗炎和抗菌药物，具体取决于根本原因。甲硝唑（10-15 mg/kg，每12小时一次）提供抗菌和抗炎作用，常用于犬和猫的急性结肠炎[1]。泰乐菌素（10-15 mg/kg，每8-12小时一次）提供抗菌和免疫调节益处，副作用最小，但大肠杆菌和沙门氏菌仍然耐药[1]。对于炎症性肠病病例，糖皮质激素（泼尼松龙）是猫的首选治疗，通常初始剂量为1 mg/kg，每日两次，然后逐渐减量[1]。

**饮食管理**是治疗的基石。新蛋白饮食通过使用患者以前未接触过的蛋白质来源，有效控制了犬和猫的临床症状[1]。使用洋车前亲水胶浆（1-6茶匙）补充纤维或喂食高纤维商品饮食有助于改善许多病例的腹泻[1]。高易消化性、低残留饮食可能对纤维补充无反应的患者有益[7]。

**非药物方法**包括液体疗法以维持水合作用并纠正急性结肠炎中常见的电解质失衡[6]。粪便微生物群移植作为单一和辅助治疗显示出前景，通常通过保留灌肠给药[1]。益生菌可能有助于恢复健康的肠道微生物群，尽管证据主要仍是轶事性的[1]。

### Sources

[1] Colitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[6] What's new with boxer colitis and other large bowel disorders? (Proceedings): https://www.dvm360.com/view/whats-new-with-boxer-colitis-and-other-large-bowel-disorders-proceedings
[7] Dietary management of GI diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/dietary-management-gi-diseases-dogs-and-cats-proceedings

## 预防措施

急性结肠炎的预防侧重于饮食管理、环境控制和寄生虫预防，而不是传统的疫苗接种方案，因为急性结肠炎通常是非传染性的[1][2]。

**饮食管理和环境控制**

最有效的预防方法是喂食低过敏性或新蛋白饮食，包含动物以前未食用过的蛋白质，如鹿肉、兔肉或羊肉[1]。高纤维饮食有助于维持正常的结肠功能并预防炎症发作。Omega-3脂肪酸补充剂减少促炎介质，可能预防急性发作[1]。

环境应激管理至关重要，因为应激可触发发作。这包括保持一致的喂食时间表，避免突然的饮食变化，并尽量减少环境干扰[2]。持续获得新鲜饮水可防止脱水相关并发症。

**寄生虫预防和消毒**

全面的寄生虫预防至关重要，因为肠道寄生虫如贾第鞭毛虫、产气荚膜梭菌和隐孢子虫是急性结肠炎的重要原因[3]。定期粪便检查有助于早期发现寄生虫感染[2]。

使用稀释漂白剂（1:30）、季铵化合物或加速过氧化氢消毒剂进行环境消毒可有效消除传染性病原体[4]。在清除有机物后对污染区域进行蒸汽清洁可提供额外保护[4]。

**客户教育和监测**

主人应认识到早期预警信号，包括粪便稠度、频率变化或出现黏液和血液。症状出现时及时兽医咨询可防止进展为严重急性结肠炎[2]。某些对炎症性肠病有遗传倾向的品种需要加强监测和积极的饮食管理[1]。

### Sources

[1] Advances in managing inflammatory bowel disease: https://www.dvm360.com/view/advances-managing-inflammatory-bowel-disease/1000

[2] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs

[3] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-0

[4] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

## 鉴别诊断

急性结肠炎必须与几种出现重叠胃肠道症状的疾病相鉴别[1]。主要鉴别诊断包括小肠性腹泻、寄生虫感染和炎症性肠病（IBD），每种都需要不同的诊断方法。

**小肠性与大肠性腹泻**代表关键的初始区别[3]。小肠性腹泻通常表现为大量粪便、频率轻度增加、体重减轻，无黏液或血液[6]。相反，大肠疾病如急性结肠炎特征是频繁、小量粪便伴有黏液、血便和里急后重[4]。

**寄生虫感染**构成主要鉴别诊断，特别是犬中的鞭虫（鞭虫属）和两个物种中的贾第鞭毛虫[2][4]。使用硫酸锌浮聚法和抗原检测的粪便检查至关重要，因为间歇性排虫可导致假阴性[2]。即使粪便结果阴性也应进行治疗性驱虫[4]。

**IBD与急性结肠炎**的鉴别具有挑战性，因为两种疾病表现可能相似[1]。然而，IBD通常在超声检查中显示肠壁增厚，并且在传染性病例临床恶化前最初对免疫抑制性类固醇有反应[1]。患有传染性胃肠道疾病的宠物往往表现出这种先改善后恶化的模式[1]。

**诊断算法**应包括全面的粪便诊断组合，同时检测贾第鞭毛虫、产气荚膜梭菌肠毒素、胎儿三毛滴虫和隐孢子虫[2]。其他考虑因素包括食物反应性肠病，需要2-4周的独家饮食试验，以及全身性疾病如猫甲状腺功能亢进或犬肾上腺皮质功能减退症[4]。

### Sources
[1] Diagnosis and management of IBD in dogs and cats: https://www.dvm360.com/view/diagnosis-and-management-of-ibd-in-dogs-and-cats
[2] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t
[3] Diagnostic approach to chronic diarrhea in dogs and cats: https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[4] Colitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[5] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[6] Feline diarrhea: Let the diagnostic clues flow: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow

## 预后

犬和猫急性结肠炎的预后根据根本病因、严重程度和治疗反应而有显著差异。**在适当的支持性护理下，70-90%患有细小病毒性肠炎的犬将存活**[1]。对于大多数形式的急性结肠炎，临床恢复通常在1-7天内发生，大多数无并发症病例无论治疗如何都会自行缓解。

几个预后因素影响恢复和并发症。出现**严重低蛋白血症（白蛋白<1.5 g/dL）、明显血液浓缩（PCV>60%）或蛋白丢失性肠病证据的犬面临更谨慎的预后**[1][4]。**对于急性出血性腹泻综合征（AHDS），适当治疗的预后良好**，尽管住院犬如果不治疗死亡率可达10%[4]。

**细菌特异性原因的结果各不相同**。对于拳师犬的肉芽肿性结肠炎，对恩诺沙星的反应非常有希望，大多数犬在治疗3-12天内出现反应[9]。一些犬在一个疗程后达到完全临床反应，而其他犬需要更长时间的治疗或终身管理[9]。

**对于沙门氏菌等传染性原因**，腹泻病例的预后通常良好，但败血症患者的预后谨慎。负面预后指标包括超急性发作、明显发热、低温、严重出血性腹泻、退行性左移和低血糖[5]。

**慢性结肠炎病例的长期预后各不相同**。大多数患有炎症性肠病的犬需要终身治疗，尽管**仅饮食管理就成功控制了50-65%慢性肠病病例的临床症状**[7]。猫的病例通常对饮食管理结合必要的糖皮质激素反应良好[7]。

### Sources
[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[4] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[5] Parasitic and infectious causes of vomiting and diarrhea in dogs and cats: https://www.dvm360.com/view/parasitic-and-infectious-causes-vomiting-and-diarrhea-dogs-and-cats
[7] Colitis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[9] What's new with boxer colitis and other large bowel disorders: https://www.dvm360.com/view/whats-new-with-boxer-colitis-and-other-large-bowel-disorders-proceedings
