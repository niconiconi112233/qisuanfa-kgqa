# 伴侣动物的II类错颌畸形

II类错颌畸形，或称下颌远中错颌，是犬猫中一种关键的口腔正畸疾病，其特征为下颌相对于上颌位置异常靠后。这种遗传性疾病在下颌犬齿撞击硬腭时会造成疼痛性创伤性咬合，这使其与短头颅品种中常见的良性咬合变异有所区别。与其他错颌畸形不同，II类错颌在任何品种中都不被视为正常情况，需要及时的兽医干预以防止慢性疼痛和继发并发症。本报告探讨了全面的管理方法，从幼年患者的早期干预治疗（如球疗法）到手术干预（包括活髓治疗下的牙冠缩短和策略性拔牙），同时强调了遗传咨询在预防这种致残性疾病遗传方面的关键重要性。

## 疾病概述与流行病学

II类错颌畸形，也称为下颌远中错颌，是一种骨骼性咬合异常，表现为下颌看起来比上颌短，造成异常的颌骨关系[1]。这种疾病的特征是下颌相对于上颌位置靠后（向后方），导致闭口时上下切牙之间存在间隙[1]。

解剖学表现包括下颌切牙未能与上颌切牙的舌隆突咬合，以及上颌前臼齿相对于下颌前臼齿向前移位[1]。与在短头颅品种中被视为正常的下颌近中错颌（反颌）不同，下颌远中错颌在任何品种中都不被视为正常[1]。

II类错颌畸形通常是由于选择性繁殖偏好较长面部和鼻子而无意中选择了下颌远中错颌所致[1]。这种情况是儿科牙列中最常见的错颌畸形表现之一[2]。该疾病主要被认为是遗传性的，颌骨长度错颌畸形被认为是遗传性的[3]。这种情况具有很强的遗传成分，大多数错颌畸形是遗传而非创伤引起的[1]。患有此疾病的动物不应进行繁殖，除非已知原因是创伤[1]。

### Sources

[1] Developmental Abnormalities of the Mouth and Dentition in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals

[2] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings

[3] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth

## 临床症状与体征

II类错颌畸形表现出独特的临床特征，可通过系统的口腔检查识别。主要表现征象是下颌犬齿撞击前方硬腭导致的腭部创伤[1]。这种创伤性咬合常引起明显疼痛和炎症，这使其与其他类型的错颌畸形有所区别[1]。

**特征性临床表现**

患者通常表现为下颌犬齿的舌向移位（向内位置），这些牙齿沿着上颌犬齿的腭面萌出，而不是在其正常位置[4]。该疾病表现为闭口时上下切牙之间存在间隙，上颌前臼齿相对于下颌前臼齿向前移位[2]。

**诊断评估方法**

全面诊断需要清醒和麻醉状态下的口腔检查[1]。清醒检查允许初步评估咬合关系和咬合评估，而麻醉检查则可进行彻底的牙周评估和精确测量咬合差异[1]。必要的诊断工具包括牙周探针、牙科探针和口腔镜，以进行完整的牙周评估[1]。2期牙周疾病可能同时存在，其特征为受影响区域附着丧失小于25%且1度根分叉受累[1]。完整的诊断性X线片对于评估根结构完整性和评估并发牙科病理至关重要[4]。

### Sources

[1] Anatomy and charting (Proceedings): https://www.dvm360.com/view/anatomy-and-charting-proceedings
[2] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[3] Functional occlusion: I'm OK, but are your patients, really?: https://www.dvm360.com/view/functional-occlusion-im-ok-are-your-patients-really
[4] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals

## 治疗选择与管理

II类错颌畸形的治疗需要根据患者年龄和疾病严重程度定制的全面管理方法。在混合牙列期（4-12岁）的早期干预通过阻断性正畸治疗提供了最有利的结果[1]。这种方法可防止进行性恶化并减少后期复杂手术的需要。

**球疗法**代表了一种简单、非侵入性的治疗选择，适用于轻度II类错颌畸形伴有舌向移位的下颌犬齿。幼犬每天三次，每次15分钟握持适当大小的橡胶球（长曲棍球或球形咀嚼玩具），产生倾斜力引导牙齿到正确位置[1][4]。

**主动正畸移动**利用各种矫治器，包括斜面、复合树脂冠延伸和带有按钮和弹性链的传统正畸装置[2][3][5]。这些装置产生控制力将错颌牙齿重新定位到更健康的位置。治疗通常在1至3个月内完成[4]。

**手术干预**包括轻度病例中上颌第三切牙和犬齿之间的牙龈楔形切除术，为下颌犬齿重新定位提供引导通道[2][4]。更先进的手术选择可能涉及全面的重新定位程序。

**活髓治疗下的牙冠缩短**作为引起腭部创伤的严重II类错颌畸形的主要治疗方法。该手术通过牙髓治疗在保持牙齿活力的同时降低牙冠高度以消除咬合干扰[1][2][5]。

**策略性拔牙**在保守方法失败或口腔空间不足以进行正畸矫正的情况下可能是必要的[1][5]。

### Sources

[1] Canine orthodontics: Providing healthy occlusions: https://www.dvm360.com/view/dental-corner-canine-orthodontics-providing-healthy-occlusions
[2] Normal occlusion or malocclusion: that is the question: https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[3] Pediatric dentistry: An overview of common problems you'll see in practice: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice
[4] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[5] Orthodontic solutions: What to do with that bite: https://www.dvm360.com/view/orthodontic-solutions-what-do-with-bite

## 预防与预后

**预防**

遗传咨询仍然是II类错颌畸形最重要的预防措施[1][2]。由于下颌远中错颌是由遗传性不成比例的颌骨大小关系引起的，其中上颌长度相对长于下颌长度，患有II类错颌畸形的动物通常不应进行繁殖，除非该疾病是由已知创伤引起的[1][2]。

在乳牙列期的早期干预提供了显著的预防益处[2]。拔除乳下颌犬齿以及可能的切牙可以缓解牙锁结并鼓励恒牙在更好的位置萌出[2]。这种阻断性方法有助于防止下颌犬齿在沿着上颌犬齿腭面萌出时被引导向腭侧[2]。

从幼犬首次就诊开始的彻底口腔检查可以识别需要立即注意的重要异常[1]。未能早期识别问题可能导致需要广泛治疗的恒牙错颌畸形[1]。

**预后**

II类错颌畸形的预后根据治疗方法和严重程度而有显著差异。II类错颌畸形通常需要正畸或手术干预，因为下颌犬齿撞击硬腭会造成创伤性咬合[2]。

正畸矫正通常需要多次麻醉事件，但可以实现功能性、舒适的咬合[2]。活髓治疗下的牙冠缩短在降低的高度上保留牙齿形态和功能，需要终身X线监测[2]。

拔牙提供即时缓解，需要最少的后续随访，使其成为成本最低且结果可预测的选择[2]。成功很大程度上取决于主人对家庭护理建议的依从性和定期的专业牙科维护。如果没有适当的持续护理，牙周疾病的进展可能会损害长期结果，无论最初的治疗选择如何。

### Sources
[1] Defining dental malocclusions in dogs: https://www.dvm360.com/view/defining-dental-malocclusions-dogs
[2] Developmental Abnormalities of the Mouth and Dentition in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
