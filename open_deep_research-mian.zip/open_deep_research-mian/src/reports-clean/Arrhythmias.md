# 伴侣动物的心律失常

心律失常代表心脏电传导系统的严重紊乱，影响犬和猫，如果未经诊断或治疗，可能具有危及生命的后果。这些异常心律范围从犬的良性呼吸性窦性心律失常到需要紧急干预的严重室性心动过速。本综合报告探讨了兽医实践中心律失常的复杂情况，涵盖了品种特异性易感因素（如拳师犬的致心律失常性右心室心肌病）、不同物种对心律失常的耐受性差异，以及系统化心电图解释的关键作用。分析包括紧急稳定方案、抗心律失常药物选择、起搏器适应症以及影响受影响伴侣动物长期预后的预后因素。

## 疾病概述

心律失常是犬和猫心脏电传导系统的异常，导致不规则的心律。这些传导障碍发生在正常电冲动产生、传导或两者顺序偏离生理模式时[1]。

心律失常大致分为两大类：心动过缓（心率慢）和心动过速（心率快）[1]。心动过缓包括窦性心动过缓、病态窦房结综合征和房室传导阻滞，而心动过速包括室上性和室性心律失常[1]。此外，心律失常可根据其起源分类为室上性（起源于心室以上）或室性（起源于心室）[1]。

病理生理学涉及正常心脏传导系统的紊乱，其中窦房结通常启动去极化并作为心脏的自然起搏器[1]。正常窦性心律规则且起源于窦房结，在心电图上表现为每个QRS复合波前有一个P波[1]。

不同物种在心律失常发生率和耐受性方面存在差异。窦性心律失常在犬中被认为是正常的，但在医院环境中的猫中则是异常的[1]。猫通常比犬更能耐受某些心律失常，特别是三度房室传导阻滞[1]。心脏肿瘤经常引发犬的心律失常，其中室性异位或心动过速最常与血管肉瘤和化学感受器瘤相关[2]。

### Sources

[1] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/en/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats

[2] Cardiac tumors in dogs and cats: https://www.dvm360.com/view/cardiac-tumors-in-dogs-and-cats

## 常见原因和临床表现

现有部分已经全面涵盖了犬和猫心律失常的心脏和非心脏原因。提供的资料来源集中于人类甲状腺功能亢进和胃扩张-扭转（GDV），这些与兽医患者心律失常的主题没有直接相关性。

当前内容有效涵盖了关键的心脏原因，包括瓣膜病、动脉导管未闭等先天性缺陷以及具有适当品种易感性的心肌病。提到了甲状腺功能亢进等非心脏原因，并很好地描述了具有物种特异性模式的临床表现。

**胃扩张-扭转代表心律失常的一个重要非心脏原因**，应予以包括。**GDV主要影响大型和巨型犬种，特别是大丹犬、德国牧羊犬和标准贵宾犬**[4]。**高达70%的GDV犬发生心律失常，这些心律失常通常起源于心室**[4]。这些心律失常是由胃梗阻和血管损害继发的全身性低血压、血容量不足和电解质紊乱引起的。

**GDV的临床症状包括无效干呕、流涎过多、进行性腹部膨胀和休克体征**[4]。该情况需要立即的医疗和手术干预，**即使治疗，死亡率仍为20-45%**[4]。认识到GDV作为心律失常的潜在原因对于适当的紧急管理至关重要。

### Sources
[1] Getting to the heart of the matter: Heart disease and heart failure (Proceedings): https://www.dvm360.com/view/getting-heart-matter-heart-disease-and-heart-failure-proceedings
[2] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals
[3] Cardiac Shunts in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/cardiac-shunts-in-animals
[4] Gastric Dilation and Volvulus in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals

## 诊断方法

犬和猫的全面心律失常诊断需要系统的心电图评估结合先进的心脏监测和实验室评估[1]。心电图解释是心律失常诊断的基石，需要对心率、心律规则性、QRS形态和P波存在进行系统评估[2]。

在解释过程中必须考虑物种特异性的心电图特征。犬的平均电轴（MEA）范围为+40至+100度，而猫则表现出更广泛的0至+160度范围[3]。以50毫米/秒纸速的标准II导联记录允许准确的心律评估和振幅测量[4]。

Holter监测提供24小时动态心电图记录，对于检测间歇性心律失常和评估心律失常负担至关重要[1]。当与心脏生物标志物结合使用时，该技术对于筛选高危品种的隐匿性扩张型心肌病特别有价值[7]。

实验室评估包括血清电解质评估（特别是钾、钠和镁）、甲状腺功能测试和心脏生物标志物。NT-proBNP测量有助于区分心脏和非心脏原因的临床症状[7]。超声心动图通过评估结构性心脏病、腔室大小和心肌功能来补充心电图发现。

先进技术包括用于发作性症状的事件记录器和用于在手术过程中增强心律监测的直接胸导联。遵循既定协议的系统化心电图分析确保检测到可能导致心律失常的细微传导异常和腔室扩大模式[5]。

### Sources

[1] ECG interpretation and management of arrhythmias: https://www.dvm360.com/view/ecg-interpretation-and-management-arrhythmias-proceedings

[2] Reading ECGs in veterinary patients: an introduction: https://www.dvm360.com/view/reading-ecgs-in-veterinary-patients-an-introduction

[3] How to determine and interpret the mean electrical axis: https://www.dvm360.com/view/skills-laboratory-how-determine-and-interpret-mean-electrical-axis

[4] Recording and interpreting ECGs (Proceedings): https://www.dvm360.com/view/recording-and-interpreting-ecgs-proceedings

[5] Electrocardiography (Proceedings): https://www.dvm360.com/view/electrocardiography-proceedings

[6] Clinical and pathological findings in rabbits - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/7/javma.259.7.764.xml

[7] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 治疗选择

犬和猫的心律失常管理需要多方面的方法，包括紧急稳定、抗心律失常药物、设备干预和基础疾病治疗。

紧急稳定方案侧重于使用静脉注射利多卡因立即控制室性心律失常（犬2-4毫克/千克静脉推注，猫0.1-0.4毫克/千克）[1]。对于室上性心动过速，地尔硫卓提供有效的心率控制（5分钟内静脉注射0.05-0.1毫克/千克）[3]。

抗心律失常药物按机制分类：I类钠通道阻滞剂（利多卡因、普鲁卡因胺、美西律）、II类β受体阻滞剂（阿替洛尔、普萘洛尔）、III类钾通道阻滞剂（索他洛尔、胺碘酮）和IV类钙通道阻滞剂（地尔硫卓）[1][2]。索他洛尔（1-3.5毫克/千克口服，每12小时一次）对犬和猫的室性心律失常特别有效，特别是对于患有致心律失常性右心室心肌病的拳师犬[1][3]。

起搏器植入适用于有症状的心动过缓，包括三度房室传导阻滞、病态窦房结综合征和高度二度房室传导阻滞[6]。经静脉心内膜和心外膜系统均可使用，由于发病率较低，首选心内膜起搏。

物种特异性考虑包括猫对利多卡因的敏感性增加，需要较低剂量（0.1-0.4毫克/千克，而犬为2-4毫克/千克）[1][4]。β受体阻滞剂需要仔细滴定，从低剂量开始，并在数周内逐渐增加剂量，以避免负性肌力作用，特别是在心力衰竭患者中[1][3]。

### Sources
[1] Antiarrhythmics for Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/antiarrhythmics-for-use-in-animals
[2] Electrocardiography (Proceedings): https://www.dvm360.com/view/electrocardiography-proceedings
[3] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[4] Antiarrhythmic therapy (Proceedings): https://www.dvm360.com/view/antiarrhythmic-therapy-proceedings
[5] What drug for what disease (Proceedings): https://www.dvm360.com/view/what-drug-what-disease-proceedings
[6] The pulse on pacemakers: https://www.dvm360.com/view/pulse-pacemakers

## 预防措施和鉴别诊断

**预防措施**

心律失常的预防主要侧重于常规心脏筛查和易感条件的管理。对于具有遗传易感性的高风险品种，筛查尤为重要[1]。对于犬扩张型心肌病（DCM），建议杜宾犬从成年开始每年进行超声心动图和Holter监测筛查[1]。

超声心动图筛查对于检测特定猫品种（包括斯芬克斯猫和缅因猫）的临床前心脏病很有价值，特别是在繁殖前检测肥厚型心肌病[3]。24小时内超过10个室性早搏（VPC）或成对、成三出现的成年杜宾犬被怀疑发展为DCM[1]。

环境考虑包括避免对已知心脏病犬进行应激性操作[5]。管理甲状腺功能亢进、高血压和全身性疾病等基础疾病有助于预防继发性心律失常[8]。

**鉴别诊断**

呼吸性窦性心律失常是犬的正常发现，其特征是心率随吸气增加，随呼气减少[6][8]。这种规则的不规则心律可与病理性心律失常区分，因为它可被兴奋、运动或阿托品给药消除[8]。

其他模拟病理性心律失常的情况包括窦性心动过速，它在几秒钟内逐渐加速，而异位心律失常则突然加速[7]。电气设备、颤抖或呼吸运动产生的伪影可能在心电图记录上造成假性不规则模式[7]。

区分因素包括QRS形态（室上性为窄，室性为宽）和P波的存在或不存在[8]。仔细评估心律规则性、心率变异性和对迷走神经操作的反应有助于区分生理性和病理性心律紊乱。

### Sources

[1] Dilated and arrhythmogenic cardiomyopathy in dogs (Proceedings): https://www.dvm360.com/view/dilated-and-arrhythmogenic-cardiomyopathy-dogs-proceedings
[2] Cardiopulmonary Resuscitation of Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/specific-diagnostics-and-therapy/cardiopulmonary-resuscitation-of-small-animals
[3] MVC 2018: Advances in Feline Heart Disease Diagnosis: https://www.dvm360.com/view/mvc-2018-advances-in-feline-heart-disease-diagnosis
[4] Anesthetic management of small animals with preexisting cardiac conditions (Proceedings): https://www.dvm360.com/view/anesthetic-management-small-animals-with-preexisting-cardiac-conditions-proceedings
[5] ECG reading session-cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/ecg-reading-session-cardiac-arrhythmias-proceedings
[6] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
[7] Recording and interpreting ECGs (Proceedings): https://www.dvm360.com/view/recording-and-interpreting-ecgs-proceedings
[8] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats

## 预后

犬和猫心律失常的预后因心律失常类型、基础心脏病和治疗反应而有显著差异。基础结构性心脏病的存在通常会使预后显著恶化。

对于没有扩张型心肌病的拳师犬的致心律失常性右心室心肌病（ARVC），预后通常良好，许多在抗心律失常治疗下可存活数年[4]。然而，处于心力衰竭阶段的DCM犬的长期预后较差，大多数只能存活数月[4]。

患有高度二度和三度房室传导阻滞的犬在诊断后6个月内面临30%的猝死风险，无论临床症状如何[3]。三度房室传导阻滞在没有起搏器干预的情况下预后严重，因为犬有猝死风险[3]。猫比犬更能耐受三度房室传导阻滞，中位生存期为386天，大多数死于非心脏原因[3]。

猫的室上性心动过速，通常发生在300-400次/分钟，经常引起晕厥并需要紧急治疗[2]。预后主要取决于基础原因和对心率控制药物的反应。

长期管理策略侧重于识别和纠正基础原因，通过抗心律失常治疗维持适当的心率，以及定期监测[6]。生活质量考虑包括运动耐受性、晕厥频率和主人有效管理慢性药物的能力。

### Sources

[1] Arrhythmogenic Right Ventricular Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/arrhythmogenic-right-ventricular-cardiomyopathy-in-dogs-and-cats
[2] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
[3] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[4] Antiarrhythmic therapy (Proceedings): https://www.dvm360.com/view/antiarrhythmic-therapy-proceedings
