# 伴侣动物角膜软化症：兽医临床指南

角膜软化症是小动物临床中最紧急的眼科急症之一，其特征是角膜组织的快速酶解，可在数小时内导致穿孔和视力丧失。这种情况通常被称为"溶解性溃疡"，当铜绿假单胞菌等细菌病原体产生胶原酶，真正消化角膜基质时发生。虽然影响犬和猫，但短头颅品种由于其解剖学易感性而面临特别高的风险。本报告探讨了区分角膜软化症与常规角膜溃疡的关键临床表现，探讨了基于证据的诊断方法，包括荧光素染色和细菌培养，并详细说明了为保存眼球和视力恢复所需的积极医疗和手术干预。

## 摘要

角膜软化症是一种真正的眼科急症，需要立即识别和积极干预以防止角膜穿孔。该病的发病机制集中在细菌胶原酶上，特别是来自铜绿假单胞菌和β-溶血性链球菌的胶原酶，它们造成角膜组织特有的"溶解"外观。短头颅品种的溃疡患病率高出六倍，强调了品种特异性风险因素。

临床诊断依赖于荧光素染色，显示特征性的不透明灰色组织"悬挂在角膜上"，结合细菌培养和细胞学检查以识别病原体。治疗需要每小时强化使用抗生素，交替使用自体血清或EDTA进行抗胶原酶治疗。当基质损失超过50%时，需要通过结膜瓣移植进行手术干预。

| 因素 | 对预后的影响 |
|--------|-------------------|
| 溃疡深度 >50% | 眼球保留不良 |
| 中央位置 | 视觉结果降低 |
| 早期干预 | 恢复良好 |
| 品种易感性 | 复发风险较高 |

成功取决于快速诊断、积极的药物治疗以及在需要时及时的手术支持，通过适当的急诊管理方案可获得良好结果。

## 疾病概述和常见病原体

**角膜软化症**被定义为角膜基质组织的酶解和软化，代表犬猫溃疡性角膜炎的严重并发症[1]。当细菌酶，特别是胶原酶，消化角膜基质，导致角膜快速变薄和潜在穿孔时发生这种情况[1]。术语"溶解性溃疡"通常与角膜软化症互换使用，因为受影响的角膜组织具有特征性的液化外观[7]。

从流行病学角度看，角膜软化症影响犬和猫，但在短头颅品种和患有干性角膜结膜炎的动物中特别普遍，这些动物特别容易因感染性角膜炎而失去基质[10]。这种情况代表一种医疗急症，需要立即干预以防止角膜穿孔和潜在的视力丧失。

**细菌病原体**是角膜软化症的主要致病因子。铜绿假单胞菌和β-溶血性链球菌是最常见的致病生物[1]。这些细菌产生强效的蛋白水解酶，包括胶原酶和其他蛋白酶，它们主动消化角膜胶原蛋白并造成基质组织特有的"溶解"[1,7]。

虽然猫疱疹病毒-1等病毒感染可在猫中引起初始角膜溃疡[1,2,3]，但蛋白水解生物的继发性细菌定植将简单溃疡转变为临床上所见的侵袭性角膜软化症。发病机制涉及微生物酶和内源性组织蛋白酶，它们创造了一个需要立即积极治疗的角膜破坏级联反应。

### Sources

[1] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[2] Feline keratitis and conjunctivitis (Proceedings) - dvm360: https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[3] Feline Respiratory Disease Complex - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[7] Ulcerative keratitis with stromal loss, dog - Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/image/ulcerative-keratitis-with-stromal-loss-dog
[10] Deep Stromal Corneal Ulcers, Descemetocele, and Iris Prolapse in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/deep-stromal-corneal-ulcers-descemetocele-and-iris-prolapse-in-small-animals

## 临床症状、体征和诊断方法

角膜软化症呈现特征性的临床体征，反映角膜"溶解"过程。最显著的特征是角膜组织呈不透明的灰白色半固体外观，"悬挂在角膜上"，中央透明表明危险的基质变薄[1][2]。受影响的动物表现出严重的眼部疼痛，表现为眼睑痉挛、眯眼和过度流泪[1][2]。角膜水肿、明显的细胞浸润和溃疡床加深是特征性体征[1]。

临床检查显示溃疡边缘或溃疡床内有密集的白色浸润，表明强烈的细菌参与[2]。相关的前葡萄膜炎通常很严重，表现为低眼压、瞳孔缩小、闪辉、前房积脓和虹膜粘连形成[1]。角膜新生血管和黏液脓性分泌物是常见发现[1][2]。

**品种特异性模式**

短头颅品种的角膜溃疡患病率（6.3%）显著高于非短头颅品种（1.4%）[6]。这些品种以及患有干性角膜结膜炎的犬特别容易因感染性角膜炎而失去基质[6]。

**诊断方法**

对于任何疼痛的眼睛，必须进行荧光素染色，显示全层上皮缺损[3][5]。然而，明显的角膜水肿可能降低荧光素保留强度[2]。当荧光素染色阴性时，玫瑰红染色可检测部分厚度上皮缺损[2][3]。

在应用任何局部药物之前，必须进行角膜细胞学检查和培养，使用来自溃疡边缘和基底的深层角膜刮片[5]。革兰氏染色为抗生素选择提供即时指导，在细菌性角膜软化症中识别铜绿假单胞菌等革兰氏阴性杆菌[7]。使用Diff-Quik染色的细胞学检查可以识别细菌、真菌菌丝和细胞浸润[3][5]。

### Sources

[1] Deep Stromal Corneal Ulcers, Descemetocele, and Iris Prolapse in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/deep-stromal-corneal-ulcers-descemetocele-and-iris-prolapse-in-small-animals
[2] Corneal ulcers: https://www.dvm360.com/view/corneal-ulcers
[3] Managing equine corneal disease (Proceedings): https://www.dvm360.com/view/managing-equine-corneal-disease-proceedings
[4] Corneal disease of horses (Proceedings): https://www.dvm360.com/view/corneal-disease-horses-proceedings
[5] Management of Corneal Ulcers in Small Animals - WSAVA2007 - VIN: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3860707&pid=11242
[6] Data: Brachycephalic breeds suffer higher incidences of non-respiratory diseases: https://www.dvm360.com/view/data-brachycephalic-breeds-suffer-higher-incidences-non-respiratory-diseases
[7] The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

## 治疗选择和预防措施

**医疗管理**

角膜软化症的主要医疗疗法涉及针对细菌病原体的积极抗生素方案。强化氨基糖苷类（庆大霉素1.5%，阿米卡星）或氟喹诺酮类（氧氟沙星，莫西沙星）作为一线治疗，通常与头孢菌素类（头孢唑林5%）交替使用[1]。给药频率应最初每小时一次，直到角膜溶解得到控制，然后减少到每4-6小时一次[1]。

抗胶原酶治疗对于阻止酶性基质分解至关重要。局部自体血清提供丝氨酸蛋白酶抑制，而1% EDTA溶液螯合金属蛋白酶[1]。多西环素以10 mg/kg口服每日两次提供抗菌和抗酶双重益处[2]。全身性非甾体抗炎药控制继发性葡萄膜炎，而局部阿托品提供睫状肌麻痹和散瞳作用[1]。

**手术干预**

当基质损失超过50%或医疗疗法失败时，需要手术稳定[1]。结膜瓣移植提供即时血管灌注和结构支持，尽管它们会增加角膜瘢痕形成[1]。角膜巩膜转位为深部溃疡性病变提供替代手术方法[1]。

**预防策略**

预防侧重于避免易感因素和维持角膜完整性。定期眼科检查可在进展为角膜软化症之前检测早期溃疡性疾病。

**禁忌治疗**

局部皮质类固醇在疑似感染性角膜炎中绝对禁忌，因为它们可能诱发或加重角膜溶解[2]。非甾体抗炎药在活动性角膜软化症期间应避免使用，因为它们可能引发进一步的酶解[2]。

### Sources
[1] Managing equine corneal disease (Proceedings): https://www.dvm360.com/view/managing-equine-corneal-disease-proceedings
[2] Corneal ulcers: https://www.dvm360.com/view/corneal-ulcers

## 鉴别诊断和预后

### 鉴别诊断

角膜软化症必须与几种临床表现重叠的角膜疾病相鉴别。浅表性角膜溃疡表现为上皮缺损而无基质受累，通常在适当治疗下7-10天内愈合[1]。顽固性溃疡（自发性慢性角膜上皮缺损）表现为慢性、浅表、非感染性病变，上皮边缘松散，主要发生在中年犬，特别是拳师犬[1]。

后弹力层膨出代表延伸至后弹力膜的深基质溃疡，表现为角膜缺损内的清晰隆起区域，由于穿孔风险需要立即手术干预[2]。基质损失≥50%的基质溃疡表现为可见的角膜表面缺损，具有进行性溶解的潜力，需要紧急眼科评估[2]。

关键鉴别因素包括通过荧光素染色评估溃疡深度、是否存在基质溶解或角膜软化症、角膜细胞学结果以及对常规治疗的反应[1][2]。

### 预后

预后根据溃疡深度、基质受累程度和是否存在并发症因素而有显著差异。对于浅表性溃疡，在适当的医疗管理下眼球存活率极好[2]。当角膜透明度得以保持且中央角膜受累最小时，视觉结果仍然良好[2]。

对预后产生负面影响的因素包括深基质受累（>50%深度）、角膜中央位置、存在角膜软化症、继发性细菌感染以及干性角膜结膜炎等并发疾病[1][2]。早期干预和适当的手术支持显著改善复杂病例中的眼球保留和视觉结果[2]。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] Deep Stromal Corneal Ulcers, Descemetocele, and Iris Prolapse in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/deep-stromal-corneal-ulcers-descemetocele-and-iris-prolapse-in-small-animals
