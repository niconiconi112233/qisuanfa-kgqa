# 伴侣动物的皮肤肥大细胞瘤

皮肤肥大细胞瘤是犬类最重要的皮肤肿瘤，也是猫类中一个关键的诊断挑战，占所有犬类皮肤肿瘤的16-21%，占猫类皮肤肿瘤的12-20%。对于兽医从业者来说，理解这些复杂的肿瘤至关重要，因为它们的行为范围从良性、易于治愈的病变到侵袭性、危及生命的恶性肿瘤。本综合报告探讨了皮肤肥大细胞瘤的多面性，涵盖其流行病学模式、包括c-KIT突变在内的致病机制、利用现代分级系统的诊断方法、从传统手术到新型酪氨酸激酶抑制剂的不断发展的治疗方式，以及指导犬猫患者临床决策的预后因素。

## 疾病概述与流行病学

皮肤肥大细胞瘤（MCT）是犬类最常见的皮肤肿瘤，占所有犬类皮肤肿瘤的16-21%[1]。这些肿瘤源于皮肤组织中恶性肥大细胞的失控增殖[2]。MCT主要影响中老年犬，诊断时的平均年龄为8-9岁[2][3]。

某些品种表现出对MCT发展的显著易感性。拳师犬、波士顿梗、拉布拉多寻回犬、比格犬、雪纳瑞犬、哈巴狗、英国斗牛犬和牛头梗表现出更高的易感性[1][3]。值得注意的是，源自斗牛犬的品种，包括斯塔福德郡梗和美国斯塔福德郡梗，表现出特别高的高级别肿瘤发生风险[2]。与雌性相比，雄性犬，特别是未绝育的雄性犬，表现出更高的高级别MCT发生可能性[2]。

在猫中，MCT是第二常见的皮肤肿瘤，占所有猫类皮肤肿瘤的12-20%[7]。内脏MCT在猫中比犬中更常见，高达50%发生在内脏位置[7]。猫类皮肤MCT影响老年猫，平均年龄为9岁，没有特定的品种或性别倾向[7]。然而，据估计，猫类MCT的真实发病率仅占所有猫类恶性肿瘤的0.9%，使其比犬类罕见得多[4]。

从解剖学上看，约50%的犬类皮肤MCT发生在躯干，40%在四肢，10%在头颈部[3]。在猫中，51%的MCT位于头部[7]。在诊断时，约10-15%的犬和15-20%的猫出现多个肿瘤[3][7]。

### Sources
[1] Clinical Rounds: Recurrent mast cell tumors in a boxer: https://www.dvm360.com/view/clinical-rounds-recurrent-mast-cell-tumors-boxer
[2] Study Uncovers Breed, Sex Predilections for High-grade Mast Cell Tumors: https://www.dvm360.com/view/study-uncovers-breed-sex-predilections-for-highgrade-mast-cell-tumors
[3] Mast cell tumors in dogs and cats (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-and-cats-proceedings
[4] Round cell tumors in cats (Proceedings): https://www.dvm360.com/view/round-cell-tumors-cats-proceedings
[7] Mast cell tumors in dogs and cats (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-and-cats-proceedings

## 发病机制与临床表现

现有内容全面涵盖了肥大细胞瘤的发病机制和临床表现。所提供的来源材料提供了补充信息，增强了对物种特异性差异和品种易感性的理解。

皮肤肥大细胞瘤通过复杂的发病机制发展，c-KIT突变是主要致病因素[1]。原癌基因c-kit编码负责肥大细胞生长和分化的干细胞因子，突变促进不受控制的细胞周期进程[1][3]。与I级MCT相比，III级和II级中c-kit突变的发生率更高，突变肿瘤复发和转移的可能性是未突变肿瘤的两倍[1]。

临床表现因肿瘤级别和脱颗粒活性而有显著差异。分化良好的MCT通常表现为单个、缓慢生长的橡胶样病变，而分化不良的肿瘤则表现为快速生长、伴有周围炎症的溃疡性肿块[3][6]。达里埃征（Darier's sign）的特征是操作后出现风团，由组胺释放引起，表明肿瘤的反应性[1][3][4]。

组胺释放引起的全身效应包括胃肠道溃疡（尸检时35-83%的病例）、呕吐、黑便和腹痛[5][6]。肝素释放可能导致凝血病，引起出血和伤口愈合延迟[5]。

物种特异性表现在犬和猫之间存在差异。犬类MCT主要影响拳师犬、哈巴狗、波士顿梗、斗牛犬和寻回犬[1]，肿瘤最常见于躯干（50%）和四肢（40%）[5]。猫类MCT主要发生在头颈部（51%）[5]，猫表现出两种不同的形式：肥大细胞性和组织细胞性变体[4]。

### Sources

[1] Mast cell tumors in dogs and cats (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-and-cats-proceedings
[2] Cytologic examination of a cutaneous mast cell tumor in a boxer: https://www.dvm360.com/view/clinical-exposures-cytologic-examination-cutaneous-mast-cell-tumor-boxer
[3] Cutaneous lumps and bumps: The good, the bad and the ugly (Proceedings): https://www.dvm360.com/view/cutaneous-lumps-and-bumps-good-bad-and-ugly-proceedings
[4] Tumors of the Skin in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[5] Canine cutaneous mast-cell tumors: Current concepts for patient management: https://www.dvm360.com/view/canine-cutaneous-mast-cell-tumors-current-cocnepts-patient-management
[6] Blast those masts! Conquering mast cell tumors in your veterinary patients: https://www.dvm360.com/view/blast-those-masts-conquering-mast-cell-tumors-your-veterinary-patients

## 诊断方法与分期

皮肤肥大细胞瘤的诊断依赖于结合细胞学、组织病理学和分期程序的系统方法。细针抽吸细胞学作为主要诊断工具，显示具有异染性胞浆颗粒的特征性圆形细胞[1]。然而，当胞浆颗粒不明显时，分化不良的肿瘤可能需要特殊染色如甲苯胺蓝或吉姆萨染色来确认诊断[2][6]。

组织病理学分级仍然是预后的金标准。当代两级分级系统（Kiupel）将肿瘤分为低级别或高级别，与传统三级Patnaik系统相比提供了更好的临床实用性[1]。Patnaik系统将I级指定为低级别，II级为中级，III级为高级别[2]。包括Ki-67、AgNOR计数和c-Kit表达在内的增殖标志物提供额外的预后信息[5]。

分期程序包括全血细胞计数、生化面板、胸部X光检查和腹部超声检查[3]。无论大小如何，都应进行区域淋巴结的细胞学评估，因为转移性淋巴结并不总是肿大[3]。对于高级别肿瘤或存在全身症状时，可能需要额外的分期，包括肝/脾抽吸和骨髓评估[2][5]。

### Sources

[1] Merck Veterinary Manual Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[2] DVM 360 Mast cell tumors in dogs (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-proceedings
[3] DVM 360 Surgery STAT: An overview of cutaneous mast cell tumors in dogs: https://www.dvm360.com/view/surgery-stat-overview-cutaneous-mast-cell-tumors-dogs
[4] Merck Veterinary Manual Lymphocytic, Histiocytic, and Related Cutaneous Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/lymphocytic-histiocytic-and-related-cutaneous-tumors-in-animals
[5] DVM 360 Mast cell tumors: Margins, markers and prognostic factors (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-margins-markers-and-prognostic-factors-proceedings
[6] Getting the most from the histopathology (Proceedings): https://www.dvm360.com/view/getting-most-histopathology-proceedings

## 治疗方式与管理

手术仍然是皮肤肥大细胞瘤的主要治疗方式[1]。历史上，推荐2-3厘米的侧缘和一个筋膜平面的深缘，但最近的研究显示，大多数I级和II级肿瘤可以用1-2厘米的侧缘完全切除[1]。在没有筋膜平面的区域，需要至少4毫米的深部组织切除[1]。犬在麻醉期间应接受苯海拉明（2.2 mg/kg 肌肉注射）以预防组胺相关并发症[1]。

放射治疗对于不完全切除的肿瘤非常有效，在2-5年内对II级MCT实现85-93%的局部控制率[3]。对于显微镜下疾病，放射治疗比大块肿瘤（约50%的一年控制率）提供更好的结果[3]。

化疗适用于高级别肿瘤和转移性疾病[3]。长春新碱和泼尼松方案对III级肿瘤提供45%的一年生存率，对II级肿瘤提供90%的一年生存率[5]。CCNU对难治性病例表现出42%的反应率[4]。

新型酪氨酸激酶抑制剂如托塞尼布磷酸盐（Palladia）和马替替尼靶向约30%犬类MCT中发现的c-kit突变[5][6]。这些口服药物为复发性II-III级肿瘤提供有效治疗，副作用最小[6]。

替吉兰替格酯代表了一种新的瘤内疗法，适用于肢体上不可切除的体积小于8 cm³的皮下MCT，通过直接注射诱导肿瘤坏死[6]。

### Sources

[1] An overview of cutaneous mast cell tumors in dogs: https://www.dvm360.com/view/surgery-stat-overview-cutaneous-mast-cell-tumors-dogs
[2] Dogs undergoing surgical excision of mast cell tumors are not ...: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.20.09.0488.xml
[3] Mast cell tumors in dogs and cats (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-and-cats-proceedings
[4] Demystifying mast cell tumors (Proceedings): https://www.dvm360.com/view/demystifying-mast-cell-tumors-proceedings
[5] Mast cell tumors: new tools in the arsenal (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-new-tools-arsenal-proceedings
[6] Lymphocytic, Histiocytic, and Related Cutaneous Tumors ...: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/lymphocytic-histiocytic-and-related-cutaneous-tumors-in-animals

## 预后

皮肤肥大细胞瘤的预后基于多种预后因素而有显著差异。组织学分级仍然是结果的最重要预测因素[1]。使用传统的Patnaik分级系统，83%的I级肿瘤犬、44%的II级肿瘤犬和仅6%的III级肿瘤犬在手术后大约存活四年[1]。较新的两级分级系统显示，低级别肿瘤的中位生存时间超过两年，而高级别肿瘤则不到四个月[2]。

其他因素显著影响预后。肿瘤位置影响结果，皮肤黏膜交界处、趾部和内脏位置与更具侵袭性的行为相关[1][2]。有丝分裂指数是一个强有力的预测因素，有丝分裂指数低（≤5）的犬显示70个月的中位生存期，而较高指数的犬为五个月[2]。c-kit突变和过表达与较差的预后和更高的肿瘤级别相关[1][3]。

对于猫，皮肤MCT通常通过保守手术切缘有良好的预后，显示出0-24%的复发率[2]。然而，尽管有广泛播散的可能性，脾脏MCT的猫在脾切除术后平均生存时间为12-19个月[2]。

治疗方式显著影响结果。完全手术切除为适当分期的病例提供超过90%的治愈率。放射治疗对不完全切除的低级别肿瘤实现85-95%的两年控制率[1]。适当的临床分期能够进行准确的预后评估和治疗规划[4]。犬中的大多数肥大细胞瘤表现为隆起的肿块或团块，触诊时可能从软到实，需要仔细的诊断评估[5]。

### Sources

[1] Mast cell tumors in dogs (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-proceedings
[2] Mast cell tumors in dogs and cats (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-dogs-and-cats-proceedings
[3] Mast cell tumors: Margins, markers and prognostic factors (Proceedings): https://www.dvm360.com/view/mast-cell-tumors-margins-markers-and-prognostic-factors-proceedings
[4] General introduction to veterinary oncology: Myths and misconceptions (Proceedings): https://www.dvm360.com/view/general-introduction-veterinary-oncology-myths-and-misconceptions-proceedings
[5] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
