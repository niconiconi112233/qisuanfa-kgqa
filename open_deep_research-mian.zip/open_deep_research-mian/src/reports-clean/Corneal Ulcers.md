# 犬猫角膜溃疡

角膜溃疡是伴侣动物临床中最常见且可能严重的眼科急症之一。这些上皮缺损会导致显著疼痛，若不及时治疗，可能迅速发展为威胁视力的并发症。该疾病影响犬和猫，但在每个物种中表现出不同的挑战，猫科病例常涉及病毒病原体，而犬的溃疡通常由创伤或品种特异性易感性引起。

本综合报告探讨了角膜溃疡的多方面性质，从驱动许多病例的猫疱疹病毒-1等传染性病原体，到深层基质缺损所需的先进手术干预。通过对诊断方案、治疗模式和预防策略的详细分析，兽医可以为这些具有挑战性的病例制定有效的管理方法。

## 预后

角膜溃疡的预后因溃疡深度、潜在病因和患者因素而有显著差异。浅表溃疡通常在适当的药物治疗下7-14天内愈合，而深层基质溃疡需要手术干预，并发症风险更高。猫疱疹病毒相关溃疡由于病毒在三叉神经节中的持续存在，常成为慢性复发性疾病。

关键预后因素包括：
- **溃疡深度**：浅表溃疡预后良好，而后弹力层膨出有穿孔风险
- **病原体参与**：假单胞菌感染可导致角膜快速溶解
- **品种易感性**：患有惰性溃疡的拳师犬需要专业手术治疗
- **治疗依从性**：频繁用药是成功的关键

早期识别和积极治疗可显著改善预后，大多数病例在适当管理下可获得功能性视力。然而，严重的溶解性溃疡可能导致角膜瘢痕形成，或在晚期病例中需要眼球摘除术。

## 常见病原体

犬猫的角膜溃疡由多种传染性病原体引起，这些病原体损害角膜上皮和下方的基质。了解这些病原体对于制定适当的治疗策略至关重要。

**病毒病原体**
猫疱疹病毒-1（FHV-1）是猫角膜溃疡最重要的病毒性病因[1]。这种病毒影响全球高达95%的猫，其中约80%成为慢性携带者[1]。FHV-1引起浅表角膜疾病，并特征性地产生树枝状溃疡，这被认为是疱疹病毒感染的特征性病变[2]。复发性FHV-1感染表现为疱疹病毒性角膜炎、角膜溃疡，在严重情况下可形成睑球粘连[2]。该病毒在三叉神经节等组织中保持潜伏状态，在应激或免疫抑制期间重新激活[3]。

**细菌病原体**
继发性细菌感染常使角膜溃疡复杂化。从角膜分离的常见细菌包括葡萄球菌属、链球菌属、假单胞菌属和大肠杆菌[7]。铜绿假单胞菌尤其值得注意，因其产生的蛋白水解酶可导致快速进展的溶解性溃疡[1]。在犬和马中，大多数溃疡起源于机械性损伤，而在猫中，传染性病原体和机械性原因同等重要[1]。所有角膜溃疡都有继发性细菌污染和内源性蛋白酶"溶解"基质的潜力[1]。

**其他传染性病原体**
猫衣原体可导致结膜炎，并可能与角膜疾病相关，尽管它通常不引起溃疡性病变[2][3]。这种生物体在猫呼吸道疾病复合体中尤其相关，需要特定的抗菌治疗。

### Sources
[1] Merck Veterinary Manual The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[2] Feline viral upper respiratory disease: why it persists! (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[3] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[7] Understanding how the cornea heals offers insights into treatment: https://www.dvm360.com/view/understanding-how-cornea-heals-offers-insights-treatment

## 临床症状和体征

角膜溃疡表现为特征性的眼部疼痛表现，包括睑痉挛（眯眼）、流泪（过度流泪）和畏光（光敏感）[1][2][3]。这些体征伴有结膜充血和角膜混浊，可能表现为水肿、细胞浸润或角膜不规则[2][4]。

临床表现因溃疡深度和复杂性而异。浅表溃疡通常表现出中度不适，使用荧光素染色时角膜清晰着色[3]。深部溃疡表现出更严重的疼痛，患者通常将受影响的眼睛完全闭合，并可能因基质溶解而呈现凝胶状外观[4]。感染性溃疡在溃疡边缘有致密的白色浸润物和黏液脓性分泌物[2]。

**品种特异性模式**

某些品种对特定类型的角膜溃疡表现出易感性。拳师犬常发生惰性角膜溃疡（自发性慢性角膜上皮缺损），其特征为具有疏松上皮边缘的非愈合性浅表溃疡[3]。像北京犬这样的短头颅品种因眼球突出和眼睑闭合不全而易发生暴露相关性溃疡[2]。

**非典型表现**

一些溃疡可能似乎"时隐时现"，因为疏松的上皮暂时覆盖缺损，然后再次翻转出来[3]。非愈合性溃疡通常在荧光素阳性区域周围显示出特征性的疏松上皮"唇"，在更亮的中央染色周围形成暗淡的光晕效应[3]。

### Sources
[1] DVM 360 Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[2] Merck Veterinary Manual The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] DVM 360 A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[4] DVM 360 Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers

## 诊断方法

诊断角膜溃疡需要结合临床检查和专业诊断技术的系统方法[2]。基本眼科检查应包括希尔默泪液试验（STT）、荧光素染色和眼内压（IOP）测量，因为这些诊断可以识别促成因素并排除并发疾病[2]。

**荧光素染色**
荧光素染色仍然是检测角膜溃疡的金标准[2,4]。除了识别溃疡外，荧光素还可以评估泪膜破裂时间（TFBUT）以诊断定性泪膜缺陷，正常值约为20秒[2]。Seidel试验使用浓缩荧光素检测后弹力层膨出的房水渗漏，其中流出的绿色稀释液表明穿孔风险[2]。Jones试验评估鼻泪管通畅性，染料在5分钟内出现在鼻孔[2]。

**其他诊断方法**
希尔默泪液试验可识别水液缺乏（低值）和继发于角膜刺激的过度流泪（>25mm/分钟）[2]。然而，由于猫的正常泪液产生量较低和交感神经系统影响，STT值在猫中可能难以解释[6]。所有基质溃疡都应进行角膜细胞学的培养和敏感性测试，理想情况下在应用荧光素之前进行，以防止生长抑制[2,4]。光学相干断层扫描等先进成像技术允许详细检查角膜深度和结构，而超声生物显微镜可以评估前房角[1]。病毒检测的PCR检测可用但有限制，由于处理要求，假阴性常见[6]。

### Sources
[1] Merck Veterinary Manual Glaucoma: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/glaucoma-in-animals
[2] Ocular Exam Techniques: https://www.dvm360.com/view/turning-your-ocular-exam-techniques-better-diagnosis-proceedings
[3] Management of Corneal Ulcers: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3860707&pid=11242
[4] Corneal Ulcers Treatment: https://veterinarypartner.vin.com/doc/?id=4951434&pid=19239
[5] Feline Keratitis Reference: https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[6] Corneal Disease Review: https://www.dvm360.com/view/corneal-disease-proceedings

## 治疗选择

角膜溃疡需要结合医疗和手术干预的多方面治疗方法。医疗管理从局部抗生素开始，环丙沙星和氧氟沙星等氟喹诺酮类药物是角膜感染的首选抗生素[1]。这些药物提供对革兰氏阳性和革兰氏阴性细菌的广谱覆盖，并具有优异的角膜渗透性[2]。

对于猫角膜溃疡，立即进行局部抗病毒治疗至关重要，因为猫疱疹病毒是最常见的原因[1]。三氟胸苷1%溶液是目前猫疱疹病毒性角膜炎的首选药物，每日4-6次给药[1]。替代性抗病毒药物包括0.1%碘苷和0.5%西多福韦，后者提供每日两次给药的优势以改善依从性[1]。

疼痛管理使用1%阿托品每日1-2次以控制睫状肌痉挛并提供舒适感[2]。严重的溶解性溃疡可能需要抗胶原酶药物，如乙酰半胱氨酸，稀释至5-8%浓度[3]。

对于深层基质溃疡或后弹力层膨出，手术干预成为必要。结膜瓣是最常见的手术程序，提供结构支持和血液供应[2]。带蒂瓣技术最容易执行，对大多数病例足够，在移除前保持完整6-8周[2]。其他手术选择包括角膜结膜转位瓣和A细胞和BioSist等生物合成移植物材料[4]。

对于惰性溃疡，专门治疗包括线性网格角膜切开术和金刚石磨头浅层角膜切除术，这些方法比传统网格角膜切开术显示更快的愈合时间[4]。这些程序突破透明膜以促进适当的上皮粘附[4]。

新兴疗法显示出前景，包括用于溶解性溃疡的羊膜组织移植物和用于增强愈合的富血小板纤维蛋白应用，尽管临床方案仍在建立中[5][6]。

### Sources
[1] 6 eye errors you're probably overlooking: https://www.dvm360.com/view/6-eye-errors-you-re-probably-overlooking
[2] Understanding how the cornea heals offers insights into treatment: https://www.dvm360.com/view/understanding-how-cornea-heals-offers-insights-treatment
[3] Current and practical updates on ocular therapeutics (Proceedings): https://www.dvm360.com/view/current-and-practical-updates-ocular-therapeutics-proceedings
[4] Corneal surgical techniques: Conjunctival pedicle grafts and beyond (Proceedings): https://www.dvm360.com/view/corneal-surgical-techniques-conjunctival-pedicle-grafts-and-beyond-proceedings
[5] The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[6] Methodology of easy-to-use horizontally centrifuged platelet: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0204/javma.25.03.0204.xml

## 预防措施

猫疱疹病毒-1（FHV-1）的疫苗接种策略代表了猫角膜溃疡预防的基石。核心疫苗接种方案包括FHV-1疫苗，这些疫苗可减少病毒脱落和疾病严重程度，尽管它们不能完全预防感染[1]。注射和鼻内疫苗都可用，兽医建议适当的时间以获得最佳保护[2]。

环境管理侧重于减少创伤风险和控制传染性传播。硬质塑料伊丽莎白圈对防止受影响动物的自伤至关重要[3]。环境污染控制至关重要，因为FHV-1通过眼、鼻和口腔的分泌物以及受污染的物体传播[2]。

减压在预防中起着至关重要的作用，因为压力会触发FHV-1重新激活。避免压力情况，包括新宠物、住房变化、饮食改变和并发疾病，有助于预防病毒激活[2]。皮质类固醇药物应谨慎使用，因为它们可能触发病毒重新激活[2]。

定期眼科检查能够早期发现角膜异常，特别是在高风险品种和环境中。感染病例的隔离方案有助于防止在收容所和寄养设施等多猫环境中的疾病传播，这些环境中压力大的猫被聚集在一起[2]。

### Sources
[1] Vaccines against feline viral rhinotracheitis and calicivirus: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[2] Feline Herpesvirus-1 prevention and stress management: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/eye-disorders-resulting-from-generalized-diseases-in-cats
[3] Prevention of self-trauma in corneal ulcer management: https://www.dvm360.com/view/mastering-corneal-ulcers-part-2-

## 鉴别诊断

角膜溃疡必须与几种可表现为相似临床体征（发红、疼痛和视力障碍）的眼部疾病相鉴别。最常见的鉴别诊断包括结膜炎、青光眼和前葡萄膜炎[1][2]。

**结膜炎**通常表现为结膜充血和分泌物，但缺乏定义角膜溃疡的荧光素染色吸收。然而，慢性结膜炎可能导致继发性角膜变化，使鉴别变得具有挑战性[2]。

**青光眼**可引起角膜水肿和疼痛，模拟溃疡性疾病。关键鉴别特征包括眼内压升高（>25 mmHg）、瞳孔扩张和无荧光素吸收[3][4]。角膜水肿的具体主要鉴别诊断包括角膜溃疡、葡萄膜炎或青光眼，这些通常通过全面检查容易区分[3][4]。

**前葡萄膜炎**表现为房水闪光、瞳孔缩小和通常眼内压降低，这与大多数角膜溃疡中看到的正常压力形成对比。荧光素染色在诊断葡萄膜炎时对于排除角膜溃疡至关重要[1][5]。大多数红眼与葡萄膜炎和涉及血眼屏障破坏的眼内出血相关[2]。

**角膜营养不良和变性**可能导致混浊，但通常缺乏上皮破坏和疼痛。内皮营养不良导致蓝色角膜水肿而无溃疡，而脂质角膜病表现为晶体沉积[4]。

包括荧光素染色、眼压测量和全面前段评估的系统检查能够准确区分这些疾病并选择适当的治疗。

### Sources

[1] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment

[2] The red eye: diagnostics and treatment (Proceedings): https://www.dvm360.com/view/red-eye-diagnostics-and-treatment-proceedings

[3] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings

[4] Canine corneal diseases: secrets for transparency greater than the federal stimulus (Proceedings): https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings

[5] A challenging case: Uveitis and secondary glaucoma in a cat: https://www.dvm360.com/view/challenging-case-uveitis-and-secondary-glaucoma-cat
