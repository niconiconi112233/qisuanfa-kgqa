# 伴侣动物乳头状瘤：综合兽医指南

乳头状瘤是影响伴侣动物（尤其是犬）最常见的良性病毒性肿瘤之一。本报告为兽医专业人员提供了在小动物临床中管理乳头瘤病毒感染的基本临床知识。综合分析涵盖了流行病学模式，显示了明显的年龄相关表现，从幼犬的多发性口腔病变到老年动物的令人担忧的免疫缺陷指标。报告探讨了包括视觉检查和组织病理学在内的关键诊断方法，以及新兴的治疗方式，如咪喹莫特免疫疗法和阿奇霉素方案。报告还讨论了关键的鉴别诊断和预后因素，同时强调了通过适当的管理策略通常可获得优异的结果。

## 摘要

伴侣动物的乳头状瘤表现为一种可管理的病毒性疾病，具有独特的临床模式和治疗方式。幼犬通常发展为多发性口腔乳头状瘤，这些瘤体常通过免疫系统成熟而自发消退，而患有广泛病变的老年动物可能需要检查潜在的免疫缺陷状况，如淋巴瘤。

| 方面 | 犬 | 猫 |
|--------|------|------|
| **主要部位** | 口腔黏膜、嘴唇 | 皮肤病变，罕见口腔 |
| **年龄偏好** | 幼犬/青春期 | 10岁以上 |
| **预后** | 优异，常自限性 | 治疗后良好 |
| **恶性潜能** | 罕见 | 较高风险（与鳞状细胞癌相关） |

当前的治疗策略强调以2cm边缘的外科切除作为金标准，而新兴疗法如局部咪喹莫特和口服阿奇霉素提供了有前景的替代方案。预防依赖于环境管理和隔离方案，因为没有特定的疫苗存在。大多数病例（尤其是幼犬）的优异预后支持保守管理方法，外科干预仅保留用于影响生活质量的问题性病变。

## 疾病概述

乳头状瘤是由犬乳头瘤病毒感染引起的良性肿瘤，主要影响犬，尽管在猫中很少发生[1]。这些病毒诱导的肿瘤呈现为手指状或丝状突起，具有特征性的花椰菜样表面，最常影响口腔黏膜、黏膜皮肤交界处和嘴唇周围的皮肤[1][2]。

该病在犬中表现出明显的年龄相关模式。幼犬和青春期犬通常发展为多发性口腔乳头状瘤，这些瘤体突然出现并迅速生长和扩散[1]。当成年犬出现多发性乳头状瘤时，应怀疑潜在的免疫缺陷状况，如淋巴瘤[1]。研究表明，犬乳头瘤病毒感染有三种不同的临床表现：犬黏膜乳头状瘤病是最常见的形式[2]。

传播通过与受感染动物或受污染环境的直接接触发生，因为病毒需要通过轻微的皮肤擦伤或黏膜破损才能机械性引入。在猫中，乳头瘤病毒感染与鳞状细胞癌和基底细胞癌的发展相关，表明与犬相比具有更令人担忧的进展潜能[1]。此外，猫乳头瘤病毒与多中心原位鳞状细胞癌（鲍文病）相关，特别是在10岁以上的免疫抑制猫中[2]。

### Sources

[1] Oral Papillomas in Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs

[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

Looking at the provided source materials, I can identify relevant information about papillomavirus from sources 3 and 8. I'll synthesize this with the existing content to expand on papillomavirus etiology and pathogenesis.

## 常见病原体

伴侣动物的乳头状瘤由属于乳头瘤病毒科的种特异性DNA病毒引起。犬乳头瘤病毒是导致犬口腔乳头状瘤的主要病原体[1]。这些是无包膜的双链DNA病毒，特异性靶向上皮细胞。

该病毒表现出严格的宿主特异性，仅影响犬科动物。口腔乳头瘤病毒对口腔黏膜、黏膜皮肤交界处和口周皮肤的快速分裂细胞显示出特殊的趋向性[1]。

在猫中，几种皮肤病综合征与猫乳头瘤病毒感染相关，尽管猫通常不像犬那样发展为口腔疣[2]。猫乳头瘤病毒导致包括鲍文病和猫肉芽肿在内的疾病[2]。

幼犬最容易感染乳头瘤病毒，幼犬和青春期动物显示出更高的感染率。患有多发性乳头状瘤的成年犬可能表明潜在的免疫缺陷，表明病毒复制通常由完整的细胞免疫控制[1]。

病毒通过与受感染动物或受污染表面的直接接触传播。与其他病毒病原体相比，乳头瘤病毒的环境持久性有限，因为这些病毒需要活的上皮细胞进行复制和生存。

### Sources
[1] Oral Papillomas in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
[2] Feline viral skin diseases (Proceedings): https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings

## 临床表现和诊断

犬和猫的乳头状瘤表现为良性上皮肿瘤，具有明显的解剖位置模式。口腔乳头状瘤在幼犬中最常见，表现为舌、牙龈或腭上的小型白色至粉红色花椰菜样生长物[1]。这些病变通常测量2-15mm，可能以单一肿块或多发性簇状生长物出现。

皮肤乳头状瘤表现为粗糙、角化表面的隆起疣状病变。它们常见于头部、颈部和四肢，特别是在老年动物中。眼部乳头状瘤较少见，但可能发生在眼睑或结膜上，可能导致继发性刺激或分泌物。

非典型表现包括大的带蒂肿块，可能在免疫功能低下的患者中发生恶性转化。一些乳头状瘤可能伴有继发性细菌感染，导致炎症和外观改变。

诊断主要依靠视觉检查和临床表现[2]。组织病理学检查仍然是金标准，显示特征性上皮增生伴有挖空细胞改变和病毒包涵体[2]。在需要时，PCR检测可以识别特定的乳头瘤病毒株[2]。免疫组织化学可用于确认受影响组织内的病毒抗原，尽管这在临床常规诊断中很少必要。细针抽吸通常产生具有特征性形态的簇状上皮细胞[3]。

### Sources
[1] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.03.0153.xml
[2] Merck Veterinary Manual - Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[3] DVM360 - Cytologic Diagnoses: https://www.dvm360.com/view/cytologic-diagnoses-every-practicing-veterinarian-should-be-able-make-proceedings

## 治疗和管理

伴侣动物乳头状瘤的治疗方法强调外科切除作为主要干预措施[1]。对于犬和猫，病变的外科切除或受影响的趾或耳廓的截肢代表治疗选择，推荐边缘至少为2厘米[1]。

新兴的免疫调节疗法在乳头状瘤管理中显示出前景。5%咪喹莫特乳膏在每周连续应用2-4天时已显示出治疗犬乳头瘤病毒感染的成功结果[2]。这种免疫调节剂刺激Toll样受体7，激活对病毒病变的自然免疫反应[2]。

冷冻疗法提供了另一种治疗方式，对早期病变特别有效。电穿孔和热疗提供替代的局部治疗选择，尽管记录其有效性的对照研究仍然有限[1]。

支持性护理策略包括干扰素疗法，已显示出管理乳头瘤病毒感染的疗效。据报道，每日1,000 IU的低剂量口服干扰素α-2a用于犬乳头瘤病毒治疗[2]。干扰素的抗病毒和免疫调节特性使其成为有价值的辅助治疗。

阿奇霉素疗法代表了犬乳头状瘤病的一种新兴抗生素方法。以10 mg/kg每24小时口服一次的阿奇霉素治疗似乎有效，可在2-3周内消除病变[3]。这种大环内酯抗生素的抗炎和免疫调节特性有助于其对抗乳头瘤病毒感染的疗效[4]。

外科方法仍然是基础，完全切除对局限性病变具有治愈性[1]。对于广泛或多发性病变，结合外科减瘤与免疫调节剂的联合治疗可能优化结果。

### Sources

[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] What's new in dermatologic therapy?: https://www.dvm360.com/view/whats-new-dermatologic-therapy
[3] Oral Papillomas in Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
[4] Infectious skin disease in cats, more than you realized: https://www.dvm360.com/view/infectious-skin-disease-cats-more-you-realized-proceedings

## 预防和预后

**预防措施**

目前，伴侣动物没有针对乳头瘤病毒的特定疫苗[1]。口腔乳头状瘤的预防主要依赖于最小化受感染和易感动物之间的直接接触，特别是幼犬[1]。传播通过直接接触或受污染物体发生，使环境管理变得至关重要[6]。

隔离方案应将受影响动物分开，直到病变消退。病毒可以在受污染表面上持续存在，需要使用适当的抗病毒剂进行彻底清洁和消毒[1][2]。**有效的消毒剂包括稀释漂白剂（1:32稀释）、过氧单硫酸钾和加速过氧化氢，而季铵盐产品已被证明对细小病毒无效**[4]。

**预后**

犬口腔乳头状瘤的预后通常优异[6]。这些良性生长物通常在数周至数月内自发消退，因为免疫系统发展出保护性免疫[6]。幼犬通常比免疫功能低下的动物有更好的结果[6]。

必要时，完全手术切除通常可防止复发[6]。然而，发展为乳头状瘤的犬如果再次暴露，可能易于未来病变[6]。**大多数病例无需干预即可消退，尽管影响进食或呼吸的严重病例可能需要治疗**[6]。

**预后因素**

年龄显著影响结果，幼犬比具有潜在免疫缺陷的老年动物显示出更高的恢复率[6]。多发性病变或广泛受累可能表明免疫功能受损，并需要检查潜在状况，如淋巴瘤[6]。

### Sources

[1] Merck Veterinary Manual Preventative Health Care for Small Animals: https://www.merckvetmanual.com/management-and-nutrition/preventative-health-care-and-husbandry-in-small-animals/preventative-health-care-for-small-animals

[2] Canine parovirus and feline panluekopenia: New ideas for prevention, risk assessment, and treatment: https://www.dvm360.com/view/canine-parovirus-and-feline-panluekopenia-new-ideas-prevention-risk-assessment-and-treatment-parts-1

[3] Merck Veterinary Manual Canine Parvovirus Infection: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

[4] Merck Veterinary Manual Feline Panleukopenia: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia

[5] DVM 360 Podcast CE: New guidelines in the management of canine parvovirus: https://www.dvm360.com/view/podcast-ce-new-guidelines-in-the-management-of-canine-parvovirus

[6] Oral Papillomas in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
