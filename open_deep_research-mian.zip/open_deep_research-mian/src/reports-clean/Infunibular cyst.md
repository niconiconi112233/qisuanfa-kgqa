# 伴侣动物漏斗部囊肿

漏斗部囊肿是小动物兽医实践中最常见的皮肤囊肿类型，作为良性毛囊异常影响犬和猫。这些包膜性病变源于毛囊漏斗部的囊性扩张，表现为含有特征性角质物质的坚实、可移动结节。本综述全面探讨了伴侣动物漏斗部囊肿的临床表现、诊断方法和治疗策略。报告涵盖了包括其他毛囊囊肿类型和皮脂腺病变在内的关键鉴别诊断，强调了完全手术切除的关键重要性，并讨论了挪威猎麋犬和拉萨犬的品种易感性。正确理解管理方法可预防囊肿破裂并发症，同时确保最佳患者预后。

## 摘要

漏斗部囊肿是良性、非感染性毛囊病变，是犬和猫最常见的皮肤囊肿类型。这些发育异常通常表现为含有灰棕色角质物质的坚实、可移动结节，最常见于中年动物的背部、尾部和四肢。主要诊断发现包括细胞学检查中的特征性角质碎屑，尽管组织病理学可提供确诊。

| 诊断特征 | 漏斗部囊肿 | 皮脂腺瘤 | 脂肪瘤 |
|-------------------|-------------------|-------------------|--------|
| 细胞学 | 角质碎屑，无核鳞状细胞 | 泡沫状脂质充盈细胞 | 脂肪物质 |
| 质地 | 坚实，部分可压缩 | 可变 | 柔软，波动感 |
| 治疗 | 完全手术切除 | 手术切除 | 如有指征则手术切除 |

完全手术切除提供良好预后，治愈率接近100%。必须避免剧烈操作以防止角质释放和继发性炎症。挪威猎麋犬和拉萨犬因易患全身性形式需要持续监测。早期识别和适当手术管理可确保最佳结果，同时预防囊肿破裂并发症。

## 疾病概述

漏斗部囊肿是犬和猫最常见的皮肤囊肿类型，代表真皮内表皮细胞和角质物质的良性包膜性增生[1]。这些囊肿源于毛囊畸形，特别是漏斗部（毛囊外根鞘上部）的囊性扩张[2]。

也称为毛囊囊肿、表皮样囊肿或表皮包涵囊肿，漏斗部囊肿在犬中常见，在猫中偶有发现[2]。囊肿内衬与表皮相同的分层角化上皮细胞，含有由管腔角质组成的灰色、棕色或淡黄色颗粒状物质[2]。这些病变大小从2毫米到超过5厘米直径不等，小于5毫米的较小变异体常被称为粟粒疹[2]。

虽然漏斗部囊肿的特定流行病学数据有限，但它们是伴侣动物中最常记录的皮肤囊肿类型[1]。大多数角化皮肤囊肿，包括漏斗部变异体，通常发生于中年至老年动物[2]。尚未确定犬和猫的特定品种易感性，尽管某些毛囊囊肿类型在其他物种中显示品种倾向。

### Sources
[1] What Is Your Diagnosis? in: Journal of the American ... - AVMA: https://avmajournals.avma.org/view/journals/javma/249/10/javma.249.10.1135.xml
[2] Merck Veterinary Manual Epidermal and Hair Follicle Tumors in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 常见病原体

漏斗部囊肿通常被认为是非感染性发育性病变，没有确定的微生物病因学[1]。与其他犬类皮肤疾病如趾间毛囊炎不同，后者通常由包括葡萄球菌属、梭菌属、大肠杆菌属、拟杆菌属和巴氏杆菌属在内的细菌深度感染引起，漏斗部囊肿没有原发性病毒、细菌或寄生虫致病因子[1]。

漏斗部囊肿的发病机制涉及毛囊创伤和随后的角质潴留，而非感染过程[1]。然而，如果囊肿受到创伤或破裂，可能发生继发性细菌感染，可能涉及常见皮肤细菌如伪中间葡萄球菌（犬脓皮症的主要病原体）[2]。这些继发性感染代表并发症而非原发性致病因素。

漏斗部囊肿缺乏确定致病病因学，这将其与感染性毛囊疾病如蠕形螨病或细菌性脓皮症区分开来。当前兽医文献不支持特定病毒、细菌或真菌因子作为伴侣动物漏斗部囊肿发展的主要原因。

### Sources

[1] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs

[2] Pyoderma in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats

## 临床症状和体征

漏斗部囊肿通常表现为丘疹或结节，具有特征性中央角质化孔，可能突出于表皮表面，形成角状外观[1]。然而，许多这些病变从未与表皮建立连续性，可能仅表现为皮肤下的角质化囊肿[1]。这些良性肿瘤最常见于中年犬的背部、尾部和四肢[1]。

囊肿大小差异显著，范围从小于5毫米直径（常称为粟粒疹）到超过5厘米[1]。它们通常表现为坚实、孤立、丘疹样至结节样病变，可自由移动，触诊时偶尔部分可压缩[1]。一些病变可能有通过表皮的小开口，可从中挤出囊肿内容物[1]。

切开时，漏斗部囊肿含有特征性灰色、棕色或淡黄色颗粒状、干酪样物质，由管腔角质组成[1]。挪威猎麋犬、比利时牧羊犬、拉萨犬和古代英国牧羊犬显示品种易感性，挪威猎麋犬和拉萨犬特别易患全身性疾病形式[1]。

肿瘤壁破裂可将角质释放到周围组织中，引发化脓性肉芽肿性炎症反应，可能导致继发性并发症[1]。患有全身性形式的犬在存在多个病变时可能受益于口服类视黄醇治疗[1]。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 诊断方法

漏斗部囊肿的诊断主要依靠临床表现评估和细胞学检查[1]。细针抽吸细胞学（FNA）是评估皮肤囊肿最实用和最常用的诊断方法[1]。抽吸物质通常显示大量角质碎屑，在大体检查中呈现为颗粒状、干酪样物质，呈灰色、棕色或淡黄色外观[3]。

FNA样本的细胞学评估显示角质物质，可能包括上皮细胞，但由于这些病变的囊性特征，细胞产量通常较低[1]。可进行毛发描记术以识别任何并发的蠕形螨，这可能使临床情况复杂化[2]。

组织病理学检查提供确诊，当临床表现不典型或怀疑恶性转化时建议进行[3]。活检显示毛囊漏斗部的囊性扩张，内衬与表皮无法区分的分层角化上皮细胞[3]。

影像学检查对单纯漏斗部囊肿用途有限。然而，超声检查偶尔可用于评估较深部的囊性结构或在疑难病例中引导FNA操作[5]。大多数漏斗部囊肿通过体格检查和细胞学评估即可确诊，无需先进的影像学技术。

### Sources

[1] Cytologic diagnoses that every practicing veterinarian should be able to make (Proceedings): https://www.dvm360.com/view/cytologic-diagnoses-every-practicing-veterinarian-should-be-able-make-proceedings

[2] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs

[3] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

[4] Ultrasonography in Animals - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/ultrasonography-in-animals

## 治疗选择

手术切除是犬和猫漏斗部囊肿的首选治疗方法[1]。完全切除可治愈这些良性毛囊囊肿，它们内衬分层角化上皮细胞并充满角质物质[1]。囊肿大小从2毫米到超过5厘米直径不等[1]。

严禁用力挤压或操作漏斗部囊肿，因为这可能破裂囊肿壁并将角质释放到周围组织中[1]。这种角质物质作为异物发挥作用，引发严重炎症反应，可导致化脓性肉芽肿性炎症和继发性并发症[2]。

术后护理通常简单，因为这些是良性病变，完全手术切除后具有良好愈合潜力。主人应监测手术部位是否有感染或过度肿胀迹象。大多数动物术后经历最小不适。

预防复发需要在初次手术时完全切除囊肿壁[1]。不完全切除可能导致囊肿再形成。虽然漏斗部囊肿通常是孤立性病变，但一些患者可能随时间在不同部位发展出额外囊肿，需要持续监测。药物治疗对这些囊肿无效[3]。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[3] Prostatic and Paraprostatic Cysts in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-and-paraprostatic-cysts-in-dogs-and-cats

## 预防措施

目前，犬和猫漏斗部囊肿没有特定的预防措施，因为这些良性毛囊囊肿似乎是通过毛囊形成中的发育异常发展而来，而非感染或环境原因[1]。

**环境管理**
虽然不是直接预防，但保持适当的梳毛习惯并通过轻柔处理避免毛囊创伤可能是有益的。对于涉及紫外线相关皮肤疾病的情况，限制上午10:00至下午2:00之间的紫外线辐射暴露有助于预防日光诱导的并发症[1]。为圈养动物提供适当表面，防止铁丝笼或粗糙地面造成的创伤性毛囊损伤，这是推荐的[1]。

**品种考虑因素**
漏斗部囊肿没有特定的品种筛查方案，因为它们零星发生，没有确定的遗传模式[1]。虽然某些品种如罗得西亚脊背犬易患其他毛囊疾病如皮样囊肿，但漏斗部囊肿缺乏需要针对性筛查的明确遗传关联[1]。

**一般管理**
定期兽医检查可在并发症发展前实现早期检测。宠物主人应监测生长的皮肤肿块并寻求兽医评估，而非尝试家庭治疗[1]。漏斗部囊肿的零星发生和良性性质意味着尚未制定特定预防方案，重点仍然是通过组织病理学进行正确诊断以及在临床指征时进行适当手术管理。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 鉴别诊断

漏斗部囊肿必须与几种其他临床表现相似的皮肤囊肿和肿块进行鉴别。最重要的鉴别诊断包括其他毛囊囊肿类型和良性皮肤肿块。

**其他毛囊囊肿**代表主要鉴别诊断。峡部退行期囊肿（毛根鞘囊肿）源于外根鞘下部，表现出不同的角化模式[1]。基质囊肿起源于毛球上皮，可能进展为毛母质瘤[3]。混合囊肿（全毛囊囊肿）结合多种毛囊囊肿类型的特征，常进展为毛上皮瘤[3]。

**皮脂腺囊肿**常与漏斗部囊肿混淆，但源于皮脂腺而非毛囊。细胞学上，皮脂腺瘤含有泡沫状细胞，胞质富含脂质，与漏斗部囊肿的典型角质碎屑形成对比[6,7]。

**需要鉴别的其他皮肤肿块**包括脂肪瘤，抽吸时产生脂肪物质而非角质[7,8]；以及基底细胞肿瘤，表现为小的嗜碱性细胞凝聚群而非角质物质[6]。

**关键鉴别特征**包括抽吸内容的细胞学检查。漏斗部囊肿产生角质碎屑和无核鳞状细胞，而皮脂腺病变含有泡沫状脂质充盈细胞[6,7]。特定毛囊囊肿类型的确诊需要组织病理学检查，因为细胞学无法可靠区分毛囊囊肿变异体[2,3]。仅凭临床表现不足以进行鉴别，因此组织取样对准确诊断至关重要。

### Sources

[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

[2] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs

[3] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

[4] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0

[5] Cytologic diagnoses that every practicing veterinarian should be able to make (Proceedings): https://www.dvm360.com/view/cytologic-diagnoses-every-practicing-veterinarian-should-be-able-make-proceedings

[6] Diagnostic cytology--the basics (Proceedings): https://www.dvm360.com/view/diagnostic-cytology-basics-proceedings

## 预后

犬和猫的漏斗部囊肿通过完全手术切除通常具有良好预后(1)。这些良性、包膜性病变可通过手术切除治愈，适当管理时并发症罕见。

完全切除可治愈并防止复发。然而，应避免剧烈操作或囊肿破裂，因为这可能将角质释放到周围组织中，引发严重肉芽肿性炎症，使愈合复杂化(1)。

对于患有多发性漏斗部囊肿的犬，特别是易患全身性形式的挪威猎麋犬和拉萨犬，即使在成功手术治疗后，不同部位新囊肿复发也很常见(1)。这些患者可能受益于长期口服类视黄醇治疗以减少额外囊肿形成。

在皮样窦囊肿中，完全手术切除提供良好结果。一项病例研究报告完全手术切除后13个月随访无复发的成功愈合(2)。然而，部分切除显著增加复发风险和相关并发症。

大多数角化皮肤囊肿在其整个过程中保持良性。恶性转化极为罕见，仅在特定品种如美利奴羊中有孤立报告，记录了其向鳞状细胞癌的进展(1)。

### Sources

[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

[2] A true dermoid cyst on a golden retriever's dorsal skull: https://www.dvm360.com/view/clinical-exposures-true-dermoid-cyst-golden-retrievers-dorsal-skull
