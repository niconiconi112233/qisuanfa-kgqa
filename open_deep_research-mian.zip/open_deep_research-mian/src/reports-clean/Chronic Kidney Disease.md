# 伴侣动物慢性肾病

慢性肾病是伴侣动物面临的最重大健康挑战之一，尤其是在猫中，影响高达50%的10岁以上动物。这种进行性、不可逆的疾病在四分之三的肾单位失去功能时发展，导致代谢废物积聚和全身性并发症。早期检测仍然具有挑战性，因为临床症状通常在肾功能仅剩15-30%时才出现。本报告探讨了CKD管理的综合兽医方法，包括能够实现早期检测的诊断进展（如SDMA检测）、基于证据的治疗方案（包括肾脏饮食和ACE抑制剂），以及显著影响不同疾病阶段生存结果的预后因素。

## 疾病概述与流行病学

慢性肾病（CKD）是一种进行性、不可逆的疾病，其特征是在数周、数月或数年内逐渐丧失肾单位功能和代偿机制[1]。当双肾中四分之三或更多的肾单位失去功能时，就会发生CKD，导致肾小球滤过减少和代谢废物产物积聚[1]。

CKD的患病率在不同物种间差异显著。在猫中，CKD影响估计1.6%至20%的种群，老年动物的患病率更高[1]。研究表明，CKD总体影响6%的猫，在15岁以上猫中急剧增加到15%[2]。CKD是家猫中最常见的代谢性疾病，占10岁以上猫的25-50%[7]。在狗中，患病率范围为0.5%至7%，使其比猫科动物明显少见[1]。

年龄是主要风险因素，先天性疾病导致3岁以下动物患病率短暂增加，随后从5-6岁开始稳步增加[4]。病理生理学涉及通过肾小球、肾小管、间质组织或肾血管的不可逆损伤导致的进行性肾单位丧失[1]。当肾单位受到不可逆损伤时，愈合通过替代性纤维化发生，这使得确定特定病因通常不可能[1]。剩余肾单位的代偿性肥大最初维持功能，但最终因工作负荷增加和肾小球内高血压而导致其衰竭[1]。

### Sources
[1] Staging and management of chronic kidney disease: https://www.dvm360.com/view/staging-and-management-chronic-kidney-disease-proceedings
[2] Facilitating client management of chronic kidney disease: https://www.dvm360.com/view/facilitating-client-management-chronic-kidney-disease-proceedings
[3] Journal Scan: Do we really know what we think we know about feline chronic kidney disease?: https://www.dvm360.com/view/journal-scan-do-we-really-know-what-we-think-we-know-about-feline-chronic-kidney-disease
[4] Chronic kidney disease in cats: https://www.dvm360.com/view/chronic-kidney-disease-cats-proceedings-0

## 常见病原体和病因

狗和猫的慢性肾病（CKD）由多种传染性和非传染性原因引起。最常见的是，该疾病源于原因不明的慢性肾小管间质性肾炎，但几种可识别的病原体和病因促成CKD的发展[1]。

**传染性原因**

细菌性肾盂肾炎是重要的传染性原因，通常进展为慢性间质性炎症[1]。狗的钩端螺旋体病可导致进展为CKD的急性肾损伤，或通过持续性感染直接导致慢性疾病[1][7]。*Leptospira interrogans*血清型Icterohaemorrhagiae、Pomona、Grippotyphosa和*L kirschneri*已特别与肝和肾疾病相关[11]。在猫中，猫传染性腹膜炎（FIP）通常导致双侧肾肿大和肉芽肿性肾病[2][7]。

额外的细菌原因包括*巴尔通体*属，特别是猫中的*B. henselae*，可能引起多种器官表现，包括潜在的肾脏受累[3][5]。立克次体生物包括*埃里希体*属和*立氏立克次体*可导致全身性炎症和继发性肾损伤[3][5]。

**非传染性原因**

先天性异常包括肾发育不全和肾发育不良是重要原因，特别是在特定品种中[6][9]。多囊肾病作为遗传性疾病发生在波斯猫和某些狗品种中[9][10]。肿瘤原因包括原发性肾肿瘤和淋巴瘤，淋巴瘤在猫中特别常见，通常表现为双侧弥漫性疾病[2]。

**毒性和缺血性原因**

最初引起急性肾损伤的肾毒性药物可进展为CKD。这些包括乙二醇、氨基糖苷类抗生素、非甾体抗炎药和猫中的百合植物[1][7]。由长期低血压、休克或血栓栓塞性疾病引起的缺血性损伤也可导致慢性变化[1][7]。

**肾小球和血管疾病**

原发性肾小球疾病和影响肾血管的全身性疾病，包括高血压和免疫介导性肾小球肾炎，促成进行性CKD[6]。淀粉样变性和其他蛋白沉积疾病也导致慢性肾功能不全[6][7]。

### Sources
[1] Your guide to managing acute renal failure: https://www.dvm360.com/view/your-guide-managing-acute-renal-failure
[2] Renal ultrasonography: kidneys big, small, and in-between: https://www.dvm360.com/view/renal-ultrasonography-kidneys-big-small-and-between-proceedings
[3] Ocular manifestations of systemic disease (Proceedings): https://www.dvm360.com/view/ocular-manifestations-systemic-disease-proceedings
[5] The red eye: diagnostics and treatment (Proceedings): https://www.dvm360.com/view/red-eye-diagnostics-and-treatment-proceedings
[6] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[7] Therapeutic implications of recent findings in feline renal insufficiency: https://www.dvm360.com/view/therapeutic-implications-recent-findings-feline-renal-insufficiency-proceedings
[9] Congenital and Inherited Disorders of the Urinary System of Cats: https://www.merckvetmanual.com/cat-owners/kidney-and-urinary-tract-disorders-of-cats/congenital-and-inherited-disorders-of-the-urinary-system-of-cats
[10] Congenital and Inherited Disorders of the Urinary System in Dogs: https://www.merckvetmanual.com/dog-owners/kidney-and-urinary-tract-disorders-of-dogs/congenital-and-inherited-disorders-of-the-urinary-system-in-dogs
[11

## 临床症状和体征

狗和猫慢性肾病的临床表现随着功能性肾质量的下降而遵循可预测的模式。最早的临床体征是多尿和烦渴，通常在大约三分之二的肾单位丧失时出现[1][2]。患有进展性CKD的狗和猫通常直到至少50-67%的肾质量丧失才显示临床症状[2]。

随着疾病进展到第3和第4阶段，全身性尿毒症体征变得明显。这些包括厌食、体重减轻、脱水、呕吐、腹泻、口腔溃疡和嗜睡[3]。最初，尿毒症表现为偶尔呕吐和嗜睡，在狗中数月进展，在猫中数年进展[3]。

**物种特异性模式**值得注意。患有CKD的猫即使在氮质血症时也可能保留实质性的尿液浓缩能力，特别是那些患有肾小球疾病的猫[3]。一些受影响的猫可以在维持尿比重高于1.035的情况下发展为氮质血症[3]。

**品种易感性**存在于几种形式的CKD中。肾发育不良的临床体征，包括进展为厌食、呕吐和体重减轻等尿毒症体征的多尿/烦渴，常见于拉萨犬、金毛寻回犬和可卡犬等品种[4]。患有多囊肾病的波斯猫通常在7-8岁时发展为肾衰竭，表现为多尿、烦渴、厌食、体重减轻、被毛不良和嗜睡[6]。

范可尼综合征表现为多尿/烦渴、脱水、体重减轻、虚弱和被毛不良，可能进展为尿毒症体征[1]。肾小球疾病的标志是严重蛋白尿，伴有嗜睡、食欲不振、体重减轻等非特异性体征，以及可能的高血压相关并发症[5]。

### Sources
[1] Renal Tubular Defects in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-tubular-defects-in-dogs-and-cats
[2] Prolonging life and kidney function (Proceedings): https://www.dvm360.com/view/prolonging-life-and-kidney-function-proceedings
[3] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[4] Renal Anomalies in Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/congenital-and-inherited-anomalies-of-the-urinary-system/renal-anomalies-in-animals
[5] Glomerular Disease in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/glomerular-disease-in-dogs-and-cats
[6] Overview of feline renal disease (Proceedings): https://www.dvm360.com/view/overview-feline-renal-disease-proceedings

## 诊断方法

诊断慢性肾病需要结合临床表现、实验室分析和影像学研究的系统方法。脱水时无法产生浓缩尿液是早期临床体征，脱水动物的尿比重在狗中>1.030，在猫中>1.035[1]。尿液浓缩能力的丧失发生在大约三分之二的肾单位丧失时，通常在CKD第1-2阶段[1]。

实验室评估侧重于血清肌酐和对称二甲基精氨酸（SDMA）浓度。SDMA提供更早的检测，在仅25-40%的肾功能丧失时升高，而肌酐在65-75%肾单位丧失后增加[2]。SDMA升高先于肌酐增加，在狗中约提前9.8个月，在猫中提前17个月[2]。国际肾脏兴趣协会（IRIS）分期系统根据肌酐和SDMA值将CKD分为四个阶段[1]。

尿液分析评估包括用于蛋白尿评估的尿蛋白:肌酐比值（UPC），正常值<0.4，在没有尿路炎症的情况下持续升高表明病理性蛋白尿[5]。血压测量是必要的，因为全身性高血压影响大约20%患有CKD的狗[6]。影像学方法包括放射学和超声检查，有助于评估肾脏大小、结构，并识别潜在原因，如肾结石或梗阻性尿路病[1][6]。

对这些参数的连续监测允许趋势分析和早期干预，这至关重要，因为临床症状通常在75%的肾单位失去功能时才出现[1]。

### Sources
[1] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[2] SDMA: Satisfy your need for speed (in diagnosing CKD): https://www.dvm360.com/view/sdma-satisfy-your-need-speed-diagnosing-ckd
[5] Prolonging life and kidney function (Proceedings): https://www.dvm360.com/view/prolonging-life-and-kidney-function-proceedings
[6] Noninfectious Diseases of the Urinary System in Dogs: https://www.merckvetmanual.com/dog-owners/kidney-and-urinary-tract-disorders-of-dogs/noninfectious-diseases-of-the-urinary-system-in-dogs

## 治疗选择

慢性肾病治疗采用多模式方法，针对多种病理生理过程，以减缓疾病进展并提高生活质量[1]。基于证据的治疗干预根据疾病严重程度和个体患者需求进行分期。

**饮食管理**
肾脏饮食构成CKD治疗的基石，在狗和猫中都显示出显著的生存益处[2]。这些特殊配方的饮食具有限制磷（减少70-80%）、适度限制蛋白质并使用高生物价值来源、减少钠和补充omega-3脂肪酸的特点[3]。临床研究表明，喂食肾脏饮食的猫比喂食维持饮食的猫存活时间长两倍，在24个月研究期间没有发生尿毒症危机[2]。

**ACE抑制剂和蛋白尿管理**
贝那普利和其他ACE抑制剂通过降低肾小球内压力、减少蛋白尿和潜在减缓疾病进展提供肾保护作用[1]。这些药物对有明显蛋白尿的患者特别有益（猫UPC >0.4，狗>0.5）[4]。ACE抑制剂还提供轻度降压作用，但可能需要联合治疗以实现最佳血压控制。

**高血压管理**
全身性高血压影响大约三分之一的CKD患者，需要积极管理[4]。氨氯地平是猫的一线降压药物，而狗可能受益于初始ACE抑制剂治疗，并根据需要添加氨氯地平[1]。目标收缩压应保持在160 mmHg以下，以尽量减少靶器官损伤。

**磷控制和支持性护理**
当单独饮食限制不能维持正常磷水平时，需要磷结合剂[2]。额外的支持措施包括皮下液体治疗、钾补充、食欲刺激剂和管理继发性并发症如贫血和代谢性酸中毒[1]。

### Sources
[1] Chronic renal disease in cats: treat 'em, don't kill 'em: https://www.dvm360.com/view/chronic-renal-disease-cats-treat-em-dont-kill-em-proceedings
[2] Prolonging life and kidney function: https://www.dvm360.com/view/prolonging-life-and-kidney-function-proceedings
[3] Feeding pets with renal disease: https://www.dvm360.com/view/feeding-pets-with-renal-disease-proceedings
[4] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats

## 预防措施

预防狗和猫的慢性肾病需要全面的方法，侧重于早期检测、风险因素管理和环境保护。**早期筛查方案**至关重要，特别是在老年患者中，因为临床症状通常在肾功能仅剩15-30%时出现(1)。常规监测应包括血清肌酐、尿比重评估，以及使用尿蛋白-肌酐比值或微量白蛋白尿检测进行蛋白尿筛查(1)。

**饮食管理**在预防中起着关键作用。限制磷含量的治疗性肾脏饮食已显示出显著益处，研究表明在患有CKD的狗和猫中延长生存时间和减少尿毒症发作(2,4)。这些饮食通常含有降低的蛋白质水平、增加的omega-3脂肪酸和增强的适口性，以确保足够的卡路里摄入(4)。

**避免肾毒性药物**仍然至关重要。在使用潜在有害药物时，仔细的药物选择和监测是必要的。应在使用肾毒性药物之前建立常规基线实验室值，并在治疗期间每两到四个月进行定期重新评估(1)。

**易感条件的管理**包括控制全身性高血压和预防可能加速疾病进展的并发症如高磷血症。早期使用适当的药物和饮食修改干预可以减缓CKD进展并改善患者结果(2,3)。

### Sources

[1] Prolonging life and kidney function (Proceedings): https://www.dvm360.com/view/prolonging-life-and-kidney-function-proceedings
[2] Staging and management of canine chronic kidney disease: https://www.dvm360.com/view/staging-and-management-canine-chronic-kidney-disease
[3] Current concepts for management of chronic renal failure in dogs: nutritional support (Proceedings): https://www.dvm360.com/view/current-concepts-management-chronic-renal-failure-dogs-nutritional-support-proceedings
[4] Nutritional management of chronic kidney disease: https://www.dvm360.com/view/nutritional-management-chronic-kidney-disease

## 鉴别诊断

将慢性肾病与其他疾病区分需要仔细评估多个临床参数。主要鉴别诊断包括急性肾损伤、肾前性氮质血症和肾后性氮质血症[1]。

**急性肾损伤**呈现出有助于将其与CKD区分的独特特征。患有AKI的动物通常具有肿大或正常大小的肾脏、良好的身体状况，并且相对于氮质血症程度具有严重的临床症状[2]。高钾血症和严重代谢性酸中毒在AKI中更常见[3]。尿沉渣通常活跃，有细胞管型和肾上皮细胞[1]。

**肾前性氮质血症**由脱水、休克或心血管疾病导致的肾灌注减少引起。这些患者保持浓缩能力，尿比重高（狗>1.030，猫>1.035）[1]。随着潜在灌注问题的纠正，氮质血症迅速解决。

**肾后性氮质血症**发生在尿路梗阻或破裂时。导尿可能困难，排尿困难或痛性尿淋漓是常见体征[2]。腹水可能含有比血清更高的肌酐浓度[1]。

**CKD的关键鉴别特征**包括历史性体重减轻和烦渴-多尿、身体状况不佳、非再生性贫血、触诊时小而不规则的肾脏，以及相对于氮质血症程度相对轻微的临床症状[3]。尿液浓缩能力丧失发生较早，尽管脱水，尿比重通常在狗中<1.030，在猫中<1.035[1]。

### Sources
[1] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[2] Differentiating between acute and chronic kidney disease: https://www.dvm360.com/view/differentiating-between-acute-and-chronic-kidney-disease
[3] The nuts and bolts of azotemia (Proceedings): https://www.dvm360.com/view/nuts-and-bolts-azotemia-proceedings

## 预后

慢性肾病的预后根据IRIS分期差异显著，生存时间与疾病严重程度直接相关[1]。在狗中，CKD诊断后的中位生存时间为IRIS第2阶段14.8个月，第3阶段11.1个月，第4阶段2.0个月[1]。对于猫，中位生存时间明显更长：第IIb阶段CKD患者存活763天（约25个月），第III阶段患者存活548天（约18个月），第IV阶段患者仅存活97天[2][4]。

死于CKD而非其他原因的可能性也随疾病阶段增加。患有第IIb阶段CKD的猫有40%的机会死于肾脏相关原因，而患有第IV阶段CKD的猫有93%的机会死于肾脏疾病[2][4]。大约50%在第II阶段诊断的猫将死于癌症或心脏病等非肾脏疾病[3]。

几个因素显著影响预后和疾病进展。蛋白尿是主要的负面预后指标，尿蛋白:肌酐比值超过0.4的猫与比值低于0.2的猫相比，死亡风险高四倍[4]。高血压对不同物种的预后影响不同 - 虽然它显著影响收缩压超过160 mmHg的狗的生存，但不影响患有CKD的猫的生存[4]。贫血的存在与较短的生存时间相关，尽管这与肌酐浓度增加相关[2][4]。

### Sources

[1] A New Marker for Chronic Kidney Disease in Dogs?: https://www.dvm360.com/view/a-new-marker-for-chronic-kidney-disease-in-dogs
[2] Updates in feline chronic kidney disease (Proceedings): https://www.dvm360.com/view/updates-feline-chronic-kidney-disease-proceedings
[3] The technician's role in outpatient management of chronic kidney disease (Proceedings): https://www.dvm360.com/view/technicians-role-outpatient-management-chronic-kidney-disease-proceedings
[4] Updates in outpatient management of chronic kidney disease (Proceedings): https://www.dvm360.com/view/updates-outpatient-management-chronic-kidney-disease-proceedings
