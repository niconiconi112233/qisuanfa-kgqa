# 伴侣动物的肺水肿

肺水肿是兽医实践中最关键的呼吸系统急症之一，其特征是肺间质和肺泡内异常积液。这种危及生命的状况通过不同的病理生理机制影响犬和猫--心源性水肿源于心力衰竭，而非心源性形式则由各种诱因引起，包括上呼吸道阻塞、神经创伤和电击。该疾病需要立即识别和干预，因为延迟治疗会迅速发展为呼吸衰竭。本报告探讨了肺水肿的全面临床管理，涵盖从放射学模式到先进成像的诊断方法，包括利尿剂治疗和氧气支持在内的循证治疗方案，以及在急诊和长期护理场景中影响患者预后的因素。

## 疾病概述

肺水肿被定义为肺间质和肺泡中异常量的血管外肺水积聚[1]。这种情况代表一种严重的呼吸系统急症，其严重程度可从临床无意义到危及生命不等[1]。

根据潜在机制，肺水肿分为两大类。心源性肺水肿是由左侧心力衰竭导致的肺毛细血管静水压升高引起的[1]。小动物中常见的心脏原因包括扩张型心肌病、获得性二尖瓣反流和肥厚型心肌病[1]。非心源性肺水肿(NCPE)由胶体渗透压降低或血管通透性改变引起，常见兽医原因包括上呼吸道阻塞、电击、颅脑创伤和癫痫发作[1][6]。

该疾病影响犬和猫，但流行病学模式有所不同。患有心源性水肿的犬通常有心内膜病引起的心脏杂音病史[1]。患有心力衰竭的猫经常表现为急性呼吸窘迫而无先兆症状[1]。心源性水肿的危险因素包括预先存在的心脏疾病、高钠饮食和过度积极的液体治疗[1]。对于NCPE，危险因素包括意外接触诱因或严重的潜在全身性疾病[1]。

### Sources
[1] DVM 360 Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[2] Non-cardiogenic pulmonary edema (Proceedings): https://www.dvm360.com/view/non-cardiogenic-pulmonary-edema-proceedings

## 常见病原体

犬和猫的肺水肿可能由感染性原因引起，这些原因要么直接损伤肺组织，要么损害呼吸防御机制。虽然肺水肿本身主要是一种非感染性疾病，但继发性细菌感染经常使临床情况复杂化[1]。

**继发性细菌感染**
当呼吸防御机制受损时，机会性细菌病原体常会入侵。包括多杀巴氏杆菌(*Pasteurella multocida*)、支气管败血波氏杆菌(*Bordetella bronchiseptica*)、链球菌、葡萄球菌、假单胞菌和大肠杆菌在内的本土共生菌通常存在于鼻腔和上呼吸道而不引起疾病[1]。当发生原发性损伤时，这些细菌变得具有致病性，导致可加剧肺水肿的继发性感染。

**原发性病毒病原体**
几种病毒感染可使动物易患包括肺水肿在内的继发性并发症。在犬中，犬瘟热病毒、副流感病毒和犬腺病毒2型会损害呼吸防御[1]。在猫中，猫疱疹病毒(鼻气管炎病毒)和杯状病毒是主要病原体，某些杯状病毒毒株特别产生肺水肿和间质性肺炎[4]。犬流感病毒已成为一种重要病原体，引起可发展为肺炎并可能促成肺部并发症的急性呼吸道感染[7]。

**细菌性肺炎病原体**
当继发于肺水肿的细菌性肺炎发生时，常见分离株包括支气管败血波氏杆菌(*Bordetella bronchiseptica*)、多杀巴氏杆菌(*Pasteurella multocida*)、克雷伯氏菌属(*Klebsiella*)、链球菌属(*Streptococcus*)和大肠杆菌(*Escherichia coli*)[7,8]。支原体属(*Mycoplasma*)也可导致呼吸道感染，特别影响黏膜纤毛功能，并可能诱发肺水肿发展[7]。

### Sources
[1] Merck Veterinary Manual Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[2] Pulmonary parenchymal disease (Proceedings): https://www.dvm360.com/view/pulmonary-parenchymal-disease-proceedings
[3] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 临床症状和体征

现有内容为理解肺水肿表现提供了全面基础。根据来源材料，几种额外的模式和机制增强了这一临床图景。

**上呼吸道阻塞**可引发非心源性肺水肿，特别是在患有喉部和咽部疾病的犬中[10]。这些病例通常表现为吸气和呼气喘鸣、呼吸困难、爆裂音和发绀，放射学模式显示肺门周围和背侧区域的混合性间质性和肺泡浸润[10]。

**电线咬伤**代表一种独特的NCPE表现，最常见于幼犬和幼猫[10]。临床症状包括伴有口腔烧伤的急性呼吸困难，可能伴有吞咽困难或流涎。强直阵挛性肌肉活动常在犬接触电线后立即发生[10]。

**神经源性肺水肿**由中枢神经系统损伤引起，包括头部创伤、癫痫发作和电击，可能与血管收缩变化和交感神经张力增加有关[11]。这种形式表现为呼吸窘迫迅速发作，无典型心脏异常。

**物种特异性呼吸模式**在犬和猫之间差异显著。患有心脏病的犬可能失去与呼吸相关的正常心率变异性，而患有心血管疾病的猫常表现出隐匿行为并采取端坐呼吸姿势，伴有显著的腹部呼吸成分[12]。

**急性发作特征**可区分心脏疾病与呼吸疾病，心源性病例通常比原发性呼吸疾病表现更急性。患有心力衰竭的犬可能显示心脏恶病质，而呼吸疾病患者通常保持身体状况[12]。

### Sources
[1] Infectious Endocarditis in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats
[2] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[3] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings
[4] Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[5] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[6] Initial stabilization of dogs in respiratory distress: https://www.dvm360.com/view/initial-stabilization-dogs-respiratory-distress-proceedings
[7] Pulmonary contusions and other thoracic trauma: https://www.dvm360.com/view/pulmonary-contusions-and-other-thoracic-trauma-proceedings
[8] Non-cardiogenic pulmonary edema (Proceedings): https://www.dvm360.com/view/non-cardiogenic-pulmonary-edema-proceedings
[9] Acute lung injury and acute respiratory distress syndrome: https://www.dvm360.com/view/acute-lung-injury-and-acute-respiratory-distress-syndrome-two-challenging-respiratory-disorders
[10] Pulmonary parenchymal disease (Proceedings): https://www.dvm360.com/view/pulmonary-parenchymal-disease-proceedings
[11] The buildup of pulmonary edema: https://www.dvm360.com/view/the-build-up-of-pulmonary-edema
[12] Is it really heart failure I'm treating? (Proceedings): https://www.dvm360.com/view/it-really-heart-failure-im-treating-proceedings

## 诊断方法

**临床表现评估**

心源性肺水肿通常表现为心脏杂音、呼吸急促、端坐呼吸、呼吸窘迫和咳嗽病史[1]。体格检查显示肺部爆裂音、心脏异常(杂音、奔马律、心律失常)、心率快、脉搏质量弱，可能伴有颈静脉扩张[2]。猫可能显示体温过低，并且在急性发作前常缺乏先兆症状[2]。

非心源性肺水肿(NCPE)患者表现为低氧血症和高血糖症[1]。动物可能有气道阻塞、电线咬伤、癫痫发作或严重全身性疾病病史[2]。

**放射学成像**

胸部放射学检查是首选的诊断方法[2]。心源性水肿显示心脏肿大、肺静脉扩张，以及从肺门周围区域开始的间质性至肺泡浸润[2]。在犬中，浸润表现为间质性(67.2%)或混合性间质-肺泡模式，而猫则显示更多变的分布[4]。

NCPE显示无心脏肿大的肺浸润，通常呈对称性(77%)、外周性(92%)和背侧性(58%)分布[1]。阻塞后模式通常不对称[1]。

**高级诊断**

超声心动图和心电图分析支持心源性诊断[2]。虽然肺毛细血管楔压(>18 mmHg)是人类医学中的金标准，但它需要肺动脉导管插管，这在兽医实践中很少进行[2]。

### Sources
[1] The buildup of pulmonary edema: https://www.dvm360.com/view/the-build-up-of-pulmonary-edema
[2] Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[3] Radiographic features of cardiogenic pulmonary edema in dogs: https://avmajournals.avma.org/view/journals/javma/235/9/javma.235.9.1058.xml
[4] Radiographic findings of cardiopulmonary structures in cats: https://avmajournals.avma.org/view/journals/ajvr/84/9/ajvr.23.01.0017.xml

## 治疗选择

肺水肿的治疗根据潜在病因差异很大，需要立即干预以防止呼吸衰竭。心源性肺水肿治疗以氧气补充、利尿剂和血管扩张剂为中心[1]。呋塞米作为主要利尿剂，在犬中静脉给药2-4 mg/kg，每1-6小时一次，在猫中为0.5-2 mg/kg，恒速输注作为替代方案(犬0.25-1 mg/kg/h，猫0.25-0.6 mg/kg/h)[1,2]。当产生耐药性时，托拉塞米等袢利尿剂可替代呋塞米[2]。

血管扩张剂包括硝酸甘油、硝普钠和ACE抑制剂可降低心脏前负荷和后负荷[1]。使用匹莫苯丹的正性肌力支持可增强收缩功能障碍情况下的心脏收缩力[2]。氧气治疗对严重病例至关重要，但很少需要机械通气[1]。

非心源性肺水肿治疗侧重于解决根本原因同时提供支持性护理[1]。休息和氧气补充通常足以治疗由上呼吸道阻塞或电线咬伤引起的病例[1]。一些临床医生主张抗炎治疗或胶体液，尽管支持特定干预措施的证据仍然有限[1]。

关键禁忌症包括避免在急性充血性心力衰竭患者中使用静脉输液[1,4]。监测参数包括整个治疗过程中的呼吸频率、心率、血压和血氧饱和度[1]。

### Sources

[1] Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[2] Heart Failure in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[3] Cardiogenic Pulmonary Edema in a Dog Following Initiation: https://meridian.allenpress.com/jaaha/article/52/6/378/170639/Cardiogenic-Pulmonary-Edema-in-a-Dog-Following
[4] 2024 AAHA Fluid Therapy Guidelines for Dogs and Cats: https://meridian.allenpress.com/jaaha/article/60/4/131/501375/2024-AAHA-Fluid-Therapy-Guidelines-for-Dogs-and

## 预防措施

肺水肿的预防侧重于危险因素管理和根本原因控制。对于心源性肺水肿，在心力衰竭发展之前识别和管理心脏疾病至关重要[1]。危险因素包括心脏病、高钠饮食以及过度积极的晶体液或胶体液治疗[1]。

环境控制起着关键作用。压力减轻至关重要，因为压力可激活猫疱疹病毒等状况并可能触发心脏失代偿[2]。保持适当通风、控制过度拥挤和提供无压力环境有助于预防可能加剧肺水肿的呼吸并发症[2]。

对于与呼吸道病原体相关的肺部并发症，疫苗接种方案很重要。猫疱疹病毒、杯状病毒和猫瘟的改良活疫苗应在进入收容所时立即接种以获得最佳保护[3]。虽然这些疫苗不能完全预防感染，但它们可减轻疾病严重程度和持续时间[3]。

监测策略包括对高危患者进行定期心血管评估和维持适当的血压控制。平均动脉压应保持在60 mm Hg以上，目标为80 mm Hg[1]。通过犬的常规睡眠呼吸频率监测进行早期检测，可在临床症状变得严重之前识别正在发展的肺水肿[1]。在犬群中，通过限制在收容所环境中的天数来减少拥挤压力可将呼吸道疾病风险降低3%[4]。

### Sources
[1] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure
[2] Why do we have respiratory disease in our shelter cats and what can we do to control it? (Proceedings): https://www.dvm360.com/view/why-do-we-have-respiratory-disease-our-shelter-cats-and-what-can-we-do-control-it-proceedings
[3] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[4] Canine infectious respiratory disease complex: management and prevention in canine populations (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin

## 鉴别诊断

肺水肿必须与几种临床表现重叠的呼吸系统疾病进行鉴别。最常混淆的疾病包括胸腔积液、肺炎和上呼吸道阻塞[1]。

**胸腔积液**呈现独特的放射学特征，有助于将其与肺水肿区分开来。胸腔积液显示叶间裂隙内积液，外周最宽，肋膈角变圆，与心脏轮廓和膈肌边界模糊[1]。相比之下，肺水肿保持可见的肺血管系统，显示间质性至肺泡浸润而无叶间裂隙增宽[1]。

**肺炎**，特别是细菌性肺炎，与严重肺水肿具有相似的肺泡模式，但在分布和相关发现方面有所不同。支气管肺炎通常影响腹侧肺野(右前叶、右中叶和左前叶)，而心源性肺水肿显示背侧和肺门分布[3][4]。患有肺炎的动物常表现为发热、脓性鼻分泌物，以及经气管冲洗液中的中性粒细胞炎症，而肺水肿患者通常缺乏这些感染体征[3]。

**上呼吸道阻塞**可引起继发性非心源性肺水肿，造成诊断复杂性[6]。患有原发性上呼吸道疾病的动物产生可听见的呼吸声音(喘鸣或鼾声)，可能存在延长的吸气努力，这些在原发性肺水肿病例中不存在[6]。

关键鉴别因素包括放射学模式分布、心脏异常存在、对利尿剂的反应以及可行时气道采样的细胞学发现。

### Sources
[1] Small animal thoracic radiology: Pulmonary edema vs. pleural effusion: https://www.dvm360.com/view/small-animal-thoracic-radiology-pulmonary-edema-vs-pleural-effusion-lines-and-buckets-proceedings
[2] Managing pulmonary parenchymal diseases: https://www.dvm360.com/view/managing-pulmonary-parenchymal-diseases-proceedings
[3] Radiographic evaluation of pulmonary patterns and disease: https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[4] Managing pleural effusion: https://www.dvm360.com/view/managing-pleural-effusion-proceedings
[5] Managing upper airway obstruction in dogs: https://www.dvm360.com/view/managing-upper-airway-obstruction-dogs-proceedings
[6] Medical management of upper airway obstruction in dogs: https://www.dvm360.com/view/medical-management-upper-airway-obstruction-dogs-proceedings

## 预后

犬和猫肺水肿的预后在心源性和非心源性形式之间差异显著，结果主要取决于潜在病因和治疗速度[1]。

对于心源性肺水肿，长期预后通常谨慎至不良。慢性退行性瓣膜病继发充血性心力衰竭的传统治疗在犬中仅提供平均4-6个月的生存时间[2]。虽然当前的标准治疗方案可为许多患者提供良好的生活质量，但包括持续充血、晕厥、心律失常引起的猝死或客户选择安乐死在内的并发症可能导致患者过早死亡[2]。

当潜在疾病过程得到控制时，非心源性肺水肿通常具有更有利的预后。通过早期识别、适当治疗和坚定的客户配合，病例通常在24-48小时内肺部迅速清除，氧合和放射学发现显著改善[3]。总体预后主要取决于潜在诊断，而非肺水肿本身[3]。

几个预后因素影响恢复结果。在心源性病例中，潜在心脏疾病的严重程度、并发心律失常的存在以及心脏恶病质的发展会恶化预后[1]。对于非心源性形式，诱发原因的性质(头部创伤、电击、上呼吸道阻塞)和患者的神经状况是关键决定因素[3]。

### Sources
[1] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings
[2] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings
[3] Non-cardiogenic pulmonary edema (Proceedings): https://www.dvm360.com/view/non-cardiogenic-pulmonary-edema-proceedings
