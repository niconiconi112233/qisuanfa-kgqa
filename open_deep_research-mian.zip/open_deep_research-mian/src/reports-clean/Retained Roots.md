# 伴侣动物中的牙根残留

牙根残留是兽医牙科实践中的一种重要并发症，指在拔牙手术后牙根碎片仍留在牙槽窝内。这种情况在犬和猫中均可发生，研究表明其患病率令人担忧，尤其是在裂齿等多根牙中。临床表现从明显的面部肿胀和瘘管形成到引起慢性疼痛的隐匿性亚临床感染不等。本报告探讨了牙根残留的病理生理学、诊断方法和治疗方案，强调通过正确的拔牙技术进行预防以及放射学确认的关键重要性。理解这一状况对于进行牙科手术的兽医从业者至关重要，因为早期识别和适当处理显著影响患者的预后和长期口腔健康。

## 疾病概述

牙根残留是指在犬和猫的牙科拔牙手术后牙根碎片未被完全清除的情况。当临床牙冠被拔除后，部分牙根结构仍留在牙槽窝内时就会发生这种情况。牙根残留是兽医牙科实践中的一种重要并发症，研究表明其频率从常规拔牙时的无意残留到具有临床意义的致病性病例不等[1]。

流行病学数据显示两个物种的患病率都令人担忧。检查上颌第四前磨牙和下颌第一磨牙拔牙部位的研究发现，相当比例的病例存在牙根碎片残留的证据[1]。其他专门针对犬的牙根碎片残留(RTRFs)的研究记录了相关炎症的临床和放射学证据，其频率根据碎片长度和在牙槽骨内的位置而有所不同[2]。

解剖因素显著增加牙根残留风险。多根牙，特别是裂齿（上颌第四前磨牙和下颌第一磨齿），由于其复杂的牙根解剖结构，在拔牙过程中面临更大挑战。许多牙根结构的弯曲性质以及靠近重要解剖结构的位置造成技术困难，可能导致意外的牙根折断和残留[1][2]。手术拔牙程序强调通过牙科放射学进行充分可视化以预防这一并发症的重要性[3]。

### Sources

[1] Evaluation of Extraction Sites for Evidence of Retained Tooth: https://meridian.allenpress.com/jaaha/article/50/2/77/176101/Evaluation-of-Extraction-Sites-for-Evidence-of
[2] Frequency of clinical and radiographic evidence of: https://avmajournals.avma.org/view/journals/javma/256/6/javma.256.6.687.xml
[3] Surgical tooth extractions (Proceedings): https://www.dvm360.com/view/surgical-tooth-extractions-proceedings

## 常见病原体

牙根残留通常与继发性细菌感染相关，主要涉及在感染牙周组织的缺氧环境中繁殖的厌氧菌[1]。当牙菌斑变厚且氧气耗尽时，细菌群从主要是好氧的革兰氏阳性菌种（如葡萄球菌属和链球菌属）转变为更具致病性的厌氧生物[1]。

牙根残留感染中发现的关键厌氧病原体包括脆弱拟杆菌、消化链球菌属、牙龈卟啉单胞菌、唾液卟啉单胞菌、犬齿卟啉单胞菌、中间普雷沃菌、密螺旋体属和内脏拟杆菌[1]。这些细菌常见于龈下菌斑，通过直接组织损伤和宿主炎症反应导致牙周炎[1]。

残留的牙根碎片为细菌定植和生物膜形成提供了理想环境[2]。细菌微生物群包括好氧和厌氧菌种，许多牙科病原体是厌氧菌，当它们在生物膜结构中组织时具有抗微生物性[2]。

正常口腔菌群在发病机制中起关键作用。在健康的口腔中，口腔微生物群与宿主存在共生和谐关系，甚至可能限制牙周致病菌[1]。然而，口腔卫生不良和残留的牙根碎片创造了有利于致病菌过度生长的条件[1]。

根据目前的兽医文献，病毒在牙根残留感染中的参与似乎很少。发病机制主要涉及细菌定植和随后的宿主炎症反应，导致残留牙根碎片周围的骨骼和组织损伤[1]。

### Sources

[1] Periodontal Disease in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals

[2] Treatment of periapical abscesses and osteomeyelitis in rabbits (Proceedings): https://www.dvm360.com/view/treatment-periapical-abscesses-and-osteomeyelitis-rabbits-proceedings

## 临床症状和体征

伴侣动物的牙根残留表现出一系列临床表现，从明显的面部肿胀到隐匿的亚临床感染。最具特征性的体征是单侧面部肿胀，特别是在眶下区域，根据感染程度可能坚实或波动[1]。疼痛是一致的发现，表现为口腔不适、不愿吃硬食物或用爪子抓挠受影响的面部一侧。

当存在瘘管形成时，它代表一种特征性体征，表现为从口腔延伸到面部皮肤表面的引流道。这些瘘管通常排出脓性物质，可能带有恶臭[1]。研究表明，52.7%的牙根残留病例显示相关的透射性，但由于动物无法表达不适，与口腔疼痛相关的临床症状经常未被报告[2]。

亚临床感染尤其具有挑战性，因为受影响的动物可能只表现出轻微的体征，如轻度食欲不振或偶尔摇头。一些病例在残留牙根区域出现慢性牙龈炎或牙周炎，没有明显的外部表现[1]。

犬和猫之间存在物种特异性模式。犬更常见明显的面部肿胀和外部瘘管，而猫倾向于表现更微妙的体征，包括慢性口腔疼痛和吸收性病变的逐渐发展[3]。两个物种中的短头品种可能由于解剖限制而表现出更明显的呼吸道并发症[1]。

### Sources
[1] Frequency of clinical and radiographic evidence: https://avmajournals.avma.org/downloadpdf/view/journals/javma/256/6/javma.256.6.687.pdf
[2] Frequency of clinical and radiographic evidence: https://avmajournals.avma.org/view/journals/javma/256/6/javma.256.6.687.xml
[3] Tooth Resorption in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals

## 诊断方法

临床检查从口腔的彻底视诊开始，寻找牙根残留的迹象，包括具有不规则折断牙冠表面的缺失牙齿，这可能表明存在牙根碎片[1]。中心有红色或黑色斑点的折断牙齿提示可能存在牙髓暴露和潜在的残留牙根材料[2]。

牙科放射学对于诊断牙根残留是绝对必要的，应在任何拔牙尝试之前进行[2,5]。X光片显示残留的牙根作为牙槽骨内更高密度的区域[4,10]。拔牙后放射学检查是强制性的，以确认牙根完全清除并记录成功治疗[1,6]。AAHA牙科护理指南要求对所有拔牙病例进行术后X光检查以确保完全清除[1]。

先进的成像方式，特别是CT扫描，在标准X光片不确定时提供优越的可视化[2]。数字放射学提供即时成像，消除了可能损害诊断质量的处理错误[3,4]。

拔牙尝试后的牙根残留在兽医医学中很常见，可能不会引起明显的临床症状，尽管患者可能默默承受痛苦[1]。在罕见情况下，残留的牙根可能导致脓肿形成，导致显著发病率[1]。没有对牙根和骨结构进行充分的放射学可视化，拔牙计划将大大受损[8]。

### Sources

[1] Interpreting dental radiographs: The clues to clinical disease: https://www.dvm360.com/view/interpreting-dental-radiographs-clues-clinical-disease
[2] Six common pitfalls in veterinary dentistry and how to avoid them: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them
[3] Tips for mastering veterinary dental radiography: https://www.dvm360.com/view/tips-for-mastering-veterinary-dental-radiography
[4] Dental radiography: Digital techniques and radiographic diagnosis (Proceedings): https://www.dvm360.com/view/dental-radiography-digital-techniques-and-radiographic-diagnosis-proceedings
[5] Dental radiography: Equipment and positioning ... - DVM360: https://www.dvm360.com/view/dental-radiography-equipment-and-positioning-proceedings
[6] Oral surgery solutions: A look at difficult cases in dentistry: https://www.dvm360.com/view/oral-surgery-solutions-look-difficult-cases-dentistry

## 治疗选择

牙根残留需要利用瓣膜设计原则和骨去除技术进行手术切除[1]。当拔除断裂的牙根尖端时，会掀起粘骨膜瓣并去除残留牙根上的颊侧牙槽骨[1]。正确的技术包括创建粘骨膜瓣以暴露牙槽骨，随后暴露牙根以利于拔除[3]。

对于手术入路，应尽可能使用信封瓣，在需要时使用垂直释放切口提供额外暴露[3]。去除的颊侧骨量取决于牙齿类型和牙周组织健康状况，骨去除从边缘骨开始并向根尖方向延伸[3]。使用小圆钻在牙根周围创建"沟槽"以便放置牙挺[1]。

药物治疗包括对有明显感染、慢性口炎或多处拔牙的病例使用抗生素治疗[10]。疼痛管理是必要的，使用术前和术后镇痛药3-7天[8]。氯己定溶液冲洗或葡萄糖酸锌凝胶可能有助于保持手术部位清洁[8]。

当病例超出操作者的技能水平或出现并发症时，应考虑转诊给兽医牙科专家[3]。被推入下颌管、鼻腔或上颌窦的牙根尖端需要立即转诊给有经验的从业者[3]。

术后护理包括10天软食、避免硬咀嚼物体和两周患者重新评估[8]。如果发生瓣膜裂开，需要立即修复以防止感染和患者不适[8]。

### Sources

[1] Decision making and extraction techniques in dogs: https://www.dvm360.com/view/decision-making-and-extraction-techniques-dogs-proceedings
[3] Surgical approach to root tip retrieval (Proceedings): https://www.dvm360.com/view/surgical-approach-root-tip-retrieval-proceedings
[8] 10 top considerations in performing dental extraction: https://www.dvm360.com/view/10-top-considerations-performing-dental-extraction-procedures
[10] The complete dental cleaning procedure (Proceedings): https://www.dvm360.com/view/complete-dental-cleaning-procedure-proceedings

## 预防措施

预防牙根残留需要精细的手术技术和适当的规划。术前X光片对于评估牙齿解剖结构、识别牙根异常（如弯曲或弯曲牙根）以及确定最合适的拔牙方法至关重要[1]。

多根牙必须在拔牙前适当分割。牙槽成形术和多根牙分割通过增加牙根、牙周韧带和根分叉的暴露来简化牙科拔牙[1]。对于多根牙，从根分叉开始并穿过牙冠的牙冠分割允许隔离牙根并更容易单独拔除[1]。

适当的器械对于预防并发症至关重要。应使用锋利、维护良好的牙科挺和牙挺器，施加受控、轻柔的力量[3]。使用适当的手指止点和手部休息可防止器械滑动和拔牙过程中的潜在伤害[3]。在牙槽成形术和牙齿分割期间充分的冲洗是强制性的，以最大限度地减少感染并避免患者受伤[1]。

术后放射学确认对于验证牙根完全清除至关重要[3]。应拍摄最终X光片以确保牙根已完全从牙槽窝中清除[1]。如果术后发现牙根碎片，应立即处理，特别是在存在根尖周病理或感染证据的情况下[3]。

### Sources

[1] Dental extractions: Easy cues help with critical long-term medical decisions: https://www.dvm360.com/view/dental-extractions-easy-cues-help-with-critical-long-term-medical-decisions
[2] 10 top considerations in performing dental extraction procedures: https://www.dvm360.com/view/10-top-considerations-performing-dental-extraction-procedures
[3] Six common pitfalls in veterinary dentistryand how to avoid them: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them

## 鉴别诊断

牙根残留必须与几种可能表现相似口腔病变和放射学特征的情况进行鉴别[1]。**含牙囊肿**是主要的鉴别诊断，特别是在表现为充满液体的口腔肿胀的年轻犬中[2]。这些囊肿起源于发育中的牙囊的细胞成分，包含一个或多个包埋的牙齿，通常围绕牙冠部分[2]。

**口鼻瘘**当与上颌牙齿拔牙相关时可能模仿牙根残留，表现为鼻分泌物和口鼻交通。**肿瘤**必须考虑，特别是在老年患者中，因为口腔肿瘤可导致骨破坏和牙齿移位，类似于根尖周病理[1]。

**来自牙髓疾病的牙根脓肿**提出了最具挑战性的鉴别诊断[1]。两种情况在X光片上都显示根尖周透射性，但脓肿通常在"粗糙"外观的牙根尖端周围有"光晕"外观，而残留的牙根碎片表现为拔牙部位内的离散不透射结构[1]。

**关键鉴别特征**包括患者近期拔牙史（针对牙根残留）、牙髓疾病中完整牙冠结构的存在，以及含牙囊肿中在釉牙骨质界附近看到的特征性光滑边界透射腔[2]。诊断成像和彻底的临床检查对于准确鉴别至关重要。

### Sources

[1] Clinical signs and histologic findings in dogs with ...: https://avmajournals.avma.org/downloadpdf/view/journals/javma/239/11/javma.239.11.1470.pdf
[2] Managing challenging oral cases in dogs: part II (Proceedings): https://www.dvm360.com/view/managing-challenging-oral-cases-dogs-part-ii-proceedings

## 预后

牙根残留的预后因几个关键因素和适当治疗的及时性而有很大差异。当牙根残留被早期诊断并适当治疗时，结果通常是有利的[1]。残留牙根碎片的完全手术切除通常导致极好的愈合且并发症最少[4]。

几个因素显著影响预后。保留持续时间起着关键作用 - 最近折断的牙根比长期保留的牙根有更好的结果[1]。感染的存在严重恶化预后，特别是在上颌牙齿中，残留的牙根可能脓肿并形成伴有引流道的眶下肿胀[1]。位置也很重要，因为下颌牙根可能带来额外的手术挑战[4]。

潜在并发症包括持续疼痛、慢性感染和如果牙根碎片残留则愈合延迟[1,3]。断裂的残留牙根可能在无症状的犬中未被检测到，但在犬和猫中都成为持续性疼痛和感染的来源[1]。特别是在猫中，牙根残留与厌食症相关[1]。

长期监测对于最佳结果至关重要。应获得术后X光片以确保牙根完全清除[4]。患者需要随访检查以评估愈合情况和识别任何残留碎片。通过适当的手术技术和完全清除所有牙根材料，大多数病例成功愈合且无并发症[4]。

### Sources

[1] Six common pitfalls in veterinary dentistryand how to avoid them: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them

[3] Toothaches and triumphs: https://www.dvm360.com/view/toothaches-and-triumphs

[4] Surgical approach to root tip retrieval (Proceedings): https://www.dvm360.com/view/surgical-approach-root-tip-retrieval-proceedings
