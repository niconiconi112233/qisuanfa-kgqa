# 犬肢端舔舐性皮炎

犬肢端舔舐性皮炎代表了小动物临床中最具挑战性的皮肤病之一，其特征是通过强迫性舔舐行为造成的自伤性伤口。本综合报告探讨了该病症的多因素性质，分析了其涉及过敏、骨科、神经和行为因素的复杂病因。分析涵盖了通常影响肢体远端的独特临床表现模式，包括细胞学和组织病理学在内的循证诊断方法，以及成功管理所需的关键多模式治疗策略。特别关注了使该病症对治疗特别具有抵抗性的自我持续的瘙痒-舔舐循环，以及兽医从业人员管理这些棘手病例时必需的预防措施和长期预后考虑因素。

## 疾病概述

**定义**
犬肢端舔舐性皮炎，也称为肢端舔舐性肉芽肿，是一种局部性皮肤病，特征是由于慢性强迫性舔舐肢体远端而形成的增厚、隆起的病变（默克兽医手册，2024年）。该病症代表了一种自我持续的皮肤病，最初的瘙痒引发过度舔舐行为，导致组织创伤、继发性细菌感染和维持舔舐循环的持续性炎症。

**流行病学背景**
大型犬对肢端舔舐性皮炎表现出更高的易感性，德国牧羊犬、拉布拉多寻回犬、金毛寻回犬和杜宾犬是最常受影响的品种（DVM360，2024年）。该病症通常影响中老年犬，雄性比雌性表现出轻微的易感性。虽然全面的患病率数据有限，但肢端舔舐性皮炎被认为在小动物皮肤病临床中是常见的表现，特别是在环境过敏原负荷较高的地理区域。该病症全年出现，但在具有潜在过敏成分的病例中可能表现出季节性变化。

## 病因和病理生理学

犬肢端舔舐性皮炎通过原发性原因和继发性并发症的复杂相互作用发展而成。原发性病因包括过敏反应（环境或食物过敏原）、引起局部疼痛或不适的骨科疾病、神经系统疾病，以及焦虑或强迫症等行为因素[1]。

病理生理学以自我持续的瘙痒-舔舐循环为中心。任何原因引起的初始瘙痒都会触发过度舔舐，这会造成组织创伤和炎症。这种炎症反应释放内啡肽和其他介质，这些介质可以强化舔舐行为，同时降低瘙痒阈值[1]。

继发性细菌感染由于舔舐造成的持续潮湿和创伤而频繁发展。葡萄球菌种类通常定植于受损组织，形成毛囊炎和更深的感染，加剧炎症和瘙痒[1]。异物反应可能由碎片、毛发或其他物质嵌入受损组织而发生。

神经化学基础涉及与人类强迫症的相似性，表现为血清素和去甲肾上腺素失衡的模式[2]。随着内啡肽释放为舔舐行为创造神经化学奖励，而持续的炎症维持瘙痒感，该病症变得自我维持。治疗成功取决于解决原发性原因并通过针对炎症、感染和行为成分的多模式方法打破这种病理循环。

### Sources
[1] Management of the pruritic dog (Proceedings): https://www.dvm360.com/view/management-pruritic-dog-proceedings
[2] Managing acral lick dermatitis in canines - dvm360: https://www.dvm360.com/view/managing-acral-lick-dermatitis-in-canines

## 临床表现和诊断

肢端舔舐性肉芽肿表现为特征性皮肤病变，通常位于犬的肢体远端。这些伤口通常在腕部、掌部、跖部区域或小腿前部发展[1][2]。病变很少出现在胁腹或尾根部[1]。多个肉芽肿可能同时影响一只犬。

临床进展遵循可预测的模式。病变最初表现为红斑和结痂，然后进展为增厚、脱毛的斑块或结节[1]。中央区域通常变得溃疡、红色和湿润，或可能被痂覆盖。受影响区域经常发生色素沉着[1]。这些病变表现为隆起、坚硬、圆形至长圆形的形成物，具有增厚的边缘[2]。

诊断结合多种诊断方法。患者病史应探讨发病、进展、行为变化和环境因素[1]。体格检查揭示肢端舔舐性皮炎特有的病变外观和解剖分布模式。

使用印片涂片的细胞学评估显示慢性炎症浸润，主要由巨噬细胞、淋巴细胞和浆细胞组成[3]。由于慢性炎症引起的鳞状上皮增生（棘皮症），通常存在鳞状上皮细胞[3]。

深层皮肤刮片、真菌培养和细菌培养有助于排除潜在原因[4]。通过皮肤活检进行的皮肤组织病理学提供明确诊断并排除其他疾病[1]。细菌培养指导抗生素选择，由于这些病变中通常存在深层细菌感染，组织样本比表面拭子提供更多信息[1]。

### Sources
[1] Acral lick granuloma: stopping the itch-lick cycle: https://www.dvm360.com/view/acral-lick-granuloma-stopping-itch-lick-cycle
[2] Differential diagnoses for canine pododermatitis (Proceedings): https://www.dvm360.com/view/differential-diagnoses-canine-pododermatitis-proceedings
[3] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[4] Diagnosing and treating canine bacterial pyodermas (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings

## 治疗策略

犬肢端舔舐性皮炎的治疗需要多模式方法，针对继发性感染和潜在行为成分[3]。主要关注点是继发性细菌性毛囊炎和毛囊疖，需要基于培养和敏感性结果的6-12周口服抗生素治疗[3]。

**医疗管理**
抗炎治疗包括局部、口服或注射皮质类固醇，以减少舔舐行为，同时让抗生素发挥作用[5]。非甾体抗炎药提供疼痛管理的替代选择，但必须避免同时使用类固醇以防止胃肠道溃疡[5]。含有二甲基亚砜和氟轻松的外用产品可以渗透更深组织以减少炎症[3]。

**行为干预**
精神药物治疗利用三环类抗抑郁药（氯米帕明1-3 mg/kg q12h，阿米替林1-3 mg/kg q12h）或选择性血清素再摄取抑制剂（氟西汀1 mg/kg q24h）[4]。纳曲酮（2.2 mg/kg q24h）等麻醉拮抗剂在打破内啡肽驱动的舔舐循环方面已显示出疗效[1,4]。

**物理屏障和替代疗法**
机械威慑物包括伊丽莎白圈、保护性袖套和含有辣椒素的外用苦味化合物[3,5]。激光治疗（CO2和冷激光）和针灸在选择性病例中已显示出成功[3,5]。虽然可以考虑手术切除小病变，但如果不解决潜在原因，复发仍然常见[5]。

治疗需要耐心，因为解决通常需要数月时间，早期干预比慢性病例有更好的结果[5]。

### Sources
[1] Journal of the American Veterinary Medical Association Naltrexone for treatment of acral lick dermatitis in dogs: https://avmajournals.avma.org/view/journals/javma/196/7/javma.1990.196.07.1073.xml
[2] Allen Press Organic Diseases Mimicking Acral Lick Dermatitis in Six Dogs: https://meridian.allenpress.com/jaaha/article-abstract/43/4/215/176339/Organic-Diseases-Mimicking-Acral-Lick-Dermatitis
[3] DVM 360 Just Ask the Expert: How do you combat acral lick dermatitis?: https://www.dvm360.com/view/just-ask-expert-how-do-you-combat-acral-lick-dermatitis
[4] Merck Veterinary Manual Psychotropic Agents for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/psychotropic-agents-for-integumentary-disease-in-animals
[5] DVM 360 Acral lick granuloma: stopping the itch-lick cycle: https://www.dvm360.com/view/acral-lick-granuloma-stopping-itch-lick-cycle

## 预防和预后

### 预防措施

犬肢端舔舐性皮炎的预防以环境丰富化和早期干预策略为中心。环境丰富化包括提供充足的有氧运动、互动服从训练和精神刺激，以减少导致强迫性舔舐行为的压力、无聊和分离焦虑[1]。早期识别和治疗过敏、关节炎和细菌感染等潜在疾病可以防止维持该病症的瘙痒-舔舐循环的发展[2]。

一致的主人互动和可预测的日常生活有助于最小化与焦虑相关的触发因素。在治疗阶段，伊丽莎白圈或保护性服装等物理屏障可能暂时有益，尽管它们解决的是症状而非根本原因[2]。定期洗澡和外用治疗可能有助于预防使病症复杂化的继发性感染[3]。

### 预后和长期管理

肢端舔舐性皮炎的预后通常谨慎，因为如果不解决潜在原因，复发很常见[2][5]。治疗需要2-3个月或更长时间的抗生素治疗来应对继发性细菌感染，成功率在个体患者之间差异显著[2][4]。接受早期治疗的犬比患有慢性或严重病变的犬有更好的恢复前景[4][5]。

主人依从性对成功结果至关重要，因为治疗通常是一个缓慢的过程，需要数月的一致治疗[4][5]。长期管理通常涉及结合医疗治疗、行为改变和环境管理的多模式方法，以防止复发[1][5]。虽然肢端舔舐性皮炎很少危及生命，但如果管理不当，它会显著影响犬和主人的生活质量[5]。

### Sources

[1] Managing acral lick dermatitis in canines: https://www.dvm360.com/view/managing-acral-lick-dermatitis-in-canines

[2] Acral lick granuloma: stopping the itch-lick cycle: https://www.dvm360.com/view/acral-lick-granuloma-stopping-itch-lick-cycle

[3] Treating atopy: Keep patients comfortable without causing harm: https://www.dvm360.com/view/treating-atopy-keep-patients-comfortable-without-causing-harm

[4] Psychotropic Agents for Integumentary Disease in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/psychotropic-agents-for-integumentary-disease-in-animals

[5] Just Ask the Expert: How do you combat acral lick dermatitis?: https://www.dvm360.com/view/just-ask-expert-how-do-you-combat-acral-lick-dermatitis
