# 伴侣动物中的支持细胞瘤

支持细胞瘤是兽医实践中一种重要的睾丸肿瘤，主要影响老年未去势雄性犬，偶尔也影响猫。这些产生激素的肿瘤起源于曲细精管内的支持细胞，与隐睾症密切相关，在睾丸未降的犬中发生率高出13倍。支持细胞瘤的临床重要性不仅限于其肿瘤性质，因为高达50%的肿瘤具有功能性，分泌雌激素并导致特征性的雌性化综合征，表现为双侧脱毛、乳腺肿大和严重的骨髓抑制。本综合综述探讨了在小动物实践中管理支持细胞瘤的流行病学、临床表现、诊断方法、治疗方案和预防策略，强调了通过早期识别和适当的外科干预所能获得的良好预后。

## 疾病概述

支持细胞瘤是起源于支持细胞（足细胞）的睾丸肿瘤，这些细胞支持曲细精管内的精子发生[1]。这些肿瘤是犬类最常见的三种原发性睾丸肿瘤之一，与精原细胞瘤和间质细胞瘤并列[2]。

支持细胞瘤与隐睾症密切相关，在睾丸未降的犬中发生率比睾丸正常下降的犬高13倍[3]。在隐睾睾丸中，支持细胞瘤约占睾丸肿瘤的60%，而精原细胞瘤约占40%[1]。隐睾犬风险增加的原因归因于升高的腹腔温度导致除支持细胞外的所有管状细胞丧失[1]。

这些肿瘤主要影响老年未去势雄性犬，大多数病例发生在5岁以上的犬中[4]。尚未发现支持细胞瘤有特定的品种倾向性[4]。肿瘤可能是单侧发生，较少情况下为双侧发生[2]。高达50%的支持细胞瘤具有功能性，产生雌激素并导致高雌激素综合征，表现为雌性化、吸引其他雄性犬、前列腺肿大、乳腺发育、对称性脱毛和贫血[4][5]。虽然这些肿瘤可以转移到腹部、肺部、胸腺和大脑，但转移发生率低于15%[4]。

### Sources
[1] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge
[2] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/241/1/javma.241.1.55.xml
[3] Surgery of the urogenital system: https://www.dvm360.com/view/surgery-urogenital-system-proceedings
[4] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
[5] Abnormal conditions of the stud: https://www.dvm360.com/view/abnormal-conditions-stud-proceedings

## 常见病原体

支持细胞瘤主要是一种肿瘤性疾病，没有已知的病毒、细菌或其他传染性病原体原因[1]。这种肿瘤自发起源于睾丸曲细精管内的支持细胞，被认为是犬类最常见的三种睾丸肿瘤之一，与精原细胞瘤和间质细胞瘤并列[2][3]。

与一些通常由细菌、真菌或病毒感染引起的生殖道疾病（如睾丸炎或附睾炎）不同，支持细胞瘤是通过肿瘤转化而非感染过程发展的[4]。肿瘤细胞本身不是传染性病原体，这使该疾病与犬传染性性病肿瘤（TVT）等可传播癌症区分开来，后者通过犬之间癌细胞的直接传播扩散[1]。

虽然支持细胞瘤的病因尚不清楚，但它与任何已知病原体无关。这种情况最常见于老年未去势雄性犬，特别是患有隐睾症的犬，其未降睾丸发生肿瘤的风险显著更高[2][3]。在严重激素影响或组织并发症的病例中，偶尔可能发生继发性细菌感染，但这些是原发性肿瘤过程的后果而非原因。

### Sources

[1] Canine Transmissible Venereal Tumor - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/canine-transmissible-venereal-tumor/canine-transmissible-venereal-tumor

[2] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease

[3] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings-0

[4] Orchitis and Epididymitis in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-male-small-animal/orchitis-and-epididymitis-in-dogs-and-cats

## 临床症状和体征

支持细胞瘤表现出独特的临床表现，可分为典型和非典型表现。最具特征性的综合征是雌性化，约70%的患病犬出现此症状[1]。

**典型表现**

雌性化综合征是由于肿瘤细胞分泌雌激素引起的高雌激素症所致的标志性临床表现[2]。患病犬出现双侧对称性脱毛，始于腹侧腹部、大腿内侧和体侧，逐渐累及躯干和颈部，但头部和四肢不受影响。皮肤变得色素沉着过度且变薄，呈现特征性的"雌性"外观。雄性犬可能表现出乳腺肿大（男子乳腺发育）、下垂的包皮以及对其他雄性犬的吸引[1]。

骨髓抑制是另一个关键表现。由于雌激素引起的骨髓抑制，犬出现严重的非再生性贫血、血小板减少和中性粒细胞减少[1][2]。临床症状包括嗜睡、虚弱、苍白黏膜、瘀点出血和易感性增加。前列腺疾病也可能继发于高雌激素症[2]。

**非典型体征**

一些犬表现出非特异性症状，包括间歇性跛行、厌食或行为改变，而无明显雌性化。在隐睾病例中，睾丸肿大引起的腹部膨胀可能是唯一的初始发现[1]。

**品种特异性模式**

支持细胞瘤可能发展为单侧或双侧肿瘤[3]。隐睾症使某些品种易患支持细胞瘤，特别是拳师犬、德国牧羊犬和魏玛犬。这些品种的腹部肿瘤发生率较高，由于肿块不可触及而延迟诊断[1]。

### Sources
[1] Is it immune-mediated neutropenia?: https://www.dvm360.com/view/it-immune-mediated-neutropenia
[2] Bone Marrow Hypoplasia in Eight Dogs with Sertoli Cell: https://avmajournals.avma.org/view/journals/javma/178/5/javma.1981.178.05.497.xml
[3] Pathology in Practice in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/241/1/javma.241.1.55.xml

## 诊断方法

支持细胞瘤的诊断评估涉及多种方法，以准确识别和表征这些睾丸肿瘤。体格检查包括触诊睾丸不对称、肿块，以及评估高雌激素症体征[1]。

超声检查对诊断评估至关重要。睾丸肿瘤表现为边界不同的肿块，呈低至高回声，可能模糊正常睾丸结构[2]。彩色多普勒超声可能在涉及睾丸扭转或血管供应受损的病例中显示无血流[3]。

实验室检测包括作为诊断辅助的激素检测。抗苗勒管激素（AMH）检测可检测功能性卵巢组织，而升高的雌二醇浓度可能表明产生激素的支持细胞瘤[4]。睾酮浓度有助于区分未去势、隐睾和去势犬。去势犬的基础睾酮水平应<50 pg/ml，而隐睾犬通常显示100-500 pg/ml[5]。

人绒毛膜促性腺激素（HCG）刺激测试在基础激素水平不确定时为滞留睾丸组织提供激发性评估[5]。睾丸肿块的细针穿刺抽吸有助于区分肿瘤类型，包括精原细胞瘤、间质细胞瘤和支持细胞瘤[2]。

组织病理学检查仍然是明确的诊断方法。通过睾丸切除术获得的组织样本允许进行完整的显微镜评估和明确的肿瘤分类[3]。在怀疑转移的病例中，可能需要对区域淋巴结进行同步评估。

### Sources

[1] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease

[2] Abnormal reproductive ultrasononography in dogs and toms (Proceedings): https://www.dvm360.com/view/abnormal-reproductive-ultrasononography-dogs-and-toms-proceedings

[3] A retained testis and spermatic cord torsion in a boxer: https://www.dvm360.com/view/clinical-exposures-retained-testis-and-spermatic-cord-torsion-boxer

[4] Ovarian Remnant Syndrome in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals

[5] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge

## 治疗方案

支持细胞瘤的主要治疗方法是手术睾丸切除术（去势），包括完全切除双侧睾丸[1]。这种手术干预消除了雌激素产生的来源并解决了潜在的肿瘤问题。缺乏睾丸切除术经验的兽医应考虑转诊给专科外科医生以确保最佳结果。

医疗管理侧重于治疗雌性化综合征引起的并发症。支持性护理包括为因雌激素引起的骨髓抑制而导致严重贫血或出血障碍的患者输血[2]。犬的浓缩红细胞输注量为6-10 ml/kg，而凝血功能障碍可能需要输注血浆，剂量为10-20 ml/kg[2]。

术后监测对高危患者至关重要。体温支持很关键，因为麻醉期间常发生低体温[3]。通过液体疗法（包括晶体液和胶体液）进行循环支持有助于维持血压和组织灌注[3]。在第一小时内每15分钟密切监测生命体征，然后每小时监测一次，确保早期发现并发症[3]。

大多数患有支持细胞瘤的犬表现出功能性肿瘤体征，需要全面的支持性护理[4]。关于睾丸肿瘤化疗的证据有限，尽管在某些病例中已使用卡铂[1]。主要重点仍然是手术切除结合全面的支持性护理以解决全身并发症。

### Sources
[1] Avian reproduction and reproductive diseases (Proceedings): https://www.dvm360.com/view/avian-reproduction-and-reproductive-diseases-proceedings
[2] Practical transfusion therapy (Proceedings): https://www.dvm360.com/view/practical-transfusion-therapy-proceedings
[3] High-risk patients: Supportive care, monitoring, and postoperative care (Proceedings): https://www.dvm360.com/view/high-risk-patients-supportive-care-monitoring-and-postoperative-care-proceedings
[4] Surgery of the urogenital system (Proceedings): https://www.dvm360.com/view/surgery-urogenital-system-proceedings

## 预防措施

支持细胞瘤最有效的预防策略是对所有雄性犬和猫进行早期去势[1]。常规绝育消除了支持肿瘤发展的激素环境，并完全防止支持细胞瘤的形成。

**隐睾管理**
应特别关注隐睾动物，因为滞留睾丸的肿瘤风险显著高于正常下降的睾丸[1][2]。隐睾犬无论年龄大小都应立即进行去势手术，因为它们易患睾丸癌，包括支持细胞瘤[2][3]。隐睾个体的父母双方都应被视为携带者，因为这种情况是遗传性的且性别限制性的[3]。

**高风险品种筛查**
某些品种对隐睾症和随后的睾丸肿瘤表现出更高的易感性，包括玩具贵宾犬和迷你贵宾犬、博美犬、腊肠犬、吉娃娃、马尔济斯犬、拳师犬、北京犬、英国斗牛犬、迷你雪纳瑞犬和设得兰牧羊犬[1]。

**繁殖建议**
由于这种情况的遗传性质，隐睾动物绝不应用于繁殖[1][3]。常规繁殖能力检查应包括仔细触诊阴囊内容物，以早期识别睾丸异常。

环境管理包括避免过度热暴露和在常规检查期间监测睾丸炎症或肿大的迹象。

### Sources
[1] Reproductive Disorders of Male Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-male-dogs
[2] A literature review on the welfare implications of gonadectomy: https://avmajournals.avma.org/view/journals/javma/250/10/javma.250.10.1155.xml
[3] Male Genital Abnormalities of Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/congenital-and-inherited-anomalies-of-the-reproductive-system/male-genital-abnormalities-of-animals

## 鉴别诊断

支持细胞瘤的主要鉴别诊断包括犬类另外两种最常见的睾丸肿瘤：间质细胞（莱迪希细胞）瘤和精原细胞瘤[1]。这三种肿瘤类型在犬类患者中发生率几乎相等，临床上可能难以区分[1]。

**关键鉴别特征：**

支持细胞瘤与雌性化综合征独特相关，导致吸引雄性犬、性欲丧失和双侧对称性脱毛[3]。这种激素活性很少在间质细胞瘤或精原细胞瘤中出现。 

**临床鉴别：**
所有睾丸肿瘤都表现为睾丸肿大和触诊时睾丸质地改变[3]。超声检查显示密度变化，但可能无法明确区分肿瘤类型[3]。

**基于位置的考虑：**
支持细胞瘤在隐睾睾丸中患病率增加，而精原细胞瘤可能在滞留睾丸中表现为小的管内肿块[1][5]。混合肿瘤表现是可能的，已有报道在同一患者中同时存在支持细胞瘤和精原细胞瘤的病例[5]。

**非肿瘤性鉴别：**
5岁以上犬的睾丸退化表现为睾丸变软和体积减小，与肿瘤典型的坚实肿大形成对比[3]。附睾炎引起疼痛性肿胀，但缺乏支持细胞瘤特有的激素效应[3]。

### Sources

[1] Pathology in Practice in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0231.xml
[2] Pathology in Practice - javma: https://avmajournals.avma.org/downloadpdf/view/journals/javma/259/S2/javma.21.05.0231.pdf
[3] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings
[4] Testicular Neoplasia in the Retained Testicles of an Intersex: https://meridian.allenpress.com/jaaha/article/48/2/118/176671/Testicular-Neoplasia-in-the-Retained-Testicles-of

## 预后

当通过手术去势适当治疗时，支持细胞瘤的预后通常良好[1]。大多数犬在切除受影响的睾丸后临床症状完全缓解，特别是当高雌激素症被及时识别和治疗时时，结果尤为有利。

低转移率显著提高了长期生存率。转移发生率低于15%，通常扩散到区域淋巴结、肺部或腹部器官[1]。诊断时无转移性疾病的犬在手术干预后具有极好的生存率。

高雌激素症的恢复因严重程度而异。轻度雌性化体征如男子乳腺发育和脱发通常在术后数周至数月内消退[2]。然而，严重的骨髓抑制可能需要数月才能完全恢复，在此期间一些犬可能需要支持性护理，包括输血和促红细胞生成素治疗。

隐睾犬面临额外的考虑因素，因为滞留睾丸的肿瘤风险比下降睾丸高13倍[1]。隐睾患者的早期手术干预可预防并发症并改善结果。

影响恢复的预后因素包括肿瘤大小、高雌激素症存在、骨髓抑制严重程度和患者年龄。患有局部性疾病并接受及时治疗的犬预后最为有利，而那些有严重全身影响的犬可能经历较长的恢复期，但仍能获得良好的长期结果。

### Sources
[1] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
[2] Paraneoplastic syndromes (Proceedings): https://www.dvm360.com/view/paraneoplastic-syndromes-proceedings
