# 犬传染性气管支气管炎：综合兽医指南

犬传染性气管支气管炎，通常被称为犬窝咳，是小动物兽医实践中最常见的呼吸道疾病之一。这种高度传染性的多病原综合征影响所有年龄段的犬，但在寄养设施、收容所和兽医医院等拥挤环境中构成特殊风险。

本报告从临床表现到治疗结果对犬窝咳进行了系统检查。涵盖的关键领域包括支气管败血波氏杆菌与病毒共同感染之间的复杂病原体相互作用、利用PCR组合和放射学评估的诊断方法、强调支持性护理的循证治疗方案，以及结合疫苗接种与环境管理的综合预防策略。该分析借鉴了当前兽医文献，为伴侣动物环境中的有效疾病管理和疫情预防提供了实用指导。

## 疾病概述

犬传染性气管支气管炎（ITB），通常被称为"犬窝咳"，是一种高度传染性的呼吸道疾病复合体，影响犬的上呼吸道[1][7]。该病症的特征是气管和支气管发炎，导致特征性的剧烈阵发性咳嗽，常以干呕或咳痰结束[1][7]。

ITB由多种病因引起，包括支气管败血波氏杆菌、犬副流感病毒、犬腺病毒2型和犬流感病毒[1][7]。该病在饲养于犬舍、寄养设施、狗公园和兽医医院等拥挤环境中的年轻、体弱动物中表现出特别高的患病率[3][7]。该病在密切接触的易感犬中迅速传播，所有年龄均受影响，但幼犬更容易患重症[7]。

该病通过气溶胶化呼吸道分泌物和接触受污染的污染物（包括食盆和人手）传播[1]。尽管广泛接种疫苗，但在犬类密集环境中仍常见疫情爆发，凸显了该综合征复杂的多病原体特性[1]。临床症状通常在暴露后5-10天出现，近期与其他犬接触或全身麻醉是常见的诱发因素[1][7]。

### Sources
[1] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[2] Managing of bronchial disease in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[3] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[4] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 常见病原体

犬传染性气管支气管炎由多种病原体引起，这些病原体通常协同作用导致疾病。主要细菌病原体是支气管败血波氏杆菌，一种革兰氏阴性需氧球杆菌，与百日咳波氏杆菌（人类百日咳的病原体）密切相关[1]。这种细菌特别适应于定植犬和猫的纤毛呼吸道上皮，是该病症的主要病因[1]。

与该病相关的病毒病原体包括犬副流感病毒（CPiV）、犬腺病毒2型（CAV-2）和犬流感病毒[2]。当与支气管败血波氏杆菌共同感染时，感染这些病毒病原体的犬比单独感染任何单一病原体时经历更严重的呼吸道疾病[1]。其他病毒病因包括犬瘟热病毒，但在典型的犬窝咳病例中认为可能性较小[2]。

支气管败血波氏杆菌具有几种毒力因子，包括菌毛和非菌毛粘附素，如丝状血凝素（FHA）和百日咳粘附素，它们促进附着于呼吸道上皮细胞[1]。该细菌释放外毒素，包括腺苷酸环化酶-溶血素和皮肤坏死毒素，损害纤毛功能并损害免疫反应[1]。支气管败血波氏杆菌、CPiV和CAV-2的共同感染在临床实践中最为常见[2]。

### Sources

[1] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings

[2] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 临床症状和体征

犬传染性气管支气管炎最具特征性的临床体征是持续性、剧烈、干咳，常被描述为具有"鹅鸣"音质[1][2][3]。这种独特的咳嗽可能随后出现干呕和作呕，通常呈阵发性[2]。咳嗽常由兴奋、运动或轻柔触诊气管引发[2][6]。

其他典型体征包括运动不耐、呼吸困难和鼻分泌物，可能从浆液性发展为粘液性或粘液脓性[1]。在无并发症的病例中，犬通常保持警觉并维持正常食欲，但如果发生继发性细菌性肺炎，则可能出现嗜睡和厌食[1][2]。

该病通常在接触其他犬后3-10天发展[2][6]。在大多数情况下，严重程度在最初5天内减轻，但疾病持续10-20天[6]。发热、脓性鼻分泌物、抑郁和咳痰的出现通常表明已发展为支气管肺炎[6]。

非典型表现可能包括主要表现为呼吸窘迫而无明显咳嗽，特别是在非常年轻或免疫功能低下的动物中[1]。一些犬可能表现为更严重的呼吸道综合征，特征为粘液性至粘液脓性鼻眼分泌物，并伴有肺炎并发症[2]。

虽然犬窝咳影响所有品种，但短头颅品种由于其解剖结构易发生气道阻塞，可能表现出更严重的呼吸窘迫[1][10]。

### Sources
[1] Diagnosing and managing canine eosinophilic bronchopneumopathy: https://www.dvm360.com/view/diagnosing-and-managing-canine-eosinophilic-bronchopneumopathy
[2] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[3] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings
[4] Canine Infectious Respiratory Diseases: https://www.dvm360.com/view/canine-infectious-respiratory-diseases-sponsored-schering-plough-and-vetreach
[5] Canine infectious respiratory disease: Challenges and considerations in animal shelters: https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings
[6] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[7] Kennel Cough (Infectious Tracheobronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/kennel-cough-infectious-tracheobronchitis-in-dogs
[8] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[9] Retrospective analysis of incidence, clinical features, potential risk factors, and prognostic indicators for aspiration pneumonia in three brachycephalic dog breeds: https://avmajournals.avma.org/view/journals/javma/253/7/javma.253.7.869.xml
[10] What Is a Brachycephalic Dog Breed? - Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/what-is-a-brachycephalic-dog-breed

## 诊断方法

临床表现评估是诊断犬传染性气管支气管炎的基础。犬通常表现为急性咳嗽、打喷嚏、鼻眼分泌物、发热、厌食和嗜睡[1]。特征性的干、剧烈、爆发性咳嗽常通过气管触诊引发，可能伴有作呕，提示有痰咳出[1]。"鹅鸣"声音是犬窝咳的特有症状[2]。

当特征性咳嗽在接触易感犬后5-10天出现时，应怀疑犬窝咳[2]。鉴别诊断包括多种心脏和呼吸道疾病，传染性病因包括犬流感病毒、犬瘟热病毒、副流感病毒、腺病毒2型、支气管败血波氏杆菌、支原体属和马链球菌兽瘟亚种[4]。

呼吸道PCR组合是必要的诊断工具，特别是在初始临床症状出现四天内采集样本以捕获病原体在排毒期内的样本时[1]。全面组合应包括支气管败血波氏杆菌、犬腺病毒2型、犬瘟热病毒、甲型流感病毒、犬支原体和马链球菌兽瘟亚种[1]。商业诊断实验室通过IDEXX、Antech和康奈尔提供呼吸道PCR组合[1]。

胸部X光片对于确定疾病严重程度和排除其他咳嗽原因至关重要[2]。无并发症病例的放射学检查结果通常无明显异常，主要作用是排除其他呼吸道疾病[10]。然而，在更严重的病例中，胸部X光片可显示支气管增厚、肺过度充气、支气管扩张和继发性并发症如肺炎[10]。

### Sources

[1] Breaking down the mysterious canine infectious respiratory disease: https://www.dvm360.com/view/breaking-down-the-mysterious-canine-infectious-respiratory-disease
[2] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[3] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings-0
[4] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings

## 治疗选择

犬传染性气管支气管炎的治疗主要是支持性的，因为该病通常是自限性的[1]。患有无并发症犬窝咳的犬通常不需要住院治疗，可以作为门诊病例管理[1]。

**药物干预**

除非有继发性细菌性肺炎的证据，否则通常不需要抗生素[1]。当需要时，推荐的抗生素包括阿莫西林/克拉维酸（12-25 mg/kg口服每12小时一次）、甲氧苄啶-磺胺（15-30 mg/kg口服每12小时一次）、恩诺沙星（10 mg/kg口服每24小时一次）或多西环素/米诺环素（5-10 mg/kg口服每12小时一次），疗程7-14天[1]。多西环素是各地区的主要首选药物[2]。对于波氏杆菌感染，多西环素和增效磺胺是良好的经验性选择，而波氏杆菌对头孢氨苄始终耐药[3]。

**非药物方法**

支持性护理包括使用生理盐水雾化和气道湿化以帮助液化分泌物[4]。叩诊（轻柔胸部叩击）应每天进行数次，以刺激排痰并分解分泌物[5]。环境管理包括最小化压力、维持最佳温度和湿度条件以及确保适当休息[4]。

**护理**

受影响的犬应与其他动物隔离饲养以防止传播[1]。住院患者需要严格的隔离协议和适当的卫生实践[1]。犬应使用胸背带而非项圈牵引，以避免气管压力[3]。

### Sources

[1] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[2] an observational survey using dog o - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0133/ajvr.25.04.0133.pdf
[3] Canine infectious respiratory disease complex: https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[4] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[5] Managing puppies with pneumonia: https://www.dvm360.com/view/managing-puppies-with-pneumonia-proceedings

## 预防措施

有效预防犬传染性气管支气管炎需要结合疫苗接种、环境管理和隔离协议的多方面方法。鼻内接种提供最佳保护，在72小时内迅速产生免疫力，并且持续时间优于注射替代方案[1]。与皮下疫苗不同，鼻内途径可防止挑战暴露后的细菌脱落[1]。

疫苗接种方案因途径和风险水平而异。注射疫苗需要在8周和12周时初始接种，每年加强一次，或在高风险环境中每6个月一次[2]。犬应在6-8周时接种针对犬瘟热、副流感和腺病毒2型的核心疫苗，每3-4周重复一次，直到14-16周龄[3]。

环境控制侧重于减少拥挤和有效消毒。在密集饲养环境中，每天增加3%的感染风险[1]。使用次氯酸钠（1:32稀释）进行适当消毒可有效灭活大多数病原体，但表面必须每天彻底干燥[1]。隔离协议要求将症状犬单独饲养，与健康动物保持至少20英尺距离[1]。通过独立通风系统或空气净化器进行空气质量管理可减少空气传播病原体的传播[4]。

多犬设施需要全面的协议，包括及时移除症状动物，无论严重程度如何，因为轻度受影响的犬可能脱落强毒病原体[1]。对于患有慢性支气管疾病的犬，应避免鼻内接种，因为可能加重呼吸道症状[5]。

### Sources

[1] Canine infectious respiratory disease complex: https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[2] Canine vaccine update (Proceedings): https://www.dvm360.com/view/canine-vaccine-update-proceedings
[3] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[4] Clearing the air in contaminated spaces: https://www.dvm360.com/view/clearing-the-air-in-contaminated-spaces
[5] Chronic cough in the dog (Proceedings): https://www.dvm360.com/view/chronic-cough-dog-proceedings

## 鉴别诊断

犬传染性气管支气管炎必须与几种表现出类似咳嗽和呼吸窘迫临床症状的呼吸道和心脏疾病相鉴别。主要的鉴别诊断包括气管塌陷、慢性支气管炎和心脏病[1]。

**气管塌陷**产生特征性的"鹅鸣"咳嗽，通常是阵发性的，由兴奋或运动引发[1]。与传染性气管支气管炎不同，气管塌陷主要影响中年小型犬，并且在咳嗽发作时常伴有可听见的"咔嗒"声[1]。体格检查可能发现颈部气管变平，放射学或支气管镜检查可确认动态气道塌陷[1]。

**慢性支气管炎**表现为持续至少两个月的咳嗽，通常影响中小型成年犬[2][4]。咳嗽通常伴有作呕，患者常有呼气时喘息[4]。X光片可能显示支气管间质型，而支气管镜检查显示气道充血和粘液分泌过多[4]。

**心脏病**，特别是左侧心力衰竭或左心房增大引起主支气管压迫，可导致犬咳嗽[6]。患有心脏病咳嗽的犬通常有响亮的心脏杂音，胸部X光片显示心脏增大并可能伴有肺水肿[6]。与传染性气管支气管炎不同，心脏病患者通常表现为体重减轻和运动不耐[6]。

鉴别特征包括气管支气管炎的急性发作和传染背景与其他疾病的慢性进行性体征，以及传染病例对抗微生物治疗的反应[2]。

### Sources
[1] Tracheal collapse: A common cause of chronic cough: https://www.dvm360.com/view/tracheal-collapse-common-cause-chronic-cough-proceedings
[2] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[3] Managing the coughing dog: https://www.dvm360.com/view/managing-coughing-dog-proceedings
[4] Canine chronic bronchitis and pulmonary fibrosis: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[5] Localization of the pulmonary problem: https://www.dvm360.com/view/localization-pulmonary-problem-proceedings
[6] Heart or lungs: https://www.dvm360.com/view/heart-or-lungs-proceedings

## 预后

犬传染性气管支气管炎的预后在无并发症和有并发症病例之间差异显著。大多数无并发症病例预后良好，疾病自限性，在10-20天内消退[1]。咳嗽的严重程度通常在最初5天内减轻，尽管疾病持续整个病程[3]。患有轻度疾病的犬通常保持正常食欲、体温和白细胞计数[3]。

然而，并发症可显著改变临床结果。出现更严重的体征，包括发热、脓性鼻分泌物、抑郁和咳痰，表明继发感染如肺炎，特别是在幼犬中[3]。在犬舍环境中，疫情可能影响超过50%的犬，幼犬受影响更严重，如果不治疗有显著死亡风险[2]。患有继发于气管支气管炎的细菌性肺炎的犬需要及时抗生素治疗以防止危及生命的并发症[2]。

对治疗的反应在个体患者之间差异很大[6]。一些犬通过适当治疗获得近乎完全的康复，而其他犬则需要终身积极的多种药物管理[6]。晚期疾病并发症如支气管扩张或肺叶不张通常对药物治疗反应不佳，预后更为谨慎[6]。环境因素、压力和继发性细菌感染可加剧疾病严重程度并影响恢复结果[1][2]。

### Sources

[1] Canine infectious respiratory disease complex: https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[2] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[3] Tracheobronchitis (Bronchitis) in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheobronchitis-bronchitis-in-dogs
[6] Chronic cough in the dog (Proceedings): https://www.dvm360.com/view/chronic-cough-dog-proceedings
