# 伴侣动物基底细胞肿瘤

基底细胞肿瘤在小动物兽医临床中是一个重要关注点，特别是作为猫最常见的皮肤肿瘤和犬类中显著的新生物。这些上皮性肿瘤虽然通常为良性，但需要准确诊断和适当管理以确保最佳的患者预后。本综合报告探讨了犬猫基底细胞肿瘤的临床特征、诊断方法和治疗策略。主要发现包括两个物种中的品种特异性易感性、区分犬毛母细胞瘤与真正基底细胞肿瘤的术语演变，以及与完全手术切除相关的良好预后。报告涉及关键的鉴别诊断、细胞学特征和新兴的治疗方法，为循证兽医护理提供信息。

## 疾病概述

基底细胞肿瘤是良性皮肤新生物，代表伴侣动物中一组异质性的上皮性皮肤肿瘤[1]。这些肿瘤由类似于表皮和附属器祖细胞的小嗜碱性细胞组成，主要起源于真皮中层至深层[1]。

基底细胞肿瘤的术语和分类已显著演变。在犬类中，传统的"基底细胞肿瘤"现在更准确地被描述为毛母细胞瘤，因为它们起源于毛球[1]。对于猫类，基底细胞肿瘤仍然是最常见的皮肤肿瘤，通常是良性增生[1][3]。

**犬类的流行病学模式：**
犬类基底细胞肿瘤主要影响中老年犬，品种易感性包括刚毛指示格里芬犬、凯利蓝梗和软毛麦色梗[1]。这些肿瘤最常见于头部（尤其是耳朵）、颈部和前肢[1]。肿瘤表现为坚实的、单个的、通常无毛或溃疡性结节，可能呈带蒂状，直径从小于1厘米到超过10厘米不等[1]。

**猫类的流行病学模式：**
猫类基底细胞肿瘤主要影响老年猫，家养长毛猫、喜马拉雅猫和波斯猫风险最高[1][5]。这些肿瘤几乎可以在身体的任何部位发展，常见于头部、颈部或肩部区域[4]。在猫中，这些肿瘤通常高度色素沉着，并且比犬类更常表现为囊性变异[1][5]。它们表现为单个、边界清晰、坚实、无毛、圆顶状肿块，通常可移动[4]。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Incidences of neoplasia: https://www.dvm360.com/view/incidences-neoplasia
[3] Common feline cancers (Proceedings): https://www.dvm360.com/view/common-feline-cancers-proceedings
[4] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[5] Tumors of the Skin in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats

## 病理生理学和临床表现

基底细胞肿瘤是最常见的猫皮肤肿瘤，起源于类似于表皮祖细胞的嗜碱性细胞[1]。这些肿瘤通常出现在真皮中层至深层，表明可能是附属器来源而非表皮来源，这将其与人类基底细胞癌区分开来[6]。

猫的大多数基底细胞肿瘤是良性的，表现为坚实、单个、边界清晰、圆顶状的肿块，通常无毛且隆起[1]。它们常见于中老年猫的头部、颈部或肩部区域，特别影响家养长毛猫、喜马拉雅猫和波斯猫[1][6]。这些肿瘤可以有色素沉着，使它们成为猫最常见的色素性皮肤肿瘤[1]。

临床表现具有特征性：这些肿块通常直径小于1厘米到大于10厘米，通常高度色素沉着且可能呈带蒂状[6]。囊性变异在猫中比在犬中更常见。虽然良性肿瘤表现为可能溃疡并引起继发性炎症的扩张性病变[6]，但恶性变异（基底细胞癌）表现为与表皮连续且具有局部侵袭性的溃疡性斑块[6]。

手术切除通常可以治愈典型的良性基底细胞肿瘤[1]。然而，恶性形式需要更积极的管理，包括评估区域淋巴结和考虑对不完全切除的肿瘤进行放射治疗[1]。

### Sources
[1] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 诊断方法

基底细胞肿瘤的明确诊断需要结合临床检查、细胞学评估和组织病理学确认。诊断方法在准确表征方面的效用和局限性各不相同。

**临床检查和细胞学**

细针穿刺提供快速初步诊断，但存在显著局限性。基底细胞肿瘤通常脱落良好，产生小而均匀的深染细胞簇，具有高核质比（1:1）[1]。细胞呈现为"葡萄状簇"，可见细胞质很少，使得细胞学上难以评估单个细胞形态[1,2]。然而，细胞学评估不能可靠地区分良性和恶性基底细胞肿瘤，也不能将它们与其他圆形细胞肿瘤区分开来。

**组织病理学特征**

组织病理学检查仍然是明确诊断和分类的金标准。在犬类中，大多数以前被分类为基底细胞癌的肿瘤显示角化证据，现在被称为基底鳞状细胞癌[1]。这些肿瘤显示与表皮的组织学连续性和局部侵袭性。猫类基底细胞癌通常表现出表皮连续性、局部侵袭，并且可能是多中心的，尽管远处转移很少发生[1]。组织病理学上可见的构筑模式和分化程度提供了确定恶性潜能的重要信息，而这些信息无法通过细胞学评估[2]。

**先进影像学考虑因素**

虽然对于皮肤基底细胞肿瘤通常不需要先进影像学检查，但对于恶性变异的分期或评估局部侵袭可能需要先进影像学检查，特别是当广泛病变需要手术计划时。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings-0

## 治疗选择

手术切除仍然是猫和犬大多数基底细胞肿瘤的主要治疗方法。对于良性基底细胞肿瘤，狭窄的手术切缘（0.5-1厘米）通常足够，完全切除通常可以治愈[1]。该手术通常耐受良好，典型良性表现的预后良好。

**手术治疗**

完全手术切除为基底细胞肿瘤提供最佳预后。对于恶性变异，应考虑更宽的手术切缘，同时进行引流淋巴结穿刺和三视图胸部X光检查以评估转移性疾病[2]。如果手术切缘不完全，应考虑修复手术以切除带有适当切缘的疤痕或进行放射治疗[2]。这些新生物的异质性需要专门的组织病理学评估来指导适当的治疗计划[3]。

**替代治疗方法**

冷冻手术是眼睑肿块和具有挑战性位置的有效替代方法。使用液氮和冷冻探头，通常建议进行两次冻融循环，实现快速冷冻后缓慢解冻以获得最佳组织破坏[4]。对于眼睑等具有挑战性位置的肿瘤，使用锶-90放射的近距离治疗可以非常有效[1]。这种局部放射方法在手术切除困难或美容上不可接受时特别有用。

**恶性病例考虑因素**

虽然猫的大多数基底细胞肿瘤是良性的，但恶性变异需要更积极的管理。当组织病理学上发现血管或淋巴管栓塞时，可以考虑化疗[2]。然而，考虑到这些肿瘤通常为良性，全身治疗很少必要。

### Sources

[1] Common feline cancers (Proceedings): https://www.dvm360.com/view/common-feline-cancers-proceedings
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[3] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[4] Skills Laboratory: Cryosurgery for eyelid masses: https://www.dvm360.com/view/skills-laboratory-cryosurgery-eyelid-masses

## 预防措施

**环境风险因素和预防**

犬和猫的基底细胞肿瘤由多种环境因素发展而来。化学致癌物、太阳辐射和病毒可能导致皮肤肿瘤的发展[1]。然而，由于基底细胞肿瘤主要具有遗传和年龄相关性质，其特定的预防策略有限。

在某些情况下，阳光暴露可能起作用，特别是对于色素沉着浅的动物肿瘤[2]。通过适当的庇护所限制过度紫外线暴露和避开阳光高峰时段可能提供一些保护性益处。

**品种特异性考虑因素**

某些品种显示对基底细胞肿瘤的易感性增加。在犬类中，刚毛指示格里芬犬、凯利蓝梗和软毛麦色梗风险较高[1]。在猫类中，家养长毛猫、喜马拉雅猫和波斯猫最常受影响[3]。基底细胞肿瘤是猫最常见的皮肤肿瘤，并且几乎总是良性[4]。

虽然尚未建立常规筛查方案，但易感品种的主人应密切监测宠物的新皮肤肿块，特别是当动物达到中年及以上年龄时。

## 预后

基底细胞肿瘤的预后通常良好。在猫中，这些肿瘤几乎总是良性且易于切除[4]。简单的手术切除通常可以治愈大多数病例[2]。

当实现完全切除时，复发率很低。在两只仅接受简单切除治疗的猫中，肿块分别在8个月和10个月后复发[3]，表明虽然复发是可能的，但发生频率不高。大多数基底细胞肿瘤的良性性质有助于在适当手术管理后获得良好的长期预后。

### Sources
[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[3] Use of chemical ablation with trichloroacetic acid to treat...: https://avmajournals.avma.org/view/journals/javma/230/8/javma.230.8.1170.xml
[4] Common feline cancers (Proceedings): https://www.dvm360.com/view/common-feline-cancers-proceedings

## 鉴别诊断

现有内容提供了基底细胞肿瘤鉴别诊断的全面概述。根据原始资料，可以进行额外的改进，以更好地区分基底细胞肿瘤与外观相似的肿块。

**原发性皮肤肿瘤鉴别诊断**已得到很好确立，包括肥大细胞瘤、鳞状细胞癌和黑色素瘤[1]。肥大细胞瘤是猫第二常见的皮肤肿瘤，可表现为坚实肿块，特别是年轻暹罗猫的组织细胞变异型[1]。基底细胞肿瘤是猫最常见的皮肤肿瘤，表现为单个、边界清晰、圆顶状的肿块，可能有色素沉着[2]。

**细胞学鉴别**对准确诊断至关重要。基底细胞肿瘤显示特征性的均匀立方形细胞，排列成紧密簇状，具有少量深嗜碱性细胞质，可能有色素沉着[2]。独特的颗粒状细胞质有助于将这些肿瘤与其他类型区分开来[5]。相比之下，肥大细胞瘤含有在浅蓝色细胞质中具有不同数量深紫色颗粒的细胞[4]。

**额外的鉴别考虑因素**包括皮脂腺肿瘤和毛囊肿瘤。皮脂腺瘤含有成熟的、均匀的皮脂上皮细胞簇，具有丰富的泡沫状细胞质，而毛囊肿瘤通常表现为丰富的角蛋白和碎片[2]。鳞状细胞癌通常显示单个细胞，具有角化和透明样细胞质的证据[2]。

**诊断方法改进**强调细针穿刺细胞学作为主要诊断工具，允许按细胞来源对肿瘤进行分类[9]。基底细胞肿瘤细胞的均匀外观和紧密簇状排列模式提供了可靠的细胞学识别，尽管当细胞学发现不确定时，明确诊断需要组织病理学确认。

### Sources
[1] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[2] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[3] Cytologic diagnoses that every practicing veterinarian should be able to make (Proceedings): https://www.dvm360.com/view/cytologic-diagnoses-every-practicing-veterinarian-should-be-able-make-proceedings
[4] Clinical Exposures: Canine circumanal gland adenoma: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[5] Cancer testing: beyond the biopsy (Proceedings): https://www.dvm360.com/view/cancer-testing-beyond-biopsy-proceedings
