# 伴侣动物创伤性椎间盘突出

创伤性椎间盘突出是兽医医学中一种关键的神经系统急症，其特征是在外部创伤后急性发作，这与退行性椎间盘疾病不同。与汉森I型IVDD中观察到的逐渐退化不同，创伤性突出涉及正常髓核物质由于撕裂纤维环的物理力而突然疝入椎管。本综合报告探讨了机械性病理生理学、软骨营养障碍犬的品种易感性、强调MRI作为金标准的诊断成像方案，以及从保守管理到手术减压的循证治疗方法。分析涵盖了关键预后因素，包括神经系统分级系统、深痛觉评估的关键作用，以及及时手术干预对严重病例恢复结果的显著影响。

## 疾病概述

创伤性椎间盘突出，也称为汉森I型椎间盘疾病（IVDD），是伴侣动物，特别是犬类脊髓疾病的常见原因[1]。当退变的椎间盘物质突然疝入椎管，导致脊髓或神经根受压时，就会发生这种情况。

椎间盘疾病在犬中的终生患病率约为3.5%，使其成为一个重要的兽医关注问题[2]。该病在软骨营养障碍品种中最为普遍，迷你腊肠犬的终生患病率最高，约为15.3%[3]。其他易感品种包括法国斗牛犬、比格犬、西施犬、拉萨犬和北京犬[2]。最近的研究表明，在纯种犬中，法国斗牛犬患IVDD的几率最高[3]。

在这些易感品种中，由于遗传因素，特别是成纤维细胞生长因子4基因的突变，椎间盘的软骨样变性在生命的前几个月内发生[2]。软骨营养障碍品种的椎间盘突出最早可在1-2岁龄时发生，通常表现为急性且严重的临床症状[2]。

椎间盘疾病在猫中相对罕见，发病率仅为0.12%，而犬的总发病率为2%[4]。当猫发生此病时，通常影响中老年动物[4]。

### Sources

[1] Cervical jerks as a sign of cervical pain or myelopathy in dogs: https://avmajournals.avma.org/view/journals/javma/261/4/javma.22.11.0507.xml

[2] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals

[3] Demographic and lifestyle characteristics impact lifetime prevalence of owner-reported intervertebral disc disease: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.08.0553.xml

[4] Clinical Exposures: Intervertebral disk disease: An unusual cause of a cat's lameness and tail weakness: https://www.dvm360.com/view/clinical-exposures-intervertebral-disk-disease-unusual-cause-cats-lameness-and-tail-weakness

## 常见病原体

创伤性椎间盘突出主要是一种机械性疾病，而非传染病。当外部创伤，如车祸或跌倒，导致椎间盘物质突然疝入椎管时，就会发生这种情况[1][2]。与退行性椎间盘疾病不同，创伤性突出不涉及细菌、病毒或其他传染性病原体作为主要致病因素。

病理生理学集中在撕裂纤维环并允许正常髓核物质爆裂通过从而压迫神经结构的物理力上[2]。这种急性机械过程与影响脊柱的传染性疾病（如椎间盘炎）有根本不同，后者涉及细菌或真菌病原体引起椎间盘和相邻椎骨的炎症[3]。

虽然最初的创伤性椎间盘突出是非感染性的，但继发性并发症可能引入感染问题。如果需要减压手术，可能会发生术后感染，因此在手术过程中需要适当的抗生素预防[1]。此外，有神经功能缺损的虚弱患者可能因膀胱功能障碍而继发尿路感染。

创伤性椎间盘突出的非感染性性质意味着抗菌治疗不是主要治疗方案的一部分。相反，治疗重点在于抗炎药物、必要时进行手术减压和支持性护理[2]。

### Sources
[1] Clinical Exposures: Intervertebral disk disease: An unusual: https://www.dvm360.com/view/clinical-exposures-intervertebral-disk-disease-unusual-cause-cats-lameness-and-tail-weakness
[2] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings
[3] Disorders of the Spinal Column and Cord in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-spinal-column-and-cord-in-dogs

## 临床症状和体征

创伤性椎间盘突出表现出多样的神经系统表现，这些表现因病变位置、脊髓损伤程度和就诊时间而有显著差异。患有超急性或急性胸腰椎椎间盘突出的犬可能表现为脊髓休克或希夫-谢林顿姿势的临床体征[1]。这些显著的表现表明急性且严重的脊髓损伤，但不能确定预后。

临床症状差异很大，从仅有脊柱痛觉过敏到完全性截瘫，伴或不伴有深痛觉[1]。神经功能障碍程度从1级（仅背痛而无运动障碍）到5级（截瘫且无深痛觉）分级[2]。颈椎椎间盘突出通常表现为颈部疼痛，表现为颈部僵硬和肌肉痉挛，常伴有前肢跛行[3]。在胸腰椎病例中，背部疼痛表现为脊柱后凸和不愿移动，神经功能缺损范围从骨盆肢体共济失调到截瘫和失禁[3]。

腊肠犬等软骨营养障碍品种表现出遗传易感性，90%在2岁前出现退行性椎间盘变化，通常在5岁左右出现临床症状[1]。神经功能缺损的不对称性有助于病变的侧向定位，但不如其他定位体征可靠[1]。最重要的预后指标是深痛觉的存在与否，通过捏压骨结构并观察行为反应（而非反射性肢体回缩）来评估[3]。

### Sources

[1] Surgical considerations for intervertebral disk disease: https://www.dvm360.com/view/surgical-considerations-intervertebral-disk-disease-proceedings
[2] Making the cut: Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease  
[3] Disorders of the Spinal Column and Cord in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-spinal-column-and-cord-in-dogs

## 诊断方法

创伤性椎间盘突出的确诊需要先进的影像学技术[1]。临床评估始于全面的神经系统检查，以定位病变并评估运动功能、本体感觉、脊髓反射和深痛觉[2]。深痛觉的存在与否对预后确定至关重要。

磁共振成像（MRI）是诊断创伤性椎间盘突出的金标准，提供优越的软组织对比度和脊髓压迫的详细可视化[1][3]。MRI能有效识别椎间盘物质突出的程度和伴随的脊髓损伤。研究表明，MRI可以检测创伤性椎间盘突出后的脊髓压迫，并描述受影响犬的相关因素[1]。

计算机断层扫描（CT）提供了一种更快、更具成本效益的替代方案，在许多情况下同样准确[3]。CT脊髓造影结合了CT成像和对比增强的优势，以改善压迫病变的可视化并提高诊断准确性[1]。

普通X光片诊断价值有限，特别是在软骨营养障碍品种中，即使在没有症状的患者中椎间盘钙化也很常见[3]。然而，X光片可能显示椎间隙狭窄、椎管内钙化的椎间盘物质或创伤证据[4]。尽管X光脊髓造影仍常用于识别脊髓压迫部位，但在评估实际脊髓病理方面存在局限性[1]。

### Sources
[1] Magnetic resonance imaging findings in dogs with traumatic intervertebral disk extrusion: https://avmajournals.avma.org/view/journals/javma/242/2/javma.242.2.217.xml
[2] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified  
[3] Magnetic resonance imaging in animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/magnetic-resonance-imaging-in-animals
[4] Degenerative diseases of the spinal column and cord in animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals

## 治疗方案

创伤性椎间盘突出的治疗方法包括保守管理和手术干预，选择基于神经功能严重程度、疼痛强度和主人资源[1]。保守管理是轻度病例的基础，涉及2-4周的严格笼养限制并结合抗炎药物[3]。对于颈椎椎间盘突出，皮质类固醇通常比非甾体抗炎药提供更好的镇痛效果，尽管两者对轻中度疼痛都可能有效[1,5]。

对于严重疼痛、任何程度的轻瘫或保守治疗失败的患者，手术干预成为必要[1]。当椎间盘物质位于中央时，使用腹侧开槽减压术；而当物质位于外侧时，则需要背侧椎板切除术或半椎板切除术[1,5]。最近的研究表明，水合髓核突出的保守管理与手术减压达到相似的成功率[2]。

护理方案包括对非行走患者的膀胱管理、通过定期改变体位预防褥疮以及监测并发症[3]。物理治疗方式包括被动关节活动度练习、控制性牵引行走和水疗，以改善肢体功能和力量[8]。成功率因神经功能分级而异：1-2级两种方法均达到90%的恢复率，而3级手术成功率为90%，保守治疗为70%[7]。

### Sources

[1] Cervical disorders of large breed dogs (Proceedings): https://www.dvm360.com/view/cervical-disorders-large-breed-dogs-proceedings
[2] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs
[3] Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease
[4] Long-term neurologic outcome of hemilaminectomy and disk: https://avmajournals.avma.org/view/journals/javma/241/12/javma.241.12.1617.xml
[5] Cervical disorders of small breed dogs (Proceedings): https://www.dvm360.com/view/cervical-disorders-small-breed-dogs-proceedings
[6] Percutaneous enzymatic chemonucleolysis: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0790.pdf
[7] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[8] Chronic pain: nonpharmacologic therapy (Proceedings): https://www.dvm360.com/view/chronic-pain-nonpharmacologic-therapy-proceedings

## 预防措施

管理创伤性椎间盘突出需要全面的预防方法，重点是降低风险和环境改造。体重管理至关重要，因为超重犬患椎间盘疾病的几率显著更高[1][2]。通过适当饮食和控制喂养保持理想身体状况有助于减少椎间盘的机械应力。

活动调整对高风险品种至关重要，特别是腊肠犬、法国斗牛犬和比格犬等软骨营养障碍品种[1][2]。这些犬应避免高强度冲击活动，如跳上跳下家具、过度爬楼梯以及涉及扭转或突然方向改变的剧烈玩耍。有趣的是，在一些研究中，定期使用楼梯（>8级）显示出保护作用，可能是由于受控、一致的锻炼模式[2]。

环境改造包括提供通往家具的坡道或台阶、使用支撑性挽具而非项圈，以及确保防滑表面以防止跌倒[3]。对于从椎间盘疾病恢复的犬，3-4周的严格笼养限制对于防止再次受伤至关重要[3][4]。

高风险品种需要早期干预策略，因为软骨营养障碍犬的退行性变化可能在出生后几个月内开始[1]。定期兽医监测允许在临床症状出现前进行早期检测和管理。物理康复和控制的锻炼计划有助于维持脊柱健康，同时避免对椎间盘的过度压力。

### Sources

[1] Surgery STAT: Diagnosing intervertebral disk disease: https://www.dvm360.com/view/surgery-stat-diagnosing-intervertebral-disk-disease
[2] Demographic and lifestyle characteristics impact lifetime prevalence of owner-reported intervertebral disc disease: 43,517 companion dogs in the United States: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.08.0553.xml
[3] Surgery STAT: Managing IVDD: https://www.dvm360.com/view/surgery-stat-managing-ivdd/1000
[4] Disorders of the Spinal Column and Cord in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-spinal-column-and-cord-in-dogs

## 鉴别诊断

几种神经系统疾病表现出与创伤性椎间盘突出相似的临床体征，需要通过临床检查和先进影像学进行仔细鉴别[1]。

**缺血性脊髓病**通常影响老年大型犬，表现为急性、非进行性截瘫。与创伤性椎间盘突出不同，疼痛通常很轻微或不存在，MRI显示脊髓实质内特征性的T2加权高信号变化，没有压迫性物质[1]。

**纤维软骨性栓塞（FCE）**导致急性、不对称的神经功能缺损，无脊柱疼痛。该病主要影响大型、活跃的犬在运动期间。MRI显示髓内T2高信号，占位效应最小，这与椎间盘突出中看到的压迫性硬膜外物质形成对比[1]。

**汉森I型椎间盘疾病**与创伤性椎间盘突出具有相似的信号特征和临床表现，特别是在软骨营养障碍品种中。然而，I型IVDD涉及退行性椎间盘变化，其中髓核经历脱水、胶原化和钙化，使其在突出前变硬[2]。MRI通常显示由于退行性变化导致的T2低信号髓核，而创伤性突出可能显示正常椎间盘信号伴急性疝出[1]。

**急性非压迫性髓核突出（ANNPE）**表现为创伤后超急性局灶性脊髓挫伤。与持续压迫的创伤性椎间盘突出不同，ANNPE涉及正常髓核分散而无持续性压迫性物质，导致局灶性脊髓损伤，MRI上无显著占位效应[1][2]。

### Sources

[1] Comparison of magnetic resonance imaging findings in...: https://avmajournals.avma.org/view/journals/javma/258/11/javma.258.11.1222.xml
[2] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease

## 预后

创伤性椎间盘突出的预后高度依赖于就诊时的神经功能分级，深痛觉是最关键的预后指标[1]。具有完整痛觉的犬总体恢复率为80%，而没有深痛觉的犬恢复机会显著降低至50%[1]。

神经功能分级与预期结果直接相关。1-2级患者（仅疼痛或可行走性轻瘫）通过医疗或手术治疗均可达到90%的恢复率。3级病例手术结果（90%）优于药物治疗（70%）。对于4级患者，手术干预产生80-90%的恢复率，而保守管理为50%[1]。

手术干预时间严重影响严重病例的预后。5级患者（瘫痪且无深痛）单独医疗管理的恢复机会低于5%。48小时内手术提供60%的恢复概率，但一周后急剧下降至低于5%[1]。

长期并发症包括失禁、永久性神经功能恶化和自残[2]。进行性脊髓软化症影响约10%的严重受影响犬，是最严重的后遗症，通常致命[1]。复发模式显示，50%的医疗管理病例在两年内经历复发，强调了这种疾病的慢性性质[1]。

### Sources

[1] Making the cut: Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[2] Long-term neurologic outcome of hemilaminectomy and disk ...: https://avmajournals.avma.org/view/journals/javma/241/12/javma.241.12.1617.xml
