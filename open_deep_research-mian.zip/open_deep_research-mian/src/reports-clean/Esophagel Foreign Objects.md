# 伴侣动物食管异物

食管异物是小动物兽医实践中最常见的急症之一，与猫相比，犬的受影响比例更高。这种情况发生在摄入的物体卡在食管内的解剖狭窄点时，造成机械性梗阻，可能迅速发展为危及生命的并发症，包括穿孔、吸入性肺炎和狭窄形成。

本报告探讨了犬猫食管异物的临床表现、诊断方法和治疗方案。涵盖的关键领域包括显示小型犬发病率较高的流行病学模式、从骨骼到洁齿咀嚼零食的常见异物谱、紧急内窥镜取出技术，以及快速干预以预防严重并发症的关键重要性。分析还讨论了长期结果，特别关注狭窄形成作为最常见的延迟并发症，以及影响患者生存和恢复的预后因素。

## 摘要

伴侣动物的食管异物需要立即进行兽医干预以预防严重并发症。小型犬面临最高风险，物体通常卡在三个解剖狭窄点。临床表现包括吞咽困难、流涎和反流，而诊断成像依赖于放射学和内窥镜检查，既用于可视化也用于治疗。

| 治疗方法 | 成功率 | 关键考虑因素 |
|-------------------|--------------|-------------------|
| 内窥镜取出 | 良好至优秀预后 | 一线治疗，需要专业设备 |
| 推入胃部 | 不定 | 口腔取出失败时的替代方案 |
| 手术移除 | 并发症风险较高 | 保留用于复杂病例 |

并发症从即刻的穿孔和吸入性肺炎到24%的洁齿咀嚼病例中延迟发生的狭窄形成。最近的研究显示，即使食管穿孔，及时治疗后的存活率也达到87%。预防重点在于对宠物主人进行关于适当咀嚼玩具的教育，以及对反流症状立即寻求兽医关注。早期识别和快速内窥镜干预仍是这种急症成功治疗的基石。

## 疾病概述和流行病学

食管异物是伴侣动物的常见疾病，在犬中的发生率高于猫[1]。这些物体卡在食管中是因为它们过大而无法通过食管的自然解剖狭窄，造成机械性梗阻和潜在的严重并发症。

**定义和常见物体**
食管异物由卡在食管腔内的摄入物组成。骨骼是最常见的异物，但其他经常遇到的物体包括针、鱼钩、木块、生皮零食、洁齿咀嚼零食、玩具、球、石头、塑料、橡胶、大头针和绳子[1][6][7]。

**解剖易感部位**
异物通常卡在三个特定的解剖位置，这些位置食管的扩张性最小：胸廓入口、心基底部和膈肌正前方的尾段食管[1][2][7]。偶尔，物体可能卡在食管上括约肌[1]。

**物种和体型易感性**
体重小于10公斤的小型犬对食管异物嵌塞的易感性增加[2][6]。虽然犬和猫都可能受到影响，但犬的发病率显著高于猫[1][8]。

### Sources
[1] Esophageal Foreign Bodies in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophageal-foreign-bodies-in-small-animals
[2] Diagnosing and treating esophageal diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-esophageal-diseases-dogs-and-cats-proceedings
[3] Esophageal foreign bodies, esophagitis and strictures (Proceedings): https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings
[4] Surgery STAT: Surgical management of esophageal foreign bodies: https://www.dvm360.com/view/surgery-stat-surgical-management-esophageal-foreign-bodies
[5] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/255/4/javma.255.4.423.xml
[6] Regurgitation, dysphagia, and esophageal dysmotility (Proceedings): https://www.dvm360.com/view/regurgitation-dysphagia-and-esophageal-dysmotility-proceedings
[7] Common esophageal diseases that are commonly missed (Proceedings): https://www.dvm360.com/view/common-esophageal-diseases-are-commonly-missed-proceedings
[8] Diseases of the esophagus (Proceedings): https://www.dvm360.com/view/diseases-esophagus-proceedings

## 临床症状和诊断方法

患有食管异物的犬猫表现出特征性临床症状，包括吞咽困难、流涎（唾液过多）、反流、干呕和反复尝试吞咽[1][2]。其他体征可能包括张闭嘴和明显不适[1]。对于慢性异物，会出现更全身性的症状，包括厌食、体重减轻和嗜睡[2]。

如果发生穿孔，可能出现呼吸道并发症。颈段食管穿孔可能导致局部脓肿或皮下气肿，而胸段穿孔可导致胸膜炎、纵隔炎、脓胸或气胸[2][5]。**食管狭窄形成是与食管异物相关的最常见并发症**[2]。

诊断成像从普通的胸部和颈部X光片开始，因为**许多食管异物是不透射线的**，在平片上可见[2][5]。对于透射性物体，使用**水溶性碘化化合物**的食管造影优于钡剂，特别是在怀疑穿孔时[1][2][5]。**食管镜检查提供诊断可视化和治疗干预能力**[2]。由于钡糊可能遮蔽并可能损坏内窥镜，建议在食管造影后等待24小时再进行食管镜检查[2]。

这些临床症状与食管狭窄相似，后者表现为反流、流涎、吞咽困难和疼痛[3]。**荧光镜检查下的食管造影是狭窄的首选诊断工具**，可显示狭窄的数量、长度、位置和严重程度[3]。主要鉴别诊断包括食管炎、巨食管症、食管裂孔疝和血管环异常，这些疾病有重叠的临床表现，但需要不同的影像学方法进行明确诊断[2][6]。

### Sources
[1] Surgical management of esophageal foreign bodies: https://www.dvm360.com/view/surgery-stat-surgical-management-esophageal-foreign-bodies
[2] Esophageal Foreign Bodies in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophageal-foreign-bodies-in-small-animals
[3] Esophageal Strictures in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophageal-strictures-in-small-animals
[4] Regurgitation, dysphagia, and esophageal dysmotility: https://www.dvm360.com/view/regurgitation-dysphagia-and-esophageal-dysmotility-proceedings
[5] Diagnosing and treating esophageal diseases in dogs and cats: https://www.dvm360.com/view/diagnosing-and-treating-esophageal-diseases-dogs-and-cats-proceedings
[6] Gastrointestinal motility disorders caused by esophageal disease: https://www.dvm360.com/view/gastrointestinal-motility-disorders-caused-by-esophageal-disease

## 治疗选择和管理

食管异物的治疗以紧急稳定随后快速移除为中心[1]。初始稳定措施包括静脉输液、补充氧气和广谱抗生素[1]。所有患者都需要立即评估呼吸功能受损情况，因为吸入性肺炎是常见且严重的并发症。

内窥镜取出是大多数异物首选的一线方法[1]。目标是使用专业工具经口取出，包括线篮、鼠齿抓钳和大直径保护管，以防止额外的食管创伤[1]。可能需要创造性技术，基本原则是避免进一步的食管损伤同时保护内窥镜[1]。

当经口取出失败时，可将异物推入胃中，胃酸可能溶解骨骼，或通过胃切开术移除物体[1]。如果两种方法都不成功，食管切开术仍是一个选择，但由于食管愈合特性差，它具有较高的术后并发症率[1]。

医疗管理侧重于预防和治疗继发性并发症。质子泵抑制剂如奥美拉唑比H2受体拮抗剂提供更好的酸抑制[1]。硫糖铝作为粘膜保护剂，在受损组织上形成保护屏障[1]。移除后的内窥镜检查对于评估食管炎或穿孔至关重要。

穿孔患者需要积极的抗生素治疗，而那些有显著食管损伤的患者可能受益于胃造口管置入，用于营养支持和愈合期间的食管休息[2]。

### Sources

[1] Esophageal foreign bodies, esophagitis and strictures (Proceedings): https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings
[2] Interventional endoscopic techniques: Foreign bodies, stricture/dilation, peg/pej tube placement (Proceedings): https://www.dvm360.com/view/interventional-endoscopic-techniques-foreign-bodies-stricturedilation-pegpej-tube-placement-proceedi

## 并发症和预防

**即时并发症**
食管异物可引起几种即时危及生命的并发症[1]。颈段食管穿孔可能导致局部脓肿或皮下气肿，而胸段食管穿孔可导致胸膜炎、纵隔炎、脓胸、气胸或致命的主动脉食管瘘形成[8]。吸入性肺炎通常继发于反流，是受影响动物发病和死亡的主要原因[1]。

**延迟并发症**
食管狭窄形成是与食管异物相关的最常见的长期并发症[8]。狭窄通常在初始损伤后1-3周发展，但可能在4-6周后发生[1]。严重的食管炎可进展为食管坏死和纤维化[7]。患有洁齿咀嚼零食梗阻的动物面临更高风险，24%的病例发生狭窄形成，且死亡率更高[5]。

**预后因素**
预后因多种因素而有显著差异。无并发症的内窥镜取出具有良好的至优秀的预后[1]。然而，严重的食管损伤、穿孔或需要手术移除会使结果恶化[1]。在最近的研究中，87%的食管穿孔犬存活至出院[3]。梗阻持续时间、食管损伤程度和并发症存在情况都影响结果[1]。

**预防**
宠物主人应避免给予可能卡在食管中的骨骼、洁齿咀嚼零食和不适当的玩具[1]。在喂食和玩耍期间监督宠物可防止摄入异物。对反流或吞咽困难立即寻求兽医关注有助于确保早期诊断和治疗，降低并发症风险。

### Sources
[1] Diagnosing and treating esophageal diseases in dogs and cats: https://www.dvm360.com/view/diagnosing-and-treating-esophageal-diseases-dogs-and-cats-proceedings
[3] Likelihood and outcome of esophageal perforation secondary: https://avmajournals.avma.org/view/journals/javma/253/8/javma.253.8.1053.xml
[5] Esophageal foreign body obstruction caused by a dental chew: https://avmajournals.avma.org/view/journals/javma/232/7/javma.232.7.1021.xml
[7] Esophagitis and esophageal stricture: https://www.dvm360.com/view/esophagitis-and-esophageal-stricture-proceedings
[8] Esophageal Foreign Bodies in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophageal-foreign-bodies-in-small-animals
