# 犬猫晶状体异位

晶状体异位是指晶状体从正常位置发生移位，在伴侣动物中这是一种严重的眼科急症，若不及时治疗可迅速导致失明。该病主要影响中年梗犬品种，由遗传性基因突变引起，而猫通常在慢性炎症性疾病后继发晶状体移位。早期识别至关重要，因为前部晶状体脱位可在数小时内引起眼压立即升高和不可逆的眼部损伤。本报告探讨了在小动物兽医临床中成功管理这种威胁视力状况的遗传易感性、临床表现、诊断方法和治疗结果。

## 摘要

晶状体异位是一种需要立即兽医关注的复杂眼科疾病，在犬和猫中表现出不同的模式。梗犬品种中ADAMTS17突变的遗传易感性与猫继发性炎症原因形成鲜明对比，从根本上影响了治疗方法和结果。

| 方面 | 犬 | 猫 |
|------|------|------|
| 主要原因 | 遗传性（ADAMTS17突变） | 继发于慢性葡萄膜炎 |
| 品种易感性 | 梗犬、沙皮犬 | 无特定品种 |
| 治疗成功率 | 初始手术成功率90-95% | 药物管理效果更好 |
| 预后 | 因并发症而预后谨慎 | 治疗潜在原因后预后更佳 |

特征性的"无晶状体新月征"是关键的诊断指标，而使用甘露醇和碳酸酐酶抑制剂立即降低眼压为手术干预提供了关键的稳定性。现代超声乳化技术取得了极好的短期效果，但长期并发症包括继发性青光眼和视网膜脱离仍然是重大问题。在发生不可逆损伤之前早期转诊给兽医眼科医生是保存视力和实现最佳患者结果的最关键因素。

## 疾病概述和常见病原体

**晶状体异位**定义为晶状体从正常解剖位置发生移位，当正常悬吊晶状体的悬韧带完全或部分丧失时发生[1]。晶状体从睫状体平坦部附件处脱位，导致前部脱位（进入前房）、后部脱位（进入玻璃体腔）或半脱位（部分移位）[1]。

该病在犬中有明显的品种易感性，特别影响中年梗犬和沙皮犬[1]。原发性晶状体脱位与*ADAMTS17*基因的遗传突变相关，该突变导致遗传性悬韧带缺陷[1]。梗犬品种，尤其是杰克罗素梗犬，对这种遗传性疾病具有遗传易感性[2]。在几个品种中，遗传方式已被确定为常染色体隐性遗传[2]。

继发性晶状体脱位可由各种创伤性或病理过程引起。在犬中，常见原因包括过熟期白内障、慢性前葡萄膜炎、慢性青光眼和晶状体过大[1]。创伤性原因涉及眼球钝性创伤，产生压迫力导致悬韧带破裂[3]。在猫中，慢性前葡萄膜炎是晶状体脱位最常见的基础原因[1]。

虽然晶状体异位主要不是传染性疾病，但没有特定的病毒或细菌病原体直接导致该病。然而，传染性病原体可通过慢性葡萄膜炎间接导致继发性形式，随时间推移损害悬韧带。

### Sources
[1] Dislocation of the Lens in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/dislocation-of-the-lens-in-small-animals
[2] Lens disorders: Diagnosis and treatment (Proceedings): https://www.dvm360.com/view/lens-disorders-diagnosis-and-treatment-proceedings
[3] Selected lens diseases and cataract treatment (Proceedings): https://www.dvm360.com/view/selected-lens-diseases-and-cataract-treatment-proceedings

## 临床症状、体征和诊断方法

### 临床表现

晶状体异位根据晶状体移位位置表现出不同的临床症状[1]。前部晶状体脱位表现为眼压（IOP）升高、弥漫性角膜水肿、眼睑痉挛、流泪以及巩膜和结膜充血[2]。这些体征是由于玻璃体粘附于后晶状体囊导致的瞳孔阻滞或继发性虹膜角膜角闭合引起的[2]。

晶状体半脱位产生特征性的"无晶状体新月征"--瞳孔中晶状体缺失的新月形区域，由虹膜边缘和移位的晶状体赤道部界定[2]。虹膜颤动可能表明晶状体不稳定[9]。后部晶状体脱位通常表现为较不急性的体征，但可引起继发性青光眼和慢性前葡萄膜炎[2]。

### 品种特异性模式

原发性晶状体脱位常见于中年梗犬和沙皮犬，由ADAMTS17基因突变引起[2,5]。在猫中，晶状体脱位最常继发于慢性前葡萄膜炎，而非原发性疾病[1,2]。

### 诊断方法

临床检查侧重于眼压测量评估IOP，避免在移位的晶状体上直接测量以防止读数错误性升高[2]。当角膜水肿阻碍直接观察后部结构时，B超超声检查是必需的[2,6]。其他诊断检查包括眼底镜检查、视网膜电图和血压测量以确定潜在原因[6]。直接检查评估瞳孔光反射和眩光反射有助于确定视力潜力和手术候选资格[2]。

### Sources
[1] Understanding and managing cataracts and lens luxation in cats and dogs: https://www.dvm360.com/view/understanding-and-managing-cataracts-and-lens-luxation-in-cats-and-dogs
[2] Dislocation of the Lens in Small Animals - Emergency Medicine: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/dislocation-of-the-lens-in-small-animals
[3] Evaluation of ADAMTS17 in Chinese Shar-Pei: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.98.xml
[4] Retinal Detachment in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/retinal-detachment-in-small-animals
[5] Ophthalmic examinations should not be complicated or expensive: https://www.dvm360.com/view/ophthalmic-examinations-should-not-be-complicated-or-expensive

## 治疗选择和预防措施

### 药物管理

对于前部晶状体脱位，立即药物稳定化包括使用甘露醇（1-2 g/kg，静脉注射）缓慢给药降低眼压，联合局部或全身性碳酸酐酶抑制剂[1]。局部前列腺素类似物是禁忌的，因为它们通过引起强烈瞳孔缩小和进一步升高压力而加重病情[1]。

晶状体诱导性葡萄膜炎的药物管理需要局部和全身性抗炎治疗。非甾体抗炎药如局部氟比洛芬或双氯芬酸每日一至四次处方，必要时常联合局部皮质类固醇[2]。对于原发性晶状体不稳定或后部脱位的犬，每12小时使用地美溴铵可延迟前部晶状体脱位的发生[1]。

### 手术干预

当视力保存可能时，手术晶状体摘除是确定性治疗。对于前部脱位，如果眼睛保留视力潜力（通过眩光反射和同感瞳孔光反射评估），应立即进行囊内晶状体摘除术[1]。

现代超声乳化技术在白内障手术中达到90-95%的成功率。该手术使用小切口（约3mm）并植入可折叠人工晶状体[3]。对于脱位的晶状体，囊内晶状体摘除需要更长的角膜切口（160-180度），并可使用冷冻探针或晶状体镊摘除[3]。

### 术后护理

术后管理包括局部和全身性皮质类固醇、抗菌药物和抗青光眼药物。眼压监测至关重要，因为升高通常在术后3小时内发生[1]。长期并发症包括继发性青光眼、视网膜脱离和无法控制的前葡萄膜炎，需要持续监测[1]。

### 预防措施

早期转诊给兽医眼科医生可在并发症变得不可逆之前预防其发生[4]。物种差异存在：在犬中，晶状体脱位主要在梗犬中遗传，而在猫中则继发于慢性葡萄膜炎，需要识别和治疗潜在的炎症原因[4]。

### Sources

[1] Dislocation of the Lens in Small Animals - Emergency Medicine: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/dislocation-of-the-lens-in-small-animals
[2] Lens disorders: Diagnosis and treatment (Proceedings): https://www.dvm360.com/view/lens-disorders-diagnosis-and-treatment-proceedings
[3] Disease and surgery of the lens (Proceedings): https://www.dvm360.com/view/disease-and-surgery-lens-proceedings
[4] Understanding and managing cataracts and lens luxation in cats and dogs: https://www.dvm360.com/view/understanding-and-managing-cataracts-and-lens-luxation-in-cats-and-dogs

## 鉴别诊断和预后

### 鉴别诊断

晶状体异位必须与几种表现出相似临床症状的眼部疾病相鉴别。**白内障**具有视力损害症状，但通过晶状体混浊而非移位来区分[1]。老年动物的核硬化表现为晶状体混浊，但维持正常晶状体位置且通常不会显著影响视力[2]。

**青光眼**可能表现为相似的眼压升高和角膜水肿，特别是当继发于晶状体脱位时。然而，原发性青光眼缺乏特征性的无晶状体新月征和晶状体移位[1]。**前葡萄膜炎**可引起瞳孔缩小、结膜充血和不适，但没有晶状体位置变化[1]。

**创伤性眼球突出**可能在钝性创伤后与晶状体脱位同时发生，需要仔细检查以识别两种情况[1]。区分原发性和继发性晶状体脱位至关重要--原发性病例通常由于遗传性悬韧带缺陷影响中年梗犬，而继发性病例由慢性炎症、创伤或过熟期白内障引起[1]。

### 预后

晶状体异位的预后因多种因素而有显著差异。**前部晶状体脱位**由于相关的继发性青光眼和角膜并发症，预后比后部脱位更为谨慎[1]。

在犬中，**早期手术晶状体摘除成功率在头1-2年内为90-95%**[2]。然而，长期术后并发症包括继发性青光眼、视网膜脱离和无法控制的前葡萄膜炎很常见，因此预后谨慎[1]。**白内障手术总体成功率已提高到80-90%**，随着手术技术的进步[3]。

**猫通常有更好的药物管理效果**，因为脱位通常继发于慢性炎症而非原发性悬韧带缺陷[1]。早期识别和治疗潜在炎症原因显著改善结果[1]。

### Sources
[1] Dislocation of the Lens in Small Animals - Emergency Medicine and Critical Care - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/dislocation-of-the-lens-in-small-animals
[2] The Lens in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
[3] Lens disorders: Diagnosis and treatment (Proceedings): https://www.dvm360.com/view/lens-disorders-diagnosis-and-treatment-proceedings
