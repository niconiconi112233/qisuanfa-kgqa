# 伴侣动物中耳炎：综合临床指南

中耳炎，即包括鼓室泡和听小骨在内的中耳结构炎症，在小动物兽医临床实践中代表着一项重大的临床挑战。虽然不如外耳炎常见，但这种疾病通过不同的致病机制影响犬和猫--在犬中是源于慢性外耳疾病的上行感染，而在猫中则是下行性鼻咽感染。本报告为兽医从业者提供基于循证的指导，涵盖从初步诊断到治疗结果的完整临床谱。关键主题包括骑士查理王小猎犬的品种特异性易感性、先进的诊断影像学技术、假单胞菌生物膜引起的抗菌素耐药性挑战、手术干预方案，以及影响受影响患者长期神经系统预后的预后因素。

## 疾病概述与流行病学

中耳炎是中耳结构的炎症，包括鼓室泡、咽鼓管开口和听小骨 [1]。该疾病涉及鼓膜远端的结构，可以是单侧或双侧，影响所有年龄段的犬和猫 [1]。

从解剖学上看，猫的中耳被隔膜分隔，与犬相比，这会使治疗方法复杂化 [1]。鼓腔通过咽鼓管与口腔相连，使这些结构易受来自外耳道或咽部微生物的上行感染影响 [1]。

总体而言，中耳炎在兽医学中并不常见，作为就诊原因约占猫兽医就诊的5%，而犬则为15% [4]。在犬中，它最常见于慢性外耳炎的扩展，研究表明，超过一半的长期、复发性外耳炎症犬存在中耳炎 [1]。

该疾病在猫中比犬少见，尽管猫可能在呼吸道疾病后发生中耳炎或与炎性息肉相关 [1]。存在品种易感性，特别是骑士查理王小猎犬的原发性分泌性中耳炎（PSOM），通常在3-7岁时出现，无性别偏好 [1]。在其他短头颅小品种中也报道了原发性分泌性中耳炎 [1]。该疾病可进展为内耳炎，引起更严重的并发症，包括前庭功能障碍和永久性神经功能缺损 [1]。

### Sources

[1] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[2] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis

## 发病机制与常见病原体

中耳炎通过多种致病机制发展。在犬中最常见的途径涉及来自慢性外耳炎的上行感染，细菌通过破裂的鼓膜从外耳道扩散 [1]。相比之下，猫更常通过咽鼓管从鼻咽感染（包括疱疹病毒和杯状病毒等上呼吸道病原体）发生下行性感染而患上中耳炎 [2]。血源性传播很少见，通过血液循环到达中耳 [1]。

**假单胞菌**属和**葡萄球菌**属是小动物中的主要细菌病原体 [1]。**链球菌**属感染也会发生，特别是在马中 [1]。混合需氧和厌氧感染很常见，在晚期病例中高达25%存在厌氧生物 [3]。真菌原因虽然较少见，但可包括**马拉色菌**属 [3]。

**假单胞菌**感染由于生物膜形成而特别具有挑战性，生物膜保护细菌免受抗生素影响并导致治疗耐药性 [3]。鼓腔的假复层纤毛上皮在炎症期间经历增生，产生过多的粘液，捕获细菌并延续感染 [3]。这创造了一个循环，其中细菌蛋白酶和炎症细胞阻止鼓膜愈合 [3]。形成生物膜的细菌产生增强的抗菌素耐药性，使局部联合治疗对于取得成功治疗结果至关重要 [3]。

### Sources
[1] Otitis Media and Interna in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[2] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
[3] Diagnosis and management of otitis media (Proceedings): https://www.dvm360.com/view/diagnosis-and-management-otitis-media-proceedings

## 诊断方法

中耳炎的全面诊断需要结合临床检查、细胞学分析和先进影像学技术的系统方法。诊断的挑战在于准确区分外耳炎和中耳炎，因为临床表现常常重叠 [1]。

**耳镜检查**构成耳部评估的基石，需要从耳廓到鼓膜的系统可视化。视频耳镜与手持设备相比提供优越的放大和记录功能，对于识别微妙的鼓膜异常特别有价值 [1]。鼓膜可能表现为膨出、不透明、变色或破裂，由于中耳压力增加，松弛部特别容易膨出 [1]。

**细胞学分析**必须在每个病例中进行，理想情况下在水平-垂直耳道交界处采样。样本应在引入清洁剂之前收集 [1]。正常的细胞学检查结果包括犬每个高倍视野少于5个生物体，而异常发现包括吞噬细菌的炎症细胞，表明活动性感染 [2]。

**先进影像学**在临床检查受限时提供明确的诊断确认。CT和MRI在检测中耳受累方面比传统X线摄影具有更高的灵敏度 [6]。这些模态可以识别鼓室泡内的液体积聚、软组织增生和骨性变化。然而，在临床正常的犬中偶然发现鼓室泡内有液体，使解释复杂化 [6]。

**鼓膜切开术和培养**应在怀疑中耳炎时进行，特别是在有神经系统体征的慢性病例中 [6]。该程序需要全身麻醉和带套囊的气管插管以防止误吸 [1]。

### Sources

[1] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause

[2] Practical approach to diagnosing and managing ear disease in the dog (Proceedings): https://www.dvm360.com/view/practical-approach-diagnosing-and-managing-ear-disease-dog-proceedings

[6] Otitis Media and Interna in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

## 治疗策略与管理

中耳炎的医学管理需要结合全身和局部抗菌药物的综合方法。当中耳炎存在时，在全身麻醉下进行深度耳道冲洗是必不可少的 [1]。对于有增生性耳道、糜烂、溃疡或中耳受累的病例，需要全身性抗生素 [2]。氟喹诺酮类药物如马波沙星（4-5.5 mg/kg每日）或环丙沙星（30 mg/kg每日）是假单胞菌感染的首选药物 [2]。

鼓膜切开术兼具诊断和治疗目的，允许收集样本进行培养并缓解中耳压力 [3]。该程序包括在紧张部的后下象限做一个切口，然后用温的无菌盐水轻轻冲洗 [4]。这能够去除渗出物和碎屑，同时允许局部药物直接递送到中耳 [3]。

局部治疗利用高浓度的抗生素来克服耐药机制。含有恩诺沙星联合Tris-EDTA的产品非常有效，Tris-EDTA破坏细菌细胞膜以增强抗生素渗透 [1]。磺胺嘧啶银和替卡西林已被证明对耐药性假单胞菌病例有益 [2]。

治疗持续时间至关重要--慢性病例需要至少四周，可能延长至三个月或更长时间 [1]。全身性皮质类固醇（1-2 mg/kg泼尼松龙每日）对于管理炎症和耳道狭窄至关重要 [2]。

对于猫，腹侧鼓室泡骨切开术（VBO）通常用于中耳疾病治疗 [5]。当药物治疗失败时，通过全耳道切除术与鼓室泡骨切开术（TECA-BO）的手术干预可能是难治性病例所必需的 [6]。

某些药物存在耳毒性问题，特别是当鼓膜破裂时。安全选择包括氟喹诺酮类、青霉素类、头孢菌素类和水溶性地塞米松 [6]。通过细胞学和耳镜检查进行定期监测确保治疗效果并预防并发症。

### Sources
[1] Treatment of Pseudomonas otitis in the dog: https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[2] Otitis externa - a quick guide to management: https://www.dvm360.com/view/otitis-externa-quick-guide-management-proceedings
[3] Diagnosis and management of otitis media (Proceedings): https://www.dvm360.com/view/diagnosis-and-management-otitis-media-proceedings
[4] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
[5] Endoscopic evaluation of the feline tympanic bulla is feasible: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0331.xml
[6] Merck Veterinary Manual Otitis Media and Interna: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

查看提供的来源和现有章节内容，我需要纳入关于中耳炎易感因素的信息，这对于预防至关重要。当前内容写得很好，但可以从来源材料中添加关于品种易感性和风险因素的额外信息中受益。

## 预防、鉴别诊断和预后

**预防措施**

中耳炎的预防以适当的耳部卫生和易感因素的管理为中心 [1]。使用适当的溶液定期清洁耳朵有助于去除过敏原和碎屑，同时避免棉签等刺激物至关重要，特别是在猫中，这代表一个常见的易感原因 [1]。环境控制包括尽量减少水分暴露和保持适当通风 [2]。在外耳炎病例中早期干预可防止进展为中耳炎，因为高达80%的犬中耳炎病例由慢性外耳感染发展而来 [2]。

品种易感性意识很重要，因为患有狭窄耳道的沙皮犬、梗类犬和金毛寻回犬对慢性耳部疾病表现出更高的易感性 [9]。管理过敏、甲状腺功能减退和免疫缺陷等潜在疾病有助于预防继发性耳部并发症 [9]。

**鉴别诊断**

关键鉴别诊断包括炎性息肉，特别是在1-5岁的猫中，可能需要通过鼓室泡骨切开术手术切除 [5]。涉及颞骨岩部（骨肉瘤、纤维肉瘤、软骨肉瘤）的新生物必须与感染过程区分开来 [8]。异物和胆脂瘤可以模拟中耳炎的表现 [6]。在猫中，原发性分泌性中耳炎最常见于骑士查理王小猎犬，但在其他短头颅品种中也有报道 [7]。

**预后**

早期诊断和适当治疗可以使感染和临床症状完全缓解 [7]。然而，慢性病例即使在成功治疗后也可能发展出持续性神经功能缺损，包括头倾斜、面神经麻痹和听力损失 [7,8]。严重病例可能需要手术干预（全耳道切除术），特别是当存在多重耐药菌时 [7]。

### Sources
[1] Feline otitis (Proceedings): https://www.dvm360.com/view/feline-otitis-proceedings
[2] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[3] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[4] Managing otitis externa (Proceedings): https://www.dvm360.com/view/managing-otitis-externa-proceedings
[5] Approach to otitis, client education leads to success ...: https://www.dvm360.com/view/approach-otitis-client-education-leads-success-proceedings
[6] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/243/6/javma.243.6.775.xml
[7] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[8] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[9] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
