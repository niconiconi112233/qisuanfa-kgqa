# 伴侣动物的囊性子宫内膜增生

囊性子宫内膜增生（CEH）是一种影响未绝育母犬和母猫的重要生殖系统疾病，其特征是由于长期激素暴露导致的子宫内膜进行性病理变化。这种激素介导的疾病主要影响老年未绝育母犬，并构成可能危及生命的CEH-子宫蓄脓综合征的基础。对于兽医从业者而言，理解CEH至关重要，因为它影响生育能力，需要通过超声诊断及时识别，并需要在手术和药物治疗之间做出果断的治疗决策。本报告探讨了涉及孕激素诱导的子宫内膜变化的病理生理学、包括粗毛柯利犬和金毛寻回犬在内的品种易感性、强调超声检查结果的诊断方法，以及比较卵巢子宫切除术的良好预后与药物治疗的不同成功率和高复发风险的治疗结果。

## 疾病概述与病理生理学

囊性子宫内膜增生（CEH）是子宫内膜的一种进行性病理变化，其特征为子宫内膜腺体增生和扩大[1]。CEH代表了CEH-子宫蓄脓综合征中的主要病理损伤，其中子宫蓄脓是作为增生子宫内膜上的继发性细菌感染发生的[1]。

其发病机制主要与激素有关，由孕激素介导，并可能通过反复的激素暴露周期被雌激素加重[1,2]。雌激素通过增加孕激素受体来使子宫内膜做好准备，而孕激素则诱导子宫内膜腺体增生、扩大以及子宫内膜腺体因分泌物而扩张[1,2]。这创造了一个有利于细菌生长和感染的环境。

随着大多数未绝育母犬年龄增长，它们会发展为CEH，这是由于在间情期子宫内膜长期反复暴露于孕激素所致[2]。该疾病通常影响经历一次或多次未怀孕发情周期的老年或中年未绝育母犬[1]。研究表明，某些品种可能具有更高的易感性，包括粗毛柯利犬、罗威纳犬、迷你雪纳瑞犬、骑士查理王小猎犬、金毛寻回犬、伯尔尼山地犬和英国史宾格犬[2]。

该疾病与生育能力低下有关，并可能发展为子宫蓄脓，尽管并非所有病例都会进展到感染阶段[1]。母犬可能患有CEH但无临床症状，这使得早期检测具有挑战性[1]。

### Sources
[1] Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals
[2] Canine pyometra: Early recognition and diagnosis: https://www.dvm360.com/view/canine-pyometra-early-recognition-and-diagnosis

## 临床表现与诊断

囊性子宫内膜增生（CEH）的临床表现因疾病严重程度和宫颈开放状态而异。大多数患病动物表现为多饮、多尿、嗜睡和厌食[1]。如果宫颈保持开放，可能出现浆液血性至黏液脓性阴道分泌物，但由于爱干净的猫常在观察到之前就清理干净了分泌物[2]。宫颈闭锁的病例通常表现为腹部膨隆和更严重的全身性疾病[3]。

体格检查可能发现因子宫增大导致的腹部膨隆，但应避免用力触诊以防子宫破裂[3]。实验室检查结果通常包括中性粒细胞增多伴核左移或在严重病例中出现中性粒细胞减少、肝酶升高、氮质血症和高球蛋白血症[3,6]。

超声检查是首选的诊断方法，可显示子宫壁增厚、子宫内膜小囊肿和液体积聚[1,2]。其特征性超声表现显示"子宫壁增厚，子宫内膜内有小囊肿，宫腔内有少量液体"[1]。X光片可能显示子宫增大并伴有肠道前移位，但无法明确区分CEH与其他子宫疾病[3]。

宫颈开放病例的阴道细胞学检查通常显示大量退行性中性粒细胞和细菌，而宫颈闭锁病例可能仅反映正常发情周期的变化[3]。组织病理学检查提供确定性诊断，对于确认CEH严重程度和排除并发肿瘤仍然至关重要。

### Sources

[1] Bladder and reproductive ultrasonography: the good, bad and really ugly: https://www.dvm360.com/view/bladder-and-reproductive-ultrasonography-good-bad-and-really-ugly-proceedings
[2] Don't let the sun set on pyometra: https://www.dvm360.com/view/dont-let-sun-set-pyometra  
[3] Canine pyometra: Early recognition and diagnosis: https://www.dvm360.com/view/canine-pyometra-early-recognition-and-diagnosis
[4] Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals

## 治疗与管理

卵巢子宫切除术仍是囊性子宫内膜增生的首选治疗方法，兼具治愈和预防双重益处[5][7]。该手术消除了孕激素的来源并防止复发[1][2]。腹腔镜卵巢切除术具有减少手术时间、改善视野和减轻术后疼痛等优势[1][3]。然而，当存在子宫疾病时，卵巢切除术是禁忌的，因为CEH需要同时切除卵巢和子宫[2]。

对于具有繁殖价值且临床状况稳定的母犬，可考虑药物治疗[2][5][7]。治疗目标包括溶解黄体、放松宫颈和排空子宫内容物[2][7]。前列腺素（地诺前列素或氯前列烯醇）可诱导黄体退化和促进子宫收缩[2][5][7]。卡麦角林等多巴胺激动剂通过抑制催乳素提供协同溶黄体作用[2][5][7]。阿来司酮等孕激素受体拮抗剂可竞争性阻断孕激素的作用，但在美国的供应有限[2][7]。

药物治疗的成功率在40-90%之间，恢复通常需要多个疗程[2][5]。在一项研究中，153只狗中有98只在一个疗程后恢复，而55只需要两个疗程[2][5]。然而，在27个月内的复发率高达77%[2][5]。成功治疗的母犬应在治疗后首次发情时进行配种，并在实现繁殖目标后实施卵巢子宫切除术[2][5][7]。

手术治疗的预后极佳[4]。药物治疗具有更高的复发风险，需要仔细监测并最终进行卵巢子宫切除术[2][5][7]。

### Sources

[1] Female sterilization procedures: https://www.dvm360.com/view/female-sterilization-procedures
[2] Surgical and medical treatment of pyometra: https://www.dvm360.com/view/surgical-and-medical-treatment-pyometra
[3] Performing an ovariectomy in dogs and cats: https://www.dvm360.com/view/performing-ovariectomy-dogs-and-cats
[4] Findings and prognostic indicators of outcomes for bitches: https://avmajournals.avma.org/view/journals/javma/260/S2/javma.20.12.0713.xml
[5] Managing canine pyometra (Proceedings): https://www.dvm360.com/view/managing-canine-pyometra-proceedings
[6] is removal of the uterus necessary? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/239/11/javma.239.11.1409.xml
[7] Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals
