# 伴侣动物中的二尖瓣发育不良

二尖瓣发育不良是一种影响犬猫的重要先天性心脏畸形，涉及出生时即存在的二尖瓣复合体发育异常。与随时间发展的获得性二尖瓣疾病不同，这种情况源于瓣叶、腱索和乳头肌的发育异常，导致不同程度的二尖瓣反流和潜在的心力衰竭。

本综合兽医报告探讨了小动物临床实践中二尖瓣发育不良的临床表现、诊断方法和管理策略。分析涵盖了斗牛犬和德国牧羊犬等大型犬的品种易感性，探讨了超声心动图作为诊断金标准的作用，并评估了使用心脏药物的药物治疗和手术干预选择，为管理这种复杂先天性心脏疾病的兽医从业者提供了基本指导。

## 疾病概述

二尖瓣发育不良（又称二尖瓣发育不全）是一种出生时即存在的二尖瓣装置先天性畸形[1]。这种情况涉及二尖瓣结构的异常发育，包括瓣叶、腱索或乳头肌，导致瓣膜功能不全[1]。与随时间发展的获得性二尖瓣疾病不同，二尖瓣发育不良代表整个二尖瓣复合体的发育异常[2]。

犬先天性心脏病的患病率估计为0.68%[1]，而猫约为0.2-1%[2]。二尖瓣发育不良是猫常见的先天性心脏缺陷，在犬中则较为少见[6]。该病表现出明显的品种易感性，犬中最常受影响的品种包括斗牛犬、德国牧羊犬和大丹犬[1][6]。大型犬通常比小型犬更易感[1]。早期诊断很重要，因为某些缺陷可以在心力衰竭发展之前得到纠正[2]。

### Sources

[1] Congenital diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/congenital-diseases-dog-and-cat-proceedings
[2] Overview of Congenital and Inherited Anomalies of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/overview-of-congenital-and-inherited-anomalies-of-the-cardiovascular-system-in-animals
[6] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals

## 病理生理学和临床表现

二尖瓣发育不良涉及二尖瓣复合体的先天性畸形，包括瓣叶、腱索和乳头肌[1]。解剖异常包括瓣叶增厚、活动度降低伴杵状尖端，腱索缩短或融合，以及乳头肌直接插入瓣叶[1]。这些结构缺陷导致不同程度的二尖瓣功能不全，收缩期血液反流至左心房[6]。

病理生理级联反应始于畸形引起的左心腔容量超负荷[6]。严重的二尖瓣反流导致左心房和心室扩张，其严重程度决定腔室扩大程度和左侧充血性心力衰竭的风险[6]。严重病例随着左心房压力升高会发展为肺静脉充血和肺水肿[6]。

临床表现取决于缺陷严重程度。患有二尖瓣发育不良的犬通常表现为左心尖全收缩期至泛收缩期杂音，其强度与反流严重程度平行[1]。可在左心尖触及心前区震颤[6]。受影响的动物可能表现出左侧充血性心力衰竭的迹象，包括咳嗽、呼吸困难和呼吸窘迫[7,8]。大型犬，特别是斗牛犬、德国牧羊犬和大丹犬，表现出品种易感性[6]。在猫中，二尖瓣发育不良是一种常见的先天性心脏缺陷，具有相似的血液动力学后果[6]。

### Sources
[1] Murmurs in puppies and kittens (Proceedings): https://www.dvm360.com/view/murmurs-puppies-and-kittens-proceedings
[6] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals
[7] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[8] Congenital and Inherited Disorders of the Cardiovascular System in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/congenital-and-inherited-disorders-of-the-cardiovascular-system-in-dogs

## 诊断方法

二尖瓣发育不良的诊断需要综合多模式方法，将体格检查结果与专业心脏成像相结合。体格检查显示特征性表现，包括心脏杂音（通常为收缩期），在左心尖处最清晰，以及可能表明心室功能障碍的奔马律[1]。杂音的强度和性质可能随二尖瓣反流的严重程度而变化，响亮杂音（3-6级）通常与更严重的疾病相关[1]。

**超声心动图是诊断二尖瓣发育不良的金标准**[2]。这种成像方式提供瓣膜形态的明确评估，识别特征性畸形，包括增厚、缩短的腱索和异常的乳头肌位置。多普勒研究量化二尖瓣反流程度并评估左心房大小，后者作为关键的预后指标[2]。

**胸部放射摄影支持诊断过程**，通过评估心脏大小和检测充血性心力衰竭迹象[1]。椎体心脏评分（VHS）有助于量化心脏扩大，犬的正常值为9.7±0.5，猫为6.9-8.1[1]。在晚期病例中可能可见左心房扩大和肺静脉充血。

**心电图有助于识别心律失常**，这些心律失常通常与二尖瓣发育不良相关[3]。虽然心电图变化不具有特异性，但在显著心房扩大的病例中可能观察到宽P波和心室传导障碍。晚期病例可能表现出左心室肥大或继发于腔室重构的传导异常的证据[3]。

### Sources

[1] Back to basics: clinical cardiovascular exam and diagnostic testing (Proceedings): https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings

[2] Current strategies on diagnosis and treatment of feline cardiomyopathy (Proceedings): https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings

[3] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals

## 治疗选择

二尖瓣发育不良的药物治疗侧重于通过多模式方法控制充血性心力衰竭。主要治疗策略包括心脏药物，如利尿剂、ACE抑制剂和正性肌力药物[1]。

呋塞米（1-4 mg/kg，口服，每8-12小时一次）作为管理液体潴留和肺水肿的基石利尿剂治疗[1]。ACE抑制剂如贝那普利或依那普利（0.25-0.5 mg/kg，口服，每12-24小时一次）提供后负荷降低和心脏保护[1]。匹莫苯丹（0.25-0.3 mg/kg，口服，每8-12小时一次）既是正性肌力药物又是血管扩张剂，在减少心室负荷的同时改善心输出量[1]。

手术干预在可行的情况下仍然是明确的治疗选择。有经验的心脏外科医生可以在心肺分流下进行二尖瓣修复或置换，但这存在显著的死亡风险，仅限于中大型成年犬[1]。术后患者需要终身使用香豆素类抗凝药物治疗[1]。然而，犬的二尖瓣缺陷手术矫正与高成本和高死亡率相关[2]。

因充血性心力衰竭接受药物治疗的犬可以在极其谨慎的情况下安全麻醉，但应避免在未经治疗的CHF病例中使用麻醉[1]。在存在动态流出道梗阻的病例中可考虑使用β受体阻滞剂[1]。

长期监测方案包括定期超声心动图评估，以评估瓣膜功能障碍、左心房扩大和心室重构的进展。鉴于利尿剂治疗的肾毒性潜力，定期监测肾功能和电解质至关重要[1]。

### Sources
[1] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[2] Congenital and Inherited Disorders of the Cardiovascular System in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/congenital-and-inherited-disorders-of-the-cardiovascular-system-in-dogs

## 鉴别诊断和预后

### 鉴别诊断

二尖瓣发育不良必须与多种产生相似临床表现的先天性和获得性心脏疾病进行鉴别。最常见的鉴别诊断包括其他先天性瓣膜发育不良，特别是三尖瓣发育不良，其表现为右心尖收缩期杂音而非左侧杂音[1]。

室间隔缺损（VSD）可能模拟二尖瓣发育不良，通常产生在右心底部最响的全收缩期杂音，与二尖瓣发育不良的左心尖位置形成对比[2]。动脉导管未闭在左心底部呈现特征性的连续性"机器样"杂音和洪脉，可与二尖瓣发育不良区分[3]。

在老年犬中，获得性退行性二尖瓣疾病（黏液瘤性二尖瓣变性）产生相似的左心尖收缩期杂音，但发生在成年动物而非幼犬，超声心动图上可见进行性瓣膜增厚[4]。扩张型心肌病也可引起功能性二尖瓣反流，但通常影响较大、较老的犬，伴有腔室扩张而非原发性瓣膜畸形[5]。

### 预后和临床结局

二尖瓣发育不良的预后因疾病严重程度和解剖受累情况而有显著差异。轻微反流的轻度病例可能具有极好的长期预后，受影响的犬通过定期监测可正常生活[6]。

中重度二尖瓣发育不良预后谨慎，特别是当显著反流导致左心容量超负荷和最终充血性心力衰竭时。患有严重疾病的犬可能出现左侧心力衰竭迹象，包括呼吸窘迫、运动不耐受和继发于左心房扩大的咳嗽[7]。

预后因素包括瓣膜畸形程度、反流严重程度、是否合并其他心脏缺陷，以及是否发生肺动脉高压等继发并发症。早期使用适当的心脏药物（包括ACE抑制剂和利尿剂）干预可以改善有症状患者的生活质量，并可能减缓疾病进展[8]。

### Sources

[1] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[2] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[3] Congenital heart disease (Proceedings): https://www.dvm360.com/view/congenital-heart-disease-proceedings
[4] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[5] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[6] Congenital heart disease (Proceedings): https://www.dvm360.com/view/congenital-heart-disease-proceedings
[7] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[8] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
