# 伴侣动物中的肺源性心脏病

肺源性心脏病是兽医医学中一种严重的心血管疾病，其特征为由潜在肺部疾病引起的肺动脉高压继发的右心衰竭。本综合报告探讨了犬猫肺源性心脏病的病理生理学、诊断和管理，特别强调犬类患者的主要病因--心丝虫病。分析涵盖了包括超声心动图和心脏生物标志物在内的基本诊断方式，探索了以西地那非等磷酸二酯酶抑制剂为中心的治疗选择，并讨论了以心丝虫预防方案为重点的预防策略。理解肺源性心脏病对兽医从业者至关重要，因为在这种通常是致命的疾病中，早期识别和适当干预可以显著影响患者预后。

## 疾病概述

肺源性心脏病定义为由肺部疾病引起的肺动脉高压继发的右心衰竭的发展[1]。这种情况代表了右心室对慢性肺部疾病引起的肺动脉高压的一种适应机制[2]。在兽医医学中，肺源性心脏病最常见的原因是犬的心丝虫病[2]。

在小动物临床实践中，当肺部疾病导致肺血管阻力增加，引起肺动脉压力升高时，就会发生肺源性心脏病。正常平均肺动脉压力平均低于15 mmHg，但当超过此阈值时，会导致右心室压力超负荷[1]。

该疾病通过病理生理级联反应发展，其中慢性肺部疾病通过缺氧性肺血管收缩、肺小动脉外压迫和肺微血管破坏等机制导致肺动脉高压[2]。这导致右心室获得性压力超负荷，特征为向心性肥大和心腔扩张[2]。

伴侣动物的特定流行病学数据有限，尽管该疾病可影响犬和猫。该疾病在犬中的进展速度各不相同，但在猫中通常持续不到2年[3]。严重、持续的肺动脉高压可能导致右心室肥大、右心充盈压力增加，并最终发展为右侧充血性心力衰竭[3]。

### Sources
[1] Pulmonary vascular disease (Proceedings): https://www.dvm360.com/view/pulmonary-vascular-disease-proceedings
[2] The silent killer: pulmonary hypertension (Proceedings): https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[3] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/en-au/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals

## 常见病原体

伴侣动物的肺源性心脏病由各种引起慢性肺部疾病并继发右心衰竭的病原体引起。最重要的致病因子是**犬恶丝虫**（心丝虫），它在肺动脉中造成机械阻塞和炎症反应[1][2]。肺血管中的成虫心丝虫诱导动脉变化，阻碍血流，导致持续性肺动脉高压并最终发展为肺源性心脏病[2]。

**血管圆线虫**代表一种新出现的寄生虫病因，特别是在犬中。这种"法国心丝虫"引起犬肺血管圆线虫病，成虫寄居在右心和肺动脉中[3]。临床表现包括慢性感染中的肺动脉高压和肺源性心脏病，以及严重的凝血障碍[3]。

引起慢性呼吸道感染的**细菌病原体**可导致继发性肺源性心脏病。在患有肺炎的犬中，*支气管败血波氏菌*和*马链球菌兽瘟亚种*是主要病原体，而最常分离到的机会性革兰氏阴性需氧菌包括*大肠杆菌*、*多杀性巴氏杆菌*、*肺炎克雷伯菌*和*铜绿假单胞菌*[4]。支原体物种也可能导致慢性支气管肺炎病例[1][4]。

**病毒性呼吸道病原体**可能引发慢性气道炎症，进展为肺动脉高压。在猫中，各种病毒因子可触发支气管肺疾病，最终可能导致肺源性心脏病[1]。

环境因素包括吸入性刺激物、粉尘和气溶胶可引起慢性肺部炎症，导致肺动脉高压[1]。虽然不是传染性病原体，但这些因子通过持续的肺血管阻力触发导致肺源性心脏病的病理生理级联反应。

### Sources
[1] Bronchopulmonary disease in cats-is it really asthma?: https://www.dvm360.com/view/bronchopulmonary-disease-cats-it-really-asthma-proceedings
[2] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/en-au/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[3] The expanding universe of three parasites: https://www.dvm360.com/view/expanding-universe-three-parasites
[4] Managing pulmonary parenchymal diseases (Proceedings): https://www.dvm360.com/view/managing-pulmonary-parenchymal-diseases-proceedings

## 临床症状和体征

现有章节内容全面概述了犬猫肺源性心脏病的临床表现。在此基础上的额外资料中，出现了几种重要的临床模式。

在猫中，呼吸窘迫的表现与犬不同，最初通常表现为更细微的体征。患有继发于呼吸道疾病的肺源性心脏病的猫可能表现出呼吸音减弱，特别是腹侧，这通常表明胸腔积液[8]。与犬不同，猫很少以腹水作为右心衰竭的主要表现，而是以胸腔积液为主要表现[8]。

体温模式提供诊断线索，患有心脏病的猫通常表现为体温过低，这与原发性肺部疾病中常见的正常或升高体温形成对比[8]。心率超过200次/分钟通常与猫的心力衰竭相关，而主要患有呼吸道疾病的猫可能维持较慢的心率[8]。

患有肺源性心脏病的猫的体格检查发现可能包括颈静脉扩张，这可伴随任何病因的胸腔积液，不仅限于心脏病[8]。肺水肿和并发呼吸道疾病时都可能存在湿啰音，使鉴别诊断具有挑战性[8]。一些患有严重胸腔积液的猫可能偶尔因呼吸窘迫而出现上呼吸道阻塞的表现[8]。

临床症状的进展在个体动物之间差异显著，有些保持稳定的表现，而其他则经历需要立即干预的快速恶化[8]。

### Sources
[1] Pulmonary vascular disease (Proceedings): https://www.dvm360.com/view/pulmonary-vascular-disease-proceedings
[2] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[3] Managing laryngeal and tracheal problems (Proceedings): https://www.dvm360.com/view/managing-laryngeal-and-tracheal-problems-proceedings
[6] Is it really heart failure I'm treating? (Proceedings): https://www.dvm360.com/view/it-really-heart-failure-im-treating-proceedings
[7] Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-2
[8] Feline respiratory distress (Proceedings): https://www.dvm360.com/view/feline-respiratory-distress-proceedings

## 诊断方法

诊断犬的肺源性心脏病需要结合临床检查、实验室检测和先进成像模式的综合方法。体格检查可能揭示特征性发现，包括心脏杂音、第二心音分裂、异常肺音、腹水和发绀[1]。这些临床体征反映了肺压升高和右心功能障碍的血流动力学后果。

实验室评估应包括全血细胞计数、血清生化分析、心丝虫抗原检测和尿液分析，以识别潜在的全身性疾病[1]。心脏生物标志物在诊断中起着关键作用。患有肺动脉高压的犬的NT-proBNP浓度升高，并与疾病严重程度相关[1]。临床III级肺动脉高压犬的值显著高于仅患有呼吸道疾病的犬[1]。心脏肌钙蛋白I浓度在多个临床级别的肺动脉高压犬中也通常升高[1]。

超声心动图代表兽医医学中肺动脉高压的无创诊断金标准[1]。检查包括右心变化的主观评估和客观多普勒测量。使用改良伯努利方程测量三尖瓣反流最大速度提供收缩期肺动脉压力估计值[1]。正常收缩期肺动脉压力<25 mm Hg，轻度高血压为30-50 mm Hg，中度为50-80 mm Hg，重度为>80 mm Hg[1]。

胸部X线和心电图提供支持性但非特异性的发现[1][2]。右心导管插入术仍是金标准，但需要全身麻醉，对不稳定患者风险较高[1]。

### Sources

[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment

[2] Diagnosis of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/diagnosis-of-cardiovascular-disease-in-animals

## 治疗选择

肺源性心脏病的治疗侧重于处理潜在的肺部疾病和管理继发性右心衰竭。**磷酸二酯酶5（PDE5）抑制剂**是降低肺血管阻力的主要药物干预措施[1]。西地那非是最常用的药物，剂量为1-3 mg/kg口服，每8-12小时一次[1,3]。该药物通过抑制PDE5选择性靶向肺血管，导致血管舒张和肺动脉压力降低[3]。

**他达拉非**代表一种长效替代PDE5抑制剂，通常剂量为1 mg/kg口服，每12-24小时一次，尽管临床经验仍然有限[3]。**匹莫苯丹**可能对继发于左心衰竭的病例有益，通过其双重正性肌力和血管舒张作用[1]。

**氧疗**对低氧血症患者至关重要，因为补充氧气可以减少缺氧性肺血管收缩[2]。潜在肺部疾病的管理通常包括抗炎药物、支气管扩张剂或心丝虫治疗，取决于主要病因[2]。

**利尿剂**在右心衰竭发展时起着关键作用，呋塞米是管理腹水和胸腔积液的基石疗法[4,5]。然而，利尿剂必须谨慎使用，因为过度容量减少可能损害固定肺血管阻力患者的心输出量[2]。

**手术干预**很少指征，但可能包括适当情况下的心丝虫移除[2]。预后仍然谨慎，生存时间通常从几天到几个月不等，取决于疾病严重程度[2]。

### Sources
[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[2] The silent killer: pulmonary hypertension (Proceedings): https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[3] Systemic and Pulmonary Hypertension in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/systemic-and-pulmonary-hypertension-in-dogs-and-cats
[4] Diuretics for Use in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/diuretics-for-use-in-animals
[5] Emergency management of congestive heart failure: https://www.dvm360.com/view/emergency-management-congestive-heart-failure

## 预防措施

预防伴侣动物的肺源性心脏病集中于控制导致肺动脉高压和右心疾病的潜在条件。最关键的预防措施是心丝虫预防，因为心丝虫预防药的广泛使用已显著降低了肺动脉高压的频率[1]。

在流行地区的所有犬猫都应每月持续给予心丝虫预防药，因为心丝虫病仍然是兽医医学中最常见的肺源性心脏病原因[2]。全年预防至关重要，即使是室内猫，因为它们仍可能接触到受感染的蚊子。

环境管理在预防可进展为肺动脉高压的呼吸道疾病中起着关键作用。宠物主人应尽量减少接触气道刺激物，包括粉尘、气溶胶、二手烟、香水和地毯清洁剂[6]。对于患有支气管肺疾病的猫，避免强制空气供暖系统并确保适当通风有助于减少呼吸道触发因素。

早期检测策略包括定期监测具有易感条件的宠物，如慢性呼吸道疾病、先天性心脏缺陷或全身性高血压[3]。对高危患者进行常规超声心动图检查可以在临床症状出现前识别右心变化的早期迹象。

管理易感条件同样重要。这包括使用适当药物控制全身性高血压，治疗慢性支气管炎或哮喘以防止进展为慢性阻塞性肺疾病，以及及时处理任何潜在感染[5][7]。定期监测高危品种并在出现呼吸道体征时早期干预可以防止进展为不可逆的肺血管变化。

### Sources
[1] Severe pulmonary hypertension and cardiovascular sequelae in dogs: https://www.dvm360.com/view/severe-pulmonary-hypertension-and-cardiovascular-sequelae-dogs
[2] The silent killer: pulmonary hypertension (Proceedings): https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[3] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[4] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[5] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[6] Bronchopulmonary disease in cats-is it really asthma? (Proceedings): https://www.dvm360.com/view/bronchopulmonary-disease-cats-it-really-asthma-proceedings
[7] Managing pulmonary parenchymal diseases (Proceedings): https://www.dvm360.com/view/managing-pulmonary-parenchymal-diseases-proceedings

## 鉴别诊断

肺源性心脏病需要与几种可模拟右心功能障碍的疾病进行仔细鉴别。原发性肺动脉高压表现为没有可识别的潜在肺部疾病，特征为肺动脉压力孤立性升高[1]。这种情况通常影响小型老年雌性犬，并表现出相似的临床体征，包括呼吸困难、运动不耐受和晕厥[2]。

继发性肺动脉高压的左心疾病代表一个主要鉴别诊断，特别是由严重二尖瓣疾病或扩张型心肌病引起的毛细血管后肺动脉高压[2]。在这些情况下，肺动脉压力因左心房压力升高而被动增加，需要超声心动图评估以区分原发性右心病理[3]。

肺血栓栓塞必须与肺源性心脏病区分，因为两种情况都可引起急性呼吸窘迫和右心功能障碍[2,4]。血栓栓塞性疾病通常表现为在具有易感条件（如心丝虫病、肾上腺皮质功能亢进或免疫介导性溶血性贫血）的患者中突发呼吸困难[4]。

右心功能障碍的其他原因包括心包疾病伴心脏压塞、三尖瓣功能不全和先天性心脏缺陷，如肺动脉狭窄或法洛四联症[1,3]。鉴别因素包括超声心动图发现显示特定的瓣膜异常、心包积液或先天性畸形，而不是肺源性心脏病特征的肺血管变化。

### Sources

[1] What's wrong with the ticker?: https://www.dvm360.com/view/whats-wrong-with-ticker-proceedings
[2] The silent killer: pulmonary hypertension: https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[3] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[4] Pulmonary vascular disease: https://www.dvm360.com/view/pulmonary-vascular-disease-proceedings

## 预后

犬猫肺源性心脏病的预后通常较差到极差，根据潜在原因和严重程度有显著差异[1]。生存时间通常较短，从几天到几个月不等，大多数患有明显肺源性心脏病和呼吸困难的犬存活时间少于6个月[1]。报告的生存时间从3到734天不等，尽管这种广泛变化反映了研究中疾病严重程度的差异[1]。

几个因素对预后有重要影响。潜在原因起着主要作用--心丝虫病，历史上犬中最常见的原因，可能通过使用美拉索明和抗炎治疗的适当治疗而改善[1]。然而，由其他原因引起的严重肺动脉高压通常预后更差。

高级功能级别代表负面预后指标，以及高右心房压力和严重右心室功能障碍[2]。西地那非疗法的引入在一定程度上改善了结果，平均发表生存时间增加到91天，一些患者存活近两年[2]。治疗反应显著影响预后--对治疗反应不佳的患者通常结果更差。

右心衰竭的发展、严重呼吸困难的存在和升高的NT-proBNP值是额外的负面预后因素[2]。在西地那非可用之前，患有肺动脉高压的犬预后极差，许多在诊断后仅存活几天[2]。在患有继发于心肌病的肺动脉高压的猫中，预后同样谨慎，右心衰竭、心律失常或血栓栓塞的并发症进一步恶化结果[3]。

### Sources
[1] The silent killer: pulmonary hypertension (Proceedings): https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[2] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[3] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
