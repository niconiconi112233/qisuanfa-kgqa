# 犬猫窦性心动过缓

窦性心动过缓是小动物兽医实践中一种重要的心脏传导异常，其特征为心率不适宜地缓慢，可能损害动物的健康和生活质量。这种疾病影响犬和猫，具有物种特异性的阈值和临床表现，需要仔细的诊断评估和管理。

本综合报告探讨了伴侣动物窦性心动过缓的病理生理学、临床表现和治疗方法。关键主题包括迷你雪纳瑞犬和可卡犬的品种易感性、迷走神经张力和全身性疾病在心动过缓发展中的作用、包括心电图解读和阿托品激发试验在内的诊断技术，以及从抗胆碱能药物治疗到对难治性病例进行起搏器植入的治疗方法。

## 疾病概述

窦性心动过缓被定义为以低于特定物种和临床情况预期的速率发生的规律窦性心律[1]。在健康犬中，正常心率变化很大，从睡眠时的十几次到最大运动时的≥250次/分钟(bpm)[1]。对于猫来说，健康但受应激的个体在检查室静息时心率可达240 bpm，而相对心动过缓(<160 bpm)被认为是患病猫最常见的心律紊乱，通常伴有低温，这是一个不祥的征兆[2]。

这种情况代表一种生理异常，即窦房结相对于动物的代谢需求和应激水平以不适宜的缓慢速率放电。正常心率参数在物种间差异显著，犬在安静休息时通常维持40-90 bpm的速率，尽管这在兽医诊所环境中的警觉犬中是不适宜地缓慢[2]。

从流行病学角度看，窦性心动过缓在某些情况和患者群体中发生得更频繁。它可能出现在患有影响呼吸系统、神经系统、眼部、胃肠道或泌尿系统的全身性疾病的动物中，这是由于迷走神经张力增加[1]。这种情况在老年犬中特别显著，尤其是迷你雪纳瑞犬和可卡犬，可能与病态窦房结综合征相关[1]。患有三度房室传导阻滞的犬心率在30-60 bpm之间很常见，而猫的逸搏心率往往更快(100-110 bpm)[3]。

### Sources
[1] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[2] Cardiopulmonary exam: Is this patient OK? (Proceedings): https://www.dvm360.com/view/cardiopulmonary-exam-patient-ok-proceedings
[3] The pulse on pacemakers: https://www.dvm360.com/view/pulse-pacemakers

## 常见病原体

窦性心动过缓本身通常不是由直接传染性病原体引起的，因为它是一种以心率缓慢为特征的心律紊乱。然而，全身性感染可能通过多种机制间接导致窦性心动过缓。

脓毒症是导致伴侣动物心动过缓最重要的传染性原因。脓毒症被定义为对已证实的感染的全身性反应，当动物除了感染外还存在全身性炎症反应综合征(SIRS)时发生[2]。其病理生理学涉及暴露于革兰氏阴性细菌的内毒素或革兰氏阳性细菌的脂磷壁酸，这些物质激活可能影响心脏传导的炎症级联反应。

在患有脓毒症的猫中，心动过缓特别常见，是一个令人担忧的发现。与通常在脓毒症期间发展为心动过速的犬不同，猫在存在休克时倾向于变得心动过缓，使心动过缓成为猫SIRS标准的一个组成部分[2]。

感染性心内膜炎可导致包括心动过缓在内的心脏传导异常。从犬和猫中最常分离出的细菌包括链球菌属、葡萄球菌属、克雷伯氏菌属和大肠杆菌[3]。巴尔通体也被认为是犬主动脉瓣感染性心内膜炎的一个原因[3]。此外，驱虫治疗中的双甲脒中毒可导致心动过缓、嗜睡、厌食、呕吐和过度流涎[4]。

当犬猫的呼吸道防御机制被犬瘟热、副流感病毒或犬2型腺病毒等主要病毒病原体损害时，继发性细菌感染可能使病毒性呼吸道疾病复杂化[5]。

### Sources

[1] Glossary: https://www.merckvetmanual.com/resourcespages/glossary
[2] Management of septic peritonitis: more than surgery: https://www.dvm360.com/view/management-septic-peritonitis-more-surgery-proceedings
[3] Infectious Endocarditis in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats
[4] The mighty mites of companion animals: https://www.dvm360.com/view/mighty-mites-companion-animals-proceedings
[5] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats

## 临床症状和体征

窦性心动过缓通常表现为与心输出量不足和组织灌注不良相关的临床症状。运动不耐受、虚弱和虚脱是有症状动物最常见的就诊主诉[1]。在严重情况下，当心率显著低于正常阈值时可能发生晕厥。

体格检查发现包括心动过缓，心率低于物种特异性正常范围：小型犬低于80 bpm，中大型犬低于70 bpm，巨型犬低于60 bpm，猫低于120 bpm[1]。心律通常保持规律，心电图上P波形态和PR间期正常。

**品种特异性模式**有充分记录，迷你雪纳瑞犬和可卡犬对病态窦房结综合征表现出特殊易感性，这通常表现为窦性心动过缓[1]。这些品种可能从简单的窦性心动过缓发展为更复杂的心律失常，包括窦性停搏和房室传导阻滞。

许多患有窦性心动过缓的动物保持无症状，特别是当这种情况是由休息或镇静期间的高迷走神经张力引起时[1]。然而，潜在原因如低温、甲状腺功能减退或颅内压升高可能产生那些疾病特有的额外临床症状[5]。与其他心动过缓心律失常的关键区别特征是心律保持窦性起源，通过心电图上每个QRS复合波前有正常P波证明。

### Sources
[1] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
[2] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[3] Diagnosis of Heart Disease in Animals: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals

## 诊断方法

准确诊断窦性心动过缓需要结合心电图分析、临床评估和诊断测试的系统方法[1]。心电图(ECG)作为主要诊断工具，通常以25-50 mm/秒的纸速和标准校准记录[2]。心电图解读遵循有条理的顺序：计算心率、评估心律规律性、评估QRS形态和检查P波特征[2]。

当心率低于物种特异性阈值（小型犬<80 bpm，中大型犬<70 bpm，巨型犬<60 bpm，猫<120 bpm）并维持窦性心律时，确诊窦性心动过缓[1]。心电图显示每个QRS复合波前有正常P波形态，间隔一致，这将其与其他心动过缓心律失常区分开来[2]。

先进的诊断测试包括24-48小时动态心电图监测，对检测间歇性心律失常和量化严重程度特别有价值[3]。阿托品激发试验(0.04 mg/kg皮下注射)有助于区分高迷走神经张力和内在性窦房结功能障碍[1]。具有正常迷走神经反应的犬在阿托品后显示窦性心动过速>140 bpm，而患有病态窦房结综合征的犬显示次优增加<130 bpm[1]。

实验室评估应包括全血细胞计数、血清生化、电解质评估和甲状腺功能测试，以识别潜在的全身性原因[4]。超声心动图排除结构性心脏病，而胸部X线摄影可能显示心脏扩大或并存疾病。

### Sources
[1] Get with the beat! Analysis and treatment of cardiac: https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
[2] Reading ECGs in veterinary patients: an introduction: https://www.dvm360.com/view/reading-ecgs-in-veterinary-patients-an-introduction
[3] The indications and technique for continuous ambulatory: https://www.dvm360.com/view/indications-and-technique-continuous-ambulatory-electrocardiographic-recording-dogs
[4] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats

## 治疗选择

犬猫窦性心动过缓需要基于潜在原因和临床严重程度的目标治疗方法。药物干预代表有症状患者的一线治疗。

**阿托品**作为主要抗胆碱能药物，以0.04 mg/kg静脉、肌肉或皮下注射用于中度病例[1]。对于窦性心律是主要问题的轻度心动过缓，较低剂量的阿托品0.02-0.04 mg/kg可能更合适，因为较高剂量有诱发心动过速或心室颤动的风险[3]。当阿托品未能恢复足够心率时，可使用**异丙肾上腺素**，特别是当心电图显示房室传导阻滞时[3]。

**拟交感神经药物**提供替代性变时性支持。特布他林(0.2 mg/kg口服，每8-12小时)和缓释茶碱(10 mg/kg，每12小时)为慢性病例提供口服管理选择[2][4]。丙胺太林溴化物(0.25-0.5 mg/kg，每8-12小时)提供额外的副交感神经阻断作用[4]。

**非药物管理**专注于解决潜在原因。低温患者需要逐渐复温方案，而药物性心动过缓患者则在临床上适当时受益于药物剂量调整或停用[5]。

**起搏器植入**当药物治疗未能控制症状性心动过缓或患者发展为完全性心脏传导阻滞时变得必要[2]。这种干预对患有三度AV传导阻滞的犬特别重要，无论临床症状如何，都存在猝死风险。

**护理考虑**包括连续心脏监测、维持正常体温和确保充分液体平衡，同时避免可能损害心脏功能的容量超负荷。

### Sources
[1] Cardiopulmonary-cerebral resuscitation (Proceedings): https://www.dvm360.com/view/cardiopulmonary-cerebral-resuscitation-proceedings
[2] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings
[3] Cardiovascular Medications (Toxicity) - Toxicology: https://www.merckvetmanual.com/toxicology/toxicities-from-human-drugs/cardiovascular-medications-toxicity
[4] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[5] Anesthetic monitoring savvy: https://www.dvm360.com/view/anesthetic-monitoring-savvy

## 预防措施

预防窦性心动过缓主要侧重于管理潜在的易感条件，而不是特定的疫苗接种方案。犬猫的大多数窦性心动过缓病例是由高迷走神经张力、镇静、低温或潜在窦房结疾病引起的[1]。

环境控制在预防中起着至关重要的作用。维持适当的体温至关重要，因为低温常导致心动过缓[3]。兽医团队应在麻醉和恢复期间实施复温方案，以防止温度相关的心律紊乱[2]。

监测方案应包括老年患者和具有易感条件患者的定期心脏评估。定期筛查病态窦房结综合征在迷你雪纳瑞犬和可卡犬中特别重要，这些品种具有已知易感性[3]。常规血压监测有助于识别有心血管并发症风险的患者[4]。

客户教育应强调管理易致心动过缓的潜在疾病的重要性。这包括适当治疗甲状腺功能减退、呼吸系统疾病和可能增加迷走神经张力的神经系统疾病[3]。应告知主人认识临床症状，如运动不耐受、虚弱或虚脱，这些可能表明需要兽医注意的心律紊乱。

### Sources
[1] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings
[2] Anesthetic management of small animals with preexisting cardiac conditions (Proceedings): https://www.dvm360.com/view/anesthetic-management-small-animals-with-preexisting-cardiac-conditions-proceedings
[3] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
[4] Management of systemic hypertension in dogs and cats: https://www.dvm360.com/view/management-of-systemic-hypertension-in-dogs-and-cats

## 鉴别诊断

窦性心动过缓必须与其他具有相似临床表现的心动过缓心律失常和传导异常相鉴别[1]。最重要的鉴别诊断包括病态窦房结综合征、房室传导阻滞和心房静止。

**病态窦房结综合征(SSS)**的特征是窦性停搏（停顿>2×RR间期），常伴有窦性心动过缓、窦性心律不齐和房室传导阻滞[1]。阿托品激发试验(0.04 mg/kg皮下注射)有助于区分SSS与高迷走神经张力 - 正常犬发展为规律性窦性心动过速>140 bpm，而SSS患者显示次优反应(<130 bpm)并伴有持续性停搏[1][6]。

**二度房室传导阻滞**表现为偶尔的未下传P波，而**三度房室传导阻滞**显示完全性房室分离，心房和心室节律独立[3]。与窦性心动过缓不同，这些传导阻滞维持正常P波形态，但显示心房和心室之间的传导异常。

**心房静止**表现为P波消失和交界性逸搏心律（犬40-65 bpm），由高钾血症（可逆性）或心房肌病（永久性）引起[3]。这种情况需要立即进行电解质评估，当由肌病引起时预后不良。

关键鉴别因素包括P波存在和形态、对阿托品测试的反应以及相关的心电图异常[1][3]。心电图仍然是区分这些传导紊乱的确定性诊断工具[1]。

### Sources

[1] Merck Veterinary Manual Diagnosis of Cardiovascular Disease in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/diagnosis-of-cardiovascular-disease-in-animals

[2] Merck Veterinary Manual Heart Disease: Conduction Abnormalities in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats

[3] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings

## 预后

犬猫窦性心动过缓的预后因潜在原因和临床表现而异。窦性心动过缓很少导致血流动力学损害，但偶尔可能引起与心输出量减少相关的晕厥[1]。

对于需要治疗的有症状病例，在适当管理下前景通常良好。有症状犬的治疗可能包括抗胆碱能药物（阿托品）或对药物治疗无反应时的手术起搏器植入[1]。起搏器植入在适当编程和维护的情况下提供优异的长期结果[2]。

长期预后主要取决于心动过缓心律失常的病因，病态窦房结综合征和无其他结构性疾病的房室传导阻滞预后最佳[2]。根据最近的兽医文献，适当治疗病例的长期预后"高度有利"[3]。然而，与心房肌肉疾病相关的持续性心房静止患者预后最差[2]。

当窦性心动过缓由可逆原因如高迷走神经张力、低温或某些药物引起时，预后最有利。在这些情况下，解决潜在状况通常可解决心动过缓，预期完全恢复。

当窦性心动过缓与进行性窦房结功能障碍或病态窦房结综合征相关时，通常需要永久性起搏器治疗。然而，在系统性能良好的情况下，这提供了优异的长期结果[2]。

物种间对心动过缓心律失常的耐受性存在差异。猫通常比犬更能耐受缓慢心率，通常在较低心率下维持足够的心输出量。直接归因于单纯性窦性心动过缓的总死亡率仍然很低，特别是当潜在原因被识别并适当管理时。

### Sources

[1] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings

[2] ECG reading session-cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/ecg-reading-session-cardiac-arrhythmias-proceedings

[3] Get with the beat! Analysis and treatment of cardiac arrhythmias (Proceedings): https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
