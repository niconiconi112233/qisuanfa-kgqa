# 伴侣动物肾上腺皮质功能减退症

肾上腺皮质功能减退症，通常称为阿狄森氏病，是小动物临床中一种兽医必须识别并迅速治疗的关键内分泌急症。本综合报告探讨了犬猫肾上腺皮质功能不全的多方面特性，包括其免疫介导的发病机制、从模糊的慢性体征到危及生命的危象的多样化临床表现，以及使其获得"伟大模仿者"绰号的诊断挑战。分析涵盖了基于证据的诊断方法，包括ACTH刺激试验、使用激素替代疗法的急诊和长期治疗方案，以及通过适当管理可获得的良好预后，为临床医生提供了管理这种复杂但高度可治疗疾病的基本知识。

## 总结

伴侣动物肾上腺皮质功能减退症呈现复杂的诊断和治疗挑战，但若得到适当管理，预后极佳。该病主要影响青年至中年雌性犬，通过免疫介导的肾上腺破坏引起，在贵宾犬和新斯科舍诱鸭寻回犬中有明显的品种易感性。临床表现差异很大，从慢性、模糊的胃肠道体征到急性心血管衰竭，特征性低钠血症和高钾血症仅存在于70-80%的病例中。

诊断金标准仍然是ACTH刺激试验，但基础皮质醇>2 mcg/dL可有效排除该病。急诊管理侧重于使用生理盐水进行积极的静脉输液治疗，而长期治疗需要使用DOCP或氟氢可的松进行盐皮质激素替代，并使用泼尼松进行糖皮质激素补充。

| 治疗阶段 | 主要干预措施 | 预期结果 |
|---|---|---|
| 急诊 | 静脉输液 + 地塞米松 | 24-48小时内快速稳定 |
| 维持 | DOCP + 泼尼松 | 通过适当监测获得正常预期寿命 |

通过适当的激素替代治疗，患者的2年生存率达到76%，并保持极好的生活质量，使得早期识别和及时治疗对于在这种高度可控的内分泌疾病中获得最佳结果至关重要。

## 疾病概述

**定义**

肾上腺皮质功能减退症，通常称为阿狄森病，是一种以肾上腺皮质激素分泌不足为特征的内分泌疾病[1]。该病症源于原发性肾上腺皮质衰竭，影响糖皮质激素和盐皮质激素的产生，或源于垂体ACTH分泌不足导致的继发性肾上腺皮质功能不全[1]。

**流行病学背景**

肾上腺皮质功能减退症在犬中最常见，通常在青年至中年成年期发病，尽管报告的年龄范围很广[1]。雌性比雄性更常见，研究表明70%的确诊病例为雌性[3]。该病可影响任何品种，但杂交犬诊断最频繁[1]。几个品种表现出过度代表性，包括新斯科舍诱鸭寻回犬（影响1.4%的人口）、贵宾犬（在一项研究中8.6%受影响）、大丹犬、西部高地白梗、古代英国牧羊犬和葡萄牙水犬[1][3]。在贵宾犬和新斯科舍诱鸭寻回犬等某些品种中，该病似乎以常染色体隐性性状遗传[3]。肾上腺皮质功能减退症在猫和马中罕有报道[1]。

### Sources

[1] Merck Veterinary Manual Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals

[2] DVM 360 Canine hypoadrenocorticism: managing difficult cases: https://www.dvm360.com/view/canine-hypoadrenocorticism-managing-difficult-cases-proceedings

[3] DVM 360 Canine hypoadrenocorticism (Proceedings): https://www.dv360.com/view/canine-hypoadrenocorticism-proceedings-1

## 常见病原体

肾上腺皮质功能减退症主要由非传染性原因引起，而非传统的病毒或细菌病原体[1]。最常见的病因是免疫介导的肾上腺破坏，在大多数病例中都被怀疑[1][2]。

**主要原因：**
免疫介导的肾上腺皮质衰竭代表主要原因，通常与其他自身免疫性内分泌疾病如甲状腺功能减退症、糖尿病和甲状旁腺功能减退症同时发生[1]。肉芽肿性破坏可由炎症性疾病引起，而出血性梗死和肾上腺坏死代表其他非传染性原因[1][2]。

**肿瘤浸润：**
转移性肿瘤可浸润肾上腺，导致皮质组织破坏[2]。原发性肾上腺肿瘤虽然罕见，但也可损害正常的肾上腺皮质功能。

**医源性原因：**
药物诱导的肾上腺皮质功能减退症代表一个重要类别。米托坦导致永久性肾上腺破坏，而曲洛司坦和酮康唑产生可逆性肾上腺抑制[1]。外源性糖皮质激素给药通过垂体ACTH抑制导致继发性肾上腺皮质功能减退，长效缓释制剂引起最持久的影响[1][2]。

**继发性原因：**
由肿瘤、炎症或创伤引起的垂体功能障碍可通过ACTH缺乏导致继发性肾上腺皮质功能减退症[1][2]。在研究环境中已证明实验性疫苗诱导的抗ACTH抗体产生，但这仍限于实验模型[3]。特发性ACTH缺乏也会发生，但很少见。

### Sources
[1] Testing for Addison's disease: https://www.dvm360.com/view/testing-addisons-disease
[2] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[3] Inoculation of dogs with a recombinant ACTH vaccine: https://avmajournals.avma.org/view/journals/ajvr/74/12/ajvr.74.12.1499.xml

## 临床症状和体征

肾上腺皮质功能减退症的临床表现差异很大，从慢性、模糊的体征到急性危象。胃肠道症状是最常见的表现，包括厌食、体重减轻、呕吐和腹泻[1]。嗜睡、虚弱和抑郁经常与多尿和多饮一起观察到[2][3]。这些体征通常随时间波动，经常通过输液治疗或减压干预暂时改善[1][2]。

不太常见但严重的表现包括急性胃肠道出血、低血糖或电解质紊乱引起的癫痫发作以及心血管衰竭[1][2]。体格检查可能显示脱水、心动过缓、脉搏微弱、毛细血管再充盈时间减少和低血容量休克体征[1]。

**电解质异常**是典型发现，约70-80%的病例存在低钠血症和高钾血症[1][2]。然而，24-32%的犬缺乏这些特征性电解质变化，特别是那些患有非典型或继发性肾上腺皮质功能减退症的犬[1][3]。

**品种易感性**存在于贵宾犬、古代英国牧羊犬、葡萄牙水犬和新斯科舍诱鸭寻回犬中，该病似乎以常染色体隐性性状遗传[1]。70%受影响的犬是雌性，大多数是青年至中年（平均年龄4-5岁）[1]。

### Sources

[1] Canine hypoadrenocorticism: managing difficult cases: https://www.dvm360.com/view/canine-hypoadrenocorticism-managing-difficult-cases-proceedings
[2] Canine hypoadrenocorticism (Proceedings): https://www.dvm360.com/view/canine-hypoadrenocorticism-proceedings
[3] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals

## 诊断方法

肾上腺皮质功能减退症的明确诊断需要ACTH刺激试验，因为临床症状通常模糊且非特异性[1]。初始筛查从基础皮质醇测量开始 - 水平>2 mcg/dL可有效排除肾上腺皮质功能减退症，具有100%的阴性预测值[1,2]。然而，仅基础皮质醇无法确认诊断。

ACTH刺激试验使用合成ACTH（cosyntropin）5 mcg/kg静脉注射，在给药前和一小时后测量皮质醇[1]。肾上腺皮质功能减退症的犬显示最小的皮质醇反应，通常ACTH前和后值均<2 mcg/dL[1,3]。

支持性实验室检查结果包括特征性电解质异常（低钠血症、高钾血症，钠钾比<27）、缺乏应激白细胞象、轻度非再生性贫血和氮质血症[1,2]。然而，24-32%的犬缺乏典型的电解质变化，特别是那些仅影响糖皮质激素产生的非典型疾病犬[2]。

影像学检查可能显示心影缩小、超声显示小肾上腺和低血容量体征[2]。高钾血症引起的ECG变化包括T波高尖和QRS波增宽[2]。内源性ACTH测量有助于在电解质正常的犬中区分原发性（ACTH升高）和继发性肾上腺皮质功能减退症（ACTH正常/低）[2]。

### Sources

[1] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals

[2] Testing for Addison's disease: https://www.dvm360.com/view/testing-addisons-disease

[3] Hypoadrenocorticism in the emergency setting: https://www.dvm360.com/view/hypoadrenocorticism-in-the-emergency-setting

## 治疗选择

肾上腺皮质功能减退症（阿狄森危象）的急诊管理需要立即、积极的干预。最重要的治疗组成部分是使用生理盐水进行静脉输液治疗（第一小时40-80 mL/kg），这可纠正低血容量、促进钾排泄并解决肾前性氮质血症[1][2]。仅通过改善组织灌注，液体治疗通常就能解决电解质异常和代谢性酸中毒。

对于急性糖皮质激素替代，地塞米松磷酸钠（0.1 mg/kg静脉注射每12小时）作为一线治疗，因为它起效迅速且不干扰ACTH刺激试验[3]。或者，氢化可的松提供糖皮质激素和盐皮质激素活性。引起心律失常的严重高钾血症需要紧急葡萄糖酸钙（1 mL/kg静脉注射超过10分钟）以提供心脏保护作用[3]。

长期维持治疗包括盐皮质激素和糖皮质激素替代。脱氧皮质酮匹伐酸盐（DOCP）2.2 mg/kg肌肉注射每25天可有效管理盐皮质激素缺乏[1][2]。或者，氟氢可的松醋酸酯（Florinef）起始剂量0.10 mg/10磅可口服使用，根据电解质监测调整剂量[1][2]。大多数但不是所有犬都需要泼尼松（0.2 mg/kg/天）进行糖皮质激素替代[4]。可以逐渐减少每日泼尼松以确定仅盐皮质激素替代是否足够，但在疾病期间应激剂量类固醇仍然至关重要。

护理包括最初每1-2周仔细监测电解质，稳定后每3-4个月监测一次[1]。血压监测和并发症的支持性护理确保最佳患者结果。

### Sources
[1] Canine hypoadrenocorticism (Proceedings): https://www.dvm360.com/view/canine-hypoadrenocorticism-proceedings-1
[2] Canine hypoadrenocorticism (Proceedings): https://www.dvm360.com/view/canine-hypoadrenocorticism-proceedings-0  
[3] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[4] Endocrinology update for practitioners (Proceedings): https://www.dvm360.com/view/endocrinology-update-practitioners-proceedings

## 预防措施

肾上腺皮质功能减退症主要由免疫介导的肾上腺皮质破坏引起，使传统疫苗接种方案作为预防措施无效[1]。没有特定的疫苗可以预防这种内分泌疾病。

环境控制侧重于减压，因为临床症状在美容、寄养或展示等压力事件期间经常恶化[1][2]。保持一致的常规和最小化不必要的压力源可以帮助预防易感动物的阿狄森危象。危象患者通常有在压力期间通过输液和糖皮质激素治疗改善的病史[2]。

高风险患者的监测策略包括定期筛查具有遗传易感性的品种，包括新斯科舍诱鸭寻回犬、大丹犬、贵宾犬和西部高地白梗[1][3]。基础皮质醇浓度大于2 mcg/dL可有效排除肾上腺皮质功能减退症，使其成为高风险患者的有用筛查工具[1][3]。

主人教育强调早期识别模糊的、波动的临床症状，包括嗜睡、厌食、呕吐和体重减轻，这些症状可能通过支持性护理暂时改善[1][2]。教育主人了解症状的间歇性性质以及在症状复发时寻求兽医护理的重要性，对于及时诊断和预防危及生命的阿狄森危象至关重要。

### Sources
[1] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[2] Hypoadrenocorticism in the emergency setting: https://www.dvm360.com/view/hypoadrenocorticism-in-the-emergency-setting
[3] Updates on hypoadrenocorticism: https://www.dvm360.com/view/updates-hypoadrenocorticism

## 鉴别诊断

肾上腺皮质功能减退症被称为"伟大模仿者"，因为它能够模仿许多其他疾病[1]。主要鉴别诊断包括肾脏疾病，其中并发氮质血症和低尿比重可使阿狄森危象 closely resemble 急性肾衰竭[1]。高钾血症和低钠血症的存在可能最初提示原发性肾脏功能障碍而非肾上腺功能不全。

胃肠道疾病代表另一个主要的诊断挑战。慢性病例通常表现为非特异性体征，包括体重减轻、食欲下降、呕吐和腹泻，经常导致误诊为炎症性肠病（IBD）或蛋白丢失性肠病[2]。非典型肾上腺皮质功能减退症（发生在24-32%的病例中）缺乏典型电解质异常，这进一步使与原发性胃肠道疾病的鉴别复杂化[5]。

需要考虑的其他内分泌疾病包括糖尿病、甲状腺功能减退症和胰岛素瘤。与糖皮质激素缺乏相关的低血糖可模拟胰岛素瘤表现[4]。没有胆红素浓度升高的疑似肝功能衰竭，以低胆固醇血症、低白蛋白血症或低血糖为特征，也可能提示肝病而非肾上腺皮质功能减退症[2]。

关键区分因素包括全身性疾病犬缺乏应激白细胞象、钠钾比<27，以及基础皮质醇浓度≤2 μg/dL需要ACTH刺激试验[1,2]。兽医应对具有适当信号和模糊、波动的临床症状的患者保持高度临床怀疑肾上腺皮质功能减退症。

### Sources
[1] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[2] Oh yes, its the great pretender: https://www.dvm360.com/view/oh-yes-it-s-great-pretender
[4] Hypoadrenocorticism in dogs (Proceedings): https://www.dvm360.com/view/hypoadrenocorticism-dogs-proceedings
[5] Canine hypoadrenocorticism: managing difficult cases (Proceedings): https://www.dvm360.com/view/canine-hypoadrenocorticism-managing-difficult-cases-proceedings

## 预后

通过适当治疗，肾上腺皮质功能减退症在犬猫中具有极好的长期预后[1]。该病对激素替代治疗高度敏感，大多数患者在适当管理下达到正常预期寿命[1][2]。

治疗反应通常快速且显著。临床症状通常在开始适当的糖皮质激素和盐皮质激素替代治疗后几天到几周内消退[1]。许多犬在开始治疗后24-48小时内显示临床参数改善[2]。

影响恢复的关键预后因素包括早期诊断、主人对治疗方案的依从性和持续监测[1][3]。患有非典型肾上腺皮质功能减退症的犬可能最终发展为典型疾病，需要终身电解质监测[1]。然而，总体生存率仍然有利，研究报告2年生存率为76%，3年生存率为71%[2]。

生活质量考虑通常是积极的。大多数患者在治疗稳定后恢复正常活动水平和食欲[3]。定期监测对于调整药物剂量和预防并发症至关重要。当治疗得到适当管理时，潜在的长期并发症很少见，尽管一些患者可能在压力或疾病期间需要剂量调整[1]。

原发性或继发性形式的疾病在适当诊断并持续使用激素替代治疗时，预后仍然极好[1][3]。

### Sources
[1] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[2] Current concepts in canine adrenal disease (Proceedings): https://www.dvm360.com/view/current-concepts-canine-adrenal-disease-proceedings
[3] Updates on hypoadrenocorticism: https://www.dvm360.com/view/updates-hypoadrenocorticism
