# 伴侣动物的肱骨干骨折

肱骨干骨折是影响犬猫肱骨骨干的重要骨科损伤，由于桡神经邻近以及实现稳定固定的挑战而具有特殊的临床重要性。这些骨折通常发生在年轻、活跃的动物身上，由高能量创伤引起，尽管老年宠物可能因年龄相关的骨骼变化而从轻微事故中遭受类似损伤。

本报告综合了当前关于伴侣动物肱骨干骨折的兽医知识，研究其流行病学模式、包括神经系统并发症在内的临床表现、利用先进影像学的诊断方法，以及从传统钢板到微创技术和带锁髓内针的不断发展治疗策略。特别关注常见并发症，如桡神经麻痹和植入物失效，以及基于证据的方法，以优化受影响患者的愈合结果和功能恢复。

查看现有部分内容和提供的来源材料，我可以综合信息以增强疾病概述部分，同时保持在150-200字的限制内。

## 疾病概述与流行病学

肱骨干骨折是影响犬猫肱骨骨干或中段的创伤性损伤。这些骨折发生在近端干骺端（肱骨头下方）和远端干骺端（肘关节上方）之间的区域，特指肱骨干的皮质骨[1]。

肱骨的解剖结构使骨干骨折尤为重要，因为骨干缺乏其他长骨中发现的广泛肌肉覆盖，并且包含重要的神经血管结构。桡神经沿着肱骨干走行，使其在骨折事件中容易受伤[1]。

大多数关节旁骨折，包括肱骨损伤，发生在骨骼未成熟的犬中[3]。这些骨折具有挑战性，因为其中一个骨段长度短，以及年轻动物的骨骼相对较小[3]。

年龄易感性根据根本原因而异。年轻、活跃的犬可能在玩耍或事故中通过高能量创伤遭受这些骨折，而老年动物可能因年龄相关的骨骼减弱而从相对轻微的创伤中经历骨折[2]。大型品种犬与小型品种犬相比似乎有不同的风险因素，较轻的体重可能增加并发症风险[2]。

### Sources

[1] The seven most common reasons Fido might limp into your clinic (Sponsored by Purina Veterinary Diets): https://www.dvm360.com/view/seven-most-common-reasons-fido-might-limp-your-clinic-sponsored-purina-veterinary-diets
[2] Lower body weight and increasing age are significant risk ...: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0232.xml
[3] Managing physeal and articular fractures (Proceedings): https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings

## 临床表现与诊断方法

肱骨干骨折通常表现为急性不负重跛行、受影响肢体明显畸形、操作时疼痛以及骨折部位周围肿胀[1]。动物可能表现出不愿移动和表示不适的行为变化。体格检查显示捻发音、肢体角度异常以及触诊肱骨干时的局部疼痛[2]。

神经系统评估至关重要，特别是桡神经功能评估，因为该神经沿着肱骨干的螺旋沟走行，可能在中远端骨干骨折中受损[3]。桡神经功能障碍的体征包括无法伸展趾部、肘部下垂姿势、爪部背屈以及从肘部到趾部的肢体背侧感觉丧失[3]。

临床症状总是包括跛行、疼痛和肿胀[4]。放射摄影仍然是主要的诊断影像学方法，正交视图（头尾位和内外侧位）对于充分表征骨折构型、移位和粉碎程度至关重要[5]。计算机断层扫描可能在复杂病例中有益，以更好地评估骨折形态并辅助手术规划[1][5]。

分类系统有助于指导治疗决策，骨折通常按位置（近端、中段或远端三分之一）、构型（简单、粉碎、节段性）和移位模式分类[5]。骨折特征基于破坏性创伤力，包括弯曲、压缩、张力和旋转[4]。

### Sources

[1] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/262/1/javma.23.08.0448.xml
[2] Merck Veterinary Manual - Developmental Osteopathies: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/developmental-osteopathies-in-dogs-and-cats
[3] Merck Veterinary Manual - Limb Paralysis: https://www.merckvetmanual.com/nervous-system/limb-paralysis/limb-paralysis-in-animals
[4] Merck Veterinary Manual - Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[5] DVM 360 - Managing physeal and articular fractures: https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings

## 治疗选择与手术技术

肱骨干骨折的治疗遵循两种主要方法：保守治疗和手术修复。这些方法之间的选择取决于骨折构型、患者因素以及实现充分复位的能力[1]。

保守治疗包括闭合复位和使用刚性夹板的加压绷带进行外部固定。这种方法适用于最小移位的骨折，特别是在预期快速愈合的年轻动物中[1]。然而，由于仅靠外部固定难以维持复位，大多数肱骨干骨折需要手术干预。

手术选择包括多种固定方法。钢板骨接合术仍然是金标准，锁定加压钢板（LCP）在骨质不良或近端/远端靶点有限的情况下具有优势[1]。钢板-针结构通过结合两种固定方法的优势提供额外的稳定性。带锁髓内针（ILN）已越来越受欢迎，预弯角度稳定设计显示出良好的结果[2][3]。曲率半径为750-806mm的通用预弯ILN为大多数骨干骨折提供了合适的选择[2]。

外骨骼固定代表了另一种手术选择，线性构型在管理复杂骨折（包括不愈合病例）中显示出有效性[5]。混合外固定器结构为具有挑战性的骨折模式提供了额外的多功能性[6]。

微创钢板骨接合术（MIPO）已变得越来越重要，利用战略性放置的切口来保护软组织生物学[1][4]。这种技术减少了手术创伤，同时保持固定质量，研究表明其愈合率与开放复位方法相当[4]。

术后护理方案强调在实现刚性固定时的积极镇痛和早期活动[7]。物理康复通过控制性治疗练习、关节活动度活动和渐进性负重方案增强恢复[7]。无论内部固定方法如何，外部固定通常维持6-8周[1]。

### Sources

[1] Changes in fracture treatment which help practitioners: https://www.dvm360.com/view/changes-fracture-treatment-which-help-practitioners-proceedings
[2] A generic precurved interlocking nail is more compatible with: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/86/3/ajvr.24.09.0267.pdf
[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/85/3/ajvr.23.09.0207.xml
[4] Journal of the American Veterinary Medical Association Assessment of fracture healing: https://avmajournals.avma.org/view/journals/javma/241/6/javma.241.6.744.xml
[5] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[6] Use of a hybrid external skeletal fixator construct for managing: https://avmajournals.avma.org/view/journals/javma/258/10/javma.258.10.1098.xml
[7] Physical rehabilitation: Improving the outcome in dogs with: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems

## 并发症与鉴别诊断

肱骨干骨折存在几种可能显著影响患者结果的潜在并发症。**桡神经麻痹**是最严重的神经系统并发症，由于神经邻近肱骨干，发生在约2-18%的病例中[1]。这种并发症导致无法伸展肘部和趾部，肢体呈现下垂和背侧屈曲状态。

**植入物失效**通常发生在为骨折类型或患者大小选择了不合适的固定时。钢板长度不足、螺钉放置不当或植入物过小可能导致结构失效，特别是在粉碎性骨折中，骨骼与植入物之间的负荷共享受到损害[2]。**不愈合和延迟愈合**并发症由多种因素引起，包括感染、稳定性不足或过度刚性导致的应力保护[3]。

**畸形愈合**源于修复期间解剖对位不当，导致角度畸形，可能引起异常关节力学和继发性骨关节炎[2]。预期愈合时间根据患者年龄、骨折类型和固定方法而异，外部固定通常比内部固定愈合更快[3]。最新研究表明，在使用线性外固定治疗的猫不愈合病例中，骨愈合平均在57.8天内完成[4]。

肱骨骨折的**鉴别诊断**包括肩关节脱位、无骨折的桡神经麻痹、软组织创伤和其他胸部肢体骨折。仔细的神经系统检查和放射学评估可以区分这些情况。恢复预后通常良好，取决于损伤性质和修复成功情况，随访护理包括骨折愈合的放射学和临床评估[5]。

### Sources
[1] Merck Veterinary Manual Limb Paralysis in Animals: https://www.merckvetmanual.com/nervous-system/limb-paralysis/limb-paralysis-in-animals
[2] DVM 360 Surgery STAT: Tailor your bone fracture repair technique: https://www.dvm360.com/view/surgery-stat-tailor-your-bone-fracture-repair-technique
[3] DVM 360 Treating fracture disease and nonunion fractures: https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings
[4] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[5] Merck Veterinary Manual Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
