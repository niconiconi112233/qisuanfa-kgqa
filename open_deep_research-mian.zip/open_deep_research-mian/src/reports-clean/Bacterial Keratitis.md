# 犬猫细菌性角膜炎

细菌性角膜炎是伴侣动物临床中严重的眼部急症，可在数小时内导致角膜快速破坏和视力丧失。当细菌病原体侵入受损的角膜上皮时，就会发生这种情况，导致进行性基质融化和潜在穿孔。最危险的病例涉及*铜绿假单胞菌*，它可通过侵袭性蛋白水解活性在24-72小时内导致角膜完全溶解。本综述全面探讨了导致细菌性角膜炎的致病微生物、从浅表溃疡到融化角膜的临床表现、包括细胞学检查和先进成像技术的诊断方法，以及结合强化医疗治疗和必要时手术干预的治疗策略。

## 摘要

犬猫细菌性角膜炎需要立即识别和积极治疗，以防止不可逆的角膜损伤。该病主要由革兰氏阳性生物（如*葡萄球菌*属）和革兰氏阴性病原体（包括特别危险的*铜绿假单胞菌*）引起，后者通过蛋白水解酶产生快速角膜融化。临床表现从伴有黏液脓性分泌物的疼痛性浅表溃疡到可在数天内穿孔的破坏性融化溃疡不等。诊断依赖于角膜细胞学和培养，共聚焦显微镜等先进成像技术可提供详细的组织评估。

| 关键方面 | 关键特征 |
|------------|------------------|
| 高风险病原体 | *铜绿假单胞菌*（融化性溃疡）、*葡萄球菌*属、混合感染 |
| 急症体征 | 密集白色浸润、凝胶样外观、快速进展 |
| 诊断优先级 | 荧光素染色前的角膜细胞学和培养 |
| 治疗紧迫性 | 强化局部抗生素、抗胶原酶治疗、深度>50%时手术干预 |

早期使用氟喹诺酮类药物和抗胶原酶剂干预可保存视力，而延迟治疗通常需要手术重建。预防侧重于管理干性角膜结膜炎和环境紫外线暴露等易感因素，特别是在高海拔地区和短头颅品种中。

## 常见病原体

犬猫细菌性角膜炎由革兰氏阳性和革兰氏阴性生物引起，这些生物在上皮破坏后侵入角膜组织[1][3]。最常见的革兰氏阳性细菌包括*葡萄球菌*属，特别是犬中的*伪中间葡萄球菌*，以及*链球菌*属[1][3]。当正常结膜菌群受损时，这些生物通常建立感染。

在革兰氏阴性细菌中，*铜绿假单胞菌*因其通过蛋白酶产生导致快速角膜融化的能力而构成特别重大的威胁[1][3]。*大肠杆菌*和*肠杆菌*属也是常见的病原体[4][7]。*巴斯德菌*属可能遇到，特别是在有咬伤史的病例中[7]。

混合细菌感染在临床实践中经常发生[4]。正常结膜微生物群通常保持健康的革兰氏阳性优势，但在角膜溃疡期间向革兰氏阴性生物转变，增加继发性机会性感染的易感性[1][3]。*支气管败血波氏杆菌*可引起呼吸道感染，可能继发影响眼部组织[5]。继发性细菌感染常使原发性病毒性角膜炎复杂化，特别是在感染猫疱疹病毒1型的猫中[5]。

存在物种特异性模式，葡萄球菌感染在犬病例中更常见，而*假单胞菌*感染因其侵袭性蛋白水解活性对两种物种的角膜穿孔构成最大风险。

### Sources

[1] Diseases of the equine cornea (Proceedings): https://www.dvm360.com/view/diseases-equine-cornea-proceedings
[2] Top Trending Collection - AVMA Journals: https://avmajournals.avma.org/page/Top-Trending-Collection
[3] Oral administration of famciclovir for treatment of spontaneous...: https://avmajournals.avma.org/view/journals/javma/249/5/javma.249.5.526.xml
[4] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs
[5] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[6] Three-minute peripheral blood film evaluation: The leukon: https://www.dvm360.com/view/three-minute-peripheral-blood-film-evaluation-leukon
[7] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats

## 临床症状和体征

犬猫细菌性角膜炎表现为一系列反映角膜炎症和继发性并发症的临床体征。典型表现包括角膜水肿、血管化和不同程度的混浊，从轻微 haze 到密集的灰白色浸润[1]。

**疼痛表现**是主要特征，表现为睑痉挛、过度流泪和畏光[3]。动物可能表现出摩擦行为和不愿睁开受影响的眼睛[3]。结膜充血和水肿通常伴随细菌性角膜炎，眼部分泌物从浆液性进展为黏液脓性，随着继发性细菌感染的发展[2]。

**角膜病变外观**因细菌病原体和疾病严重程度而有显著差异。浅表细菌性角膜炎通常表现为不规则或地理性溃疡模式[1]。深基质受累可能产生特征性的凝胶样外观，特别是在与*铜绿假单胞菌*和β-溶血性*链球菌*属相关的角膜软化或"融化性溃疡"病例中[8]。这些融化性溃疡进展极快，可在24-72小时内导致角膜穿孔[8]。

**密集的白色浸润**出现在溃疡边缘或溃疡床内，表明白细胞浸润和细菌参与[5]。在晚期病例中，角膜基质可能呈现液化，伴有严重水肿和潜在的继发性葡萄膜炎[3]。

**物种特异性模式**包括疼痛耐受性的差异，尽管病变严重程度相似，但猫通常比犬显得更舒适[4]。在猫患者中，细菌性角膜炎常继发于疱疹病毒感染，特别是当溃疡在预期的7-10天时间框架内未能愈合时[8]。

### Sources
[1] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[2] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings
[3] Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[4] Feline corneal diseases: herpesvirus and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[5] Disorders of the Cornea in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-cornea-in-dogs
[8] Ocular emergencies: Presenting signs, initial exam and treatment (Proceedings): https://www.dvm360.com/view/ocular-emergencies-presenting-signs-initial-exam-and-treatment-proceedings

## 诊断方法

细菌性角膜炎诊断需要系统的方法，结合临床检查与特定的实验室和成像技术[1]。诊断过程始于全面的眼科检查，以评估角膜病变、评估疼痛水平和识别易感因素[1]。

**临床检查技术**
初始检查涉及荧光素染色以识别角膜缺陷并评估溃疡深度[8]。任何似乎涉及角膜基质的溃疡都需要立即进行诊断检查[1]。临床表现从浅表糜烂到深基质受累不等，溃疡边缘有密集的白色浸润，表明细菌参与[3]。

**实验室检测**
角膜细胞学和培养仍然是细菌性角膜炎诊断的金标准[1][5]。样本应在应用荧光素染料之前收集，因为它会抑制细菌生长[1]。细胞学使用细胞刷、刀片刮擦或棉拭子提供快速结果，而培养和药敏测试指导适当的抗生素选择[4][5]。革兰氏染色为初始抗生素治疗提供即时指导[4]。

**先进诊断**
体内共聚焦显微镜提供所有角膜层的实时高分辨率细胞评估，提供与组织化学分析相当的图像[10]。当角膜混浊阻碍更深结构可视化时，眼部超声（10-20 MHz探头）有帮助[5]。这些先进的成像模式正在迅速推进兽医眼科诊断[6]。

**解读指南**
进行性基质溃疡、软化外观或脓性分泌物需要立即进行培养和药敏测试[4]。超过角膜深度50%的深溃疡需要紧急评估手术干预[3]。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] A refresher on the cornea: https://www.dvm360.com/view/a-refresher-on-the-cornea
[3] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[4] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[5] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings
[6] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[7] Treatment of dematiaceous fungal keratitis in a dog: https://avmajournals.avma.org/downloadpdf/view/journals/javma/240/9/javma.240.9.1104.pdf
[8] Physical Examination of the Eye in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals
[9] Canine Keratomycosis in 11 Dogs: https://meridian.allenpress.com/jaaha/article/50/2/112/176144/Canine-Keratomycosis-in-11-Dogs-A-Case-Series-2000
[10] Clinical applications of in vivo confocal microscopy: https://avmajournals.avma.org/view/journals/javma/262/S2/javma.24.05.0333.xml

## 治疗选择

细菌性角膜炎的治疗需要积极的医疗管理，包括强化局部抗菌药物和辅助治疗，并在必要时结合手术干预[1]。主要医疗治疗涉及频繁应用广谱抗生素，氟喹诺酮类药物（氧氟沙星、环丙沙星）因其优异的革兰氏阴性覆盖和角膜渗透性而成为首选[2]。对于严重病例，可能需要强化抗生素，如复方头孢唑林（5%）或妥布霉素（1.5%）[1]。

使用局部血清、EDTA或乙酰半胱氨酸进行抗胶原酶治疗对于融化性溃疡至关重要，以防止酶性角膜破坏[2]。支持性护理包括使用局部阿托品进行散瞳和疼痛缓解、全身抗炎药和当存在葡萄膜炎时的口服抗生素[1]。口服多西环素以10 mg/kg每日两次的剂量提供抗菌和抗酶双重作用[2]。

当基质损失超过50%深度或医疗治疗失败时，手术干预变得必要[6]。选择包括用于结构支持和血管化的结膜瓣移植、用于更好视觉效果的角膜结膜转位瓣，以及用于感染组织切除的角膜切除术加移植[8]。紧急程序可能需要直接角膜缝合或角膜移植，具体取决于缺陷严重程度[6]。

使用全身NSAIDs或曲马多进行疼痛管理，以及严格使用伊丽莎白圈，可防止愈合期间的自伤[1]。每24-48小时进行复查检查的密切监测确保适当的治疗反应，并在医疗治疗不足时早期手术干预[2]。

### Sources

[1] Medical Management of Deep Ulcerative Keratitis: https://www.dvm360.com/view/medical-management-of-deep-ulcerative-keratitis
[2] Corneal ulcers: https://www.dvm360.com/view/corneal-ulcers
[3] Antimicrobial Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[4] Corneal disease in dogs: there is a hole in my cornea (Proceedings): https://www.dvm360.com/view/corneal-disease-dogs-there-hole-my-cornea-proceedings
[5] Corneal surgical techniques: Conjunctival pedicle grafts and beyond (Proceedings): https://www.dvm360.com/view/corneal-surgical-techniques-conjunctival-pedicle-grafts-and-beyond-proceedings
[6] Complicated corneal ulcer: Avoiding disasters (Proceedings): https://www.dvm360.com/view/complicated-corneal-ulcer-avoiding-disasters-proceedings

## 预防措施

预防犬猫细菌性角膜炎需要全面的风险因素缓解和环境管理。高海拔和紫外线辐射是重要的环境风险因素，最严重的病例发生在犹他州和科罗拉多州等州[1]。短头颅品种和眼睛突出的犬特别容易发生角膜溃疡性疾病，需要加强保护措施[1]。

一级预防侧重于解决导致细菌性角膜炎的潜在疾病。干性角膜结膜炎（干眼症）是导致角膜溃疡的最常见潜在疾病，使定期泪液产生评估变得至关重要[1,2]。通过Schirmer泪液测试早期发现可以在角膜受损之前进行及时干预[2]。

环境修改包括通过在高风险地理区域采取保护措施来最大限度地减少紫外线辐射暴露。定期检查眼睑结构和功能有助于识别可能导致角膜创伤的结构异常，如眼睑内翻或双行睫[2]。适当的伤口护理和异物移除可防止继发性细菌感染。

主人教育强调对任何眼部不适迹象（包括斜视、流泪或摩擦）立即就医的重要性。早期干预可防止从简单的浅表溃疡进展为复杂的感染病例[2]。对高风险品种进行定期眼科检查，可在角膜损伤发生之前早期发现易感因素。

预防小反刍动物传染性角膜结膜炎主要依靠隔离受影响动物和防止畜群内传播[3]。应根据既定指南维持核心疾病的疫苗接种方案[4]。

### Sources

[1] Canine corneal diseases: Treatment for transparency: https://www.dvm360.com/view/canine-corneal-diseases-treatment-transparency-greater-federal-stimulus-proceedings
[2] Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases  
[3] Infectious Keratoconjunctivitis in Cattle and Small Ruminants: https://www.merckvetmanual.com/eye-diseases-and-disorders/infectious-keratoconjunctivitis/infectious-keratoconjunctivitis-in-cattle-and-small-ruminants
[4] 2022 AAHA Canine Vaccination Guidelines (2024 Update): https://meridian.allenpress.com/jaaha/article/60/6/1/503802/2022-AAHA-Canine-Vaccination-Guidelines-2024

## 鉴别诊断

在犬猫中，必须将几种疾病与细菌性角膜炎区分开，每种疾病都有特定的临床和诊断特征。**病毒性角膜炎**，特别是猫中的猫疱疹病毒1型（FHV-1），表现为树枝状溃疡，这是病毒感染的特征性表现[3]。与细菌性角膜炎不同，病毒性角膜炎常伴有上呼吸道体征和全身性疾病，角膜细胞学检查缺乏细菌生物，但可能显示病毒包涵体。

**真菌性角膜炎**表现为白色蓬松的基质浸润或斑块，有时由暗色真菌引起棕色色素沉着[5]。深角膜刮片在Gomori六胺银染色的细胞学检查中显示真菌菌丝和孢子，将其与以中性粒细胞和细菌为主的细菌感染区分开。

**免疫介导性角膜炎**包括慢性浅表性角膜炎（血管翳），影响德国牧羊犬及相关品种，双侧发生但无溃疡[1]。这种情况显示从角膜缘进行的进行性血管化和色素沉着，但缺乏细菌性角膜炎典型的脓性分泌物和角膜融化。

**干性角膜结膜炎（KCS）**表现为黏液性分泌物和暗淡无光的角膜[4]。Schirmer泪液测试值低于15 mm/分钟确认泪液产生不足，而细菌性角膜炎通常发生在泪液产生正常的情况下，除非KCS是易感因素。

猫的**嗜酸性粒细胞性角膜结膜炎**显示伴有周围血管化的灰白色角膜斑块[3]。角膜细胞学检查显示丰富的嗜酸性粒细胞，而不是细菌感染中见到的中性粒细胞和细菌。

明确诊断需要角膜细胞学、培养和药敏测试，以识别细菌生物并指导适当的抗菌治疗。

### Sources
[1] Merck Veterinary Manual The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[2] DVM 360 Immune-mediated keratitis in horses: https://www.dvm360.com/view/immune-mediated-keratitis-horses
[3] DVM 360 Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] DVM 360 Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[5] DVM 360 Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
