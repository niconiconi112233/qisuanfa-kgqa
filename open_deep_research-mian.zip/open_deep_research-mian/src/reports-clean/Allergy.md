# 宠物疾病：过敏

过敏性疾病是伴侣动物医学中最常见且最具挑战性的疾病之一，显著影响着宠物及其主人的生活质量。本综合报告探讨了犬猫过敏反应的复杂性质，从花粉和尘螨等环境诱因到食物蛋白和跳蚤唾液抗原。该疾病在普通诊疗中影响1-2%的犬和不到1%的猫，但在皮肤病病例中患病率急剧增加。通过对临床表现、诊断方法、治疗方案和预防策略的系统检查，本报告为管理这些通常在1-3岁发病并需要终身多模式治疗方法的慢性疾病提供了重要见解。

## 摘要

本报告揭示，伴侣动物的过敏性疾病呈现出复杂的诊断和治疗挑战，需要全面的多模式管理方法。该疾病主要表现为剧烈瘙痒和特征性分布模式，其中异位性皮炎在犬中影响腹侧区域，在猫中影响头部/颈部区域。环境过敏原包括花粉、尘螨和跳蚤唾液是最常见的诱因，而食物过敏主要涉及牛肉、鸡肉和乳制品蛋白。

| 方面 | 犬 | 猫 |
|--------|------|------|
| **患病率** | 普通诊疗1-2%，皮肤病病例高达24% | 普通诊疗<1%，皮肤病病例3-6% |
| **常见诱因** | 花粉、尘螨、牛肉、鸡肉 | 牛肉、鱼、鸡肉、环境过敏原 |
| **典型表现** | 腹侧腹部、腋窝、耳朵（56-80%食物过敏病例） | 头/颈部瘙痒、粟粒性皮炎 |
| **金标准诊断** | 8-12周排除饮食试验 | 相同排除方案 |
| **主要治疗** | JAK抑制剂、免疫疗法（60-70%反应率） | 抗组胺药、omega-3脂肪酸 |

成功的管理需要全年跳蚤预防、包括HEPA过滤和湿度控制在50%以下的环境控制措施，以及严格的饮食方案。通过适当的多模式治疗，预后通常良好，尽管通常需要终身管理。使用过敏原特异性免疫疗法进行早期干预为环境过敏提供了最佳的长期结果。

## 疾病概述

犬猫的过敏性皮炎是指由环境或饮食过敏原的超敏反应引起的炎症性皮肤病[1]。最常见的形式是异位性皮炎，定义为一种具有遗传倾向、炎症性和瘙痒性的过敏性皮肤病，具有特征性临床表现[1][3]。这种遗传性疾病主要与环境过敏原（如花粉、霉菌孢子、尘螨和动物皮屑）的IgE抗体相关[1][3]。

过敏性疾病的真实患病率因研究人群不同而有显著差异。环境过敏在普通兽医诊疗中影响1-2%的犬和不到1%的猫，但这些百分比在皮肤病病例中大幅增加（犬0-24%，猫3-6%）[5]。食物过敏较为少见，但仍然是过敏性皮炎的重要诱因。

发病年龄在犬中通常为1-3岁，尽管病例范围可从6个月到5岁[1]。在猫中，发病年龄相似为1-3岁，但可能从4个月到15岁不等[5]。某些品种表现出易感性，包括梗类犬、寻回犬、德国牧羊犬、西部高地白梗和法国斗牛犬[2][5]。母犬似乎比公犬更易感（2.5:1比例）[1]。

免疫发病机制涉及复杂的I型超敏反应。当过敏原通过皮肤或呼吸道吸收时，它们与肥大细胞和嗜碱性粒细胞上的过敏原特异性IgE结合，触发脱颗粒并释放包括组胺、白三烯和细胞因子在内的炎症介质[1][3][6]。

### Sources

[1] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings
[2] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[3] Atopic Dermatitis in Animals - Integumentary System: https://www.merckvetmanual.com/en-au/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[5] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[6] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals

## 常见病原体和过敏原

犬猫的过敏反应主要由环境和饮食过敏原触发，而非传染性病原体。犬中最常见的食物过敏原包括牛肉、乳制品、鸡肉、小麦和羊肉，而猫最常对牛肉、鱼和鸡肉产生反应[1]。这些蛋白是最常食用的成分，解释了它们作为过敏原的普遍性。

环境过敏原包括来自树木、草和杂草的花粉，这些通常引起季节性过敏反应[2]。霉菌孢子和室内尘螨代表全年性环境诱因，其中尘螨在潮湿条件下尤其成问题。昆虫相关过敏原起着重要作用，跳蚤唾液抗原是伴侣动物过敏性皮炎的最常见原因[3]。

相关蛋白之间的交叉反应在临床上很重要。羽毛类蛋白（鸡肉、鸭肉、火鸡肉）可能发生交叉反应，牛肉和鹿肉之间也存在潜在的交叉反应[4]。接触性过敏原在小动物中较少见，因为它们有保护性被毛，但当接触到外用药物或环境化学品时，可能影响毛发稀疏区域。

过敏原暴露途径在异位性皮炎发病机制中至关重要。通过皮肤的经皮吸收现在被认为是环境过敏原暴露的主要途径，这由表皮屏障缺陷促进，使免疫细胞能够接触[3]。

### Sources
[1] Cutaneous Food Allergy in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[2] Canine Atopic Dermatitis - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis
[3] Allergies in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/allergies-in-dogs
[4] Common food allergens in cats and dogs: https://www.dvm360.com/view/common-food-allergens-in-cats-and-dogs

## 临床症状和体征

犬猫的宠物过敏通过不同的临床模式表现，瘙痒是所有过敏性疾病普遍存在的标志性体征[1]。所有过敏性超敏反应的临床表现相似：瘙痒、红斑、脱毛、丘疹，随着时间推移还会出现色素沉着和苔藓化[1]。

**犬的瘙痒模式**

犬过敏性皮炎通常呈现特征性分布模式。异位性皮炎影响腹侧腹部、腋窝、腹股沟、口鼻部、眼周、肛周以及掌部或跖部区域[1]。食物过敏相关的瘙痒可能像疥疮引起的瘙痒一样严重，可能涉及任何身体区域，尽管它常常反映异位性皮炎的模式[2][6]。继发并发症通常包括复发性浅表性脓皮病和外耳炎，耳部疾病影响56-80%的食物过敏犬[4]。

**猫的表现**

在猫中，与食物过敏相关的最常见临床体征是面部和头部的剧烈瘙痒[6]。猫的过敏性疾病通过独特的反应模式表现，包括粟粒性皮炎、自发性脱毛、嗜酸性肉芽肿复合体病变以及头颈部瘙痒[2]。瘙痒的猫常常带来诊断挑战，因为同一疾病在不同动物中可能有不同的表现[9]。

**继发性表现**

两个物种都常因皮肤屏障功能受损和自发性创伤而继发细菌和马拉色菌感染[1]。胃肠道症状在大约50-60%的食物过敏犬和30%的猫中同时出现，包括间歇性呕吐、腹泻和排便频率增加[4][6]。

**品种特异性考虑**

某些品种对过敏性皮炎表现出易感性。在犬中，梗类犬、寻回犬、德国牧羊犬和西部高地白梗比例过高[1][6]。异位性皮炎的临床体征通常在1-3岁之间发展，尽管食物过敏可能从6个月到15岁不等[6]。

### Sources
[1] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[2] Atopic Dermatitis in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[3] Dermatologic manifestations and nutritional management of adverse food reactions: https://www.dvm360.com/view/dermatologic-manifestations-and-nutritional-management-adverse-food-reactions
[4] Cutaneous Food Allergy in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[5] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[6] Differential diagnoses for the itchy and scratchy: https://www.dvm360.com/view/differential-diagnoses-itchy-and-scratchy-proceedings

## 诊断方法

伴侣动物过敏的准确诊断需要结合临床评估、排除试验和专门测试的系统方法。金标准仍然是排除饮食试验，它既是诊断工具也是治疗干预[1]。

**临床评估和病史**
全面的病史采集构成过敏诊断的基础。临床医生应记录发病年龄、季节性模式、病变分布和对先前治疗的反应[2]。彻底的皮肤科检查包括皮肤刮片、真菌培养和细胞学评估，在进行过敏测试前排除传染性原因[1]。

**细胞学检查**
皮肤细胞学是兽医皮肤病学中最有价值的诊断测试之一[4]。各种采集技术包括直接印片、用于干燥病变的胶带准备以及用于耳道或难以到达区域的棉签采样[4]。印片细胞学提供对炎症过程和继发感染的即时见解，而胶带细胞学特别适用于采集趾间空间或干燥、鳞屑性病变的样本[5]。这些技术有助于识别细菌过度生长、酵母菌感染和寄生虫感染，这些常见于过敏疾病的并发症[6][8]。

**排除饮食试验**
食物过敏诊断完全依靠严格的8-12周排除饮食试验，随后进行激发再暴露[3]。这些试验必须使用新颖蛋白来源或水解饮食，并完全消除所有零食、调味药物和补充剂。使用食物过敏原的皮内皮肤测试已被证明非常不准确，不推荐使用[3]。

**环境过敏原的过敏测试**
对于环境过敏，皮内过敏测试代表金标准，涉及注射特定过敏原以评估皮肤反应[1]。血清过敏测试在皮内测试不可行时提供替代方案，尽管由于与皮内结果相关性差，其临床有效性受到质疑[2]。两种测试方法都应仅在临床诊断确立后用于指导过敏原特异性免疫疗法[1]。

### Sources
[1] Cats can itch too! Feline pruritic diseases and treatment: https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[2] A clinical approach to feline atopic dermatitis: https://www.dvm360.com/view/a-clinical-approach-to-feline-atopic-dermatitis
[3] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings
[4] Dermatologic cytology 101: Tips for collecting samples: https://www.dvm360.com/view/dermatologic-cytology-101-tips-for-collecting-samples
[5] Quick overview of foundational diagnostic strategies in feline dermatology: https://www.dvm360.com/view/quick-overview-of-foundational-diagnostic-strategies-in-feline-dermatology
[6] Cutaneous Food Allergy in Animals: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals
[7] Skills Laboratory: How to perform skin scraping and skin surface cytology: https://www.dvm360.com/view/skills-laboratory-how-perform-skin-scraping-and-skin-surface-cytology
[8] Dermatological Problems in Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

## 治疗选择

宠物过敏的药物治疗采用结合各种治疗类别的多模式方法[1]。皮质类固醇仍然是主要治疗选择，全身性糖皮质激素在犬猫异位性皮炎中提供快速临床反应[1]。较新的靶向疗法改变了过敏管理，如奥拉替尼等JAK抑制剂通过阻断白细胞介素-31（IL-31）信号传导，在数小时内提供快速瘙痒缓解[1]。

免疫调节剂在长期管理中起着关键作用。环孢素通过抑制钙调神经磷酸酶和阻断IL-2产生，提供比皮质类固醇更有针对性的方法，从而防止T细胞活化[1]。对于猫科患者，氯苯那敏等抗组胺药（每只猫口服2-4毫克，每8-24小时一次）提供有益效果且副作用最小[3]。必需脂肪酸，特别是omega-3补充剂，在过敏性疾病猫中显示50-75%的改善率[3]。

过敏原特异性免疫疗法（ASIT）代表长期治疗的金标准，60-70%的犬显示阳性反应[1]。这种方法涉及逐渐增加给予过敏原提取物的浓度以提高耐受性。局部治疗补充全身疗法，含有氯己定（3-4%浓度）的防腐制剂提供抗菌效果同时支持屏障修复[1]。最近的创新包括单克隆抗体疗法（lokivetmab），专门靶向IL-31，提供4-6周的瘙痒缓解且不良反应最小[1]。

### Sources
[1] Immunomodulators for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/immunomodulators-for-integumentary-disease-in-animals
[2] The multimodal approach to canine atopic dermatitis: https://www.dvm360.com/view/the-multimodal-approach-to-canine-atopic-dermatitis
[3] Management of the pruritic cat: Topical and systemic: https://www.dvm360.com/view/management-pruritic-cat-topical-and-systemic-proceedings

## 预防措施和鉴别诊断

### 预防措施

**环境控制策略**
有效的过敏管理需要全面的环境改造以减少过敏原暴露。对于尘螨过敏，使用HEPA过滤器吸尘器每周吸尘以及蒸汽清洁床垫、床上用品和软垫家具被证明最有效[4][5]。将湿度水平保持在50%以下，用热水（>50°C）或加茶树油的冷水洗涤床上用品有助于减少尘螨种群[4]。

**跳蚤预防方案**
全年跳蚤预防对所有宠物至关重要，因为跳蚤可以在爬行空间和软垫家具等受保护环境中在具有挑战性的条件下生存[6]。CAPC指南建议在出生后尽快给犬猫使用预防性跳蚤产品，并持续其一生[7]。现代跳蚤预防药物包括氟虫腈、吡虫啉和塞拉菌素，在持续使用时已被证明极其有效[8]。

**饮食考虑**
食物过敏预防集中在使用水解蛋白或新颖成分进行8-12周的严格排除饮食试验。储藏螨预防包括购买小袋干粮，立即转移到密封容器中，并冷冻未使用部分[4]。避免生肉并提供新鲜饮用水是必要的预防措施[9]。

### 鉴别诊断

**模拟过敏的关键疾病**
几种寄生虫和传染性疾病呈现相似的瘙痒性病变。蠕形螨病、疥螨病和Cheyletiella螨病需要皮肤刮片进行明确诊断[4]。细菌性脓皮病和马拉色菌皮炎常引起继发感染，使过敏病例复杂化，需要细胞学检查[4]。

**肿瘤考虑**
肥大细胞瘤、皮肤淋巴瘤和亲上皮性淋巴瘤可表现为瘙痒性皮肤病变，需要组织病理学检查才能准确诊断。这些疾病需要及时识别，因为治疗方法与过敏性皮炎管理显著不同[4]。

### Sources

[1] It's Spring and My Pet Itches! A Look at Seasonal Allergies: https://www.dvm360.com/view/its-spring-and-my-pet-itches-a-look-at-seasonal-allergies
[2] FAQs about house dust mite and storage mite allergies: https://www.dvm360.com/view/faqs-about-house-dust-mite-and-storage-mite-allergies
[3] Discuss facts, fallacies of dust mite allergies: https://www.dvm360.com/view/discuss-facts-fallacies-dust-mite-allergies
[4] CAPC primary guidelines: https://www.dvm360.com/view/capc-primary-guidelines
[5] Parasite control in pets requires year-round vigilance: https://www.dvm360.com/view/parasite-control-pets-requires-year-round-vigilance
[6] Developing integrated flea control for cats: https://www.dvm360.com/view/developing-integrated-flea-control-cats
[7] Challenges in parasite management: https://www.dvm360.com/view/challenges-parasite-management
[8] Preventative Health Care for Small Animals: https://www.merckvetmanual.com/management-and-nutrition/preventative-health-care-and-husbandry-in-small-animals/preventative-health-care-for-small-animals
