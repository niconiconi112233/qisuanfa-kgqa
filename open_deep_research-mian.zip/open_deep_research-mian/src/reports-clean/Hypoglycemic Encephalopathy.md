# 伴侣动物低血糖性脑病

低血糖性脑病是犬猫中一种严重的神经系统急症，由大脑葡萄糖供应不足引起。如果不能及时识别和治疗，这种情况可能导致不可逆的脑损伤和死亡。大脑对葡萄糖的绝对需求使得当血糖降至临界阈值以下时，伴侣动物特别容易受到影响。本综合报告探讨了小动物临床中低血糖性脑病的多面性，涵盖了从胰岛素过量、木糖醇毒性到胰岛素瘤和新生儿低血糖等多种根本原因。分析范围包括从微妙的行为改变到危及生命的癫痫发作的临床表现、基于证据的诊断方法、紧急治疗方案以及兽医从业者管理糖尿病患畜和风险动物所必需的预防策略。

## 疾病概述与流行病学

**低血糖性脑病**是一种神经系统疾病，由大脑葡萄糖供应不足引起，导致犬猫细胞功能障碍和潜在的不可逆脑损伤。大脑对葡萄糖作为主要能量来源有绝对需求，且缺乏显著的糖原储备，使其特别容易受到葡萄糖剥夺的影响[1]。

其病理生理学涉及当血糖降至临界阈值以下时，大脑无法维持正常代谢过程。在犬猫中，当血糖水平降至60 mg/dL以下时通常会出现临床症状，当浓度低于40-45 mg/dL时会发生严重的神经功能障碍[2]。 prolonged低血糖会导致细胞能量衰竭、膜功能障碍，如果不迅速纠正，最终会导致神经元死亡[2]。

**从流行病学角度看**，低血糖性脑病是继发于多种潜在疾病，而不是作为原发性疾病实体。在小动物临床中，最常见的原因是糖尿病患畜的胰岛素过量、胰岛素瘤、严重肝病、败血症或毒素暴露（特别是犬的木糖醇）[2][3]。幼年动物和玩具品种犬由于糖原储备有限和代谢需求较高而表现出易感性增加[2]。这种情况代表一种医疗急症，死亡风险随着低血糖的持续时间和严重程度显著增加。

### Sources
[1] Merck Veterinary Manual Diabetes Mellitus in Dogs and Cats: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[2] DVM 360 Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[3] DVM 360 Managing complications in diabetic cats: https://www.dvm360.com/view/managing-complications-diabetic-cats

## 病因学与风险因素

现有章节内容全面涵盖了低血糖性脑病的病因，我现在将结合源材料中的额外信息进一步综合，以增强本章节内容。

伴侣动物的低血糖性脑病由多种损害葡萄糖稳态或增加葡萄糖消耗的潜在原因引起[1]。胰岛素过量代表一种常见的医源性原因，特别是在接受不适当剂量给药或胰岛素注射后饮食摄入不足的糖尿病患畜中[2]。木糖醇毒性对犬构成重大风险，仅摄入0.1 g/kg即可通过深刻的胰岛素释放引起严重低血糖[4]。

胰岛素瘤虽然在猫中极为罕见，仅有8例报告，但代表一个需要早期识别的关键病因[6]。这些胰腺β细胞肿瘤分泌过量胰岛素，引起深度低血糖，伴有无力、嗜睡和癫痫样发作等神经学表现[6,7]。犬胰岛素瘤通常影响中年至老年犬，爱尔兰塞特犬、标准贵宾犬和德国牧羊犬等品种发病率较高[8]。

新生儿和幼年低血糖在幼犬和幼猫中频繁发生，原因是糖原储备有限和葡萄糖需求高[3]。幼年动物主要依赖肝脏糖原储备，在禁食时仅能提供8-12小时的葡萄糖[3]。患有先天性门体分流的犬种在低血糖方面表现出特殊易感性，特别是在长时间禁食期间[1]。

其他风险因素包括败血症，它通过增加葡萄糖消耗和损害肝功能引发低血糖[2,3]。诸如夹竹桃、全身性细菌感染和肾脏疾病等毒素也可引发需要立即干预的危险低血糖发作[9]。

### Sources

[1] Miscellaneous Serum Biochemical Measures in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/miscellaneous-serum-biochemical-measures-in-hepatic-disease-in-small-animals

[2] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals

[3] Pediatric emergencies (Proceedings): https://www.dvm360.com/view/pediatric-emergencies-proceedings

[4] Hepatotoxins in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/hepatotoxins-in-small-animals

[5] Hepatic Portal Venous Hypoperfusion in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-portal-venous-hypoperfusion-in-small-animals

[6] Detection of feline insulinoma with contrast-enhanced ultrasonography: https://www.dvm360.com/view/detection-of-feline-insulinoma-with-contrast-enhanced-ultrasonography

[7] Unusual and uncommon endocrine disorders (Proceedings): https://www.dvm360.com/view/unusual-and-uncommon-endocrine-disorders-proceedings

[8] Diabetes mellitus in cats (Proceedings): https://www.dvm360.com/view/diabetes-mellitus-cats-proceedings

[9] Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient

## 临床表现与诊断方法

犬猫的低血糖性脑病表现为一系列临床症状，从轻微的行为改变到危及生命的神经学表现[1]。早期症状包括不安、行为改变、颤抖、全身无力、共济失调和步履蹒跚[1]。随着病情进展，动物会出现更严重的表现，包括虚脱、癫痫发作、木僵，甚至昏迷[1,2]。

临床症状的严重程度既取决于血糖下降的速度，也取决于实际的血糖浓度，动物通常在血糖降至30-40 mg/dl以下时才出现症状[1,6]。患有慢性低血糖的动物可能对低血糖水平表现出显著的适应能力，而急性下降则会引发交感神经放电，导致焦虑和极度饥饿[1]。

诊断方法从立即测量血糖开始，因为低于40 mg/dl的低血糖可引发癫痫活动[6]。应在治疗前采集关键样本，包括疑似胰岛素瘤时的同步血糖和胰岛素水平[1]。可能需要进行CT或MRI等高级诊断成像以识别潜在原因，如胰腺肿瘤或肝脏异常[1,4]。其他诊断测试应包括全血细胞计数、综合生化面板和尿液分析，以评估代谢紊乱、肝功能障碍或其他导致低血糖性脑病的系统性原因[4]。

### Sources
[1] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings-1
[2] Metabolic encephalopathies: Diagnoses from blood work alone (Proceedings): https://www.dvm360.com/view/metabolic-encephalopathies-diagnoses-blood-work-alone-proceedings
[4] Diagnostic approach to patients with signs of encephalopathy (Proceedings): https://www.dvm360.com/view/diagnostic-approach-patients-with-signs-encephalopathy-proceedings
[6] Seizures in puppies, kittens difficult diagnostic and therapeutic problem: https://www.dvm360.com/view/seizures-puppies-kittens-difficult-diagnostic-and-therapeutic-problem

## 治疗与管理

急性低血糖性脑病的紧急治疗需要立即补充葡萄糖以恢复大脑功能并防止永久性脑损伤[1]。对于严重低血糖，应静脉注射右旋糖酐，以0.5 g/kg的剂量按1:4稀释后缓慢推注，或者10-20 ml/kg的10-20%右旋糖酐溶液在几分钟内缓慢给药[1,4]。必须避免快速给药，因为它可能引起呕吐和疼痛[1]。

初始稳定后，持续葡萄糖输注至关重要。应开始2.5-5%右旋糖酐（0.1-0.3 g/kg/hr）的维持输注，以维持血糖浓度在80-120 mg/dl之间[5,6]。对于严重低血糖的猫，可以口服葡萄糖（玉米糖浆或蜂蜜），虽然效果短暂，应立即给予食物[7]。

长期管理取决于潜在病因[3]。对于胰岛素瘤，手术切除是确定性治疗，医学管理包括频繁少量进餐、糖皮质激素和难治性病例的二氮嗪[3]。糖尿病患畜需要仔细调整胰岛素和饮食调整[2]。建议第一个月每周监测，然后每两周一次，逐渐过渡到每月一次[8]。

### Sources
[1] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings
[2] The latest management recommendations for cats and dogs with nonketotic diabetes mellitus: https://www.dvm360.com/view/latest-management-recommendations-cats-and-dogs-with-nonketotic-diabetes-mellitus
[3] Unusual and uncommon endocrine disorders (Proceedings): https://www.dvm360.com/view/unusual-and-uncommon-endocrine-disorders-proceedings
[4] Diabetic crises: Recognition and management (Proceedings): https://www.dvm360.com/view/diabetic-crises-recognition-and-management-proceedings
[5] Guidelines for daily fluid therapy planning: When the going gets tough (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-when-going-gets-tough-proceedings
[6] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[7] Managing complications in diabetic cats: https://www.dvm360.com/view/managing-complications-diabetic-cats
[8] What's new in small-animal drug therapy (Proceedings): https://www.dvm360.com/view/whats-new-small-animal-drug-therapy-proceedings

## 鉴别诊断与预后

### 鉴别诊断

低血糖性脑病必须与引起犬猫癫痫发作和神经功能障碍的其他疾病相鉴别[1]。主要考虑因素包括特发性癫痫，特别是在1-5岁的动物中，因为这是最常见的无潜在代谢原因的癫痫发作障碍[1]。

其他代谢性脑病，特别是肝性脑病，表现出类似的意识改变、癫痫发作和行为改变[2]。肝性脑病通常影响患有门体分流或肝病的动物，引起高氨血症和神经学症状[2]。其他代谢性鉴别诊断包括低钙血症、低钠血症和尿毒性脑病[1]。

必须排除病毒性、细菌性或原生动物性脑炎等传染性原因，特别是在幼年动物或伴有发热和脑脊液细胞增多症的动物中[1]。毒素暴露，包括犬摄入木糖醇，可引起急性低血糖和癫痫发作[3]。应考虑结构性脑部病变如肿瘤或创伤，特别是在老年动物或存在局灶性神经功能缺损的动物中[1]。

### 预后

低血糖性脑病的预后在很大程度上取决于潜在原因和低血糖的严重程度。具有可逆原因（如胰岛素过量或饮食不当）的动物，通过及时补充葡萄糖通常预后良好[3]。

然而，严重低血糖（< 30 mg/dL）死亡风险增加，如果持续时间延长可能导致永久性神经损伤[3,4]。低血糖的持续时间至关重要 - 延长时间可因依赖葡萄糖的神经元代谢而导致不可逆的脑损伤[3]。

患有幼年低血糖的玩具品种幼犬通常预后良好，因为肝脏成熟度发展，通常在4-6月龄时缓解[2]。相反，继发于胰岛素瘤或严重肝病的低血糖预后更为谨慎，需要对潜在疾病进行持续管理[2,3]。

### Sources
[1] Seizures: Forming the differential diagnoses list (Proceedings): https://www.dvm360.com/view/seizures-forming-differential-diagnoses-list-proceedings
[2] Congenital and Inherited Cerebral Disorders in Animals - Nervous System - Merck Veterinary Manual: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[3] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[4] Managing and treating sick neonates (Proceedings): https://www.dvm360.com/view/managing-and-treating-sick-neonates-proceedings

## 预防措施

预防低血糖性脑病需要全面的多方面方法，重点关注适当的胰岛素管理、避免毒素和强化客户教育[1]。最关键的预防措施涉及糖尿病患畜的精细胰岛素给药方案。主人必须接受适当的注射技术、根据胰岛素浓度选择合适的注射器以及保持进食和注射时间一致性的培训[1]。

木糖醇意识是另一个关键的预防策略，因为这种人工甜味剂在犬中以低至0.1 g/kg的剂量即可引起严重低血糖[6]。犬在已知摄入木糖醇后应住院12-24小时，因为存在迟发性低血糖风险，特别是接触口香糖时[6]。客户教育必须强调将含木糖醇产品远离宠物，包括牙膏、无糖糖和多种人类食品[6]。

家庭血糖监测系统使主人能够及早发现低血糖发作，闪现葡萄糖监测系统（FGMS）提供显著优势[2][3]。FGMS可以监测长达14天的血糖水平而无需血液样本，比传统血糖计对动物的应激更小[3]。研究表明FGMS在犬猫中的准确度为93-99%，尽管在低血糖范围内准确度稍低[3]。

定期监测方案应包括每3-6个月进行一次血糖曲线，当临床症状改变时立即进行兽医评估[1]。客户教育应全面涵盖识别早期低血糖症状，包括无力、定向障碍和癫痫发作，并建立明确的紧急方案[2]。

### Sources
[1] Diabetes Mellitus in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[2] Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[3] The flash glucose monitoring system: an invaluable tool for diabetic cats and dogs: https://www.dvm360.com/view/the-flash-glucose-monitoring-system-an-invaluable-tool-for-diabetic-cats-and-dogs
[6] Hepatotoxins in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/hepatotoxins-in-small-animals
