# 犬猫绦虫病：综合兽医指南

绦虫病是伴侣动物中最常见的寄生虫感染之一，全球数百万犬猫受其影响。本综合报告探讨了小动物临床实践中绦虫感染的关键方面，从通过摄入跳蚤传播的普遍存在的犬复孔绦虫到具有人畜共患潜力的更令人关注的棘球绦虫属。分析涵盖了影响伴侣动物的四个主要绦虫属、其涉及节肢动物和脊椎动物中间宿主的复杂生活史，以及通常促使兽医就诊的特征性黄瓜籽样孕节。通过对诊断挑战、治疗方案和预防策略的系统检查，本报告为兽医专业人员提供了在临床实践中管理这些普遍存在的寄生虫感染的循证指导。

## 疾病概述

绦虫病是由绦虫（绦虫纲）引起的寄生虫感染，影响犬和猫。这种情况涉及成体圆叶目绦虫存在于小肠内，受感染的动物在其粪便中排出含卵的孕节[1]。伴侣动物中最常见的绦虫包括犬复孔绦虫、带属绦虫、中绦虫属和棘球绦虫属[1][2]。

从流行病学角度看，绦虫病在不同地理区域表现出不同的患病率模式。犬复孔绦虫被认为是犬猫最常见的绦虫，呈世界性分布[2]。在整个美洲，报告的患病率在犬中为4-60%，在猫中为1.8-52.7%[1]。地理分布差异显著，犬复孔绦虫和带属绦虫在整个北美都有发现，而棘球绦虫属主要限于阿拉斯加、美国中北部、中西部和西南部以及加拿大部分地区[1][2]。

宿主-寄生虫关系涉及需要特定中间宿主的间接生活史。犬和猫作为终宿主，通过摄入含有幼虫囊的中间宿主而感染[2]。潜伏期因物种而异，犬复孔绦虫在感染后2-3周开始排出孕节，而带属和棘球绦虫属可能需要1-2个月[1]。

### Sources

[1] An overview of cestode infections in dogs and cats: https://www.dvm360.com/view/overview-cestode-infections-dogs-and-cats
[2] Merck Veterinary Manual Table: Cestodes of Dogs and Cats in North America: https://www.merckvetmanual.com/multimedia/table/cestodes-of-dogs-and-cats-in-north-america

## 常见病原体及其生活史

影响犬猫的主要绦虫种类包括四个主要属，每个属都具有独特的形态特征和需要中间宿主的复杂生活史[1]。

**犬复孔绦虫**是全球犬猫最常见的绦虫[1][2]。该物种长15-70厘米，具有黄瓜籽样的节片，每个节片在每个侧缘附近有一个孔[1]。犬猫在梳理毛发时摄入感染的跳蚤或虱子而获得感染，这使得即使是圈养的室内宠物也易受感染[2]。

**带属绦虫**通过摄入含有中绦期幼虫的受感染猎物动物而感染犬猫[1]。带状带绦虫主要通过受感染的啮齿动物影响猫，而豆状带绦虫通常通过兔子和野兔感染犬[1]。成体带绦虫根据物种不同，长度从20厘米到5米不等[1]。

**棘球绦虫属**代表了重要的公共卫生问题。细粒棘球绦虫复合种（2-6毫米，3-5个节片）和多房棘球绦虫（1.2-2.7毫米，2-4个节片）都具有双排顶突钩[1]。犬分别通过摄入受感染的有蹄类动物或啮齿动物的内脏而感染[1]。

**中绦虫属**的生活史尚未完全了解，但怀疑有节肢动物中间宿主[1]。成体长10厘米，宽2-5毫米，特征是有四个吸盘但没有顶突或钩[1]。

### Sources
[1] Tapeworms in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/tapeworms-in-dogs-and-cats
[2] Gastrointestinal Parasites of Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs

## 临床表现与诊断

犬猫绦虫病在大多数情况下通常表现出最小的临床症状。居住在小肠中的成体绦虫很少引起严重疾病，尽管一些动物可能表现出消瘦、精神不振、易怒、食欲无常和毛发粗糙[1]。更严重的病例可表现为腹痛、轻度腹泻，罕见肠套叠、肠梗阻、消瘦或癫痫发作[1]。

最常见的临床表现是主人在肛周区域、寝具或粪便材料中观察到活动的孕节[2]。新鲜的犬复孔绦虫孕节呈黄瓜籽状，边缘圆润，而带属绦虫孕节更呈矩形，边缘锐利[2]。干燥后，这些节片失去其特征性形状，看起来像米粒或芝麻籽[2]。

诊断主要依赖于在粪便中识别孕节或通过粪便浮选法识别卵[1][2]。然而，粪便浮选方法的敏感性较低，因为孕节和卵在粪便材料中呈局部分布[1][2]。干燥的孕节可以在生理盐水中重新水合，并在显微镜下检查特征性卵[2]。棘球绦虫属感染只能通过粪便浮选法识别，因为孕节太小无法肉眼检测[2]。可能需要PCR检测来区分带属和棘球绦虫属的卵[1]。在某些地区有棘球绦虫属的粪便抗原检测[1]。

### Sources
[1] Tapeworms in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/tapeworms-in-dogs-and-cats
[2] An overview of cestode infections in dogs and cats: https://www.dvm360.com/view/overview-cestode-infections-dogs-and-cats

## 治疗与预防

**药物干预**

吡喹酮被认为是犬猫大多数绦虫感染的首选治疗方法，因为它对犬复孔绦虫、带属绦虫和棘球绦虫属具有高效性[1]。标准剂量为5-12.5 mg/kg口服一次，尽管一些来源建议对某些感染使用高达25 mg/kg的剂量[2]。依西太尔（5.5 mg/kg口服一次）对犬复孔绦虫和特定的带属绦虫也有效，但与吡喹酮相比谱较窄[2]。

芬苯达唑（50 mg/kg每日一次，连续3天）对带属绦虫有效，但对犬复孔绦虫明显无效，且未标明对棘球绦虫属有效[1]。最近的报告表明，某些犬复孔绦虫种群对吡喹酮和依西太尔产生耐药性，需要硝硫氰酯或复方产品等替代治疗[2]。

**预防措施**

有效的预防需要全面的跳蚤控制，因为犬复孔绦虫的传播是通过摄入跳蚤发生的[1]。含有吡喹酮的每月心丝虫预防药物提供对绦虫感染的持续保护[6]。在棘球绦虫属流行地区，犬应每4-6周接受一次吡喹酮治疗[2]。

环境管理包括通过将猫养在室内和犬拴绳或圈养来防止捕食和食腐[1]。定期清除粪便和适当的卫生措施可减少环境中感染性卵的污染[7]。绦虫感染没有常规的疫苗接种方案，因此通过药物和环境控制进行寄生虫预防至关重要[2]。

### Sources

[1] DVM 360 An overview of cestode infections in dogs and cats: https://www.dvm360.com/view/overview-cestode-infections-dogs-and-cats
[2] Merck Veterinary Manual Tapeworms in Dogs and Cats - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/tapeworms-in-dogs-and-cats
[6] The ABCs of Tapeworm treatment and prevention ...: https://www.dvm360.com/view/abcs-tapeworm-treatment-and-prevention-sponsored-virbac-animal-health
[7] Helping protect the bond between veterinary clients and ...: https://www.dvm360.com/view/helping-protect-bond-between-veterinary-clients-and-pets-through-parasite-control

## 鉴别诊断与预后

### 鉴别诊断

绦虫病必须与其他具有相似临床表现的其他胃肠道疾病相鉴别[1]。主要的鉴别诊断包括其他寄生虫感染，如蛔虫、钩虫和鞭虫，这些可能引起类似的胃肠道症状，包括腹泻、呕吐和腹部不适[1]。

不同绦虫种类之间的区分因素对于正确治疗至关重要。犬复孔绦虫节片呈黄瓜籽样孕节，孔位于每个侧缘中部附近，而带属绦虫缺乏独特的黄瓜籽外观[1]。棘球绦虫属产生的成虫（2-6毫米长）比其他绦虫小得多，需要PCR检测方法进行物种鉴定，因为它们的卵在显微镜下无法与带属绦虫区分[1]。

当存在胃肠道症状时，在鉴别诊断中也应考虑非寄生虫疾病，如炎症性肠病、饮食不当和食物过敏[1]。此外，中绦虫属可以通过其独特的生殖孔位置（中线腹侧）和孕节中存在子宫旁器官来区分[1]。

### 预后与结果

大多数犬猫肠道绦虫感染在适当治疗下的预后极好[1]。肠道中的成体绦虫很少引起严重疾病，临床症状在出现时通常较轻微[1]。大多数感染对批准的驱虫治疗反应良好，包括吡喹酮、依西太尔和芬苯达唑[1]。

然而，在某些情况下可能会出现并发症。罕见地，重度感染可导致肠套叠、肠梗阻或严重消瘦[1]。对于棘球绦虫属等物种，预后变得更加谨慎，它们构成重大的公共卫生风险，并可能在犬中引起泡型棘球蚴病[1]。中绦虫属引起的腹膜幼虫绦虫病代表另一种具有不同结果的潜在并发症[1]。

### Sources

[1] Tapeworms in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/gastrointestinal-parasites-of-small-animals/tapeworms-in-dogs-and-cats
