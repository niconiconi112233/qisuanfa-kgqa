# 伴侣动物汉森I型椎间盘疾病

汉森I型椎间盘疾病是影响伴侣动物，特别是软骨营养障碍性犬种的最重要神经系统疾病之一。这种急性脊柱疾病涉及退变的椎间盘物质突入椎管，导致压迫和潜在的永久性脊髓损伤。腊肠犬的终生患病率为15.3%，法国斗牛犬的患病几率比混种犬高21.1倍，因此该疾病需要兽医从业者全面了解。本报告从病理生理学到治疗结果，全面探讨了临床谱系，涉及区分内科和外科手术候选者的诊断方法、在适当病例中达到90%恢复率的循证治疗方案，以及针对高风险品种的关键预防策略。

## 疾病概述与流行病学

汉森I型椎间盘疾病（IVDD）是一种病理性疾病，其特征是退变的髓核通过纤维环急性突入椎管[1]。这种情况与汉森II型IVDD不同，后者涉及退变纤维环的突出，而非髓核的突出[1]。

I型IVDD主要影响软骨营养障碍性品种，这些品种的椎间盘退变在出生后不久即开始[5]。该疾病通常在2岁以上犬中表现，与II型IVDD形成对比，后者更常见于非软骨营养障碍性品种的老年犬[5]。临床表现可能差异显著，急性病例由于突然压迫而类似"脊髓中风"[1]。

流行病学数据显示显著的品种易感性。腊肠犬的终生患病率最高，为15.3%，其次是法国斗牛犬（8.4%）和比格犬（6.6%）[3]。在纯种犬中，法国斗牛犬与混种犬相比，患IVDD的比值比最高（21.1）[3]。雄性犬、玩具犬和小型犬以及超重犬患该疾病的几率显著增加[3]。

伴侣犬的总体终生患病率为1.2%，诊断通常发生在约10.4岁[3]。软骨营养障碍性品种由于早期椎间盘退变的遗传易感性而特别易患[5]。在猫中，IVDD患病率随年龄增长而显著增加，胸椎和颈椎椎间盘退变的几率最高[2]。

### Sources
[1] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified
[2] The prevalence of intervertebral disc degeneration in the ...: https://avmajournals.avma.org/view/journals/ajvr/85/12/ajvr.24.04.0095.xml
[3] 43517 companion dogs in the United States in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.08.0553.xml
[5] 43517 companion dogs in the United States: https://avmajournals.avma.org/downloadpdf/view/journals/javma/263/5/javma.24.08.0553.pdf

## 病理生理学与临床表现

汉森I型椎间盘疾病涉及椎间盘随年龄发生的软骨样退变，其中髓核被透明软骨侵入并钙化[1]。退变的椎间盘失去减震能力，而纤维环出现裂缝并变弱[1]。这导致钙化的髓核物质通过纤维环急性突入椎管，引起脊髓压迫和挫伤[1]。

病理生理学涉及七种损伤机制：解剖压迫、快速力引起的震荡、持续性压迫、继发性水肿的缺氧缺血、供氧不足引起的炎症、影响内皮功能的微循环障碍以及电磁离子通道变化[6]。这些机制导致椎间盘突出引起原发性损伤和炎症级联反应及血管损害引起的继发性损伤。

临床症状反映病变位置和严重程度[1]。胸腰椎表现从脊柱疼痛发展到共济失调、轻截瘫、截瘫，最终痛觉丧失[1]。大多数犬表现为上运动神经元体征，病变尾部皮肤躯干反射消失[1]。神经功能障碍分为1级（仅疼痛）至5级（截瘫伴痛觉丧失）[1][2]。颈椎病变通常表现为严重颈部疼痛，常伴有神经根体征导致前肢跛行[1]。约10%的5级犬发展为致命性上行性脊髓软化症[1]。

### Sources

[1] Treating acute disk herniations (Proceedings): https://www.dvm360.com/view/treating-acute-disk-herniations-proceedings
[2] Surgical considerations for intervertebral disk disease (Proceedings): https://www.dvm360.com/view/surgical-considerations-intervertebral-disk-disease-proceedings  
[3] Managing acutely paralyzed patients with disc herniation or spinal cord injury (Proceedings): https://www.dvm360.com/view/managing-acutely-paralyzed-patients-with-disc-herniation-or-spinal-cord-injury-proceedings

## 诊断方法

神经系统检查是诊断汉森I型IVDD的基石。受影响的犬通常表现为分级神经功能障碍，范围从仅背部疼痛到完全截瘫[1]。严重程度使用标准化分级系统分类，从1级（仅背部疼痛）到5级（截瘫无深痛觉）[1]。

普通X线摄影的诊断价值有限，特别是在软骨营养障碍性品种中，即使无症状动物也常见椎间盘钙化[1]。调查X线片仅在50-60%的椎间盘突出中能准确识别确切位置，不应仅基于调查X线片做出明确诊断[9]。然而，X线片可能显示椎间盘间隙变窄、椎管内钙化不透明影，并有助于排除椎间盘炎和骨肿瘤[6][9]。

先进影像学对明确诊断和手术规划至关重要。MRI和CT提供脊髓压迫的优越可视化，并有助于定位病变[1][6][9]。CT能安全、敏感、快速地识别钙化椎间盘物质，但非钙化物质可能不可见[9]。MRI提供对钙化和非钙化椎间盘物质的全面评估[9]。两种方法均可评估脊髓压迫程度并识别相关的突出椎间盘[6][9]。

深痛觉的存在与否是最关键的预后指标[1]。通过捏骨而非皮肤来刺激深痛觉感受器进行评估，吠叫或转头等行为反应表明伤害感受完整[6]。

### Sources
[1] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[6] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals
[8] Clinical Exposures: Intervertebral disk disease: An unusual cause of a cat's lameness and tail weakness: https://www.dvm360.com/view/clinical-exposures-intervertebral-disk-disease-unusual-cause-cats-lameness-and-tail-weakness
[9] Treating acute disk herniations (Proceedings): https://www.dvm360.com/view/treating-acute-disk-herniations-proceedings

## 治疗策略与预后

汉森I型IVDD的管理主要取决于神经学分级，有内科和外科两种选择[1]。对于1-2级（仅疼痛或可行走轻截瘫），两种方法均达到90%的恢复率[1]。然而，随着严重程度增加，手术结果逐渐优于内科管理：3级恢复率为90%对70%，4级手术成功率为80-90%对内科管理50%[1]。

保守治疗以严格笼养休息4-6周为核心，结合多模式疼痛控制[1,2]。使用低剂量皮质类固醇（0.5-1 mg/kg）或NSAIDs的抗炎治疗是基础，辅以阿片类药物、加巴喷丁和肌肉松弛剂[2]。3级患者需要膀胱管理和住院监测神经功能恶化[2]。

手术干预仍然是4-5级的金标准，半椎板切除术是胸腰椎突出的标准方法[3]。虽然背侧椎板切除术加部分椎间盘切除术通常被描述为最常用的技术，但在特定情况下可能需要椎间孔切开术或稳定术[3]。深痛觉完整的犬预后良好（85-95%恢复率），而没有深痛觉的犬恢复几率显著降低[3]。手术时间对5级病例至关重要：48小时内干预恢复率为60%，而一周后低于5%[1]。物理康复加速恢复，平均行走时间从10天（轻度病例）到51天（截瘫患者）不等[1]。

### Sources
[1] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[2] Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease
[3] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals

## 预防措施

体重管理对预防汉森I型IVDD至关重要，超重犬的风险增加1.67倍[1]。客户教育应强调通过控制喂养和定期兽医监测体重和体况评分来维持理想体况。

活动限制对高风险品种至关重要，特别是腊肠犬和法国斗牛犬等软骨营养障碍性犬[1]。生活方式调整包括避免高强度活动、从家具上跳下和爬楼梯。安装家具通道坡道和提供受控的低强度运动可减少脊柱压力[2]。12号染色体上携带FGF4逆转录基因的软骨营养障碍性品种面临最高风险，需要特定的基于品种的预防策略[3]。

对于高风险品种的雄性犬，绝育时间可能影响IVDD发展。在威尔士柯基犬中，6个月前绝育的雄性犬IVDD发生率从3%增加到18%，而雌性和腊肠犬早期绝育未显示风险增加[4]。

长期监测方案应包括高风险品种的半年一次检查、体况评估和神经学筛查。与自制饮食相比，商业日粮具有保护作用，表明适当营养在预防中起作用[1]。早期保守干预，包括严格笼养休息2-4周和适当疼痛管理，可在许多病例中避免手术干预[2]。

### Sources

[1] Demographic and lifestyle characteristics impact lifetime prevalence of owner-reported intervertebral disc disease: 43,517 companion dogs in the United States: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.08.0553.xml

[2] Saved from the sidelines: Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease

[3] DVM opportunities stem from dairy farm biosecurity: https://www.dvm360.com/view/dvm-opportunities-stem-dairy-farm-biosecurity

[4] Study gauges best canine sterilization ages by breed and gender: https://www.dvm360.com/view/study-gauges-best-canine-sterilization-ages-by-breed-and-gender
