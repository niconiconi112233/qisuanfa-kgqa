# 犬猫心源性肺水肿

心源性肺水肿是一种危重的兽医急症，其特征是由于左侧心力衰竭导致血管外肺水异常积聚。当肺毛细血管压力升高超过心脏的代偿机制时，就会发生这种危及生命的情况，导致液体渗漏到肺组织中。早期识别至关重要，因为犬和猫的临床表现差异显著--犬通常表现为咳嗽和端坐呼吸，而猫则表现为轻微的呼吸急促且很少咳嗽。本报告探讨了综合管理方法，包括使用胸部X线和超声心动图的快速诊断方案、结合利尿剂和氧疗的积极治疗策略以及关键的鉴别诊断考虑因素。了解这些物种特异性模式和循证干预措施对于伴侣动物成功的急诊管理和长期心脏护理至关重要。

## 疾病概述与病理生理学

心源性肺水肿被定义为因左侧心力衰竭引起的肺毛细血管静水压升高导致的血管外肺水异常积聚[1]。当肺毛细血管与间质之间的Starling力（静水压和胶体渗透压）平衡被破坏，有利于液体过滤进入肺实质时，就会发生这种情况[1]。

病理生理学核心是随着左心疾病恶化，左房压力升高。当左心室的代偿机制不堪重负时，升高的左心室舒张压通过开放的房室瓣逆向传导至左心房、肺静脉和毛细血管[7]。这种增加的肺毛细血管静水压导致液体渗出，首先进入肺间质，然后随着压力严重增加而进入肺泡[7]。

根据一个资料来源，心源性肺水肿的发展分为三个不同阶段[9]。最初，水肿形成促使淋巴管募集和肥大，暂时管理增加的液体负荷[9]。然而，随着静水压继续上升超过淋巴管容量，液体在整个间质中逐渐积聚，最终压倒肺泡屏障。

犬的常见病因包括扩张型心肌病、获得性二尖瓣反流和瓣膜性心内膜炎[1]。猫的主要病因是肥厚型心肌病和限制型心肌病[7]。该疾病仅在存在严重、压倒性的心脏病时发生，因为心脏通过容量超负荷（偏心性肥大）和压力超负荷（向心性肥大）等机制对较轻度的疾病有极好的代偿能力[7]。

### Sources

[1] Pulmonary edema (Proceedings) - dvm360: https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[2] Dyspneic cats: triage and differentiation of cardiogenic versus noncardiogenic causes (Proceedings): https://www.dvm360.com/view/dyspneic-cats-triage-and-differentiation-cardiogenic-versus-noncardiogenic-causes-proceedings
[3] Non-cardiogenic pulmonary edema (Proceedings): https://www.dvm360.com/view/non-cardiogenic-pulmonary-edema-proceedings
[4] Geriatric cardiology: The role of the ECG (Proceedings): https://www.dvm360.com/view/geriatric-cardiology-role-ecg-proceedings
[5] Heart Failure in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/en/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 临床表现与诊断方法

心源性肺水肿的临床症状在犬和猫之间有明显差异[1]。在犬中，典型症状包括呼吸急促、端坐呼吸、呼吸窘迫和咳嗽，这是由肺水肿或左心房压迫左主支气管引起的[1][2]。心源性咳嗽特征为柔和，可与气管塌陷的响亮鹅鸣咳嗽区分[2]。犬通常有心内膜炎引起的心脏杂音病史[1]。

患有心源性水肿的猫很少咳嗽，更常见表现为主人可能注意不到的轻微呼吸急促/呼吸困难以及食欲不振[2]。许多猫除了急性发作呼吸窘迫外没有前驱症状[1]。大多数患有心源性肺水肿的猫体温过低，有些可能有甲状腺肿大[1]。

体格检查显示两个物种都有呼吸急促和呼吸窘迫[1][2]。听诊时可能闻及肺部湿啰音，但其缺失并不能排除轻度心源性水肿[2]。心脏异常包括杂音、奔马律或心律失常，通常心率快，脉搏质量弱[1]。颈静脉扩张或腹水可能表明双心室衰竭[1]。患有扩张型心肌病的猫通常因肺水肿和/或胸腔积液而出现严重呼吸道症状，临床症状往往快速进展[3]。

胸部X光是首选的诊断检查[1]。在犬中，X光显示心脏增大、肺静脉扩张以及从肺门到尾背部的间质性至肺泡浸润[1][2]。在猫中，心源性肺水肿没有典型的分布模式，心脏大小可能被掩盖，通常需要超声心动图进行评估[2]。其他诊断包括超声心动图、心电图分析和血压测量[1][2]。NT-proBNP有助于区分心脏和呼吸原因引起的呼吸困难，特别是在猫中[4]。

### Sources
[1] Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[2] Back to basics: clinical cardiovascular exam and diagnostic testing (Proceedings): https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings
[3] Dilated Cardiomyopathy in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/dilated-cardiomyopathy-in-dogs-and-cats
[4] Lecture Link: The NT-proBNP assay: A portent of heart health: https://www.dvm360.com/view/lecture-link-nt-probnp-assay-portent-heart-health

## 治疗选择

心源性肺水肿的治疗需要立即、积极的干预，重点是降低前负荷、支持氧合和促进利尿[1]。基础治疗结合呋塞米（初始4-8 mg/kg静脉注射，然后每1-6小时2-4 mg/kg）、补充氧气和血管扩张剂以快速动员肺液[1,2]。

**药物干预**包括袢利尿剂作为一线治疗，最常用的是呋塞米。对于呋塞米耐药病例，托拉塞米（每24小时0.13-0.4 mg/kg）提供10-20倍的更强效力且作用时间更长[2]。血管扩张剂如硝酸甘油软膏（每8小时局部涂抹0.25-1英寸）或硝普钠（静脉注射2-10 μg/kg/min）可降低静脉压力和肺充血[1]。ACE抑制剂如依那普利提供额外的后负荷降低和心脏保护作用。

**非药物方法**集中在氧疗和减轻压力。旁流氧气、鼻导管或氧舱在避免患者压力的同时维持充分氧合[1]。持续气道正压通气在减少急性病例的利尿剂需求和改善临床参数方面显示出前景[3]。

**急性与慢性表现的管理差异显著**。急性病例需要积极的静脉利尿剂治疗、立即氧气支持和仔细的血压监测以防止低血压[1]。慢性管理包括口服维持治疗，使用较低剂量的呋塞米（2-6 mg/kg BID-TID）、螺内酯用于心脏保护和饮食钠限制[1]。使用氢氯噻嗪进行连续肾单位阻断可能对难治性慢性病例有益[2]。

### Sources
[1] Pulmonary edema (Proceedings): https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[2] Diuretics for Use in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/diuretics-for-use-in-animals
[3] Continuous positive airway pressure ventilation in dogs with acute cardiogenic pulmonary edema: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0244.xml

## 鉴别诊断与疾病监测

将心源性肺水肿与其他呼吸系统疾病区分开来需要仔细评估多个临床和放射学因素[1][2]。非心源性肺水肿（NCPE）是最具挑战性的鉴别诊断，通常需要根据潜在病因和分布模式进行区分[2]。

**具有重叠症状的关键鉴别诊断**

非心源性肺水肿通常影响尾背侧肺野，呈对称性外周分布，与心源性水肿的肺门周围或弥漫性模式形成对比[2][3]。NCPE通常由头部创伤、电击或上呼吸道梗阻引起，表现为急性发作，而心源性水肿则是阶段性进展[2][3]。

胸腔积液需要胸腔穿刺术进行鉴别，而肺炎等原发性呼吸系统疾病则显示出与心脏原因不同的腹侧分布模式[3][5]。猫呈现独特的挑战，因为与犬典型的肺门周围表现相比，心源性肺水肿显示可变的分布模式[1][5]。

**鉴别放射学因素**

心源性病例通常表现为心脏增大、肺静脉扩张和背侧/肺门浸润，而非心源性病例缺乏心脏增大[3][4]。空气支气管征的存在和特定的分布模式有助于区分各种病因[5]。

**长期监测策略**

连续呼吸率监测提供关键的持续评估，睡眠呼吸率>30次/分钟表明需要关注[6][9]。家庭监测呼吸用力，结合定期评估体重和肾功能参数，能够早期发现失代偿[10]。定期胸部X光有助于跟踪治疗反应并识别需要调整干预措施的并发症[4]。

### Sources
[1] Radiographic findings of cardiopulmonary structures: https://avmajournals.avma.org/view/journals/ajvr/84/9/ajvr.23.01.0017.xml
[2] Non-cardiogenic pulmonary edema: https://www.dvm360.com/view/non-cardiogenic-pulmonary-edema-proceedings
[3] Pulmonary edema: https://www.dvm360.com/view/pulmonary-edema-proceedings-0
[4] The buildup of pulmonary edema: https://www.dvm360.com/view/the-build-up-of-pulmonary-edema
[5] Radiographic evaluation of pulmonary patterns: https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[6] Monitoring the Critically Ill Small Animal: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20

## 预防、预后和并发症

### 预防措施

心源性肺水肿的预防侧重于早期识别和管理潜在的心脏疾病。患有肥厚型心肌病的猫在适当管理下，肺水肿发作后可存活超过两年[5]。不应给有明显充血性心力衰竭迹象的猫进行麻醉[5]。

对于已有心脏病的宠物，定期心血管监测至关重要。环境管理包括减轻压力和保持最佳体重。高危患者应避免可能诱发心脏失代偿的过度劳累和热暴露[5]。

### 预后与生存率

心源性肺水肿的预后因潜在心脏病和治疗反应而有显著差异。大多数患有扩张型心肌病的犬在诊断后6个月至2年内死亡[5]。一些病情严重的犬经治疗后显著改善，可舒适地生活数月或数年，而其他犬则无法住院初期的48小时[5]。

不同研究报告的1年生存率在3%至54%之间变化，爱尔兰猎狼犬报告的百分比最高[5]。据报道，杜宾犬的DCM预后通常较差，而可卡犬的预后通常较好[5]。

### 治疗相关并发症

当遇到呋塞米耐药时，托拉塞米用于治疗犬猫的心源性肺水肿[7]。潜在的并发症包括电解质失衡、脱水和肾前性氮质血症。当利尿剂与ACE抑制剂或NSAIDs同时使用时，氮质血症的风险增加[7]。

在犬的慢性CHF治疗中添加螺内酯可能改善生存率，但可引起高钾血症，特别是与ACE抑制剂联合使用时[7]。据报道，接受螺内酯的猫出现面部擦伤[7]。

### Sources

[5] Anesthetic management of small animals with preexisting cardiac conditions: https://www.dvm360.com/view/anesthetic-management-small-animals-with-preexisting-cardiac-conditions-proceedings
[7] Diuretics for Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/diuretics-for-use-in-animals
