# 伴侣动物鼻部色素减退症

鼻部色素减退症是一种影响犬猫的重要皮肤病，其特征为鼻镜及周围组织的黑色素流失。该病症包含多种病因，从良性的季节性变化到需要积极干预的严重免疫介导疾病不等。其临床重要性不仅限于美容问题，因为某些类型会使动物易患日光诱导性肿瘤，并可能提示潜在的系统自身免疫过程。

本报告通过对疾病机制、诊断方法和治疗策略的综合分析，系统性地探讨了鼻部色素减退症。重点关注领域包括北极犬种和柯利犬的品种特异性易感性、季节性"雪鼻"与永久性免疫介导疾病的鉴别，以及盘状红斑狼疮和眼皮肤综合征等疾病的循证治疗方案。分析强调了在小动物兽医实践中实现最佳临床结果所必需的实用诊断工作流程和长期管理策略。

## 疾病概述

鼻部色素减退症是一种影响犬猫的皮肤病，其特征为鼻镜及周围黏膜皮肤交界处的色素（黑色素）流失[1]。该病症代表一组异质性疾病，具有不同的潜在病理生理机制，从免疫介导的黑素细胞破坏到季节性环境影响。

存在两种主要类型：季节性和永久性色素减退症[1,4]。季节性鼻部脱色素，通常称为"雪鼻"，发生在特定品种中，包括西伯利亚哈士奇、拉布拉多寻回犬、金毛寻回犬和伯尔尼山地犬，表现为冬季色素流失，春季和夏季重新着色[1]。永久性色素减退症通常由免疫介导疾病引起，如白癜风、盘状红斑狼疮或眼皮肤综合征。

品种易感性因潜在病因而异。德国牧羊犬对影响鼻部色素的黏膜皮肤脓皮病表现出更高的易感性[1]。北极犬种对季节性脱色素表现出遗传易感性[1]。柯利犬和德国牧羊犬易患盘状红斑狼疮，而西伯利亚哈士奇、秋田犬、萨摩耶犬和松狮犬患眼皮肤综合征的风险增加[1,4]。

发病年龄取决于具体疾病，季节性色素减退症通常在成年犬中表现，而免疫介导疾病可发生在各个生命阶段[4]。流行病学数据仍然有限，尽管季节性鼻部脱色素在易感品种中似乎相对常见。

### Sources

[1] Diseases of the nasal planum (Proceedings): https://www.dvm360.com/view/diseases-nasal-planum-proceedings
[2] Watch for these red flags in your veterinary derm exams: https://www.dvm360.com/view/watch-for-these-red-flags-in-your-veterinary-derm-exams
[3] Allergy mimickers (Proceedings): https://www.dvm360.com/view/allergy-mimickers-proceedings-0
[4] Nose-itis (Proceedings): https://www.dvm360.com/view/nose-itis-proceedings

## 病因和临床表现

伴侣动物的鼻部色素减退症涵盖了一系列复杂的病因因素和临床表现。该病症的病因包括多种影响鼻镜黑素细胞功能和存活的病理生理机制。

**特发性原因**是最常遇到的病因，无法确定潜在的疾病过程。这些病例通常表现为自发发作，伴有不同的进展模式[1]。

**免疫介导病因**构成一个重要类别，包括自身免疫疾病，如盘状红斑狼疮、白癜风和眼皮肤综合征。这些疾病涉及针对黑素细胞抗原的抗体形成，导致炎症细胞浸润和随后的黑素细胞破坏[1][2]。盘状红斑狼疮通常影响鼻镜，表现为进行性脱色素、鹅卵石结构丧失和潜在的溃疡形成[1]。

**感染性原因**可能通过慢性炎症过程促成。细菌感染，特别是由假中间葡萄球菌引起的黏膜皮肤脓皮病，可能使免疫介导疾病复杂化或模拟其表现[2]。真菌生物，包括隐球菌、曲霉菌和皮肤癣菌，可能通过持续性炎症引起继发性色素变化[2][3]。

**临床表现**通常从鼻镜的逐渐色素流失开始，通常是单侧开始，然后进展为双侧。在严重病例中，正常的鹅卵石结构可能变得模糊[1]。相关体征包括不同程度的红斑、结痂和潜在的溃疡，具体取决于潜在病因。

**物种特异性模式**显示品种易感性，柯利犬、德国牧羊犬和北方犬种常受影响[2][3]。环境因素，特别是紫外线辐射暴露，可能加剧某些疾病，导致临床症状的季节性变化[1][2]。

### Sources

[1] Merck Veterinary Manual Nasal Dermatoses of Dogs - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/nasal-dermatoses-of-dogs/nasal-dermatoses-of-dogs
[2] Diseases of the nasal planum (Proceedings): https://www.dvm360.com/view/diseases-nasal-planum-proceedings
[3] Nose-itis (Proceedings): https://www.dvm360.com/view/nose-itis-proceedings

## 诊断方法和鉴别诊断

系统性诊断评估从对鼻镜的彻底临床检查开始。关键检查发现包括评估鹅卵石结构、色素变化、对称性和病变分布[1]。正常的鹅卵石外观消失并伴有脱色素强烈提示盘状红斑狼疮（DLE），而角化过度伴有裂隙表明锌反应性皮肤病或肝皮肤综合征等疾病[2][3]。

必要的诊断测试包括皮肤刮片以排除蠕形螨病、脓疱或分泌物的细胞学检查以及细菌/真菌培养[3]。如果前鼻孔和鼻镜存在色素减退，DLE比落叶型天疱疮更有可能[1]。皮肤活检仍然是明确的诊断工具，需要组织病理学检查，对于自身免疫疾病可能还需要免疫组织化学检查[2][3]。

主要鉴别诊断包括黏膜皮肤脓皮病，表现为黏膜皮肤交界处的红斑和结痂，需要细菌培养[3]。其他鉴别诊断包括白癜风，表现为脱色素但保持正常鼻部结构[4]，以及达德利鼻/雪鼻，特征为成年发病的逐渐色素减退，可能季节性波动[4]。肿瘤性疾病如鳞状细胞癌或皮肤淋巴瘤需要活检进行明确诊断[2][3]。

系统方法涉及在活检前消除细菌感染，为病理学家提供更清晰的组织学解释，特别是在区分黏膜皮肤脓皮病和DLE时[3]。

### Sources

[1] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings
[2] Nasal Dermatoses of Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/nasal-dermatoses-of-dogs/nasal-dermatoses-of-dogs
[3] Diseases of the nasal planum (Proceedings): https://www.dvm360.com/view/diseases-nasal-planum-proceedings
[4] Nose-itis (Proceedings): https://www.dvm360.com/view/nose-itis-proceedings

## 治疗选择

鼻部色素减退症的治疗因潜在病因而有显著差异，需要全面的多模式方法[1][2]。管理的基石在于解决主要疾病过程，同时提供适当的支持性护理和环境调整。

### 日光性皮炎管理

对于鼻部日光性皮炎，每12小时外用皮质类固醇洗剂（0.1%倍他米松戊酸酯）5-7天有助于控制炎症[3]。必须严格限制阳光暴露，因为紫外线会加重脱色素并增加进展为鳞状细胞癌的风险[1][3]。外用防晒霜需要每天至少涂抹两次，但并非所有人用配方都对犬安全[3]。

### 免疫介导疾病治疗

引起鼻部色素减退的自身免疫疾病通常需要免疫抑制治疗。对于盘状红斑狼疮，治疗包括避免阳光/使用防晒霜、外用他克莫司/类固醇以及多西环素/烟酰胺组合[1]。只有严重病例需要泼尼松和/或硫唑嘌呤[1]。眼皮肤综合征需要积极治疗，包括泼尼松、硫唑嘌呤、环孢素和外用眼科皮质类固醇，因为可能导致失明[1][2]。

### 新型疗法和支持性护理

先进的治疗选择包括用于白癜风的0.1%外用他克莫司[2]，用于皮肌炎和血管炎的己酮可可碱[1]，以及维生素E补充[1]。环境调整包括气道湿化、消除刺激物和使用鼻内盐水以增加舒适度[1][2]。

### Sources

[1] Nose-itis (Proceedings) - dvm360: https://www.dvm360.com/view/nose-itis-proceedings
[2] Diseases of the nasal planum (Proceedings) - dvm360: https://www.dvm360.com/view/diseases-nasal-planum-proceedings
[3] Nasal Dermatoses in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/nasal-dermatoses-in-dogs

## 预后和临床结果

鼻部色素减退症的预后因潜在病因和受影响品种而有显著差异。犬猫中的白癜风通常对整体健康具有良好预后，脱色素主要是美容问题[1]。完全缓解很少见，而脱色素模式可能随时间波动[1]。

涉及鼻部损伤的创伤性病例在保留足够血液供应时显示出良好的结果。在适当的治疗时机下，成功干预后通常在2-3个月内发生重新着色[4]。一旦血液循环恢复，暂时性脱色素可能是完全可逆的[4]。

影响鼻部色素的免疫介导疾病需要终身管理，预后通常谨慎到一般。影响鼻镜的盘状红斑狼疮犬通常需要持续的免疫抑制治疗和光保护[7]。虽然通过适当治疗可以控制，但如果没有维持治疗，复发仍然常见[7]。

在大多数情况下，生活质量通常良好，因为鼻部色素减退主要是美容问题。然而，继发并发症包括脱色素区域对日光辐射诱导肿瘤的易感性增加[1]。相关的炎症疾病可能引起需要对症管理的不适[7]。

某些品种存在季节性变化，如"雪鼻"在温暖月份表现出自然的重新着色周期，表明这些病例的长期预后极佳。

### Sources
[1] Pigmentary Abnormalities in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/congenital-and-inherited-anomalies-of-the-integumentary-system/pigmentary-abnormalities-in-animals
[2] Successful maxilla reimplantation after traumatic injury in a dog: https://www.dvm360.com/view/successful-maxilla-reimplantation-after-traumatic-injury-dog
[3] Diseases of the nasal planum (Proceedings): https://www.dvm360.com/view/diseases-nasal-planum-proceedings
