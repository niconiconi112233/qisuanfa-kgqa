# 伴侣动物子宫积液

子宫积液代表一系列影响未绝育母犬和母猫的重要生殖系统疾病，从良性液体积聚到危及生命的子宫脓肿。该病症源于子宫囊性增生-子宫脓肿复合症，其中长期暴露于孕酮为子宫腔内细菌繁殖创造了理想条件。本报告探讨了从激素失衡到脓毒性并发症的病理生理进展，详细介绍了区分宫颈开放和宫颈闭合病例的诊断方法。治疗方案范围从通过卵巢子宫切除术的确定性手术干预到用于育种动物的医疗管理方案，每种方案都具有不同的成功率和并发症。通过选择性绝育进行预防是最有效的策略，而预后则根据宫颈通畅性和所选治疗方法而显著不同。

## 疾病概述

子宫积液包括一系列以未绝育母犬和母猫子宫腔内液体积聚为特征的病症。主要病症包括子宫积液（无菌液体）、子宫积黏液（黏液性分泌物）和子宫积脓（脓性物质）[1]。这些病症代表了子宫囊性增生-子宫脓肿复合症的不同表现形式，该复合症影响中年至老年未绝育母犬在经历多次发情周期后[2]。

子宫囊性增生（CEH）是导致子宫积液的基础病理变化[2]。这一进行性病症由孕酮介导，雌激素可能通过反复的激素暴露周期加重这一过程[2]。孕酮诱导子宫内膜腺体增殖、增大和分泌物积聚，为细菌生长创造了理想条件[2]。孕酮的作用包括抑制免疫系统、刺激子宫内膜腺体分泌、宫颈闭合阻碍引流以及减少子宫肌层收缩[3]。

病理生理学涉及非妊娠发情周期后的长期子宫内膜刺激[2]。CEH通常发生在经历一次或多次非妊娠发情周期后的老年或中年未绝育母犬中[3]。子宫积脓通常在孕酮作用最大的发情间期发展，细菌感染是预先存在的CEH的继发表现[2]。从生殖周期到生殖周期的累积效应为细菌繁殖创造了最佳环境[2]。

### Sources
[1] Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals
[2] Canine pyometra: Early recognition and diagnosis: https://www.dvm360.com/view/canine-pyometra-early-recognition-and-diagnosis
[3] Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals

## 临床表现与诊断

犬和猫的子宫积液根据宫颈通畅性表现出不同的临床症状。在宫颈闭合病例中，动物通常表现为腹部膨大、嗜睡、厌食、呕吐以及由肾功能不全引起的多饮/多尿[1]。宫颈开放或部分开放病例可能显示脓性、血性阴道分泌物以及全身性症状[1][2][3]。

体格检查显示宫颈闭合病例腹部膨大，可能伴有发热、脱水和精神沉郁[1][4]。应检查外阴以确定分泌物特征。犬比猫更常受影响，子宫积脓通常发生在中年至老年未绝育雌性动物发情后4-6周[3][4]。

诊断成像对确诊至关重要。超声检查显示子宫壁增厚，充满液体的扩张子宫角，且无妊娠迹象[4]。X线检查可能显示扩张、充满液体的子宫，在宫颈闭合病例中尤其明显[4]。

实验室检查结果包括中性粒细胞增多或中性粒细胞减少、BUN和肌酐浓度升高以及γ球蛋白增加[4]。血液学变化反映了全身性炎症反应和潜在的肾功能损害。

区分宫颈开放与宫颈闭合病例对预后和治疗紧迫性至关重要。宫颈闭合病例子宫破裂和腹膜炎风险更高，需要立即手术干预[2][3]。

### Sources
[1] Merck Veterinary Manual Clinical Investigation of Canine Reproduction Disorders: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/clinical-investigation-of-canine-reproduction-disorders
[2] Merck Veterinary Manual Reproductive Disorders of Female Cats: https://www.merckvetmanual.com/cat-owners/reproductive-disorders-of-cats/reproductive-disorders-of-female-cats
[3] MSD Veterinary Manual Reproductive Disorders of Female Dogs: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-female-dogs
[4] Merck Veterinary Manual Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals

## 治疗方案

**手术治疗**
卵巢子宫切除术仍然是子宫积脓的确定性治疗方法，兼具治疗和预防益处[1]。由于子宫壁脆弱，在操作过程中容易破裂，该手术需要谨慎的手术技术[1]。充分的腹部切口允许更安全地暴露和取出感染的子宫，最小化污染风险。术后并发症可能包括伤口感染、瘘管、局部肿胀或出血[1]。

**育种动物的医疗管理**
对于具有繁殖价值的患者，医疗方案提供了手术的替代方案。前列腺素F2-α诱导黄体溶解并促进宫颈松弛和子宫肌层收缩以排出子宫内容物[1][2]。在宫颈开放病例中成功率可达约94%[1]。使用卡麦角林和氯前列醇的联合疗法显示出优异的疗效，不良反应最小且治疗时间缩短[1]。

**抗孕激素和高级方案**
阿来司酮（10mg/kg皮下注射）阻断孕酮受体，可每5天给药一次直至病情缓解[3]。合成前列腺素氯前列醇与天然前列腺素相比，具有更好的子宫特异性且全身副作用减少[2]。

**患者稳定**
危重患者需要立即稳定治疗，包括静脉输液、杀菌性抗生素（阿莫西林-克拉维酸或青霉素/氟喹诺酮类联合用药）以及纠正电解质紊乱[1]。治疗通常在临床缓解后根据体格检查和实验室检查结果继续7-14天[1]。

### Sources

[1] Surgical and medical treatment of pyometra: https://www.dvm360.com/view/surgical-and-medical-treatment-pyometra
[2] Prevention or Termination of Pregnancy in Bitches and Queens: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/prevention-or-termination-of-pregnancy-in-bitches-and-queens
[3] Hormonal usage in canine theriogenology (Proceedings): https://www.dvm360.com/view/hormonal-usage-canine-theriogenology-proceedings-0

## 预防与预后

选择性绝育代表预防子宫积液的最有效措施。卵巢子宫切除术（OVH）和卵巢切除术（OVE）通过消除疾病发展所必需的激素刺激提供完全预防[1]。通过切除卵巢组织，消除了内源性孕酮的来源，防止子宫积脓形成[2]。

早期绝育的考虑涉及平衡益处与潜在并发症。研究表明，较早绝育的较重犬只（>25kg）可能面临尿失禁风险增加，而在6个月前早期绝育可能与关节疾病增加相关[3]。育种动物的医疗管理策略侧重于防止孕酮影响直至繁殖准备，建议在成功医疗治疗后下一个发情周期立即进行繁殖[4]。

关于预后，卵巢子宫切除术显示出优异的结果，犬的死亡率范围为0-17%，猫约为8%[5]。医疗治疗携带显著更高的复发风险，因为患者在每次随后的发情周期后仍易患子宫积脓[4]。医疗治疗的恢复率从40-90%不等，取决于疾病严重程度，治疗后繁殖成功率约为50-65%[6]。成功的手术治疗提供确定性治愈并预防复发，使其成为大多数病例的首选治疗方法。

### Sources
[1] Managing canine pyometra (Proceedings): https://www.dvm360.com/view/managing-canine-pyometra-proceedings
[2] Pyometra in the bitch (Proceedings): https://www.dvm360.com/view/pyometra-bitch-proceedings
[3] Determining the optimal age for gonadectomy of dogs and cats: https://avmajournals.avma.org/view/journals/javma/231/11/javma.231.11.1665.xml
[4] Frequently asked questions about small-animal reproduction (Proceedings): https://www.dvm360.com/view/frequently-asked-questions-about-small-animal-reproduction-proceedings
[5] Promoting access to care in pyometra treatment: pathways to collaboration between high-quality, high-volume spay-neuter clinics and private practices in: https://avmajournals.avma.org/view/journals/javma/262/7/javma.23.12.0694.xml
[6] Cystic Endometrial Hyperplasia-Pyometra Complex in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/cystic-endometrial-hyperplasia-pyometra-complex-in-small-animals
