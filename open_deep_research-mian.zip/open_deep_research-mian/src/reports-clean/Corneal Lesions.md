# 伴侣动物角膜病变

角膜病变是小动物兽医临床中最常遇到的眼科疾病之一，影响着犬和猫，其严重程度和复杂性各不相同。这些眼睛透明前表面的病理变化范围从浅表上皮缺损到可能威胁视力和眼球完整性的深基质溃疡。本综合报告探讨了伴侣动物角膜疾病的多方面性质，涵盖了从荧光素染色到先进成像技术的基本诊断方法，包括药物治疗和手术干预在内的多样化治疗模式，以及针对品种特异性易感性的关键预防策略。通过对感染性和非感染性病因、物种特异性临床表现和循证治疗方案的详细分析，本报告为兽医从业者提供了有效诊断、治疗和预防其犬猫患者角膜病变所需的知识。

## 疾病概述与流行病学

角膜病变包括影响犬和猫眼睛前部透明穹顶状结构的广泛病理变化[1]。角膜由四个不同的层次组成：浅表上皮、基质（主要由胶原蛋白组成的最厚层）、后弹力膜和内皮[4]。这些病变可分为三种主要类型：角膜溃疡（可能延伸至更深层的上皮缺损）、角膜营养不良（遗传性双侧疾病）和角膜变性（获得性单侧或双侧变化）[1][2]。

角膜溃疡是伴侣动物中最常见的角膜病理[7]。浅表溃疡仅影响上皮层，而基质溃疡延伸更深，可能进展至后弹力膜膨出（到达后弹力膜）或穿孔[1][7]。顽固性溃疡，也称为自发性慢性角膜上皮缺损（SCCED），主要发生于中老年犬，拳师犬表现出特殊易感性[1][4]。

特定角膜疾病存在显著的品种易感性[2][4]。德国牧羊犬对慢性浅表性角膜炎（血管翳）表现出极强的易感性，而波士顿梗、吉娃娃和腊肠犬通常发展为角膜内皮营养不良[2][3]。波斯猫和喜马拉雅猫对角膜坏死（一种独特的猫科疾病）表现出更高的易感性[1]。环境因素，特别是高海拔和紫外线辐射暴露，显著影响血管翳等疾病的严重程度[4]。

### Sources

[1] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[2] Canine corneal diseases: secrets for transparency greater than the federal stimulus (Proceedings): https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings
[3] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[4] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[7] Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers

## 常见病原体与病因学

犬和猫的角膜病变由感染性和非感染性原因引起，细菌病原体是最常见的感染因子。细菌性溃疡通常涉及铜绿假单胞菌和β-溶血性链球菌，特别是在伴有基质溶解的复杂病例中[1]。葡萄球菌和链球菌通常从睑板炎和继发性角膜受累中分离出来[2]。

真菌性角膜炎虽然较少见，但在犬和猫中都有记录，曲霉菌和镰刀菌是在马中常见的分离株，也可能影响小动物[2]。病毒感染，特别是猫疱疹病毒，是猫复发性角膜溃疡的重要原因，在犬中罕见，常导致角膜坏死[2]。

非感染性原因在伴侣动物角膜病理中占主导地位。结构性缺陷包括眼睑内翻、眼睑外翻和兔眼，这些都会导致机械性创伤并引起溃疡[3]。干燥性角膜结膜炎（干眼症）通常引起角膜病变，而异常睫毛（双行睫和异位睫）会造成慢性刺激和溃疡[3]。

免疫介导疾病代表另一个重要类别，其中慢性浅表性角膜炎（血管翳）在德国牧羊犬及相关品种中普遍存在[2]。与年龄相关的变化，特别是中老年犬的顽固性溃疡，是由于影响上皮附着的基底膜异常引起的[2]。

### Sources

[1] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[2] The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] Eyelids in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/eyelids-in-animals

## 临床症状与体征

角膜病变表现出多样的临床表现，这些表现因病因、物种和进展阶段而异。急性表现包括眼睑痉挛、流泪、结膜充血和畏光[1]。患者可能表现出眯眼行为和不愿睁开受影响的眼睛，这是由于眼部不适所致[2]。

**典型表现**取决于病变类型和位置。浅表溃疡表现为不规则或地图状（地图样）缺损，而较深的病变可能显示基质混浊和血管化[3]。慢性浅表性角膜炎（血管翳）表现为起源于颞侧角膜缘的双侧肉样病变，向鼻侧扩散并伴有进行性浅表血管化[1]。

**物种特异性模式**值得注意。在猫中，疱疹病毒引起的病变通常表现为树枝状（树状分支）溃疡，这是猫疱疹病毒的特征性表现[4]。角膜坏死表现为琥珀色至黑色斑块，这是猫特有的，通常伴有溃疡和血管化[4]。嗜酸性角膜炎表现为粉白色、隆起的炎性斑块，伴有角膜血管[4]。

**品种易感性**包括德国牧羊犬对慢性浅表性角膜炎的易感性，灵缇犬、比利时坦维连犬和西伯利亚哈士奇也经常受影响[1]。波斯猫和喜马拉雅猫对角膜坏死表现出更高的易感性[4]。

**进展指标**包括在肉样病变之前进展的白色浸润和加重的血管化[1]。并发症表现为角膜溶解、穿孔或伴有脓性分泌物的继发性细菌感染[3,4]。早期识别可防止威胁视力的后遗症。

### Sources

[1] Ophthalmology Challenge: A greyhound with red eyes: https://www.dvm360.com/view/ophthalmology-challenge-greyhound-with-red-eyes
[2] Ocular emergencies--what to do next: https://www.dvm360.com/view/ocular-emergencies-what-do-next
[3] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings
[4] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings

## 诊断方法

诊断角膜病变需要系统的方法，将临床检查技术与专业诊断工具相结合。初始临床评估应包括观察特征性体征，如眯眼、流泪和结膜充血，这些表明需要进一步调查[1]。

**荧光素染色**是角膜病变诊断的基石。这种水溶性染料只有在保护性上皮受损时才会附着在暴露的角膜基质上，从而清晰显示溃疡的范围[2]。在自发性慢性角膜上皮缺损（SCCED）等病例中，荧光素显示特征性染色模式，在溃疡边缘周围出现暗绿色光晕，染料在松散上皮下渗漏[1]。

**细胞学检查**提供快速诊断信息，应使用无菌棉签或刮刀从深层角膜刮取物中获得[3]。瑞氏-吉姆萨染色显示细胞碎片、炎症细胞和潜在的感染因子，而戈莫里六胺银染色专门识别真菌元素，敏感性为86%[6]。

**培养方法**对深层、溶解性或进行性溃疡至关重要。样本应在涂抹局部溶液之前收集，并在血琼脂和麦康凯琼脂上培养，并添加硫乙醇酸盐富集[2]。细菌培养有助于指导适当的抗生素治疗，这一点特别重要，因为约85%的正常眼睛存在细菌菌群[2]。

**先进诊断技术**包括使用TonoPen或TonoVet设备进行眼压测量，这有助于排除继发性青光眼[4]。希尔默泪液测试评估可能导致角膜疾病的泪液产生不足[2]。在复杂病例中，当混浊妨碍直接观察时，眼部超声可评估更深层的结构[9]。

### Sources
[1] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[2] Getting ready for the eye patient (Proceedings): https://www.dvm360.com/view/getting-ready-eye-patient-proceedings
[3] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[4] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings
[5] Corneal ulcers in general practice: https://www.dvm360.com/view/corneal-ulcers-in-general-practice
[6] Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[7] Comparison of the use of a standard cytology brush versus a ...: https://avmajournals.avma.org/view/journals/javma/259/3/javma.259.3.288.xml
[8] Chlamydial Conjunctivitis in Animals - Eye Diseases and ...: https://www.merckvetmanual.com/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals
[9] Ophthalmic anatomy and diagnostics (Proceedings): https://www.dvm360.com/view/ophthalmic-anatomy-and-diagnostics-proceedings

## 治疗选择

犬和猫角膜病变的治疗方法取决于病变类型、深度和严重程度。管理包括药物治疗、手术干预和针对特定情况的辅助护理。

**药物治疗**
对于浅表、无并发症的溃疡，局部抗生素如新霉素-杆菌肽-多粘菌素、庆大霉素或妥布霉素每日给药2-3次[1]。包括环丙沙星和氧氟沙星在内的氟喹诺酮溶液是角膜感染的首选抗生素[1]。感染性或深层溃疡需要更广谱的抗生素，如莫西沙星[2]。局部阿托品（1%）控制睫状肌痉挛并提供疼痛缓解[1]。

对于深层基质溃疡，积极的药物治疗包括频繁使用抗生素（最初每1-2小时一次）、使用血清或EDTA进行抗蛋白酶治疗，以及全身性抗炎药[1,3]。在猫疱疹相关溃疡中，治疗结合局部抗生素、三氟胸苷等抗病毒药物和口服L-赖氨酸作为病毒复制的竞争性抑制剂[1]。

**手术干预**
顽固性溃疡需要清创手术，包括在局部麻醉下使用25号针头进行线性网格角膜切开术[1,4]。当深层基质溃疡超过角膜深度的50%时，需要手术干预[3,5]。

结膜瓣移植为深层缺损提供结构支持、血液供应和即时血流[1,4]。替代手术包括角膜结膜转位瓣，该手术将透明角膜组织推进到缺损处以获得更好的视力结果[4]。生物合成材料如A-cell和BioSist作为胶原蛋白底物，而严重病例可能进行角膜移植[4]。

**辅助护理**
伊丽莎白圈可防止自伤，而疼痛管理包括局部阿托品、口服曲马多或非甾体抗炎药[1,3,5]。限制运动和频繁监测确保最佳愈合结果[3,5]。

### Sources
[1] Understanding how the cornea heals offers insights into treatment: https://www.dvm360.com/view/understanding-how-cornea-heals-offers-insights-treatment
[2] Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers
[3] Corneal disease in dogs: there is a hole in my cornea (Proceedings): https://www.dvm360.com/view/corneal-disease-dogs-there-hole-my-cornea-proceedings
[4] Corneal surgical techniques: Conjunctival pedicle grafts and beyond (Proceedings): https://www.dvm360.com/view/corneal-surgical-techniques-conjunctival-pedicle-grafts-and-beyond-proceedings
[5] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings

## 预防措施

犬和猫角膜病变的预防侧重于识别和管理易感因素。短头颅品种和具有大暴露眼窝的犬需要高度警惕，因为它们对角膜溃疡性疾病的易感性增加[1]。环境控制包括通过从宠物环境中移除潜在的异物，如木屑、碎片和尖锐材料来保护眼睛免受创伤[1]。

定期监测基础疾病至关重要。干眼（干燥性角膜结膜炎）是犬溃疡发展的最常见的易感因素，需要对高危患者进行常规泪液产生评估[1]。患有糖尿病和库欣病等代谢疾病的患者需要仔细的角膜监测，因为这些条件由于免疫反应受损而使动物易受感染性溃疡的影响[1]。

通过矫正眼睑内翻、双行睫和其他结构异常来维持适当的眼睑解剖结构，可防止慢性角膜刺激[2]。应维持疫苗接种方案以预防可能影响角膜健康的全身性疾病，核心疫苗可预防如传染性犬肝炎等可引起双侧间质性角膜炎的疾病[7]。

## 鉴别诊断

角膜病变必须与几种临床表现重叠的疾病进行鉴别。角膜水肿的主要鉴别诊断包括角膜溃疡、葡萄膜炎和青光眼，每种通常通过全面的眼科检查来区分[3,6]。

猫疱疹病毒性角膜炎需要通过角膜细胞学与肿瘤和其他感染因子进行鉴别，角膜细胞学可以通过显示特征性的嗜酸性粒细胞和肥大细胞来确认嗜酸性角膜炎[4]。荧光素染色有助于区分溃疡性和非溃疡性疾病，地理或树枝状模式是疱疹病毒感染的特征性表现[4]。

在猫中，角膜坏死表现为特征性的深色色素沉着，因为角膜色素沉着在该物种中很罕见[4,7]。当发生双侧角膜受累时，必须考虑系统性葡萄膜炎，需要在实施抗炎治疗前进行荧光素染色以排除并发溃疡[5]。

### Sources
[1] Mastering corneal ulcers (part 1): https://www.dvm360.com/view/mastering-corneal-ulcers-part-1-
[2] Eyelid disease and surgery (Proceedings): https://www.dvm360.com/view/eyelid-disease-and-surgery-proceedings
[3] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[4] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[5] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[6] Glaucoma in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/glaucoma-in-animals
[7] The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
