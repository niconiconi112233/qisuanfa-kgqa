# 伴侣动物脊柱创伤：急诊处理与临床结局

脊柱创伤是小动物兽医临床中最严重的神经系统急症之一，需要立即干预以防止永久性残疾或死亡。本综合报告 examines 了犬猫急性脊柱损伤的病理生理学、临床表现、诊断方法和治疗策略。

本报告综合了当前兽医知识，涵盖了从机动车事故到咬伤的创伤机制，特别强调了占病例50-60%的胸腰段区域。主要发现包括软骨发育不良犬的品种特异性易感性、深痛觉的关键预后重要性，以及基于证据的治疗方案。临床数据显示，保持伤害感受性的动物恢复率为80%，而深痛觉缺失超过一周的恢复率低于5%，凸显了这些急症的时间敏感性。

## 总结与临床意义

本报告揭示脊柱创伤是一种复杂的急症，需要伴侣动物快速评估和干预。胸腰段区域占大多数损伤，机动车创伤和坠落是主要机制。深痛觉是单一最重要的预后因素，保留时恢复率为80%，而缺失超过一周时恢复率低于5%。

| 因素 | 良好预后 | 不良预后 |
|--------|---------------|----------------|
| 深痛觉 | 存在 | 缺失 >48小时 |
| 恢复率 | 80% | 1周后 <5% |
| 手术时机 | 48小时内 | >1周延迟 |
| 恢复行走 | 10天（轻度病例） | 51.5+天（重度） |

治疗成功很大程度上取决于早期识别和立即稳定。8小时内给予甲泼尼龙，结合对不稳定损伤的适当手术干预，可显著改善结局。20%的多发创伤并发率要求全面的患者评估超越神经系统评估。

兽医必须优先进行快速神经分级和痛觉测试，以指导治疗决策并在脊柱损伤后的关键最初几小时内为主人提供准确的预后信息。

## 疾病概述与流行病学

脊柱创伤是指犬猫椎骨及相关脊髓结构的急性损伤，由导致神经组织压迫、撕裂、剪切、弯曲或牵张的机械力引起[1]。这种情况代表一种兽医急症，需要立即干预以保护神经功能并防止继发性损伤进展。

胸腰段（T11-L6）是最常受影响的解剖位置，占犬猫脊柱创伤病例的50-60%[1]。外部原因占主导地位，包括机动车相关损伤、高处坠落、坠落物体和投射物创伤[1][2]。咬伤是另一个重要原因，特别是在犬中[2]。内部原因包括椎间盘疾病恶化、病理性骨折和血管意外[1]。

脊柱创伤常表现为多发创伤的一部分，约20%的患者在多个脊柱水平同时存在胸腰椎骨折[1]。相关的全身性损伤通常包括气胸、肺挫伤、骨科骨折、泌尿生殖系统创伤和膈疝[1]。

神经功能障碍的严重程度与施加于脊髓组织的压迫力的速度、大小和持续时间直接相关[1]。由于户外活动增加和创伤暴露增多，年轻至中年动物最常受影响[3]。

### Sources

[1] Acute spinal cord injury - The first hour can make the difference: https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings

[2] Trauma of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/trauma-of-the-spinal-column-and-cord-in-animals

[3] Clinical signs, causes, and outcome of central cord syndrome: https://avmajournals.avma.org/view/journals/javma/262/3/javma.23.08.0478.xml

## 临床症状和体征

### 品种特异性易感性

现有内容提供了脊柱创伤表现的全面覆盖，但额外的品种模式值得纳入。软骨发育不良品种包括腊肠犬、法国斗牛犬和比格犬显示对椎间盘疾病（IVDD）的特定易感性，法国斗牛犬显示特别高的比值比发展脊柱病理学[2]。这些品种表现早期发病模式，法国斗牛犬显示中位诊断年龄为4.6岁，相比其他品种[2]。

短头品种包括英国斗牛犬由于解剖学易感性显示增加的脊柱并发症易感性[3]。螺旋尾品种如哈巴狗、斗牛犬和波士顿梗常见半椎体和相关脊柱不稳定[4]。

### 高级诊断考虑因素

除传统影像学外，全面的脊柱创伤评估需要理解品种特异性风险因素。软骨发育不良犬显示终身IVDD患病率从腊肠犬的15.3%到法国斗牛犬的8.4%不等[2]。大型品种犬包括大丹犬和杜宾犬表现独特的颈椎脊髓病模式，需要专门诊断方法[1]。

### Sources

[1] Acute spinal cord injury - The first hour can make the difference: https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[2] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals
[3] Resection via carbon dioxide laser for the treatment of canine: https://avmajournals.avma.org/view/journals/ajvr/86/5/ajvr.25.01.0004.xml
[4] Congenital and Inherited Disorders of the Nervous System in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs

## 治疗策略与管理

犬猫脊柱创伤的治疗方法包括保守和手术干预[1]。保守管理涉及严格的笼内限制6-8周，适用于神经功能缺损最小和椎体移位的病例[1]。根据患者体型、性情和损伤程度，可使用夹板进行外部固定，尽管它对轴向压缩的抵抗力有限[1]。

手术稳定适用于神经功能快速进展、顽固性疼痛、伤害感受性丧失或脊柱不稳定的患者[1]。内固定方法包括钢板和螺钉、聚甲基丙烯酸甲酯（PMMA）针和脊柱钉合[1,2]。使用螺纹针的聚甲基丙烯酸甲酯和Steinmann针固定是首选技术[1]。透视引导下的外骨骼固定提供微创稳定选择[3,4]。

药物治疗包括神经保护性甲泼尼龙琥珀酸钠（30 mg/kg IV推注，随后15 mg/kg剂量），如果在损伤后8小时内给药[1]。疼痛管理最初使用阿片类药物，添加NSAIDs作为辅助治疗，加上胃肠道保护[1]。

术后护理需要精心护理以预防并发症，包括压疮、尿路感染和肺炎[1]。结合活动范围练习的物理治疗对于维持关节活动和促进恢复至关重要[1]。

### Sources

[1] Acute spinal cord injury - The first hour can make the difference (Proceedings): https://www.dvm360.com/view/acute-spinal-cord-injury-first-hour-can-make-difference-proceedings
[2] Improving the safety of spinal fracture fixation in dogs: https://avmajournals.avma.org/view/journals/ajvr/85/1/ajvr.23.10.0245.xml
[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/81/12/ajvr.81.12.915.xml
[4] Stabilization of a vertebral fracture by a monolateral external: https://avmajournals.avma.org/view/journals/javma/260/12/javma.21.03.0137.xml

## 预后

脊柱创伤的预后根据损伤严重程度和深痛觉的存在差异很大，后者作为最重要的预后指标[1]。对于在脊柱损伤部位以下保持深痛觉的动物，适当治疗的总体恢复率约为80%[2]。

深痛觉丧失代表严重的预后征象。术前深痛觉丧失超过24-48小时的犬结果显著较差[1]。在深痛觉缺失的病例中，48小时内手术干预的恢复率约为60%，一周后降至低于5%[2]。对于脊柱损伤以下失去痛觉的猫，恢复前景不佳[3]。

恢复时间根据损伤严重程度差异很大。轻度轻瘫的犬通常在术后10天内恢复行走，而截瘫动物可能需要51.5天或更长时间[1]。其他预后因素包括损伤位置，L3-4尾侧的病变通常比T10-L3之间的病变结果更好[1]。

潜在并发症包括脊髓软化症（影响10%严重受影响犬的进行性脊髓坏死）、持续性神经功能缺损、粪便和尿失禁，以及卧床相关并发症如吸入性肺炎和压疮[1]。长期管理通常需要物理康复、膀胱管理和生活质量评估，特别是对于永久性缺损的动物。

### Sources
[1] Traumatic spinal cord injury (Proceedings): https://www.dvm360.com/view/traumatic-spinal-cord-injury-proceedings
[2] Making the cut: Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[3] Disorders of the Spinal Column and Cord in Cats: https://www.merckvetmanual.com/cat-owners/brain-spinal-cord-and-nerve-disorders-of-cats/disorders-of-the-spinal-column-and-cord-in-cats
