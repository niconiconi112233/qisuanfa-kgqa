# 伴侣动物单纯性牙冠折断

单纯性牙冠折断是兽医实践中最常见的牙齿损伤之一，影响10-29%的伴侣动物。这些折断涉及牙釉质和牙本质的损伤，没有直接暴露牙髓，但通过微观牙本质小管为细菌入侵创造了途径。尽管这些损伤通常看起来轻微且临床症状不明显，但需要及时进行兽医评估，以防止发展为严重的牙髓疾病。本报告探讨了犬猫单纯性牙冠折断的病理生理学、诊断和管理，强调基于证据的治疗方法和预防策略，以优化患者预后并维持口腔健康。

## 摘要

伴侣动物的单纯性牙冠折断呈现出一个看似复杂但需要及时干预的临床挑战，尽管症状通常不明显。暴露的牙本质小管为细菌入侵提供了直接途径，损伤后48小时内会发生明显污染。虽然猫由于其浅表牙髓腔而表现出品种特异性易感性，但犬最常见的是由创伤导致的裂齿牙折断。

明确诊断需要在麻醉下进行口腔检查并强制进行口腔内X线摄影，因为仅凭视觉评估无法可靠地确定牙髓是否受累。治疗以复合修复封闭暴露的牙本质为中心，活髓治疗仅适用于近期遭受创伤的幼年动物。适当管理时预后仍然极佳，年龄是主要的预后因素。

| 因素 | 对管理的影响 |
|--------|---------------------|
| 年龄 | 幼年动物由于牙髓腔扩大需要更积极的干预 |
| 受伤时间 | 近期折断（≤48小时）可能受益于活髓治疗 |
| 牙本质暴露深度 | 决定修复复杂性和细菌入侵风险 |

通过客户教育关于适当的咀嚼玩具和环境改造进行预防，仍然是降低折断发生率的最有效策略。

## 疾病概述

单纯性牙冠折断是影响牙齿坚硬外表面的牙齿损伤，没有直接暴露中央牙髓组织[1]。这些折断仅涉及牙釉质或同时涉及牙釉质和牙本质层，但不穿透牙齿的神经血管核心[1][3]。

折断牙齿是伴侣动物中最常见的牙齿疾病之一，在小动物实践中报告的患病率在10%至29%之间[4]。在犬中，上颌第四前臼齿（裂齿）最容易发生折断，而在猫中，上颌犬齿和裂齿都常受影响[4][5]。

这些损伤通常由创伤引起，如咀嚼硬物、事故或打架的直接冲击，或用牙齿咬住硬物[3][4]。虽然在单纯性折断中牙髓仍然受到保护，但暴露牙本质的多孔性质可能允许细菌通过牙本质小管渗透，随着时间的推移可能导致污染和感染[3][7]。

### Sources

[1] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options

[2] American Journal of Veterinary Research Evaluating periodontal probing depth and furcation involvement on the endodontic treatment of maxillary fourth premolar complicated crown-root fractures in 122 teeth in: American Journal of Veterinary Research Volume 86 Issue 2 (2025): https://avmajournals.avma.org/view/journals/ajvr/86/2/ajvr.24.09.0260.xml

[3] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals

[4] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats

[5] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth

## 常见病原体

单纯性牙冠折断虽然不直接暴露牙髓，但通过暴露的牙本质小管为细菌入侵创造了途径[1]。牙本质的多孔性质允许口腔细菌通过这些直径为0.9至2.5微米的微观通道传播，可能到达牙髓组织并引起感染[1]。

口腔细菌足够小，可以通过暴露的牙本质小管穿透并侵入单纯性牙齿折断中的牙髓[1]。这种细菌污染可导致牙髓炎并最终导致牙髓坏死，特别是在牙本质小管刚刚暴露的折断后立即发生[1]。牙本质敏感的流体动力学机制发生在细菌和碎屑进入这些小管时，刺激神经纤维并引起疼痛[1]。

当创伤暴露牙本质时，口腔细菌迅速侵入牙齿结构[5]。最新研究表明，在牙冠折断后仅48小时内，牙髓冠部就会出现明显的细菌污染和炎症的组织学迹象[1]。这种快速的细菌入侵强调了及时治疗以防止从可逆性牙髓炎发展为不可逆性牙髓炎的重要性。

暴露的牙本质为环境细菌通过牙本质小管到达牙髓提供了直接通道[3]。即使没有直接暴露牙髓，这些微观途径也允许细菌渗透，如果不治疗，最终可能导致牙髓疾病、牙齿死亡和继发并发症[1]。口腔常驻细菌与其他解剖部位的继发感染有关，证明了牙齿细菌污染的全身性影响[7]。

### Sources

[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[2] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
[3] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[4] Oral bacteria may affect conjunctival microorganisms in: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.11.0260.xml

## 临床症状和体征

**典型临床表现**

大多数患有单纯性牙冠折断的宠物不会表现出明显的疼痛或不适临床症状，它们的食欲通常保持不变[1]。这种缺乏明显症状的情况历史上导致了观望态度，但缺乏可见的痛苦并不表示没有疼痛[2]。

当出现症状时，主人可能会观察到微妙的行为变化，包括用口腔一侧咀嚼、偶尔掉落食物或不愿吃硬食物[4]。特别是在猫中，症状可能更加微妙，因为它们是隐藏不适的专家，有些会表现出摇头、过度流涎或对着食物碗嘶嘶叫[4]。

**体格检查发现**

在麻醉下进行口腔检查时，单纯性牙冠折断表现为牙本质暴露而没有直接涉及牙髓腔[2]。暴露的牙本质呈现为较暗的区域，用牙科器械探查时可能发出"乒乓"声[4]。在猫中，牙髓腔延伸至牙冠尖端几毫米内，使即使是小的折断也可能具有重要意义[4]。

由于暴露的牙本质小管，患者会经历流体动力学牙本质敏感，这是由于液体流动增加刺激牙髓A-δ神经纤维所致[2]。虽然牙髓没有直接暴露，但细菌可以通过暴露的牙本质小管传播侵入牙髓组织[2]。

**品种特异性模式**

犬的上颌第四前臼齿（裂齿）和猫的上颌犬齿最常受影响[2][4]。某些品种表现出易感性模式，小型和玩具品种更容易发生牙齿折断，而工作犬由于职业活动可能有更高的犬齿折断率[2]。

### Sources
[1] Day one core competencies in veterinary dentistry: https://avmajournals.avma.org/view/journals/javma/261/12/javma.23.05.0242.xml
[2] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[3] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[4] Endodontic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals

## 诊断方法

诊断单纯性牙冠折断需要系统的临床评估和影像学评估。初始的清醒检查包括评估面部对称性、触诊淋巴结和抬起嘴唇检查牙齿是否有可见的牙冠损伤[1]。在此评估期间，医生应寻找没有牙髓暴露的暴露牙本质，这表现为折断牙釉质下的淡黄色层[2]。

全面的麻醉下口腔检查对于准确诊断至关重要。这包括使用毫米刻度进行牙周探诊以评估龈沟深度（正常：犬0-3mm，猫0.5-1mm）以及使用Triadan编号系统进行牙齿记录[3]。视觉检查应识别慢性病例中可能形成的第三期或修复性牙质的暗区[1]。

口腔内牙科X线摄影对所有疑似牙冠折断都是强制性的，即使临床上没有明显的牙髓暴露迹象[1][2]。X线片有助于识别牙髓疾病的迹象，包括根尖周透射区、增宽的牙周韧带间隙和牙髓腔形态变化[3]。牙本质敏感的流体动力学机制允许细菌通过暴露的牙本质小管入侵，使X线摄影评估对于检测继发并发症至关重要[1]。

### Sources
[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[2] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[3] Day one core competencies in veterinary dentistry: https://avmajournals.avma.org/view/journals/javma/261/12/javma.23.05.0242.xml

## 治疗选择

单纯性牙冠折断的治疗选择取决于折断严重程度、患者年龄和主人期望[1]。保守治疗包括磨平锐利边缘并应用粘接复合修复封闭暴露的牙本质小管[2]。这可以防止细菌通过多孔牙本质入侵并提供患者舒适。

对于牙本质暴露最小的成年犬，如果没有明显的牙髓暴露，定期进行牙科X线片监测可能就足够了[3]。然而，复合修复是保护暴露牙本质和防止敏感的首选方法[2][3]。粘接程序包括酸蚀，然后放置粘接剂和复合材料，进行光固化并抛光[2]。

对于近期创伤（少于48小时）的幼年动物（18个月以下），如果怀疑牙髓暴露，可能需要进行活髓治疗[4]。该程序包括部分牙髓去除，放置矿物三氧化物凝聚体作为盖髓剂，以及复合修复[2][4]。

疼痛管理通常包括术后7-10天的非甾体抗炎药和抗生素[5]。应建议主人避免硬咀嚼玩具并监测并发症迹象[5]。建议每6个月进行定期随访检查和X线片，以评估治疗成功情况并检测任何发展的牙髓疾病[3][4]。

### Sources
[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[2] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[3] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[4] Managing fractured and worn teeth (Proceedings): https://www.dvm360.com/view/managing-fractured-and-worn-teeth-proceedings
[5] Advanced dental procedures for pets: What's possible?: https://www.dvm360.com/view/advanced-dental-procedures-for-pets-what-s-possible

## 预防措施

预防单纯性牙冠折断以环境控制和全面的客户教育为中心。适当的管理实践对于减少牙齿折断的发生率至关重要[1]。应警告宠物护理人员不要提供硬咀嚼物，如尼龙骨头、动物骨头、牛蹄、岩石和声称具有机械牙菌斑优势的硬塑料玩具[3]。这些材料非常坚硬，咀嚼可能导致牙齿折断并暴露牙髓[3]。

客户教育应强调避免在液体环境中放置时不容易弯曲、压缩或溶解的物体[3]。这对于用爪子握住零食并用侧牙咀嚼的犬尤为重要[3]。导致牙齿折断的材料包括煮熟或生的动物骨头、尼龙或硬塑料玩具、牛蹄、压缩零食、笼子栏杆、金属项圈、围栏和岩石[2]。

环境改造包括防止笼子咀嚼行为，这可能导致磨损并使牙齿容易折断[2]。通过作为每次体格检查一部分的清醒口腔检查进行早期识别至关重要，每12至18个月进行一次全面的麻醉下口腔检查或如果注意到任何异常[2]。

兽医专业人员应教育客户关于安全的咀嚼替代品，并强调咀嚼物应适合宠物的体重。所有宠物在咀嚼零食时都应被观察，那些吞咽而非咀嚼的犬不应喂食生皮咀嚼物或大零食[3]。

### Sources
[1] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[2] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[3] The ultimate guide to veterinary dental home care: https://www.dvm360.com/view/ultimate-guide-veterinary-dental-home-care

## 鉴别诊断

单纯性牙冠折断必须与可能表现出相似临床症状或外观的几种其他牙齿和口腔疾病区分开来[1]。主要的区别特征是单纯性牙冠折断涉及牙本质暴露而没有牙髓暴露，通过使用牙科探针的麻醉下检查确认[2]。

**复杂性牙冠折断**是最重要的鉴别诊断，因为它们涉及直接暴露牙髓，需要立即进行牙髓治疗或拔牙，而非保守管理[3]。牙髓暴露表现为折断处的红色或暗点，需要紧急干预以防止疼痛和感染[4]。

**牙釉质折断**仅影响最外层牙齿而没有牙本质暴露，表现为表面碎片或裂缝。与单纯性牙冠折断相比，这些通常需要最少的处理[5]。

**由钝性创伤引起的牙齿变色**可能表现为牙冠损伤，但涉及牙髓出血和随后的颜色变化，从粉红色到蓝灰色再到棕色。研究表明92.2%的变色牙齿有牙髓坏死，需要牙髓治疗[4]。

**牙齿磨损和磨耗**导致牙齿逐渐磨损，咬合表面有棕色斑点，代表第三期牙质形成。与急性折断不同，这些是由于正常使用或不适当的咀嚼习惯缓慢发展而来[4]。

**猫的吸收性病变**可能表现为牙冠缺陷，但涉及由破牙细胞活动引起的进行性牙齿破坏，而非创伤性折断[5]。

### Sources

[1] DVM360: Dental concerns and care through the life stages of pets: https://www.dvm360.com/view/dental-concerns-and-care-through-life-stages-pets-sponsored-greenies
[2] DVM360: Examining new classifications of tooth fractures: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures
[3] JAVMA: Day one core competencies in veterinary dentistry: https://avmajournals.avma.org/view/journals/javma/261/12/javma.23.05.0242.xml
[4] DVM360: Tooth fracture - Should you ever just "wait and see?": https://www.dvm360.com/view/tooth-fracture-should-you-ever-just-wait-and-see-proceedings
[5] DVM360: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats

## 预后

犬猫单纯性牙冠折断在适当管理时预后通常极佳[1]。这些仅涉及牙釉质而没有牙髓暴露的折断，通常需要最少的干预并具有良好的长期结果[2]。

对于仅限于牙釉质而没有牙本质穿透的折断，除了磨平锐利边缘外可能不需要治疗[2]。建议在受伤后6个月和12个月进行定期X线片监测，以检测任何发展的根尖周病变[3]。绝大多数这些病例保持无症状并保留正常的牙齿功能。

年龄显著影响预后和治疗决策。幼年动物（9个月以下）有扩大的牙髓腔和较少的保护性牙本质，使它们更容易受到牙髓影响[4]。相比之下，成年犬在牙釉质下有相当多的保护性牙本质，提供更好的自然保护[1]。

成功的结果在很大程度上取决于早期识别和适当管理。当单纯性折断通过口腔内X线片进行适当评估并适当监测时，并发症很少见[2]。然而，延迟诊断或发展为复杂性折断会显著恶化预后，可能需要根管治疗或拔牙[5]。

大多数患有单纯性牙冠折断的宠物没有不适迹象并保持正常的饮食习惯[1]。在适当的兽医评估和主人遵守随访建议的情况下，总体预后仍然极佳。

### Sources
[1] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[2] Fractured tooth presents options for correction: https://www.dvm360.com/view/fractured-tooth-presents-options-correction-classifications-defined
[3] Explore the options for dental treatment plans: https://www.dvm360.com/view/explore-options-dental-treatment-plans
[4] The ABCs of veterinary dentistry: When waiting is wishful thinking: https://www.dvm360.com/view/the-abcs-of-veterinary-dentistry-when-waiting-is-wishful-thinking
[5] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.xml
