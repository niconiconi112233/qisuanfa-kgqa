# 伴侣动物汉森II型椎间盘疾病

汉森II型椎间盘疾病是一种独特的慢性退行性疾病，主要通过脊柱椎间盘的进行性纤维样变性影响老年大型犬。与I型疾病的急性性质不同，这种疾病通过自然椎间盘脱水和矿化逐渐发展，导致缓慢进行性的脊髓压迫。理解II型IVDD对兽医从业者至关重要，因为它与其急性对应疾病相比需要不同的诊断方法和治疗策略。本报告探讨了纤维样椎间盘退变的病理生理学、受影响品种的临床表现模式、准确诊断所需的高级影像学要求，以及显著不同的治疗方案，强调保守管理而非紧急手术干预。

## 疾病概述与病理生理学

汉森II型椎间盘疾病（IVDD）是一种影响伴侣动物（特别是犬和猫）的慢性退行性脊柱疾病。与涉及髓核通过破裂的纤维环急性突出的汉森I型IVDD不同，II型IVDD的特点是缓慢、进行性的椎间盘退变和突出[1]。

汉森II型IVDD主要影响平均年龄为7-8岁的老年大型犬，与通常在5岁左右软骨营养障碍品种中出现的I型疾病形成对比[1]。大型犬随着年龄增长可能发生纤维样椎间盘退变，这易导致椎间盘缓慢进行性突出[2]。其病理生理学涉及髓核和周围纤维环随时间推移发生的自然脱水和矿化，称为纤维样变性[1][2]。

这种慢性退行性过程导致椎间盘逐渐膨出并随后压迫脊髓，而不是I型疾病中看到的急性突出。II型IVDD的缓慢进展是由于椎间盘内蛋白聚糖和水含量的逐渐丧失，导致胶原蛋白沉积增加和纤维化。这种纤维样变性形成一个坚硬、突出的椎间盘，逐渐使椎管变窄。

慢性性质允许脊髓有一定程度的适应，通常导致与急性I型椎间盘突出相比较轻的神经功能缺损。临床症状通常在5岁以上出现，包括缓慢进行性的共济失调和轻瘫[2]。两种类型的临床管理差异显著，因为II型IVDD通常对休息和抗炎药物的保守治疗反应良好，而I型通常需要紧急手术干预[1]。

### Sources
[1] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[2] Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals

## 诊断方法

汉森II型IVDD的诊断依赖于临床检查、影像学方法和神经学评估的组合，以将其与其他脊柱疾病区分开来[1]。诊断方法必须考虑II型疾病的慢性、进行性性质，这与I型IVDD典型的急性表现显著不同[2]。

神经学检查揭示具有位置特异性的发现，有助于定位。胸腰椎病变在T3-L3区域表现出完整反射，或在L4-S3区域表现为反射减退，脊柱旁痛觉过敏有助于精确定位受累节段[2]。犬可能表现为不对称的神经功能缺损，但这一发现对确定侧化的可靠性较低[2]。

普通X线片在软骨营养障碍品种中价值有限，因为椎间盘矿化在年轻犬中就会出现，与临床疾病无关[1]。然而，X线片在非软骨营养障碍品种中更有用，可以排除椎间盘炎或肿瘤等鉴别诊断[1]。

高级影像学提供确定性诊断。计算机断层扫描（CT）提供更快、更经济的病变定位，并且在许多情况下可以与MRI一样准确[1]。磁共振成像（MRI）仍然是评估所有可能参与脊髓压迫成分的金标准[3]。当计划手术干预时，两种影像学方法对于确认并精确定位突出的椎间盘材料都是必需的[1]。

鉴别诊断包括其他导致慢性进行性无力的原因，如退行性脊髓病、肿瘤和炎症性脊髓疾病[3]。

### Sources
[1] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[2] Surgical considerations for intervertebral disk disease: https://www.dvm360.com/view/surgical-considerations-intervertebral-disk-disease-proceedings
[3] Exercise intolerance in retrievers: https://www.dvm360.com/view/exercise-intolerance-retrievers

## 治疗选择

汉森II型IVDD的治疗涉及药物和手术干预，方法选择基于神经功能严重程度和对保守治疗的反应。

**药物治疗**
大多数II型IVDD病例可以保守治疗[1]。治疗需要严格笼养休息至少2周，随后限制活动约一个月[1]。有效的药物干预包括非甾体抗炎药（NSAIDs）、地西泮和加巴喷丁[1]。或者，可以使用短期泼尼松治疗[1]。NSAIDs的使用需要胃肠道保护剂，并且由于胃溃疡风险，NSAIDs永远不应与皮质类固醇联合使用[2]。

保守治疗的成功率对于仅有疼痛或轻度轻瘫的可行走犬范围为82%至100%[2]。对于1级和2级IVDD，药物和手术治疗均可达到90%的恢复率[5]。然而，保守治疗后的复发率在轻度受影响的犬中可达30-50%[2]。

**手术干预**
手术适用于患有严重颈部疼痛、进行性神经功能缺损、无法行走的截瘫、复发性轻瘫、持续性脊柱疼痛或药物治疗失败的犬[1,3]。手术程序包括减压技术，如半椎板切除术、背侧椎板切除术和椎弓根切除术[2]。与其他方法相比，半椎板切除术能以最小的脊髓操作提供优越的椎间盘材料取出[3]。对于颈椎II型疾病，腹侧开窗术是腹侧软组织压迫的首选方法[3]。

**物理康复**
接受物理康复的犬可能有更短的恢复时间[2]。康复通常包括被动关节活动度练习和肌肉按摩[4]。在兽医诊所每周两次的物理治疗，结合减肥和家庭练习，可以在30天内减少患有骨关节炎的肥胖犬的跛行[7]。

### Sources
[1] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified
[2] Surgical considerations for intervertebral disk disease: https://www.dvm360.com/view/surgical-considerations-intervertebral-disk-disease-proceedings
[3] Clinical Exposures: Intervertebral disk disease in a dog: https://www.dvm360.com/view/clinical-exposures-intervertebral-disk-disease-dog-with-agenesis-cervical-vertebra
[4] Clinical Exposures: Intervertebral disk disease: An unusual cause: https://www.dvm360.com/view/clinical-exposures-intervertebral-disk-disease-unusual-cause-cats-lameness-and-tail-weakness
[5] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[6] A mulitmodal approach to treating canine osteoarthritis beyond NSAIDs: https://www.dvm360.com/view/mulitmodal-approach-treating-canine-osteoarthritis-beyond-nsaids-sponsored-nestl-purina
[7] Management of osteoarthritis in sporting dogs: https://www.dvm360.com/view/management-osteoarthritis-sporting-dogs-proceedings
