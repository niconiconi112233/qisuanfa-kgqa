# 伴侣动物的耵聍腺腺瘤

耵聍腺腺瘤是影响犬猫最常见的耳道肿瘤之一，起源于外耳道中产生耳蜡的特化顶泌腺。这些良性肿瘤通常继发于慢性外耳炎和炎症性疾病，某些品种如美国可卡犬表现出特殊的易感性。本综合报告探讨了耵聍腺腺瘤的临床表现、诊断方法和治疗策略，同时将其与恶性 counterpart 及其他耳道肿块进行区分。分析涵盖了基本的预防措施、预后因素以及早期干预在管理这些肿瘤中的关键重要性，以优化患者的治疗效果和生活质量。

## 疾病概述

耵聍腺腺瘤是起源于犬猫外耳道内衬特化顶泌腺的良性肿瘤[1]。这些肿瘤是伴侣动物最常见的耳道肿瘤之一，与其恶性 counterpart 耵聍腺腺癌一起[1][2]。

耵聍腺是改良的顶泌汗腺，产生耵聍（耳蜡），位于外耳道的软骨部分[1]。耵聍腺肿瘤的发展通常与这些腺体的慢性炎症和增生有关，可能从良性增生进展到异型增生，最终发展为肿瘤[1]。

美国可卡犬对良性和恶性耳肿瘤表现出最高的易感性，这可能是由于该品种倾向于慢性外耳炎及随后的耵聍腺增生[1]。中年犬猫更常受良性耳肿瘤影响，而11岁以上的动物恶性肿瘤发病率增加[2]。老年动物较高的恶性肿瘤率似乎与耳病的慢性程度有关，而不仅仅是年龄因素[2]。

### Sources

[1] Tumors of the Ear Canal in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/tumors-of-the-ear-canal-in-animals

[2] Overview of Tumors of the Ear in Small Animals: https://www.merckvetmanual.com/en/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/tumors-of-the-ear-canal-in-animals

## 常见病原体

耵聍腺腺瘤是非感染性肿瘤，因此不是由病毒或细菌病原体直接引起的[1]。然而，慢性外耳炎可能创造易感条件，通过持续炎症和组织刺激促进肿瘤发展。

慢性细菌感染，特别是涉及假中间葡萄球菌、铜绿假单胞菌、变形杆菌种和大肠杆菌的感染，可延续耳道的炎症状况[3]。铜绿假单胞菌在慢性病例中尤其成问题，产生如绿脓素和胞外酶等毒力因子，损害组织并削弱免疫功能[3]。这些革兰氏阴性细菌通过生物膜形成和持续炎症创造有利于细胞变化的环境。

酵母感染，主要是厚皮马拉色菌，经常与慢性外耳炎相关，并可能促进持续炎症[2]。马拉色菌发酵产物已被证明具有严重炎症性，可能创造有利于肿瘤转化的条件[6]。

虽然不是直接致病因素，但潜在的过敏性疾病（特应性皮炎、食物过敏）作为主要的炎症触发因素，可能使动物易患慢性外耳炎及随后的肿瘤发展[2]。这些状况创造慢性炎症环境，可导致耵聍腺增生和最终的肿瘤变化[1]。

寄生虫感染，包括耳螨（Otodectes cynotis）和蠕形螨种，可引起耳道的慢性刺激和炎症[2]。虽然这些生物体不直接引起耵聍腺肿瘤，但持续的炎症反应可能有助于肿瘤形成前的细胞变化。

### Sources
[1] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[2] Derm Jeopardy: "I'll take annoying parasites for $400, Bob" (Proceedings): https://www.dvm360.com/view/derm-jeopardy-ill-take-annoying-parasites-400-bob-proceedings-0
[3] Pseudomonal otitis (Proceedings): https://www.dvm360.com/view/pseudomonal-otitis-proceedings
[4] Diagnostic otology (Proceedings): https://www.dvm360.com/view/diagnostic-otology-proceedings
[5] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
[6] Otitis Media and Interna in Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/ear-disorders-of-dogs/otitis-media-and-interna-in-dogs

## 临床症状和体征

现有内容全面涵盖了耵聍腺腺瘤的典型临床表现，但额外的参考资料提供了关于相关神经系统体征和猫科动物表现的宝贵补充信息。

除了特征性的单侧耳分泌物和摇头外，当肿瘤延伸到更深部结构时，患有耵聍腺腺瘤的猫可能发展出更复杂的神经系统表现[1]。这些额外体征包括面瘫、转圈行为、眼球震颤（不自主的眼球运动）和张口时疼痛[1]。某些情况下也可能出现上呼吸道噪音，表明附近解剖结构可能受累[1]。

猫的临床表现与其他耳道肿块相似，特别是炎性息肉[2]。最常见的临床症状包括单侧耳分泌物，可能为耵聍性、脓性或出血性，伴有持续摇头[2]。这些肿瘤通常在耳镜检查时呈现为在水平或垂直耳道内可见的粉红色、边界清晰的肿块[2]。

当耵聍腺腺瘤累及中耳结构时，神经系统并发症变得更加明显，可能包括先前描述的完整前庭体征谱，以及面神经功能障碍和交感神经受累导致的霍纳综合征[1][2]。

品种易感模式与现有信息保持一致，某些品种对这些耳道肿瘤显示易感性增加，尽管特定的解剖分布在品种间可能有所不同，如前所述。

### Sources

[1] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/243/6/javma.243.6.775.xml

[2] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis

[3] Tumors of the Ear Canal in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/tumors-of-the-ear-canal-in-dogs

[4] Overview of Tumors of the Ear in Small Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-in-small-animals/overview-of-tumors-of-the-ear-in-small-animals

[5] Ceruminous Gland Tumors in Small Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-in-small-animals/ceruminous-gland-tumors-in-small-animals

## 诊断方法

耵聍腺腺瘤需要从耳镜检查开始的综合诊断方法[1]。肿瘤通常可以在常规耳镜检查中观察到，特别是当肿块造成耳道阻塞时[3]。细针抽吸（FNA）和细胞学作为初步诊断工具，用于区分炎症性和肿瘤性病变[1]。

然而，明确诊断需要切开活检和组织病理学检查，因为仅靠细胞学可能不足以区分良性和恶性病变[1]。深部组织活检至关重要，因为浅表样本可能只显示继发性增生和炎症，而非潜在肿瘤[1]。耵聍腺腺瘤是良性耳道肿块谱系的一部分，包括炎性息肉和耵聍腺囊肿[1]。

先进影像学在手术规划和分期中起着关键作用。CT扫描或MRI对于评估局部侵犯、确定手术切缘和评估疾病程度至关重要[1]。这些影像学模式对于治疗规划和提供预后信息以指导治疗决策特别重要。

诊断检查应包括通过FNA和细胞学评估区域淋巴结，加上三视图胸部X光片以筛查转移，尽管在初次诊断时远处转移并不常见[1]。视频耳镜比手持耳镜提供更优越的可视化效果，并允许使用专用镊子进行引导活检[3]。

### Sources

[1] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[2] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[3] Diagnostic cytology--the basics (Proceedings): https://www.dvm360.com/view/diagnostic-cytology-basics-proceedings

## 治疗选择

耵聍腺腺瘤的治疗策略取决于肿瘤位置、大小和恶性潜能。对于良性腺瘤，外侧耳道切除术为肿瘤肿块提供了有效的手术通路[1]。这种微创方法特别适用于位于垂直耳道的肿瘤。

激光手术彻底改变了治疗方法，特别是与视频耳镜结合使用时。该技术允许精确切除肿瘤而无需手术打开耳道，使手术创伤更小且更易进行[1]。CO2激光消融对于局限于外耳道的肿瘤显示出极好的效果[1]。

对于恶性腺癌或广泛病变，需要更积极的手术干预。全耳道切除术和鼓室骨切除术（TECA-BO）是恶性肿瘤的金标准，因为单纯外侧切除术对恶性肿瘤的复发率超过75%[1]。广泛耳道肿块的唯一有效治疗方法是手术切除，耳道切除术加鼓室骨切除术通常能获得最佳结果[2]。

在猫中，手术切除仍然是耵聍腺肿瘤的主要治疗选择[3]。对于切除不完全的肿瘤，术后应进行全程放射治疗，因为这些肿瘤似乎对放射治疗相当敏感[3]。放射治疗作为切除的耵聍腺腺癌的重要辅助治疗，研究报告称放射治疗后56%的一年无进展生存率[1]。

术后护理侧重于监测并发症、管理疼痛和预防继发感染。目前，没有数据支持化疗对伴侣动物耳肿瘤的有效性[1]。

### Sources

[1] Ceruminous Gland Tumors in Small Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-in-small-animals/ceruminous-gland-tumors-in-small-animals
[2] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis
[3] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings

## 预防措施

耵聍腺腺瘤的预防侧重于全面的耳健康管理和早期干预策略。常规耳部检查应纳入常规兽医护理中，以便在肿瘤发展前识别早期变化[1]。关键是预防慢性外耳炎，这是耳道肿瘤的重要易感因素[1]。

环境控制措施包括保持适当的耳道卫生，但不要过度清洁，因为这可能引起刺激和炎症[2]。不建议将拔除耳道毛发作为常规做法，因为它可能创造有利于细菌和酵母菌定植的炎症条件[1]。然而，在垂耳品种中进行耳廓内侧剃毛可能减少水分滞留[4]。

早期干预方案需要及时治疗外耳炎，以防止慢性化和持续变化[3][4]。识别和管理原发性原因（如过敏性疾病、内分泌疾病和异物）对预防至关重要[4]。品种特异性预防护理应关注高风险品种，特别是那些有狭窄耳道或垂耳的品种，这些品种创造了有利于肿瘤发展的环境[4]。

在外耳炎治疗期间定期进行细胞学评估有助于监测反应并防止进展为慢性、不可逆的耳道变化[3]。由于耵聍腺腺瘤是犬猫最常见的耳道肿瘤[1]，通过这些预防策略维持最佳耳健康对降低肿瘤风险至关重要。

### Sources

[1] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[2] Diagnostic otology (Proceedings): https://www.dvm360.com/view/diagnostic-otology-proceedings
[3] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[4] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings

## 鉴别诊断

耵聍腺腺瘤必须与几种在耳道中表现相似的疾病进行鉴别[1]。最关键的区分是良性耵聍腺腺瘤与其恶性 counterpart 耵聍腺腺癌之间的区别，后者是犬猫最常见的耳道肿瘤[2][3]。

需要鉴别的其他耳道肿瘤包括鳞状细胞癌，这在猫中特别常见，当累及中耳时可导致面瘫[1]。在犬中，必须考虑皮脂腺肿瘤、组织细胞瘤和耳廓肥大细胞瘤[4][5]。

可模拟耵聍腺腺瘤的非肿瘤性疾病包括炎性息肉（在幼猫中特别常见）、耵聍腺增生和耵聍腺囊肿[2][3]。慢性外耳炎可导致沿耳道出现增生的上皮组织，表现为生长物，但与真正的肿瘤不同，这些病变可通过局部治疗消退[4][5]。

关键的鉴别因素包括患者信号（中老年动物更可能患有肿瘤）、单侧表现伴顽固性外耳炎以及对治疗的反应。增生性病变通常对抗炎治疗有改善，而真正的肿瘤持续存在[4][5]。先进影像学和组织病理学检查对于明确诊断至关重要，因为仅靠细胞学无法可靠区分良性和恶性耵聍腺肿瘤[2][3]。

### Sources

[1] Facial Paralysis in Animals - Nervous System: https://www.merckvetmanual.com/nervous-system/facial-paralysis/facial-paralysis-in-animals  
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings  
[3] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause  
[4] Tumors of the Ear Canal in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/tumors-of-the-ear-canal-in-animals  
[5] Overview of Tumors of the Ear in Small Animals: https://www.merckvetmanual.com/en/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/tumors-of-the-ear-canal-in-animals

## 预后

耵聍腺腺瘤的预后在良性和恶性形式之间差异显著，治疗方法和肿瘤特征作为关键的预后指标。

**按肿瘤类型的生存结果**
恶性耵聍腺肿瘤在物种间显示出明显不同的生存时间。患有恶性耳道肿瘤的犬的中位生存时间超过58个月，而猫的生存时间显著缩短，为11.7个月[1]。然而，接受手术治疗的恶性耳道肿瘤猫可以达到约12个月的中位生存时间，其中许多死亡与肿瘤本身无关[2]。

**治疗相关预后**
手术干预显著影响结果。对患有耵聍腺腺癌的猫进行全耳道切除术和鼓室骨切除术（TECABO）可实现75%的一年生存率和42个月的中位无病间隔，尽管25%的病例发生局部复发[2]。相反，恶性肿瘤的外侧耳道切除术复发率超过75%[1]。手术切除后的放射治疗在犬猫中显示出56%的一年无进展生存率[1]。

**预后因素**
几个因素影响结果。肿瘤广泛累及的犬预后较差[1]。在猫中，未分化癌诊断、继发性神经系统体征、血管/淋巴管栓塞以及TECABO以外的治疗方法预示着较短的生存期[2]。完全手术切除是最关键的预后因素，切除组织的组织学检查提供明确的预后确定[1]。

### Sources
[1] Ceruminous Gland Tumors in Animals - Ear Disorders: https://www.merckvetmanual.com/en-au/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/ceruminous-gland-tumors-in-animals
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
