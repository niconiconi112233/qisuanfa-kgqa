# 伴侣动物第三眼睑突出

第三眼睑突出是小动物临床实践中一种重要的眼科疾病，包括创伤性抬高和通常被称为"樱桃眼"的腺体脱垂情况。该疾病影响瞬膜的正常解剖结构和功能，可能损害泪液产生和眼部健康。理解从与霍纳综合征相关的抬高到品种特异性腺体脱垂等不同的临床表现，对于准确诊断和选择适当的治疗方案至关重要。本报告探讨了兽医对第三眼睑突出的全面处理方法，包括希林泪液测试和荧光素染色等诊断技术、以改良摩根囊袋技术为重点的手术干预，以及为维持易感品种眼部健康的长期管理考虑因素。

## 摘要

第三眼睑突出包含多种需要个性化兽医处理方法的疾病。第三眼睑腺体脱垂（"樱桃眼"）主要影响特定品种的幼犬，包括美国可卡犬和英国斗牛犬，而创伤性眼球脱位主要影响短头颅品种。诊断评估以全面的眼科检查为中心，包括希林泪液测试和荧光素染色，以评估泪液产生和角膜完整性。

治疗方法因疾病类型而有显著差异：

| 疾病 | 主要治疗方法 | 预后 | 关键考虑因素 |
|-----------|------------------|-----------|-------------------|
| 樱桃眼 | 改良摩根囊袋技术 | 保留腺体则预后极佳 | 贡献30-40%的泪膜 |
| 创伤性眼球脱位 | 紧急稳定处理 | 犬25%恢复视力，猫预后不良 | 物种特异性结果 |
| 霍纳综合征 | 治疗潜在病因 | 根据病因而异 | 相关全身性症状 |

长期管理需要终身进行希林泪液测试监测，特别是对于易感品种。在樱桃眼修复过程中保留腺体组织的关键原则可预防未来干性角膜结膜炎的发生。兽医应优先选择手术复位而非切除，并保持细致的术后护理，以优化功能结果并保护泪膜产生。

## 疾病概述

第三眼睑突出，通常被称为"樱桃眼"，是犬和猫瞬膜腺体的脱垂[1]。这种情况涉及产泪腺体从第三眼睑下方的正常位置移位，导致其在眼内侧角突出为粉红色或红色肿块[2]。

瞬膜，也称为第三眼睑，是位于眼内角的粉白色保护性结构，在需要时可延伸横过眼球以防止划伤或炎症[6][7]。该膜内的腺体产生约30-40%的水性泪膜，因此保留该腺体对于维持足够的泪液产生至关重要[9]。

第三眼睑突出主要影响幼犬，并表现出强烈的品种易感性，美国可卡犬和英国斗牛犬的发病率较高[9]。在猫中，第三眼睑腺体脱垂不常见，但缅甸猫有易感性，最常影响幼猫，尽管在家养短毛猫中发病可能较晚[10][11]。确切病因尚不清楚，但归因于通常将腺体锚定到眼眶周围结构的结缔组织薄弱[9]。该疾病可能最初表现为单侧，但常发展为双侧，腺体在不同时间脱垂[9]。

### Sources
[1] Prolapse, gland of third eyelid, dog: https://www.merckvetmanual.com/multimedia/image/prolapse-gland-of-third-eyelid-dog
[2] Third eyelid prolapse, dog: https://www.merckvetmanual.com/multimedia/image/third-eyelid-prolapse-dog
[6] Eye Structure and Function in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/eye-structure-and-function-in-dogs
[7] Eye Structure and Function in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/eye-structure-and-function-in-cats
[9] Skills Laboratory: Prolapsed third eyelid gland replacement: https://www.dvm360.com/view/skills-laboratory-prolapsed-third-eyelid-gland-replacement
[10] Ocular diseases unique to the feline patient (Proceedings): https://www.dvm360.com/view/ocular-diseases-unique-feline-patient-proceedings
[11] Image Quiz: Can you name these ophthalmic conditions?: https://www.dvm360.com/view/image-quiz-can-you-name-these-ophthalmic-conditions

## 临床症状和诊断方法

第三眼睑突出表现出特征性的临床症状，需要系统性的诊断评估。主要的临床表现为瞬膜可见抬高或脱垂，可能是单侧或双侧[1]。这种情况常表现为霍纳综合征的一部分，其典型临床症状包括上睑下垂、眼球内陷、第三眼睑抬高和瞳孔缩小[5]。

相关症状通常包括结膜变化，研究表明超过50%的患病猫存在眼表异常[2]。患者可能表现出结膜炎、结膜水肿和潜在的角膜刺激。在与自主神经系统功能障碍等全身性疾病相关的情况下，其他体征包括瞬膜脱垂伴随尿失禁、反流、瞳孔散大、泪液减少和心动过缓[3]。

体格检查应从远距离仔细观察开始，以评估眼球位置和对称性。通过闭合的眼睑手动触诊眼眶结构有助于评估眼球后缩，并可能自然抬高第三眼睑以便检查[1]。保定考虑至关重要，因为镇静可引起生理性第三眼睑突出和眼球内陷，可能混淆检查结果[4]。

诊断测试包括希林泪液测试以测量泪液产生，因为数值降低可能表明干性角膜结膜炎[1][4]。荧光素染色有助于识别角膜溃疡，而眼内压测量可排除青光眼或葡萄膜炎[1][4]。全面的眼科检查应使用直接或间接检眼镜评估结膜、角膜透明度、前房和眼底。

### Sources
[1] Ophthalmic examinations should not be complicated or expensive: https://www.dvm360.com/view/ophthalmic-examinations-should-not-be-complicated-or-expensive
[2] Ocular examinations before and after total ear canal ablation: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0187/javma.25.03.0187.pdf
[3] GI motility disorders (Proceedings): https://www.dvm360.com/view/gi-motility-disorders-proceedings
[4] Turning up your ocular exam techniques for better diagnosis (Proceedings): https://www.dvm360.com/view/turning-your-ocular-exam-techniques-better-diagnosis-proceedings
[5] Merck Veterinary Manual Image:Horner syndrome, llama-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/image/horner-syndrome-llama

## 治疗选择和手术技术

第三眼睑突出的治疗方法根据根本原因而有显著差异，从保守管理到先进的手术干预。对于脱垂的第三眼睑腺体（"樱桃眼"），由于该腺体对水性泪膜贡献30-40%的关键作用，强烈建议进行手术复位而非切除[1]。

改良摩根囊袋技术代表了腺体脱垂修复的金标准。该手术涉及在脱垂腺体周围创建弧形切口，并建立一个结膜囊袋用于腺体复位[1]。该技术的主要优势是术后保持正常的第三眼睑活动，而将第三眼睑锚定到眼外肌并限制活动的固定手术则不具备此优势[1]。

替代的手术方法包括眼眶缘锚定法，该方法已被改良以改善结果[2]。然而，由于优越的功能结果和较少的并发症，囊袋技术仍然是首选。

手术技术需要对细节的精心关注。初始切口平行于眼睑边缘进行，使用肌腱剪刀向近端创建囊袋。缝合使用5-0或6-0聚葡萄糖酸910，锚定结位于第三眼睑前表面以防止接触角膜[1]。必须保持内侧和外侧开口以利于泪液引流和预防囊肿形成。

术后管理包括广谱局部抗生素（新霉素、多粘菌素B、杆菌肽）每日三至四次，持续7-14天，结合口服非甾体抗炎药用于疼痛控制[1]。大多数患者不需要伊丽莎白圈，除非出现过度摩擦。缝线是可吸收的，无需拆除，通常在两周内完全愈合。

复发率因品种而异，大型和巨型品种即使手术技术正确也经历较高的失败率[1]。当遵循正确的手术原则时，并发症很少见。

### Sources

[1] Skills Laboratory: Prolapsed third eyelid gland replacement: https://www.dvm360.com/view/skills-laboratory-prolapsed-third-eyelid-gland-replacement
[2] Modification of the orbital rim anchorage method for surgical replacement of the gland of the third eyelid in dogs in: Journal of the American Veterinary Medical Association Volume 205 Issue 10 (1994): https://avmajournals.avma.org/view/journals/javma/205/10/javma.1994.205.10.1412.xml

## 预防、预后和长期管理

第三眼睑突出的预防侧重于最小化创伤暴露和品种特异性考虑因素。虽然通过避免高风险活动和保护短头颅犬可以减少创伤性眼球脱位的发生[1]，但第三眼睑腺体脱垂（樱桃眼）无法预防，因为它源于结缔组织附着的遗传性薄弱[2][3]。对于这两种疾病都不存在特定的疫苗接种或环境控制措施。

预后因类型和物种而有显著差异。对于创伤性眼球脱位，约25%的犬恢复视力，而猫的预后不良[1]。当妥善处理时，樱桃眼手术预后极佳，大多数犬在保留腺体而非切除时能维持正常的泪液产生[2][4]。

长期监测要求包括终身进行希林泪液测试，特别是对于易患干眼的品种[1][4]。患有樱桃眼的犬在晚年患干性角膜结膜炎的风险增加，尤其是在手术过程中切除腺体组织的情况下[2]。术后监测包括7-14天的抗生素治疗，如果患者表现出不适，可能需要使用伊丽莎白圈[4]。

品种特异性考虑至关重要，因为樱桃眼主要发生在美国可卡犬、英国斗牛犬、比格犬和那不勒斯獒犬中[2][3]，而创伤性眼球脱位主要影响眼球突出的短头颅品种[1]。

### Sources

[1] Disorders of the Nasal Cavity and Tear Ducts in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs
[2] Skills Laboratory: Prolapsed third eyelid gland replacement: https://www.dvm360.com/view/skills-laboratory-prolapsed-third-eyelid-gland-replacement
[3] Genetic ocular problems: what breeders know that you need to know (Proceedings): https://www.dvm360.com/view/genetic-ocular-problems-what-breeders-know-you-need-know-proceedings
[4] Image Quiz: Can you name these ophthalmic conditions?: https://www.dvm360.com/view/image-quiz-can-you-name-these-ophthalmic-conditions
