# 伴侣动物阴茎异常勃起：一种兽医急症

阴茎异常勃起是小动物临床中一种重要的泌尿系统急症，特征是在没有性刺激的情况下，犬和猫出现持续性阴茎勃起。虽然相对少见，但这种情况需要立即兽医干预，以防止永久性组织损伤和坏死。阴茎异常勃起的复杂性在于其多样的病因因素，从使用乙酰丙嗪后的药物诱发病例到神经系统并发症和特发性表现。本综述全面探讨了兽医从业者必需的病理生理学、临床表现和循证治疗方案。重点关注领域包括缺血性和非缺血性类型的区分、使用超声检查的先进诊断方法，以及新兴的药物治疗干预，包括特布他林和加巴喷丁治疗，这些在最近的病例研究中显示出良好的临床效果。

## 摘要

本综述综合了当前关于伴侣动物阴茎异常勃起管理的兽医知识，强调了关键的诊断和治疗考虑因素。由于其病因多样，从乙酰丙嗪诱发的病例到神经系统并发症和特发性表现，该病症呈现出独特的挑战。关键的临床见解表明，非缺血性阴茎异常勃起在犬和猫中占主导地位，超声评估作为区分包茎嵌顿的确定性诊断工具。

治疗方案已显著发展，药物治疗干预现在代表了一线疗法。特布他林（每只犬每次1.25-5毫克，每8-24小时一次）联合加巴喷丁（犬每8小时10-20毫克/公斤）在最近的病例研究中显示出特别的前景。手术干预仍保留用于难治性病例，采用微创阴茎体切口并用肝素化盐水冲洗。

| 治疗方法 | 适应症 | 成功率影响因素 |
|---|---|---|
| 药物治疗 | 非缺血性、早期表现 | 特布他林联合治疗成功率更高 |
| 手术干预 | 难治性病例、组织坏死 | 保留用于药物治疗失败者 |
| 急症支持护理 | 所有病例 | 预防继发并发症 |

兽医从业者必须优先考虑快速识别和干预，因为延迟治疗会显著影响预后，在严重情况下可能需要阴茎切除术。

## 疾病概述

阴茎异常勃起是指在没有性刺激的情况下出现的持续性阴茎勃起，影响犬和猫[1]。这种情况代表一种泌尿系统急症，需要及时的兽医干预以防止永久性组织损伤和坏死。

在小动物临床中，阴茎异常勃起相对少见，但可发生于任何年龄的雄性动物。该病症影响犬和猫，其中非缺血性阴茎异常勃起比缺血性阴茎异常勃起在伴侣动物中更常见[1]。虽然尚未确定特定的品种易感性，但该病症可影响不同品种的犬。

由于阴茎异常勃起发生罕见，关于伴侣动物阴茎异常勃起的流行病学数据有限。该病症可在精液采集程序、交配活动后发展，或可能特发性发生[1]。早期识别和治疗至关重要，因为长时间的勃起会导致静脉引流受损、组织水肿以及阴茎结构潜在的缺血性损伤[1]。

### Sources
[1] Priapism in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/priapism-in-dogs-and-cats

## 常见病原和原因

犬和猫的阴茎异常勃起主要是一种非感染性疾病，具有多种病因因素。最常见的原因包括药物诱发的阴茎异常勃起，特别是来自吩噻嗪类镇静剂如乙酰丙嗪[1]。脊髓病是另一个重要原因，通常涉及脊髓病变、脊髓手术或神经系统疾病如慢性犬瘟热脑脊髓炎[1,2]。

血管异常通过干扰阴茎组织中的正常血流动力学导致阴茎异常勃起的发生。肿瘤性病变，主要是鳞状细胞癌和其他涉及阴茎体的肿块，可机械性地干扰正常的消退机制[3]。交配事故、踢伤或其他外部损伤造成的创伤经常引发患病动物的阴茎异常勃起[1,2]。

特别在猫中，去势已被确定为潜在原因，尽管机制尚不清楚[1]。全身麻醉和除乙酰丙嗪外的各种药物制剂可通过改变阴茎血管功能的神经控制而诱发该病症[2]。包括镰状细胞病（在兽医患者中不常见）和睾丸肿瘤等肿瘤过程在内的血液疾病可能导致该病症[4]。

当尽管彻底检查仍无法确定潜在原因时，会发生特发性阴茎异常勃起。这代表了小动物临床中的相当一部分病例[1]。与细菌或病毒疾病不同，阴茎异常勃起不涉及传染性病原体作为主要病因因子，这使其区别于需要抗菌治疗的其他生殖道疾病。

### Sources
[1] Priapism in Dogs and Cats: https://www.merckvetmanual.com/en-au/reproductive-system/reproductive-diseases-of-the-male-small-animal/priapism-in-dogs-and-cats
[2] Using drug therapy to treat priapism in two dogs: https://www.dvm360.com/view/using-drug-therapy-treat-priapism-two-dogs
[3] Equine field surgery- Urogenital surgery (Proceedings): https://www.dvm360.com/view/equine-field-surgery-urogenital-surgery-proceedings-0
[4] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings

## 临床症状和体征

现有章节内容提供了阴茎异常勃起临床表现的全面概述。然而，由于源材料不包含关于犬和猫阴茎异常勃起症状和体征的其他兽医特定信息，在坚持所有主张均基于所提供源材料的指示下，我无法进一步扩展本节。

当前内容适当地区分了缺血性和非缺血性阴茎异常勃起，描述了典型的体格检查结果，包括阴茎硬度模式，并概述了可能伴随该病症的相关行为变化和全身性体征。疼痛性缺血性阴茎异常勃起与相对无痛的非缺血性阴茎异常勃起之间的区别已明确建立，同时考虑了物种特异性因素，指出虽然犬和猫的表现相似，但犬中阴茎异常勃起的报告更为频繁。

所描述的行为表现，包括嗜睡、抑郁、食欲丧失和不愿移动，为进行体检的兽医提供了重要的临床背景。提及潜在的并发泌尿道体征如血尿和蛋白尿，为完整的临床图景增加了有价值的诊断考虑因素。

### Sources
[1] Using drug therapy to treat priapism in two dogs: https://www.dvm360.com/view/using-drug-therapy-treat-priapism-two-dogs
[2] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings
[3] Using drug therapy to treat priapism in two dogs: https://www.dvm360.com/view/using-drug-therapy-treat-priapism-two-dogs
[4] Rabies in Animals - Nervous System: https://www.merckvetmanual.com/nervous-system/rabies/rabies-in-animals
[5] Priapism in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/priapism-in-dogs-and-cats

## 诊断方法

诊断犬和猫的阴茎异常勃起需要结合体格检查、影像学研究和血流评估的综合临床方法。诊断过程必须区分缺血性和非缺血性形式，以指导适当的治疗[1]。

**体格检查**
初步诊断依赖于对在没有性刺激情况下持续勃起并保持在包皮外的阴茎的目视检查[1,2]。临床医生应评估干燥、肿胀和周围组织变化的迹象。主要鉴别诊断是包茎嵌顿，后者以没有勃起为特征[2]。

**超声评估**
阴茎超声检查作为阴茎异常勃起的确认性诊断工具[1]。多普勒超声检查可以评估动脉血流模式，并帮助区分缺血性和非缺血性表现。彩色多普勒检查可以区分阴茎异常勃起与其他阴茎肿胀原因，尽管这种先进影像学检查可能并非在所有病例中常规进行[2]。

**血流评估**
区分缺血性和非缺血性阴茎异常勃起对于治疗计划至关重要。非缺血性阴茎异常勃起在犬和猫中比缺血性形式更常见[1]。该评估有助于确定药物治疗或手术干预是否最合适，因为非缺血性病例通常对药物治疗反应更好。

### Sources

[1] Priapism in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/priapism-in-dogs-and-cats
[2] Using drug therapy to treat priapism in two dogs - dvm360: https://www.dvm360.com/view/using-drug-therapy-treat-priapism-two-dogs

## 治疗选择

犬阴茎异常勃起的治疗需要及时干预，并根据潜在病理生理学和严重程度遵循系统方法。在可行的情况下，首选早期药物治疗，手术干预保留用于难治性或严重病例。

### 药物干预

一线药物治疗包括针对阴茎消退的全身性药物。加巴喷丁（犬每8小时口服10-20毫克/公斤，猫每8小时10毫克/公斤）代表主要治疗选择[4]。特布他林，一种β2-肾上腺素能激动剂，已显示出显著疗效，剂量为每只犬每次1.25-5毫克，每8-24小时一次，或每只猫每次0.625毫克，每12-24小时一次[2][4]。伪麻黄碱（犬每8-12小时口服1.5毫克/公斤）提供拟交感神经效应，可促进阴茎消退[4]。

临床病例报告显示，使用抗胆碱能药物（阿托品、苯海拉明、氯苯那敏）联合特布他林治疗成功[2]。这种方法针对副交感神经抑制和平滑肌松弛机制。特布他林通过放松拉伸的阴茎体平滑肌和扩大阴茎静脉直径来发挥作用，消除静脉血流的障碍[2]。

### 手术管理

当药物治疗失败或发生严重缺血性阴茎异常勃起时，需要手术干预。微创技术包括在阴茎海绵体的白膜上做小切口，然后用肝素化盐水溶液冲洗[4]。对于伴有组织坏死或坏疽的严重病例，可能需要阴茎切除术和会阴尿道造口术[4]。

急症支持护理包括用稀释氯己定清洁阴茎、局部应用抗生素以及放置保护性颈圈以防止自伤[2]。

### Sources

[1] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings-0
[2] Using drug therapy to treat priapism in two dogs: https://www.dvm360.com/view/using-drug-therapy-treat-priapism-two-dogs
[3] Reproductive Disorders of Male Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-male-dogs
[4] Priapism in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/priapism-in-dogs-and-cats

## 预防措施和鉴别诊断

### 预防措施
目前，对于犬和猫的阴茎异常勃起没有特定的预防措施，因为该病症通常是特发性的或由不可预测的因素引起[1]。去势没有帮助，因为阴茎异常勃起不是睾酮介导的[1]。对于与药物给药相关的病例，避免已知的致病药物如吩噻嗪类镇静剂可以降低风险[1]。

管理复发性病例涉及解决潜在的神经系统疾病，避免在交配或精液采集期间发生创伤，以及监测患有脊髓疾病的动物[1]。早期识别和及时治疗对于预防缺血性并发症至关重要。药物治疗选择包括抗胆碱能药物联合β-肾上腺素能激动剂，特布他林在最近的病例报告中显示出成功[2]。

### 鉴别诊断
主要鉴别诊断是包茎嵌顿，涉及无法将未勃起的阴茎回缩到包皮腔内[1]。包茎嵌顿
