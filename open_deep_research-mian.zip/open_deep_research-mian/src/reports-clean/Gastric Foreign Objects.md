# 伴侣动物胃内异物

胃内异物是小动物兽医实践中常见的急症，影响各年龄段的犬和猫，但在幼年动物中尤为普遍。这种情况发生在宠物摄入非食物物品并滞留在胃中时，可能导致梗阻、组织损伤和危及生命的并发症。与传染性疾病不同，胃内异物主要是由行为因素和环境暴露引起，而非病原性原因。本报告探讨了临床表征、诊断方法、治疗模式和预防策略，这些对于管理这种常见的兽医急症至关重要，并强调了物种特异性模式和基于证据的治疗干预。

## 摘要

伴侣动物的胃内异物带来了重大的诊断和治疗挑战，需要及时的兽医干预。幼猫和大型犬表现出更高的易感性，具有物种特异性的摄入模式：猫通常摄入线性材料如绳子或纱线，而犬则摄入更坚固的物品，包括玩具、骨头和家居用品。

临床诊断依赖于全面的放射学评估作为主要影像学方法，辅以超声检查检测不透射线异物，以及实验室评估揭示脱水和电解质失衡标志物。28%的病例出现高乳酸血症，这是一个重要的预后指标。

| 治疗方法 | 适应症 | 成功因素 |
|---|---|---|
| 内镜取出 | 胃内异物 | 物体大小、可及性 |
| 手术胃切开术 | 内镜取出失败 | 及时干预、适当技术 |
| 保守治疗 | 选择的监测病例 | 物体特征、患者稳定性 |

通过环境管理和行为训练进行预防仍然是最有效的方法。主人必须实施宠物防护策略，提供合适的替代品，并监督高风险动物。及早识别临床症状并及时就医可显著改善患者预后，并减少这种可预防疾病的相关并发症。

## 常见病原体和原因

与传染性疾病不同，胃内异物本身并非由特定病原体引起。然而，细菌并发症经常由异物的存在及其相关的组织损伤引起 [1]。

继发性细菌污染通常涉及大肠杆菌（*Escherichia coli*）和梭菌属（*Clostridium*）种类，当异物损害组织完整性时，这些细菌会从胃肠道易位 [1]。梗阻或绞窄可导致胃肠道组织失活，为细菌易位和随后的脓毒症创造有利条件 [1]。

主要原因是行为和环境因素，而非传染性病原体。随意进食行为是最重要的易感因素，特别是在年轻、爱玩的犬中 [2]。最近的研究证实，与年长动物相比，幼猫和年轻的大型犬更有可能出现异物梗阻的体征 [1]。

某些品种表现出更高的易感性，其中梗犬类、猎犬类和牧羊犬显示出品种易感性 [2]。犬倾向于吃更"坚固"的物品，如玩具、地毯碎片、袜子和洗碗布，而猫则更容易吃细线、纱线或牙线等小片物品 [3]。

潜在的疾病可能通过异食癖行为使动物易患异物摄入，包括肠道肿瘤、炎症性肠病、慢性肾病和库欣病 [2]。

### Sources
[1] Gastrointestinal Obstruction in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[2] Gastro-Intestinal Foreign Bodies (Do's and Don'ts) - WSAVA 2015 Congress: https://www.vin.com/apputil/content/defaultadv1.aspx?id=7259318&pid=14365
[3] Surgery pearls: Removing linear foreign bodies in dogs: https://www.dvm360.com/view/surgery-pearls-removing-linear-foreign-bodies-in-dogs

## 临床症状和体征

患有胃内异物的犬和猫表现出可变的临床症状，这些症状取决于梗阻位置、异物大小和类型以及摄入持续时间 [1]。最常见的表现症状包括呕吐（87%的病例）、嗜睡（48%）和食欲不振（38%）[1]。与近端胃梗阻相比，远端小肠梗阻的呕吐频率较低 [2]。

体格检查可能揭示腹痛，一些动物表现出从轻度（5-6%）到中度（7-8%）不等的脱水迹象 [1]。腹部检查时可能触及到肠道肿块或异物，尽管在早期病例中体格检查结果可能不明显 [2]。

**物种特异性模式：** 幼猫和年轻的大型犬比年长动物更常受影响 [2]。猫通常在玩耍时摄入线性异物，如绳子、纱线或牙线，仔细的口腔检查至关重要，因为线性材料可能锚定在舌根部 [2]。犬更有可能随意摄入物品，包括塑料、岩石或骨头 [2]。

**症状持续时间和变异性：** 59%的病例临床症状持续0-1天，症状持续时间越长，治疗失败率越高 [1]。完全梗阻通常比部分梗阻引起更严重的症状，而线性异物更可能导致部分梗阻，而大的圆形物体则导致完全梗阻 [2]。

### Sources

[1] Clinical features and outcomes of dogs with attempted medical management for discrete gastrointestinal foreign material: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml

[2] Gastrointestinal Obstruction in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals

## 诊断方法

**全面的放射学评估**
腹部X线摄影仍然是主要的初始影像学方法，推荐右侧和左侧卧位加腹背位作为标准方案 [4]。数字X线摄影（DR）系统现在优于计算机X线摄影（CR），因为其工作流程效率更高且对比度分辨率更好，尽管空间分辨率略低 [1]。**压迫X线摄影**使用不透射线压板有效分离胃结构，减少器官重叠，同时增强异物和胃扩张模式的可视化 [4]。

**实验室评估** 
全血细胞计数通常显示与脱水一致的红细胞增多和血浆蛋白浓度升高 [4]。电解质异常通常包括**低氯血症**和**低钠血症**，而高乳酸血症出现在约28%的病例中，是一个重要的预后指标 [2]。**血清生化面板**评估器官功能和酸碱状态，由于全身性低血压，通常存在肾前性氮质血症 [6]。

**高级影像学方法**
**超声检查**提供优越的软组织细节，用于评估胃壁完整性、扩张模式以及识别不透射线的异物 [4]。超声学上，线性高回声结构伴随的肠道折叠是线性异物的特征 [4]。使用钡剂或碘化溶液的**造影X线摄影**通过充盈缺损帮助检测不透射线物体，但当怀疑有穿孔时，应使用**水性碘剂**或碘海醇 [6]。

**内镜评估**
通过内镜直接可视化能够进行诊断和潜在的治疗性取出，尤其适用于胃内异物，尽管成功率因物体特征和解剖位置而有显著差异 [3]。

### Sources

[1] Merck Veterinary Manual Radiography of Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/radiography-of-animals
[2] Clinical features and outcomes of dogs with attempted medical management for discrete gastrointestinal foreign material: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml
[3] Emesis induction is successful for recovery of gastric foreign objects: https://avmajournals.avma.org/view/journals/javma/261/9/javma.23.03.0176.xml
[4] Diagnostic imaging for linear foreign bodies in cats: https://www.dvm360.com/view/diagnostic-imaging-linear-foreign-bodies-cats
[5] Merck Veterinary Manual Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[6] Merck Veterinary Manual Clinical Biochemistry: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-biochemistry

## 治疗选择

胃内异物的保守治疗侧重于支持性护理和监测自发排出 [1]。含有电解质纠正的液体疗法至关重要，因为患者通常表现为脱水和代谢紊乱。止吐药如马罗匹坦有助于控制呕吐，而疼痛管理则解决患者的不适 [1][2]。

当技术上可行时，内镜取出是胃内异物的首选一线干预措施 [1][2]。这种微创方法允许使用专用钳子直接可视化和移除物体，降低手术风险并缩短恢复时间。

当内镜取出失败或存在禁忌症时，手术干预变得必要 [1][2][3]。胃切开术是胃内异物取出最常见的手术方法，特别适用于因尺寸或锋利边缘而不适合内镜取出的物体 [1]。锚定在幽门处的线性异物需要手术取出，因为存在穿孔风险 [1]。

对于肠道异物，可能需要肠切开术或肠切除术 [3]。当肠道损害明显时，切除和吻合术成为必要，但这带来更高的发病率 [3]。手术方法应尽量减少肠切开部位的数量，以降低裂开风险 [2]。

术后支持性护理包括持续的液体疗法、疼痛管理和对并发症的仔细监测 [3]。如果呕吐得到控制，应在术后12-24小时开始营养支持 [1]。密切监测手术部位裂开（通常发生在术后3-5天）至关重要 [2]。

### Sources

[1] Key gastrointestinal surgeries: Gastrotomy: https://www.dvm360.com/view/key-gastrointestinal-surgeries-gastrotomy
[2] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[3] Surgery STAT: Surgical management of gastrointestinal foreign bodies: https://www.dvm360.com/view/surgery-stat-surgical-management-gastrointestinal-foreign-bodies

## 预防措施和鉴别诊断

### 预防策略

环境管理是胃内异物预防的基石 (1)。主人应从宠物环境中移除可能摄入的物品，包括玩具、骨头、岩石和家居物品。通过固定垃圾桶和移除小物件来宠物防护家庭对于高风险动物至关重要。

行为训练和监督指南是关键的预防措施 (1)。有随意进食行为的犬受益于基于强化的训练技术，以教授适当的替代反应，如"坐下"和"放下"命令。提供建设性的替代品，如喂食玩具和益智喂食器，可以转移破坏性咀嚼行为。一些犬在户外活动或无人监督时可能需要持续监督。

### 关键鉴别诊断

胃内异物必须与几种引起相似胃肠道症状的重要疾病相鉴别 (2)。肿瘤是一个重要的鉴别诊断，特别是中老年犬的胃腺癌，通常表现为呕吐、体重减轻和厌食。胃肠道梗阻最常见的腔外原因是肠套叠，通常发生在回盲结肠交界处 (2)。

其他关键的鉴别诊断包括肠道狭窄、粘连和炎症性肠病 (2)。线性异物由于在X光片上特征性的逗号状气体模式和肠道折叠，带来了独特的诊断挑战。仅凭临床表现无法可靠地区分这些疾病，因此需要全面的诊断影像学和内镜评估以进行明确诊断。

### Sources

[1] Behavioral Problems of Dogs: https://www.merckvetmanual.com/behavior/normal-social-behavior-and-behavioral-problems-of-domestic-animals/behavioral-problems-of-dogs

[2] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
