# 犬猫脑积水：综合临床指南

脑积水以脑室内脑脊液异常积聚为特征，是影响伴侣动物的一种重要神经系统疾病。该疾病主要影响玩具犬和短头颅犬种，先天性形式在幼年动物中表现，而获得性病例则继发于创伤、感染或肿瘤形成。本综合报告探讨了小动物临床实践中脑积水管理的多方面内容，涵盖从先进影像技术到脑脊液分析的诊断方法，从使用皮质类固醇的药物治疗到脑室腹腔分流术的手术治疗策略，以及预后考量，包括手术后72%的改善率。其临床意义不仅限于直接的神经功能障碍，还包括对受影响动物的繁殖建议、基因筛查方案和长期生活质量考量。

## 疾病概述

脑积水定义为脑脊液（CSF）在脑室内的异常积聚，导致脑室扩大和颅内压增高[1]。这种神经系统疾病是由脑脊液产生与吸收之间的不平衡引起的，导致脑组织受压并可能引发严重的神经功能障碍[1]。

该疾病最常见于玩具犬和短头颅犬种，包括吉娃娃、约克夏梗、马尔济斯犬、博美犬和波士顿梗[2]。脑积水在犬中最常见，特别是在玩具犬和短头颅品种中，可分为交通性（非梗阻性）或非交通性（梗阻性）[2]。

幼年动物主要受影响，先天性脑积水通常在出生后头几个月内表现[3]。临床症状通常表明脑功能障碍且常进展，尽管有些动物可能保持无症状[2]。受影响动物可能有圆顶状头部，伴有开放的囟门和腹外侧斜视[2][3]。然而，获得性形式可在任何年龄因创伤、感染或肿瘤形成后发展。

在猫中，脑积水通常被称为"脑积水"，比犬中报道的少，但可能引起类似脑损伤的症状并随时间恶化[4]。

### Sources
[1] Merck Veterinary Manual - Congenital and Inherited Cerebral Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[2] Merck Veterinary Manual - Hydrocephalus, dog: https://www.merckvetmanual.com/multimedia/image/hydrocephalus-dog
[3] DVM360 - Seizures in puppies, kittens difficult diagnostic and therapeutic problem: https://www.dvm360.com/view/seizures-puppies-kittens-difficult-diagnostic-and-therapeutic-problem
[4] Merck Veterinary Manual - Congenital and Inherited Disorders of the Nervous System in Cats: https://www.merckvetmanual.com/cat-owners/brain-spinal-cord-and-nerve-disorders-of-cats/congenital-and-inherited-disorders-of-the-nervous-system-in-cats

## 常见病原体

犬猫脑积水很少由传染性病原体引起，大多数病例为先天性或发育性起源。然而，某些病毒和细菌病原体可通过影响脑脊液循环的炎症过程导致继发性脑积水。

**病毒性原因**
猫泛白细胞减少症病毒（FPV）仍然是与猫脑积水相关的最重要的病毒病原体[1][2]。当怀孕母猫感染FPV时，病毒可穿过胎盘影响发育中的小猫，导致脑积水和脑小脑发育不全，这些可能与脑积水同时发生[1][2]。犬瘟热病毒也可能通过影响大脑的炎症过程促进脑积水发展[4]。虽然人类副流感病毒影响人类，但没有兽医文献支持其在伴侣动物脑积水中的作用。

**细菌性原因**
细菌性脑膜脑炎可通过炎症性阻塞脑脊液流动导致继发性脑积水。常见细菌病原体包括葡萄球菌、大肠杆菌、链球菌和各种厌氧菌[3][5]。这些感染在免疫系统受损的幼年动物中更常见。围产期脑炎或细菌感染引起的粘连可导致非交通性脑积水[2]。

**其他传染性病原体**
虽然较少见，但其他传染性病原体可能通过继发性炎症过程促进脑积水发展，而不是作为主要病因[1]。

### Sources
[1] Cerebellar Ataxia and Its Congenital Transmission in Cats by ...: https://avmajournals.avma.org/view/journals/javma/158/6/javma.1971.158.06.888.xml
[2] Congenital and Inherited Cerebral Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[3] Infectious neurologic diseases of puppies and kittens ...: https://www.dvm360.com/view/infectious-neurologic-diseases-puppies-and-kittens-proceedings
[4] Diagnostic approach to patients with signs of ...: https://www.dvm360.com/view/diagnostic-approach-patients-with-signs-encephalopathy-proceedings
[5] The Neurologic Evaluation of Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/the-neurologic-evaluation-of-dogs

## 临床症状和体征

脑积水的临床症状通常反映脑功能障碍，在表现和严重程度上各不相同[1]。最具特征性的身体表现是由颅内压增高引起的圆顶状头部，幼年动物常伴有开放的囟门[1]。

神经系统体征常见包括癫痫发作、食欲不振、嗜睡和精神状态改变[1]。受影响动物可能表现出腹外侧斜视，形成独特的"日落"眼外观[5]。由于颅内压增高，可能发展出包括失明在内的视力缺陷[4]。

**品种特异性模式**在犬中尤为明显，脑积水在玩具犬和短头颅品种如哈巴狗、斗牛犬和斗牛獒中最常见[4]。这些品种因其独特的颅骨构型而表现出更高的易感性[6]。

**行为改变**代表重要的早期指标，可能包括"凝视太空"、不当发声、抑郁和意识改变[4]。一些动物可能表现出头抵物、推进式转圈或木僵[1]。在晚期病例中，动物可能进展到昏迷或显示肌阵挛[1]。

**表现可变性**值得注意，一些患有脑积水的动物尽管有放射学证据可能仍保持无症状[1][4]。临床症状通常表明脑功能障碍且常随时间进展，尽管严重程度可能从细微的行为异常到严重的神经功能障碍不等。

### Sources
[1] Congenital and Inherited Cerebral Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[2] Congenital and Inherited Disorders of the Nervous System in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs
[3] Hydrocephalus, dog: https://www.merckvetmanual.com/multimedia/image/hydrocephalus-dog
[4] What Is a Brachycephalic Dog Breed?: https://www.merckvetmanual.com/multimedia/table/what-is-a-brachycephalic-dog-breed

## 诊断方法

脑积水的准确诊断依赖于全面的临床评估结合先进的影像技术[1]。临床表现评估包括神经系统检查以评估意识改变、异常姿势和颅神经功能障碍[1]。眼底检查对于检测视乳头水肿和评估视盘变化至关重要[2]。

先进影像是诊断的金标准。磁共振成像（MRI）提供脑室扩大和脑实质变化的优越可视化[1,2]。计算机断层扫描（CT）对脑室扩张具有极好的检测能力，对急诊评估有价值[1,2]。两种模态均可识别潜在的梗阻性病变并评估脑压迫严重程度[2]。

脑脊液（CSF）分析提供重要的诊断信息。蛋白质水平升高可能表明炎症或感染，而细胞计数增加提示炎症过程[2]。CSF采集应始终在影像学检查之后进行，以防止颅内压增高病例发生脑疝[1]。

脑室内压力测量虽然在临床实践中很少进行，但当临床症状不明确时可以确认颅内压增高。通过幼年动物开放的囟门进行超声成像可提供脑室大小的无创评估，特别适用于监测治疗反应[3]。

### Sources
[1] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings
[2] The Neurologic Evaluation in Cats: https://www.merckvetmanual.com/cat-owners/brain-spinal-cord-and-nerve-disorders-of-cats/the-neurologic-evaluation-in-cats
[3] Outcome of ventriculoperitoneal shunt implantation for ...: https://avmajournals.avma.org/view/journals/javma/242/7/javma.242.7.948.xml

## 治疗选择

犬猫脑积水的治疗包括药物治疗和手术干预，取决于疾病严重程度和进展。初始药物治疗通常包括糖皮质激素以减少脑脊液产生和控制脑室周围水肿[1]。泼尼松通常以0.5 mg/kg口服每日两次给药，逐渐减量至最低有效剂量[1]。其他药物可能包括奥美拉唑和乙酰唑胺（碳酸酐酶抑制剂）以进一步减少CSF产生[1]。

对于颅内压增高的动物，利尿疗法可能提供额外益处。呋塞米（速尿）以1-2 mg/kg静脉注射有时与其他治疗联合使用以增强利尿效果并更显著降低颅内压[3]。一些神经学家主张将呋塞米与甘露醇治疗结合以获得最佳降压效果[3]。

对于进行性体征对药物治疗无反应的犬，脑室腹腔分流术的手术置入代表确定性治疗选择[1]。研究报告称72%的动物在分流植入后显示临床改善[2]。然而，成功率各不相同，潜在并发症包括感染、分流管阻塞和移位[1]。由于这些并发症，手术修正常常是必要的[1]。

支持性护理在整个治疗过程中仍然至关重要，特别是管理并发神经系统体征。出现癫痫发作的动物需要适当的抗惊厥治疗以及针对脑积水的特异性治疗[1]。治疗决定取决于临床进展，对抗惊厥药难治的复发性癫痫发作或额外的神经系统异常表明需要更积极的干预[1]。

### Sources
[1] Sparky's shaking again: Seizures in young dogs (Proceedings): https://www.dvm360.com/view/sparkys-shaking-again-seizures-young-dogs-proceedings
[2] Outcome of ventriculoperitoneal shunt implantation for: https://avmajournals.avma.org/view/journals/javma/242/7/javma.242.7.948.xml
[3] Approach to head trauma (Proceedings): https://www.dvm360.com/view/approach-head-trauma-proceedings

## 预防措施

根据现有兽医知识，现有章节内容已全面涵盖脑积水预防措施。由于提供的来源材料包含关于脑积水预防的有限相关信息，我将综合现有内容与额外来源信息以增强该部分，同时保持既定的字数限制。

犬猫脑积水的预防主要侧重于基因筛查和负责任的繁殖实践，因为这种情况最常见于具有遗传成分的先天性[1]。由于脑积水在玩具犬和短头颅品种如吉娃娃、马尔济斯犬和约克夏梗中最普遍[1][5]，基因检测和繁殖建议是重要的预防策略。

繁殖计划应实施基因筛查方案以识别携带者动物，避免繁殖受影响个体或已知携带者[4]。繁殖者必须保持准确的谱系记录并向品种协会报告任何先天性异常以进行集中数据收集[3]。当识别出基因缺陷时，品种协会通常强制要求检测并可能限制携带者动物的注册[3]。产前护理包括在怀孕期间防止母体暴露于致畸剂[3]。

环境控制措施包括在怀孕期间防止母体暴露于致畸剂，如植物毒素、某些药物和传染病[3]。适当的产前护理和疫苗接种方案有助于预防可能导致发育异常的病毒感染[3]。

管理潜在条件至关重要，特别是早期检测和治疗门体分流，这可能导致肝性脑病和继发性神经系统并发症[2]。定期监测颅内压增高迹象以便及时进行药物或手术干预。

由于没有特定疫苗可预防脑积水且该疾病主要为先天性，疫苗接种方案侧重于预防继发并发症并维持受影响动物的整体健康[1]。

### Sources
[1] Congenital and Inherited Cerebral Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[2] Congenital and Inherited Anomalies of the Liver in Animals: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/congenital-and-inherited-anomalies-of-the-liver-in-animals
[3] Congenital and Inherited Anomalies in Animals: https://www.merckvetmanual.com/generalized-conditions/congenital-and-inherited-anomalies/congenital-and-inherited-anomalies-in-animals
[4] Determining the cause of neurologic signs in neonates: https://www.dvm360.com/view/determining-cause-neurologic-signs-neonates
[5] Seizures: etiologies and developing a diagnostic plan: https://www.dvm360.com/view/seizures-etiologies-and-developing-diagnostic-plan-proceedings

## 鉴别诊断

脑积水必须与几种具有重叠神经系统体征的疾病区分开来。**脑膜脑炎**表现出类似的前脑功能障碍，包括精神状态改变、癫痫发作和行为改变[1]。特别是隐球菌性脑膜脑炎可在犬中引起轴外病变，在影像学上可能模拟脑积水，尽管它通常显示对比增强和相关的鼻窦受累[1]。

**脑肿瘤**，特别是猫的脑膜瘤，常引起进行性前脑体征并可导致继发性梗阻性脑积水[2]。肿瘤在CT和MRI上显示特征性的对比增强模式和占位效应，有助于将其与原发性脑积水区分开来[2]。

**脑积水和脑室扩大**之间的关键区别在于临床表现和脑脊液动力学[3]。真正的脑积水涉及CSF压力增高并伴有临床症状，而脑室扩大代表脑室扩大而不一定有压力增高或症状[3]。脑积水可分为交通性（非梗阻性）或非交通性（梗阻性），后者常由导水管狭窄或围产期炎症引起[3]。

使用MRI或CT的先进影像有助于区分这些情况，显示脑积水的脑室扩张与肿瘤的局灶性病变或脑膜脑炎的炎症变化[4][8]。CSF分析有助于诊断，先天性脑积水通常显示正常结果，而脑炎显示炎症变化。

### Sources
[1] Brain magnetic resonance imaging and computed tomography findings in cats and dogs with central nervous system cryptococcosis in Australia: 23 cases (2009-2020): https://avmajournals.avma.org/view/journals/javma/262/4/javma.23.08.0454.xml
[2] Forebrain disease in older cats: Look for intracranial neoplasia: https://www.dvm360.com/view/forebrain-disease-older-cats-look-intracranial-neoplasia
[3] Congenital and Inherited Cerebral Disorders in Animals: https://www.merckvetmanual.com/nervous-system/congenital-and-inherited-anomalies-of-the-nervous-system/congenital-and-inherited-cerebral-disorders-in-animals
[4] Use of MRI in the neurologic patient: https://www.dvm360.com/view/use-mri-neurologic-patient
[8] Magnetic Resonance Imaging in Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/magnetic-resonance-imaging-in-animals

## 预后

伴侣动物脑积水的预后根据管理方法和个体因素差异显著。通过使用脑室腹腔分流术的手术干预，约72%的动物经历临床改善，在一项研究中7只犬和2只猫临床症状完全缓解[1]。然而，手术死亡率令人担忧，36%的动物死于脑积水相关并发症或需要安乐死[1]。

药物治疗侧重于使用抗惊厥治疗癫痫发作的症状控制。糖皮质激素可能通过减少CSF产生和解决脑室周围水肿提供暂时益处。奥美拉唑和乙酰唑胺等额外药物可能有助于减少CSF产生[2]。

几个预后因素影响结果。尽管接受药物治疗但神经系统进行性恶化的动物预后较差。临床症状的早期发作和脑室扩张的严重程度影响长期结果。手术并发症包括感染、阻塞和移位常需要修订手术，影响整体预后。在一项研究中3只犬需要分流修订手术[1]。

并发疾病的存在或由肿瘤或感染引起的继发性脑积水通常使预后恶化。具有轻度、非进行性临床症状的动物通过适当的药物治疗可能保持良好的生活质量，而那些具有严重神经系统缺陷的动物无论治疗方法如何预后谨慎至不良[2]。

### Sources

[1] Outcome of ventriculoperitoneal shunt implantation for: https://avmajournals.avma.org/view/journals/javma/242/7/javma.242.7.948.xml
[2] Sparky's shaking again: Seizures in young dogs: https://www.dvm360.com/view/sparkys-shaking-again-seizures-young-dogs-proceedings
