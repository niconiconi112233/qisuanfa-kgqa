# 伴侣动物产气荚膜梭菌感染

产气荚膜梭菌肠毒素中毒是兽医实践中影响犬猫的一种重要细菌性胃肠道疾病。这种厌氧、产芽孢的细菌通过产生肠毒素引起急性出血性腹泻和慢性间歇性胃肠道疾病。由于该细菌存在于正常肠道菌群中，该病症的诊断具有挑战性，需要特定的检测来检测肠毒素，而不仅仅是简单的细菌鉴定。

本综合报告探讨了A型菌株的发病机制、从急性血性腹泻到慢性间歇性发作的临床表现，以及基于证据的诊断方法，包括PCR和ELISA检测。分析涵盖了以泰乐菌素作为一线治疗的抗菌疗法、支持性护理方案，以及高纤维饮食管理在急性治疗和长期预防复发性感染中的关键作用。

## 疾病概述与流行病学

产气荚膜梭菌肠毒素中毒是一种影响犬猫的细菌性胃肠道疾病，其特征为由肠毒素产生引起的腹泻[1]。产气荚膜梭菌是一种广泛分布的革兰氏阳性、厌氧、产芽孢细菌，存在于土壤和动物的正常肠道微生物群中[2]。

已鉴定出五种类型（A、B、C、D和E）的产气荚膜梭菌，但只有A型在犬中引起肠毒血症[1]。A型菌株通常作为正常肠道微生物群的一部分存在，并产生产气荚膜梭菌肠毒素（CPE），这是食源性和非食源性腹泻疾病中的主要毒素[2]。该病症在犬中可表现为急性出血性腹泻或慢性间歇性腹泻[2]。

产气荚膜梭菌肠毒素中毒被认为是犬猫中常见的细菌性肠道病原体[3]。该疾病与犬的医院获得性和获得性急慢性腹泻相关[2]。最近的研究表明，在约26%的胃肠道表现的犬中可发现编码肠毒素的产气荚膜梭菌菌株[4]。年龄和品种易感性在当前文献中未有充分记载，尽管该疾病影响各种年龄的动物。由于该细菌在土壤和肠道环境中的普遍存在，地理分布似乎遍及全球。

### Sources

[1] Enterotoxemia in Dogs: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/enterotoxemia-in-dogs
[2] Enterotoxemias in Animals: https://www.merckvetmanual.com/infectious-diseases/clostridial-diseases/enterotoxemias-in-animals
[3] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[4] Effects of dietary cellulose on clinical and gut microbiota: https://avmajournals.avma.org/view/journals/javma/263/2/javma.24.07.0476.pdf

## 病因学与发病机制

**产气荚膜梭菌**是一种革兰氏阳性、厌氧、产芽孢细菌，广泛分布于土壤以及犬猫的胃肠道中[1]。存在五种生物型（A、B、C、D和E），其中A型是最常见且在产毒特性上最具变异性的菌株[1][2]。

**A型发病机制：** 产气荚膜梭菌A型产生多种毒素，包括α毒素、肠毒素（CPE）和与犬坏死性肠炎和结肠炎相关的坏死毒素[2][3]。肠毒素在芽孢形成过程中释放，刺激肠上皮细胞向肠腔分泌过量液体[1]。netF毒素基因可能在犬急性出血性腹泻综合征的发病机制中发挥重要作用[4]。

**易感因素：** 正常肠道微生物群的破坏是疾病发展的必要条件[1]。关键易感因素包括抗菌治疗（特别是大环内酯类、β-内酰胺类和甲氧苄啶/磺胺类）、饮食改变、应激和免疫功能低下状态[1][2]。

**疾病机制：** 该细菌通过毒素介导的肠道损伤和全身效应引起疾病[1]。产气荚膜梭菌持续存在于健康犬的粪便中，但当条件允许细菌过度增殖和毒素产生时才会发生疾病[1][4]。宿主因素包括年龄、免疫力和肠道毒素受体的存在，决定疾病易感性[1]。

### Sources
[1] Clostridium difficile and C perfringens Infections in Animals: https://www.merckvetmanual.com/infectious-diseases/clostridial-diseases/clostridium-difficile-and-c-perfringens-infections-in-animals
[2] Enterotoxemias in Animals: https://www.merckvetmanual.com/infectious-diseases/clostridial-diseases/enterotoxemias-in-animals
[3] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich
[4] Antibiotics in canine GI disease: when to use and when to ditch: https://www.dvm360.com/view/antibiotics-in-canine-gi-disease-when-to-use-and-when-to-ditch

## 临床表现与诊断

犬产气荚膜梭菌感染通常表现为慢性间歇性或持续性腹泻，但也可能出现急性表现[1]。在某些情况下，可能出现类似出血性胃肠炎综合征的急性血性腹泻，其特征是红细胞压积增加[1]。犬通常表现出大肠腹泻症状，但也可能出现小肠表现[1]。发作可能仅持续一到两天，每周、每月或不频繁地周期性复发，通常由应激事件或饮食改变触发[1]。

在猫中，产气荚膜梭菌感染已被确立为不太常见但仍重要的腹泻原因[1]。临床症状与犬相似，慢性间歇性腹泻是主要表现[1]。

诊断可能具有挑战性，需要特定的检测方法。当在高倍油镜视野中观察到超过3-4个芽孢时，粪便细胞学检查可能提示感染，这些芽孢呈现为比大多数细菌更大的安全别针状结构[1]。然而，这只是推测性的，因为仅存在芽孢并不能确认诊断[1]。

确诊需要通过粪便ELISA检测鉴定产气荚膜梭菌肠毒素[1]。有商业ELISA检测可用于产气荚膜梭菌和艰难梭菌的诊断[2]。基于PCR的检测越来越多地用于区分细菌种类和鉴定毒素基因[2]。为获得最佳结果，应在异常粪便发作期间而非正常排便时收集粪便样本，因为在有症状的病例中肠毒素检出率更高[1]。

### Sources
[1] Clostridium difficile and C perfringens Infections in Animals: https://www.merckvetmanual.com/infectious-diseases/clostridial-diseases/clostridium-difficile-and-c-perfringens-infections-in-animals
[2] Diagnostic approach to diarrhea (Proceedings): https://www.dvm360.com/view/diagnostic-approach-diarrhea-proceedings

## 治疗与管理

伴侣动物产气荚膜梭菌感染的治疗侧重于抗菌治疗、支持性护理和饮食调整。泰乐菌素是首选的主要抗菌药物，以15-25 mg/kg的剂量口服，每日一次或两次[1]。这种大环内酯类抗生素对产气荚膜梭菌显示出优异的疗效，通常在开始治疗后12-24小时内解决腹泻[1][2]。替代抗菌药物包括甲硝唑（7.5-10 mg/kg，每日两次）和β-内酰胺类抗生素，但由于泰乐菌素的特定活性和最小副作用，它仍然是首选[1][2]。

支持性护理包括为脱水患者进行液体治疗和根据需要进行电解质管理[2]。高纤维饮食在治疗中发挥关键作用，特别是对于慢性或间歇性病例[1]。纤维来源如洋车前子、罐装南瓜或商业高纤维饮食有助于正常化肠道蠕动，促进有益细菌生长，同时抑制梭菌增殖[1]。治疗持续时间通常从急性病例的5天到慢性表现的2-4周不等[1]。

对治疗的反应通常是迅速且显著的，预计在12小时内出现临床改善[1]。在此时间框架内未能反应的病例需要重新评估诊断[2]。对于复发性感染，可能需要长期饮食纤维补充，一些患者需要间歇性抗菌治疗[1]。益生菌补充提供额外益处，与对照组相比，可将自限性腹泻的持续时间缩短32-41%[3]。

### Sources

[1] Is it IBD? (Proceedings): https://www.dvm360.com/view/it-ibd-proceedings
[2] Antibiotics in canine GI disease: when to use and when to ditch: https://www.dvm360.com/view/antibiotics-in-canine-gi-disease-when-to-use-and-when-to-ditch
[3] Gut check: https://www.dvm360.com/view/gut-check

## 预防与控制

伴侣动物产气荚膜梭菌感染的预防侧重于全面的环境管理和饮食控制策略。在犬舍、猫舍和多宠物家庭中保持严格的卫生规程至关重要，因为产气荚膜梭菌芽孢可以在环境中长时间存活并污染食物、水和表面[1]。

有效的环境消毒需要彻底清除所有固体粪便物质，然后进行蒸汽清洁，这对细菌芽孢非常有效。化学消毒可以使用含季铵盐的消毒剂完成，这些消毒剂在室温下能有效杀死产气荚膜梭菌[2]。定期的清洁规程和细致的猫砂盆维护有助于最大限度地减少环境污染和再感染风险。

饮食管理在预防中发挥关键作用。在7-10天内逐渐过渡食物有助于防止可能引发细菌过度生长的肠道紊乱。高质量、易消化的饮食可减少促进致病细菌增殖的发酵底物。避免餐桌食物、变质食物和高脂肪饮食可最大限度地减少可能引发肠毒素产生的饮食诱因[6]。

对于慢性病例，长期管理涉及识别和消除易感因素，如并发的寄生虫感染、饮食敏感性或潜在炎症性疾病。通过肠毒素检测分析进行定期粪便监测有助于评估治疗效果并预防复发[6]。

客户教育强调正确的食物储存、定期驱虫方案以及识别需要兽医关注的临床症状。主人应了解应激、抗菌治疗和饮食不当可能在易感动物中引发发作[9]。

### Sources

[1] A Risk Assessment for Clostridium perfringens in Ready-to-Eat and...: https://www.fsis.usda.gov/sites/default/files/media_file/2020-07/CPerfringens_Risk_Assess_ExecSumm_Sep2005.pdf

[2] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t

[6] How to manage feline chronic diarrhea, Part I: Diagnosis: https://www.dvm360.com/view/how-manage-feline-chronic-diarrhea-part-i-diagnosis

[9] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich

## 鉴别诊断与预后

现有部分提供了产气荚膜梭菌肠毒素中毒的鉴别诊断和预后因素的全面覆盖。将其与提供的来源材料综合，增强了对区分特征和临床管理原则的理解。

产气荚膜梭菌肠毒素中毒必须与众多细菌、病毒和寄生虫引起的急慢性腹泻原因进行鉴别[1][5]。主要细菌鉴别诊断包括沙门氏菌属、空肠弯曲杆菌和艰难梭菌，它们呈现类似的出血性结肠炎模式[1][5]。与这些病原体不同，产气荚膜梭菌的诊断特别依赖于通过ELISA进行粪便肠毒素检测，结合cpe基因的PCR鉴定，因为简单的芽孢计数超过每高倍视野3-5个仅具有提示性而非确定性[1][5]。

病毒原因，特别是幼犬的细小病毒，会产生严重的血性腹泻，但通常包括发热和白细胞减少等全身症状，这些症状将其与产气荚膜梭菌感染区分开来[1]。寄生虫感染，特别是贾第鞭毛虫属和犬鞭虫，通常引起伴有粘液和血液的大肠腹泻，但需要不同的诊断方法[1][2]。

产气荚膜梭菌肠毒素中毒的预后在适当的支持性护理下仍然良好[1][6]。大多数犬在使用基本液体治疗和饮食管理的情况下在24-48小时内恢复，即使在严重受影响的病例中也是如此[1][6]。然而，一些动物经历反复发作，特别是当饮食不当或应激等易感因素持续存在时[1]。长期并发症罕见，在免疫功能正常的动物中，感染很少进展为全身性疾病，确保在大多数病例中通过及时识别和支持性护理获得良好结果。

### Sources

[1] Bacterial diarrhea and related public health concerns: https://www.dvm360.com/view/bacterial-diarrhea-and-related-public-health-concerns-proceedings
[2] Diagnostic approach to chronic diarrhea in dogs and cats: https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[3] Gastrointestinal problems in pediatric patients require careful assessment: https://www.dvm360.com/view/gastrointestinal-problems-pediatric-patients-require-careful-assessment
[4] Antibiotics in canine GI disease: when to use and when to ditch: https://www.dvm360.com/view/antibiotics-in-canine-gi-disease-when-to-use-and-when-to-ditch
[5] Diagnostic approach to chronic diarrhea in dogs and cats: https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[6] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
