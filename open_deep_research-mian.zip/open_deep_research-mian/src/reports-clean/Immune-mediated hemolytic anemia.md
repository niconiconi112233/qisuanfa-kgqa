# 伴侣动物免疫介导性溶血性贫血

免疫介导性溶血性贫血（IMHA）是小动物临床中最具挑战性的血液学急症之一，尽管进行积极干预，死亡率仍高达30-60%。这种破坏性疾病发生时，免疫系统错误地靶向红细胞，导致快速发作的贫血，可能在数天内致命。该病主要影响中年母犬，可卡犬和贵宾犬具有明显的品种易感性，而在猫中则较为罕见。

本综合报告探讨了血管内和血管外溶血背后的复杂病理生理学，分析了传统库姆斯试验局限性等诊断挑战，并回顾了当前强调免疫抑制和血栓栓塞预防的治疗方案。对关键预后因素、长期管理策略以及康复患者疫苗接种的持续争议进行了深入分析，为兽医从业者提供管理这种危及生命疾病的循证指导。

## 疾病概述与流行病学

**定义**

免疫介导性溶血性贫血（IMHA）是犬的一种破坏性血液疾病，其中免疫球蛋白与红细胞表面抗原结合，通过补体激活（血管内）或被单核吞噬细胞清除（血管外）导致溶血[1]。当不存在可识别的触发因素时，IMHA被分类为原发性（特发性自身免疫性溶血性贫血），或当由潜在过程如肿瘤、传染病或药物反应引起时为继发性[1,3]。

**流行病学模式**

IMHA通常影响中老年犬，具有明显的雌性偏向--约四分之三的病例发生在绝育母犬中[1]。平均发病年龄约为六岁，尽管该病可在任何年龄发生[1]。

存在明显的品种易感性，美国可卡犬约占所有IMHA病例的四分之一[1,3]。其他易感品种包括贵宾犬、西施犬、拉萨犬、古代英国牧羊犬、边境牧羊犬和史宾格犬[1]。这些品种偏好表明遗传因素导致疾病易感性[3]。

已观察到季节性偏好，春季和夏季病例增加，可能反映了对外界过敏原或抗原刺激的增强暴露[1]。猫的IMHA不常见，通常继发于潜在疾病过程[2]。

### Sources
[1] Immune-mediated hemolytic anemia (Proceedings): https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-proceedings
[2] Immune-mediated thrombocytopenia--pathophysiology and diagnosis (Proceedings): https://www.dvm360.com/view/immune-mediated-thrombocytopenia-pathophysiology-and-diagnosis-proceedings
[3] Controversies in diagnosing IMHA (Proceedings): https://www.dvm360.com/view/controversies-diagnosing-imha-proceedings

## 病理生理学与临床表现

免疫介导性溶血性贫血涉及通过两种不同机制破坏红细胞。**血管内溶血**发生在补体激活在血管内溶解红细胞时，将游离血红蛋白直接释放到血浆和尿液中[1]。这通常由能有效激活补体的IgM抗体引起。**血管外溶血**更为常见，发生在IgG包被的红细胞通过网状内皮系统被脾脏和肝脏中的巨噬细胞清除时[1]。

免疫系统产生针对红细胞膜糖蛋白的抗体，其中IgG是最常见的抗体类型[2]。这些抗体要么消耗整个红细胞，要么去除膜部分，形成球形红细胞--缺乏中央淡染区的小圆形细胞，是IMHA的特征[2]。球形红细胞僵硬且易被破坏， perpetuating the hemolytic process.

**临床表现**包括典型的贫血症状：嗜睡、虚弱、苍白或黄疸性黏膜和运动不耐受[3]。患者可能出现有色尿液（血管内溶血时的血红蛋白尿或血管外溶血时的胆红素尿）和因红细胞清除增加导致的脾肿大[3]。血管内溶血产生更严重的症状，包括波特酒色尿液和血红蛋白血症[4]。

**物种特异性模式**显示IMHA主要影响中年犬（5-6岁），具有雌性偏向，可卡犬、贵宾犬和古代英国牧羊犬过度代表[4]。原发性IMHA在猫中罕见，其中继发于传染病或肿瘤的形式占主导[8]。

### Sources
[1] Immune-mediated hemolytic anemia (Proceedings): https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-proceedings
[2] Regenerative Anemias in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/anemia/regenerative-anemias-in-animals
[3] IMHA: Diagnosing and treating a complex disease: https://www.dvm360.com/view/imha-diagnosing-and-treating-complex-disease
[4] Immune-mediated hemolytic anemia: Understanding and diagnosing a complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-understanding-and-diagnosing-complex-disease
[5] Approach to anemia (Proceedings): https://www.dvm360.com/view/approach-anemia-proceedings
[6] Immune-mediated hemolytic anemia: Treating cats and dogs with a complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-treating-cats-and-dogs-with-complex-disease
[7] Anemia in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/blood-disorders-of-dogs/anemia-in-dogs
[8] The "RBCs" of feline anemia (Proceedings): https://www.dvm360.com/view/rbcs-feline-anemia-proceedings

## 诊断方法与鉴别诊断

IMHA的诊断检查需要系统方法以确认免疫介导性溶血并与其他原因区分[1]。确诊需要至少两个免疫介导破坏的迹象（球形红细胞增多、自身凝集或阳性库姆斯试验）加上溶血证据（高胆红素血症、血红蛋白血症或血红蛋白尿）[2]。

初始血液学发现通常包括再生性贫血，67-94%的犬出现球形红细胞[3]。玻片凝集试验提供即时诊断信息--将血液与盐水混合可区分真正的自身凝集与缗钱状形成。如果凝集试验为阴性，库姆斯试验（直接抗球蛋白试验）可检测表面抗体，尽管假阴性率高达50%[1,4]。

血涂片显示再生病例中的球形红细胞、多染性和网织红细胞。流式细胞术在检测抗红细胞抗体方面比库姆斯试验具有更高的敏感性[2]。生化谱通常显示高胆红素血症、缺氧引起的肝酶升高和潜在的器官损伤标志物[1,4]。

必要的鉴别诊断包括锌中毒（需要腹部X光检查）、氧化损伤（海因茨小体形成）、低磷血症和巴贝斯虫或埃里希体等传染性原因[1,5]。胸部和腹部影像学检查有助于识别潜在肿瘤或异物。必须通过适当的传染病检测和用药史回顾系统地排除继发性原因[1,3]。

### Sources

[1] Immune-mediated hemolytic anemia: Understanding and diagnosing a complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-understanding-and-diagnosing-complex-disease

[2] Regenerative Anemias in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/anemia/regenerative-anemias-in-animals

[3] Possible IMHA dog-now what?: https://www.dvm360.com/view/possible-imha-dog-now-what

[4] IMHA: Diagnosing and treating a complex disease: https://www.dvm360.com/view/imha-diagnosing-and-treating-complex-disease

[5] Approach to anemia (Proceedings): https://www.dvm360.com/view/approach-anemia-proceedings

## 治疗选择

先进的治疗方法超越了传统免疫抑制疗法，以解决IMHA患者的危及生命的并发症[3]。静脉注射人免疫球蛋白（HIVIG）通过Fc受体阻断为严重病例提供快速干预，但成本限制限制了其广泛使用[1][2]。低分子量肝素（达肝素、依诺肝素）在预防血栓栓塞并发症方面比普通肝素显示出优越的抗凝效果[1]。

当发生肺血栓栓塞时，尽管有预防性抗凝治疗，仍需要使用链激酶或尿激酶进行溶栓治疗[1]。长春新碱（0.02 mg/kg IV）在并发免疫介导性血小板减少症病例中通过对抗体包被的血小板产生细胞毒性作用而显示出疗效[2]。

先进干预措施包括用于快速抗体去除的血浆置换术和用于难治性病例的脾切除术，尽管其持续益处尚未得到证实[1]。人促红细胞生成素提供临时支持，但由于对外源蛋白产生抗体而常常失去效果[5]。严格的笼养休息减少氧气需求，而补充氧气提供的益处最小，因为在严重贫血中血红蛋白饱和度仍接近最大值[1][2]。

### Sources
[1] Immune-mediated hemolytic anemia (Proceedings): https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-proceedings
[2] Immune-mediated blood disorders--emergency management (Proceedings): https://www.dvm360.com/view/immune-mediated-blood-disorders-emergency-management-proceedings
[3] IMHA: Diagnosing and treating a complex disease: https://www.dvm360.com/view/imha-diagnosing-and-treating-complex-disease

## 预后与长期管理

IMHA的预后仍然谨慎，尽管进行积极治疗，总体存活率在40-70%之间[1]。多个预后因素影响犬IMHA患者的存活结果。最一致确定的负面预后指标包括高胆红素血症和肾功能降低标志物（血尿素氮和肌酐升高）[1]。报告的其他不良预后因素包括血小板减少症，特别是并发免疫介导性血小板破坏（埃文斯综合征）、血管内溶血和低白蛋白血症[1][4]。

血栓栓塞仍然是发病率和死亡率的最常见原因，在尸检中高达50%的IMHA犬发生[1]。有趣的是，与高凝患者相比，凝血功能指数正常的犬显示出更高的死亡风险，表明严重病例中存在弥散性血管内凝血[1]。

达到缓解的犬的复发率在11-15%之间[4]。长期免疫抑制治疗通常需要总共4-6个月的持续时间，必须仔细制定减量方案以防止复发[1]。只有在血细胞比容稳定后，才应逐渐减少药物剂量，大约每3-4周一次[1]。许多患者需要终身监测，缓解后第一年每季度复查一次，之后每半年一次[1]。

疫苗接种与IMHA复发之间的联系仍然不确定，尽管许多从业者建议对康复患者避免常规疫苗接种[1]。生活质量考虑包括管理长期药物副作用以及在免疫抑制期间监测机会性感染[1]。

### Sources

[1] Immune-mediated hemolytic anemia: Treating cats and dogs with complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-treating-cats-and-dogs-with-complex-disease

[2] Just Ask the Expert: A protocol for treating IMHA: https://www.dvm360.com/view/just-ask-expert-protocol-treating-imha

[3] Possible IMHA dog-now what?: https://www.dvm360.com/view/possible-imha-dog-now-what

[4] IMHA: Diagnosing and treating a complex disease: https://www.dvm360.com/view/imha-diagnosing-and-treating-complex-disease
