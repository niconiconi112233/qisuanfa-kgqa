# 伴侣动物脓疱疮：临床指南

脓疱疮是一种浅表性细菌皮肤感染，主要影响幼犬，在猫中罕见发生。该病主要由*伪中间型葡萄球菌*引起，表现为6周龄至4月龄幼犬腹部腹侧及其他毛发稀疏区域的非毛囊性脓疱。虽然通常在常规兽医检查中偶然发现，但脓疱疮需要及时识别和适当的抗菌治疗以防止并发症。本报告探讨了小动物临床实践中与脓疱疮相关的流行病学、临床表现、诊断方法、治疗方案和预后因素，为兽医管理这种幼年动物常见皮肤病提供循证指导。

## 疾病概述

脓疱疮是一种浅表性、非毛囊性细菌皮肤感染，常见于幼犬，罕见于猫[1]。该病主要影响6周龄至4月龄的幼犬，通常是在常规兽医检查中偶然发现，而非主要就诊原因[2]。

该病是一种表面性脓皮症，特点是角质层下脓疱，不累及毛囊，这与较深的细菌感染有所区别[2]。由于幼年动物的免疫系统尚未成熟和皮肤屏障功能正在发育，它们对感染性皮肤病的易感性增加[2]。

**伪中间型葡萄球菌**是犬脓疱疮的主要病原体，是犬皮肤感染最常见的细菌原因[3]。这种生物体是犬皮肤的正常寄生物，但在某些易感条件下会变得具有致病性。其他细菌种类可能包括凝固酶阴性葡萄球菌，以及较少见的其他常驻菌群[3]。

导致脓疱疮发展的环境因素包括促进细菌过度生长的温暖潮湿条件、卫生不良、过度拥挤，以及潜在因素如肠道寄生虫或营养缺乏[2][4]。该病通常影响毛发稀疏区域，特别是腹部腹侧，那里的皮肤环境有利于细菌增殖。

### Sources

[1] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[2] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[4] Staphylococcal skin diseases-an update (Proceedings): https://www.dvm360.com/view/staphylococcal-skin-diseases-update-proceedings

## 临床表现与诊断

犬脓疱疮表现为非毛囊性脓疱，主要影响6周龄至4月龄的幼犬[2]。该病通常表现为腹部腹侧、腹股沟和腋窝区域的浅表性脓疱，常在常规疫苗接种就诊期间偶然发现。

**临床症状和品种模式**
特征性病变包括大的、不规则的脓疱，可能融合，多个毛干穿过单个脓疱[2]。与较深的细菌感染不同，脓疱疮仅限于浅表表皮层。短毛品种常因多个浅表毛囊性丘疹而呈现独特的"虫蛀状"外观[2]。大多数病例无瘙痒，但可能出现轻微刺激。

**诊断方法**
诊断主要依赖于动物信息、临床表现、病变分布和对抗菌治疗的反应[2][4]。完整脓疱的细胞学检查显示非变性中性粒细胞，细菌参与最少，这可将脓疱疮与较深的脓皮症区分开来[2]。应进行深层皮肤刮片以排除蠕形螨病，而根据病变特征可考虑进行皮肤真菌培养[4]。

**鉴别诊断**
主要鉴别诊断包括浅表性细菌性毛囊炎、蠕形螨病、皮肤真菌病和落叶型天疱疮[3]。落叶型天疱疮可通过细胞学检查中发现棘层松解角质形成细胞来区分，且通常影响面部区域和耳廓凹面[3]。细菌培养和药敏试验保留用于治疗反应不佳的病例[6]。

### Sources
[1] Pathology in Practice in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.06.0328.xml
[2] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[3] Canine and feline pemphigus foliaceus: Improving your: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome
[4] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[5] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[6] Dermatophytosis in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats

## 治疗与管理

犬和猫的脓疱疮需要综合方法，包括药物和非药物干预。治疗成功取决于适当的伤口管理、合适的抗菌治疗以及解决潜在的易感因素[1]。

### 局部抗菌治疗

对于简单的表面性和浅表性脓皮症，单独使用局部抗菌治疗可能就足够了。氯己定（1-4%）和碘载体是有效的一线局部抗菌剂[1]。这些药物可作为轻中度浅表感染的唯一治疗方法，并可缩短较严重感染的治疗时间[1]。

MURICIN™软膏（2%莫匹罗星）是一种水可去除的局部治疗药物，专门批准用于犬细菌性皮肤感染，包括浅表性脓皮症。该软膏含有莫匹罗星，一种天然存在的广谱抗生素，对革兰氏阳性菌有效，包括*金黄色葡萄球菌*和*中间型葡萄球菌*[3]。

### 抗菌药浴

使用含有氯己定或过氧化苯甲酰的抗菌香波进行药浴可提供有效的辅助治疗[1][5]。这些香波可去除皮肤表面的细菌，并可能加速临床康复。对于幼犬的脓疱疮，每3-7天使用含有氯己定或三氯生的温和抗菌香波进行药浴通常就足够了[7]。

### 全身性抗生素治疗

当单独局部治疗不足时，需要全身性抗生素。一线抗菌药物包括头孢氨苄、头孢羟氨苄、阿莫西林-克拉维酸、甲氧苄啶-磺胺类和林可酰胺类[1]。治疗持续时间应延长至临床痊愈后，并在表面愈合后继续7-14天，浅表感染通常为3-4周[1]。

### 环境管理与卫生

环境控制包括保持适当的卫生和解决易感因素。应评估幼年动物的肠道寄生虫，并应审查和修改其饮食和环境[7][8]。对于严重或耐药感染，可能需要适当的伤口覆盖和隔离措施[9]。

### Sources

[1] Merck Veterinary Manual Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals

[2] Journal of the American Veterinary Medical Association Topical therapy for canine pyoderma: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0001.xml

[3] DVM 360 Dechra's muricin topical treatment for canines: https://www.dvm360.com/view/dechras-muricin-topical-treatment-canines

## 预后与并发症

犬脓疱疮在适当治疗下通常预后良好。该病通常在开始适当的抗菌治疗后7-10天内完全痊愈[1]。大多数病例是局限于皮肤上层的浅表性细菌皮肤感染，在适当选择一线抗生素时反应良好。

全身性抗菌治疗的持续时间应至少持续3周，并在临床痊愈后继续至少1周，以防止复发[1]。基于培养和药敏试验早期进行适当的抗生素选择可显著改善结果[2]。

在简单病例中并发症通常罕见。然而，如果该病未经治疗或管理不当，可能会发生继发性细菌感染。耐甲氧西林葡萄球菌的出现是最重要的预后问题，因为这些病例需要延长治疗时间和专门的抗生素方案[2]。

治疗失败最常见的原因是抗生素选择不当、治疗持续时间不足或潜在的易感因素如过敏或免疫抑制[3]。由于伪中间型葡萄球菌产生β-内酰胺酶，应避免经验性使用青霉素、阿莫西林和氨苄西林，以防止治疗失败[3]。

在简单病例中复发不常见，但在与潜在皮肤病相关的复杂感染中可能发生。正确识别和管理易感因素可显著降低复发风险。

### Sources
[1] questioning the duration of systemic antimicrobial therapy for: https://avmajournals.avma.org/view/journals/javma/260/10/javma.22.03.0113.xml
[2] Staphylococcal skin diseases-an update (Proceedings): https://www.dvm360.com/view/staphylococcal-skin-diseases-update-proceedings
[3] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
