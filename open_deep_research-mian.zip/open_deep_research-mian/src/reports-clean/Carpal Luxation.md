# 伴侣动物腕关节脱位

腕关节脱位是兽医实践中的一项重要骨科挑战，涉及犬猫腕关节复合体内骨骼的移位。这种情况从需要先进诊断技术的轻微半脱位到导致严重跛行和功能障碍的完全关节脱位不等。该损伤主要通过创伤性过伸事件影响运动型和竞技型犬，但也有先天性形式发生。

本综合报告探讨了腕关节脱位的多方面性质，从其流行病学模式和临床表现到当前的诊断方法和治疗方式。分析涵盖了保守管理策略、包括关节融合术在内的手术干预，以及影响患病伴侣动物恢复结果的预后因素。

## 摘要

伴侣动物的腕关节脱位是一种复杂的骨科疾病，需要系统性的诊断和治疗方法。该疾病主要通过创伤机制影响大型品种和竞技型犬，临床表现从轻微的间歇性跛行到完全不能负重和特征性的跖行姿态不等。

诊断依赖于全面的体格检查结合放射学评估，应力放射摄影和先进成像技术对于检测轻微不稳定性至关重要。治疗方法从轻度病例的外部支持保守管理到严重损伤的手术干预（包括韧带修复或关节融合术）不等。

| 严重程度 | 治疗方法 | 预后 | 恢复时间 |
|----------|-------------------|-----------|---------------|
| 1-2级扭伤 | 保守治疗（夹板/绷带） | 极好 | 6-8周 |
| 3级/完全脱位 | 手术修复/关节融合术 | 良好至极好 | 8-12周 |
| 慢性/未经治疗 | 复杂手术重建 | 谨慎 | 不定 |

通过环境改造、体重管理和活动限制进行预防对于高危动物至关重要。虽然手术结果通常有利，报告成功率为93%，但长期运动表现可能会受到影响。早期干预和适当的术后依从性显著影响恢复，尽管韧带在愈合后仅恢复原强度的60%。

## 疾病概述

腕关节脱位是影响犬猫腕关节的重要骨科疾病。这种情况涉及构成腕部的骨骼之间正常解剖对位的移位或完全丧失，最常影响桡腕关节和腕骨间关节[1]。

由于兽医文献中的报告不足，伴侣动物腕关节脱位的流行病学数据仍然有限[1]。然而，该疾病在大型和巨型品种犬中似乎更为常见，有证据表明发育因素可能影响易感性[2]。由于腕关节的复杂性质及其在负重过程中作为减震器的作用，腕关节损伤在敏捷和竞技犬中特别常见[3]。

年龄易感性根据潜在原因而异。先天性腕关节脱位出生时就存在，可能与肌肉骨骼系统更广泛的发育异常有关[1]。创伤性脱位可发生在任何年龄，但在从事高强度活动的活跃大型品种犬中更为常见[3]。

### Sources

[1] Congenital and Inherited Anomalies of the Musculoskeletal System in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats

[2] Looking at canine angular limb deformities in a new way: https://www.dvm360.com/view/forefront-looking-canine-angular-limb-deformities-new-way

[3] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings

## 常见病原体

虽然腕关节脱位主要是创伤性骨科疾病，但感染性病原体可通过化脓性关节炎或损伤后的继发性细菌污染导致关节不稳定[1]。

**细菌病原体**
影响小动物关节的最常见细菌性化脓性关节炎病因包括葡萄球菌、链球菌和大肠杆菌[1]。金黄色葡萄球菌和表皮葡萄球菌通常与关节注射或手术操作后的医源性感染有关[1]。这些细菌可导致关节破坏和韧带不稳定，可能诱发或加重腕关节脱位。

**非细菌病原体**
其他感染性病原体可引起伴侣动物的关节炎。立克次体生物，包括引起落基山斑疹热和埃里希氏体病的生物，可产生化脓性关节炎[1][2][3]。引起莱姆病（疏螺旋体病）的螺旋体也可影响关节结构[1][2][3]。

**感染途径**
感染性关节炎通常通过细菌经血液的血流播散或通过穿透性创伤（包括手术操作）直接引入而发展[1][2][3]。在伴有开放性伤口的腕关节脱位病例中，细菌污染可能导致继发性化脓性关节炎，可能使愈合和关节稳定复杂化。应进行培养和药敏试验以排除低度化脓性关节炎，特别是当单个关节严重受累时[4]。

### Sources
[1] Septic Arthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/septic-arthritis-in-dogs-and-cats
[2] Joint Disorders in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/bone-joint-and-muscle-disorders-of-cats/joint-disorders-in-cats
[3] Other Joint Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/other-joint-disorders-in-dogs
[4] Polyarthritis: clinical approach to medical joint disease (Proceedings): https://www.dvm360.com/view/polyarthritis-clinical-approach-medical-joint-disease-proceedings

## 临床症状和体征

现有部分全面涵盖了腕关节脱位的症状和体征。然而，来源4（默克关节创伤）包含关于掌侧腕关节塌陷的相关信息，这是一种与腕关节脱位具有相似临床表现的过伸性损伤。

患有腕关节脱位的犬通常表现为不同程度的急性或慢性跛行[1]。临床症状的出现和严重程度取决于脱位的原因和程度。

**跛行模式**
受影响的犬表现出可见的跛行，可能是间歇性或持续性的。在急性创伤性病例中，犬表现出突发性的非负重性跛行。在慢性或重复性损伤中，跛行可能缓慢进展，在运动或活动后变得更加明显[1][2]。

**关节肿胀和疼痛**
触诊显示腕关节周围软组织肿胀，当该区域被操作时犬表现出不适[1]。疼痛通常在关节屈曲、伸展或应力测试时引发。关节积液可能表现为波动性肿胀，由于关节囊增厚，髌骨韧带可能变得不那么明显[3]。

**关节不稳定**
体格检查显示施加应力时关节活动异常。受影响的腕部在内翻或外翻应力测试期间可能显示关节间隙过度张开，或在活动范围评估期间出现异常滑动（半脱位）[1]。通过与对侧正常肢体比较，不稳定性通常最为明显。

**姿势改变**
在严重病例中，特别是掌侧腕关节塌陷，由于腕关节塌陷，犬表现出特征性的跖行姿态[4]。这种过伸畸形是由于腕部承受过度力量导致掌侧腕韧带撕裂所致。

**继发性变化**
慢性病例可能在关节操作期间出现摩擦音，这是由于软骨损伤和继发性骨关节炎[1]。犬可能表现出受影响肢体的肌肉萎缩，并采取代偿性姿势或步态以减少受伤腕部的负重。

**品种特异性考虑**
虽然腕关节脱位可影响任何品种，但由于运动活动期间腕关节承受重复性应力，运动型和敏捷犬常受影响[1]。

### Sources
[1] Carpal & tarsal sports related injuries (Proceedings): https://www.dvm360.com/view/carpal-tarsal-sports-related-injuries-proceedings
[2] Diagnosing and treating strains and sprains (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-strains-and-sprains-proceedings
[3] Diagnosing and treating rear limb disorders in dogs ...: https://www.dvm360.com/view/diagnosing-and-treating-rear-limb-disorders-dogs-proceedings
[4] Joint Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 诊断方法

诊断腕关节脱位需要系统性的方法，结合临床检查和适当的成像技术。体格检查应包括对腕关节的彻底触诊，以评估软组织肿胀、关节积液、疼痛反应以及在关节伸展、屈曲、内翻或外翻方向施加应力时的不稳定性[1]。与对侧肢体比较有助于识别异常，因为在早期病例中关节不稳定可能很轻微[1]。

标准放射摄影是腕关节脱位诊断的基础，需要正交投影（头尾位和内外侧位）来可视化关节对位并识别骨折或脱位[1]。然而，对于在标准放射照片上不易看到的半脱位，应力放射摄影对于明确诊断变得至关重要，检查者施加特定方向的力量以证明韧带完整性和关节不稳定[2]。

当标准技术无法确定时，先进成像方式提供额外的诊断价值。荧光透视提供关节运动的实时可视化，允许在操作期间检测关节间隙过度张开或异常滑动[3]。这种动态评估优于静态应力放射照片，用于评估腕关节不稳定。当临床症状提示腕关节损伤但放射学异常不存在时，磁共振成像可以识别轻微的韧带扭伤和软组织损伤[1]。

当存在关节积液或怀疑多发性关节炎时，应进行关节穿刺，特别是为了区分炎症性和机械性腕关节功能障碍的原因[4]。滑液分析有助于区分可能表现为与腕关节脱位相似的感染性、免疫介导性和创伤性关节疾病。

### Sources
[1] Carpal & tarsal sports related injuries (Proceedings): https://www.dvm360.com/view/carpal-tarsal-sports-related-injuries-proceedings
[2] Distal limb injury: The hind-limb (Proceedings): https://www.dvm360.com/view/distal-limb-injury-hind-limb-proceedings
[3] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings
[4] Arthrocentesis: Quick cytologic diagnosis of orthopedic conditions (Proceedings): https://www.dvm360.com/view/arthrocentesis-quick-cytologic-diagnosis-orthopedic-conditions-proceedings

## 治疗选择

腕关节脱位的治疗根据严重程度而异，可能涉及保守管理或手术干预。轻度至中度韧带扭伤（1级和2级）通常可以通过外部支持进行管理，使用专用绷带、矫形器或夹板6-8周，结合康复治疗[1]。对于更严重的病例，可以在受伤关节的上方和下方放置带铰链的外固定器，以允许控制的活动范围，同时支持愈合结构[1]。

导致不稳定的严重扭伤或脱位通常需要手术治疗[1]。手术选择包括撕裂韧带的初级修复、放置假体韧带（缝线）以替代受伤结构，或部分至完全关节融合术[1]。使用骨板和螺钉、针和钢丝或外骨骼固定的全腕关节融合术是腕关节过伸损伤的既定治疗方法[2]。部分关节融合术可以稳定中腕关节或腕掌关节，同时保持大部分关节活动，而完全关节融合术对于桡腕关节不稳定可能是必要的[1]。

术后护理需要至少6周的外部绷带支持，逐渐康复包括活动范围练习和控制性活动[1]。使用非甾体抗炎药和冷冻疗法进行疼痛管理有助于减少炎症并提高患者在愈合期间的舒适度[2]。物理康复方案可增强恢复结果并帮助恢复最佳关节功能[3]。

### Sources

[1] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings

[2] Joint Trauma in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

[3] Physical rehabilitation: Improving the outcome in dogs with orthopedic problems: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems

## 预防措施

伴侣动物腕关节脱位的预防主要集中在环境改造和生活方式管理策略上。由于腕关节损伤通常由过伸事件、创伤和关节结构的重复性应力引起[2]，对高危动物实施预防措施至关重要。

环境安全是最关键的预防策略。避免可能导致过伸损伤的高强度活动至关重要[2]。宠物主人应阻止宠物从过高的表面跳下，因为这是严重腕关节损伤的最常见原因之一[2]。提供坡道或台阶以进入抬高的表面可减少腕关节的冲击力。

体重管理在预防关节应力和随后的损伤中起着重要作用。将宠物保持在平均体重或略低于平均体重可减少通过关节炎关节的力传递，并减少关节软骨和软骨下骨的损伤[4]。这种体重减轻可缓解受影响动物的疼痛并增加活动水平。

对于运动型和工作犬，在训练和比赛期间可使用支撑性绷带和矫形器提供保护[2][5]。专门的腕部支撑设备如Carpo-Flex氯丁橡胶绷带适用于轻度关节保护和预防再损伤[5]。这些支撑装置允许控制性活动，同时保护易受损伤的关节结构。

对于现有腕关节问题的犬，建议进行活动调整。首选在平坦表面上进行运动，而应阻止从抬高的表面上下跳跃[2]。定制支撑绷带可能有利于患有慢性腕关节损伤的敏捷犬在练习期间使用[2]。

### Sources

[1] Congenital and Inherited Anomalies of the Musculoskeletal System in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats

[2] Carpal & tarsal sports related injuries (Proceedings): https://www.dvm360.com/view/carpal-tarsal-sports-related-injuries-proceedings

[3] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management

[4] Degenerative joint disease in the cat (Proceedings): https://www.dvm360.com/view/degenerative-joint-disease-cat-proceedings

[5] Orthopedic devices (stifle braces, orthotics, etc.) (Proceedings): https://www.dvm360.com/view/orthopedic-devices-stifle-braces-orthotics-etc-proceedings

## 鉴别诊断

腕关节脱位必须与几种表现出相似临床症状的肌肉骨骼疾病进行区分。腕关节扭伤是最常见的鉴别诊断，表现为跛行和关节疼痛，但缺乏完全脱位时明显的移位[1]。扭伤按严重程度分类：1级（轻度过度拉伸）、2级（部分韧带撕裂）和3级（完全断裂），只有3级扭伤导致与脱位相当的关节不稳定[1]。

腕关节骨折，特别是侧副韧带附着处的撕脱骨折和副腕骨骨折，可模拟脱位症状[1,2]。骨折通常显示明显的放射学变化，包括骨不连续，而脱位表现为关节间隙增宽和骨骼移位而无骨折线[3]。

当多个关节受影响时，必须考虑免疫介导性多发性关节炎（IMPA）[4]。IMPA导致多个关节出现跛行、关节肿胀和疼痛，通常伴有发热和嗜睡等全身症状[4,5]。滑液分析显示中性粒细胞计数升高（>3,000个/μL）可将IMPA与机械性损伤区分开来[4]。

骨关节炎表现为慢性、进行性僵硬和跛行，特别是在休息后，但缺乏脱位的急性发作和明显的关节移位[6]。鉴别因素包括逐渐发作、骨关节炎中常见的双侧对称性，以及显示关节间隙变窄和骨赘形成而非急性移位的特征性放射学变化[5,6]。

### Sources

[1] Carpal & tarsal sports related injuries (Proceedings): https://www.dvm360.com/view/carpal-tarsal-sports-related-injuries-proceedings
[2] Joint Disorders in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/bone-joint-and-muscle-disorders-of-cats/joint-disorders-in-cats
[3] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings
[4] DVM 360 Recognizing and treating immune-mediated polyarthritis in dogs: https://www.dvm360.com/view/recognizing-and-treating-immune-mediated-polyarthritis-dogs
[5] Merck Veterinary Manual Immune-mediated Arthritis in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/immune-mediated-arthritis-in-dogs-and-cats
[6] Osteoarthritis (Degenerative Joint Disease) - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/osteoarthritis-degenerative-joint-disease

## 预后

腕关节脱位的预后根据损伤严重程度、治疗方法和个体患者因素而有显著差异[1]。

对于手术管理的病例，结果通常是有利的。在接受手术治疗的运动型犬中，大多数患者的预后良好至极好，尽管他们手术后的运动表现水平尚未经过科学评估[1]。外骨骼固定治疗猫腕关节损伤的成功率显示93%的成功结果，完全拆除固定器的中位时间为8周[2]。

几个因素影响预后。早期诊断和适当治疗显著改善结果，而慢性、未经治疗的损伤增加了骨关节炎和潜在长期跛行的风险[3]。韧带损伤的程度影响恢复--1级和2级扭伤通常对保守治疗反应良好，而需要手术干预的3级扭伤可能有更谨慎的预后[3]。

患者对术后护理的依从性至关重要，因为在骨科病例中不遵守随访建议很常见，大量患者失访[4]。对于竞技运动员，恢复到之前的运动水平可能受到限制，特别是在涉及多发性韧带损伤或需要关节融合术的病例中[3]。

长期考虑因素包括韧带在一年愈合后仅恢复约60%的原始强度[5]。修复失败、持续性不稳定或退行性关节疾病发展等并发症可能对预后产生负面影响，特别是在治疗延迟或愈合期间固定不充分的病例中。

### Sources
[1] Sporting dog injuries: https://www.dvm360.com/view/sporting-dog-injuries
[2] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[3] Carpal & tarsal sports related injuries (Proceedings): https://www.dvm360.com/view/carpal-tarsal-sports-related-injuries-proceedings
[4] Nonadherence to follow-up recommendations is common for orthopedic surgery patients: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.21.01.0019.xml
[5] Treating tendon and ligament injuries in dogs: https://www.dvm360.com/view/treating-tendon-and-ligament-injuries-dogs-surgery-platelet-rich-plasma-laser-therapy-proceedings
