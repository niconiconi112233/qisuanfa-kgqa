# 葡萄球菌感染

## 疾病概述

**定义**

伴侣动物的葡萄球菌感染是一种由葡萄球菌属引起的细菌性皮肤病，在犬和猫中最常见的是伪中间型葡萄球菌（默克兽医手册，2024年）。这些感染表现为浅表性或深部脓皮病，其特征是影响皮肤和毛囊的脓疱、丘疹、结痂和表皮领圈（DVM360，2024年）。

**流行病学背景**

葡萄球菌性脓皮病是小动物兽医临床中最常见的皮肤病之一（默克兽医手册，2024年）。伪中间型葡萄球菌是犬类皮肤的主要常驻菌，也是犬类脓皮病的主要病因，而金黄色葡萄球菌感染较少见但临床意义重大（DVM360，2024年）。耐甲氧西林菌株的出现，特别是耐甲氧西林伪中间型葡萄球菌（MRSP）和耐甲氧西林金黄色葡萄球菌（MRSA），显著增加了治疗方案的复杂性，并提高了基于培养的治疗选择的重要性（JAVMA，2024年）。这些耐药生物已成为犬和猫中的重要病原体，其中MRSP代表有特应性等基础疾病的犬的原发感染，而MRSA感染通常发生在人类接触和定植后的继发感染（DVM360，2024年）。

## 常见病原体

伴侣动物的葡萄球菌感染主要由特定的细菌种类引起，这些细菌在犬和猫之间有所不同。在犬中，伪中间型葡萄球菌（以前称为中间型葡萄球菌）是皮肤最常见的常驻菌，也是犬类脓皮病最常见的原因[1]。虽然金黄色葡萄球菌不被认为是犬类的正常菌群，但伴侣动物确实携带其他可能成为致病菌的葡萄球菌种[2]。

耐甲氧西林的出现显著增加了治疗的复杂性。耐甲氧西林伪中间型葡萄球菌（MRSP）已成为引起犬和猫感染的重要临床病原体[3]。这些生物获得了由mecA基因编码的青霉素结合蛋白（PBP2a），该基因赋予对所有β-内酰胺类抗菌药物的耐药性[1]。

宠物中的耐甲氧西林金黄色葡萄球菌（MRSA）感染通常是继发感染，因为大多数接触人类MRSA的小动物会暂时定植而不是发展为临床疾病[2]。耐甲氧西林施莱福氏葡萄球菌（MRSS）代表了另一种新兴病原体，研究表明施莱福氏葡萄球菌的耐甲氧西林发生率高于金黄色葡萄球菌或伪中间型葡萄球菌[3]。

原发与继发感染模式因物种而异。大多数MRSP感染代表有特应性等基础疾病的犬的原发性细菌感染，而MRSA感染通常继发于人类接触和定植[2]。

### Sources
[1] Surgery STAT: Managing methicillin-resistant wound infections: https://www.dvm360.com/view/surgery-stat-managing-methicillin-resistant-wound-infections
[2] The emergence and prevalence of MRSA, MRSP, and MRSS in pets and people: https://www.dvm360.com/view/emergence-and-prevalence-mrsa-mrsp-and-mrss-pets-and-people
[3] Managing MRSA, MRSP, and MRSS dermatologic infections in pets: https://www.dvm360.com/view/managing-mrsa-mrsp-and-mrss-dermatologic-infections-pets

## 临床症状和体征

犬和猫的葡萄球菌感染表现出多样化的临床表现，因位置和严重程度而异。浅表性脓皮病是最常见的表现形式，特征是脓疱、丘疹、结痂、表皮领圈、红斑和自发性脱毛[1]。典型病变表现为毛囊管型、毛囊炎和瘘管，伴有异味和不同程度的瘙痒[1]。

深部脓皮病表现更为剧烈，伴有肿胀、疼痛、外周淋巴结肿大、嗜睡、发热和引流道，可能导致败血症[2]。犬可能表现出出血性毛囊炎和广泛组织受累，需要紧急干预[1]。

存在品种易感性，某些梗犬品种、杜宾犬、斗牛犬、斯塔福德郡梗犬和罗威纳犬对过度瘢痕形成和慢性感染表现出更高的易感性[1]。幼龄动物可能发生脓疱疮，表现为主要影响幼犬腹部的非瘙痒性浅表脓疱[4]。

耐甲氧西林葡萄球菌感染在临床上与甲氧西林敏感感染没有区别[5]。体格检查结果无法区分耐药性脓皮病，因此培养测试对于正确诊断至关重要[6]。犬的表现通常涉及躯干、腋窝和腹股沟，而猫的葡萄球菌感染较少见，但可能表现出相似病变[3]。在猫中，脓疱较少见；丘疹、结痂、皮屑增多、剥脱性皮炎和鳞屑是更典型的表现[6]。

### Sources

[1] Got a pyoderma? Step away from the systemics: https://www.dvm360.com/view/got-pyoderma-step-away-systemics
[2] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[3] Derm's dirty Dozen, The top chronic, recurrent cases destined to cause frustration: https://www.dvm360.com/view/derms-dirty-dozen-top-chronic-recurrent-cases-destined-cause-frustration
[4] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[5] Managing MRSA, MRSP, and MRSS dermatologic infections in pets: https://www.dvm360.com/view/managing-mrsa-mrsp-and-mrss-dermatologic-infections-pets
[6] If drug-resistant pyoderma scares you, don't panic. Plan.: https://www.dvm360.com/view/if-drug-resistant-pyoderma-scares-you-don-t-panic-plan-

## 诊断方法

伴侣动物葡萄球菌感染的诊断主要依靠临床表现评估结合几种实验室技术。皮肤细胞学是最有价值的初步诊断工具，可以识别炎症细胞和细菌[1]。该技术涉及通过脓疱或丘疹的印片、干燥病变的透明胶带、引流道的棉签或结节的细针穿刺收集样本[1]。

细菌培养和药敏测试对于复发性脓皮病病例至关重要，因为耐药感染的发生率增加，并且对于选择适当的全身性抗菌治疗至关重要[1]。应对反应不佳的浅表性细菌性毛囊炎、细胞学上仅有杆状细菌的深部脓皮病或之前接受过抗生素治疗的病例进行培养[3]。应要求肉汤微量稀释法（MIC）而非纸片扩散测试，因为它提供定量结果，既指示敏感性又指示适当的抗生素剂量[3]。

对于耐甲氧西林葡萄球菌的检测，兽医实验室应使用苯唑西林敏感性测试而非头孢西丁[3]。适当的样本收集需要避免表面碎屑或坏死材料的污染[2]。兽医与微生物学实验室之间的合作对于细菌感染的最佳诊断和治疗结果至关重要[2]。

### Sources
[1] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[2] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[3] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings

## 治疗选项

### 高级全身性抗生素选择

对于耐甲氧西林葡萄球菌感染，氟喹诺酮类药物被认为是犬和猫的二线抗生素，但对于多重耐药生物应预期治疗失败[1]。恩诺沙星在猫中有特定的安全性问题，每日剂量超过5 mg/kg与视网膜变性有关，这是由于影响药物转运的遗传多态性所致[1]。

当培养结果指导选择时，氯霉素对北美耐甲氧西林分离株保持优异活性，在某些研究中对耐药菌株的有效率达到100%[3]。然而，由于潜在的骨髓抑制作用，治疗需要仔细监测。

### 非药物干预措施

耐药感染的伤口管理方案强调隔离程序和环境控制[7]。患者应使用适当的个人防护设备处理，所有仪器必须在每次使用之间消毒。对于渗出性或坏死性病变，每日清创和冲洗的开放伤口管理优于封闭管理。

### 护理考虑因素

治疗成功在很大程度上取决于依从性和正确的应用技术[6]。像Phovia这样的光基疗法在浅表性脓皮病中比单独使用抗生素愈合快36%，提供无痛应用，改善患者配合度。这些替代模式在抗生素敏感和耐药细菌群中提供了宝贵的抗生素节约选择，同时保持治疗效果。

### Sources

[1] Quinolones, Including Fluoroquinolones, Use in Animals: https://www.merckvetmanual.com/pharmacology/antibacterial-agents/quinolones-including-fluoroquinolones-use-in-animals

[2] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals

[3] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings

[4] Managing superficial pyoderma with light therapy: https://www.dvm360.com/view/managing-superficial-pyoderma-with-light-therapy

[5] Managing methicillin-resistant wound infections: https://www.dvm360.com/view/surgery-stat-managing-methicillin-resistant-wound-infections

## 预防措施

有效的葡萄球菌感染预防需要在兽医机构、家庭和临床环境中实施全面的环境控制和卫生方案[1]。

**环境控制和设施卫生**

兽医机构必须实施书面生物安全计划，对表面、设备和洗衣物品进行适当的消毒程序[1]。AAHA感染控制指南建议使用经EPA注册的对葡萄球菌细菌有效的消毒剂进行常规清洁。病房需要定期消毒，污染材料需要妥善处理以防止患者之间交叉污染。

**抗菌药物管理和耐药预防**

负责任的抗生素使用对于预防耐甲氧西林葡萄球菌感染（MRSA/MRSP）至关重要，这些感染在兽医医学中越来越常见[2]。一线抗生素包括第一代头孢菌素、阿莫西林-克拉维酸和克林霉素，应在怀疑耐药时适当使用并结合敏感性测试[2]。培养和敏感性测试指导治疗决策，特别是对于复发性感染。

**个人防护设备和手部卫生**

医护人员应遵循严格的手部卫生程序，在每次患者接触前后用肥皂和水洗手或使用含酒精的消毒剂[1]。包括手套、长袍和口罩在内的防护设备可防止直接细菌传播，在处理受感染动物或污染材料时尤为重要。

**基础疾病管理**

免疫系统受损、患有糖尿病等慢性疾病或最近接受过手术的宠物需要加强预防措施[1]。环境压力减轻和最佳营养支持免疫功能，降低感染易感性。

**隔离和接触预防措施**

受感染动物应隔离以防止传播[1]。毛巾、床上用品和美容工具等共用物品必须避免使用或在每次使用之间适当消毒。家庭成员应采取类似的预防措施以防止人畜共患病传播。

### Sources

[1] Hazards Related to Environmental and Infectious Diseases in Veterinary Medicine - Public Health - Merck Veterinary Manual: https://www.merckvetmanual.com/public-health/occupational-safety-and-health/hazards-related-to-environmental-and-infectious-diseases-in-veterinary-medicine
[2] The Paw-fect prescription: Antimicrobials for staphylococcal infections in small animals: https://www.dvm360.com/view/the-paw-fect-prescription-antimicrobials-for-staphylococcal-infections-in-small-animals

## 鉴别诊断

犬和猫的葡萄球菌感染必须与几种表现出相似皮肤病变的疾病进行鉴别。关键鉴别诊断包括皮肤癣菌病、蠕形螨病、过敏性皮炎和其他细菌感染[1][2]。

**皮肤癣菌病**与细菌性脓皮病有重叠的临床体征，包括脱毛、丘疹和结痂病变。应根据信号特征、病变分布和感染程度考虑皮肤癣菌培养[1][2]。

**蠕形螨病**是一个关键的鉴别诊断，特别是对于浅表性细菌性毛囊炎。所有病变与浅表性细菌性毛囊炎或深部脓皮病一致的犬都需要深度皮肤刮片以识别蠕形螨，因为蠕形螨病可能是继发性细菌感染的基础原因[1][2]。

**过敏性皮炎**包括特应性皮炎、皮肤不良反应和跳蚤过敏皮炎，通常易导致继发性葡萄球菌感染。这些疾病可能表现出相似的瘙痒性、红斑性病变，伴有丘疹和脓疱[1][2]。

**马拉色菌皮炎**与葡萄球菌性脓皮病非常相似，通常作为合并感染发生。必须进行细胞学检查以确定是否存在一种或两种生物[3]。两种疾病都可能表现出相似的瘙痒性、红斑性病变。

**落叶型天疱疮**当存在脓疱时应考虑，因为脓疱中的棘层松解角质形成细胞有助于将这种自身免疫性疾病与细菌性脓皮病区分开来[1][2]。

**关键鉴别方法**包括印片评估感染剂和棘层松解角质形成细胞、皮肤刮片检查寄生虫、必要时进行皮肤癣菌培养，以及系统评估基础易感因素，包括超敏反应和内分泌病[1][2]。

### Sources
[1] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[2] Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Update on treatment of Malassezia dermatitis: https://www.dvm360.com/view/update-treatment-malassezia-dermatitis-proceedings
