# 伴侣动物急性肾损伤

急性肾损伤是兽医医学中的危重急症，其特征是肾功能迅速恶化，可能在数小时至数天内进展为危及生命的并发症。本综合临床指南探讨了犬猫急性肾损伤的多面性，涉及兽医在临床实践中遇到的各种感染性和毒性病因。该报告综合了当前的诊断方法，从传统实验室标志物到新兴生物标志物如SDMA，同时探讨了循证治疗方案，包括液体疗法、电解质管理和肾脏替代治疗。特别强调了预防策略和鉴别诊断技术，以实现早期识别和干预，最终改善这一挑战性疾病的患者预后。

## 疾病概述

**定义：** 急性肾损伤（AKI）定义为在数小时至数天内发生的肾功能迅速恶化，特征是无法维持体液、电解质和酸碱稳态（默克兽医手册，2024年）。国际肾脏兴趣协会（IRIS）基于血清肌酐升高提供标准化分级：I级（≥0.3 mg/dL升高或1.5-1.9倍基线值）、II级（2-2.9倍基线值），更高等级用于更严重的升高（JAVMA，2024年）。

**流行病学背景：** AKI影响所有年龄段的犬和猫，但出现某些人口统计学模式。在猫中，AKI患者主要是老年雌性，通常伴有潜在的慢性肾病（JAVMA，2023年）。由于其快速进展的潜力和未经治疗的高死亡率，该疾病具有重要的临床意义。钩端螺旋体病已成为北美犬的常见细菌性病因，而百合毒性仍然是猫的常见原因。预后因潜在病因而异，与感染性或缺血性病因相比，及时治疗的毒性暴露通常预后更好。

## 常见病原体

伴侣动物的急性肾损伤可由各种传染性病原体引起，这些病原体直接损害肾组织或引发免疫介导的肾脏损伤。

### 病毒性病因
猫传染性腹膜炎（FIP）是猫AKI的重要病毒性病因[1][2]。FIP由某些猫冠状病毒（FCoV）株引起，在5-12%的感染猫中发生[2]。其发病机制涉及转化为毒力生物型，感染巨噬细胞，导致免疫介导的多系统疾病，伴有影响肾脏的血管周围化脓性肉芽肿性炎症[2]。此外，猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）感染与可能进展为急性肾损伤的肾小球疾病相关[3][4]。

### 细菌性病因
钩端螺旋体病是犬急性间质性肾炎最重要的细菌性病因[5][6]。这种螺旋体感染已成为北美AKI的常见原因，其中流感伤寒型、布拉迪斯拉发型、波蒙纳型和秋季型血清型最常涉及[8]。该病原体穿透粘膜，通过血流传播，并定位于肾小管[8]。由革兰氏阴性细菌（如大肠杆菌）引起的上行性尿路感染导致的细菌性肾盂肾炎也可导致AKI[5]。

### 其他传染性病原体
其他几种病原体可通过免疫复合物机制引发AKI。这些包括猫胞浆虫和利什曼原虫，它们通过抗体-抗原复合物沉积引起继发性肾脏损伤[1]。猫血支原体可能导致溶血性贫血和随后的肾损伤[1]。

### Sources
[1] Immune-mediated hemolytic anemia: Understanding and diagnosing complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-understanding-and-diagnosing-complex-disease
[2] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[3] Protein losing nephropathy (Proceedings): https://www.dvm360.com/view/protein-losing-nephropathy-proceedings
[4] Noninfectious Diseases of the Urinary System of Cats: https://www.merckvetmanual.com/cat-owners/kidney-and-urinary-tract-disorders-of-cats/noninfectious-diseases-of-the-urinary-system-of-cats
[5] Overview of Infectious Diseases of the Urinary System in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/overview-of-infectious-diseases-of-the-urinary-system-in-small-animals
[6] Leptospirosis in Dogs - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/leptospirosis/leptospirosis-in-dogs
[7] Acute renal failure: leptospirosis is more common than you think (Proceedings): https://www.dvm360.com/view/acute-renal-failure-leptospirosis-more-common-you-think-proceedings
[8] The diagnostic challenge of leptospirosis: https://www.dvm360.com/view/the-diagnostic-challenge-of-leptospirosis

## 临床症状和体征

犬和猫的急性肾损伤表现出特征性临床症状，反映肾功能迅速恶化[1]。最常见的观察到的体征包括厌食症，在高达91%的患病猫中出现，约75%的病例伴有嗜睡[1]。

胃肠道表现很常见，38%的AKI猫出现呕吐[1]。在急性肾功能衰竭动物中，由于尿毒症诱导的高胃泌素血症，呕吐可能是一个严重问题[7]。脱水是另一个显著发现，因为动物失去了通过尿液浓缩保存体液的能力[1]。

排尿模式的变化是重要的诊断指标。根据肾脏损伤的阶段和严重程度，动物可能表现为多尿、少尿或无尿[1,7,9]。约半数AKI犬猫为少尿或无尿[9]。多尿可能出现在恢复期，由于肾小管功能部分恢复和渗透性利尿[7]。相反，少尿或无尿可能出现在AKI的维持期[7]。

其他临床症状包括尿量异常、口腔溃疡，偶尔出现肾脏或腹痛[1]。有些动物可能表现为尿失禁、血尿或其他下尿路疾病体征[1]。发热较少见，仅发生在约22%的猫科AKI病例中[1]。

物种特异性模式显示，AKI猫主要是老年雌性，通常伴有潜在的慢性肾病[1]。猫的临床表现往往不如犬明显，早期体征更微妙，可能延误对该疾病的识别[1]。

### Sources

[1] Acute pyelonephritis in cats is frequently caused by Escherichia coli resistant to potentiated penicillins but has a better prognosis than other causes of acute kidney injury: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml

[2] Acute Kidney Injury in Dogs and Cats: https://www.dvm360.com/view/acute-kidney-injury-in-dogs-and-cats

[3] Differentiating between acute and chronic kidney disease: https://www.dvm360.com/view/differentiating-between-acute-and-chronic-kidney-disease

## 诊断方法

急性肾损伤的临床表现评估始于详细的病史采集和体格检查。仔细评估潜在的肾毒性暴露、药物和潜在疾病至关重要[1]。体格检查结果可能包括脱水、精神状态改变或与潜在病因相关的体征。

实验室评估构成AKI诊断的基石。血清化学分析侧重于肌酐和血尿素氮浓度。国际肾脏兴趣协会（IRIS）AKI分级系统基于血清肌酐升高提供标准化分期：I级（≥0.3 mg/dL升高或1.5-1.9倍基线值）、II级（2-2.9倍基线值），更高等级用于更严重的升高[2]。对称二甲基精氨酸（SDMA）在肌酐升高之前检测早期肾功能异常提供了更高的敏感性[1]。全血细胞计数可能揭示相关并发症，而尿液分析评估浓缩能力、蛋白尿和表明活动性肾小管损伤的细胞管型[1]。

影像学技术提供重要的结构信息。X线摄影评估肾脏大小和形状，而超声检查评估结构、回声性，并识别肾积水或肾周液体等并发症[4]。正常或增大的肾脏提示急性疾病，与慢性疾病的典型小而不规则肾脏形成对比[4]。增强的皮髓质分界和肾周液体积聚可能表明急性损伤[4]。

### Sources
[1] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[2] Prevalence of acute kidney injury and outcome in cats treated as inpatients versus outpatients following lily exposure: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml
[3] Acute Kidney Injury in Dogs and Cats: https://www.dvm360.com/view/acute-kidney-injury-in-dogs-and-cats
[4] Differentiating between acute and chronic kidney disease: https://www.dvm360.com/view/differentiating-between-acute-and-chronic-kidney-disease

## 治疗方案

急性肾损伤治疗需要针对每位患者特定需求量身定制的全面支持性护理。液体疗法仍然是治疗的基石，最初推荐等渗替代溶液如乳酸林格氏液[2]。目标是在4-6小时内快速恢复水合状态以优化肾脏灌注，随后仔细监测液体以防止超负荷[7]。

电解质管理至关重要，特别是对少尿患者的高钾血症。严重高钾血症需要立即干预，使用特定疗法降低血清钾水平[7]。当血液pH值低于7.2或血清碳酸氢盐降至14 mEq/L以下时，应治疗代谢性酸中毒[7]。

止吐疗法使用药物如甲氧氯普胺（0.2-0.5 mg/kg q8h IV）、昂丹司琼（0.1-0.2 mg/kg q8h SQ）或多拉司琼（0.6 mg/kg q24h）处理尿毒症相关呕吐[7]。由于尿毒症诱导的高胃泌素血症，应使用法莫替丁或奥美拉唑控制胃酸产生[7]。

营养支持至关重要，商业肾病饮食分别提供犬和猫12-15%和20-27%的蛋白质热量（可代谢能，ME）[5]。对于无法自主进食的患者，可能需要通过食管造口管进行肠内喂养或肠外营养[8][9]。

对于少尿或无尿患者，在确保充分水合后可尝试利尿疗法。呋塞米可作为递增剂量或以0.66-1.0 mg/kg/hr的持续速率输注[7]。如果利尿剂失败，包括血液透析在内的肾脏替代治疗变得必要，早期干预与更好的预后相关[3]。

### Sources

[1] Prevalence of acute kidney injury and outcome in cats treated: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml
[2] 2024 AAHA Fluid Therapy Guidelines for Dogs and Cats: https://meridian.allenpress.com/jaaha/article/60/4/131/501375/2024-AAHA-Fluid-Therapy-Guidelines-for-Dogs-and
[3] Acute Kidney Injury in Dogs and Cats - dvm360: https://www.dvm360.com/view/acute-kidney-injury-in-dogs-and-cats
[4] Your guide to managing acute renal failure: https://www.dvm360.com/view/your-guide-managing-acute-renal-failure
[5] Feeding pets with renal disease (Proceedings): https://www.dvm360.com/view/feeding-pets-with-renal-disease-proceedings
[6] Technician care for acute kidney injury: https://www.dvm360.com/view/technician-care-for-acute-kidney-injury
[7] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[8] The nutritional assessment (Proceedings): https://www.dvm360.com/view/nutritional-assessment-proceedings
[9] Practical parenteral nutrition--when the gut doesn't work: https://www.dvm360.com/view/practical-parenteral-nutrition-when-gut-doesnt-work-proceedings

## 预防措施

急性肾损伤的预防侧重于识别和减轻风险因素，维持最佳患者水合状态，并为高风险动物实施适当的监测方案[1]。

**毒素暴露预防**代表关键的预防措施。应教育宠物主人了解常见的肾毒素，包括百合（对猫特别危险）、葡萄/葡萄干、NSAIDs、乙二醇和含维生素D产品[2][3][4]。如果发生百合暴露，需要立即进行48小时静脉液体治疗，在18小时内启动治疗最有效[1]。葡萄/葡萄干毒性可能由低至一颗葡萄的剂量引起，强调完全避免的重要性[4]。

**既往疾病管理**涉及在给予潜在肾毒性药物前仔细评估。脱水和容量不足是AKI发展的最重要风险因素[6]。既往肾病、高龄和血容量不足通过改变药物药代动力学和损害肾脏维持充足血流的能力显著增加肾毒性风险[7]。

**高风险患者的监测方案**包括在麻醉和手术期间维持最佳水合状态，避免在脱水或受损患者中使用NSAIDs，以及实施仔细的液体疗法管理[9]。早期检测标志物如尿酶（GGT、NAG）可在氮质血症发展前识别肾小管损伤，允许及时干预[6]。

环境控制应侧重于限制接触有毒物质和确保充足的水供应。风险因素是叠加的，使全面的预防策略对保护易感患者至关重要[6]。

### Sources
[1] Prevalence of acute kidney injury and outcome in cats treated as inpatients versus outpatients following lily exposure: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml
[2] Renal Dysfunction in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[3] Acute Kidney Injury in Dogs and Cats: https://www.dvm360.com/view/acute-kidney-injury-in-dogs-and-cats
[4] A practical review of common veterinary renal toxins: https://www.dvm360.com/view/practical-review-common-veterinary-renal-toxins
[5] 11 guidelines for conservatively treating chronic kidney disease: https://www.dvm360.com/view/11-guidelines-conservatively-treating-chronic-kidney-disease
[6] Risk factors and patient monitoring to avoid acute kidney injury: https://www.dvm360.com/view/risk-factors-and-patient-monitoring-avoid-acute-kidney-injury-proceedings
[7] Are NSAIDS safe in dogs with liver and kidney disease?: https://www.dvm360.com/view/are-nsaids-safe-dogs-with-liver-and-kidney-disease-proceeding
[8] Updates in outpatient management of chronic kidney disease: https://www.dvm360.com/view/updates-outpatient-management-chronic-kidney-disease-proceedings
[9] NSAIDs, anesthesia, and the kidneys: https://www.dvm360.com/view/nsaids-anesthesia-and-kidneys-what-they-are-not-telling-you-proceedings
[10] Fluid treatment for renal failure: https://www.dvm360.com/view/fluid-treatment-renal-failure-proceedings-0

## 鉴别诊断

AKI必须通过仔细评估临床病史、体格检查结果和实验室参数与慢性肾病（CKD）、肾前性氮质血症和肾后性氮质血症进行鉴别[1,2]。

**肾前性与肾性氮质血症：** 肾前性氮质血症由肾脏灌注减少（脱水、休克）引起，表现为浓缩尿（犬比重>1.030，猫>1.035）[1,3]。如果BUN升高但尿液浓缩能力充足，肾前性原因最可能[1]。相反，AKI通常表现为等渗尿（1.007-1.015），尽管存在氮质血症[3]。

**肾后性氮质血症：** 由尿路梗阻或破裂引起[3]。导尿困难、排尿困难和里急后重是常见体征[3]。腹水中肌酐浓度高于血清提示膀胱或尿道破裂[3]。

**AKI与CKD：** 关键鉴别因素包括患者病史和体格检查结果[4,5]。AKI患者通常表现为既往健康状态、良好的身体状况、正常至增大的肾脏以及含有细胞管型的活动性尿沉渣[4,5]。CKD患者显示体重减轻、多尿/烦渴病史、身体状况差、小而不规则肾脏和非再生性贫血[4]。AKI通常表现出相对于氮质血症程度更严重的临床症状，而CKD患者尽管存在显著氮质血症可能仅有轻微体征[5]。

### Sources

[1] Introduction to laboratory profiling and laboratory profiling of the urinary system: https://www.dvm360.com/view/introduction-laboratory-profiling-and-laboratory-profiling-urinary-system-case-oriented-approach-pro

[2] Renal Dysfunction in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats

[3] The nuts and bolts of azotemia: https://www.dvm360.com/view/nuts-and-bolts-azotemia-proceedings

[4] Laboratory evaluation of kidney disease: https://www.dvm360.com/view/laboratory-evaluation-kidney-disease

[5] Diagnosing, managing, and preventing acute renal failure: https://www.dvm360.com/view/diagnosing-managing-and-preventing-acute-renal-failure-proceedings
