# 伴侣动物低钙血症

低钙血症是犬猫中一种严重的代谢性疾病，其特征是血清钙浓度危险性地降低，可迅速发展为危及生命的神经肌肉并发症。此病症影响所有生命阶段的两个物种，从败血症幼犬到经历子痫的产后雌性动物。该疾病的临床意义在于钙在神经功能、肌肉收缩和细胞代谢中的重要作用。本报告探讨了低钙血症的多面性，涵盖感染性和代谢性原因、从细微行为变化到严重强直和癫痫的特征性临床表现、包括离子钙测量和PTH检测在内的综合诊断方法、紧急和长期治疗方案、高危患者的预防策略、鉴别诊断考量以及影响兽医实践中患者预后的因素。

## 疾病概述

**定义**

低钙血症是犬猫血清钙浓度异常降低的一种代谢性疾病[2]。该病症特指离子钙（生理活性形式，对正常细胞功能至关重要）的减少[2]。犬离子钙浓度低于1.1 mmol/L，猫低于1 mmol/L即可诊断为低钙血症[3]。

**流行病学背景**

低钙血症影响犬和猫，但其患病率因根本原因而异。在危重幼犬中，约18%的病例出现低钙血症[1]。原发性甲状旁腺功能减退症是最严重的类型，最常见于中年绝育雌性犬，就诊时平均年龄为4.8岁[3]。60%至65%的患病犬为雌性[3]。玩具贵宾犬、拉布拉多寻回犬、迷你雪纳瑞犬、德国牧羊犬和梗犬品种表现出品种易感性[3]。

在猫中，原发性甲状旁腺功能减退症罕见，首例病例报道于1990年[3]。患病猫平均年龄略超过2岁，可能存在雄性偏好，但尚未确立品种易感性[3]。术后低钙血症最常见于猫双侧甲状腺切除术后[2]。

**钙的生理作用**

钙在伴侣动物中发挥关键作用，包括稳定神经细胞膜对钠的通透性、实现正常的骨骼、心脏和平滑肌收缩、作为细胞内第二信使、调节线粒体代谢以及在凝血级联反应中作为辅助因子[3]。

### Sources

[1] Calcium and magnesium abnormalities in puppies with: https://avmajournals.avma.org/view/journals/ajvr/86/1/ajvr.24.07.0187.xml

[2] Parathyroid diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/parathyroid-diseases-dogs-and-cats-proceedings

[3] Primary hypoparathyroidism in dogs and cats: Physiology: https://www.dvm360.com/view/primary-hypoparathyroidism-dogs-and-cats-physiology-clinical-signs-and-initial-diagnostic-tests

## 常见病原体

虽然低钙血症主要是一种代谢性疾病，但传染病可通过几种机制促使其发展。败血症，特别是细菌感染引起的败血症，是犬猫低钙血症最重要的感染性原因[1]。

细菌性败血症通常导致败血症猫犬的离子钙浓度降低。革兰氏阴性菌如大肠杆菌、克雷伯氏菌属和链球菌属常从败血症动物中分离出来[1][2]。在猫中，败血症最常起源于脓胸（24%）、败血症性腹膜炎（14%）和肾盂肾炎（7%）[1]。发病机制涉及甲状旁腺抑制、维生素D浓度不足以及甲状旁腺激素-维生素D抵抗[1]。

病毒感染也可能促发低钙血症。猫病毒性疾病包括猫白血病病毒（FeLV）、猫免疫缺陷病毒（FIV）和猫冠状病毒感染与可导致低钙血症的败血症相关[3]。此外，猫胰腺炎可能与多种病毒因子相关，包括弓形虫、猫疱疹病毒I型、猫传染性腹膜炎病毒和杯状病毒，而胰腺炎本身通过胰周脂肪皂化作用引起低钙血症[4]。

其他传染性病原体包括毛状芽孢杆菌（泰泽病），可导致免疫抑制动物致命的肠肝综合征[2]。新生儿的严重钩虫和蛔虫感染可导致包括低钙血症在内的代谢紊乱[3]。虽然不常见，但医源性原因如磷酸盐灌肠中毒也可通过高磷血症导致低钙血症[5]。

### Sources
[1] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[2] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/infectious-diseases-of-the-liver-in-small-animals
[3] Causes of fading puppy and kitten syndrome: https://www.dvm360.com/view/causes-fading-puppy-and-kitten-syndrome
[4] Feline exocrine pancreatic disease: A diagnostic and therapeutic challenge: https://www.dvm360.com/view/feline-exocrine-pancreatic-disease-diagnostic-and-therapeutic-challenge-proceedings
[5] Hypertonic phosphate enema intoxication in dogs and cats: https://www.dvm360.com/view/hypertonic-phosphate-enema-intoxication-dogs-and-cats

## 临床症状和体征

犬猫低钙血症表现出特征性的神经肌肉和行为表现，反映了潜在的钙缺乏。临床症状从无到严重不等，取决于低钙血症的程度、发生速度和持续时间[1]。

**典型神经肌肉体征**

最一致的临床体征包括非特异性厌食、面部摩擦、低吼、紧张以及影响耳朵和面部的局灶性肌肉抽搐[1]。随着低钙血症进展，犬会出现步态僵硬、全身肌肉颤搐，并可能表现出行为变化，包括不愿被触摸和攻击性行为[1][2]。强直和癫痫代表严重表现，癫痫发作前常先出现一个肢体的肌肉震颤，逐渐扩散至全身[2]。

**行为和继发性体征**

面部摩擦可能很剧烈，并可能导致自残，这很可能代表感觉异常，类似于人类低钙血症报告的刺痛感[2]。运动和兴奋可能诱发或加重临床症状，因为呼吸性碱中毒会减少离子钙比例[1][2]。犬还可能出现发热、腹部紧张或板样腹以及心血管体征，包括心动过速和脉搏微弱[1]。

**产褥期强直/子痫表现**

多胎小型品种母犬常在分娩后2-3周发生产后低钙血症（子痫）[3]。早期体征包括气喘、不安、轻微震颤以及步态僵硬和共济失调的变化[3]。行为变化如攻击性、呜咽、流涎、踱步和定向障碍很常见[3]。严重病例进展为强直、全身性癫痫发作，并可能伴有高热性昏迷[3]。

**物种特异性模式**

与犬相比，低钙血症猫更常表现为厌食和嗜睡，但也有呕吐报道[2]。可观察到猫的第三眼睑突出和耳部抽搐[2]。与犬不同，猫中尚未记录到兴奋诱发的癫痫发作[2]。

### Sources

[1] Merck Veterinary Manual Hypocalcemia in Small Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/hypocalcemia-in-small-animals

[2] Primary hypoparathyroidism in dogs and cats: https://www.dvm360.com/view/primary-hypoparathyroidism-dogs-and-cats-physiology-clinical-signs-and-initial-diagnostic-tests

[3] Eclampsia in Small Animals - Metabolic Disorders: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/eclampsia-in-small-animals

## 诊断方法

准确诊断低钙血症需要系统的临床评估结合特定的实验室检测。临床表现评估是初始诊断步骤，重点关注特征性神经肌肉体征，包括肌肉震颤、强直、面部摩擦和癫痫发作[3]。体格检查应包括对潜在潜在原因的仔细评估。

实验室检测构成低钙血症诊断的基石。总钙和离子钙测量都是必需的，犬离子钙低于1.1 mmol/L，猫低于1.0 mmol/L即可诊断为低钙血症[3]。离子钙是首选测量指标，因为它反映了生物学活性部分[2]。同时进行的血清磷评估通常显示甲状旁腺功能减退患者存在高磷血症[7]。

原发性甲状旁腺功能减退症的明确诊断需要同时测量血清甲状旁腺激素（PTH）和离子钙浓度[4]。关键的诊断发现是在低钙血症存在下PTH水平不恰当地低或无法检测到[4]。适当的样本处理至关重要，血清需立即分离、冷冻并在适当温度控制下运输[2]。

特殊检测包括镁评估，因为低镁血症可导致功能性甲状旁腺功能减退症[4]。维生素D代谢物检测可提供额外的诊断信息。心电图可揭示特征性变化，包括S-T段和Q-T段延长以及深而宽的T波[7]。

### Sources

[1] Hypercalcemia in dogs and cats (Proceedings): https://www.dvm360.com/view/hypercalcemia-dogs-and-cats-proceedings
[2] Hypercalcemia in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-parathyroid-glands-and-disorders-of-calcium-regulation-in-dogs-and-cats/hypercalcemia-in-dogs-and-cats
[3] Primary hypoparathyroidism in dogs and cats: Physiology, clinical signs, and initial diagnostic tests: https://www.dvm360.com/view/primary-hypoparathyroidism-dogs-and-cats-physiology-clinical-signs-and-initial-diagnostic-tests
[4] Diagnosing and treating primary hypoparathyroidism in dogs and cats: https://www.dvm360.com/view/diagnosing-and-treating-primary-hypoparathyroidism-dogs-and-cats
[5] Managing calcium disorders (Proceedings): https://www.dvm360.com/view/managing-calcium-disorders-proceedings
[6] Diagnostic procedures (Proceedings): https://www.dvm360.com/view/diagnostic-procedures-proceedings
[7] Parathyroid diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/parathyroid-diseases-dogs-and-cats-proceedings
[8] Hypocalcemia in Small Animals - Metabolic Disorders: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/hypocalcemia-in-small-animals
[9] Potassium, phosphorus, and calcium treatment of severe abnormalities (Proceedings): https://www.dvm360.com/view/potassium-phosphorus-and-calcium-treatment-severe-abnormalities-proceedings

## 治疗方案

紧急治疗开始于静脉注射葡萄糖酸钙，剂量为10%溶液1 ml/kg缓慢静脉注射，并持续进行心脏监护以检测心律失常[1]。这可提供立即但暂时的钙升高，持续1-12小时。

过渡治疗涉及通过重复静脉推注、皮下葡萄糖酸钙（用生理盐水1:1稀释，每6-8小时一次）或以2.5-10 mg/kg/hr的恒定速率输注将钙水平维持在8-9 mg/dl之间[2]。皮下注射是首选，因为它比重复推注侵入性更小，并提供更稳定的钙水平。

长期管理需要终身维生素D类似物治疗。骨化三醇是首选（初始20-40 ng/kg/天，然后维持5-20 ng/kg/天），因其起效快、半衰期短，允许精确的剂量调整[1][2]。或者，可使用双氢速甾醇（初始0.03 mg/kg/天）或麦角钙化醇（4,000-6,000 U/kg/天），但它们的半衰期较长，反应较难预测。

同时进行口服钙补充剂在初期是必需的，通常使用碳酸钙提供每日25-50 mg/kg元素钙，分3-4次给药[2]。一旦维生素D治疗稳定血清钙，可在2-4个月内逐渐减少剂量。

定期监测包括初期每周测量血清钙，稳定后每3-4个月一次[2]。必须教育主人识别低钙血症（强直、癫痫发作）和高钙血症（烦渴、呕吐、抑郁）的体征，并在出现高钙血症体征时停止治疗。

### Sources
[1] Managing calcium disorders (Proceedings): https://www.dvm360.com/view/managing-calcium-disorders-proceedings
[2] Diagnosing and treating primary hypoparathyroidism in dogs and cats: https://www.dvm360.com/view/diagnosing-and-treating-primary-hypoparathyroidism-dogs-and-cats

## 预防措施

低钙血症的预防主要集中在高危患者的饮食管理和监测方案。怀孕和哺乳期雌性应在怀孕和哺乳期间接受高质量、营养均衡的饮食[1]。在整个哺乳期应自由提供食物和水[1]。

早期补充喂养后代对预防至关重要。幼犬应在哺乳早期接受代乳品补充，并在3-4周龄后过渡到固体食物[1]。同样，幼猫应在哺乳早期提供代乳品补充，并在3-4周龄后提供固体食物[2]。

重要的是，怀孕期间口服钙补充是禁忌的，并可能诱发产褥期低钙血症[4]。这是因为钙补充导致血清钙持续升高，随后下调甲状旁腺激素。当哺乳开始时，下调的甲状旁腺系统无法有效利用骨骼钙储备[4]。

然而，在有子痫病史的动物中，在哺乳高峰期给予钙可能有帮助[5]。口服钙补充应贯穿整个哺乳期，以避免急性低钙性强直发作[5]。

对于高危患者，建议在哺乳期间每周监测血清钙水平[1]。环境考虑包括确保充足的空间和减少可能在关键围产期损害钙代谢的压力因素。

### Sources

[1] Disorders of Calcium Metabolism in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/metabolic-disorders-of-dogs/disorders-of-calcium-metabolism-in-dogs
[2] Disorders of Calcium Metabolism in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/metabolic-disorders-of-cats/disorders-of-calcium-metabolism-in-cats
[3] Practical Matters: Do not institute calcium supplementation during canine pregnancy: https://www.dvm360.com/view/practical-matters-do-not-institute-calcium-supplementation-during-canine-pregnancy
[4] Eclampsia in Small Animals - Metabolic Disorders: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/eclampsia-in-small-animals

## 鉴别诊断

犬猫低钙血症需要与多种临床表现重叠的疾病进行系统鉴别。原发性原因包括甲状旁腺功能减退症（免疫介导性或甲状腺切除术后医源性）、慢性和急性肾功能衰竭、急性胰腺炎、产褥期强直（子痫）和低白蛋白血症[1,2,3]。

中毒代表重要的鉴别诊断，特别是乙二醇中毒和输血引起的柠檬酸盐毒性[1,2]。乙二醇代谢产生草酸，与钙结合，通过形成草酸钙晶体导致严重低钙血症[6,7]。甲状腺切除术后低钙血症发生在约10%的猫甲状腺切除病例中[1,6]。胃肠道吸收不良、营养性继发性甲状旁腺功能亢进症和肾上腺皮质功能亢进症也需考虑[3]。

实验室评估有助于鉴别。甲状旁腺功能减退症表现为PTH水平低和磷升高，而肾脏疾病通常显示氮质血症[3,7,10]。胰腺炎可能同时伴有脂肪酶升高，子痫发生在哺乳期雌性中[1,2]。原发性甲状旁腺功能减退症最常见于甲状腺或甲状旁腺手术期间的医源性损伤，特别是在猫中[4]。自发性甲状旁腺功能减退症可能由免疫介导的淋巴细胞性甲状旁腺炎或萎缩引起[2,4]。离子钙测量至关重要，因为低白蛋白血症可降低总钙，而离子钙保持正常[5,6]。临床背景、伴随的实验室检查结果和PTH测量有助于区分这些疾病并指导适当的治疗干预[3,10]。

### Sources

[1] Monitoring critical small-animal patients (Proceedings): https://www.dvm360.com/view/monitoring-critical-small-animal-patients-proceedings
[2] Hypoparathyroidism in Dogs - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/dystrophies-associated-with-calcium-phosphorus-and-vitamin-d/hypoparathyroidism-in-dogs
[3] Diagnosing and treating primary hypoparathyroidism in dogs and cats: https://www.dvm360.com/view/diagnosing-and-treating-primary-hypoparathyroidism-dogs-and-cats
[4] Diseases of the parathyroid glands (Proceedings): https://www.dvm360.com/view/diseases-parathyroid-glands-proceedings
[5] Hypercalcemia in dogs and cats (Proceedings): https://www.dvm360.com/view/hypercalcemia-dogs-and-cats-proceedings
[6] Ethylene Glycol Toxicosis in Animals - Toxicology: https://www.merckvetmanual.com/toxicology/ethylene-glycol-toxicosis/ethylene-glycol-toxicosis-in-animals
[7] Acute uremia (Proceedings): https://www.dvm360.com/view/acute-uremia-proceedings
[8] Advanced interpretation of the urine sediment (Proceedings): https://www.dvm360.com/view/advanced-interpretation-urine-sediment-proceedings
[9] Common hazards for cats (Proceedings): https://www.dvm360.com/view/common-hazards-cats-proceedings
[10] Diagnosing, managing, and preventing acute renal failure (Proceedings): https://www.dvm360.com/view/diagnosing-managing-and-preventing-acute-renal-failure-proceedings

## 预后

犬猫低钙血症的预后因根本原因和临床表现严重程度而异显著。早期识别和及时治疗通常在大多数病因中导致良好结局[1][2][3]。

对于子痫（哺乳期雌性最常见原因），立即给予葡萄糖酸钙治疗预后极佳。大多数患者在静脉治疗后15分钟内显示临床改善，肌肉立即放松[3]。然而，若无预防措施，未来妊娠中可能复发。

原发性甲状旁腺功能减退症在终身管理下预后谨慎至良好[4]。成功取决于主人对钙和维生素D补充的依从性，以及定期监测以防止医源性高钙血症并发症。预后良好，但在初始稳定期间治疗可能很密集，并且监测可能需要在犬的整个生命期间频繁进行[4]。

对于继发于慢性肾脏疾病的低钙血症，预后主要取决于潜在的肾脏状况，而不是钙失衡本身。血清钙-磷乘积较高的犬可能生存率相对较低[2]。

在引起低钙血症的先天性条件幼犬中，钙可能在整体结局中起作用，较低的离子钙浓度可能与较差的预后相关[1]。影响恢复的关键因素包括及时诊断、适当的紧急治疗以及在可能的情况下解决根本原因。

### Sources

[1] Calcium and magnesium abnormalities in puppies with ...: https://avmajournals.avma.org/view/journals/ajvr/86/1/ajvr.24.07.0187.pdf
[2] Prognostic role of the product of serum calcium and ...: https://avmajournals.avma.org/view/journals/javma/245/10/javma.245.10.1135.xml
[3] Eclampsia in Small Animals - Metabolic Disorders: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/eclampsia-in-small-animals
[4] Parathyroid diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/parathyroid-diseases-dogs-and-cats-proceedings
