# 伴侣动物肾上腺皮质功能亢进症

肾上腺皮质功能亢进症，通常称为库欣综合征，是兽医医学中最具意义的内分泌疾病之一，每年影响成千上万的犬和猫。这种复杂的病症由皮质醇过量产生引起，导致衰弱的多系统效应，显著影响生活质量。该疾病主要影响中老年动物，某些品种表现出明显的易感性。本综合报告探讨了皮质醇过量背后的病理生理学，分析了犬猫患者之间独特的临床表现，详细介绍了包括特殊内分泌检测在内的当前诊断方案，并评估了从曲洛斯坦药物治疗到手术干预的治疗策略。此外，它还讨论了可能模拟肾上腺皮质功能亢进症的关键鉴别诊断，并提供了临床决策必需的循证预后信息。

## 摘要

肾上腺皮质功能亢进症是一种需要复杂诊断和治疗方法的复杂内分泌疾病。该疾病的病理生理学集中在影响多个器官系统的皮质醇过量产生上，其中垂体依赖性疾病占病例的80-85%，肾上腺依赖性形式占10-15%。临床表现在不同物种间差异显著，犬表现出典型的"库欣样"症状，而猫则经常并发糖尿病和脆弱皮肤综合征。

诊断成功依赖于将临床评估与特定内分泌检测相结合，特别是低剂量地塞米松抑制试验作为金标准筛查方法。治疗策略已显著发展，曲洛斯坦现已成为一线药物治疗，尽管包括肾上腺切除术和垂体切除术在内的手术选择为合适的患者提供了治愈潜力。

| 治疗方法 | 中位生存期 | 成功率 | 关键考虑因素 |
|-------------------|----------------|--------------|-------------------|
| 曲洛斯坦治疗 | 662-930天 | 85-90%反应率 | 需要定期监测 |
| 肾上腺切除术 | 约18个月 | 不定 | 围手术期死亡率14-60% |
| 垂体切除术 | 1年生存率86% | 80%缓解率 | 仅限专业中心 |

早期识别和适当治疗显著改善结果，预后很大程度上取决于及时诊断和正确的治疗监测方案。

## 疾病概述与流行病学

肾上腺皮质功能亢进症，通常称为库欣综合征，是指以体内糖皮质激素浓度过高为特征的临床疾病[1]。这种内分泌疾病分为两种主要类型：垂体依赖性肾上腺皮质功能亢进症（PDH），也称库欣病，以及肾上腺依赖性肾上腺皮质功能亢进症（ADH）[2]。

PDH由分泌ACTH的垂体肿瘤引起双侧肾上腺增生所致，约占自然发生病例的80-85%[1]。ADH源于肾上腺皮质肿瘤的自主皮质醇分泌，占病例的10-15%[2]。第三种形式，医源性肾上腺皮质功能亢进症，由长期外源性糖皮质激素给药引起[1]。

该疾病主要影响中老年犬（7-12岁），一些研究报告显示雌性易感（55-75%）[1][3]。易感品种包括贵宾犬（特别是迷你贵宾）、腊肠犬、拳师犬、波士顿梗犬和约克夏梗犬[1]。虽然PDH通常发生在小型犬中，但ADH更频繁影响中大型犬[1]。

在猫中，肾上腺皮质功能亢进症相当罕见，但遵循相似模式，影响中老年猫，其中约60-75%为雌性[1][5]。大多数猫病例（80%）是垂体依赖性的[5]。

### Sources
[1] Cushing Disease (Pituitary-Dependent Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-pituitary-gland/cushing-disease-pituitary-dependent-hyperadrenocorticism-in-animals
[2] Cushing Syndrome (Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/en-au/endocrine-system/the-adrenal-glands/cushing-syndrome-hyperadrenocorticism
[3] Hyperadrenocorticism (Proceedings): https://www.dvm360.com/view/hyperadrenocorticism-proceedings
[4] Laboratory diagnosis and treatment of hyperadrenocorticism in dogs (Proceedings): https://www.dvm360.com/view/laboratory-diagnosis-and-treatment-hyperadrenocorticism-dogs-proceedings-0
[5] The feline facets of Cushing's disease: https://www.dvm360.com/view/feline-facets-cushings-disease

## 病理生理学与临床表现

肾上腺皮质功能亢进症由肾上腺皮质醇过量产生引起，由于皮质醇对多个身体系统的作用导致广泛的全身效应[1]。病理生理学涉及糖皮质激素过量影响肾脏（多尿、低渗尿和代偿性烦渴）、肝脏（糖异生、糖原分解和肝脂肪变性）、胰腺（胰岛素拮抗）、骨骼肌（蛋白质分解导致肌肉无力）和免疫系统（炎症反应减弱）[2]。

在犬中，最常见的临床表现包括多尿/烦渴、多食、悬垂腹、气喘、肌肉萎缩和皮肤变化包括脱毛、脓皮症和皮肤变薄[1]。许多患病犬发展为全身性高血压[3]。典型的"库欣样"大腹外观伴有肝肿大、体重增加和全身肌肉萎缩是特征性的[4]。

猫肾上腺皮质功能亢进症表现不同，80%的猫由于皮质醇诱导的胰岛素抵抗而并发糖尿病[4]。一个独特特征是严重皮肤变薄易撕裂，称为猫脆弱皮肤综合征[1]。猫的临床症状包括多尿、烦渴、多食、肌肉萎缩、嗜睡和毛发凌乱[4]。

实验室异常反映皮质醇的全身效应，包括碱性磷酸酶活性升高（犬中最常见）、轻度高血糖、应激白细胞象、血小板增多、低尿比重和蛋白尿[1]。

### Sources

[1] Cushing Syndrome (Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/cushing-syndrome-hyperadrenocorticism-in-animals

[2] Canine and feline adrenal gland diseases (Proceedings): https://www.dvm360.com/view/canine-and-feline-adrenal-gland-diseases-proceedings

[3] Understanding Cushing syndrome and cortisol - DVM360: https://www.dvm360.com/view/understanding-cushing-syndrome-and-cortisol-from-lab-work-to-rechecks

[4] Unusual feline endocrinopathies (Proceedings): https://www.dvm360.com/view/unusual-feline-endocrinopathies-proceedings

## 诊断方法与技术

肾上腺皮质功能亢进症的诊断需要系统方法，结合临床表现评估、实验室评估和特定内分泌检测[1]。**低剂量地塞米松抑制试验（LDDST）是首选的筛查试验**，因为其高灵敏度（85-100%）并且能够既确认肾上腺皮质功能亢进症又区分垂体依赖性（PDH）和肾上腺依赖性肾上腺皮质功能亢进症（ADH）[1]。

**实验室检查结果**通常包括碱性磷酸酶（ALP）活性升高--犬中最常见的异常，由皮质类固醇诱导的酶产生引起--轻度ALT升高、高脂血症、高血糖、应激白细胞象和低尿比重[1]。在猫中，除非存在并发糖尿病，否则常规实验室检查异常不一致[1]。

**ACTH刺激试验**作为替代筛查方法，特别适用于糖尿病患者或疑似医源性肾上腺皮质功能亢进症，尽管其灵敏度（80-85%）低于LDDST[2]。对于鉴别检测，**高剂量地塞米松抑制试验（HDDST）**使用十倍更高剂量的地塞米松来区分PDH和ADH[1]。

**腹部成像**（超声或CT）对诊断工作至关重要，有助于区分双侧对称性肾上腺（PDH）与单侧肾上腺肿瘤（ADH）[1]。**内源性ACTH测量**提供额外鉴别：水平升高提示PDH而水平降低表明ADH[1]。在猫中，由于该疾病不常见且经常合并其他疾病，诊断通常需要结合腹部成像和内分泌功能测试[1]。

### Sources
[1] Merck Veterinary Manual Cushing Syndrome (Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/cushing-syndrome-hyperadrenocorticism-in-animals
[2] Merck Veterinary Manual Cushing Disease (Pituitary-Dependent Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-pituitary-gland/cushing-disease-pituitary-dependent-hyperadrenocorticism-in-animals

## 治疗策略与监测

曲洛斯坦是目前犬肾上腺皮质功能亢进症的一线药物治疗[1]。这种3β-羟基类固醇脱氢酶的竞争性抑制剂阻断皮质醇合成，应以1-3 mg/kg每12小时与食物同服[1]。初始监测需要在10天、1个月和3个月时进行ACTH刺激试验，目标为每日一次给药后ACTH刺激皮质醇浓度达到2-6 µg/dl[1]。

米托坦仍然是一种有效的替代方案，特别适用于非典型肾上腺皮质功能亢进症或恶性肾上腺肿瘤的犬，因为它提供曲洛斯坦所缺乏的细胞毒性效应[1]。诱导方案包括每日25-50 mg/kg持续7-10天直至食欲下降，然后每周50 mg/kg分次给药的维持治疗[2]。约50%的犬在曲洛斯坦治疗的前六个月内需要剂量调整[1]。

手术干预包括功能性肾上腺肿瘤的单侧肾上腺切除术和垂体依赖性疾病的垂体切除术[3]。肾上腺切除术为合适的患者提供治愈潜力，尽管围手术期死亡率在14-60%之间[3]。垂体切除术实现一年86%的生存率和80%的缓解率，并发症包括暂时性尿崩症[3]。

放射治疗有效治疗垂体大腺瘤，特别是对于出现神经系统症状的犬，像赛博刀这样的新方法需要更少的治疗次数[1]。治疗监测方案强调定期ACTH刺激试验，目标是维持皮质醇抑制同时避免医源性肾上腺皮质功能减退[2]。

### Sources
[1] Challenges in treating hyperadrenocorticism in dogs: https://www.dvm360.com/view/challenges-treating-hyperadrenocorticism-dogs-proceedings
[2] Comparing therapies for canine hyperadrenocorticism: https://www.dvm360.com/view/comparing-therapies-canine-hyperadrenocorticism
[3] Treating canine hyperadrenocorticism (Proceedings): https://www.dvm360.com/view/treating-canine-hyperadrenocorticism-proceedings-0

## 鉴别诊断与预后

肾上腺皮质功能亢进症必须与几种具有重叠临床表现的疾病进行鉴别。在猫中，需要高胰岛素剂量的胰岛素抵抗性糖尿病应引起对库欣病的怀疑[1]。肢端肥大症是一个重要的鉴别诊断，特别是在患有糖尿病且尽管接受胰岛素治疗却出现非特征性体重增加的猫中[1]。肾上腺皮质功能减退症（阿狄森氏病）可以模拟其他具有类似嗜睡、虚弱和胃肠道不适症状的疾病，但表现出特征性高钾血症和低钠血症[1]。

额外的鉴别诊断包括甲状腺功能减退症，可引起与肾上腺皮质功能亢进症相似的高胆固醇血症、嗜睡和体重增加[5]。糖尿病表现出重叠症状包括多尿、烦渴和多食，约5%的肾上腺皮质功能亢进症犬并发糖尿病[2]。肝脏疾病和其他影响肝脏的代谢状况也可能产生相似的临床表现[5]。

肾上腺皮质功能亢进症的预后因形式和治疗方法而异。对于垂体依赖性肾上腺皮质功能亢进症（PDH），无论是否接受药物治疗，中位生存时间约为2年[7]。然而，早期疾病且合并症最少的犬在适当治疗下可能存活更长时间。最近研究报告接受曲洛斯坦治疗的犬中位生存时间为662-930天，接受米托坦治疗的犬为708天[8]。肾上腺肿瘤的手术肾上腺切除术的中位生存时间约为18个月，术后一个月内死亡率在14-60%之间[7]。转移性疾病的存在显著影响预后，受影响患者的中位生存时间降至仅61天[9]。

### Sources

[1] Endocrine update: There's more to cats than thyroids and diabetes (Proceedings): https://www.dvm360.com/view/endocrine-update-theres-more-cats-thyroids-and-diabetes-proceedings
[2] Diagnosing canine hyperadrenocorticism (Proceedings): https://www.dvm360.com/view/diagnosing-canine-hyperadrenocorticism-proceedings
[3] Cushing Disease (Pituitary-Dependent Hyperadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-pituitary-gland/cushing-disease-pituitary-dependent-hyperadrenocorticism-in-animals
[4] Hypothyroid-associated neurologic signs in dogs: https://www.dvm360.com/view/hypothyroid-associated-neurologic-signs-dogs
[5] Metabolic Diseases Affecting the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/metabolic-diseases-affecting-the-liver-in-small-animals
