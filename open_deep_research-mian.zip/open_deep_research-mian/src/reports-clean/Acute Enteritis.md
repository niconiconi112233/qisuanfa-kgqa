# 伴侣动物急性肠炎：综合临床综述

急性肠炎是兽医临床实践中影响犬猫的最常见且具有临床意义的胃肠道疾病之一。这种炎症性疾病的特点是突然发生的肠道炎症，持续时间少于三周，由于其病因多样，从细小病毒和猫泛白细胞减少症等病毒病原体到细菌、寄生虫和非传染性原因，构成了特殊的挑战。该疾病对幼年动物和某些品种的影响不成比例，死亡率因致病因子和患者因素而差异显著。本报告为兽医从业者提供必要的临床知识，涵盖小动物临床中实现最佳患者结果所需的病原体识别、诊断方法、循证治疗方案和预防策略。

## 疾病概述与流行病学

**急性肠炎被定义为突然发生的、持续时间少于3周的肠道炎症，其特征是正常肠道黏膜和屏障功能遭到破坏[1]。** 这种情况在伴侣动物中代表一种重要的临床综合征，影响所有年龄段的犬和猫，但具有明显的流行病学模式。

**成年牛、羊、马、犬、猫和其他哺乳动物在暴露于足够大剂量的有毒力致病菌株时可能发生急性肠炎[1]。** 该疾病在集约化养殖和卫生条件差的地区最为普遍。**犬和猫通常是亚临床携带者，但可能出现临床症状[1]。** 伴侣动物的临床病例通常与住院、成年动物的其他感染或衰弱性疾病，或幼犬幼猫接触大量细菌有关。

**幼犬（6周至6个月大）和小型至玩具品种犬在某些类型的急性肠炎中占比过高[2]。** 约克夏梗、迷你品犬、迷你雪纳瑞、迷你贵宾犬和马尔济斯犬对急性出血性腹泻综合征表现出易感性增加。**临床FIP相关肠炎主要见于6个月至5岁的猫，最高发病率发生在6个月至2岁之间[4]。**

风险因素包括断奶压力、过度拥挤、营养不良、并发寄生虫感染、饮食不当以及喂食生肉饮食，后者已与伴侣动物的临床症状和沙门氏菌粪便排出相关[1]。

### Sources

[1] Salmonellosis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/salmonellosis/salmonellosis-in-animals

[2] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs

[3] Disorders of the Stomach and Intestines in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-stomach-and-intestines-in-cats

[4] Feline infectious peritonitis (FIP): more complex than we thought (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-fip-more-complex-we-thought-proceedings

## 常见病原体与病因学

犬猫的急性肠炎由多种传染性和非传染性原因引起。病毒病原体尤为重要，其中猫泛白细胞减少症病毒和犬细小病毒最为严重[1]。这些病毒破坏肠道隐窝上皮，导致绒毛细胞更新失败和黏膜塌陷，与仅影响绒毛尖端细胞的病毒相比，恢复时间更长[1]。

细菌原因包括产肠毒素性大肠杆菌，其产生的肠毒素刺激分泌超过肠道吸收能力[1]。其他重要细菌病原体包括沙门氏菌属、空肠弯曲杆菌和梭菌属[2]。正常存在的微生物如产气荚膜梭菌在应激或免疫抑制期间可能发生过度生长[2]。

寄生虫是肠炎的常见原因，包括等孢子球虫属、贾第鞭毛虫和隐孢子虫等原生动物[2]。重度寄生虫感染可导致肠道损伤、营养吸收减少以及体液电解质流失[3]。

非传染性原因包括饮食不当、异物摄入和炎症性疾病。分泌性腹泻可由肠毒素暴露引起，而渗透性腹泻则由吸收不良或消化不良（如外分泌胰腺功能不全）引起[1]。多种病原体常协同作用，寄生虫、细菌和病毒的并发感染会加剧疾病严重程度[4]。

### Sources
[1] The Digestive System in Animals: https://www.merckvetmanual.com/en/digestive-system/digestive-system-introduction/the-digestive-system-in-animals
[2] Infectious Diseases of the Gastrointestinal Tract in Animals: https://www.merckvetmanual.com/en-au/digestive-system/digestive-system-introduction/infectious-diseases-of-the-gi-tract-in-animals
[3] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs
[4] Therapy and vaccination for a new canine parvovirus: https://www.dvm360.com/view/therapy-and-vaccination-new-canine-parvovirus-proceedings

## 临床症状与体征

犬猫急性肠炎表现出特征性的胃肠道症状，其严重程度和表现在物种间有所不同[1]。体重减轻和慢性或复发性呕吐是极其常见的临床症状，特别是在患有小肠疾病的猫中[1]。

**典型临床表现**

急性肠炎最常见的临床症状是大肠性腹泻，其特征是黏液、血便、里急后重，偶尔排便时疼痛[2]。患者通常表现出排便紧迫感和频率增加，每次排便的粪便量减少[2]。临床症状可能时好时坏，最初表现为间歇性，但通常会随时间进展[2]。

特别是在猫中，临床症状通常是慢性的，有时是周期性或间歇性的，包括呕吐、腹泻、食欲变化和体重减轻[4]。在大多数病例中，体格检查无明显异常[2]，但彻底的直肠检查可能揭示重要发现。

**诊断方法**

临床检查应包括全面的病史采集和腹泻类型特征描述。小肠性腹泻通常表现为大量、低频率的粪便，具有明显的慢性病程并伴有体重减轻，而大肠性腹泻则表现为频繁前往猫砂盆并排出带血、黏液性粪便[8]。

**实验室检测**

常规实验室评估包括全血细胞计数、生化分析和尿液分析[3]。由于吸收不良或蛋白质丢失可能导致低蛋白血症，同时伴有低钙血症、低胆固醇血症以及血清叶酸和钴胺素水平降低[4]。嗜酸性粒细胞增多可能提示嗜酸性粒细胞性肠炎，而小细胞性贫血可反映慢性失血[4]。

**影像学研究**

腹部X光和超声检查对于排除其他问题以及评估肠壁增厚、肠层变化或肠系膜淋巴结肿大至关重要[6]。超声检查可以观察结肠黏膜和局部病变[2]。

**病原体检测**

粪便检查应包括寄生虫漂浮鉴定、通过PCR检测猫胎儿三毛滴虫，以及使用SNAP ELISA检测贾第鞭毛虫[3]。PCR面板可识别常见传染性病原体，包括弯曲杆菌、梭菌、沙门氏菌和隐孢子虫[8]。

### Sources

[1] Diagnosing feline small bowel disease: https://www.dvm360.com/view/diagnosing-feline-small-bowel-disease-do-noninvasive-tests-make-cut
[2] Colitis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[3] Diagnostic approach to diarrhea: https://www.dvm360.com/view/diagnostic-approach-diarrhea-proceedings
[4] Chronic Enteropathies in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals
[6] Managing IBD and diarrhea in adult cats: https://www.dvm360.com/view/managing-ibd-and-diarrhea-adult-cats-proceedings
[8] Feline diarrhea diagnostic clues: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow

## 治疗策略与管理

急性肠炎的成功管理需要积极的支持性护理，重点关注液体疗法、止吐控制和营养支持[1]。及时的静脉输液治疗是治疗的基石，使用平衡电解质溶液来纠正脱水和由呕吐和腹泻引起的持续损失[1][2]。

**液体治疗方案**应解决维持需求（2-3 ml/kg/h）、脱水不足量和持续损失[1]。严重脱水的患者最初可能需要快速静脉推注，剂量高达90 ml/kg/hr[1]。当总蛋白降至3.5 g/dl以下或白蛋白降至1.5-2.0 g/dl以下时，应使用羟乙基淀粉、血浆或全血进行胶体治疗[1][2]。

**止吐治疗**对于患者舒适度和防止进一步体液损失至关重要[1][3]。马罗匹坦（Cerenia）以1 mg/kg皮下注射每24小时一次、甲氧氯普胺作为恒速输注（1-2 mg/kg/24h）或氯丙嗪（0.1 mg/kg静脉注射每4-6小时一次）是有效的选择[1][3]。昂丹司琼可用于难治性病例[1]。

**抗生素治疗**在怀疑细菌移位或败血症时适用，特别是伴有中性粒细胞减少症或严重黏膜损伤时[1][2]。氨苄西林（20-40 mg/kg静脉注射每6-8小时）联合恩诺沙星或庆大霉素的广谱覆盖提供适当的革兰氏阴性菌保护[1][2]。

**营养支持**应尽可能在12-24小时内开始，因为早期肠内营养可改善结果和肠道屏障功能[5][9]。厌食患者可能需要饲管，初期首选流质饮食[9][10]。肠外营养保留用于无法控制呕吐或胃肠道功能丧失的病例[10]。

### Sources
[1] Treatment of severe parvoviral enteritis (Proceedings): https://www.dvm360.com/view/treatment-severe-parvoviral-enteritis-proceedings
[2] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[3] Intensive care management of severe viral and bacterial enteritis (Proceedings): https://www.dvm360.com/view/intensive-care-management-severe-viral-and-bacterial-enteritis-proceedings
[4] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[5] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[6] Treatment of canine sepsis: First identify, eradicate the cause: https://www.dvm360.com/view/treatment-canine-sepsis-first-identify-eradicate-cause
[7] Nutritional support for ill patients: Specialty feeding tubes (Proceedings): https://www.dvm360.com/view/nutritional-support-ill-patients-specialty-feeding-tubes-proceedings
[8] Retrospective evaluation of enteral nutrition supplementation: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.07.0494/javma.24.07.0494.xml
[9] Nutritional support basics for hospitalized patients: https://www.dvm360.com/view/nutritional-support-basics-hospitalized-patients
[10] Specialty feedings tubes for nutritional support in critically ill patients (Proceedings): https://www.dvm360.com/view/specialty-feedings-tubes-nutritional-support

## 预防与控制措施

急性肠炎的有效预防侧重于可预防病毒原因的疫苗接种方案、严格的环境控制和隔离程序。对于犬细小病毒，建议在6-8周、10-12周和14-16周龄时使用减毒活疫苗进行接种，然后进行年度加强免疫[1]。当前疫苗可预防所有流行的CPV毒株，包括CPV-2c。

环境消毒至关重要，因为细小病毒可在环境中持续存在数月甚至数年[1]。有效消毒剂包括稀释漂白剂（1:30稀释）、过一硫酸钾和加速过氧化氢[1]。尽管标签声称，季铵盐产品对细小病毒无效[5]。

一旦怀疑传染性肠炎，必须立即实施严格的隔离方案[1]。人员在处理可疑病例时应使用隔离衣、手套和鞋套[5]。所有表面、设备以及食物/水碗都需要彻底清洁后进行消毒[4]。

对于猫泛白细胞减少症，疫苗接种方案遵循类似指南，从6周龄开始使用减毒活疫苗[3]。在高风险的收容所环境中，建议在收容时立即接种疫苗[3]。

客户教育应强调完成疫苗接种系列、避免接触未接种疫苗的动物，以及为幼年动物的胃肠道症状立即寻求兽医护理[1]。只有完全接种疫苗的动物才应被引入最近发生过细小病毒性肠炎的家庭[1]。

### Sources

[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/en/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

[2] Feline Panleukopenia - Cat Owners: https://www.merckvetmanual.com/en/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-panleukopenia

[3] Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia

[4] Diarrhea in cats and kittens (Proceedings): https://www.dvm360.com/view/diarrhea-cats-and-kittens-proceedings

[5] What every technician should know about parvovirus: https://www.dvm360.com/view/what-every-technician-should-know-about-parvovirus-proceedings

## 鉴别诊断与预后

### 鉴别诊断

急性肠炎需要与几种具有重叠胃肠道症状的疾病进行仔细鉴别。主要病毒鉴别包括犬细小病毒感染，其表现为类似的出血性腹泻，但通常影响较年轻、未接种疫苗的犬，并显示特征性血液浓缩（PCV >60%）[1]。在猫中，必须考虑猫泛白细胞减少症，其存活率仅为20-51%，而其他急性肠炎病例的恢复率较高[2]。

包括沙门氏菌、弯曲杆菌和产气荚膜梭菌肠毒素中毒在内的细菌原因必须进行评估，特别是当多只动物受到影响时[3]。空肠弯曲杆菌和结肠弯曲杆菌通常导致6个月以下的犬猫腹泻，常表现为水样至血性黏液性腹泻[3]。

贾第鞭毛虫等寄生虫感染需要硫酸锌漂浮检测结合抗原检测才能准确诊断，因为单一检测的敏感性仅为70-75%[4]。急性出血性腹泻综合征（AHDS）表现为突然发作的出血性腹泻和明显血液浓缩，但通过适当的液体治疗通常预后良好[1]。

### 预后

患者年龄显著影响结果，6个月以下的动物由于生理储备有限而死亡率较高[2]。早期进行适当的支持性护理可显著提高存活率。对于细小病毒等病毒性肠炎，住院患者通过积极治疗显示85-95%的存活率[1]。然而，伴有低温、严重白细胞减少症或败血症性休克的严重病例，尽管进行强化治疗，预后仍谨慎至不良。

### Sources
[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[2] Feline Panleukopenia: https://www.merckvetmanual.com/infectious-diseases/feline-panleukopenia/feline-panleukopenia
[3] Enteric Campylobacteriosis in Animals: https://www.merckvetmanual.com/digestive-system/enteric-campylobacteriosis/enteric-campylobacteriosis-in-animals
[4] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich
