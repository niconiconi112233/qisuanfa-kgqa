# 犬猫心包积液

心包积液是伴侣动物中一种严重的心血管急症，其特征是心包囊内异常积液，可迅速发展为危及生命的心脏压塞。该疾病影响约0.43%的转诊医院就诊犬，其中肿瘤性病因--特别是血管肉瘤--占大多数病例。虽然心包积液在猫中不常见，但通常继发于充血性心力衰竭或原发性心脏淋巴瘤。根据潜在病因的不同，预后差异显著，从血管肉瘤的中位生存期几天到特发性病例的几年不等，这凸显了快速诊断和适当干预的关键重要性。本报告探讨了成功管理这种复杂心血管病症的病理生理学、临床表现、诊断方法和治疗策略。

## 疾病概述与常见病因

心包积液定义为心脏周围心包囊内异常积液[1]。在犬中，这是一种相当常见的获得性心脏病，在转诊医院就诊犬中的患病率为0.43%（233例中有1例），约占出现心脏病症状犬的7%[1]。该疾病在猫中不常见，最常继发于充血性心力衰竭[2]。

**犬的常见病因：**
肿瘤是最常见原因，占71%的病例[1]。血管肉瘤是主要病因，占所有病例的34%，其次是特发性心包炎（20%）、间皮瘤（14%）和化学感受器瘤（8%）[7]。心基底部肿瘤，包括化学感受器瘤和异位甲状腺癌，在短头品种犬中特别常见[6]。特发性心包炎和心脏肿瘤是主要原因，其中血管肉瘤和心基底部肿瘤是最常见的心脏肿瘤[6]。

**猫的常见病因：**
在猫中，心脏肿瘤几乎都是原发性，其中淋巴瘤是最常见的诊断[3]。然而，猫的大多数轻度心包积液病例是由充血性心力衰竭而非肿瘤引起[2]。其他不太常见的原因包括感染（如猫传染性腹膜炎）、创伤和心腔破裂[2]。

### Sources
[1] Pericardial effusion: causes and clinical outcomes in dogs: https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings-0
[2] Acquired Heart and Blood Vessel Disorders in Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/acquired-heart-and-blood-vessel-disorders-in-cats
[3] Cardiac tumors in dogs and cats: https://www.dvm360.com/view/cardiac-tumors-in-dogs-and-cats
[6] Pericardial Disease in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/pericardial-disease-in-dogs-and-cats
[7] Pericardial effusion: causes and clinical outcomes in dogs: https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings

## 临床症状与诊断方法

心包积液通常表现为急性或慢性临床模式。最常见的就诊主诉是虚脱、虚弱、晕厥或嗜睡[1]。中年至老年大型品种犬，包括金毛寻回犬和德国牧羊犬，最常受影响[1]。犬可能经历急性虚脱或表现出长期症状，包括运动不耐、呼吸急促和腹部膨胀[1]。

体格检查显示特征性发现。心音特征性减弱，股动脉脉搏微弱[1]。约50%的犬因心脏压塞而出现腹水[1]。可触及奇脉，即呼气时脉搏较强，吸气时脉搏较弱[1]。当存在心脏压塞时，犬显示心源性休克迹象，包括苍白黏膜、四肢冰冷、低血压和心动过速[1]。

临床症状的严重程度取决于心包积液积聚的速度[2]。缓慢发展时，心包囊可以伸展，直到严重积液出现时才可能发展出临床症状[2]。相比之下，急性积液可能不会在放射学上引起严重的心脏轮廓增大，因为心包没有时间伸展[3]。

超声心动图是诊断心包积液最敏感和特异的检查[1][2]。它可以显示积液并在大多数肿瘤病例中检测到心脏肿块[1]。当观察到右心房和/或右心室舒张期塌陷时，诊断为心脏压塞[1][2]。X线片通常显示球形心脏增大并失去典型轮廓，但这种经典外观并不总是存在[1][2]。心电图常显示窦性心动过速、电交替（28%病例）和振幅小于1mV的QRS波群减弱（19%病例）[1]。心包穿刺术既提供治疗性缓解，又提供用于细胞学分析的诊断性液体[4]。

### Sources

[1] Pericardial effusion: causes and clinical outcomes in dogs (Proceedings): https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings-0

[2] Pericardial Disease in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/pericardial-disease-in-dogs-and-cats

[3] Thoracic imaging in emergency situations (Proceedings): https://www.dvm360.com/view/thoracic-imaging-emergency-situations-proceedings

[4] Managing pericardial effusion in the dog (Proceedings): https://www.dvm360.com/view/managing-pericardial-effusion-dog-proceedings

## 治疗选择与预防措施

**紧急处理：**
心包穿刺术是心包积液和心脏压塞犬猫初步稳定的首选治疗方法[1]。这种紧急程序包括使用导管机械引流心包腔，通常是通过右侧胸壁放置的14-16号套管针[1]。当诊断为心脏压塞时，应尽快进行该手术[2]。

**药物治疗：**
药物治疗通常对减少心包积液无效[1]。利尿剂在急性心脏压塞中是禁忌的，因为它们会减少血容量并导致心输出量进一步降低[1]。可在心包穿刺术前和术后给予肠外液体[1]。对于特发性心包积液，抗炎剂量的口服泼尼松龙可能有益，但缺乏证实其疗效的对照研究[6]。

**手术干预：**
对于特发性病例，建议在第三次心包穿刺术后进行心包次全切除术，这通常具有治愈性[1]。对于心基底部肿瘤，心包切除术可提供长达三年的姑息治疗，一项研究显示中位生存期为730天，而不手术为42天[8]。胸腔镜下部分心包切除术具有术后疼痛减轻和住院时间缩短等优势[9]。

**预防措施：**
由于大多数病例由肿瘤或特发性原因引起，一级预防策略有限。通过对易感品种进行常规心脏评估进行早期检测，可能允许更早干预。对于抗凝灭鼠剂中毒病例，维生素K1治疗可预防复发[7]。

### Sources
[1] Pericardial Disease in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/pericardial-disease-in-dogs-and-cats
[2] How to perform a pericardiocentesis - dvm360: https://www.dvm360.com/view/how-perform-pericardiocentesis
[6] Pericardial disease: The forgotten cardiac malady: https://www.dvm360.com/view/pericardial-disease-the-forgotten-cardiac-malady
[7] Managing pericardial effusion in the dog (Proceedings): https://www.dvm360.com/view/managing-pericardial-effusion-dog-proceedings
[8] Recognizing and treating pericardial disease: https://www.dvm360.com/view/recognizing-and-treating-pericardial-disease
[9] Thoracoscopic partial pericardectomy in the dog: https://www.dvm360.com/view/thoracoscopic-partial-pericardectomy-dog

## 鉴别诊断与预后

### 鉴别诊断

心包积液的主要鉴别诊断包括扩张型心肌病，其在X线片上呈现类似的球形心脏轮廓[1]。心包积液通常可与扩张型心肌病区分，因为心脏轮廓看起来更圆且边界更清晰[1][2]。其他鉴别诊断包括三尖瓣发育不良和严重右心疾病如严重三尖瓣反流，但这些通常只引起血液动力学上不显著的轻度心包积液[4]。

超声心动图提供更好的鉴别，检测心脏肿块的敏感性为80%，特异性为100%，有助于区分肿瘤性和特发性原因[4]。心基底部肿瘤有时可在胸部X线片上看到，可能导致气管偏移[1]。

### 预后

预后根据潜在病因差异显著[1][3]。无心脏肿块的犬生存时间显著更长（中位10.1个月），而超声心动图显示有肿块的犬（中位0.5个月）[4]。非肿瘤性病因的犬生存时间明显更长（中位24.83个月），而肿瘤性病因的犬（中位0.63个月）[4]。

血管肉瘤预后最差，中位生存期为0.07个月，而其他肿瘤性病因的中位生存期为5.17个月[4]。右心房肿块的犬生存时间显著缩短（中位0.03个月），而心基底部肿块（中位5.2个月）[4]。右心房血管肉瘤的预后仍然不良至极差，许多犬在诊断时已有转移[3]。

### Sources

[1] Recognizing and treating pericardial disease: https://www.dvm360.com/view/recognizing-and-treating-pericardial-disease
[2] Managing pericardial effusion in the dog (Proceedings): https://www.dvm360.com/view/managing-pericardial-effusion-dog-proceedings
[3] Pericardial Disease in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/pericardial-disease-in-dogs-and-cats
[4] Pericardial effusion: causes and clinical outcomes in dogs (Proceedings): https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings-0
