# 伴侣动物单核细胞嗜性埃里希体病

单核细胞嗜性埃里希体病是影响犬类的最具临床意义的蜱传疾病之一，由专性细胞内细菌*犬埃里希体*（*Ehrlichia canis*）引起。该疾病表现出独特的进展过程，包括急性、亚临床和可能危及生命的慢性阶段，这使其区别于其他通常表现为轻微和自限性的埃里希体感染。褐色犬蜱*血红扇头蜱*（*Rhipicephalus sanguineus*）是主要传播媒介，导致其地理分布广泛，在美国南部和东南部地区尤其高发。本综述全面探讨了病原体特征、各疾病阶段的临床表现、结合血清学和PCR检测的诊断方法、以多西环素治疗为中心的循证治疗方案，以及专注于蜱虫控制的预防策略。理解这些关键方面对于兽医从业人员有效诊断、治疗和预防伴侣动物中这种潜在严重疾病至关重要。

## 疾病概述

单核细胞嗜性埃里希体病是一种由专性细胞内细菌引起的蜱传疾病，主要影响犬和猫免疫系统中的单核细胞[1]。致病微生物犬埃里希体属于立克次体科，在受感染的白细胞内产生称为桑葚体的胞质内包涵体[1]。

由于其传播媒介褐色犬蜱（血红扇头蜱）在全球范围内存在，该疾病呈世界性分布[1]。在美国，犬单核细胞性埃里希体病最常见于南部、东南部和南部中心地区，在流行州犬的血清阳性率高达8.5%[2]。该疾病是北美最常见的犬类蜱传感染之一[3]。

单核细胞嗜性埃里希体病在兽医实践中尤为重要，因为犬埃里希体在埃里希体感染中可导致最严重的临床表现[1]。与其他通常引起轻微、自限性疾病的埃里希体种类不同，犬埃里希体可经历急性、亚临床和慢性阶段，其中慢性阶段可能危及生命[1]。该疾病的重要性还因其能够与其他蜱传病原体共同感染而进一步凸显，可能导致更严重的临床表现[4]。

### Sources

[1] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/en-au/generalized-conditions/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals

[2] Spotlight on Ehrlichia ewingii (Sponsored by IDEXX): https://www.dvm360.com/view/spotlight-ehrlichia-ewingii-sponsored-idexx

[3] Tick-borne diseases: Ehrlichiosis and Rocky Mountain spotted fever (Proceedings): https://www.dvm360.com/view/tick-borne-diseases-ehrlichiosis-and-rocky-mountain-spotted-fever-proceedings

[4] Coinfection with multiple tick-borne pathogens: https://www.dvm360.com/view/coinfection-with-multiple-tick-borne-pathogens

## 病原体特征与传播

单核细胞嗜性埃里希体病主要由*犬埃里希体*引起，这是一种属于立克次体科的革兰氏阴性专性细胞内细菌[1]。这种类似立克次体的微生物特异性靶向并感染单核细胞和巨噬细胞，导致特征性临床综合征[1]。

褐色犬蜱*血红扇头蜱*是*犬埃里希体*传播的主要媒介[2][3]。成年*血红扇头蜱*在从埃里希体病急性期感染的犬身上作为饱食若虫脱落后，可在长达155天内有效地将病原体传播给易感犬[4]。重要的是，在慢性期犬身上饱食的蜱虫未能将*犬埃里希体*传播给易感宿主[4]。

*犬埃里希体*对犬表现出强烈的宿主特异性，犬作为主要的储存宿主[1]。该微生物对单核细胞具有细胞嗜性，这使其区别于靶向不同细胞类型的其他埃里希体种类[6]。这种病原体存在于多个地理区域，特别是美国东南部、西南部和南部中心地区[6]。

传播发生在受感染蜱虫在吸血过程中叮咬易感犬时。蜱虫必须附着足够长的时间，以允许病原体从蜱虫的唾液腺转移到宿主的血液中[1][6]。

### Sources
[1] Coinfection with multiple tick-borne pathogens: https://www.dvm360.com/view/coinfection-with-multiple-tick-borne-pathogens
[2] American journal of veterinary research - avmajournals.avma.org: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/38/12/ajvr.1977.38.12.1953.pdf
[3] Focus on brown dog tick-transmitted Rocky Mountain spotted fever: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.11.0756.xml
[4] The Brown Dog Tick Rhipicephalus sanguineus and the Dog as: https://avmajournals.avma.org/view/journals/ajvr/38/12/ajvr.1977.38.12.1953.xml
[5] Ehrlichiosis and Related Infections in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/ehrlichiosis-and-related-infections-in-dogs
[6] Identifying and treating 3 tick-borne diseases in dogs: https://www.dvm360.com/view/identifying-and-treating-3-tick-borne-diseases-dogs

## 临床表现与疾病阶段

单核细胞嗜性埃里希体病表现出明显的临床阶段，急性和慢性阶段之间存在显著差异。在急性感染中，临床症状通常在感染后8-20天开始，包括网状内皮系统增生、发热、全身性淋巴结病、脾肿大，以及不同程度的厌食、抑郁和僵硬[1]。

**急性期特征：** 在这个持续2-4周的阶段，血象可能反映为轻度正细胞性贫血、白细胞减少或轻度白细胞增多。血小板减少常见但通常轻微（150,000-50,000个细胞/µL），很少出现瘀点。大多数犬经历自限性感染并自发恢复，但有些会发展为慢性疾病[1][3]。

**慢性期表现：** 慢性埃里希体病在初次感染后数月至数年发展，德国牧羊犬可能易感。临床症状包括明显脾肿大、肾小球肾炎、前葡萄膜炎和严重体重减轻。血液学异常明显严重，包括全血细胞减少、引起鼻衄和瘀点的严重血小板减少，以及频繁的多克隆高丙种球蛋白血症[1][5]。

**独特的血液学特征：** 血小板减少是埃里希体感染中最一致的发现，尽管在慢性病例中通常更严重。患有慢性埃里希体病的犬在抽吸细胞学检查中常出现明显的浆细胞增多，并可能表现出导致出血风险的免疫介导机制[1][3]。

### Sources
[1] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/en-au/generalized-conditions/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[2] Spotlight on Ehrlichia ewingii (Sponsored by IDEXX): https://www.dvm360.com/view/spotlight-ehrlichia-ewingii-sponsored-idexx
[3] Identifying and treating 3 tick-borne diseases in dogs: https://www.dvm360.com/view/identifying-and-treating-3-tick-borne-diseases-dogs
[4] Tick-borne disease: Ecrlichiosis, Lyme borreliosis and anaplasmosis (Proceedings): https://www.dvm360.com/view/tick-borne-disease-ecrlichiosis-lyme-borreliosis-and-anaplasmosis-proceedings
[5] Inflammatory and Infectious Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/inflammatory-and-infectious-diseases-of-the-spinal-column-and-cord-in-animals

## 诊断方法

诊断单核细胞嗜性埃里希体病需要结合临床表现评估和多种实验室技术的综合方法。血小板减少是最一致的发现，血小板计数通常低于50,000/μl[1]。全血细胞计数通常显示白细胞减少、贫血和形态学异常，包括反应性淋巴细胞和单核细胞增多[5]。

血清学检测仍然是基础，免疫荧光抗体（IFA）检测对犬埃里希体检测具有高度敏感性[1]。基于ELISA的检测如SNAP 4Dx提供快速院内筛查，但对低抗体滴度的敏感性降低[3]。埃里希体种类之间存在交叉反应性，需要仔细解读[1]。

PCR检测提供物种特异性鉴定，并能区分活动性感染和既往暴露[1][3]。然而，PCR敏感性随样本类型和时间而异，一项研究中只有36只血清阳性犬中的10只显示PCR阳性结果[2]。血涂片检查桑葚体的敏感性较低，但当存在时提供快速诊断支持[6]。

显示四倍滴度增加的配对血清学确认活动性感染[6]。支持性实验室发现包括高球蛋白血症、低白蛋白血症、肝酶升高和蛋白尿，特别是在慢性病例中[5][6]。当临床症状和流行病学因素提示埃里希体感染时，结合血清学和PCR检测可最大化诊断准确性。

### Sources
[1] Coinfection with multiple tick-borne pathogens: https://www.dvm360.com/view/coinfection-with-multiple-tick-borne-pathogens
[2] Managing and preventing feline febrile diseases: https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings
[3] Spotlight on Ehrlichia ewingii: https://www.dvm360.com/view/spotlight-ehrlichia-ewingii-sponsored-idexx
[4] Diagnosing and treating ehrlichiosis and anaplasmosis in dogs: https://www.dvm360.com/view/diagnosing-and-treating-ehrlichiosis-and-anaplasmosis-dogs-proceedings
[5] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/en-au/generalized-conditions/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[6] Identifying and treating 3 tick-borne diseases in dogs: https://www.dvm360.com/view/identifying-and-treating-3-tick-borne-diseases-dogs

## 治疗方案与管理

多西环素是治疗单核细胞嗜性埃里希体病的金标准，因其具有优异的细胞内穿透力和对立克次体的抑菌活性[1]。推荐剂量为5 mg/kg每12小时一次或10 mg/kg每24小时一次，口服或静脉给药，至少持续28天[1][3]。当怀疑感染时应开始经验性治疗，不应等待实验室结果而延误[3]。

替代抗生素包括四环素（22 mg/kg每日三次）、米诺环素和二丙酸咪唑苯脲（5-7 mg/kg肌肉注射，间隔两周两次给药）[1][3]。如果多西环素不可用，可用米诺环素替代[1]。值得注意的是，恩诺沙星对埃里希体感染无效[4]。

在急性病例中，发热通常在适当抗生素治疗后24-48小时内消退[1][3]。然而，慢性病例可能经历持续3-6个月的血液学异常，尽管临床改善通常发生得早得多[1][3]。

支持性护理至关重要，特别是在有并发症的慢性病例中。这包括为严重血小板减少或贫血进行血小板或全血输血、液体治疗和使用非甾体抗炎药控制发热[1][3]。短期糖皮质激素治疗（泼尼松2 mg/kg/天，持续2-5天）可能对危及生命的血小板减少的急性病例有益[4]。如果存在严重白细胞减少，可能需要同时使用广谱抗生素[1]。

### Sources
[1] Ehrlichiosis and Related Infections in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/ehrlichiosis-and-related-infections-in-dogs
[2] Ehrlichiosis and Related Infections in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/ehrlichiosis-and-related-infections-in-cats
[3] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals - ...: https://www.merckvetmanual.com/generalized-conditions/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[4] Diagnosing and treating ehrlichiosis and anaplasmosis in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-ehrlichiosis-and-anaplasmosis-dogs-proceedings

## 预防、鉴别诊断与预后

单核细胞嗜性埃里希体病的预防以全面的蜱虫控制策略为中心。建议在蜱虫流行地区的所有犬全年使用外用杀蜱剂[1]。有多种外用药物可用于预防蜱虫叮咬，应在将犬带入有蜱虫出没的区域前按照标签说明使用[2]。

对于在犬舍和家庭中可能成为问题的褐色犬蜱感染，含有丙硫磷、双甲脒或氟氯苯菊酯的有效长效项圈已被证明对血红扇头蜱有活性[2]。应限制犬在小径外行走和在落叶层中可能存在蜱虫的草地活动[2]。散步后定期检查并仔细清除蜱虫至关重要[2]。

急性单核细胞嗜性埃里希体病的主要鉴别诊断包括落基山斑点热、布鲁菌病、芽生菌病、心内膜炎、系统性红斑狼疮和淋巴肉瘤[2]。慢性埃里希体病必须与雌激素毒性、骨髓纤维化、免疫介导性全血细胞减少和伴有特定器官功能障碍的多系统疾病相鉴别[2]。此外，无形体病可能表现出相似的临床症状，但通常引起的疾病较轻[3][4]。

如果在疾病早期开始治疗，大多数受影响犬的预后良好[5]。临床改善通常在治疗开始后24-48小时内出现[2]。如果早期诊断并适当治疗，犬不应出现死亡[6]。在慢性病例中，血液学异常可能持续3-6个月，尽管对治疗的临床反应通常发生得早得多[2]。如果发生严重出血或贫血，一些犬可能需要输血[6]。如果怀疑慢性埃里希体病，应在6个月后重复犬埃里希体抗体滴度和全血PCR以确认治疗成功[2]。

### Sources
[1] Spotlight on Ehrlichia ewingii (Sponsored by IDEXX): https://www.dvm360.com/view/spotlight-ehrlichia-ewingii-sponsored-idexx
[2] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/infectious-diseases/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[3] Identifying and treating 3 tick-borne diseases in dogs: https://www.dvm360.com/view/identifying-and-treating-3-tick-borne-diseases-dogs
[4] Tick-borne diseases: Ehrlichiosis and Rocky Mountain spotted fever (Proceedings): https://www.dvm360.com/view/tick-borne-diseases-ehrlichiosis-and-rocky-mountain-spotted-fever-proceedings
[5] Tick-borne disease: ehrlichia-lyme borreliosis-anaplasmosis (Proceedings): https://www.dvm360.com/view/tick-borne-disease-ehrlichia-lyme-borreliosis-anaplasmosis-proceedings
[6] Ehrlichiosis and Related Infections in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/ehrlichiosis-and-related-infections-in-dogs
