# 伴侣动物水合髓核突出：综合性兽医综述

水合髓核突出（HNPE）是犬猫中一种独特的急性脊髓损伤类型，与传统椎间盘突出有显著差异。本综合性兽医综述将HNPE视为一种主要影响大型犬在剧烈活动期间发生的非压迫性神经系统疾病。该报告综合了当前八个关键领域的临床知识：疾病病理生理学和流行病学、区分HNPE与其他脊柱疾病的诊断影像学标准、手术与保守治疗方法的治疗结果比较，以及影响恢复率的预后因素。主要发现包括：无论采用何种治疗方法，89-94%的功能恢复率显示出极佳的预后；平均恢复时间快速，为6-7天；以及MRI通过特征性的"海鸥形"影像模式在准确诊断中的关键作用。

## 疾病概述

水合髓核突出（HNPE）是犬类中一种独特的急性非压迫性脊髓损伤类型，也称为急性非压迫性髓核突出（ANNPE）[1]。与传统椎间盘突出不同，HNPE涉及水合髓核物质的急性突出，该物质撞击脊髓，造成缺血性损伤而无持续性压迫[2]。

其病理生理学涉及髓核物质的爆炸性突出，通常发生在剧烈活动期间，在脊髓中造成"中风样"缺血事件[3]。这导致急性、非进行性、不对称性神经功能缺损，与压迫性椎间盘疾病相区别。

大型犬主要受影响，其中德国牧羊犬比例过高[1]。该疾病通常发生在中年犬（3-7岁），常在运动或剧烈活动期间发生[2]。一些研究表明雄性犬易患病[4]。胸腰段（T3-L3）最常受影响，特别是T12-L2椎体节段。与软骨营养障碍品种中见到的汉森I型椎间盘疾病不同，HNPE主要影响非软骨营养障碍品种[6]。

HNPE常因相似的急性发作和不对称性表现而与纤维软骨栓塞性脊髓病（FCE）混淆[3]。然而，磁共振成像结果和临床进展模式有助于区分这些疾病，在许多情况下，HNPE比FCE显示出更好的恢复潜力。

### Sources

[1] Association of clinical and magnetic resonance imaging findings with outcome in dogs with presumptive acute noncompressive nucleus pulposus extrusion: https://avmajournals.avma.org/view/journals/javma/234/4/javma.234.4.495.xml

[2] Comparison of clinical signs and outcomes between dogs with presumptive ischemic myelopathy and dogs with acute noncompressive nucleus pulposus extrusion: https://avmajournals.avma.org/view/journals/javma/249/7/javma.249.7.767.xml

[3] Assessment of interobserver agreement and use of selected magnetic resonance imaging variables for differentiation of acute noncompressive nucleus pulposus extrusion and ischemic myelopathy in dogs: https://avmajournals.avma.org/view/journals/javma/248/9/javma.248.9.1013.xml

[4] Surgery STAT: Diagnosing intervertebral disk disease: https://www.dvm360.com/view/surgery-stat-diagnosing-intervertebral-disk-disease

[5] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified

[6] The volume of extruded materials is correlated with neurologic severity in small-breed dogs with type I thoracolumbar intervertebral disk herniation: https://avmajournals.avma.org/view/journals/javma/261/3/javma.22.07.0326.xml

## 常见病原体

水合髓核突出（HNPE）本质上是一种影响犬猫椎间盘的非感染性、退行性疾病[1][2]。与细菌或真菌脊柱感染（如椎间盘炎）不同，HNPE不涉及病原体作为致病因子。

该疾病代表汉森I型椎间盘疾病的一种形式，其中髓核物质迅速突出进入椎管[2]。这使得HNPE与由细菌病原体（如葡萄球菌属、链球菌属和大肠杆菌）引起的感染性椎间盘疾病相区别，后者通常产生严重脊柱疼痛和全身性疾病[3][5]。

HNPE的病理生理学涉及纤维环的机械性破裂，允许髓核物质疝出，通过血管损害而非感染性侵入在脊髓中造成"中风样"事件[4][5]。HNPE中突出的椎间盘物质特征性地呈凝胶状或液体状，而非固体或钙化状[6]。

这种非感染性特征在临床上具有重要意义，因为HNPE患者通常不出现发热、白细胞计数升高或其他感染性全身症状[4]。该疾病主要影响软骨营养障碍品种，需要通过适当的影像学和临床评估与感染性原因进行鉴别[6]。

### Sources

[1] Clinical signs, causes, and outcome of central cord: https://avmajournals.avma.org/view/journals/javma/262/3/javma.23.08.0478.xml
[2] Central cord syndrome: clinical features, etiological diagnosis: https://avmajournals.avma.org/view/journals/javma/260/7/javma.21.08.0389.xml
[3] When to consider aspergillosis in dogs: https://www.dvm360.com/view/when-consider-aspergillosis-dogs
[4] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified
[5] Degenerative lumbosacral stenosis in dogs: https://www.dvm360.com/view/degenerative-lumbosacral-stenosis-dogs
[6] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs

## 临床症状和体征

水合髓核突出表现为急性发作的神经功能缺损，其表现因脊髓压迫的位置和严重程度而异。最具特征性的表现是突然发作的背部或颈部疼痛，常表现为颈部僵硬、肌肉痉挛和不愿移动[1]。在胸腰段病例中，患病动物表现为脊柱后凸和不愿正常行走。

神经功能缺损范围从轻度共济失调到完全瘫痪。颈椎突出通常导致四肢轻瘫伴所有肢体的本体感觉缺失，而胸腰段病例通常表现为后肢轻瘫或后肢瘫痪[2]。脊柱疼痛的常见体征包括发热、痛觉过敏、颈部僵硬和疼痛性椎旁肌肉痉挛[3]。

深痛感知是瘫痪患者最重要的预后指标。通过捏压骨结构并观察行为反应（如发声或转头）来评估，这与简单的缩回反射不同[4]。

在患有椎间盘病理的猫中，近一半表现出脊柱疼痛或神经功能缺损体征[5]。与典型的椎间盘疾病不同，水合髓核突出常发生在运动中的年轻动物，由于损伤的震荡性质，一些病例尽管初始神经体征严重，但显示最小持续性压迫。

### Sources
[1] Merck Veterinary Manual Recognition and Assessment of Pain in Animals: https://www.merckvetmanual.com/therapeutics/pain-assessment-and-management/recognition-and-assessment-of-pain-in-animals
[2] Merck Veterinary Manual Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals
[3] Merck Veterinary Manual Meningitis, Encephalitis, and Encephalomyelitis in Animals: https://www.merckvetmanual.com/nervous-system/meningitis-encephalitis-and-encephalomyelitis/meningitis-encephalitis-and-encephalomyelitis-in-animals
[4] Merck Veterinary Manual The Neurologic Examination of Animals: https://www.merckvetmanual.com/nervous-system/the-neurologic-examination/the-neurologic-examination-of-animals
[5] Spinal magnetic resonance imaging in cats - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.02.0099.xml

## 诊断方法

诊断HNPE需要结合临床评估和先进影像技术的多模态方法。磁共振成像（MRI）是HNPE诊断的金标准[1][2]。MRI序列专门评估病变位置并表征椎管内水合髓核物质的独特影像特征[2]。

HNPE的MRI诊断标准包括识别突然发生的、非压迫性髓核突出及其特征性信号强度[1]。突出的物质表现为边界清晰的T2加权高信号和T1加权等信号或低信号物质，源自椎间盘间隙，呈独特的"海鸥"形状[3]。与传统椎间盘突出不同，HNPE显示出特定的MRI模式，可与其他脊柱病理相区别[1][2]。

与MRI相比，计算机断层扫描（CT）在HNPE诊断中存在显著局限性[4]。虽然CT可以识别脊柱压迫，但其较差的软组织对比度使其不太适合表征定义该疾病的水合髓核物质。HNPE物质的凝胶状或液体稠度需要只有MRI才能提供的优越组织表征能力[3]。

临床表现评估仍然至关重要，神经系统检查结果支持影像诊断。犬通常表现为急性发作的神经功能缺损而无先前创伤，这有助于将HNPE与其他脊柱功能障碍原因区分开来[1]。最大横截面脊髓压迫范围可从0%到62%，大多数病变影响颈椎区域[3]。

### Sources
[1] Spinal magnetic resonance imaging in cats: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.02.0099.xml
[2] Anatomic description and clinical relevance of the: https://avmajournals.avma.org/view/journals/javma/255/6/javma.255.6.687.xml
[3] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs
[4] Merck Veterinary Manual Degenerative Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/degenerative-diseases-of-the-spinal-column-and-cord-in-animals

## 治疗选择

水合髓核突出（HNPE）的主要治疗方法包括手术减压和保守治疗，两者显示出相似的成功率(1)。手术干预通常涉及颈椎病例的腹侧开槽术或胸腰段病变的半椎板切除术(1)。HNPE中突出椎间盘物质的凝胶状稠度使其能够在椎管内自然分散，这解释了为什么即使不手术切除压迫物质，保守治疗也可能有效(1)。

保守治疗包括笼养休息、物理治疗和多模式镇痛疗法，包括安乃近、加巴喷丁或普瑞巴林、芬太尼-利多卡因-氯胺酮恒速输注，以及根据需要使用的尿潴留药物(1)。手术和保守治疗方法均在约89-94%的病例中实现功能恢复，平均恢复时间相似，为6-7天(1)。

物理康复在治疗后护理中起着关键作用，结合被动关节活动度练习、按摩疗法和神经肌肉电刺激以防止肌肉萎缩(2)。水疗和水下跑步机疗法可通过提供支撑性负重运动来增强恢复(1)。当MRI显示异质性椎间盘物质表明不经手术干预会出现长期脊髓压迫时，最常选择手术治疗(1)。

### Sources
[1] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs
[2] Management tips for the postoperative neurosurgical case: https://www.dvm360.com/view/management-tips-postoperative-neurosurgical-case-proceedings

## 预防措施

HNPE（水合髓核突出）的预防侧重于最小化椎间盘的机械应力并维持易感伴侣动物的最佳脊柱健康[1][2]。

活动调整代表主要的预防策略。有HNPE病史的犬应避免高强度活动，包括从高处跳跃、过度爬楼梯和剧烈的扭动动作，这些动作会对脊柱造成旋转应力[1]。受控制的牵引绳运动和游泳提供有益的低冲击替代方案，可在不压迫椎间盘的情况下保持健康[2]。

品种特异性考虑至关重要，因为软骨营养障碍品种（腊肠犬、法国斗牛犬、比格犬）由于椎间盘过早退化而面临显著升高的HNPE风险[2]。这些品种受益于早期实施活动限制和体重管理方案。到2岁时，十只软骨营养障碍犬中有九只的椎间盘出现退行性变化[2]。

体重管理在预防中至关重要，因为肥胖会增加椎间盘的机械负荷。维持理想身体状况可减少压迫力并降低HNPE复发风险[1]。

环境调整包括提供通往高处的坡道或台阶、使用支撑性卧具以及确保防滑地板表面，以防止突然移动或跌倒[1]。定期兽医随访检查对于监测慢性后遗症和确保适当的长期疼痛管理至关重要[3]。

### Sources

[1] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs
[2] Surgical versus medical management of canine disk disease: https://www.dvm360.com/view/making-cut-surgical-versus-medical-management-canine-disk-disease
[3] Understanding canine intervertebral disc disease: https://www.dvm360.com/view/understanding-canine-intervertebral-disc-disease

## 鉴别诊断

将HNPE与其他脊柱疾病区分需要仔细评估临床和影像特征。主要鉴别诊断包括汉森I型椎间盘突出、急性非压迫性髓核突出（ANNPE）、纤维软骨栓塞性脊髓病和创伤性脊柱损伤[1][2]。

汉森I型椎间盘突出表现为相似的急性发作神经体征，但MRI上通常显示固体或钙化的突出椎间盘物质，与HNPE在T2加权图像上的特征性凝胶状高信号外观形成对比[4]。MRI上独特的"海鸥"形状模式有助于特异性识别HNPE[4]。

ANNPE代表另一个重要的鉴别诊断，因为两种情况都可导致急性神经功能缺损[1][2]。然而，ANNPE涉及最小体积的椎间盘物质，通过突出的速度而非持续性压迫造成震荡性脊髓损伤[1]。比较这些疾病的研究发现相似的临床表现，强调了先进影像学在准确诊断中的重要性[1]。

纤维软骨栓塞性脊髓病通常表现为剧烈活动后的不对称性神经功能缺损和非进行性体征，与HNPE的压迫性质不同[2][3]。创伤性脊柱损伤，包括椎骨骨折、脱位和半脱位也必须考虑，特别是当有创伤史时[2][3]。

中央索综合征可由多种疾病引起，包括HNPE，其中汉森I型椎间盘突出最常见（占病例的36%），HNPE占病例的22%[5]。MRI仍然是鉴别的金标准，揭示HNPE源自椎间盘间隙的特征性T2加权高信号物质。

### Sources

[1] Comparison of clinical signs and outcomes between dogs with presumptive ischemic myelopathy and dogs with presumptive acute noncompressive nucleus pulposus extrusion: https://avmajournals.avma.org/view/journals/javma/249/7/javma.249.7.767.xml

[2] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.12.0690.xml

[3] Association of clinical and magnetic resonance imaging findings: https://avmajournals.avma.org/view/journals/javma/234/4/javma.234.4.495.xml

[4] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs

[5] Central cord syndrome: clinical features, etiological factors: https://avmajournals.avma.org/view/journals/javma/260/7/javma.21.08.0389.xml

## 预后

诊断为水合髓核突出（HNPE）的犬预后极佳，通过手术和保守治疗方法均可实现优异的恢复率。最近的比较研究表明，无论选择何种治疗方式，约89-94%的病例出现功能恢复[1][2]。

恢复时间始终快速，大多数犬在手术减压或保守治疗后6至7天内达到功能恢复[1]。这种快速改善反映了HNPE独特的病理生理学，其中突出椎间盘物质的凝胶状稠度允许其在椎管内自发分散，自然缓解脊髓压迫而无需手术干预[1]。

已确定关键的预后因素显著影响结果。磁共振成像上显示较大病变的犬预后明显较差，需要更长的恢复期[1][2]。脊髓压迫程度和影像上异质性椎间盘物质的存在也可能对恢复率产生负面影响[1][2]。

HNPE病例的死亡率仍然较低，死亡通常发生在严重病例中，由心肺骤停或上行-下行脊髓软化引起[1][2]。绝大多数达到功能恢复的犬保持优异的长期预后，即使在需要手术干预的病例中也记录到完全的神经恢复。

### Sources

[1] Treating Hydrated Nucleus Pulposus Extrusion in Dogs: https://www.dvm360.com/view/treating-hydrated-nucleus-pulposus-extrusion-in-dogs
[2] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/251/9/javma.251.9.1007.xml
