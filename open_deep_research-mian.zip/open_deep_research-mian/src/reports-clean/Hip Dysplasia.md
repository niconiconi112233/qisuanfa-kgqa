# 犬猫髋关节发育不良：综合兽医指南

髋关节发育不良是兽医实践中最重要的骨科疾病之一，以不同严重程度影响犬和猫。这种多因素的髋关节发育障碍性疾病涉及关节松弛，导致进行性退行性变化，影响生活质量和活动能力。虽然主要见于大型犬，在某些品种中患病率高达75%，但该病也见于小型犬和猫，特别是缅因猫。本报告探讨了伴侣动物中的病理生理学、临床表现、诊断方法、从保守管理到全髋关节置换等先进手术干预的治疗方式，以及影响长期预后的因素。

## 疾病概述

髋关节发育不良是一种多因素的髋关节异常发育，其特征是关节松弛和随后的退行性关节病[1]。其病理生理基础涉及髋关节肌肉质量与快速骨骼发育之间的不匹配，导致髋关节松弛，进而引起退行性变化，包括髋臼骨硬化、骨赘形成、股骨颈增厚、关节囊纤维化和股骨头半脱位[1]。

这种疾病主要影响大型犬，在某些品种中放射学患病率高达75%[2]。然而，髋关节发育不良在小型犬和猫中也日益受到重视[3]。在猫中，髋关节发育不良主要见于缅因猫[4]。犬中患病率最高的是那些倾向于粗壮、圆润和沉重的品种（例如，德国牧羊犬、拉布拉多寻回犬），而患病率最低的是纤细、匀称的品种（例如，灵缇、惠比特犬）[4]。

病因是多因素的，涉及遗传易感性和环境触发因素[6]。髋关节发育不良表现为多基因遗传，遗传力评分在0.1至0.6之间，表明环境因素对疾病表达有显著影响[6]。环境因素显著影响表型表达，在遗传易感犬中，限制热量摄入可使髋关节发育不良发病率降低50%[2]。

### Sources

[1] Hip Dysplasia in Dogs - Musculoskeletal System: https://www.merckvetmanual.com/en-au/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/hip-dysplasia-in-dogs

[2] New hope for old hips: https://www.dvm360.com/view/new-hope-old-hips

[3] Diagnosing hip dysplasia (Proceedings): https://www.dvm360.com/view/diagnosing-hip-dysplasia-proceedings

[4] Osteoarthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats

[6] Speaking with clients about hip dysplasia (Proceedings): https://www.dvm360.com/view/speaking-with-clients-about-hip-dysplasia-proceedings

## 临床表现和诊断方法

髋关节发育不良的临床表现各异，通常与放射学严重程度不相关[1]。跛行可能轻微、中度或严重，且通常在运动后加重[1]。常观察到特征性的"蹦跳步态"，同时伴有起立困难、跳跃或爬楼梯困难[1,2]。犬可能表现出运动不耐受、行为改变或单侧跛行[4]。

髋关节发育不良遵循双峰年龄分布。一岁以下的幼犬因关节松弛、半脱位和滑膜炎而出现疼痛和跛行[4]。老年犬则主要因进行性退行性关节病而表现出功能障碍[4]。

体格检查显示关节松弛（阳性奥托拉尼征）、活动范围减小、摩擦音，以及在髋关节完全伸展和屈曲时疼痛[1]。奥托拉尼测试是最广泛使用的临床评估方法，通过沿股骨施加轴向力引起半脱位，然后外展肢体直至复位[4]。清脆的"咔嗒"声表示相对正常的髋臼结构，而逐渐滑动则提示髋臼磨损[4]。

放射学检查对于诊断和治疗规划仍然至关重要[1]。腹背位髋关节伸展视图最常用，显示半脱位（股骨头覆盖率低于50%）、关节重塑、骨赘形成和髋臼变化[4]。PennHIP分离技术使用0-1的分离指数提供定量松弛评估，高于0.7的值表示退行性关节病的可能性更高[4]。包括CT在内的高级影像学检查可提供额外的软骨评估能力[6]。

### Sources
[1] Merck Veterinary Manual Hip Dysplasia in Dogs: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/hip-dysplasia-in-dogs
[2] Merck Veterinary Manual Hip Dysplasia - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/hip-dysplasia
[3] DVM 360 Canine hip dysplasia: new trends in diagnosis, treatment and prevention: https://www.dvm360.com/view/canine-hip-dysplasia-new-trends-diagnosis-treatment-and-prevention
[4] DVM 360 Diagnosing hip dysplasia: https://www.dvm360.com/view/diagnosing-hip-dysplasia-proceedings
[5] American Journal of Veterinary Research Breed-specific evaluation: https://avmajournals.avma.org/view/journals/ajvr/84/11/ajvr.23.07.0170.xml
[6] AVMA Journals Abstract: https://avmajournals.avma.org/view/journals/ajvr/69/3/ajvr.69.3.362.xml

## 治疗选择和管理策略

髋关节发育不良的治疗包括保守和手术方法，选择基于患者年龄、严重程度和临床表现。保守管理是大多数病例的基础，包括多模式治疗，包括体重控制、控制运动、非甾体抗炎药（卡洛芬、美洛昔康、地拉考昔）以及多硫酸氨基多糖等软骨保护剂[1][2]。物理治疗，包括游泳和水疗，有助于维持关节活动范围和肌肉力量，当水位达到髋部时，水疗可减少60%的髋关节负荷[1][2][7]。

手术干预按患者年龄和疾病严重程度分类。对于4-5个月以下有髋关节松弛的幼犬，幼年耻骨联合融合术（JPS）可预防髋臼发育异常[2]。三重骨盆截骨术（TPO）适用于6-12个月中度发育不良且无明显重塑变化的犬，5年时达到90-95%的满意结果[1][2]。

对于患有明确关节炎的成年犬，全髋关节置换术（THR）代表金标准，提供90-95%的优异长期功能，并在3个月内使患者恢复正常负重[1][4]。微型THR适用于猫和小型犬（2.5-12公斤），成功率相似[1]。然而，客观数据显示，与THR相比，股骨头颈切除术（FHO）导致持续性肌肉萎缩（50-80%的病例）、肢体缩短（60-85%）和功能下降[4][6]。尽管存在局限性，FHO需要密集的术后康复治疗，包括活动范围练习，可能需要六个月才能获得良好的行走功能[6]。

### Sources

[1] Surgery STAT: Micro total hip replacement for cats and small dogs: https://www.dvm360.com/view/surgery-stat-micro-total-hip-replacement-cats-and-small-dogs

[2] Speaking with clients about hip dysplasia (Proceedings): https://www.dvm360.com/view/speaking-with-clients-about-hip-dysplasia-proceedings

[4] FHO vs total hip replacement: separating fact from fiction: https://www.dvm360.com/view/fho-vs-total-hip-replacement-separating-fact-from-fiction

[6] Speaking with clients about hip dysplasia (Proceedings): https://www.dvm360.com/view/speaking-with-clients-about-hip-dysplasia-proceedings

[7] Rehabilitation and canine osteoarthritis: a multimodal approach: https://www.dvm360.com/view/rehabilitation-and-canine-osteoarthritis-a-multimodal-approach

## 预后和临床结果

犬髋关节发育不良的预后因治疗方法、诊断时严重程度、患者年龄和干预时机而有显著差异。保守管理是合理的，但最终在许多犬中会失效[3]。大多数年轻患者由于增生性纤维组织形成缓解疼痛，在15至18个月龄时临床状况会自发改善[3]。

对于手术干预，结果差异显著。当不发生并发症时，全髋关节置换术可产生优异的术后结果[2]。接受股骨头颈切除术（FHNE）的犬约85%的病例显示良好至优异的结果，但随着犬体重增加，成功率下降[3]。对于1-7岁的犬，FHNE的终身成本最低，而全髋关节置换术在4岁前是第二低成本的选择[1]。

三重骨盆截骨术的预后与手术时的退行性关节病程度直接相关。在12个月龄接受TPO的犬发生术后退行性关节病的可能性是在6个月龄接受手术犬的7倍[2]。对于双侧髋关节发育不良，85%的病例在一侧进行全髋关节置换术后临床状况良好[2]。

长期保守管理研究表明，尽管89%的病例有退行性关节病的放射学证据，但76%的主人报告他们的犬没有或仅有轻微跛行，作为宠物是可以接受的[3]。体重优化是管理髋关节发育不良最有效的终身策略，减重6%可显著改善症状[4]。全髋关节置换术的预后极佳，5年时95%达到良好至优异的结果[5]。

### Sources

[1] Lifetime cost of surgical treatment for canine hip osteoarthritis: https://avmajournals.avma.org/view/journals/javma/262/8/javma.24.01.0043.xml

[2] Speaking with clients about hip dysplasia (Proceedings): https://www.dvm360.com/view/speaking-with-clients-about-hip-dysplasia-proceedings

[3] Canine hip dysplasia (Proceedings): https://www.dvm360.com/view/canine-hip-dysplasia-proceedings

[4] Tips for Managing Osteoarthritis in Dogs: https://www.dvm360.com/view/tips-for-managing-osteoarthritis-in-dogs

[5] Hip dysplasia in adult dogs--options and nutraceuticals (Proceedings): https://www.dvm360.com/view/hip-dysplasia-adult-dogs-options-and-nutraceuticals-proceedings
