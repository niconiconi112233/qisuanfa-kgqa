# 伴侣动物的乳牙滞留

乳牙滞留是兽医实践中一种重要的发育性牙齿疾病，尤其影响小型和玩具品种犬。当恒牙萌出时，乳牙未能自然脱落，导致牙齿拥挤和潜在的正畸并发症。本报告探讨了导致该状况的潜在遗传和发育因素，介绍了包括临床检查和X线评估在内的诊断方法，并详细说明了基于证据的治疗方案，重点是及时的手术拔除。主要研究结果表明，确诊后立即干预可防止永久性咬合不正，而延迟治疗往往导致需要复杂矫正手术的不可逆正畸问题。

## 摘要

乳牙滞留主要是一种遗传性疾病，需要立即进行兽医干预以防止长期并发症。该疾病最常影响小型品种的犬齿，异常的恒牙萌出路径阻碍了正常的乳牙根吸收。通过系统的口腔检查和X线评估进行早期诊断，可实现及时的手术拔除，在恒牙萌出后立即进行时预后良好。

| 治疗时机 | 结果 | 长期并发症 |
|------------------|---------|------------------------|
| 立即拔除 | 预后良好；恒牙自行矫正 | 极少或无 |
| 延迟干预 | 预后受损 | 永久性咬合不正、牙周病、早期牙齿脱落 |

"三十秒法则"拔牙技术可防止根部断裂，同时确保牙齿完全移除。关键预防措施包括避免在下颌牙的舌侧放置牙挺，并将上颌拔牙力导向颊侧。成功取决于早期识别、正确的手术技术以及客户对品种易感性的教育。兽医应实施主动监测方案，特别是对易感品种，并提供繁殖咨询以防止遗传传播。

## 疾病概述

乳牙滞留，也称为滞留乳牙，是一种发育性牙齿疾病，指当恒牙开始萌出时，乳牙未能自然脱落[1]。该状况定义为在恒牙开始萌出到口腔时即发生，无论恒牙是否完全萌出[2]。

该疾病主要影响小型和玩具品种犬，但也可能发生在任何犬种中，偶尔也见于猫[1]。最常受影响的牙齿是犬齿，其次是门齿和前臼齿[1][2]。正常的牙齿萌出遵循可预测的时间表，乳牙在2个月大时完全萌出，通常在6个月时被恒牙替代[2]。

乳牙滞留通常被认为是遗传性疾病，因为其在某些品种和头部类型中的发生模式[2]。根本原因通常是恒牙萌出路径不正确，未能产生正常乳牙根吸收和随后脱落所需的压力[2]。

### Sources

[1] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth

[2] Tooth eruption and exfoliation in dogs and cats: https://www.dvm360.com/view/tooth-eruption-and-exfoliation-dogs-and-cats

## 病因和临床表现

乳牙滞留是由于正常乳牙脱落失败引起的，主要原因是恒牙萌出路径异常[1]。当恒牙遵循不正确的萌出模式时，它们无法对乳牙根施加足够的压力，阻止了本应导致自然脱落的正常吸收过程[2]。这一机制反驳了常见的误解，即滞留乳牙导致恒牙位置不正。

遗传因素在病因中起重要作用，某些品种和头部类型表现出更高的易感性[2]。小型和玩具品种犬尤其受影响，包括马尔济斯犬、约克夏梗、博美犬和玩具贵宾犬[3,5]。该疾病最常发生在犬齿，其次是门齿和前臼齿[2]。

临床表现通常涉及牙弓中可见的额外牙齿，造成拥挤和恒牙位置异常[2]。犬齿最常见的表现是前移位（上颌）或舌侧移位（下颌），可能导致软组织创伤[4]。该疾病可导致咬合不正、因拥挤引起的牙周病以及支持结构的发育异常[3,5]。早期识别至关重要，因为正畸变化可能在恒牙萌出后两周内发生[2]。

### Sources
[1] Current concepts in veterinary dentistry (Proceedings): https://www.dvm360.com/view/current-concepts-veterinary-dentistry-proceedings
[2] Pediatric dentistry: An overview of common problems you'll see in practice: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice
[3] Dental Disorders of Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/dental-disorders-of-dogs
[4] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[5] Congenital and Inherited Anomalies of the Teeth in Animals: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/congenital-and-inherited-anomalies-of-the-teeth-in-animals

## 诊断方法和鉴别诊断

诊断乳牙滞留需要系统的临床检查和X线评估[1]。清醒状态下的口腔检查应评估面部对称性、牙龈健康和牙齿位置，特别注意识别同一位置存在的乳牙和恒牙[2]。

X线成像是必要的，被认为是诊断的金标准[1]。必须拍摄口腔内X线片以确认恒牙胚的存在，评估根部解剖结构，并排除阻生牙或含牙囊肿等并发症[3]。拔牙前X线片是强制性的，以评估根部形态并识别潜在并发症[4]。

关键诊断特征包括更宽、更钝的恒犬齿在更窄、尖端更锐利的乳牙旁边萌出[4]。在上颌犬齿中，恒牙在乳牙的近中（前侧）萌出，而下颌恒犬齿在乳牙的舌侧（内侧）萌出[4]。

主要的鉴别诊断区分真正的滞留乳牙（没有伴随的恒牙存在）和滞留乳牙（乳牙和恒牙都存在）[5]。临床检查可能显示拥挤、恒牙位置不正或双重牙齿周围牙周病发展的证据[4]。区分滞留乳牙和多生牙需要X线确认[1]。

一旦恒牙开始在同一牙槽中萌出，就应立即拔除[6]。等待自然脱落有正畸并发症和早期牙齿脱落的风险。

### Sources
[1] Recognizing dental and oral abnormalities: https://www.dvm360.com/view/recognizing-dental-and-oral-abnormalities
[2] Diagnostic Imaging in Veterinary Dental Practice in: https://avmajournals.avma.org/view/journals/javma/260/7/javma.21.08.0375.xml
[3] Congenital and Inherited Disorders of the Digestive System in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/congenital-and-inherited-disorders-of-the-digestive-system-in-cats
[4] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
[5] The ABCs of veterinary dentistry: 'R' is for retained, primary, deciduous teeth: https://www.dvm360.com/view/abcs-veterinary-dentistry-r-retained-primary-deciduous-teeth
[6] The ABCs of veterinary dentistry: When waiting is wishful thinking: https://www.dvm360.com/view/the-abcs-of-veterinary-dentistry-when-waiting-is-wishful-thinking

## 治疗选择和手术技术

乳牙滞留的主要治疗方法是在确诊后立即拔除，以防止恒牙位置不正[1]。拔牙技术必须使用术前口腔内X线片仔细规划，以评估根部解剖结构并避免损伤未萌出的恒牙[2]。

**手术拔牙方案：**
在乳犬齿根部做对角线切口，然后使用2号骨膜分离器提起皮瓣[2]。然后使用翼尖牙挺通过在不同位置施加20-30秒的轻柔扭转力来创造牙齿活动度[3]。"三十秒法则"可防止根部断裂，同时允许牙周韧带纤维逐渐疲劳[3]。

**关键预防措施：**
对于下颌牙齿，切勿将牙挺放在舌侧表面，以避免损伤位于舌侧的恒犬齿[2]。对于上颌牙齿，拔牙力应导向颊侧，以防止根尖穿入鼻腔[3]。

**拔牙后管理：**
拔牙部位使用4-0可吸收缝线以简单间断倒结缝合[2]。疼痛管理包括围手术期镇痛药和区域神经阻滞，以及术后NSAID治疗[4]。患者在5-7天内接受软质食物饮食并避免硬质咀嚼玩具[4]。

**并发症：**
根部断裂是最常见的并发症，特别是乳牙由于其长而窄的根部和部分吸收[5]。不完全拔除可能需要手术取出根部碎片以防止持续感染[3]。

### Sources

[1] Current concepts in veterinary dentistry (Proceedings): https://www.dvm360.com/view/current-concepts-veterinary-dentistry-proceedings
[2] 'R' is for retained, primary, deciduous teeth: https://www.dvm360.com/view/abcs-veterinary-dentistry-r-retained-primary-deciduous-teeth
[3] Surgical tooth extractions (Proceedings): https://www.dvm360.com/view/surgical-tooth-extractions-proceedings
[4] Dental Corner: How to perform a nonsurgical extraction: https://www.dvm360.com/view/dental-corner-how-perform-nonsurgical-extraction
[5] Dental extractions: diagnosis and simplified therapy (Proceedings): https://www.dvm360.com/view/dental-extractions-diagnosis-and-simplified-therapy-proceedings

## 预防、预后和长期管理

现有章节内容全面涵盖了与乳牙滞留相关的预防策略、预后因素和长期并发症。根据原始资料，本节有效整合了早期检测方案与治疗结果和繁殖考虑因素。

### 早期检测和监测

兽医应在常规幼犬和幼猫预约时进行彻底的口腔检查，特别关注3-6个月恒牙萌出时期[1]。宠物主人需要接受教育，定期检查宠物的口腔，因为正畸问题可能在恒牙萌出后两周内发展[4]。对于小型和玩具品种，考虑到它们对乳牙滞留和早期牙周病的易感性，在1岁前可能需要进行主动的牙科评估[7]。

### 治疗结果和预后

当及时进行拔除时，预后良好，位置异常的恒牙经常自行矫正到正常位置[2]。然而，延迟干预会显著损害结果，特别是在小型品种犬中，影响更为严重[7]。晚期治疗通常导致永久性位置不正的牙齿，需要正畸矫正、牙冠缩短或拔除[1]。

### 长期并发症

未经治疗的乳牙滞留会造成严重并发症，包括牙周支持受损、早期牙齿脱落、拥挤导致的牙周炎，以及创伤性咬合可能导致的口鼻瘘形成[2][6]。考虑到可能的遗传因素，繁殖咨询对于防止传播给后代至关重要[1]。

### Sources
[1] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth
[2] 'R' is for retained, primary, deciduous teeth: https://www.dvm360.com/view/abcs-veterinary-dentistry-r-retained-primary-deciduous-teeth
[4] Pediatric dentistry: An overview of common problems you'll see in practice: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice
[6] Canine orthodontics: Providing healthy occlusions: https://www.dvm360.com/view/canine-orthodontics-providing-healthy-occlusions
[7] Current concepts in veterinary dentistry: https://www.dvm360.com/view/current-concepts-veterinary-dentistry-proceedings
