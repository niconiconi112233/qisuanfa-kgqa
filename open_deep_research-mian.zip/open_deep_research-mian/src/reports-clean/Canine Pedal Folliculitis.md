# 犬足部毛囊炎

犬足部毛囊炎在小动物兽医临床实践中代表着一个重要的临床挑战，影响犬的趾间和足部区域。这种炎症性疾病涉及毛囊内细菌过度生长，主要由假中间型葡萄球菌（*Staphylococcus pseudintermedius*）引起，并常伴有马拉色菌（*Malassezia*）属的继发性真菌感染。趾间的温暖潮湿环境为病原体增殖创造了理想条件，特别是在易感品种中，如斗牛犬、德国牧羊犬和金毛寻回犬。本报告探讨了足部毛囊炎的综合兽医治疗方法，涵盖基本病原体、包括疼痛性趾间结节和跛行在内的独特临床表现、利用细胞学和细菌培养的先进诊断方案、结合局部抗菌药物与全身性抗生素的循证治疗，以及必须系统排除的关键鉴别诊断，包括异位性皮炎和蠕形螨病。

## 疾病概述

犬足部毛囊炎是一种影响犬趾间和足部区域毛囊的细菌性炎症性疾病。该病症表现为一种局限性脓皮病，以毛囊感染和随后的组织炎症为特征（默克兽医手册，2024年）。

**定义**：足部毛囊炎涉及足部毛囊内正常常驻菌群的细菌过度生长，而非由真正致病性生物体引起的感染。该病症通常继发于损害皮肤天然屏障功能的潜在易感因素（默克兽医手册，2024年）。

**流行病学背景**：趾间位置由于温暖潮湿的条件创造了细菌增殖的理想微环境，这些条件促进病原体粘附于角质形成细胞并随后侵入毛囊（默克兽医手册，2024年）。某些品种表现出更高的易感性，包括拳师犬、斗牛犬、德国牧羊犬、金毛寻回犬、拉布拉多寻回犬和中国沙皮犬，这是由于其结构特征，如短而硬的趾间毛发和突出的蹼，这些特征易导致毛囊创伤（默克兽医手册，2024年；DVM 360，2024年）。

该病症通常作为潜在疾病的继发并发症发展，包括过敏（异位性皮炎、食物超敏反应）、内分泌病（甲状腺功能减退、肾上腺皮质功能亢进）、角化障碍、毛囊发育不良和破坏正常皮肤屏障功能的外寄生虫感染（默克兽医手册，2024年）。

## 常见病原体

犬足部毛囊炎主要由细菌病原体引起，其中**假中间型葡萄球菌（*Staphylococcus pseudintermedius*）**是主要病原体[1][2]。这种凝固酶阳性葡萄球菌产生β-内酰胺酶，使其对青霉素、阿莫西林和氨苄西林产生耐药性[2]。该病症通常由正常常驻菌群的细菌过度生长引起，而非由真正致病性生物体感染所致[1]。

继发性细菌病原体可能包括凝固酶阴性葡萄球菌、链球菌以及大肠杆菌（*Escherichia coli*）、奇异变形杆菌（*Proteus mirabilis*）和假单胞菌（*Pseudomonas*）属等革兰氏阴性生物体[2]。施氏葡萄球菌（*Staphylococcus schleiferi*），包括凝固酶阳性和凝固酶阴性变种，已成为一种具有重要潜在人畜共患病意义的病原体[3]。

真菌合并感染经常发生，特别是与马拉色菌（*Malassezia*）属的感染。这些嗜脂性酵母是皮肤正常共生菌，但在温暖潮湿的趾间环境中可能过度生长[6]。马拉色菌皮炎常与细菌性毛囊炎同时出现，这是由于表面葡萄球菌生物体与酵母之间存在共生关系[6]。

趾间位置创造了病原体增殖的理想微环境。趾间的温暖潮湿条件促进细菌粘附于角质形成细胞并随后侵入毛囊[2]。任何破坏正常皮肤屏障功能的潜在疾病，包括过敏、内分泌病或创伤，都易导致继发性和真菌过度生长[2][6]。

### Sources

[1] Topical therapy for canine pyoderma: what is new?: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0001.xml
[2] Pyoderma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[3] DVM 360 Diagnosing and treating bacterial pyoderma in dogs: https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[4] Topical therapy for canine pyoderma: what is new? - PDF: https://avmajournals.avma.org/downloadpdf/view/journals/javma/261/S1/javma.23.01.0001.pdf
[5] Antimicrobial agents in small animal dermatology: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0023.xml
[6] The latest in diagnosis and management of Malassezia: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis

## 临床症状和体征

犬足部毛囊炎表现出影响趾间和足部区域的独特临床表现。最常见的体征包括**趾间红斑、脱毛和疼痛性结节**[1]。这些结节通常表现为直径1-2厘米的局灶性或多灶性病变，呈红紫色、有光泽且波动感[2]。

**主要症状**包括肿胀、因过度舔舐导致的唾液染色和色素沉着[1]。病变在触诊时可能破裂，渗出血液或脓性物质[2]。犬经常表现出**明显的跛行和疼痛**，特别是不愿在患肢上承重[2]。

**继发性表现**由自我创伤引起，包括脓皮病、出血性大疱、趾间皮肤增厚、引流窦道和溃疡[1]。足部背侧最常受影响，但腹侧也可能受累[2]。

**品种特异性模式**显示在拳师犬、斗牛犬、德国牧羊犬、金毛寻回犬、拉布拉多寻回犬和中国沙皮犬中患病率增加[1][2]。这些品种的结构特征，包括短而硬的趾间毛发和突出的蹼，使它们易患毛囊创伤和随后的感染[2]。

**非典型表现**可能包括慢性复发性病变、多灶性受累以及与葡萄球菌或马拉色菌属的继发感染并存，这可能使临床情况复杂化[2]。

### Sources

[1] Differential diagnoses for canine pododermatitis: https://www.dvm360.com/view/differential-diagnoses-canine-pododermatitis-proceedings

[2] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs

## 诊断方法

现有的犬足部毛囊炎诊断方法需要补充额外的先进检测方法，以确保准确诊断和潜在疾病识别。当怀疑皮肤癣菌病时，应进行伍德灯检查，因为某些皮肤癣菌种类表现出特征性荧光模式[1]。然而，需要注意的是，许多皮肤癣菌种类不发出荧光，这使得该检测范围有限。

在慢性或严重病例中，可能需要先进的影像学技术。X线评估有助于评估潜在的骨骼受累或异物存在，特别是当怀疑深部感染或骨髓炎时[9]。在慢性炎症可能影响更深部结构的趾间毛囊炎病例中，这一点尤其重要。

通过穿刺活检进行的组织病理学检查在疑难病例中提供确定性诊断，并有助于将足部毛囊炎与其他疾病如肿瘤或自身免疫性疾病区分开来[3][7]。应从活动性病变边缘采集组织样本以获得最佳诊断效果。

拔毛检查代表另一种诊断工具，对于检测蠕形螨特别有价值，由于脓性物质遮盖样本，这些螨虫在皮肤刮片中可能不易被发现[6]。当机械创伤和继发感染使临床情况复杂化时，该技术尤其有用。

### Sources
[1] MSD Veterinary Manual Fungal Infections in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/fungal-infections-in-dogs
[2] DVM 360 Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[3] Merck Veterinary Manual Pyoderma in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[4] Journal of the American Veterinary Medical Association Pathology in Practice in: Journal of the American Veterinary Medical Association Volume 259 Issue S2 (2022): https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.01.0045.xml
[5] DVM 360 Just Ask the Expert: How do you manage canine chin acne?: https://www.dvm360.com/view/just-ask-expert-how-do-you-manage-canine-chin-acne
[6] Interdigital furunculosis: medical and surgical options - dvm360 Abscesses Between the Toes (Interdigital Furunculosis) in Dogs Clinical and histopathologic features SMALL ANIMALS of ... Pathology in Practice in: Journal of the American Veterinary ... What Is Your Diagnosis? in: Journal of the American ... - AVMA: https://www.dvm360.com/view/interdigital-furunculosis-medical-and-surgical-options
[7] Interdigital Furunculosis in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs
[8] Abscesses Between the Toes (Interdigital Furunculosis) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/abscesses-between-the-toes-interdigital-furunculosis-in-dogs
[9] What Is Your Diagnosis? in: Journal of the American ... - AVMA: https://avmajournals.avma.org/view/journals/javma/239/4/javma.239.4.431.xml
[10] Pathology in Practice in: Journal of the American Veterinary ...: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.01.0046.xml

## 治疗选择

犬足部毛囊炎需要全面的多模式方法，针对根本原因和继发性细菌感染。循证治疗方案结合局部抗菌药物、全身性抗生素、必要时使用抗真菌治疗以及管理潜在过敏性疾病。

**局部治疗**是治疗的基石。使用氯己定（2%与2%咪康唑洗发水结合）进行每日抗菌足浴可提供必要的卫生维护[1][4]。特别推荐氯己定-咪康唑复合洗发水产品，因为它们具有双重抗菌和抗真菌特性[4]。新霉素-多粘菌素或莫匹罗星软膏等局部抗菌药物可应用于局限性病变[4]。

**全身性抗生素治疗**对于多灶性病变至关重要，通常需要至少4-6周的延长疗程[4]。根据细菌培养和药敏试验选择头孢菌素或其他抗菌药物是首选[4]。己酮可可碱可通过改善毛囊灌注来增强抗生素疗效并减少炎症[3]。

**抗真菌治疗**针对并发的马拉色菌过度生长，使用酮康唑（5 mg/kg口服每日）或伊曲康唑（小型犬5 mg/kg口服每日）[4]。

**过敏管理**对于过敏病例至关重要。全身性糖皮质激素和环孢素通常对控制显著炎症是必要的，因为lokimetmab和oclacitinib在慢性病例中常常无效[3]。当适应时应实施环境和饮食过敏方案。

**手术干预**采用Duclos方法的CO2激光消融，可能需要用于药物治疗失败的机械性慢性病例[3]。

### Sources
[1] Canine and feline pemphigus foliaceus: Improving your chances: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome
[2] Differential diagnoses for canine pododermatitis: https://www.dvm360.com/view/differential-diagnoses-canine-pododermatitis-proceedings
[3] Interdigital furunculosis: medical and surgical options: https://www.dvm360.com/view/interdigital-furunculosis-medical-and-surgical-options
[4] Interdigital Furunculosis in Dogs - Integumentary System: https://www.merckvetmanual.com/integumentary-system/interdigital-furunculosis/interdigital-furunculosis-in-dogs

## 预防措施和鉴别诊断

有效预防犬足部毛囊炎需要全面的环境管理和易感因素控制。**皮肤上的温暖潮湿区域**，如趾间空间，为细菌过度生长创造了理想条件，需要针对性干预[1]。

预防策略侧重于保持干燥条件和解决潜在诱因。**最常见的潜在诱因**包括过敏（异位性皮炎、食物过敏和跳蚤叮咬过敏）、内分泌病（甲状腺功能减退、肾上腺皮质功能亢进）、角化障碍、毛囊发育不良和外寄生虫[1]。定期梳理和避免长时间暴露于潮湿环境是必要的预防措施。

关键鉴别诊断需要系统评估。**异位性皮炎**通常影响足部、面部、耳朵和屈曲面，通常在6个月至3岁之间发展，具有品种易感性的特征[2]。**食物超敏反应**表现为非季节性瘙痒，可能对皮质类固醇有反应也可能无反应，常伴有胃肠道症状[2]。

**皮肤癣菌病**必须通过毛发和鳞屑直接检查或真菌培养排除，因为感染毛发比正常毛发更粗，在伍德灯检查下可能呈苹果绿色荧光[1]。**蠕形螨病**应始终考虑，因为它可能表现为仅限于足部或广泛分布的病变[2]。

通过改善通风、降低湿度和消除慢性湿气来源进行环境控制有助于预防细菌过度生长。有效的跳蚤控制计划至关重要，因为**跳蚤过敏性皮炎是犬猫最常见的过敏性皮肤病**[3]。

### Sources
[1] Pyoderma in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[2] Differential diagnoses for canine pododermatitis (Proceedings): https://www.dvm360.com/view/differential-diagnoses-canine-pododermatitis-proceedings
[3] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
