# 伴侣动物髋臼骨折

髋臼骨折是影响犬猫髋臼的严重创伤性损伤，通常由高冲击力的车辆事故引起。这些复杂的骨盆骨折由于严重的跛行、疼痛以及可能导致骨关节炎和神经功能缺损等长期并发症，需要立即进行兽医干预。本综合报告探讨了髋臼骨折的多方面性质，从初始创伤表现到先进的手术重建技术。涵盖的关键领域包括可能影响愈合的继发性细菌感染、以完全不负重跛行为特征的临床表现、强调放射学和CT评估的诊断成像方案，以及从保守治疗到复杂钢板固定的治疗选择。报告还讨论了专注于减少创伤的预防策略以及包括髋关节脱位和股骨头骨骺骨折在内的鉴别诊断考虑因素。

## 预后和临床结局

髋臼骨折的结局因骨折复杂性、治疗方法和患者因素而异。手术干预可产生85%的成功率，优于保守治疗，特别是对于后三分之一骨折，非手术治疗 consistently 导致中度至重度退行性关节疾病的不良结局。年龄显著影响预后--年轻动物表现出更好的愈合能力，但40%的8个月至4岁犬已显示放射学骨关节炎。继发性细菌感染，主要是葡萄球菌属，可使50-60%的病例复杂化，尤其是在金属植入物放置时。

| 因素 | 良好预后 | 不良预后 |
|------|----------|----------|
| 治疗 | 4-5天内手术稳定 | 保守治疗，延迟干预 |
| 年龄 | 具有良好愈合能力的年轻动物 | 患有关节疾病的成年动物 |
| 并发症 | 最小的并发损伤 | 神经功能缺损，泌尿道创伤 |

在肌肉萎缩发生前进行早期手术干预可最大化功能恢复，而延迟治疗会增加再脱位风险和长期退行性变化，强调了及时诊断和适当治疗选择的关键重要性。

## 常见病原体

虽然髋臼骨折是创伤性损伤而非传染性疾病，但继发性细菌感染可能使骨折部位复杂化。骨髓炎是骨科创伤后最重要的感染性并发症。

**葡萄球菌属**是骨科感染中最常见的细菌病原体，占50-60%的病例[1]。金黄色葡萄球菌和假中间葡萄球菌经常被分离出来，许多菌株产生β-内酰胺酶，赋予其对青霉素的抗性[3]。耐甲氧西林菌株（MRSA和MRSP）日益常见[3]。

**其他常见细菌病原体**包括链球菌属、大肠杆菌、变形杆菌、克雷伯菌、假单胞菌和巴斯德菌属[3]。在咬伤相关的骨折中，厌氧菌如放线菌属、梭菌属、消化链球菌属、拟杆菌属和梭杆菌属可能与巴斯德菌属一起参与[3]。

继发性感染通常发生在物理屏障受损或免疫抑制的动物中。这种情况最常与细菌感染相关，尽管真菌疾病也可能引起骨髓炎[1][2]。促成因素包括骨骼供血不足、创伤、炎症、骨损伤和传染性病原体的血源性传播[1][2]。

金属植入物带来特殊风险，因为细菌可以在植入物表面形成保护性生物膜层，使治疗具有挑战性[3]。

### Sources
[1] Bone Disorders in Cats - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/bone-joint-and-muscle-disorders-of-cats/bone-disorders-in-cats
[2] Bone Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs
[3] Managing orthopedic infections (Proceedings): https://www.dvm360.com/view/managing-orthopedic-infections-proceedings

## 临床症状和体征

髋臼骨折表现为受影响后肢特征性的急性发作严重跛行，大多数患者表现出完全不负重状态[1]。髋关节操作时的疼痛是最一致的临床发现，患者在髋关节伸展、外展和活动范围测试期间表现出明显不适[1][2]。

体格检查显示关节肿胀、积液，以及由于股骨背侧移位导致的肢体缩短外观[1]。触诊发现包括骨盆轮廓不对称、骨折部位捻发音，以及髋关节操作期间的明显不稳定性[2]。典型表现包括股骨内收和肢体外旋[3]。

神经并发症常伴随髋臼骨折，坐骨神经和股神经缺损表现为内侧和外侧趾部皮肤感觉丧失[2]。泌尿道损伤发生在超过三分之一的骨盆骨折病例中，初期可能保持临床无症状[2]。在高冲击创伤后，影响膝关节和跗关节的并发骨科损伤常伴随髋臼骨折[2]。

直肠检查应始终进行以评估骨盆通道狭窄和检测并发直肠损伤[2]。临床表现通常涵盖多个创伤系统，在处理骨科损伤前需要全面评估[2]。负重能力从部分到完全不负重不等，取决于骨折严重程度和相关损伤[2]。

品种特异性表现不常见，但车辆创伤后的年轻犬猫是典型人群[2]。与其他一些骨科疾病不同，髋臼骨折没有明显的品种易感性[2]。

### Sources

[1] Merck Veterinary Manual Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[2] Assessment and management of pelvic fractures in dogs and cats (Proceedings): https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[3] Developmental orthopedic disease: a clinical approach: https://www.dvm360.com/view/developmental-orthopedic-disease-a-clinical-approach

## 诊断方法

诊断髋臼骨折需要结合临床检查、放射学评估和先进成像模式的系统方法[1][5]。体格检查应包括骨盆对称性评估、患者站立能力评估和骶髂关节不稳定性测试[6]。直肠检查对于评估直肠穿孔或骨盆通道狭窄至关重要[6]。

骨盆正交放射线照片是主要的诊断工具，确认骨折位置、移位方向和关节形态[5]。腹背位和侧位视图通常足够，但正确的患者定位至关重要，因为轻度倾斜定位可能影响诊断准确性[1]。横断面成像对于检查髋臼和骶骨可能特别有帮助[6]。

当需要精确测量时，应考虑计算机断层扫描，特别是对于几何形状异常的骨折[2]。CT提供复杂髋臼骨折的优越可视化，并有助于手术规划。放射线照片应包括骨折部位上下方的关节，并在骨骼水平放置放大标记用于手术规划[10]。

并发损伤的评估至关重要，因为骨盆骨折经常涉及软组织创伤，包括泌尿道损伤（报道超过三分之一病例）、神经功能缺损和血管损伤[6][7]。完整的神经系统检查应评估周围神经功能，特别是坐骨神经和股神经的完整性[9]。

### Sources

[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/256/9/javma.256.9.977.xml
[2] Radiographs acquired before total hip replacement in dogs: https://avmajournals.avma.org/view/journals/ajvr/86/7/ajvr.25.02.0045.pdf
[3] Read this before performing your next veterinary orthopedic exam: https://www.dvm360.com/view/read-this-before-performing-your-next-veterinary-orthopedic-exam
[4] Acute canine coxofemoral disease and: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0272/javma.25.04.0272.xml
[5] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[6] Assessment and management of pelvic fractures in dogs and cats: https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[7] DVM 360 Pelvic fractures and soft tissue trauma: https://www.dvm360.com/view/pelvic-fractures-and-soft-tissue-trauma-proceedings
[8] DVM 360 Fracture Management Program: https://www.dvm360.com/view/fracture-management-program-level-1-2
[9] Merck Veterinary Manual Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[10] DVM 360 Managing open fractures: https://www.dvm360.com/view/managing-open-fractures-proceedings

## 治疗选择

现有内容为髋臼骨折治疗方案提供了极好的基础。在这个全面概述的基础上，额外的考虑包括先进的稳定技术和多模式康复方法。

体重管理在治疗成功中起着关键作用，肥胖显著影响骨科结局[2]。超重动物需要更长的愈合时间并面临增加的并发症风险，使体重减轻成为髋臼骨折治疗计划的重要组成部分。

新型可生物降解植入物技术在某些应用中显示出前景，尽管传统金属固定仍是髋臼重建的标准[7]。默克兽医手册强调，骨折治疗通常使用骨板、螺钉、骨科线和针作为基本固定方法[6]。

对于复杂髋臼骨折，替代方法包括用于骶髂关节稳定的腹侧腹部技术，在选定的病例中可能提供增强的可视化和减少手术发病率[4]。活动限制协议必须基于物种特异性考虑进行个体化，因为与其他伴侣动物相比，猫和犬可能需要不同的限制策略。

术后监测包括定期进行放射学评估，以评估植入物位置和骨折愈合进展。在适当限制内早期活动有助于防止肌肉萎缩，同时保护修复部位在关键愈合阶段。

### Sources

[2] Obesity and orthopedic disease: a relationship to remember: https://www.dvm360.com/view/obesity-and-orthopedic-disease-relationship-remember
[4] American Journal of Veterinary Research Ventral abdominal approach for screw fixation of sacroiliac luxation in cadavers of cats and dogs: https://avmajournals.avma.org/view/journals/ajvr/69/4/ajvr.69.4.542.xml
[6] Merck Veterinary Manual Table: Bone fracture treatments: https://www.merckvetmanual.com/multimedia/table/bone-fracture-treatments
[7] DVM 360 Research Update: Repairing fractures by using biodegradable bone plates: https://www.dvm360.com/view/research-update-repairing-fractures-using-biodegradable-bone-plates

## 预防措施

预防犬猫髋臼骨折需要多方面的方法，专注于减少创伤和主人教育。髋臼骨折的最常见原因是车辆事故，使环境安全措施至关重要[1]。

**环境安全和创伤预防**

一级预防涉及最小化导致创伤性损伤的高风险情况。适当的动物处理技术和约束方法至关重要，正如职业安全指南所强调的[1]。宠物主人应维护安全的围栏，使用适当的牵引协议，并避免让宠物靠近道路或建筑区域。

**高风险人群管理**

某些人口统计因素增加骨折风险。年轻动物由于骨骺与相邻骨骼和韧带相比较弱而特别脆弱[2]。大型和巨型品种犬由于其体型和活动水平可能面临更高风险[3]。早期绝育可能导致生长板闭合延迟和增加骨科疾病风险，表明延迟性腺切除术可能减少运动或活跃犬的损伤发生率[4]。

**主人教育**

客户教育应专注于识别髋关节问题的早期迹象和维持适当的活动水平。生长阶段的控制运动和适当营养至关重要[4]。主人应了解快速生长、过度活动和不良状况可能使动物易患肌肉骨骼损伤[3][4]。

**并发症预防**

在治疗期间，适当的病例管理包括适当的疼痛控制、必要时仔细的手术技术和结构化的康复方案。早期活动和物理治疗有助于恢复功能，同时防止继发性并发症如肌肉萎缩或关节僵硬[2][3]。

### Sources
[1] Select Occupational Hazards in Veterinary Medicine and Minimization Strategies: https://www.merckvetmanual.com/public-health/occupational-safety-and-health/select-occupational-hazards-in-veterinary-medicine-and-minimization-strategies
[2] Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[3] Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[4] Preventing injury in sporting dogs: https://www.dvm360.com/view/preventing-injury-sporting-dogs

## 鉴别诊断

几种疾病可能表现出与髋臼骨折相似的临床体征，需要仔细评估以建立准确诊断。

**髋关节脱位**是最常混淆的疾病，因为两者都表现为严重跛行和髋关节疼痛。然而，髋关节脱位在放射线照片上显示股骨头从髋臼移位，而髋臼骨折保持股骨头在破碎的髋臼内的位置[1]。体格检查显示不同的可触及标志物--在颅背侧脱位中，大转子与髂嵴和坐骨结节等距，而髋臼骨折保持正常的解剖关系[1]。

**股骨头骨骺骨折**主要发生在11个月以下的未成熟犬中，它们骨折的可能性是髋关节脱位的两倍[1]。这些骨折涉及股骨头通过生长板与颈部分离，与髋臼骨折中看到的髋臼边缘或壁破坏形成对比[3]。

**其他骨盆骨折**包括髂骨和坐骨骨折可引起类似的后肢跛行。系统的放射学评估有助于区分负重节段受累情况--髋臼骨折影响从股骨到脊柱的负重路径，而耻骨和坐骨骨折通常不会[6]。

**髋关节发育不良**表现为慢性进行性跛行，而非髋臼骨折典型的急性创伤相关发作。放射学特征显示关节松弛和退行性变化，而非急性骨折线[5]。创伤性和病理性骨折之间的区别因素在于病史--创伤性髋臼骨折 follows 显著的力应用，而病理性骨折可能在患病骨骼中因轻微创伤而发生[3]。

### Sources

[1] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[2] Joint Trauma in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[3] Assessment and management of pelvic fractures in dogs and cats (Proceedings): https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[4] Canine hip dysplasia (Proceedings): https://www.dvm360.com/view/canine-hip-dysplasia-proceedings

## 预后

犬猫髋臼骨折的预后因骨折类型、治疗方法、患者年龄和并发损伤而有显著差异[1]。对于全髋关节置换术（THA）等髋关节手术，95%的病例获得良好至优异的无痛功能[1]。潜在并发症包括感染、脱位、骨折、坐骨神经功能麻痹或植入物松动[1]。

在显著肌肉萎缩发生前进行手术治疗时，结局更佳[4]。髋臼骨折切开复位和稳定后的成功率约为85%，显著高于单纯闭合复位[5]。年龄起着关键的预后作用，年轻动物通常具有更好的愈合能力和更少的退行性变化。然而，早期干预至关重要，因为大约40%的8个月至4岁犬已显示继发性骨关节炎的放射学证据[2]。

对于后三分之一髋臼骨折特别而言，非手术治疗效果不佳，犬发展为中度至重度退行性关节疾病、活动范围减少、疼痛和跛行[6]。损伤和治疗之间的时间显著影响结局，闭合复位理想情况下应在脱位后4-5天内进行，以最小化再脱位风险和并发症[3]。

长期并发症包括进行性骨关节炎发展，大多数病例预期有不同程度的退行性关节疾病[3]。研究中最常见的并发症是再脱位，使适当的手术技术和术后管理对于最佳生活质量和维持无痛活动能力至关重要。

### Sources

[1] Arthritis in cats (Proceedings): https://www.dvm360.com/view/arthritis-cats-proceedings
[2] Why is canine osteoarthritis so complex?: https://www.dvm360.com/view/why-is-canine-osteoarthritis-so-complex-
[3] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[4] Canine hip dysplasia (Proceedings): https://www.dvm360.com/view/canine-hip-dysplasia-proceedings
[5] Hip luxation (Proceedings): https://www.dvm360.com/view/hip-luxation-proceedings
[6] Pelvic fractures and soft tissue trauma (Proceedings): https://www.dvm360.com/view/pelvic-fractures-and-soft-tissue-trauma-proceedings
