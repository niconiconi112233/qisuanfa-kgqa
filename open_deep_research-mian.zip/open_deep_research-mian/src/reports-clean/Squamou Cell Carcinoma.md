# 伴侣动物中的鳞状细胞癌

鳞状细胞癌是影响伴侣动物最重要的恶性肿瘤之一，在猫中尤为常见，构成最常见的口腔肿瘤。这种侵袭性上皮癌因其侵袭性、不良预后和复杂的治疗要求，在兽医肿瘤学中提出了独特的挑战。该病主要影响中老年动物，阳光暴露和烟草烟雾等环境因素在疾病发展中起着关键作用。本综合分析探讨了狗和猫不同解剖部位SCC的发病机制、临床表现、诊断方法、治疗方式和预后因素，为有效临床管理和改善患者结果提供了重要见解。

## 疾病概述

鳞状细胞癌（SCC）是一种恶性上皮肿瘤，是猫最常见的口腔肿瘤，占所有猫口腔肿瘤的60-80%[1]。在狗中，SCC占口腔恶性肿瘤的17-25%，是仅次于黑色素瘤的第二常见类型[2]。这种侵袭性癌最常影响牙龈组织和舌头，但也可发生在腭、咽、扁桃体和舌下区域[1][3]。

SCC主要影响中老年猫，诊断时中位年龄为11-13岁[1]。在狗中，诊断时的中位年龄为9.66岁，鳞状细胞癌占恶性口腔肿瘤的21%[4]。该病在猫中没有明显的品种易感性，尽管一些研究表明不同品种的部位分布存在轻微差异。在狗中，大型犬更常受影响，拉布拉多寻回犬和金毛寻回犬分别占鼻平面SCC病例的37%和24%[5]。

环境因素在疾病发展中起着重要作用。暴露于环境烟草烟雾与猫口腔SCC风险增加密切相关[1]。其他风险因素包括佩戴跳蚤项圈、高罐头食品摄入和食用金枪鱼罐头[1]。该病的特点是具有侵袭性局部浸润和远处转移潜力，尽管大多数猫死于局部疾病进展而非转移扩散[1]。

### Sources

[1] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[2] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[3] Oral squamous cell carcinoma in cats: https://www.dvm360.com/view/oral-squamous-cell-carcinoma-cats
[4] Understanding canine oral neoplasia - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.xml
[5] Outcomes associated with local treatment of nasal planum squamous cell carcinoma in dogs: 89 cases (2003-2020): https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0642.xml

## 常见病原体

虽然鳞状细胞癌（SCC）主要是肿瘤性疾病而非感染性疾病，但特定病原体在致癌过程中起着重要作用。乳头瘤病毒是与伴侣动物SCC发展相关的最重要感染因子[1]。

在狗中，乳头瘤病毒感染通常表现为良性口腔乳头状瘤，很少进展为侵袭性鳞状细胞癌[2]。病毒转化途径涉及慢性刺激和遗传改变，可随时间导致恶性变化。然而，全面的病毒组测序研究表明，乳头瘤病毒与猫口腔鳞状细胞癌的关联不常见，表明物种间存在不同的致病机制[3]。

猫表现出与乳头瘤病毒的独特关系，感染最常表现为多中心性鳞状细胞癌[2]。猫乳头瘤病毒感染也可引起皮肤鳞状细胞癌和基底细胞癌[2]。此外，一种称为猫多中心性原位鳞状细胞癌（鲍文病）的特殊形式已被明确与乳头瘤病毒感染相关。

环境致癌物代表另一个主要致病类别。化学致癌物、电离辐射和慢性暴露于香烟烟雾中的颗粒致癌物已被确定为重要风险因素[4]。太阳辐射暴露尤为重要，在色素沉着不良的皮肤区域引起DNA损伤，可从日光性角化病进展为侵袭性SCC。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.20.12.0688.xml
[2] Merck Veterinary Manual Oral Papillomas: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
[3] PubMed Central Virome Sequencing: https://pmc.ncbi.nlm.nih.gov/articles/PMC7117531/
[4] Merck Veterinary Manual Tumors of the Skin: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 临床症状和体征

鳞状细胞癌根据解剖位置表现出不同的临床表现。口腔SCC是猫最常见的恶性口腔肿瘤，通常引起口臭、不愿进食、流涎和体重减轻[1]。最常见部位是舌下区域，表现为不规则、溃疡、增殖性肿块[2]。

猫可能因下颌骨受累而出现下颌肿大外观，牙龈病变常侵犯下方骨骼，导致牙齿松动和严重骨质溶解[2]。在狗中，口腔SCC通常表现为牙龈、颊粘膜或唇表面的不规则、隆起、花椰菜样肿块[1]。

狗的鼻平面SCC表现为鼻出血、打喷嚏和鼻平面溃疡或肿胀[3]。皮肤形式可能表现为不愈合的溃疡或隆起病变，特别是在阳光暴露区域。

随着肿瘤增大并侵犯周围组织，临床症状会进展。当肿瘤超出初始部位时会发生面部肿胀。区域淋巴结（腮腺、下颌骨、内侧咽后）通常在口腔肿瘤肉眼可见之前就已肿大[1]。

这些肿瘤性病变具有侵袭性，常广泛涉及下方骨骼。粘膜溃疡、坏死和严重化脓性炎症常伴随口腔病变[2]。早期识别这些体征对诊断和分期至关重要。

### Sources
[1] Merck Veterinary Manual Oral Tumors in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[3] Squamous cell carcinoma of the canine nasal planum: eight cases (1988-1994): https://meridian.allenpress.com/jaaha/article-abstract/31/5/373/174840/Squamous-cell-carcinoma-of-the-canine-nasal-planum

## 诊断方法

SCC的临床诊断需要多模式方法，结合临床评估、先进成像和组织取样[1]。最可靠的诊断方法仍然是深部切开活检后的组织病理学检查，因为由于伴随的增生和化脓性炎症，浅表样本可能无法确诊[2]。

**临床表现评估**

肿瘤和区域淋巴结的视诊和触诊构成诊断评估的基础[1]。体格检查应记录肿瘤大小、位置和质地，注意病变是否向内延伸或跨越解剖边界[3]。临床分期需要彻底评估，包括区域淋巴结触诊和远处转移评估[1]。

**实验室方法**

细针抽吸提供快速细胞学诊断，可区分肿瘤类别（癌、肉瘤、圆形细胞）[4]。然而，一些具有不易染色颗粒的SCC可能表现为上皮样，需要组织学确认[5]。确诊需要深部组织活检和组织病理学检查，对于从牙齿松动区域获取组织尤为重要[2]。

**成像方式**

诊断成像包括用于初步评估的标准X光片和用于分期的先进横断面成像[1,6]。计算机断层扫描提供骨骼受累和骨质溶解变化的优越可视化，与传统超声相比提供准确的肿瘤测量[6,7]。CT对于手术计划和放射治疗靶标特别有价值，因为传统X光片可能不足以评估疾病范围[6]。三视图胸部X光片在分期期间检测肺转移仍然必不可少[3]。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals

[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings

[3] Outcomes associated with local treatment of nasal planum ...: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0642.pdf

[4] Diagnosing and Treating Cancer: https://www.dvm360.com/view/diagnosing-and-treating-cancer

[5] Cutaneous lumps and bumps: The good, the bad and ...: https://www.dvm360.com/view/cutaneous-lumps-and-bumps-good-bad-and-ugly-proceedings

[6] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors

[7] Clinical Rounds: Transitional cell carcinoma: https://www.dvm360.com/view/clinical-rounds-transitional-cell-carcinoma

## 治疗选择

狗和猫的鳞状细胞癌治疗涉及多种治疗方法，手术是局部控制的标准治疗方法。手术切除仍然是一线治疗，尽管可能存在外观改变，但提供最大的肿瘤控制机会[2]。在一项多机构研究中，71%的狗仅接受手术切除作为局部治疗，93%的病例尝试广泛切除[2]。

下颌骨切除术和上颌骨切除术常需要完全切除肿瘤。尽管这些手术具有侵袭性，许多狗恢复良好并恢复正常口腔功能，包括抓取、咀嚼和饮水[6]。部分下颌骨切除术和上颌骨切除术对外观影响最小，取决于疾病部位和范围[6]。

然而，在猫中，这些手术风险更高。下颌骨切除术和上颌骨切除术可能对生活质量产生负面影响并导致危及生命的发病率，包括无法进食[3]。在猫进行侵袭性口腔手术后应放置肠内喂养管以提供术后支持[3]。

放射治疗是重要的治疗方式，可作为确定性治疗或辅助治疗。使用大剂量每周分次的姑息性放射治疗有效治疗疼痛性肿瘤[4]。对于猫口腔SCC，放射治疗方案包括姑息性RT、确定性分次RT和立体定向RT，尽管中位生存时间仍然很短，为2-3个月[5]。

全身化疗补充局部治疗，30%的狗接受辅助方案[2]。常用药物包括卡铂、托塞尼布和环磷酰胺[2]。非甾体抗炎药经常被处方，57%的狗接受这些药物用于镇痛和潜在抗肿瘤作用[2]。

### Sources
[1] Managing canine oral tumors: https://www.dvm360.com/view/managing-canine-oral-tumors
[2] Outcomes associated with local treatment of nasal planum: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0642.xml
[3] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[4] Managing chronic cancer pain (Proceedings): https://www.dvm360.com/view/managing-chronic-cancer-pain-proceedings
[5] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[6] Managing canine oral tumors: https://www.dvm360.com/view/managing-canine-oral-tumors

## 预防措施

狗和猫鳞状细胞癌（SCC）的预防策略主要集中在风险因素修改和早期检测方案上，因为这种癌症类型没有特定的疫苗。

**阳光暴露预防**
日光性皮炎是SCC发展最重要的可预防风险因素。主要预防措施包括在紫外线辐射高峰时段（上午9点至下午3点）将宠物留在室内以限制阳光暴露[1]。对于不可避免的阳光暴露，应每天两次在风险区域频繁涂抹防水、高SPF（SPF >15）的防晒霜，以防止UVA和UVB射线[1]。T恤或专业防晒服等防护服装可为易感宠物提供额外覆盖[1]。

**品种特异性风险意识**
短毛品种中的白毛和非色素沉着皮肤区域需要特别关注，包括比特犬、斯塔福德郡斗牛犬、牛头犬、拳师犬和灵缇犬[1]。主人应将预防措施集中在脆弱区域，包括侧腹、腹股沟区域、腋窝区域和背部鼻部[1]。

**早期检测方案**
在常规兽医就诊和牙科手术期间定期口腔检查为早期SCC检测提供了重要机会[4]。兽医应教育主人识别早期临床症状，包括口腔肿块、口臭、吞咽困难或过度流涎，强调及时评估显著改善治疗结果[4]。

### Sources

[1] Diagnosis and treatment of solar dermatitis in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-solar-dermatitis-dogs
[2] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview

## 鉴别诊断

口腔鳞状细胞癌必须与具有重叠临床表现的几种疾病进行鉴别。在猫中，SCC是最常见的口腔恶性肿瘤，鉴别诊断包括牙科疾病、其他恶性肿瘤、良性异常和感染性疾病[1]。

主要恶性鉴别包括纤维肉瘤（占猫口腔肿瘤的10-20%）、黑色素瘤、淋巴瘤和骨肉瘤[2]。在狗中，主要鉴别诊断是黑色素瘤（占狗口腔恶性肿瘤的30-40%）、纤维肉瘤（8-25%）和其他肉瘤[3]。良性鉴别包括牙源性外周纤维瘤、牙龈增生和嗜酸性肉芽肿[1]。

重要的区分因素包括肿瘤位置和行为模式。SCC通常影响牙龈组织并表现出局部侵袭性浸润和骨破坏，而黑色素瘤通常表现为色素性肿块并具有高转移潜力[3][4]。纤维肉瘤通常形成坚实、增殖性肿块，与SCC相比转移率较低[2]。

仅靠临床检查无法区分良恶性病变，研究表明50%的下颌骨肿胀是良性的（主要是牙科疾病继发的骨髓炎）[1]。包括隐球菌病、芽生菌病和放线菌病在内的感染原因也必须考虑[1]。通过切开活检进行组织病理学检查对确诊仍然至关重要，因为X光和临床发现无法可靠区分肿瘤类型[1][2]。

### Sources
[1] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[3] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[4] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs

## 预后

鳞状细胞癌的预后根据肿瘤位置、组织学亚型和采用的治疗方式而有显著差异[1][2][3]。

**基于位置的结果：** 肿瘤位置是关键的预后因素。狗的鼻平面SCC通过积极局部治疗（特别是手术切除）显示出良好结果[1]。然而，鼻腔SCC预后较差，非角化性鳞状细胞癌使用钴-60放射治疗仅达到165天的中位生存时间[2]。口腔SCC预后因解剖部位而异，扁桃体形式因早期转移而预后最差[3]。

**物种特异性预后：** 患有包括SCC在内的侵袭性癌的狗通常生存时间较短（中位7.2个月），相比侵袭性较低的癌（11.9个月）或肉瘤（24.1个月）[2]。在猫中，口腔SCC是最常见的恶性口腔肿瘤，预后极差 - 中位生存时间为44天，一年生存率仅为9.5%[4][5]。大多数猫死于局部疾病进展而非转移[4]。

**治疗反应：** 尽管猫的加速放射治疗方案在八例中有五例显示完全反应，但中位生存时间仅为86天[6]。猫口腔SCC在各种治疗方式中均显示出持续不良结果，大多数猫经历快速局部疾病进展[5][6]。

### Sources
[1] Outcomes associated with local treatment of nasal planum: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0642.pdf
[2] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors
[3] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[4] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[5] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[6] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
