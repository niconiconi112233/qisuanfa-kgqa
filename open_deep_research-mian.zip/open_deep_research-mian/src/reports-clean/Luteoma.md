# 伴侣动物黄体瘤：兽医临床指南

黄体瘤是一种罕见的良性卵巢肿瘤，起源于未绝育雌性犬猫的黄素化细胞。与传染性疾病不同，这些分泌激素的肿块通过非致病性肿瘤过程发展，使其区别于其他生殖道疾病。本综合临床指南探讨了小动物兽医实践中特有的流行病学模式、诊断挑战和治疗方案。该报告解决了关于临床表现的可获得证据有限的问题，探讨了通过卵巢子宫切除术进行手术治疗，并讨论了包括早期绝育在内的预防策略。鉴于黄体瘤在兽医文献中的罕见性，本分析综合了现有信息，同时强调了需要伴侣动物生殖肿瘤学领域进一步专业研究的知识空白。

## 疾病概述

黄体瘤是非肿瘤性的、分泌激素的卵巢肿块，起源于雌性伴侣动物中的黄素化滤泡或基质细胞[1]。这些良性病变代表黄体组织增生而非真正的肿瘤形成，使其区别于恶性卵巢肿瘤[2]。

从流行病学角度看，黄体瘤在小动物临床中相对少见，关于其在犬猫中患病率的综合数据有限[1]。它们通常发生在未绝育的性成熟雌性动物生殖激素活动增强的时期[2]。中老年未绝育母犬似乎最常受影响，尽管文献中具体的年龄分布差异很大[1]。

尚未确定犬猫黄体瘤的明确品种易感性，尽管一些报告表明某些品种可能存在过度代表的情况[1]。这些病变的罕见性使得建立明确的流行病学模式具有挑战性，因为许多病例可能未被诊断或被误诊为其他卵巢疾病[2]。

与恶性卵巢肿瘤不同，黄体瘤通常单侧发生并保持局部化，没有转移潜力[2]。其产生激素的性质可导致各种生殖和全身临床症状，因此早期识别对于适当管理非常重要[1]。

### Sources
[1] Merck Veterinary Manual Luteal Cystic Ovary Disease in Cows: https://www.merckvetmanual.com/reproductive-system/cystic-ovary-disease/luteal-cystic-ovary-disease-in-cows
[2] Merck Veterinary Manual Follicular Cysts in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/follicular-cysts-in-small-animals

## 常见病原体

黄体瘤是非感染性卵巢肿瘤，没有致病原因[1]。这些肿瘤起源于卵巢内的黄素化细胞，代表纯粹的肿瘤过程而非传染性疾病[2]。与细菌、病毒或寄生虫疾病不同，黄体瘤通过黄体组织的自发细胞转化和增殖发展。

缺乏传染性因子将黄体瘤与其他可能表现相似临床症状的卵巢病理区分开来。没有特定的微生物，包括细菌、病毒、真菌或寄生虫，是导致犬猫黄体瘤发展的原因。肿瘤性转化通过未知机制发生，不涉及致病性入侵或定植。

这种非感染性性质对于兽医从业者理解很重要，因为它意味着抗菌治疗、疫苗接种方案或隔离程序不适用于黄体瘤管理。该疾病代表卵巢基质细胞的原发性肿瘤性疾病，而非对传染性因子的继发性反应。

了解黄体瘤缺乏致病性原因有助于将其与感染性卵巢疾病区分开来，并指导适当的诊断和治疗方法，专注于肿瘤性疾病管理而非感染性疾病管理。

### Sources
[1] Pathology in Practice in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.19.09.0453.xml
[2] Ovarian remnant syndrome in dogs and cats - AVMA: https://avmajournals.avma.org/downloadpdf/view/journals/javma/236/5/javma.236.5.548.pdf

## 临床症状和体征

黄体瘤通常表现为非特异性临床症状，可模拟犬猫中的各种其他疾病。最常见的临床表现为体重减轻、厌食和全身嗜睡[1]。这些全身性体征反映了肿瘤对整体健康状况的影响。

激素相关症状是黄体瘤的标志，由于其黄体细胞起源和激素产生能力。受影响的动物可能表现出行为变化，包括不安、虚弱和偶尔的虚脱发作[1]。呼吸困难和心动过速是经常观察到的心血管体征，与肿瘤对循环系统的激素效应相关。

体格检查结果通常显示高血压为常见且重要的临床体征[1]。腹部检查期间可触及肿块的存在可能因肿瘤大小和位置而异。兽医专业人员应进行全面的体格评估，重点关注心血管参数，因为这些肿瘤可引起显著的血液动力学变化。

兽医文献中尚未明确建立黄体瘤的品种特异性模式。然而，这些肿瘤在老年动物中更频繁发生，表明存在年龄相关的易感性[1]。临床症状可能零星出现，可能与间歇性激素释放模式有关，使得在没有持续监测和全面临床评估的情况下诊断具有挑战性。

### Sources
[1] Pheochromocytomas in Animals - Endocrine System - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/neuroendocrine-tumors/pheochromocytomas-in-animals

## 诊断方法

**我无法根据提供的来源提供犬猫黄体瘤的准确诊断信息，因为没有任何来源包含关于这种特定疾病的信息。**

小动物疑似卵巢疾病的诊断方法通常涉及临床表现评估[1]。激素检测，包括孕酮监测，是犬类生殖系统疾病的有用诊断工具[1]。连续孕酮浓度测量有助于预测排卵时间和评估黄体功能[1]。

影像学技术，特别是超声检查，在评估生殖系统疾病中发挥重要作用。超声检查可以检测卵巢异常并评估生殖道状况[2]。对于疑似卵巢残余综合征，确认发情行为和检测血清孕酮浓度>2 ng/mL有助于诊断[2]。

犬卵巢肿瘤不常见，仅占所有犬肿瘤的1.04%[3]。这种罕见性可能使诊断识别和解释复杂化。然而，没有关于伴侣动物黄体瘤的特定兽医文献，我无法提供针对这种疾病的准确诊断标准、实验室参数或影像学发现。正确的诊断需要咨询兽医生殖专家并获取专门解决犬猫黄体瘤问题的同行评议文献。

### Sources
[1] Clinical Investigation of Canine Reproduction Disorders: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/clinical-investigation-of-canine-reproduction-disorders
[2] Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[3] Pathology in Practice in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.19.09.0453.xml

## 治疗选择

卵巢子宫切除术代表伴侣动物黄体瘤的主要手术干预措施[1][3]。通过卵巢子宫切除术完全切除是首选治疗方法，因为它消除了激素产生的来源并防止复发[1]。该手术涉及在全身麻醉下切除两侧卵巢和子宫，遵循生殖道手术的标准手术方案。

药物治疗在黄体瘤治疗中起支持作用。虽然没有特定的药物干预直接针对黄体瘤，但支持性护理可能包括疼痛管理和并发症监测[2]。对于伴有合并症的患者，手术干预前的术前稳定至关重要[2][5]。

术后护理遵循标准的卵巢子宫切除术方案。患者需要监测可能的并发症，包括出血，这是最常见的术后并发症[2]。疼痛管理、活动限制和切口监测是恢复护理的标准组成部分[1]。大多数患者对手术耐受良好，当由经验丰富的外科医生进行时并发症很少见[2]。

恢复通常涉及10-14天的活动限制，并在适当时间间隔拆除缝线。完全手术切除后长期预后极佳，因为黄体瘤是良性病变，一旦卵巢组织被切除就不会复发[1]。

### Sources
[1] DVM 360 Performing an ovariectomy in dogs and cats: https://www.dvm360.com/view/performing-ovariectomy-dogs-and-cats
[2] DVM 360 Preventing and managing spay/neuter complications (Proceedings): https://www.dvm360.com/view/preventing-and-managing-spayneuter-complications-proceedings
[3] Merck Veterinary Manual Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals

## 预防措施

早期绝育在预防伴侣动物黄体瘤和其他生殖系统肿瘤方面起着关键作用。6个月前绝育的猫发生乳腺肿瘤的风险降低91%，而12个月前绝育的猫风险降低86%[1]。犬从早期卵巢子宫切除术获得类似的保护益处，尽管时间必须与其他恶性肿瘤增加的风险相平衡[2]。

环境因素侧重于最小化激素暴露。外源性孕激素的给药显著增加了雌雄猫犬的肿瘤风险[1][2]。避免使用合成生殖激素进行发情抑制或其他非必要目的对预防至关重要。

繁殖管理考虑强调用于繁殖的完整动物负责任的做法。对于为繁殖而保持完整的猫犬，应定期进行乳腺检查以便早期发现[1][2]。主人必须权衡维持生殖能力的益处与显著增加的癌症风险，特别是对于乳腺肿瘤，其中80-90%的猫病例是恶性的[1]。

最终，第一次发情前进行卵巢子宫切除术仍然是预防激素依赖性生殖系统肿瘤（包括黄体瘤）的最有效措施，尽管个体品种考虑可能影响最佳时间建议[2]。

### Sources
[1] Mammary Tumors in Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[2] Mammary Tumors in Dogs - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs

## 鉴别诊断

将黄体瘤与其他卵巢肿瘤区分需要仔细评估组织病理学特征和临床表现。原发性犬卵巢肿瘤包括乳头状腺癌、乳头状腺瘤、颗粒细胞瘤、无性细胞瘤、黄体瘤和畸胎瘤[1]。

**颗粒细胞瘤**是最常见的卵巢性索间质肿瘤，可通过其特征性细胞排列与黄体瘤区分。颗粒细胞瘤通常显示具有Call-Exner小体的滤泡模式，而黄体瘤显示黄素化细胞的实性片状，具有丰富的嗜酸性胞浆和中心核。

**乳头状腺瘤和腺癌**起源于表面上皮并显示具有上皮细胞簇的明显乳头状结构，与黄体瘤的实性间质外观形成对比。这些上皮肿瘤在细胞学检查期间倾向于成簇脱落，而黄体瘤由单独分散的黄体细胞组成。

**其他鉴别考虑**包括卵巢残余综合征，可在绝育雌性中表现出发情行为，但涉及功能性卵巢组织而非肿瘤性转化[2]。炎症性疾病也可能模拟卵巢肿块，但缺乏功能性卵巢肿瘤的特征性激素效应和细胞形态学。

关键区分因素包括激素活性模式、细胞学外观和组织学结构，强调了包括细针抽吸和组织病理学检查在内的全面诊断评估的重要性，以便进行明确区分。

### Sources

[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.19.09.0453.xml
[2] Merck Veterinary Manual Ovarian Remnant Syndrome: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals

## 预后

根据提供的来源材料，我无法确定关于犬猫黄体瘤预后的特定兽医文献。这些来源包含关于流行食品、一般犬类生殖状况、卵巢残余综合征和生殖道异常的大量信息，但没有专门解决伴侣动物黄体瘤临床结果或预后因素的特定数据。

在没有获得关于犬猫黄体瘤生存率、预期临床结果或影响预后因素的兽医特定研究的情况下，无法为这种疾病建立基于证据的预后信息。可用的来源讨论了各种生殖系统疾病及其管理，但没有提供确定黄体瘤预后所需的专业肿瘤学数据。

使用专门的兽医肿瘤学数据库、同行评议的兽医期刊和专业生殖病理学资源进行进一步研究，对于建立伴侣动物黄体瘤基于证据的预后指南至关重要。在获得此类兽医特定文献之前，无法用适当的临床证据支持犬猫黄体瘤的预后陈述。

### Sources

No sources available for luteoma prognosis in veterinary patients, as the provided materials focus on human foods and general canine reproductive conditions rather than specific neoplastic conditions affecting companion animals.
