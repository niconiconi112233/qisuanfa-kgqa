# 犬蠕形螨病：兽医综合指南

犬蠕形螨病是小动物临床中最复杂的寄生虫性皮肤病之一，由通常共生的蠕形螨过度繁殖引起。这种非传染性疾病从自限性局部病变到需要积极干预的严重全身性疾病不等。该疾病的临床意义不仅限于皮肤表现，在成年发病病例中，它常作为潜在免疫抑制状态的指标。本报告探讨了犬蠕形螨病的病理生理学、诊断方法和不断发展的治疗方案，特别强调了幼犬病例中的遗传易感因素以及成年病例中并发疾病管理的关键作用。

## 疾病概述

犬蠕形螨病是一种非传染性寄生虫性皮肤病，由宿主特异性毛囊蠕形螨属螨虫过度繁殖引起[1]。大多数病例由*犬蠕形螨*引起，它是犬类正常皮肤菌群的一部分，当数量较少时通常不会引起临床疾病[2]。

根据发病年龄，该疾病分为两大类。幼年发病的蠕形螨病通常在18个月以下的犬中发展，与遗传易感性、营养不良和压力有关[2]。成年发病的蠕形螨病在身体成熟后（通常4岁以上）发生，通常与免疫抑制状态相关，包括肾上腺皮质功能亢进、甲状腺功能减退、糖尿病、肿瘤或免疫抑制治疗[2][6]。

确切的发病机制涉及可疑的遗传性免疫缺陷，伴有细胞介导免疫的功能异常[2]。虽然任何品种都可能发生蠕形螨病，但某些品种似乎易感，尽管关于特定品种易感性的报道各不相同[6]。蠕形螨在出生后72小时内通过哺乳从母犬传播给幼犬，整个生命周期都在宿主上度过[8]。

### Sources
[1] Update on Demodicosis and other mite-caused dermatoses (Proceedings): https://www.dvm360.com/view/update-demodicosis-and-other-mite-caused-dermatoses-proceedings
[2] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[6] Is your demodicosis knowledge a bit (c)rusty?: https://www.dvm360.com/view/your-demodicosis-knowledge-bit-crusty
[8] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats

## 常见病原体

犬蠕形螨病由三种已确认的蠕形螨种类引起，它们表现出不同的形态特征和栖息地偏好[1]。**犬蠕形螨**是临床上最常见的种类，主要存在于毛囊中，偶尔存在于皮脂腺中[1,4]。这种螨虫在宿主上完成25-30天的生命周期，经历四个阶段：梭形卵、六足幼虫、八足若虫和八足成虫[4,7]。

**伊氏蠕形螨**是长体型变种，在所有生命阶段比犬蠕形螨大约50%[1,4]。这些螨虫表现出对皮脂腺的偏好，通常栖息在背部区域，特别是在梗类犬中[1,2]。伊氏蠕形螨感染通常表现为脂溢性皮炎，而非典型的脱毛性病变[1,2]。

**角质蠕形螨**是短体型种类，比成年犬蠕形螨短50%[1,4]。与其他犬蠕形螨种类不同，角质蠕形螨可以存在于表皮浅层，并常引起瘙痒性病变[1,4]。目前的研究表明，所有三个种类可能代表同一生物的不同菌株，尽管在临床实践中它们的治疗方式相同[1]。

所有蠕形螨种类都是专性寄生虫，以毛囊内的细胞碎片为食，在环境中存活时间不超过一小时[7]。这些螨虫是正常犬类皮肤菌群的一部分，通过哺乳从母犬传播给后代[6,7]。

### Sources
[1] Is your demodicosis knowledge a bit (c)rusty?: https://www.dvm360.com/view/your-demodicosis-knowledge-bit-crusty
[2] "We've come so far from burned motor oil": What's new in the treatment of demodicosis (Proceedings): https://www.dvm360.com/view/weve-come-so-far-burned-motor-oil-whats-new-treatment-demodicosis-proceedings
[4] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[6] Mite Infestation (Mange, Acariasis, Scabies) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs
[7] Update on treatment of demodicosis (Proceedings): https://www.dvm360.com/view/update-treatment-demodicosis-proceedings

## 临床症状和体征

犬蠕形螨病表现出不同的临床模式，在局限性和全身性形式之间差异显著[1]。**局限性蠕形螨病**通常表现为一到五个界限清晰的脱毛、红斑和鳞屑区域，常见于一岁以下犬的眼周区域、嘴唇和前肢。局限性病例通常没有或仅有轻微瘙痒[1]。

**全身性蠕形螨病**表现更严重，伴有广泛病变，包括红斑、丘疹、脱毛、油性脂溢、水肿、色素沉着和结痂[1]。继发性细菌感染（脓皮性蠕形螨病）是常见并发症，常伴有趾间皮炎[1][3]。患有严重全身性疾病的犬可能出现全身性体征，包括全身性淋巴结病、嗜睡和发热，当发生深部脓皮症或蜂窝织炎时[1]。

**幼年发病的全身性蠕形螨病**影响18个月以下的犬，由遗传性免疫缺陷引起[2]。**成年发病的全身性蠕形螨病**发生在通常3岁以上的犬中，与潜在的免疫抑制状态相关，如肿瘤、肾上腺皮质功能亢进或甲状腺功能减退[1]。

**品种易感性**已有记录，纯种犬发生全身性蠕形螨病的风险增加。据报道，美国斯塔福德郡梗、沙皮犬、英国斗牛犬、法国斗牛犬和各种梗类犬易感[3][4]。然而，任何品种都可能发生幼年发病的蠕形螨病[4]。

原发性病变包括自发性脱毛、鳞屑、毛囊套、丘疹和粉刺[2]。短体型蠕形螨种类可能引起更瘙痒的表现[2]。耵聍性外耳炎可能伴有或不伴有其他皮肤病变[2]。

### Sources
[1] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[2] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[3] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[4] Demodicosis in 2010 (Proceedings): https://www.dvm360.com/view/demodicosis-2010-proceedings

## 诊断方法

深层皮肤刮片是犬蠕形螨病的首选诊断方法[1]。应从三到五个不同部位进行多次深层皮肤刮片，包括面部和足部，即使这些部位没有明显病变[1][7]。刮片必须足够深，以产生毛细血管出血，才能到达蠕形螨栖息的毛囊[3][7]。

正确的技术包括在刮片前挤压皮肤，以从毛囊中挤出螨虫[7]。可使用10号手术刀片或钝金属刮匙，涂抹矿物油以增强样本收集[6]。对于长毛犬，轻柔的修剪可提高样本质量[6]。

毛干镜检（拔毛检查）作为替代诊断方法，特别适用于难以刮片的面部区域和爪部[2][4][5]。使用止血钳，从受影响区域拔出至少20根毛发，在矿物油中进行显微镜检查[7]。

其他技术包括用于角质蠕形螨等浅表螨虫的胶带剥离检查，以及检查耳道分泌物以诊断蠕形螨性耳炎[7]。当病变为肉芽肿性或纤维化时，特别是在爪部，可能需要进行皮肤活检，因为常规刮片可能难以显示螨虫[7][10]。

监测需要记录每个部位的螨虫数量、存在的生命阶段以及螨虫是活的还是死的[7]。治疗成功的衡量标准是未成熟螨虫比例的减少以及最终的皮肤刮片阴性[1]。在治疗期间，每月进行多次部位的皮肤刮片检查，包括先前受影响的区域和任何新病变，是必不可少的[1]。

### Sources
[1] Hot Literature: Managing canine demodicosis: https://www.dvm360.com/view/hot-literature-managing-canine-demodicosis-practical-guidelines-all-practitioners
[2] Feline alopecia (Proceedings): https://www.dvm360.com/view/feline-alopecia-proceedings
[3] Simple diagnostic tools in veterinary dermatology: https://www.dvm360.com/view/simple-diagnostic-tools-veterinary-dermatology-proceedings
[4] A pivotal pedicure: Understanding SLO: https://www.dvm360.com/view/pivotal-pedicure-understanding-slo
[5] Dermatophyte and deep fungal infections (Proceedings): https://www.dvm360.com/view/dermatophyte-and-deep-fungal-infections-proceedings
[6] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[7] Is your demodicosis knowledge a bit (c)rusty?: https://www.dvm360.com/view/your-demodicosis-knowledge-bit-crusty
[8] The mighty mites of companion animals (Proceedings): https://www.dvm360.com/view/mighty-mites-companion-animals-proceedings
[9] Dermatology for technicians (Proceedings): https://www.dvm360.com/view/dermatology-technicians-proceedings
[10] Common mistakes in your veterinary dermatology workups: https://www.dvm360.com/view/common-mistakes-your-veterinary-dermatology-workups

## 治疗选择

犬蠕形螨病的治疗取决于疾病严重程度和患者特征。对于局限性病例，使用每周氯己定或过氧化苯甲酰香波的局部治疗通常足够[1]。

**全身性药物**

大环内酯类药物仍是全身性病例的一线治疗。伊维菌素每日口服0.4-0.6 mg/kg显示出高效，尽管剂量应逐渐增加以减少不良反应[2]。米尔贝霉素肟（每日1.0-2.0 mg/kg）为伊维菌素敏感品种提供了更安全的选择，但价格显著更高[2]。

莫昔克丁与吡虫啉的局部组合，每周一次按2.5 mg/kg莫昔克丁应用，提供了另一种有效选择[5]。多拉菌素每周皮下注射0.6 mg/kg的标签外使用已显示出良好疗效[3][4]。

最近，异噁唑啉类药物（阿福拉纳、氟雷拉纳、沙罗拉纳、洛替拉纳）已成为首选治疗方法，按标准跳蚤/蜱虫剂量每月或每12周（对于氟雷拉纳）给药[5]。

**辅助治疗**

过氧化苯甲酰香波提供必要的毛囊冲洗和抗菌作用[1][6]。并发细菌感染需要适当的全身性抗菌药物治疗至少4-6周[5]。

**监测和持续时间**

治疗持续到每月间隔获得至少两次连续阴性的皮肤刮片结果[5]。每月进行多个代表性部位的皮肤刮片监测对于评估治疗效果和指导治疗决策至关重要。

### Sources
[1] Hot Literature: Managing canine demodicosis: https://www.dvm360.com/view/hot-literature-managing-canine-demodicosis-practical-guidelines-all-practitioners
[2] Update on treatment of demodicosis (Proceedings): https://www.dvm360.com/view/update-treatment-demodicosis-proceedings
[3] "We've come so far from burned motor oil": What's new in treatment of demodicosis (Proceedings): https://www.dvm360.com/view/weve-come-so-far-burned-motor-oil-whats-new-treatment-demodicosis-proceedings
[4] What's new in dermatology (Proceedings): https://www.dvm360.com/view/whats-new-dermatology-proceedings
[5] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[6] Treatment of the big three causes of folliculitis (Proceedings): https://www.dvm360.com/view/treatment-big-three-causes-folliculitis-proceedings

## 预防措施

犬蠕形螨病的一级预防集中在繁殖实践上，因为发生全身性疾病的倾向具有很强的遗传成分[1]。患有全身性蠕形螨病的犬，即使是自愈的犬，也应从繁殖计划中剔除，以防止传播给后代[1]。此建议适用于幼年发病病例和对治疗完全反应的病例。

环境管理侧重于控制易感因素而非预防螨虫传播，因为蠕形螨是正常犬类皮肤菌群的一部分[2]。成年发病的蠕形螨病需要识别和治疗潜在的免疫抑制状态，如肾上腺皮质功能亢进、甲状腺功能减退、糖尿病或肿瘤[2]。避免免疫抑制药物，包括局部糖皮质激素，对于预防疾病发展至关重要[1]。成年发病的蠕形螨病通常在免疫抑制药物治疗后发生[6]。

## 鉴别诊断

犬蠕形螨病的主要鉴别诊断包括细菌性毛囊炎、皮肤癣菌病和过敏性皮肤病[3]。毛囊炎的最常见原因是细菌性（葡萄球菌感染）、皮肤癣菌病和蠕形螨病[7]。细菌性脓皮症表现出类似的毛囊病变，但通常对适当的抗生素治疗有反应。皮肤癣菌病可能引起类似的鳞屑和脱毛，特别是在幼犬或接受免疫抑制治疗的犬中[4]。

过敏性疾病如特应性皮炎和食物过敏可能模拟蠕形螨病，但通常表现出更强烈的瘙痒和不同的分布模式[5]。疥螨病引起严重瘙痒，病变在耳缘、肘部和跗关节--这些部位在蠕形螨病中较少受影响[5]。当瘙痒伴有鳞屑时，鉴别诊断包括姬螯螨病和皮脂腺炎[7]。区分因素包括皮肤刮片中是否存在螨虫、对抗寄生虫治疗的反应以及每种疾病特有的特征性病变模式[6]。

### Sources

[1] Update on treatment of demodicosis (Proceedings): https://www.dvm360.com/view/update-treatment-demodicosis-proceedings
[2] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[3] Canine and feline demodicosis: https://www.dvm360.com/view/canine-and-feline-demodicosis
[4] The CSI approach to pruritic pets: dermatology due diligence (Proceedings): https://www.dvm360.com/view/csi-approach-pruritic-pets-dermatology-due-diligence-proceedings
[5] Differential diagnoses for the itchy and scratchy (Proceedings): https://www.dvm360.com/view/differential-diagnoses-itchy-and-scratchy-proceedings
[6] Allergy mimickers (Proceedings): https://www.dvm360.com/view/allergy-mimickers-proceedings
[7] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings
