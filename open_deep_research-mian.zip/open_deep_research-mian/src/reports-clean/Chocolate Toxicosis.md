# 伴侣动物巧克力中毒

巧克力中毒是小动物临床中最常见的兽医急症之一，尤其影响犬类，因其不加选择的饮食习惯和容易接触巧克力产品。这种情况源于摄入巧克力中天然存在的甲基黄嘌呤--主要是可可碱和咖啡因，其毒性水平根据巧克力类型和摄入量差异巨大。严重程度从轻微的胃肠道不适到危及生命的心律失常和癫痫发作不等，因此快速评估和干预至关重要。本报告探讨了管理巧克力中毒病例所需的病理生理学、临床表现、诊断方法和治疗方案，并重点介绍了在家庭巧克力消费高峰的高风险期间的预防策略。

## 摘要

巧克力中毒是一种剂量依赖性急症，需要立即进行兽医干预，其临床结果与甲基黄嘌呤暴露水平和治疗及时性直接相关。该病情可预测地从早期胃肠道症状进展至可能致命的心血管和神经系统并发症，黑巧克力和可可粉因可可碱浓度高而构成最高风险。

| 巧克力类型 | 甲基黄嘌呤含量 | 风险等级 | 中毒剂量（约） |
|---|---|---|---|
| 可可粉 | 28.5 毫克/克 | 最高 | <10克对小型犬危险 |
| 黑巧克力/烘焙巧克力 | 15.5 毫克/克 | 高 | 20-30克对中型犬有毒 |
| 牛奶巧克力 | 2.3 毫克/克 | 中等 | 需60克以上才会中毒 |
| 白巧克力 | 0.04 毫克/克 | 极低 | 很少有毒 |

治疗成功取决于2小时内快速去污染、针对心律失常和癫痫发作的积极支持性护理，以及长达72小时的持续监测。预防仍然是最有效的策略，特别是在万圣节到复活节期间的季节性高峰期，此时家庭巧克力可用性显著增加。

## 疾病概述

巧克力中毒是伴侣动物中常见的食物中毒状况，由摄入过量含有甲基黄嘌呤的巧克力产品引起[1]。该病主要影响犬类，因其不加选择的饮食习惯和容易接触巧克力来源，尽管许多物种都易感[2]。

导致巧克力中毒的有毒物质是甲基黄嘌呤可可碱（3,7-二甲基黄嘌呤）和咖啡因（1,3,7-三甲基黄嘌呤），它们来源于*Theobroma cacao*的烘焙种子[2]。虽然巧克力中可可碱浓度是咖啡因的3-10倍，但两种成分都会导致临床毒性[2]。

巧克力中毒是一种全年性的兽医急症，在"巧克力季节"期间有明显的季节性高峰，从万圣节开始，持续到圣诞节和情人节，结束于复活节[4]。该病可能导致危及生命的心律失常和中枢神经系统功能障碍[2]。

对于牛奶巧克力，每公斤体重约62克（每磅体重1盎司）被认为对犬类可能致命[2]。中毒剂量根据摄入的巧克力类型差异很大，干可可粉和无糖烘焙巧克力含有最高浓度的甲基黄嘌呤[1]。

### Sources

[1] Food Hazards - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/poisoning/food-hazards
[2] Chocolate Toxicosis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals
[3] Infographics:Household Pet Hazards Chocolate Poisoning-Merck ...: https://www.merckvetmanual.com/multimedia/infographic/household_pet_hazards_chocolate_poisoning
[4] Chocolate (Proceedings) - dvm360: https://www.dvm360.com/view/chocolate-proceedings

## 常见病原体

巧克力中毒不是由传染性病原体引起，而是由巧克力中天然存在的有毒化合物引起。主要的有毒物质是甲基黄嘌呤，特别是可可碱（3,7-二甲基黄嘌呤）和咖啡因（1,3,7-三甲基黄嘌呤）[1][2]。这些生物碱天然存在于植物中，存在于可可豆、茶叶、咖啡豆和可乐豆中[1]。

可可碱浓度在不同巧克力类型中差异很大。可可粉含量最高，为28.5毫克/克（807毫克/盎司），其次是无糖烘焙巧克力，为15.5毫克/克（440毫克/盎司）[2][3]。半甜巧克力和黑巧克力含有5.3-5.6毫克/克（150-160毫克/盎司），而牛奶巧克力浓度较低，为2.3毫克/克（64毫克/盎司）。白巧克力风险极低，仅含0.04毫克/克（1.1毫克/盎司）[2][3]。

毒性机制涉及细胞腺苷受体的竞争性抑制，导致中枢神经系统兴奋、利尿和心动过速[2]。甲基黄嘌呤还增加细胞内钙水平并抑制磷酸二酯酶，导致环磷酸腺苷水平升高[1][2]。这些作用产生拟交感神经效应，影响犬和猫的心血管和神经系统[4]。

可可碱通过细胞色素P450酶（主要是CYP1A2）在肝脏中代谢为黄嘌呤和甲基尿酸[5]。消除半衰期在人类中为6-8小时[5]，但在犬类中明显更长，约为17.5小时[2]。与人类相比，犬类这种较慢的代谢导致其对甲基黄嘌呤毒性的敏感性增加。

### Sources
[1] DVM 360 Chocolate (Proceedings): https://www.dvm360.com/view/chocolate-proceedings
[2] Merck Veterinary Manual Chocolate Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals
[3] Merck Veterinary Manual Table: Methylxanthine Content of Various Types of Chocolate-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/methylxanthine-content-of-various-types-of-chocolate
[4] The most common poisons for pets: https://www.dvm360.com/view/the-most-common-poisons-for-pets
[5] Theobromine - Wikipedia: https://en.wikipedia.org/wiki/Theobromine

## 临床症状和体征

巧克力中毒的临床症状通常在摄入后6-12小时内出现，并呈剂量依赖性进展[1]。初始表现包括多饮、呕吐、腹泻和不安，可能进展为更严重的神经和心血管症状[1,2]。

**早期症状：**患者最初表现为胃肠道紊乱，包括呕吐、腹泻和腹胀，伴有多饮和普遍不安[1]。这些轻微症状通常在犬类甲基黄嘌呤剂量为20毫克/公斤时出现[2]。

**进展症状：**随着中毒加重，临床症状升级为过度活跃、多尿、共济失调、僵硬和震颤[1]。中度至重度心脏毒性效应，包括心动过速和室性早搏，在40-50毫克/公斤剂量时出现[2]。超过60毫克/公斤剂量时可能出现癫痫发作[2]。

**严重表现：**晚期病例表现为呼吸急促、发绀、高血压、高热，可能进展为心动过缓、低血压或昏迷[1]。死亡通常由心律失常、高热或呼吸衰竭引起[1]。晚期低钾血症可能导致心功能障碍[1]。

**物种考虑：**犬类最常受影响，因其不加选择的饮食习惯，而猫类表现出相似的临床表现，但甲基黄嘌呤的消除半衰期可能不同[2]。巧克力产品中的高脂肪含量可能额外引发易感动物的胰腺炎[1]。

### Sources

[1] Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals
[2] DVM 360 Chocolate: https://www.dvm360.com/view/chocolate-proceedings

## 诊断方法

巧克力中毒的诊断主要依靠准确的病史采集和临床表现评估[1][2]。兽医应获取关于摄入巧克力的类型和数量、摄入时间和患者体重的详细信息，以计算甲基黄嘌呤暴露量[1][2]。

毒性计算器是确定严重程度的重要诊断工具，基于巧克力类型和甲基黄嘌呤含量。黑巧克力约含150毫克/盎司总甲基黄嘌呤，而牛奶巧克力约含64毫克/盎司[2][6]。对于美食巧克力棒，列出的可可百分比应乘以无糖巧克力值（约400毫克/盎司）[6]。

临床症状通常在摄入后6-12小时内出现，包括多饮、呕吐、腹泻、过度活跃进展为震颤和癫痫发作，以及心脏效应[2]。实验室检查结果通常是支持性而非诊断性的，建议进行基础血清生化分析以监测电解质并评估并发症[8]。

没有现成的特定诊断测试可用于巧克力中毒[2]。鉴别诊断应包括其他中枢神经系统兴奋剂，如安非他明、伪麻黄碱或咖啡因中毒[2]。诊断确认主要依赖于将计算的甲基黄嘌呤剂量与观察到的临床症状相关联，并排除其他相似症状学的原因。

### Sources

[1] The most common poisons for pets: https://www.dvm360.com/view/the-most-common-poisons-for-pets
[2] Chocolate Toxicosis in Animals - Toxicology: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals
[6] Chocolate (Proceedings): https://www.dvm360.com/view/chocolate-proceedings
[8] DVM 360 Toxicology Brief: The 10 most common toxicoses in dogs: https://www.dvm360.com/view/toxicology-brief-10-most-common-toxicoses-dogs

## 治疗方案

巧克力中毒的治疗需要立即稳定临床症状和支持性护理干预。去污染程序包括在2小时内使用罗匹尼罗（2.7-5.4毫克/平方米）或阿扑吗啡（0.03-0.04毫克/公斤静脉注射）诱导呕吐，仅在致命暴露情况下谨慎考虑使用活性炭（1-2克/公斤口服一次）[1]。

药物治疗针对心脏和神经系统并发症。呕吐使用马罗匹坦（1毫克/公斤皮下/静脉注射，每24小时一次）或昂丹司琼（0.5毫克/公斤缓慢静脉注射，每8小时一次）控制。震颤和癫痫发作需要美索巴莫（50-220毫克/公斤缓慢静脉注射）或地西泮（0.5-2毫克/公斤缓慢静脉注射），严重病例保留使用巴比妥类药物[1]。

心血管稳定涉及特定的抗心律失常方案：普萘洛尔（0.02-0.06毫克/公斤缓慢静脉注射）用于心动过速，阿托品（0.01-0.02毫克/公斤）用于心动过缓，利多卡因（1-2毫克/公斤静脉注射，随后25-80微克/公斤/分钟持续输注）用于难治性室性心律失常[1]。

积极的液体治疗促进利尿和甲基黄嘌呤消除，同时支持心血管功能。其他支持措施包括心电图监测、纠正酸碱和电解质异常、体温调节，以及为不能走动的患者插导尿管以防止毒素再吸收[1]。在严重病例中，临床症状可能持续长达72小时。

### Sources
[1] Chocolate Toxicosis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals

## 预防措施和鉴别诊断

**预防措施**

巧克力中毒的预防主要依靠主人教育和环境管理[1]。宠物主人必须将所有巧克力产品存放在宠物无法接触的容器中，特别是在高风险时期，包括万圣节、圣诞节、情人节和复活节，此时巧克力消费达到高峰[4]。所有家庭成员都应了解巧克力对宠物有毒，即使少量也可能危险。

环境控制包括妥善处理巧克力包装纸和含可可产品，如可可豆壳制成的覆盖物[1]。主人应了解可可粉和烘焙巧克力因其甲基黄嘌呤浓度高而构成最高风险[1]。在从万圣节到复活节的"巧克力季节"期间，宠物主人必须格外警惕[4]。

**鉴别诊断**

巧克力中毒必须与其他甲基黄嘌呤中毒和呈现相似临床症状的中枢神经系统兴奋剂毒性区分开来[1]。主要鉴别诊断包括安非他明中毒、麻黄/瓜拉纳（麻黄碱/咖啡因）中毒、伪麻黄碱中毒和可卡因中毒[1][6]。

其他考虑包括摄入抗组胺药、抗抑郁药或其他中枢神经系统兴奋剂[1]。诊断主要依赖于暴露史和临床表现，因为没有现成的诊断测试可用于巧克力中毒[1]。考虑到三环类抗抑郁药具有相似的心血管和神经效应，也应考虑[6]。

### Sources

[1] Chocolate Toxicosis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/chocolate-toxicosis-in-animals
[2] Chocolate (Proceedings) - dvm360: https://www.dvm360.com/view/chocolate-proceedings
[3] Household toxins (Proceedings): https://www.dvm360.com/view/household-toxins-proceedings
