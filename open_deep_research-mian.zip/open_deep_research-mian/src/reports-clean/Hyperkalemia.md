# 伴侣动物高钾血症

高钾血症是小动物临床中最危急的电解质急症之一，具有潜在致命性心脏后果，需要立即识别和干预。这种危及生命的状况发生在血清钾浓度超过正常范围时，最常见于患有尿道阻塞的猫和患有肾脏病或肾上腺皮质功能减退症的狗。本报告探讨了高钾血症的多方面性质，从其基础病理生理学和多样化的临床表现，到紧急稳定方案和长期管理策略。重点关注领域包括定义严重病例的特征性肌肉无力和心律失常、结合心电图监测与实验室检测的诊断方法，以及使用葡萄糖酸钙、胰岛素-葡萄糖治疗和针对性液体管理的循证治疗方案，以获得最佳患者结果。

## 疾病概述

高钾血症定义为血清或血浆钾浓度高于正常参考范围，在犬猫中通常>5.5 mEq/L (5.5 mmol/L) [1]。这种电解质失衡代表了正常钾稳态的破坏，可能导致危及生命的并发症。

**正常钾生理学**

体内总钾量中至少95%在细胞内，其中骨骼肌含有细胞内储存量的60-75% [3]。由Na+/K+-ATP酶产生的钾梯度在细胞膜上产生负电势。钾稳态主要通过胃肠道吸收和在醛固酮影响下的肾脏排泄来维持 [3]。

**流行病学背景**

高钾血症常见于尿钾排泄不足的伴侣动物，特别是在同时存在酸血症和脱水时 [1]。在猫中，尿道阻塞是最常见的原因，猫尿道阻塞在兽医实践中的估计发病率为1-10% [4]。该状况常伴随全身性疾病，是需要及时识别和治疗的重大急症。

### Sources

[1] Hyperkalemia in Ruminants - Metabolic Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/hyperkalemia-in-ruminants

[2] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20

[3] Overview of Disorders of Potassium Metabolism in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals

[4] Pharmacological therapy for hyperkalemia in feline urethral: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0258/javma.25.04.0258.xml

## 常见病原体

高钾血症主要是一种代谢性疾病而非传染病。然而，某些寄生虫感染可能导致电解质失衡，从而在犬猫中引起高钾血症。

与高钾血症相关的主要寄生虫病原体是犬鞭虫（*Trichuris vulpis*）[1]。这种寄生虫生活在盲肠和结肠中，其前端穿过肠粘膜 [3]。在涉及数百条蠕虫的重度感染中，犬鞭虫可引起血性腹泻、脱水和贫血 [3]。慢性腹泻导致的严重液体和电解质流失可能通过脱水和肾功能损害导致继发性高钾血症。

鞭虫在收容所的各年龄段犬中很常见，6个月以下幼犬的患病率从7.84%到6-12月龄犬的16.83%不等 [3]。成年犬与幼年动物同样易受感染 [3]。虫卵在适宜温度下于土壤中9-10天内发育成含有感染性幼虫，并可在环境中长期存活 [3]。

虽然其他胃肠道寄生虫如犬弓首蛔虫（*Toxocara canis*）在犬猫中更常见 [2][3]，但它们通常与高钾血症无关。继发性细菌感染偶尔会使严重的寄生虫性肠炎复杂化，但这些代表机会性病原体而非高钾血症的主要原因。

### Sources
[1] Dosage levels of 5, 10, or 15 mg/kg of body weight daily Materials Dogs: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/43/6/ajvr.1982.43.06.1100.pdf
[2] Parasites in pets: Understanding prevalence and perception: https://www.dvm360.com/view/parasites-in-pets-understanding-prevalence-and-perception
[3] Toxocara canis and Trichuris vulpis - Common dog parasites: https://www.dvm360.com/view/toxocara-canis-and-trichuris-vulpis-common-dog-parasites-proceedings

## 临床症状和体征

犬猫高钾血症产生独特的临床表现，反映了升高的钾对细胞膜功能的深远影响。严重高钾血症通常在血清钾浓度超过6.5-8.0 mmol/L时表现出来 [1]。

最具特征性的临床体征是全身性肌肉无力，当钾水平升至6.5 mmol/L以上时变得明显 [1]。在猫中，这种无力常表现为无法抬头（颈部腹屈），形成受影响动物似乎无法正常抬头的特征性姿势 [2]。随着钾水平升高，犬猫可能表现出后肢无力、站立困难和进行性嗜睡 [1][2]。

心血管表现是高钾血症最危及生命的后果之一。心律失常由于膜兴奋性改变而发生，随着钾浓度升高，心电图变化变得明显 [1][2]。这些变化包括心动过缓、P波振幅抑制（>6.5 mmol/L）、QRS波群增宽（>7.8 mmol/L）和特征性T波"帐篷样"改变 [1]。然而，高钾血症猫和犬的临床表现与高钾血症严重程度不相关，因为由于疼痛和低血容量性休克，猫尽管患有高钾血症仍可能严重心动过速 [5]。钠钾比值变得关键，低于25:1的比值显著增加心律失常风险 [1]。

其他临床体征包括抑郁、意识迟钝和呕吐等胃肠道症状 [2]。肌肉无力、抑郁和心脏异常的结合形成了一种临床图景，如果不治疗，可能迅速发展为危及生命的并发症 [4]。

### Sources

[1] Merck Veterinary Manual Hyperkalemia in Ruminants: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/hyperkalemia-in-ruminants
[2] Disorders of potassium (Proceedings) - dvm360: https://www.dvm360.com/view/disorders-potassium-proceedings
[3] Overview of Disorders of Potassium Metabolism in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals
[4] Disorders of Potassium Metabolism in Cats: https://www.merckvetmanual.com/cat-owners/metabolic-disorders-of-cats/disorders-of-potassium-metabolism-in-cats
[5] The tenets of urological emergency care in cats: https://www.dvm360.com/view/tenets-urological-emergency-care-cats

## 诊断方法

犬猫高钾血症的诊断需要结合临床评估、心电图监测和实验室检测的系统方法。体格检查结果可能非特异性，因为临床表现并不总是与高钾血症严重程度相关 [1]。

**心电图评估**
心电图监测对于检测危及生命的心脏效应至关重要。特征性变化包括高尖窄T波、QT间期缩短、P-R间期延长、心动过缓、QRS波群增宽、窦室心律，以及可能的心脏停搏 [1][3]。然而，心率和正常心电图读数不能可靠地排除高钾血症，因为由于疼痛和低血容量，猫可能尽管存在危险的钾水平仍表现为严重心动过速 [4]。

**实验室检测**
血清钾测量对于任何需要液体治疗的危重患者都是强制性的 [5]。初始血液检测应包括红细胞压积、总蛋白、电解质、葡萄糖和静脉血气 [1]。没有固定的钾水平可预测心律失常，因此对于治疗决策，心电图发现比绝对值更重要 [1]。

**影像学研究**
当调查高钾血症的潜在原因时，影像学检查变得必要。腹部超声可识别泌尿道破裂或阻塞，而胸部X光片可能显示肿块或积液 [1]。在创伤病例中，可能需要造影研究来评估泌尿道完整性。

### Sources

[1] Unblock that cat, STAT!: https://www.dvm360.com/view/unblock-cat-stat
[2] ECG of the Month in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/260/14/javma.21.04.0183.xml
[3] Disorders of potassium (Proceedings): https://www.dvm360.com/view/disorders-potassium-proceedings
[4] The tenets of urological emergency care in cats: https://www.dvm360.com/view/tenets-urological-emergency-care-cats
[5] Measuring serum electrolytes great ally in diagnosis, ...: https://www.dvm360.com/view/measuring-serum-electrolytes-great-ally-diagnosis-treatment

## 治疗方案

现有的治疗部分很好地涵盖了小动物高钾血症的管理。通过回顾原始资料，我可以用额外的治疗方式和方案改进来增强这一部分。

高钾血症的紧急稳定侧重于立即心脏保护和钾再分布 [1]。葡萄糖酸钙（10%溶液0.6 ml/kg静脉注射）通过提高阈值电位提供快速的心脏膜稳定，抵消高钾血症对心肌细胞的影响 [1,2]。这种效果持续时间短，不到30分钟，需要每30分钟重复给药直到钾水平正常化 [2]。

对于持续治疗，胰岛素和葡萄糖治疗将细胞外钾驱入细胞内 [1]。常规胰岛素（0.2 U/kg静脉注射）随后给予葡萄糖（每单位胰岛素1-2 g，稀释至25%）有效降低血清钾水平 [4]。或者，单独使用葡萄糖（0.25 g/kg静脉注射）可以刺激内源性胰岛素释放 [6]。胰岛素给药后几小时内必须监测血糖，以防止低血糖 [7]。

特布他林（10 µg/kg肌内注射）提供协同的β2-肾上腺素能效应，与胰岛素-葡萄糖治疗联合使用以增强细胞内钾转移 [2]。对于严重高钾血症（>8 mEq/L），推荐使用葡萄糖、胰岛素和特布他林的联合治疗 [2]。β2-激动剂引起钾的细胞内再分布，但需要密切监测心动过速和低血压 [2]。

碳酸氢钠治疗纠正并存的代谢性酸中毒，并在氢离子被缓冲时促进细胞内钾转移 [7]。碳酸氢钠剂量使用碱缺乏计算：0.3 x 体重（kg）x 碱缺乏，在15-30分钟内缓慢给药 [7]。

使用乳酸林格氏液的液体治疗支持容量扩张并增强钾清除，因为LRS中的最小钾含量与体内钾水平相比可以忽略不计 [2]。对于严重病例，生理盐水给药增加尿产量并促进肾脏钾排泄 [5]。

### Sources

[1] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20

[2] The tenets of urological emergency care in cats: https://www.dvm360.com/view/tenets-urological-emergency-care-cats

[4] Cardiopulmonary Resuscitation of Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/specific-diagnostics-and-therapy/cardiopulmonary-resuscitation-of-small-animals

[5] Hyperkalemia in Ruminants: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/hyperkalemia-in-ruminants

[6] Guidelines for daily fluid therapy planning: When the going gets tough (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-when-going-gets-tough-proceedings

[7] Acute uremia (Proceedings): https://www.dvm360.com/view/acute-uremia-proceedings

## 预防措施

犬猫高钾血症的有效预防涉及通过针对性临床方案对高危患者进行早期识别和干预。高钾血症预防的基石是在钾升高变得危及生命之前及时识别和管理基础疾病 [1]。

**全面监测方案**对于具有易感条件的患者至关重要。接受ACE抑制剂治疗的犬，特别是那些同时患有肾病的犬，需要定期监测血清钾，因为这些药物会损害肾脏钾排泄。螺内酯的使用会产生额外的高钾血症风险，特别是与ACE抑制剂联合使用时 [1]。接受曲洛斯坦治疗肾上腺皮质功能亢进的患者需要仔细监测，因为该药物可通过抑制醛固酮引起高钾血症 [2]。

**高危患者识别**涉及筛查具有高钾血症易感条件的动物。患有下泌尿道疾病的雄性猫代表一个关键人群--约12%的阻塞猫出现从轻度到潜在致命水平的高钾血症。这些患者在治疗期间需要立即血清钾测量和监测 [3]。

**环境和临床管理**包括保持尿道通畅以防止阻塞引起的高钾血症。紧急方案应包括立即电解质评估和导尿过程中的密切监测。避免同时使用损害钾排泄的药物，如保钾利尿剂与ACE抑制剂，可减少医源性风险 [4]。作为综合护理方案的一部分，定期监测危重患者有助于在临床症状出现之前检测发展中的高钾血症 [5]。

### Sources

[1] New drug therapies in veterinary dermatology (Proceedings): https://www.dvm360.com/view/new-drug-therapies-veterinary-dermatology-proceedings
[2] New drug therapies in veterinary dermatology (Proceedings): https://www.dvm360.com/view/new-drug-therapies-veterinary-dermatology-proceedings
[3] Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction
[4] Cardiopulmonary resuscitation (Proceedings): https://www.dvm360.com/view/cardiopulmonary-resuscitation-proceedings-0
[5] Practice pearls for common emergencies (Proceedings): https://www.dvm360.com/view/practice-pearls-common-emergencies-proceedings

## 鉴别诊断

伴侣动物高钾血症有几个重要的鉴别诊断，必须系统地进行评估。**尿道阻塞**是猫中最常见的原因，特别是患有尿道栓子或结石的雄性猫 [1]。完全阻塞由于肾小球滤过率降低和无法经肾脏排泄钾而导致钾积累 [6,7]。

**急性肾损伤**是另一个主要原因，其中肾功能受损损害钾排泄 [3]。这可由各种肾毒素、缺血或影响肾脏的炎症性疾病引起。

**肾上腺皮质功能减退症（艾迪生病）**在犬中常表现为高钾血症，与低钠血症和钠:钾比值<27:1同时发生 [5]。盐皮质激素缺乏阻止正常的肾脏钾排泄。

**慢性肾病**当肾小球滤过率严重受损时（通常在晚期）可引起高钾血症 [3]。然而，许多CKD患者在终末期疾病之前维持正常钾水平。

**鉴别因素**包括临床表现和并存异常。尿道阻塞表现为无法排尿和膨胀、疼痛的膀胱 [1,7]。艾迪生病显示特征性电解质模式，伴有低钠血症和常伴有低血糖 [5]。急性肾损伤通常为近期发作，有潜在毒素暴露或低血压史。慢性肾病表现为逐渐发作、小而不规则肾脏和持续性氮质血症 [3]。

其他考虑包括溶血或血小板增多引起的假性高钾血症，以及药物引起的原因，如ACE抑制剂或保钾利尿剂 [4]。

### Sources

[1] Merck Veterinary Manual Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats
[2] Merck Veterinary Manual Overview of Disorders of Potassium Metabolism in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals
[3] Merck Veterinary Manual Renal Dysfunction in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[4] Merck Veterinary Manual Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[5] DVM 360 Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction
[6] Merck Veterinary Manual Urethral Obstruction in Small Animals: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urethral-obstruction-in-small-animals

## 预后

高钾血症猫和犬的预后高度依赖于潜在原因、钾升高严重程度和适当治疗的及时性 [1]。高钾血症动物的死亡率显著更高，一项研究显示高钾血症猫的死亡率为35%，而钾水平正常的猫则为 [1]。

高钾血症严重程度直接影响预后。轻度升高（5-6 mEq/L）可能临床无意义，而严重高钾血症（≥9 mEq/L）如果不治疗可能致命 [2]。然而，临床表现并不总是与钾水平相关，因为由于疼痛、休克和低血容量，猫尽管患有高钾血症仍可能严重心动过速 [2]。

潜在原因显著影响结果。患有尿道阻塞或尿腹的动物，当高钾血症得到及时纠正和主要疾病得到处理时，通常预后良好 [2]。治疗后生存取决于诱发疾病的成功管理，而非高钾血症本身。

当实施适当治疗时，对治疗的反应通常迅速。尿道阻塞引起的高钾血症一旦尿流重新建立和液体治疗开始，通常在几小时内解决 [2]。当患者在麻醉程序前代谢稳定时，预后显著改善，因为高钾血症患者在未经预先纠正的情况下接受麻醉时，死亡率显著增加 [2]。

### Sources

[1] Pharmacological therapy for hyperkalemia in feline urethral: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0258/javma.25.04.0258.pdf

[2] Managing the common comorbidities of feline urethral obstruction: https://www.dvm360.com/view/managing-common-comorbidities-feline-urethral-obstruction
