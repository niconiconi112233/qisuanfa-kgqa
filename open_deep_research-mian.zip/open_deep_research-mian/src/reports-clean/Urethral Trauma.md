# 犬猫尿道创伤

## 疾病概述

尿道创伤是伴侣动物中一种严重的泌尿生殖系统急症，其特征是尿道壁损伤，范围可从轻微的黏膜撕裂到完全破裂并伴有尿液渗漏至周围组织（Merck Veterinary Manual, 2024）。由于雄性动物的尿道更长、解剖结构更复杂，这种情况主要影响雄性动物，而猫由于阴茎尿道直径较窄，尤其易受影响（DVM360, 2024）。

流行病学数据显示了明显的物种和性别倾向性，雄性猫的发病率较高，这是由于其解剖结构限制使其易发生梗阻性发作，并在尝试解除梗阻过程中发生创伤（Merck Veterinary Manual, 2024）。风险因素包括既往泌尿系统手术史、导尿尝试、车辆创伤导致的骨盆骨折，以及导致尿道狭窄的基础尿石症或炎症性疾病（DVM360, 2024）。短头颅品种可能因骨盆解剖结构改变而面临更高风险，而户外雄性猫因车辆事故和领地争斗显示出更高的创伤率（AVMA Journals, 2024）。

## 常见病原体

尿道创伤为继发性细菌感染创造了有利条件，大多数并发症源于来自会阴部和正常皮肤菌群的上行性感染。[1] 革兰氏阴性菌是主要病原体，在大肠杆菌是继发性尿路感染犬猫中最常分离到的生物体。[1][2] 其他常见细菌病原体包括葡萄球菌属、变形杆菌属、链球菌属、克雷伯氏菌属和假单胞菌属。[2]

在尿道创伤后发生继发性感染的犬中，从尿液中常规培养出中间葡萄球菌和肠球菌属。[3] 铜绿假单胞菌在慢性或复杂病例中尤其值得关注，因其与多重耐药性相关。[3] 支原体属较少引起感染，但需要特殊培养技术才能检测到。[8] 

病毒病原体通常与小动物尿道创伤后的继发性感染无关。然而，在免疫功能低下的患者中，偶尔可能发生念珠菌属引起的机遇性真菌感染。[2] 适当的细菌培养和抗菌药物敏感性测试对于指导靶向治疗仍然至关重要，特别是考虑到尿路病原体中抗菌药物耐药性日益增加的趋势。[3]

### Sources
[1] Overview of Infectious Diseases of the Urinary System in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/overview-of-infectious-diseases-of-the-urinary-system-in-small-animals
[2] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals
[3] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[8] Bacterial Cystitis in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals

## 临床症状和体征

患有尿道创伤的动物通常表现为典型的下尿路症状，包括尿频、排尿困难和血尿 [1]。排尿困难（疼痛性排尿）和排尿障碍是标志性症状，通常表现为频繁尝试排尿但仅排出少量尿液 [1][2]。

血尿的表现可能不同，从显微镜下血尿到尿液肉眼变色 [3]。排尿过程中血液出现的时间有助于定位创伤 - 排尿初期出现或与排尿无关的出血提示尿道或生殖道受累 [3]。

体格检查时，膀胱通常胀大且触诊时有疼痛感 [1]。在雄性犬猫中，应检查阴茎是否有红斑、紫色变色或创伤迹象 [1]。直肠检查可能发现可触及的尿道阻塞或不规则 [1]。

**物种特异性差异**值得注意：猫更常见形成基质结晶栓导致阻塞，而犬通常表现为尿石症 [1]。雄性猫由于阴茎尿道解剖学狭窄而特别易感。

**并发症**包括完全梗阻时的尿毒症症状 - 呕吐、脱水、低温和严重抑郁 [1]。当血浆钾超过7 mEq/L时，高钾血症可引起心动过缓或心律失常 [1]。尿道破裂导致的尿腹可表现为腹部膨隆、严重嗜睡，以及因腹痛而呈现祈祷姿势 [6]。

### Sources
[1] Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats
[2] Disorders of Micturition in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/disorders-of-micturition-in-dogs-and-cats
[3] The diagnostic approach to hematuria: https://www.dvm360.com/view/diagnostic-approach-hematuria
[6] Uroabdomen (Proceedings): https://www.dvm360.com/view/uroabdomen-proceedings

## 诊断方法

**体格检查**是犬猫尿道创伤诊断的基础。临床医生应评估腹痛、膀胱膨胀，并进行轻柔触诊以避免进一步损伤 [1]。直肠检查可能发现尿道不规则或血肿，特别是在可触及盆腔尿道的雄性犬中 [2]。

**尿液分析**提供关键诊断信息，应包括完整的沉渣检查。血尿常存在，出血程度可能有助于定位损伤。白细胞增多可能表明对创伤的炎症反应 [6]。新鲜尿液检查至关重要，因为储存伪影会使解释复杂化 [8]。

**影像学检查**对明确诊断至关重要。X线平片应包括整个泌尿道以识别并发损伤和骨盆骨折 [1]。**阳性对比尿道造影**是评估尿道创伤的金标准，在雄性犬猫中检测狭窄、破裂或充盈缺损特别有效 [1]。该技术需要在X线曝光期间仔细放置导管和注射造影剂 [5]。

**超声检查**通过评估膀胱完整性和识别液性积聚来补充X线检查结果，但除非使用专用探头，否则无法显示盆腔尿道 [1]。**双重对比膀胱造影**提供更优越的黏膜细节，可识别细微的膀胱壁损伤 [5]。

**实验室检测**包括血尿素氮和肌酐，如果尿道破裂导致尿液泄漏到体腔，可能显示氮质血症。全血细胞计数有助于评估并发的创伤相关损伤 [3]。

### Sources
[1] Imaging the urinary tract: Correct use of radiography and ultrasonography (Proceedings): https://www.dvm360.com/view/imaging-urinary-tract-correct-use-radiography-and-ultrasonography-proceedings
[2] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[3] Positive-contrast cystography in a dog with a hard-to-detect bladder rupture: https://www.dvm360.com/view/positive-contrast-cystography-dog-with-hard-detect-bladder-rupture
[4] Fun with radiographic contrast procedures (Proceedings): https://www.dvm360.com/view/fun-with-radiographic-contrast-proceedings
[5] GI and urinary system contrast radiography: Not a dying art (Proceedings): https://www.dvm360.com/view/gi-and-urinary-system-contrast-radiography-not-dying-art-proceedings
[6] Urinalysis - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/urinalysis
[7] The value of a urinalysis (Proceedings): https://www.dvm360.com/view/value-urinalysis-proceedings
[8] Diagnostic approach to lower urinary tract disease (Proceedings): https://www.dvm360.com/view/diagnostic-approach-lower-urinary-tract-disease-proceedings/1000

## 治疗方案

保守治疗是大多数尿道创伤病例的主要方法。对于尿道撕裂和尿液渗漏的选定动物，通过尿道导管置入进行即时尿流改道可提供有效的长期解决方案 [1]。膀胱造瘘管术是短期或长期尿流改道的替代方法，但约49%的病例会出现并发症，包括尿路感染和意外拔管 [1]。

对于严重尿道创伤或保守治疗失败的情况，需要手术干预。颊黏膜移植尿道成形术已成为修复猫完全尿道破裂的可行技术 [2]。对于初次手术修复失败的病例，通过修订解剖分离和黏膜对皮肤贴合对原手术部位进行初级修复在大多数病例中被证明是有效的 [1]。

药物治疗侧重于多模式疼痛管理和感染预防。适当的镇痛药物包括布托啡诺、丁丙诺啡、氢吗啡酮和芬太尼透皮贴剂，应尽早提供镇痛 [3]。由于尿路感染的高风险，抗生素预防至关重要，据报道尿流改道术后感染率几乎普遍存在 [1]。其他支持性药物可能包括尿道平滑肌松弛剂，如乙酰丙嗪或α-1拮抗剂如酚苄明，用于管理尿道痉挛 [3]。

护理注意事项包括监测皮下尿液渗漏等并发症、保持导管通畅以及提供适当的伤口护理以预防继发性感染。涉及被动关节活动度练习和支持性卧具的物理治疗方案有助于防止卧床患者的并发症 [4]。

### Sources
[1] How to perform a feline perineal urethrostomy: https://www.dvm360.com/view/how-perform-feline-perineal-urethrostomy
[2] Buccal mucosal graft urethroplasty in male cats with traumatic: https://avmajournals.avma.org/view/journals/javma/260/1/javma.20.09.0540.xml
[3] Management of cats with urethral obstruction (Proceedings): https://www.dvm360.com/view/management-cats-with-urethral-obstruction-proceedings
[4] Management tips for the postoperative neurosurgical case: https://www.dvm360.com/view/management-tips-postoperative-neurosurgical-case-proceedings
