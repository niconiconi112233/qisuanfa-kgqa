# 伴侣动物角膜结膜炎（干眼症）：综合兽医指南

角膜结膜炎（KCS），即干眼症，是影响伴侣动物（尤其是犬）最重要的慢性眼病之一。该病症由泪液分泌不足引起，导致角膜损伤、继发感染和潜在的视力丧失。犬的整体发病率约为1%，且在斗牛犬、可卡犬和其他流行品种中存在强烈的品种易感性，因此需要及时识别和适当管理以预防不可逆的并发症。

本报告为兽医从业者提供循证指导，涵盖泪膜功能障碍的病理生理学、包括正确施氏泪液测试技术的诊断方案、从免疫调节泪液刺激剂到手术干预的当前治疗方式，以及关键的鉴别诊断。综合分析既涉及常见的免疫介导表现，也涉及与耳部药物相关的新兴神经源性病因，为临床医生提供在小动物实践中有效管理KCS的实用工具。

## 疾病概述

**角膜结膜炎（KCS）**，通常称为干眼症，是角膜前泪膜中水性（水样）部分的缺乏[1]。该病症由泪腺和/或第三眼睑腺分泌泪液不足引起，导致慢性眼表炎症和不适。

KCS主要发生于犬，总体发病率约为1%[1]。该病症通常为双侧性和特发性，通常与自身免疫性泪腺炎相关，导致泪腺和瞬膜腺的破坏[1][2]。某些品种表现出易感性，包括斗牛犬、可卡犬、骑士查理王小猎犬和西施犬[1]。

泪膜由三个基本层组成：来自睑板腺的外层脂质层、来自泪腺和第三眼睑腺的中层水样层，以及来自结膜杯状细胞的内层黏液层[1][3]。水样层60%由泪腺产生，40%由第三眼睑腺产生[3]。正常的泪液分泌维持角膜透明度，提供营养和润滑，并通过免疫球蛋白和抗菌物质保护免受感染[1]。

### Sources
[1] DVM 360 Management of tear film disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[2] Merck Veterinary Manual Nasolacrimal and Lacrimal Apparatus in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[3] DVM 360 Ophthalmic anatomy and diagnostics (Proceedings): https://www.dvm360.com/view/ophthalmic-anatomy-and-diagnostics-proceedings

## 常见病原体和病因

角膜结膜炎由影响泪腺功能的多种病因因素引起[1]。最常见的原因是免疫介导的破坏，其特征是眶内和瞬膜泪腺中的淋巴细胞-浆细胞浸润，影响某些品种如骑士查理王小猎犬和西部高地白梗[1]。

病毒感染代表重要的致病原因。犬瘟热病毒可诱发泪腺炎导致KCS[2]。在猫中，猫疱疹病毒-1是主要的传染性原因，通常导致先前感染后的瘢痕形成[2]。利什曼病也会引起犬的传染性KCS[2]。

神经源性原因涉及通过颅神经VII对泪腺的副交感神经支配丧失[2]。中耳/内耳炎经常触发神经源性KCS，特别是当含有特比萘芬和氟苯尼考的耳部药物损伤鼓膜时[3]。如果病变发生在翼腭神经节近端，犬可能出现同侧干燥性鼻炎[2]。

药物诱导的KCS可由各种药物引起，包括局部/全身性阿托品、口服磺胺类药、依托度酸和某些青光眼药物如噻吗洛尔[1]。内分泌疾病包括糖尿病、肾上腺皮质功能亢进和甲状腺功能减退可减少泪液分泌[2]。其他原因包括泪腺发育不全/发育不全、创伤和医源性因素如瞬膜腺切除术[1]。

### Sources
[1] Lacrimal disease can make you cry: What to do?: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings
[2] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[3] Beware of neurogenic keratoconjunctivitis sicca caused by otic medications: https://www.dvm360.com/view/beware-of-neurogenic-keratoconjunctivitis-sicca-caused-by-otic-medications

## 临床症状和体征

患有角膜结膜炎的犬表现出独特的眼部表现，从急性阶段发展到慢性阶段。最一致的临床体征是黏脓性眼部分泌物，通常表现为黏附在角膜和结膜上的黏稠浆液性或浆液黏液性分泌物，呈条索状[1]。由于炎性细胞浸润和潜在的继发性细菌感染，这种分泌物变得越来越脓性[1]。

急性病例通常因眼睑在较干燥的眼表上移动引起的摩擦性刺激而表现出明显的眼睑痉挛，同时影响眼睑和球结膜的结膜充血[1]。角膜失去其清晰、湿润的外观，变得暗淡无光，表面干燥[1]。

慢性KCS发展更为隐匿，伴有黏稠黏液性分泌物积聚、角膜血管新生、色素性角膜炎和角膜瘢痕形成[1][4]。晚期病例由于黑色素、脂质和钙沉积而显示广泛的角膜混浊，可能导致失明[1]。《默克兽医手册》将慢性病例描述为"血管化和色素化的角膜以及增厚、发炎的结膜伴有黏液性渗出物"[4]。

**神经源性KCS**表现出独特的单侧体征和同侧干燥性鼻炎（干燥鼻孔），将其与免疫介导形式区分开来[5][6]。最近的研究确定含有特比萘芬和氟苯尼考的耳部药物是神经源性KCS的潜在原因[5]。

KCS主要影响中老年犬，但也可能在幼年动物中急性发生[2]。常见的易感品种包括可卡犬、西部高地白梗、西施犬、波士顿梗和斗牛犬[3]。该病症在大多数情况下是双侧性的，但最初可能表现为单侧[2]。与犬相比，猫很少发生KCS[4][8]。

### Sources
[1] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[2] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[3] Common eye diseases for veterinary technicians ...: https://www.dvm360.com/view/common-eye-diseases-veterinary-technicians-proceedings
[4] Nasolacrimal and Lacrimal Apparatus in Animals - Eye Diseases ...: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[5] Beware of neurogenic keratoconjunctivitis sicca caused by otic medications: https://www.dvm360.com/view/beware-of-neurogenic-keratoconjunctivitis-sicca-caused-by-otic-medications
[6] Long-lasting otic medications may be a rare cause of neurogenic keratoconjunctivitis sicca in dogs: https://avmajournals.avma.org/view/journals/javma/261/1/javma.22.07.0301.xml
[7] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[8] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings

## 诊断方法

临床表现评估构成干眼症诊断的基础[1]。兽医应系统评估眼部分泌物、眼睑痉挛、结膜充血和角膜变化，包括血管、色素或瘢痕[1][5]。必须检查双眼以建立基线值并检测不对称性[3]。

施氏泪液测试（STT）是确认角膜结膜炎的主要诊断工具[2][3][4][5]。STT-1在应用任何诊断试剂之前进行，测量一分钟内的反射性和基础泪液分泌[4][5][6]。犬和猫的正常值均为每分钟湿润大于15毫米[2][3][4][5]。低于10毫米/分钟的值对KCS具有诊断意义，而10-15毫米/分钟之间的值应结合临床症状解读[3][4][5]。在猫中，交感神经系统刺激可导致正常但应激的动物出现极低的STT值，使解读具有挑战性[1][2]。

荧光素染色评估角膜上皮完整性，对于检测干眼症常见发展的溃疡至关重要[6][9]。当亲脂性上皮受损时，亲水性染料会附着在暴露的角膜基质上[6]。

泪膜破裂时间（TFBUT）测试通过测量荧光素应用后的稳定性来评估泪膜质量[5][6][7]。正常TFBUT约为20秒；时间缩短表明影响黏蛋白或脂质层的定性泪液缺乏[5][7]。其他诊断可能包括结膜细胞学检查以识别炎性浸润，以及在脓性分泌物或治疗难治性感染病例中进行细菌培养[5][9]。

### Sources
[1] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[2] Just Ask the Expert: What is a normal Schirmer tear test result?: https://www.dvm360.com/view/just-ask-expert-what-normal-schirmer-tear-test-result
[3] 6 eye errors youre probably overlooking: https://www.dvm360.com/view/6-eye-errors-you-re-probably-overlooking
[4] Ophthalmology Made Simple: https://www.dvm360.com/view/ophthalmology-made-simple
[5] Lacrimal disease can make you cry: What to do? (Proceedings): https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings
[6] Diagnostic Tests Pertaining to Ocular Medications in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/diagnostic-tests-pertaining-to-ocular-medications-in-animals
[7] Management of tear film disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[8] Canine corneal diseases: secrets for transparency greater than the federal stimulus (Proceedings): https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings
[9] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings

## 治疗选择

角膜结膜炎的治疗需要结合药物干预、泪液替代疗法和支持性护理的多模式方法[1]。主要目标是在维持眼表水合和预防并发症的同时恢复自然泪液分泌。

**免疫调节泪液刺激剂**代表KCS治疗的基石。局部环孢素（0.2%市售商品为Optimmune，或配制成1-2%浓度）和他克莫司（0.02-0.03%配方制剂）是钙调神经磷酸酶抑制剂，可阻断T细胞活化并减少攻击泪腺的炎性介质[2][3]。这些药物还直接刺激存活腺体组织的泪液分泌。他克莫司比环孢素效力高10至100倍，可能对环孢素抵抗病例有效[2]。

**泪液替代疗法**利用人工泪液、凝胶和软膏在泪液刺激剂达到治疗效果期间维持眼表润滑[4]。含有羧甲基纤维素或羟丙甲纤维素的黏蛋白模拟剂模拟天然泪液黏蛋白成分。

**支持性药物**包括用于继发性细菌感染的局部抗生素（新霉素-多粘菌素B-杆菌肽或红霉素），因为天然泪液具有在KCS中减弱的抗菌特性[4]。谨慎使用局部皮质类固醇（含氢化可的松的新霉素-多粘菌素B-杆菌肽）可减少结膜炎症和角膜血管新生，但由于溃疡风险增加，应谨慎使用。

**手术干预**通过腮腺导管转位应考虑用于经历持续性不适或复发性角膜溃疡的药物难治性病例[1]。该手术重新引导唾液流动以替代泪液分泌。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] Tear Stimulants and Immunosuppressants in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/tear-stimulants-and-immunosuppressants-in-animals
[3] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[4] Lacrimal disease can make you cry: What to do? (Proceedings): https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings

## 预防措施和鉴别诊断

### 预防措施

干眼症的预防主要侧重于环境控制和监测高危患者[1]。环境措施包括避免可能减少泪液分泌的药物，如局部或全身性阿托品、口服磺胺类药和某些青光眼药物如噻吗洛尔[8]。维持适当的环境湿度和在麻醉期间保护眼睛至关重要，因为全身麻醉会减少长达一周的泪液分泌[7][8]。

定期监测易感品种对于早期发现至关重要[1][7]。施氏泪液测试应常规在高风险品种中进行，包括骑士查理王小猎犬、美国可卡犬、西部高地白梗和英国斗牛犬[7][8]。早期使用人工泪液制剂干预可防止发展为严重干眼综合征。

### 鉴别诊断

几种眼部疾病表现出重叠症状，需要仔细鉴别[1]。原发性结膜炎通常维持正常泪液分泌，不像干眼症那样施氏泪液测试值特征性地低于15毫米/分钟[1][7]。角膜溃疡可能由潜在的干眼症引起或作为原发性病症出现，通过荧光素染色模式和泪液分泌评估来区分[1][4]。

睑缘炎和睑板腺炎可模拟干眼症表现，特别是在检查继发性泪膜异常时[6][8]。然而，这些病症可能显示正常的施氏值，但泪膜破裂时间在10秒以下[8]。对于泪液分泌正常但持续眼部刺激的患者，应考虑定性泪液缺乏，通过泪膜破裂时间测试诊断[8]。

### Sources
[1] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[4] Medicine to ease the feline mind: https://www.dvm360.com/view/medicine-to-ease-the-feline-mind
[6] Management of tear film disorders in the dog and cat: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[7] Canine keratitis: Ulcers to KCS: https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[8] Lacrimal disease can make you cry: What to do?: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings
