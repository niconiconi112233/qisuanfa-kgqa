# 伴侣动物恶性乳腺肿瘤

恶性乳腺肿瘤是小动物兽医实践中最重要的肿瘤学挑战之一，在犬和猫之间表现出截然不同的临床表现和预后。虽然犬的乳腺肿瘤恶性率为50%，但猫的恶性率高达惊人的90%，这使得早期识别和干预变得至关重要。本综合报告探讨了伴侣动物乳腺癌症的多方面性质，从激素风险因素和品种易感性到先进的诊断技术和不断发展的治疗方案。了解肿瘤行为的物种特异性差异、早期绝育的保护性益处以及影响生存结果的预后因素，使兽医能够为这种复杂疾病提供最佳护理，并有效向宠物主人提供建议。

## 摘要

恶性乳腺肿瘤在不同伴侣动物物种中呈现出不同的挑战，猫的预后明显比犬差。该疾病表现出明显的激素依赖性，早期绝育提供了显著的保护作用--在6个月前进行可使猫的风险降低91%，在第一次发情前进行可使犬的风险降至0.05%。与许多癌症不同，乳腺肿瘤没有传染性病因，而是由激素、遗传和环境因素引起。

临床表现因物种而异，猫常见双侧受累（占病例的40%）和频繁溃烂（50%），而犬通常表现为尾部乳腺肿块。诊断需要通过胸部X光和组织病理学进行系统分期，因为仅靠细胞学无法可靠地区分恶性和良性病变。治疗以根治性乳房切除术为中心，与保守方法相比，它提供了更长的无病间隔，通常与基于阿霉素方案的辅助化疗联合使用。

| 因素 | 犬 | 猫 |
|--------|------|------|
| 恶性率 | 50% | >90% |
| 预后 | 75%可通过手术治愈 | 通常较差 |
| 关键肿瘤大小 | ≥3 cm（预后不良） | ≥2-3 cm（最差结果） |
| 早期绝育保护 | 0.05%风险（第一次发情前） | 91%风险降低（6个月前） |

兽医必须强调预防性绝育，并对乳腺肿块保持高度临床怀疑，特别是在未绝育的母犬母猫中，以便通过早期干预优化患者预后。

## 疾病概述

恶性乳腺肿瘤是伴侣动物最重要的肿瘤学疾病之一，在犬和猫之间具有明显的流行病学模式。在犬中，乳腺肿瘤是未绝育母犬最常见的肿瘤，其中约50%是恶性的[1]。相反，猫表现出更令人担忧的模式，超过90%的乳腺肿瘤是恶性的[2]。

该疾病表现出明显的性别和年龄倾向性。每10万只动物中，母猫的发病频率是公猫的25.4倍，公猫病例占比不到1%[3]。猫的平均诊断年龄在10-12岁之间，尽管有记录显示病例可低至9个月[3]。

品种易感性在猫中尤为显著，暹罗猫和波斯猫分别占受影响群体的34%和16%。暹罗猫患乳腺肿瘤的年龄较小（9岁，而非暹罗猫品种为14岁）[3]。

激素影响在发病机制中起着关键作用。早期卵巢子宫切除术提供显著保护，在6个月、12个月和24个月前绝育分别使猫的风险降低91%、86%和11%。然而，两年后绝育没有保护作用[3]。长期使用孕激素会增加两个物种的风险[3,4]。

### Sources
[1] Incidentally diagnosed mammary gland tumors are less likely: https://avmajournals.avma.org/view/journals/javma/261/10/javma.23.03.0133.xml
[2] Determining the optimal age for gonadectomy of dogs and: https://avmajournals.avma.org/view/journals/javma/231/11/javma.231.11.1665.xml
[3] Malignant mammary tumors: Biologic behavior, prognostic: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats
[4] Mammary gland tumors (Proceedings): https://www.dvm360.com/view/mammary-gland-tumors-proceedings

## 常见病原体

犬和猫的恶性乳腺肿瘤主要是一种非传染性疾病，具有多因素病因学。目前的科学证据不支持病毒、细菌或其他传染性病原体是伴侣动物乳腺癌症发展的直接致病因素。

**病毒关联**
虽然一些研究调查了潜在的病毒联系，但尚未确定明确的因果关系。猫白血病病毒（FeLV）很少与特定肿瘤类型相关，如猫的脂肪肉瘤[1]。然而，FeLV主要通过免疫抑制和血液疾病引起癌症，受感染的猫会发展各种肿瘤，包括淋巴瘤[2]。该病毒不直接引起乳腺肿瘤，但可能通过损害免疫系统而增加整体癌症易感性。

**细菌考虑**
细菌病原体不被认为是恶性乳腺肿瘤的致病因素。虽然哺乳期母犬母猫可能发生细菌性乳腺炎，但这些炎症性疾病是与肿瘤转化不同的病理过程，不会导致癌症发展。

**非传染性病因学**
乳腺癌症的发病机制主要依赖于激素且是多因素的。激素影响、遗传易感性、年龄、品种因素和环境暴露在恶性转化中起主要作用[3]。缺乏传染性病因使乳腺肿瘤与其他许多兽医癌症区分开来，在这些癌症中病原体是已确定的风险因素。

### Sources
[1] Tumors of the Skin in Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[2] New vaccine protects against feline leukemia virus: https://www.dvm360.com/view/new-vaccine-protects-against-feline-leukemia-virus
[3] Mammary Tumors in Cats: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats

## 临床症状和体征

猫和犬的恶性乳腺肿瘤表现出不同的临床表现，需要在体格检查期间仔细评估。

**体格检查发现**
患有乳腺肿瘤的猫通常表现为多个肿瘤，诊断时高达40%的患者出现双侧乳腺受累[1]。肿瘤在乳头周围表现为可触及的离散结节或肿块，范围从几乎无法触及到跨越多个腺体的大肿块[2]。患有大型或长期存在的肿瘤的猫中，18%至25%会出现乳腺出血和溃烂[1]。在犬中，约50%表现为影响多个腺体的多个肿瘤，尾部腺体最常受累[2,3]。

**全身体征和进展**
宠物主人可能观察到非特异性的临床症状，包括体重减轻、食欲不振和嗜睡[1]。较少见的是，由弥漫性肺转移引起的运动不耐受、呼吸困难或发绀可能是主诉[1]。患有晚期转移性疾病或炎性乳腺癌的犬可能表现出全身临床症状，如疲劳、不适、体重减轻和食欲不振[2]。

**品种和物种特异性模式**
有趣的是，犬和猫约60-70%的乳腺肿瘤发生在最靠后的两个乳腺中[3]。暹罗猫似乎更频繁且在更年轻时（暹罗猫9岁 vs 非暹罗猫14岁）发生乳腺肿瘤[1]。肿瘤上方的皮肤可能受累并溃烂，约50%的猫乳腺肿瘤表现为溃烂[3]。

### Sources
[1] Malignant mammary tumors: Biologic behavior, prognostic factors, and therapeutic approach in cats: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats
[2] Mammary Tumors in Dogs - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[3] Mammary gland tumors (Proceedings): https://www.dvm360.com/view/mammary-gland-tumors-proceedings

## 诊断方法

诊断恶性乳腺肿瘤需要结合临床评估、细胞学评估、组织病理学检查和先进成像技术的系统方法[1]。

**临床评估和分期**
体格检查应包括准确的肿瘤测量和记录特征，如溃烂、与下方组织的固定以及淋巴结触诊[1]。约50%的猫乳腺肿瘤在诊断时表现为溃烂[2]。临床分期遵循改良的TNM系统，包括全血细胞计数、血清生化分析、尿液分析和三视图胸部X光检查[6]。强烈建议进行腹部超声检查，特别是对于患有乳腺肿瘤的猫，因为约25%可能有腹部转移[1]。

**细胞学和组织病理学评估**
应对肿块和区域淋巴结进行细针穿刺和细胞学检查[1][6]。细胞学检查更便宜、侵入性更小，并且可以在一些患者不使用镇静的情况下收集[7]。虽然细胞学通常足以确认细胞谱系和肿瘤性质，但可能不足以确定肿瘤病变是良性还是恶性[7]。深部切开活检和组织病理学检查对于明确诊断和分级仍然是必要的[2]。

**生物标志物评估**
在猫乳腺 carcinoma 中已评估了多种分子标志物，包括增殖细胞核抗原（PCNA）、嗜银核仁组织区（AgNORs）和Ki-67核抗原。PCNA和AgNOR计数与术后较短的生存时间相关[8]。

**先进成像**
计算机断层扫描或磁共振成像的先进断面成像有助于手术计划和评估局部肿瘤范围[5]。

### Sources
[1] What you need to know about mammary gland tumors: https://www.dvm360.com/view/what-you-need-know-about-mammary-gland-tumors-proceedings
[2] Mammary gland tumors (Proceedings): https://www.dvm360.com/view/mammary-gland-tumors-proceedings
[5] The latest from Dr. Sue Cancer Vet on feline injection-site sarcomas: https://www.dvm360.com/view/latest-dr-sue-cancer-vet-feline-injection-site-sarcomas
[6] Malignant mammary tumors: Biologic behavior, prognostic factors, and therapeutic approach in cats: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats
[7] Mammary Tumors in Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[8] Malignant mammary tumors: Biologic behavior, prognostic factors, and therapeutic approach in cats: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats

## 治疗选择

手术仍然是伴侣动物恶性乳腺肿瘤治疗的基石。肿瘤切除术适用于小型（<0.5 cm）、可移动的良性肿瘤[1]。对于恶性肿瘤，建议进行根治性乳房切除术，因为它比保守方法提供了显著更长的无病间隔（575-1,300天 vs 300-325天）[1][2]。

在猫中，双侧全链乳房切除术显示出优越的结果，与单侧手术相比，局部复发和转移率较低，但可能需要分期手术以最大限度降低发病率[4]。患有恶性肿瘤的犬从根治性乳房切除术中获益最大，一些研究表明所有恶性肿瘤病例都应接受这种方法以防止未来肿瘤发展[1]。

化疗方案通常采用基于阿霉素的方案。单药阿霉素显示出适度的疗效，而与环磷酰胺联合的方案在不可切除疾病中达到35-50%的反应率[2][8]。替代药物包括卡铂、米托蒽醌和环磷酰胺，尽管其有效性的证据仍然有限且相互矛盾[1][2][6][8]。

最近的进展包括针对晚期病例的靶向治疗，如托塞尼布磷酸盐，在猫中显示出良好的毒性特征[4]。放射治疗主要起姑息作用，用于不可切除的肿瘤或微观残留疾病[2][7]。在肿瘤切除时同时进行卵巢子宫切除术可显著提高两年生存率，特别是对激素受体阳性肿瘤有益[1]。

### Sources
[1] Current recommendations for mammary gland tumors in dogs: https://www.dvm360.com/view/current-recommendations-mammary-gland-tumors-dogs
[2] Malignant mammary tumors: Biologic behavior, prognostic factors, and therapeutic approach in cats: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats
[4] Mammary Tumors in Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[6] Elevated platelet-to-albumin ratio may predict worsened ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.01.0003/ajvr.25.01.0003.pdf
[7] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[8] Prognosis, treatment of canine mammary tumors: https://www.dvm360.com/view/prognosis-treatment-canine-mammary-tumors

## 预防措施

早期绝育是预防犬和猫恶性乳腺肿瘤最有效的策略。在犬中，第一次发情周期前绝育使乳腺癌风险降至0.05%，第一次发情后绝育风险增至8%，第二次发情后增至26%[1]。重要的是，第三次发情周期后进行绝育没有保护作用[2]。猫表现出更显著的保护作用，6个月大前绝育使乳腺肿瘤发展风险降低91%[3]。

身体状况管理是关键的二级预防措施。肥胖显著增加犬的乳腺癌风险，一项研究表明，当卵巢切除的犬在9-12个月大时保持瘦体型时，风险降低了40%[4]。相反，1岁时的肥胖使未绝育犬的乳腺癌发病率增加了近三倍[4]。环境因素也起作用，因为食用大量廉价品牌食品和饮食中红肉含量高的犬表现出更高的癌症风险[4]。

对于已经诊断为乳腺癌的犬，在肿瘤切除时同时进行卵巢子宫切除术可能会改善生存结果。最近的研究表明，在乳腺肿瘤手术后两年内绝育的犬生存时间延长[1]。无论生殖状况如何，都应强调终生体重管理，特别是在关键的第一年，以最大限度地降低整体癌症风险。

### Sources

[1] Performing an ovariectomy in dogs and cats: https://www.dvm360.com/view/performing-ovariectomy-dogs-and-cats
[2] What you need to know about mammary gland tumors: https://www.dvm360.com/view/what-you-need-know-about-mammary-gland-tumors-proceedings
[3] Mammary Tumors in Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[4] Prognosis, treatment of canine mammary tumors: https://www.dvm360.com/view/prognosis-treatment-canine-mammary-tumors

## 鉴别诊断

将恶性乳腺肿瘤与其他疾病区分需要仔细评估多个因素。最常见的鉴别诊断是乳腺纤维腺瘤，在一项研究中它占皮下肿块的53%，而乳腺 carcinoma 占12%[1]。纤维腺瘤是良性肿瘤，可能变得相当大但很少转移，这与恶性乳腺肿瘤不同。

需要考虑的其他肿瘤性疾病包括皮脂腺腺瘤、脂肪瘤和各种可能模拟乳腺肿块的皮肤肿瘤[2][4]。肥大细胞瘤是特别重要的鉴别诊断，因为它们是猫第二常见的皮肤肿瘤，可能表现为与乳腺肿块混淆的硬块[4]。

非肿瘤性疾病包括炎性乳腺疾病、乳腺炎和乳腺增生。在猫中，80-90%的乳腺肿瘤是恶性的，而在犬中只有50%是恶性的[3]。纤维上皮增生是年轻发情母犬的一种良性疾病，可导致乳腺显著增大，通过卵巢子宫切除术可有效治疗[5]。

良性和恶性病变的区别特征包括细胞学上的细胞形态、生长模式、溃烂和与下方组织的固定[7]。先进的热成像技术也有助于鉴别，恶性组织与脂肪瘤等良性肿块相比表现出不同的热扩散模式[8]。

### Sources

[1] Description of the prevalence, histologic characteristics: https://avmajournals.avma.org/view/journals/javma/249/10/javma.249.10.1170.xml
[2] Exotic mammal geriatrics (Proceedings): https://www.dvm360.com/view/exotic-mammal-geriatrics-proceedings
[3] Mammary Tumors in Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[4] Tumors of the Skin in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[5] Malignant mammary tumors: Biologic behavior, prognostic: https://www.dvm360.com/view/malignant-mammary-tumors-biologic-behavior-prognostic-factors-and-therapeutic-approach-cats
[6] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[7] A heat diffusion tool for canine dermal and subcutaneous mass screening: https://www.dvm360.com/view/a-heat-diffusion-tool-for-canine-dermal-and-subcutaneous-mass-screening

## 预后

**患有恶性乳腺肿瘤的犬和猫预后差异巨大。**手术可以治愈约75%患有乳腺肿瘤的犬，而患有乳腺肿瘤的猫通常预后较差[2]。这种物种差异反映了猫乳腺 carcinoma更具侵袭性的生物学行为，超过90%是恶性的，而犬约为50%[2]。

**肿瘤大小仍然是两个物种中最关键的预后因素。**在犬中，直径≥3 cm的肿瘤与不良预后相关[2]，而肿瘤直径≥2-3 cm的猫预后最差[2,4]。就诊时患有多个乳腺肿瘤的犬通常肿瘤位于各个部位，而患有多个肿瘤的猫通常表现为单个乳腺链内的多个肿块[4]。

**其他不良预后因素显著影响生存预期。**两个物种在淋巴结转移、高肿瘤分级和血管淋巴浸润时都会出现不良结果[2,4]。犬在炎性乳腺癌、癌肉瘤或导管性癌组织学类型时预后特别差，而猫表现出品种特异性变异，暹罗猫和三花猫预后更差[4]。

**辅助化疗可能改善选定病例的生存。**最近一项对手术后接受五剂阿霉素治疗的恶性乳腺肿瘤猫的研究表明，与历史对照组相比生存时间大约延长了一倍[4]。生活质量考虑仍然至关重要，因为即使患有侵袭性恶性肿瘤，许多癌症在适当治疗下也能延长并保持良好的生活质量[6]。

### Sources
[1] Mammary Tumors in Cats - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-cats/mammary-tumors-in-cats
[2] What you need to know about mammary gland tumors: https://www.dvm360.com/view/what-you-need-know-about-mammary-gland-tumors-proceedings
[3] Mammary Tumors in Dogs - Reproductive System: https://www.merckvetmanual.com/reproductive-system/mammary-tumors-in-dogs/mammary-tumors-in-dogs
[4] Mammary gland tumors (Proceedings): https://www.dvm360.com/view/mammary-gland-tumors-proceedings
[5] Incidentally diagnosed mammary gland tumors are less likely: https://avmajournals.avma.org/view/journals/javma/261/10/javma.23.03.0133.xml
[6] General introduction to veterinary oncology: Myths and misconceptions: https://www.dvm360.com/view/general-introduction-veterinary-oncology-myths-and-misconceptions-proceedings
