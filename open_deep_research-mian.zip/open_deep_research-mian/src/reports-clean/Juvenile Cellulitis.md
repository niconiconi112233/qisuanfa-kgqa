# 伴侣动物的幼年蜂窝织炎

幼年蜂窝织炎，通常被称为幼犬绞扼症，是一种影响幼犬的紧急皮肤病，兽医从业者必须及时识别和治疗。这种免疫介导性疾病表现为特征性的面部肿胀、脓疱性病变和明显的淋巴结病，需要立即进行皮质类固醇干预以防止永久性瘢痕形成。本报告通过对该无菌炎症性疾病的病理生理学、临床表现、诊断挑战和治疗方案的全面分析来探讨这一疾病。主要发现包括该疾病对金毛寻回犬和腊肠犬等特定品种的易感性，通过深度皮肤刮片将其与蠕形螨病区分开来的关键重要性，以及在发病后第一周内开始积极免疫抑制治疗时预后良好。

## 摘要

幼年蜂窝织炎是一种定义明确但经常被误诊的疾病，需要立即进行兽医干预。报告揭示了几项关键见解：该疾病的无菌性质将其与感染性脓皮症区分开来，细菌培养阴性是关键诊断特征。临床表现遵循可预测的模式--双侧下颌下淋巴结肿大、面部脓疱以及50%病例中的全身症状--然而该疾病需要在治疗前通过强制性深度皮肤刮片与蠕形螨病进行鉴别。

治疗方案在各来源中显示出显著的一致性，早期开始使用泼尼松龙2 mg/kg每日两次，持续4-6周可提供优异的治疗效果。报告确定了金毛寻回犬、腊肠犬和戈登雪达犬的品种易感性，表明存在遗传成分，这为繁殖建议提供了依据。

| 方面 | 主要发现 |
|------|---------|
| 诊断挑战 | 在皮质类固醇治疗前必须排除蠕形螨病 |
| 治疗反应 | 早期干预效果良好，延迟治疗会导致永久性瘢痕 |
| 预防 | 由于病因不明，预防措施有限；建议负责任的繁殖实践 |

兽医从业者应优先快速识别和积极治疗，以优化受影响幼犬的治疗效果，同时预防长期并发症。

## 疾病概述

幼年蜂窝织炎，也称为幼年脓皮症、幼犬绞扼症以及幼年无菌性肉芽肿性皮炎和淋巴结炎，是一种主要影响幼犬的罕见无菌炎症性皮肤疾病[1]。该疾病的特征是急性发作的面部肿胀、脓疱性皮炎和明显的淋巴结病，代表一种特发性免疫介导性疾病而非感染过程[1]。

该疾病通常影响3至12周龄的幼犬，尽管也有报道在2岁以下的老年犬中发生的罕见病例[1][2]。大多数病例发生在16周龄以下的幼犬中[2][3]。通常同一窝中的多只幼犬会受到影响，表明存在潜在的遗传成分[1]。虽然该疾病在许多品种中零星报道，但某些品种包括金毛寻回犬、腊肠犬、戈登雪达犬、拉布拉多寻回犬和指示犬可能易感[1][2][3][4]。由于该疾病的罕见性和经常被误诊为感染性脓皮症，伴侣动物群体中的确切发病率仍未得到充分记录[1]。

### Sources
[1] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions
[2] Pediatric emergencies (Proceedings): https://www.dvm360.com/view/pediatric-emergencies-proceedings
[3] Pediatric emergencies (Proceedings): https://www.dvm360.com/view/pediatric-emergencies-proceedings-0
[4] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings

## 常见病原体

幼年蜂窝织炎本质上是一种无菌炎症性疾病，意味着它在没有原发性感染病原体的情况下发生[1]。该疾病的特征是免疫介导的反应，而非细菌或病毒感染。使用特殊染色技术、电子显微镜和其他诊断方法检测感染病原体一直未能成功[2]。

脓疱性病变的细菌培养始终呈阴性结果，这是区分幼年蜂窝织炎与感染性脓皮症的关键诊断特征[1][2]。将患病犬的淋巴结组织接种到新生幼犬体内未能传播该疾病，这为其非传染性性质提供了有力证据[2]。

然而，随着疾病进展，继发性细菌感染可能使病情复杂化。受损的皮肤屏障和炎症环境可能使机会性细菌定植于病变部位，特别是在未保持适当伤口护理的情况下[1]。当根据细胞学或临床证据怀疑存在继发性细菌感染时，应在主要免疫抑制治疗的同时使用杀菌性抗生素，如头孢氨苄或阿莫西林-克拉维酸[2]。

幼年蜂窝织炎的无菌性质支持了当前的理解，即该疾病代表一种免疫介导性疾病而非传染性疾病[2]。这一基本特征解释了为什么该疾病对皮质类固醇的免疫抑制治疗反应显著，而单独使用抗微生物治疗则效果不佳。

### Sources
[1] Disorders of the Outer Ear in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/disorders-of-the-outer-ear-in-dogs
[2] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions

## 临床症状和体征

幼年蜂窝织炎在幼犬中表现为特征性的面部和全身表现，发展迅速。典型的临床体征包括明显的面部肿胀伴双侧下颌下淋巴结肿大，这通常先于皮肤病变的发展[1]。脓疱性病变通常出现在耳廓、眼周皮肤、口鼻部和嘴唇，经常破裂形成糜烂和结痂[1]。

患病犬通常发展为疼痛性脓疱性外耳炎，并可能出现鼻镜脱色素[2]。该疾病常常从皮肤体征进展到包括全身表现，如约50%病例中的发热、嗜睡和厌食[2]。关节受累，特征为无菌化脓性关节炎伴相关跛行和关节肿胀，发生在约25%的患者中[2]。

较少见的是，犬可能发展为无菌性化脓性肉芽肿性脂膜炎，表现为疼痛、波动的皮下结节，主要影响躯干、包皮或肛门周围区域[2]。这些结节可能形成瘘管，造成深的引流通道。下颌下淋巴结可能变得如此肿大，如果不治疗可能会破裂并形成瘘管性引流[2]。

虽然通常影响3-12周龄的幼犬，但幼年蜂窝织炎在老年犬中也有记录，包括一例9月龄拉布拉多寻回犬出现严重全身受累的显著病例[2]。金毛寻回犬、腊肠犬和戈登雪达犬可能对该疾病表现出品种易感性[2]。

### Sources
[1] Merck Veterinary Manual Image: Canine juvenile cellulitis: https://www.merckvetmanual.com/multimedia/image/canine-juvenile-cellulitis
[2] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions

## 诊断方法

诊断幼年蜂窝织炎需要结合临床评估、实验室分析和组织病理学检查的系统方法。诊断过程至关重要，因为该疾病必须与其他需要不同治疗方法的脓疱性皮肤病区分开来[1]。

**临床表现评估**

初步诊断主要依赖临床症状和病史。从业者应评估面部肿胀、凹形耳廓上的脓疱性病变和明显肿大的下颌下淋巴结--当这些特征同时出现在幼犬中时尤其重要[2]。该疾病通常伴有全身症状，包括发热、嗜睡和淋巴结病，这些可能是全身性而非局部性的[2]。

**实验室诊断**

细胞学检查是主要的诊断工具，通过从未破裂的脓疱进行Tzanck涂片检查。这显示化脓性肉芽肿性炎症，伴有非变性中性粒细胞和上皮样巨噬细胞，值得注意的是没有感染病原体[2]。深度皮肤刮片对于排除蠕形螨病至关重要，因为两种疾病都可能表现为淋巴结病和深度脓皮症[1]。

**组织病理学确认和影像学检查**

确诊需要组织病理学检查，显示结节性化脓性肉芽肿性皮炎伴毛囊炎和疖病[2]。应进行细菌和真菌培养以排除感染原因，因为阴性培养结果支持这种无菌炎症性疾病的诊断[2]。当怀疑存在全身受累时，影像学检查可能有益[3]。

### Sources

[1] Common mistakes in your veterinary dermatology workups: https://www.dvm360.com/view/common-mistakes-your-veterinary-dermatology-workups
[2] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions
[3] Fever of unknown origin (Proceedings): https://www.dvm360.com/view/fever-unknown-origin-proceedings-0

## 治疗选择

幼年蜂窝织炎需要及时和积极的免疫抑制治疗，以防止永久性瘢痕形成和并发症。治疗的基石是皮质类固醇治疗，口服泼尼松或泼尼松龙，剂量为2 mg/kg，分两次服用[1][2]。应在确诊后立即开始治疗以避免瘢痕形成，正如从业者所警告的那样[2]。

免疫抑制方案通常持续4-6周，在此期间逐渐减量[1][2]。一些难治性病例可能需要用地塞米松治疗代替泼尼松[1]。对于对标准皮质类固醇无反应的严重病例，环孢素10 mg/kg/天已被证明是有效的替代免疫抑制药物[2]。默克兽医手册证实了环孢素对皮肤免疫介导性疾病的有效性，指出其抑制T细胞增殖和减少炎症细胞因子产生的能力[3]。

继发性细菌感染很常见，需要同时进行抗生素管理。通常在皮质类固醇的同时使用杀菌性抗生素，如头孢氨苄或阿莫西林-克拉维酸，以治疗继发性脓皮症[1]。然而，主要治疗重点仍然是免疫抑制而非抗微生物治疗，因为该疾病本质上是无菌和免疫介导的。

支持性护理措施包括提供舒适的环境并监测并发症，如淋巴结破裂或全身受累。应告知主人，由于炎症病变的深度性质，即使经过适当治疗，一些瘢痕形成可能不可避免[1]。

### Sources
[1] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[2] Miscellaneous Diseases of the Pinna in Dogs and Cats: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/miscellaneous-diseases-of-the-pinna-in-dogs-and-cats
[3] Immunomodulators for Integumentary Disease in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/immunomodulators-for-integumentary-disease-in-animals

## 预防措施

由于幼年蜂窝织炎的特发性性质，其预防选择极其有限[1]。由于试图证明感染生物体或传播疾病的尝试均未成功，传统的预防方法如疫苗接种或与传染性动物隔离并不适用[1]。

治疗期间的环境管理侧重于维持最佳条件以支持愈合和预防继发并发症。环境应清洁且无压力，具有适当的温度控制和舒适的表面，以减少对受影响区域的创伤[1]。

虽然幼年蜂窝织炎本身不具有传染性，但在治疗期间隔离指南变得重要，以防止继发性细菌感染[1]。应密切监测受影响的幼犬是否有继发性脓皮症的迹象，这可能使原发病情复杂化[1]。

最有效的预防策略涉及负责任的繁殖实践。发生幼年发作全身性疾病的犬不应用于繁殖，因为遗传易感性似乎在疾病易感性中起作用[1]。金毛寻回犬、腊肠犬和戈登雪达犬可能对幼年蜂窝织炎易感[4]。

治疗期间的环境卫生至关重要，以尽量减少暴露于潜在的继发病原体[1]。定期清洁寝具、喂食区域和住房有助于减少可能加重炎症反应或延迟愈合的细菌污染。

### Sources

[1] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[2] Pediatric emergencies (Proceedings): https://www.dvm360.com/view/pediatric-emergencies-proceedings-0
[3] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions
[4] Juvenile cellulitis in dogs: 15 cases (1979-1988) in: Journal: https://avmajournals.avma.org/view/journals/javma/195/11/javma.1989.195.11.1609.xml

## 鉴别诊断

幼年蜂窝织炎必须与几种具有相似临床表现的疾病区分开来。主要的鉴别诊断包括蠕形螨病、皮肤癣菌病、细菌性脓皮症和药物反应[1]。

**蠕形螨病**是最关键的鉴别诊断，特别是在幼犬中。在开始对疑似幼年蜂窝织炎进行皮质类固醇治疗前，深度皮肤刮片是必不可少的，因为两种疾病都可能表现为脓疱性病变、淋巴结病和眼周肿胀[1,2]。对于疑似幼年蜂窝织炎的幼犬，从业者应首先刮取蠕形螨，因为两种疾病都可能导致淋巴结病、深度脓皮症以及眼周区域和口鼻部肿胀[2]。

**皮肤癣菌病**可能模仿幼年蜂窝织炎，特别是当表现为结痂病变和继发性细菌感染时。真菌培养和皮肤癣菌检测至关重要，因为免疫抑制治疗在真菌感染中是禁忌的[2]。皮肤癣菌病和落叶型天疱疮在临床和组织学上有相似之处，包括产生棘层松解细胞，这使得在开始皮质类固醇治疗前进行真菌培养至关重要[2]。

**细菌性脓皮症**可能表现相似，但通常缺乏幼年蜂窝织炎中见到的特征性全身症状和明显淋巴结病。患有耳部疾病的幼犬应将幼年蜂窝织炎（"幼犬绞扼症"）列入鉴别诊断清单[3]。发病年龄和品种易感性有助于区分这些疾病。

**药物反应**应予以考虑，但当皮肤病变出现在用药之前时可能性较小[1]。幼年蜂窝织炎的快速发作和特征性分布模式通常可将其与药物引起的皮疹区分开来。

### Sources
[1] A challenging case: A febrile dog with a swollen tarsus and multiple skin lesions: https://www.dvm360.com/view/challenging-case-febrile-dog-with-swollen-tarsus-and-multiple-skin-lesions
[2] Common mistakes in your veterinary dermatology workups: https://www.dvm360.com/view/common-mistakes-your-veterinary-dermatology-workups
[3] Diagnosing and managing canine bacterial pyoderma-parts 1 & 2 (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-canine-bacterial-pyoderma-parts-1-2-proceedings

## 预后

当早期诊断并使用皮质类固醇进行适当治疗时，幼年蜂窝织炎的预后通常良好[1][3]。大多数幼犬对每日2.2 mg/kg的泼尼松龙治疗反应良好，红斑、肿胀和淋巴结病在几天到一周内显著改善[3]。

然而，早期开始治疗对于避免永久性瘢痕至关重要。病变的深度意味着即使治疗成功，也应预期一定程度的瘢痕形成[3]。为防止复发，皮质类固醇剂量必须在4-6周内根据临床反应逐渐减量[3]。

难治性病例可能需要用地塞米松治疗代替泼尼松龙以获得更好的治疗效果[3]。如果不治疗，该疾病被认为是紧急皮肤病病例，可能迅速进展[1][4]。需要以2mg/kg的剂量给予皮质类固醇一到两周以解决该疾病，并应同时给予广谱抗生素[4]。

经过适当治疗，长期并发症很少，但由于疾病的深度炎症性质，可能发生永久性面部瘢痕[3]。当在急性阶段得到适当管理时，该疾病似乎没有长期全身性影响。

### Sources

[1] NY Vet: Skin Conditions That Can Signal an Emergency: https://www.dvm360.com/view/ny-vet-skin-conditions-that-can-signal-an-emergency
[2] Disorders of the Outer Ear in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/disorders-of-the-outer-ear-in-dogs
[3] Pediatric dermatology (Proceedings): https://www.dvm360.com/view/pediatric-dermatology-proceedings
[4] Pediatric emergencies (Proceedings): https://www.dvm360.com/view/pediatric-emergencies-proceedings
