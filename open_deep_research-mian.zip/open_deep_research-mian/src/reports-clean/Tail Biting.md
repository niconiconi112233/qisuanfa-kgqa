# 伴侣动物咬尾症：综合兽医指南

咬尾症是犬猫中一种重要的行为障碍，由于其可能导致严重的身体并发症和潜在的福利问题，需要立即进行兽医诊疗。这种自我导向的行为通常始于应激反应，但可能迅速发展为强迫症，导致严重的组织损伤、继发性细菌感染和慢性疼痛。该病症影响多个品种，具有不同的易感性，需要全面的诊断方法来区分行为性、皮肤性、神经性和寄生虫性病因。本报告检查了临床表征、诊断方案、治疗策略和预防措施，这些对于小动物临床中有效管理咬尾症至关重要，为兽医提供了基于证据的方法来解决即时医疗需求和长期行为矫正。

## 摘要

伴侣动物的咬尾症表现为一种复杂的行为障碍，需要多模式兽医干预。该病症从最初的应激相关替代行为发展为可能导致严重组织损伤和继发性细菌感染的严重强迫症，病原体包括葡萄球菌属、链球菌属和巴斯德菌属。

临床表现从重复性旋转和追尾到伴有溃疡和脓皮症的严重自残不等。诊断需要全面的行为评估、体格检查和实验室检测，包括感染时的细菌培养。鉴别诊断包括皮肤真菌病、寄生虫感染、神经系统疾病和其他强迫行为。

治疗成功取决于通过药物干预（感染时使用抗生素，如氯米帕明或氟西汀等行为调节药物）、伤口管理和行为矫正来解决根本原因。预防重点在于环境丰富化、压力减轻和早期干预方案。

| 因素 | 良好预后 | 不良预后 |
|------|----------|----------|
| 根本原因 | 可识别的医疗状况 | 强迫症 |
| 主人依从性 | 高度遵守方案 | 药物/日常依从性差 |
| 干预时机 | 早期识别和治疗 | 慢性、已确立的行为 |
| 品种因素 | 无遗传易感性 | 易感品种（德国牧羊犬、牛头梗） |

长期管理需要主人持续致力于环境改变和行为干预，某些病例需要终身治疗方案而非完全治愈。

## 疾病概述

伴侣动物的咬尾症是一种复杂的自我导向行为障碍，其特征是重复性咬、咀嚼或自残尾巴。这种情况被归类为异常重复行为，可表现为刻板行为或强迫症[1]。与正常的梳理行为不同，咬尾症没有适应功能，且常导致身体损伤，使其成为重要的动物福利问题。

该障碍通常源于潜在的压力、焦虑、冲突或挫折，最初表现为替代活动，最终发展为独立于原始触发情境的强迫行为[2]。某些品种表现出遗传易感性，德国牧羊犬和牛头梗特别容易发生追尾和自残行为[2]。

虽然咬尾症的具体患病率数据有限，但研究表明行为问题影响相当大比例的伴侣动物群体，一项研究显示犬类重复行为的估计患病率为14%至20%[3]。该病症通过造成身体创伤、继发感染和心理痛苦，显著影响动物福利。早期干预至关重要，因为这些行为可能根深蒂固，在严重情况下可能需要终身管理。

### Sources
[1] Self-directed behaviors in dogs and cats: https://www.dvm360.com/view/self-directed-behaviors-dogs-and-cats
[2] Repetitive behaviors in pets (Proceedings): https://www.dvm360.com/view/repetitive-behaviors-pets-proceedings
[3] Review of epidemiological, pathological, genetic, and ...: https://avmajournals.avma.org/view/journals/javma/259/10/javma.20.08.0462.xml

## 常见病原体

伴侣动物的咬尾伤口为继发性细菌感染创造了理想条件。最常分离的细菌病原体包括巴斯德菌属，常见于犬猫的口腔[1]。葡萄球菌属和链球菌属也经常从感染的咬伤伤口中培养出来，它们既是正常皮肤菌群又是机会性病原体[1][2]。

*犬咬二氧化碳嗜纤维菌*（*Capnocytophaga canimorsus*）是一种革兰氏阴性菌，通常存在于犬猫的口咽道中，由于其可能引起严重败血症而特别值得关注[2]。厌氧菌，包括拟杆菌属、梭杆菌属和消化链球菌属，可能在咬伤伤口的深部组织建立感染，这些部位的氧气水平较低[1]。

继发感染通常在初始咬伤创伤后八小时内发展[1]。这些感染的多微生物性质反映了来自动物口腔和受害者皮肤菌群的污染。*中间型葡萄球菌*（*Staphylococcus pseudintermedius*）被认为是犬类脓皮症的主要病原体，并可能使咬尾伤口复杂化[3]。耐甲氧西林金黄色葡萄球菌（MRSA）在某些病例中已成为额外的担忧，尽管大多数家庭宠物不太可能携带这种病原体[1]。

### Sources

[1] What you should know about people, pets, MRSA, and bite wounds: https://www.dvm360.com/view/transcript-what-you-should-know-about-people-pets-mrsa-and-bite-wounds

[2] Veterinarian to Veterinarian®: Lovesick for dogs? Unfortunately, yes: https://www.dvm360.com/view/veterinarian-to-veterinarian-lovesick-for-dogs-unfortunately-yes

[3] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats

## 临床症状和体征

伴侣动物的咬尾行为表现出独特的行为表现和由此造成的身体损伤。主要的行为体征是重复性旋转或追逐行为，随后抓住并咬尾巴[1]。这种强迫性活动通常会升级，占据动物大部分时间，并可能干扰正常的日常功能[2]。

身体伤口特征包括尾部裸露区域、脓皮症、红斑、溃疡和慢性自我创伤导致的苔藓样硬化[2]。在严重情况下，犬可能发展为继发性细菌感染，加剧瘙痒并延续这种行为[1]。尾尖通常显示反复损伤的证据，来自持续的咬尾发作。

犬通常表现出旋转行为伴随咬尾，这种行为可能最初在压力、冲突或焦虑期间出现[6]。该行为常常随时间变得强迫性，受影响的动物似乎难以从活动中分散注意力[1]。某些病例可能表现出相关的神经系统体征，包括背部皮肤波纹、发声和回避行为[1]。

某些品种表现出易感性模式，英国牛头梗、德国牧羊犬和澳大利亚牧牛犬是常见受影响的品种[2]。在猫中，咬尾可能与感觉过敏综合征相关，表现出额外体征如皮肤抽搐、过度梳理和剧烈的摇尾发作[1]。两个物种都可能表现出疼痛的继发症状，包括不愿让受影响区域被触摸以及在急性发作期间的行为改变[5]。

### Sources
[1] Self-directed behaviors in dogs and cats: https://www.dvm360.com/view/self-directed-behaviors-dogs-and-cats
[2] Dermatology and behavior (Proceedings): https://www.dvm360.com/view/dermatology-and-behavior-proceedings
[3] Recognition, assessment and scoring of pain in dogs and cats (Proceedings): https://www.dvm360.com/view/recognition-assessment-and-scoring-pain-dogs-and-cats-proceedings
[4] The chaos of compulsion: https://www.dvm360.com/view/chaos-compulsion
[5] Sporting dogs and aging--what chronic problems arise and how to diagnose them early (Proceedings): https://www.dvm360.com/view/sporting-dogs-and-aging-what-chronic-problems-arise-and-how-diagnose-them-early-proceedings
[6] Repetitive behaviors in pets (Proceedings): https://www.dvm360.com/view/repetitive-behaviors-pets-proceedings

## 诊断方法

诊断犬猫的咬尾症需要一种综合方法，结合行为评估、体格检查和实验室检测[1]。初始临床评估应侧重于识别潜在触发因素，包括压力、焦虑和医疗状况。诊断过程必须区分自伤创伤与其他尾部病变原因。

行为评估构成诊断的基石。临床医生应记录咬尾发作的频率、持续时间和周围情况。视频记录可以提供有价值的诊断信息，以评估动物独处时与主人在场时的行为[2]。环境因素、日常的近期变化和并发行为体征应进行系统性评估。

体格检查需要仔细评估尾部及其周围组织。《默克兽医手册》提供了针对作为强迫症的尾巴自残的具体诊断指导，推荐包括皮肤刮片、毛干检查、真菌培养和活检在内的皮肤病学检测，以排除潜在的医疗状况[3]。治疗反应试验也可能指导诊断。

对于感染性病变，细菌培养和药敏测试指导适当的抗生素选择。深部伤口可能需要探查并发症，如骨髓炎。当怀疑骨骼受累时，可能需要进行X线摄影等高级影像学检查，特别是在持续性伤口或疑似骨髓炎的病例中。

### Sources
[1] Simple diagnostic tools in veterinary dermatology (Proceedings): https://www.dvm360.com/view/simple-diagnostic-tools-veterinary-dermatology-proceedings
[2] Dermatological Problems in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals
[3] Clinical Presentation and Medical Differentials for Compulsive Disorders-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/clinical-presentation-and-medical-differentials-for-compulsive-disorders

## 治疗方案

咬尾症的有效管理需要多模式方法，结合药物干预、伤口护理、行为矫正，有时还需要手术程序[7]。医疗治疗应解决根本原因和继发并发症，同时防止进一步自我创伤。

**药物治疗**
抗生素对于治疗继发性细菌感染至关重要，由于深部组织受累，通常需要持续疗程[7]。对于具有强迫或焦虑相关成分的病例，行为调节药物被证明是有益的。氯米帕明（犬1-2 mg/kg BID，猫0.5 mg/kg）或选择性血清素再摄取抑制剂如氟西汀（犬1-2 mg/kg每日，猫0.5-1 mg/kg）是强迫症的一线选择[8]。这些药物需要4-6周才能起效，如果反应不足，可能需要调整剂量[8]。

**伤口管理和物理干预**
即时伤口护理包括清洁、局部抗菌剂和防止持续创伤的保护措施[8]。在愈合阶段，可能需要伊丽莎白圈、绷带或防护服。在伴有广泛组织损伤或骨髓炎等并发症的严重病例中，可能需要手术清创或截肢[8]。

**行为矫正**
环境管理包括识别和消除压力源，增加精神和身体刺激，并建立结构化的日常作息[9]。反条件作用技术有助于将动物的注意力重定向到不相容的行为上。主人应奖励平静的行为，同时避免强化自我导向的活动[9]。

### Sources
[1] Self-directed behaviors in dogs and cats: https://www.dvm360.com/view/self-directed-behaviors-dogs-and-cats
[2] Self-trauma in dogs and cats: Is it medical or is it behavioral: https://www.dvm360.com/view/self-trauma-dogs-and-cats-it-medical-or-it-behavioral-proceedings
[3] Repetitive behaviors in pets: https://www.dvm360.com/view/repetitive-behaviors-pets-proceedings

## 预防措施

咬尾症的预防策略侧重于在自伤行为发展之前解决潜在的行为和环境因素[1]。环境丰富化是预防的基石，需要结构化的日常作息，包括通过训练、玩耍和物种适宜的活动进行定期社交互动[2]。

压力减轻方案涉及识别和消除宠物环境中的潜在压力源，包括不一致的日常时间表、不充分的社交接触或环境变化[3]。猫特别受益于多模式环境改造（MEMO），这已被证明可有效减少与压力相关的行为障碍和相关的自伤[4]。

早期干预方案强调在替代行为发展为强迫症之前对其进行干预。主人应只对与自我导向活动不相容的行为提供可预测的奖励，使用积极强化技术而非惩罚，因为惩罚可能增加焦虑并使问题恶化[3]。

关于风险因素的主人教育包括识别品种易感性，并了解某些遗传系可能更容易患强迫行为[2]。在关键发育期进行适当的社会化有助于防止基于恐惧的反应，这些反应可能导致日后出现自我导向行为[1]。

一致的环境管理防止接触触发情境，同时通过丰富玩具、攀爬结构和互动喂食装置提供正常行为的适当出口，这些装置鼓励自然的狩猎和觅食活动[3][4]。

### Sources

[1] Behavior Problems of Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/behavior/behavior-of-cats/behavior-problems-of-cats
[2] How to identify, treat self-injurious patients: https://www.dvm360.com/view/how-identify-treat-self-injurious-patients
[3] Self-trauma in dogs and cats: Is it medical or is it behavioral? (Proceedings): https://www.dvm360.com/view/self-trauma-dogs-and-cats-it-medical-or-it-behavioral-proceedings
[4] Is it medical or is it behavioral? (Proceedings): https://www.dvm360.com/view/it-medical-or-it-behavioral-proceedings

## 鉴别诊断

**其他可能与咬尾症表现相似的疾病包括几种皮肤病、寄生虫感染、神经系统疾病和影响尾部区域的行为状况。**

**皮肤病**代表最常见的鉴别诊断。皮肤真菌病可导致尾部区域脱毛、脱屑和瘙痒，受感染的毛发比正常粗大，显微镜下可见真菌孢子[1]。跳蚤过敏性皮炎通常影响犬的尾根和尾部区域，表现为丘疹结痂性病变和剧烈瘙痒[2]。疥螨病通常从包括尾部在内的区域开始，引起剧烈瘙痒和丘疹结痂性皮疹[3]。

**寄生虫感染**必须考虑，特别是狂蝇幼虫（肉蛆），它们形成界限清楚、瘘管性的皮下肿胀，最常见于夏秋季节。**最常见的鉴别诊断是脓肿或异物**，当检查狂蝇病变时[4]。其他外部寄生虫如姬螯螨属引起背部分布的脱屑和不同程度的瘙痒[3]。

**神经系统疾病**可能模仿强迫性追尾行为。**神经性疼痛或感觉异常可能与大量追尾、旋转和自残病例相关**[5]。局灶性癫痫可能表现为重复行为，特别是追尾或发作性舔舐行为[6]。脊髓疾病，包括椎间盘疾病或马尾综合征，当犬表现出尾部导向行为时应予以考虑[5]。

**行为状况**包括强迫症、寻求注意行为和刻板行为。有追尾行为的犬应筛查脊髓疾病、中枢神经系统疾病和肛囊疾病，以区分于原发性行为原因[5]。

### Sources
[1] Merck Veterinary Manual Dermatophytosis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[2] Merck Veterinary Manual Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[3] Merck Veterinary Manual Mange in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[4] Merck Veterinary Manual Cuterebra Infestation in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/cuterebra-infestation-in-dogs-and-cats/cuterebra-infestation-in-dogs-and-cats
[5] Medically evaluating canine and feline behavior patients: https://www.dvm360.com/view/medically-evaluating-canine-and-feline-behavior-patients-proceedings
[6] Help! My dog licks everything: https://www.dvm360.com/view/help-my-dog-licks-everything

## 预后

犬猫咬尾症的预后因根本病因、严重程度和主人对治疗方案的依从性而异[1]。早期识别和干预是关键的预后因素，因为慢性病例常发展为继发并发症，包括细菌感染和永久性组织损伤[2]。

对于具有可识别医疗原因的病例，如皮肤病、寄生虫感染或疼痛相关疾病，当潜在状况成功治疗时，预后通常良好[3]。然而，当咬尾症发展为强迫症时，完全解决变得更加困难，通常需要长期多模式管理[4]。

主人依从性是最重要的预后因素。成功需要一致的环境改变、行为干预和必要时药物管理[1]。主人未能维持结构化作息或过早停止治疗的病例预后不良，复发率高[1]。

某些品种的遗传易感性可能影响恢复潜力，有些动物需要终身管理而非治愈[1]。继发性细菌感染（当存在时）可能延迟愈合，但通常对抗生素治疗反应良好[5]。没有适当干预，严重病例可能发展为需要手术干预的自残，在极端情况下甚至需要截肢受损组织[1]。

### Sources

[1] Self-trauma in dogs and cats: Is it medical or is it behavioral? (Proceedings): https://www.dvm360.com/view/self-trauma-dogs-and-cats-it-medical-or-it-behavioral-proceedings

[2] Self-directed behaviors in dogs and cats: https://www.dvm360.com/view/self-directed-behaviors-dogs-and-cats

[3] Wound Management - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/emergencies/wound-management

[4] Seizures and status epilepticus (Proceedings): https://www.dvm360.com/view/seizures-and-status-epilepticus-proceedings

[5] Bone Trauma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
