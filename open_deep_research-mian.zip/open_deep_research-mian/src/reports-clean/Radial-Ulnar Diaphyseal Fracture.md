# 伴侣动物桡尺骨骨干骨折

桡尺骨骨干骨折是影响犬猫前臂骨的重要骨科损伤，导致急性跛行和功能障碍。这些创伤性断裂发生在桡骨和尺骨的骨干区域，这些骨骼在正常运动中承受体重。该病症需要及时的兽医干预以恢复肢体功能并预防并发症。本报告探讨了从明显畸形到细微跛行模式的临床表现，利用放射学评估和体格检查技术的诊断方法，从保守外部固定到先进手术固定方法的综合治疗方案，以及可能影响患病动物长期结果的潜在并发症，包括延迟愈合和植入物失败。

## 疾病概述

桡尺骨骨干骨折是指犬猫前臂区域桡骨和尺骨骨干（骨干）发生的创伤性断裂[1]。骨干代表这些长骨的主要圆柱形部分，与干骺端和骨骺区域不同。

由于桡骨和尺骨平行的解剖排列以及在负重活动期间共同承受机械负荷，这些骨折通常同时影响两根骨骼[2]。前臂（前臂）是一个关键的负重结构，使得这些骨折对活动能力和功能尤为重要。

多项研究表明，较轻的体重和增长的年龄是相关前臂手术并发症的重要风险因素[4]。大型和巨型品种犬似乎易患影响桡骨和尺骨的各种发育性骨科疾病，尽管骨折可发生在所有品种和体型中[5]。桡骨和尺骨也可能受到发育异常的影响，包括半肢畸形（骨骼部分或完全缺失），这是犬猫中最常见的肢体骨发育不良形式[7]。

治疗方法因骨折构型、患者因素和外科医生偏好而异。内部固定方法如骨板固定和外部骨骼固定技术都已用于管理这些损伤[1][3]。治疗方法的选择影响患病动物的愈合结果和并发症发生率。

### Sources
[1] Treatment of canine and feline diaphyseal radial and tibial fractures: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[2] Open reduction and cranial bone plate fixation of fractures: https://avmajournals.avma.org/view/journals/javma/250/12/javma.250.12.1419.xml
[3] Assessment of fracture healing after minimally invasive plate: https://avmajournals.avma.org/view/journals/javma/241/6/javma.241.6.744.xml
[4] Lower body weight and increasing age are significant risk: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0232.xml
[5] Developmental orthopedic disease: a clinical approach: https://www.dvm360.com/view/developmental-orthopedic-disease-a-clinical-approach
[6] Bone Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs
[7] Congenital and Inherited Anomalies of the Musculoskeletal: https://www.merckvetmanual.com/musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system/congenital-and-inherited-anomalies-of-the-musculoskeletal-system-in-dogs-and-cats

## 临床表现与诊断

桡尺骨骨干骨折表现出特征性临床症状，有助于快速诊断。动物通常显示受影响前肢急性发作的无法负重的跛行，伴有明显的前臂畸形和肿胀[1]。触诊骨折部位会引起疼痛，在操作过程中可能检测到骨擦音[2]。

体格检查显示局部软组织肿胀以及可能的肢体短缩或成角[3]。深部触诊干骺端区域可能中度至极度疼痛，特别是在伴有其他疾病的情况下[2]。远端桡骨和尺骨是常见的受影响部位，应评估双侧受累情况[2]。

放射学评估对于明确诊断和手术规划至关重要。标准正交视图（头尾位和内外侧位投影）清晰显示骨折模式、移位程度和任何粉碎情况[1]。放射学检查显示在典型表现中，两骨均为闭合性、线性、横行骨干骨折[1]。如果考虑矫正手术，真正的头尾位和内外侧位投影尤为重要[2]。

在复杂病例或怀疑伴有肘部病理时，可能需要CT等先进成像技术，因为骨折可能与其他发育性疾病相关[2]。正确的放射学定位至关重要，以避免可能模拟病理或掩盖真实损伤程度的伪影[4]。

### Sources

[1] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/232/11/javma.232.11.1637.xml
[2] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings
[3] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/260/3/javma.21.05.0254.xml
[4] Bone Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs

## 治疗选择

犬猫桡尺骨骨干骨折的治疗范围从保守管理到先进手术技术。对于骨骼愈合潜力良好的年轻动物，使用夹板或石膏进行外部固定的保守治疗可能适用于稳定、最小移位的骨折[2]。然而，由于不稳定性和移位，大多数骨干骨折需要手术干预。

**手术选择**

切开复位内固定（ORIF）仍然是桡尺骨骨折的金标准。骨板固定提供刚性稳定并允许早期活动[1,3]。对于玩具犬和迷你品种犬，专用的小型骨板可适应有限的骨骼尺寸[3]。外部骨骼固定提供了另一种方法，在存在软组织损伤或希望最小手术创伤时特别有益[4]。

线性外部固定在治疗猫的骨不连病例中已显示出高成功率[1]。微创钢板骨固定术（MIPO）已成为一种先进技术，在实现稳定固定的同时保留骨膜血液供应。

**治疗选择因素**

骨折构型、患者体型、骨骼质量和软组织状况影响治疗选择。患有简单骨折的年轻动物可能受益于微创方法，而复杂或粉碎性骨折通常需要刚性内固定[6]。术后护理包括活动限制、定期放射学监测以及可能的物理治疗，包括关节活动度练习、控制性牵引行走和水疗，以优化功能恢复[2]。

### Sources
[1] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[2] Physical rehabilitation: Improving the outcome in dogs with orthopedic problems: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems
[3] Open reduction and cranial bone plate fixation of fractures: https://avmajournals.avma.org/view/journals/javma/250/12/javma.250.12.1419.xml
[4] Limb Paralysis in Animals - Nervous System: https://www.merckvetmanual.com/nervous-system/limb-paralysis/limb-paralysis-in-animals
[5] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[6] Orthopedic surgery in small mammals (Proceedings): https://www.dvm360.com/view/orthopedic-surgery-small-mammals-proceedings

## 并发症与预后

桡尺骨骨干骨折与几种可能影响愈合结果的重要并发症相关[1]。常见并发症包括延迟愈合、骨不连、畸形愈合、感染和植入物失败[1][2]。这些并发症通常由植入物选择不当、骨折固定不充分或恢复期间患者活动过度引起。

**愈合并发症**分为三种主要类型。延迟愈合是指骨折需要比平均更长的愈合时间但维持持续的成骨活动[3]。骨不连骨折在三个月后显示无愈合活动证据，碎片保持可移动状态并需要手术干预[3]。畸形愈合描述以不正常解剖对位愈合的骨折，可能导致异常力传递和关节功能障碍[1]。

**植入物相关并发症**经常发生在为患者体型或骨折类型不恰当地选择钢板或螺钉时[1]。线性外部固定在治疗猫的骨不连病例中已显示出高成功率[2]。治疗成功通常取决于骨折部位的充分稳定性和生物学条件。

**预后因素**包括患者年龄、骨折构型、固定方法和主人对活动限制的依从性[3]。外部骨骼固定器通常比内固定方法促进更快的愈合[3]。年轻动物通常比老年患者表现出更好的愈合能力[4]。恢复前景通常良好，取决于损伤和手术成功，后续护理包括X光检查和兽医检查以评估愈合进展[4]。

### Sources
[1] Surgery STAT: Tailor your bone fracture repair technique: https://www.dvm360.com/view/surgery-stat-tailor-your-bone-fracture-repair-technique
[2] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[3] Treating fracture disease and nonunion fractures (Proceedings): https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings
[4] Bone Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs

## 预防与鉴别诊断

### 预防措施

预防桡尺骨骨干骨折侧重于高风险患者管理和环境改造。年轻、活跃的犬和骨骼天生脆弱的玩具品种需要特别关注[1]。体重管理至关重要，因为过重的体重会增加生长动物发育骨骼的压力[2]。在快速生长期限制活动有助于最小化创伤风险，特别是对于易患发育性骨科疾病的大型品种幼犬[2]。

环境安全措施包括移除可能导致跌倒或从高处跳下的危险。对于玩具品种，限制进入高处表面和提供安全的运动区域可降低骨折风险[1]。适当的营养而不过度补充可预防可能易致骨折的发育性骨疾病[2]。

### 鉴别诊断

几种骨科疾病表现出与桡尺骨骨干骨折相似的临床症状。全骨炎影响年轻、快速生长的犬，伴有急性跛行和长骨疼痛，但X光片显示特征性髓内密度而非骨折线[2][3]。肥大性骨营养不良导致生长犬的干骺端疼痛和肿胀，通过放射学上的特征性"双骨骺线"来区分[2][3]。

由骨骺过早闭合引起的肢体成角畸形可能导致慢性跛行而无急性创伤史[2]。关节创伤，包括脱位和关节内骨折，需要仔细的放射学评估以与骨干骨折区分[1]。骨肿瘤虽然在年轻动物中较少见，但在具有侵袭性放射学改变或不寻常临床表现的病例中应予以考虑。

### Sources
[1] Managing physeal and articular fractures (Proceedings): https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[2] Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/developmental-osteopathies-in-dogs-and-cats
[3] Developmental orthopedic disease: a clinical approach: https://www.dvm360.com/view/developmental-orthopedic-disease-a-clinical-approach
