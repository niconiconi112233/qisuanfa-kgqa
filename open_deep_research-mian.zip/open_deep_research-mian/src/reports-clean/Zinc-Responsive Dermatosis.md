# 伴侣动物的锌反应性皮肤病

锌反应性皮肤病是伴侣动物中一种重要的营养性皮肤疾病，特别是通过遗传性锌代谢缺陷或饮食缺乏影响特定犬种。该病症表现为眼睛、口周和受压点周围的特征性结痂性病变，常继发感染而复杂化。该疾病分为两种不同的综合征：I型通过遗传性吸收不良影响北极犬种，如阿拉斯加雪橇犬和西伯利亚哈士奇；II型发生在喂食缺锌饮食的快速生长大型幼犬中。本综合报告探讨了锌反应性皮肤病的病理生理学、临床表现、诊断挑战和循证治疗方案，为兽医从业者提供在小动物临床中识别、诊断和管理这种复杂皮肤病状的基本知识。

## 疾病概述与流行病学

锌反应性皮肤病是犬的一种遗传性皮肤病，特征为锌吸收或代谢受损，导致特征性皮肤病变。根据潜在病因和品种易感性，该疾病分为两种不同的综合征[1]。

**I型综合征分类与流行病学**
I型（遗传型）主要影响北方或北极犬种，包括阿拉斯加雪橇犬、西伯利亚哈士奇，偶尔也包括德国短毛指示犬[1][2]。其他报道的品种包括杜宾犬和大丹犬[3]。这种类型涉及家族性锌缺乏综合征，伴有饮食锌的肠道吸收不良[1]。受影响的犬尽管摄入足够的饮食锌仍会发展病变，因为阿拉斯加雪橇犬在小肠中仅吸收25%的锌，而正常对照组为100%[3]。

**II型综合征分类**
II型综合征发生在喂食缺锌饮食或含有高水平锌结合成分（如钙或植酸盐）的快速生长幼犬或年轻犬中[6][7]。这种类型影响大型至巨型犬种，包括大丹犬、德国牧羊犬、拉布拉多犬、标准贵宾犬和杜宾犬[3]。

**年龄和性别分布** 
I型的临床表现通常在断奶时或之后出现，最常见于1-3岁的年轻犬[6][7]。II型在快速生长的幼犬中变得明显。母犬在发情周期、分娩和哺乳期间可能出现症状加重[1]。

### Sources
[1] Cutaneous Manifestations of Multisystemic and Metabolic Defects in Animals: https://www.merckvetmanual.com/integumentary-system/congenital-and-inherited-anomalies-of-the-integumentary-system/cutaneous-manifestations-of-multisystemic-and-metabolic-defects-in-animals
[2] Congenital and Inherited Skin Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/congenital-and-inherited-skin-disorders-in-dogs
[3] Canine zinc-responsive dermatosis: https://www.dvm360.com/view/canine-zinc-responsive-dermatosis
[4] Common causes and signs of food intolerance in veterinary patients: https://www.dvm360.com/view/common-causes-and-signs-food-intolerance-veterinary-patients
[5] Diagnosing and managing canine bacterial pyoderma-parts 1 & 2 (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-canine-bacterial-pyoderma-parts-1-2-proceedings
[6] Diseases of the footpads (Proceedings): https://www.dvm360.com/view/diseases-footpads-proceedings
[7] Diseases of the footpads and nails (Proceedings): https://www.dvm360.com/view/diseases-footpads-and-nails-proceedings

## 病理生理学与临床表现

锌反应性皮肤病涉及锌代谢和吸收的复杂缺陷。受影响的犬，特别是北极犬种（西伯利亚哈士奇、阿拉斯加雪橇犬）和一些大型犬，表现出饮食锌的遗传性肠道吸收不良或更高的个体锌需求[1]。阿拉斯加雪橇犬由于无法将蛋白质结合的锌释放为非蛋白质结合状态，在小肠中表现出锌吸收减少（与正常对照组相比仅为25%）[2]。

病理生理学涉及锌缺乏破坏正常的表皮增殖和角质化。锌对300多种酶至关重要，并在细胞复制、免疫功能和皮肤屏障完整性中发挥关键作用[2]。缺乏导致特征性伴有角质细胞中保留细胞核的角化不全性角化过度[1]。

临床表现包括紧密粘附的浅棕色至黄色结痂，下方有红斑，主要影响眼周区域、皮肤黏膜交界处、受压点和四肢远端[1][2]。足垫角化过度很常见，特别是在I型综合征病例中[3]。病变通常开始为单侧，随着疾病进展变为对称性。被毛可能显得暗淡，伴有过多的皮脂分泌[2]。继发细菌和马拉色菌感染通常使病情复杂化[1][2]。在严重病例中，犬可能出现全身性症状，包括淋巴结肿大、发热和嗜睡[2]。

### Sources

[1] Miscellaneous Systemic Dermatoses in Animals: https://www.merckvetmanual.com/integumentary-system/miscellaneous-systemic-dermatoses/miscellaneous-systemic-dermatoses-in-animals
[2] Canine zinc-responsive dermatosis: https://www.dvm360.com/view/canine-zinc-responsive-dermatosis
[3] Diseases of the footpads (Proceedings): https://www.dvm360.com/view/diseases-footpads-proceedings

## 诊断方法与鉴别诊断

锌反应性皮肤病的诊断工作需要综合方法，结合临床表现评估、组织病理学评估和实验室检测，同时考虑多种可能呈现相似病变的鉴别诊断[1][2]。

诊断主要通过病史、临床检查和皮肤组织病理学进行，因为血清或毛发锌水平可能正常，由于固有的分析困难而不推荐[3]。特征性的组织病理学发现是明显的毛囊和表皮角化不全性角化过度，其中角质细胞保留其细胞核[1][3][5]。

全面的鉴别诊断必须包括落叶型天疱疮，它常见影响头部和爪部，具有相似的结痂性病变，但组织病理学通常表现为棘层松解[1][2]。浅表坏死性皮炎（肝皮肤综合征）呈现足垫和面部相似的角化过度，但显示特征性的"红、白、蓝"组织病理学，伴有明显的细胞间水肿[4][7]。其他鉴别诊断包括引起硬足垫病的犬瘟热病毒、皮肤癣菌和普通犬粮皮炎[1][2][4]。

实验室检测限制包括锌水平测量的不可靠性，由于污染问题和甲状腺功能减退等并发疾病的干扰[3]。应进行表面细胞学检查以识别继发细菌和马拉色菌感染，这些是常见并发症[3][7]。在临床表现和组织病理学与锌反应性皮肤病一致的病例中，诊断最终依赖于对锌补充治疗的反应。

### Sources

[1] Localized keratinization syndromes (Proceedings): https://www.dvm360.com/view/localized-keratinization-syndromes-proceedings
[2] Watch for these red flags in your veterinary derm exams: https://www.dvm360.com/view/watch-for-these-red-flags-in-your-veterinary-derm-exams
[3] Canine zinc-responsive dermatosis: https://www.dvm360.com/view/canine-zinc-responsive-dermatosis
[4] The management of common dermatological problems in older dogs (Proceedings): https://www.dvm360.com/view/management-common-dermatological-problems-older-dogs-proceedings
[5] Skin diseases responding to nutritional changes (Proceedings): https://www.dvm360.com/view/skin-diseases-responding-nutritional-changes-proceedings
[6] Diseases of the footpads (Proceedings): https://www.dvm360.com/view/diseases-footpads-proceedings
[7] Treatment of Superficial Necrolytic Dermatitis with Copper: https://meridian.allenpress.com/jaaha/article/59/1/1/489772/Treatment-of-Superficial-Necrolytic-Dermatitis

## 治疗选择

锌反应性皮肤病的治疗以使用多种剂型和特定给药方案的锌补充为中心[1]。口服硫酸锌是主要治疗方法，剂量为10 mg/kg每日一次，而静脉给药为10-15 mg/kg每周一次，共四次治疗[1]。替代剂型包括蛋氨酸锌1.7 mg/kg/天和葡萄糖酸锌1.5 mg/kg每日一次[1][3]。

饮食管理在治疗成功中起着关键作用。犬应接受营养均衡的商业饮食，同时避免高钙或高植酸盐食物，这些食物会结合锌并减少吸收[1]。将药片压碎并与食物混合可增强吸收，同时减少胃肠道不适[1]。

辅助疗法支持主要的锌治疗。皮质类固醇可能最初对瘙痒性犬有益，减少炎症并增强锌从肠道的吸收[2]。继发细菌和马拉色菌感染需要同时进行抗菌治疗，通常通过表面细胞学识别[2]。治疗这些感染对于获得最佳治疗反应至关重要[2]。

长期管理策略侧重于维持治疗性锌水平，同时监测并发症。某些病例可能需要同时给予糖皮质激素以获得最佳的锌吸收和临床疗效[3]。I型综合征犬（北极犬种）通常需要终身锌补充，而II型综合征犬可能通过解决营养缺乏的饮食调整产生反应[2]。

### Sources

[1] Canine zinc-responsive dermatosis: https://www.dvm360.com/view/canine-zinc-responsive-dermatosis

[2] Diseases of the footpads (Proceedings): https://www.dvm360.com/view/diseases-footpads-proceedings/1000

[3] Topical and systemic therapy for seborrheic disorders: https://www.dvm360.com/view/topical-and-systemic-therapy-seborrheic-disorders-parts-1-and-2-proceedings

## 预后

犬的锌反应性皮肤病预后因综合征类型和患者品种而异[1]。遗传性形式，特别是影响北极犬种如阿拉斯加雪橇犬和西伯利亚哈士奇的形式，在适当管理下通常预后更佳。这些犬通常对口服锌补充和饮食调整反应良好[1]。

饮食性锌缺乏或在快速生长阶段受影响的犬通常对治疗反应极佳。临床改善通常在开始锌治疗后4-12周内变得明显[1]。继发铜诱导病例的预后可能谨慎，如果潜在的肝病严重[2]。

然而，某些遗传性形式预后不良。牛头犬的致死性肢端皮炎是致命的，受影响的幼犬通常在2岁前死亡或需要安乐死[2]。尽管进行积极的医疗管理，这些犬对口服或静脉锌补充没有反应[2]。

长期管理要求在综合征类型之间差异显著。北极犬种通常需要终身锌补充和限制铜的饮食以防止复发。监测包括定期重新评估临床症状和锌水平，以及管理通常使病情复杂化的继发细菌和马拉色菌感染[1][2]。

### Sources

[1] Canine zinc-responsive dermatosis: https://www.dvm360.com/view/canine-zinc-responsive-dermatosis
[2] Cutaneous Manifestations of Multisystemic and Metabolic Defects in Animals: https://www.merckvetmanual.com/integumentary-system/congenital-and-inherited-anomalies-of-the-integumentary-system/cutaneous-manifestations-of-multisystemic-and-metabolic-defects-in-animals
