# 伴侣动物球虫病：综合兽医指南

球虫病是全球影响犬猫的最普遍的胃肠道寄生虫病之一，由宿主特异性的等孢球虫属原生动物引起。这种肠道感染主要影响4-12周龄的幼年动物，特别是在断奶或环境变化等应激期间。虽然大多数感染在健康的成年动物中呈亚临床状态，但临床疾病可在包括幼犬、幼崽和免疫功能低下宠物在内的易感群体中导致显著发病率。本报告为兽医专业人员提供有关病原体识别、临床识别、诊断方法、治疗方案和预防策略的循证指导，这些对于伴侣动物临床实践中球虫病的有效管理至关重要。

## 总结与临床意义

伴侣动物的球虫病是一种可管理的寄生虫病，如能正确诊断和治疗，预后极佳。该疾病主要影响12周龄以下的幼年动物，犬的主要病原体为犬等孢球虫和俄亥俄等孢球虫，猫的主要病原体为猫等孢球虫和里沃尔塔等孢球虫。临床表现从亚临床感染到严重出血性腹泻不等，诊断通过定量粪便漂浮法证实每克粪便中>5,000个卵囊，并伴有相应的临床症状。

| 方面 | 犬 | 猫 |
|--------|------|------|
| 主要病原体种类 | *犬等孢球虫*、*俄亥俄等孢球虫* | *猫等孢球虫*、*里沃尔塔等孢球虫* |
| 高峰风险年龄 | 4-12周 | 4-12周（断奶期） |
| 治疗持续时间 | 1-3周磺胺类药物 | 6天甲氧苄啶-磺胺 |
| 诊断阈值 | >5,000个卵囊/克粪便 | >5,000个卵囊/克粪便 |
| 预后 | 治疗后极佳 | 自限性，预后极佳 |

兽医从业者应通过蒸汽清洁优先确保环境卫生，并在收容所和繁殖设施等高风险环境中实施减压方案。早期使用磺胺类药物治疗结合支持性护理可确保临床症状快速缓解，并预防易感群体出现并发症。

## 疾病概述与流行病学

球虫病是一种由犬猫体内等孢球虫属（也称为囊等孢球虫属）细胞内原生动物寄生虫引起的胃肠道疾病[1]。影响犬的主要病原体是犬等孢球虫和俄亥俄等孢球虫，而猫主要感染猫等孢球虫和里沃尔塔等孢球虫[1,3]。这些寄生虫具有宿主特异性，犬猫之间不会发生交叉感染[1,5]。

球虫病在伴侣动物中极为常见。近期调查表明，约5%的收容所犬在其粪便中排出球虫卵囊[1,3]。该感染在全球范围内发生，可以认为所有犬猫在幼年时期都会接触到球虫卵囊[7]。大多数动物最终会被感染但不表现疾病，因为该疾病通常是自限性的[5]。

临床球虫病主要影响4-12周龄的幼年动物，特别是那些因断奶、运输或环境变化而经历应激的动物[1,3,5]。哺乳期动物、刚断奶动物或免疫功能低下个体最有可能发展为临床明显的感染[1,3]。成年动物可能排出卵囊，但由于获得性免疫很少发病[7]。潜伏期根据种类不同为5-9天，在宿主体内的发育周期需要这段时间才能开始产生卵囊[1,3]。

### Sources
[1] Emerging protozoal diseases (Proceedings): https://www.dvm360.com/view/emerging-protozoal-diseases-proceedings
[2] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs
[3] Important protozoal diseases and how to control them: https://www.dvm360.com/view/important-protozoal-diseases-and-how-control-them-proceedings
[4] Problems associated with intestinal parasites in cats: https://www.dvm360.com/view/problems-associated-with-intestinal-parasites-cats
[5] Overview of Coccidiosis in Animals: https://www.merckvetmanual.com/digestive-system/coccidiosis/overview-of-coccidiosis-in-animals
[6] Giardiasis and coccidiosis (Proceedings): https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings
[7] Canine and feline cryptosporidiosis and giardiasis: https://www.dvm360.com/view/canine-and-feline-cryptosporidiosis-and-giardiasis-proceedings

## 常见病原体

犬猫的球虫病完全由等孢球虫属（也称为囊等孢球虫属）引起[1]。这些寄生虫是专性细胞内原生动物病原体，表现出严格的宿主特异性，犬科和猫科物种之间不会发生交叉感染[1,4]。

在犬中，公认有四个不同种类：犬等孢球虫、俄亥俄等孢球虫、伯罗斯等孢球虫和新里沃尔塔等孢球虫[1]。只有犬等孢球虫可以仅通过卵囊形态学可靠地识别，因为其他三个种类在尺寸特征上有重叠，需要内源性发育特征进行区分[1]。犬的潜伏期约为三周[1]。

猫科球虫病涉及两个种类：猫等孢球虫和里沃尔塔等孢球虫[1,4]。这些种类可以通过卵囊大小和形态特征轻易区分，两者都严格宿主特异性于猫[4]。

所有等孢球虫种类都表现出涉及三个发育阶段的复杂生命周期：孢子生殖、裂体生殖和配子生殖[1]。生命周期包括通过摄入孢子化卵囊的直接传播和兼性使用转续宿主[1]。囊子虫可以在中间宿主（如啮齿动物）中形成包囊，当被终宿主摄入时作为感染阶段释放[1]。在最佳条件下，孢子化在6小时内发生，但通常需要7-10天[1]。

### Sources

[1] Coccidiosis of Cats and Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs

[2] Feline infectious diarrhea update (Proceedings) - dvm360: https://www.dvm360.com/view/feline-infectious-diarrhea-update-proceedings

[3] Problems associated with intestinal parasites in cats - dvm360: https://www.dvm360.com/view/problems-associated-with-intestinal-parasites-cats

[4] Giardiasis and coccidiosis (Proceedings) - dvm360: https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings

## 临床表现与发病机制

球虫病在犬猫中表现出不同的临床模式，年龄是疾病严重程度的主要决定因素。猫犬中的大多数感染没有临床症状[1]。临床疾病主要影响4-12周龄的幼年动物，特别是幼崽在断奶应激期间和幼犬在感染后约2周时[1]。

病理生理学涉及肠上皮和下层结缔组织的破坏，导致出血、卡他性炎症和腹泻[2]。重度感染可导致营养吸收减少、体液和电解质损失以及肠道损伤[1]。最显著的临床症状是腹泻，可能从粘液性发展为出血性，特别是在幼崽中严重的猫等孢球虫和里沃尔塔等孢球虫感染[1]。

临床症状包括出血性或粘液性腹泻、腹痛、脱水、贫血、体重减轻和呕吐[3]。其他表现可能包括在极端情况下的呼吸和神经系统症状[3,5]。死亡可能发生，特别是在幼犬和幼崽中[5]。亚临床感染的动物可能出现生长速度下降和饲料转化效率降低[6]。

几个因素影响疾病严重程度，包括并发感染、免疫抑制、应激、高卵囊暴露、营养不良、过度拥挤和断奶压力[1,2]。哺乳期动物、刚断奶动物或免疫功能低下个体更可能发展为临床明显的感染[3,5]。成年动物除非衰弱或免疫功能低下，否则很少出现临床症状[1]。

### Sources
[1] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs
[2] Overview of Coccidiosis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/overview-of-coccidiosis-in-animals
[3] Important protozoal diseases and how to control them: https://www.dvm360.com/view/important-protozoal-diseases-and-how-control-them-proceedings
[4] The Digestive System in Animals: https://www.merckvetmanual.com/digestive-system/digestive-system-introduction/the-digestive-system-in-animals
[5] Emerging protozoal diseases: https://www.dvm360.com/view/emerging-protozoal-diseases-proceedings
[6] Overview of Coccidiosis in Animals - Digestive System (AU): https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/overview-of-coccidiosis

## 诊断方法

伴侣动物球虫病的诊断主要依靠粪便检查来识别卵囊，但解释需要仔细考虑临床背景。使用饱和盐或蔗糖溶液的粪便漂浮法是标准诊断方法[1]。离心粪便漂浮技术与简单漂浮法相比显著提高了检出率，特别是对于等孢球虫卵囊的回收[3]。

卵囊识别需要定量评估，因为临床正常动物中偶尔可能发现卵囊。每克粪便中>5,000个卵囊计数伴有临床症状被认为是活动性感染的提示[2]。然而，>2,500个/克的卵囊计数可能表明潜在问题，取决于临床表现和受影响动物数量[2]。麦氏计数室提供标准化量化，但离心硫酸锌漂浮法在球虫检测方面表现出更高的敏感性[5]。

应尽可能进行种类鉴定，特别是在幼犬中，可能需要使用重铬酸钾进行人工孢子化以准确识别[1]。临床症状可能先于阳性粪便检查出现，因为腹泻的严重程度并不总是与卵囊排出高峰期相关[2]。

重要的诊断局限性包括发现健康和临床患病动物都可能排出卵囊，这意味着阳性结果不一定确认球虫病是疾病的主要原因[7]。由于间歇性排出模式，可能需要多次粪便检查[2]。

### Sources

[1] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs

[2] Overview of Coccidiosis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/overview-of-coccidiosis-in-animals

[3] Optimize intestinal parasite detection with centrifugal fecal: https://www.dvm360.com/view/optimize-intestinal-parasite-detection-with-centrifugal-fecal-flotation

[4] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs

[5] Giardiasis and coccidiosis (Proceedings): https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings

[6] Feline infectious diarrhea update (Proceedings): https://www.dvm360.com/view/feline-infectious-diarrhea-update-proceedings

[7] An update on feline infectious diarrhea (Proceedings): https://www.dvm360.com/view/update-feline-infectious-diarrhea-proceedings

## 治疗选择

### 药物干预

**磺胺类药物**是犬猫球虫病的一线治疗药物[1]。磺胺二甲氧嘧啶是最常用的磺胺药，第一天给予50 mg/kg，随后25 mg/kg每日一次，持续1-3周[3]。甲氧苄啶-磺胺组合也有效，以30-60 mg/kg/天给予6天（体重低于4公斤的小型犬剂量减半）[3]。

**三嗪类抗原生动物药**对球虫显示出良好的疗效。地克珠利（5 mg/kg口服一次）在猫中已被证明有效，而托曲珠利和 ponazuril（20-50 mg/kg口服2-5天）在犬猫中都表现出活性，尽管这些药物在大多数国家仍未获得许可[3]。这些较新的药物可能在治疗持续时间和耐药性模式方面提供优势。

### 支持性护理措施

大多数感染是自限性的，因此支持性护理至关重要[3]。受影响的动物必须保持温暖和充分水分，当发生脱水时提供个体化液体治疗和营养支持[3]。通过环境管理减轻压力有助于促进恢复，因为并发应激因素常常导致临床疾病表现[4]。

### 治疗监测

应在48-72小时内通过临床改善监测治疗反应[1]。如果出现良好反应，治疗应在临床症状缓解后继续48小时，以防止复发和耐药性发展[1]。在正常情况下，治疗疗程通常不应超过7天[1]。

### 环境管理

有效治疗需要同时进行环境消毒。蒸汽清洁对抵抗性卵囊最有效，而基于氨的消毒剂（动物不在场时）和10%氨溶液提供可靠的卵囊破坏[4,8]。彻底清洁 followed by 休耕期可显著减少再感染压力。

### Sources

[1] Merck Veterinary Manual Sulfonamides and Sulfonamide Combinations Use in Animals: https://www.merckvetmanual.com/pharmacology/antibacterial-agents/sulfonamides-and-sulfonamide-combinations-use-in-animals

[2] Merck Veterinary Manual Table: Dosages of Potentiated Sulfonamides: https://www.merckvetmanual.com/multimedia/table/dosages-of-potentiated-sulfonamides

[3] Merck Veterinary Manual Coccidiosis of Cats and Dogs: https://www.merckvetmanual.com/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs

[4] Merck Veterinary Manual Overview of Coccidiosis in Animals: https://www.merckvetmanual.com/digestive-system/coccidiosis/overview-of-coccidiosis-in-animals

[5] DVM 360 Giardiasis and coccidiosis (Proceedings): https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings

[6] Coccidiosis of Pigs - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/coccidiosis-of-pigs

[7] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs

[8] Parasitic Diseases of Rabbits - Exotic and Laboratory: https://www.merckvetmanual.com/en-au/exotic-and-laboratory-animals/rabbits/parasitic-diseases-of-rabbits

## 预防、鉴别诊断与预后

**预防**侧重于严格的环境卫生和消毒方案。在产仔和分娩区域必须保持严格的卫生，频繁清除粪便并防止饲料和水的粪便污染[1]。卵囊对大多数消毒剂具有高度抵抗力，可在环境中存活数月[1]。蒸汽清洁是最有效的消毒方法， followed by 休耕期后再重新占用[1]。

**鉴别诊断**包括多种需要系统调查的腹泻感染性原因。弯曲杆菌、梭菌、大肠杆菌和沙门氏菌等细菌病原体可通过培养检测[1][2]。包括冠状病毒、细小病毒和轮状病毒在内的病毒病因需要粪便或血液检测[1][2]。隐孢子虫卵囊可通过专门的粪便检查检测[1][2]。根据临床表现，还应考虑其他原生动物寄生虫和蠕虫感染[3]。

**预后**在适当管理下通常极佳。猫犬中的大多数感染会自发消除，因此在许多情况下不需要治疗[1]。该疾病是自限性的，死亡率通常较低[2]。临床球虫病通常仅在过度拥挤、卫生条件差或并发疾病等应激条件下发展[2]。暴露后，免疫力良好，特别是在猫中，提供对再感染的长期保护[1]。

### Sources
[1] Coccidiosis of Cats and Dogs - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/coccidiosis-of-cats-and-dogs
[2] Overview of Coccidiosis in Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/coccidiosis/overview-of-coccidiosis
[3] Giardiasis and coccidiosis (Proceedings): https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings
