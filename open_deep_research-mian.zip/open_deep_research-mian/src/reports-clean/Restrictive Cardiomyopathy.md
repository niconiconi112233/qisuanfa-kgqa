# 伴侣动物的限制性心肌病

限制性心肌病是猫类心脏病的一种严重形式，其特征为心肌纤维化，损害舒张期充盈，同时保持相对正常的心室壁厚度。这份全面的兽医报告检查了这种疾病的临床表现、诊断挑战和管理策略，该病主要影响中老年猫，中位年龄为10岁。该报告综合了当前兽医知识，包括病理生理学、超声心动图发现（包括限制性充盈模式和严重心房扩大）、治疗方案（强调呋塞米和抗凝治疗）以及预后因素。由于83%的病例出现呼吸窘迫，且总体预后不良，了解这种疾病对于管理猫类心脏急症和慢性心力衰竭病例的兽医从业者至关重要。

## 疾病概述和常见病原体

### 疾病概述

限制性心肌病是未分类心肌病的一个亚型，其特征为严重的舒张功能障碍和硬度增加，这是由于心内膜、心内膜下或心肌被纤维化浸润所致[1]。与肥厚性心肌病不同，限制性心肌病表现为正常或仅轻度增加的室壁厚度、正常或轻度降低的收缩功能以及心房扩张[1]。

限制性心肌病占猫类心肌病病例的一小部分。大多数患者是中年的雄性家养短毛猫，就诊时的平均年龄为10岁[3]。该病的特征是心肌纤维化损害心室充盈，导致严重的舒张功能障碍[6]。超声心动图可能显示连接左室的严重纤维带或广泛的左室心内膜心肌纤维化[6]。

该病预后不良，患病猫的中位生存时间为69天[3]。猫通常表现为严重的充血性心力衰竭症状，83%的病例在诊断时出现呼吸窘迫[3]。

### 常见病原体

限制性心肌病主要不是一种传染病，而是一种结构性心脏疾病。确切的病因在很大程度上仍然未知，没有特定的病毒或细菌病原体直接参与伴侣动物限制性心肌病的发展[1]。

该病通过非感染性途径发展，涉及心肌纤维化和浸润过程，损害舒张功能[6]。在某些情况下，先前的心肌炎可能是潜在原因，但纤维化改变的发病机制仍不清楚[8]。该病似乎是一种原发性心肌疾病过程，其特征是进行性纤维化，而不是通过直接病原体入侵。

### Sources

[1] Current strategies on diagnosis and treatment of feline cardiomyopathy: https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings
[2] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[3] Prognosis and Survival in Cats With Restrictive Cardiomyopathy: https://www.dvm360.com/view/prognosis-and-survival-in-cats-with-restrictive-cardiomyopathy
[4] Dyspneic cats: triage and differentiation of cardiogenic versus noncardiogenic causes: https://www.dvm360.com/view/dyspneic-cats-triage-and-differentiation-cardiogenic-versus-noncardiogenic-causes-proceedings
[5] Feline cardiovascular diseases: parts 1, 2, 3: https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

## 临床症状和诊断方法

猫的限制性心肌病表现为特征性的临床症状，主要与充血性心力衰竭有关。**呼吸窘迫（83%的病例）是最常见的就诊表现**，表现为呼吸急促和呼吸困难[1]。与患有心力衰竭的狗不同，猫很少咳嗽，因此呼吸频率评估对早期检测至关重要[1][3]。

**体格检查发现**包括体温过低（心力衰竭猫常见）、响亮的奔马律和偶尔的心脏杂音[1][5]。由于心输出量减少，猫可能表现出运动不耐受、食欲不振和四肢冰冷[3]。**62%的病例出现胸腔积液，34%出现肺水肿**[2]。

**超声心动图是诊断的金标准**，可显示限制性充盈模式、轻度收缩功能障碍和严重的左心房扩大[1][2]。诊断需要正常的左心室壁厚度、限制性左心室充盈模式以及左心房或双心房扩大[2]。**NT-proBNP检测**作为有价值的生物标志物，用于区分呼吸困难和呼吸原因，特别适用于急诊情况[1]。

**其他诊断工具**包括显示心脏增大和肺部变化的胸部X光片、显示左心房扩大和心律失常的心电图以及血压监测[4][7]。**心肌肌钙蛋白I**可能升高，表明心肌损伤[1]。可能需要使用脉冲波多普勒或组织多普勒成像的专门超声心动图技术进行明确诊断[8]。

### Sources

[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

[2] Prognosis and Survival in Cats With Restrictive Cardiomyopathy: https://www.dvm360.com/view/prognosis-and-survival-in-cats-with-restrictive-cardiomyopathy

[3] Heart Failure in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/heart-failure-in-cats

[4] Diagnosing heart failure (Proceedings): https://www.dvm360.com/view/diagnosing-heart-failure-proceedings

[5] Respiratory distress in cats and dogs (Proceedings): https://www.dvm360.com/view/respiratory-distress-cats-and-dogs-proceedings

[6] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

[7] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings

[8] Restrictive Cardiomyopathy in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/restrictive-cardiomyopathy-in-dogs-and-cats

## 治疗选择和预防措施

猫限制性心肌病的治疗仍然存在争议，兽医心脏病学家指出"对某些猫来说最好的治疗可能根本不治疗"[1]。管理决策取决于疾病严重程度、左心房扩大和临床症状的存在。

对于无症状猫，治疗通常保留给那些有明显左心房扩大、持续性心动过速或严重动态狭窄的猫[1]。阿替洛尔和地尔硫卓是常用药物，阿替洛尔在控制心动过速和减少二尖瓣收缩期前向运动方面更有效[1]。临床证据表明，在无症状猫中早期使用ACE抑制剂或利尿剂是不必要的[1]。

呋塞米仍然是治疗猫充血性心力衰竭最有效的方法，口服剂量为1-2 mg/kg，每8-24小时一次，或在急性病例中肠外给药1-2 mg/kg，每1-4小时一次[1,2]。初始住院治疗遵循F-O-N-S方案：呋塞米（强效利尿剂）、为呼吸困难患者补充氧气、硝酸甘油软膏用于静脉扩张以及为焦虑患者镇静[2]。氧疗（60-70%吸入氧）可用于急性心力衰竭，但应在12小时内降至50%以防止气压伤[1]。

慢性家庭治疗通常包括限制饮食钠和呋塞米，可能还包括螺内酯和ACE抑制剂[2]。对于有自发对比、心内血栓、既往血栓栓塞或严重左心房扩张的猫，使用氯吡格雷、阿司匹林或低分子量肝素进行抗凝治疗是适应症[1]。其他支持性治疗包括对选定病例使用匹莫苯等正性肌力药物[1]。

目前，限制性心肌病没有特定的预防措施，因为根本原因仍然未知[1]。

### Sources
[1] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies/1000
[2] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings

## 鉴别诊断和预后

### 鉴别诊断

限制性心肌病必须与其他表现出相似临床症状的心肌病进行鉴别。最具挑战性的区分是RCM和肥厚性心肌病之间的区别，特别是进展为限制性生理学的"耗竭型"HCM[1][2]。两种情况都可能表现为严重双心房扩大和充血性心力衰竭迹象。

超声心动图特征有助于区分RCM和HCM：RCM通常显示轻度或无左心室肥厚，心室大小正常或减小，而HCM则表现为明显的室壁增厚[2]。缩窄性心包炎代表另一个重要的鉴别诊断，尽管在猫中很罕见。RCM显示心内膜心肌纤维化伴心室充盈受损，而缩窄性心包炎涉及限制心脏充盈的心包增厚[3]。

未分类心肌病与RCM有很大重叠，区分通常取决于个体心脏病学家的解释[2]。RCM和扩张型心肌病之间的区别取决于心室腔大小和收缩功能。

### 预后

猫RCM的预后通常较差或谨慎。大多数猫在诊断时表现为明显的充血性心力衰竭或动脉血栓栓塞临床症状，表明疾病已进入晚期[2]。RCM特征性的广泛心肌纤维化导致舒张和收缩功能障碍，这通常是不可逆的。

患有RCM的猫由于严重的左心房扩大和血液淤滞而面临动脉血栓栓塞的高风险[2]。最近的抗凝治疗研究显示生存时间改善：接受氯吡格雷或利伐沙班进行二级预防的猫的中位复发时间为513-663天[1]。然而，生存很大程度上取决于潜在心脏功能障碍的严重程度以及并发症（如充血性心力衰竭或心律失常）的存在。

### Sources

[1] SUPERCAT study - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0584.xml
[2] Feline cardiovascular diseases (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[3] Feline hypertrophic cardiomyopathy, hypertension, and hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hypertrophic-cardiomyopathy-hypertension-and-hyperthyroidism-proceedings
