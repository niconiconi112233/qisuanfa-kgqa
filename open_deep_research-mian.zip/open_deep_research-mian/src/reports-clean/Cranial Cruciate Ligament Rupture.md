# 伴侣动物前十字韧带断裂

前十字韧带断裂是影响犬类最常见的骨科疾病，在美国每年造成约13.2亿美元的兽医费用。本综合报告探讨了这种致残性疾病的多个方面，从涉及退行性变化和遗传易感性的复杂病因病理学到兽医从业者可用的多种手术和保守治疗方法。

该报告综合了当前兽医知识，包括临床表现模式、先进影像技术在内的诊断方法，以及从关节囊外修复到TPLO和TTA等截骨术的循证治疗方案。特别关注了品种特异性风险因素、康复策略和长期预后考虑因素，这些因素直接影响小动物临床实践中的临床决策。

## 疾病概述与流行病学

前十字韧带断裂（CCLR）是犬类最常见的骨科问题，也是犬后肢跛行的主要原因[1]。前十字韧带起于股骨外侧髁的后内侧，插入胫骨前髁间区，功能是防止胫骨前移、屈曲时过度内旋和膝关节过度伸展[1]。

该疾病总体影响3-5%的犬，在美国估计造成每年13.2亿美元的重大经济影响[4,7,9]。CCLR表现出明显的品种易感性，罗威纳犬、拉布拉多寻回犬、纽芬兰犬、斗牛獒犬和松狮犬显示出特别的风险[7]。在纽芬兰犬中已发现隐性遗传模式，具有常染色体隐性遗传方式和部分外显率[7,9]。

多种风险因素促成CCLR的发展。绝育显著增加两性的风险，绝育母犬显示出稍高的发病率[2,7]。肥胖是主要风险因素，因为机械应力增加[6,7]。发病机制涉及随年龄增长和废用发生的退行性变化，通过成纤维细胞和胶原基质的丧失削弱韧带完整性[7]。这些退行性变化在大型品种中在较年轻时发展，解释了为什么20-40%的犬最终发展为双侧CCLR[7]。

### Sources
[1] Diagnosing cranial cruciate ligament pathology: https://www.dvm360.com/view/diagnosing-cranial-cruciate-ligament-pathology
[2] Age of neutering contributes to risk of cruciate ligament: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.06.0406.xml
[4] Cranial cruciate ligament disease is perceived to be prevalent: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.01.0004.xml
[6] Complications associated with lateral fabellotibial suture: https://avmajournals.avma.org/view/journals/javma/234/2/javma.234.2.229.xml
[7] Cranial cruciate ligament disease in the dog (Proceedings): https://www.dvm360.com/view/cranial-cruciate-ligament-disease-dog-proceedings
[9] Surgical management of cranial cruciate ligament disease: https://www.dvm360.com/view/surgical-management-cranial-cruciate-ligament-disease-proceedings

## 病因病理学与易感因素

犬类前十字韧带（CCL）疾病是一种复杂的多因素疾病，很少由纯创伤引起[1]。大多数病例涉及慢性退行性变化，这些变化随时间推移削弱韧带完整性，受损韧带在组织病理学检查中经常显示淋巴浆细胞性炎症[1]。

发病机制涉及多种易感因素。**年龄增长和退行性变化**起着核心作用，因为犬类在CCL内失去成纤维细胞，将存活的成纤维细胞转化为软骨细胞，并经历胶原基质恶化[4]。与小型品种相比，这些退行性变化在大型品种中发展得更早[4]。

**解剖学和生物力学因素**显著促进疾病发展。极端胫骨平台角（>35°）、髁间窝狭窄和伸直站立膝关节角度增加CCL应力[3]。具有"牛跗"姿势的犬将膝关节移至垂直负荷轴内侧，对韧带造成更大应力[3]。中年犬典型的久坐生活方式，加上肥胖，可能进一步降低CCL机械强度[3]。

**遗传易感性**已在某些品种中得到证实。纽芬兰犬显示常染色体隐性遗传，隐性等位基因频率为0.65，外显率为59%[3]。特别高风险的品种包括罗威纳犬、拉布拉多寻回犬、纽芬兰犬、斗牛獒犬和松狮犬[3]。与未绝育的对应犬相比，绝育公犬和母犬显示出增加的风险[2]。

多因素性质解释了为什么20-40%的犬发展为双侧CCL断裂[1,3]，因为潜在的易感因素影响两个肢体。

### Sources

[1] Decision making in cranial cruciate injuries (Proceedings): https://www.dvm360.com/view/decision-making-cranial-cruciate-injuries-proceedings
[2] Cranial cruciate ligament injuries in dogswhere to go next?: https://www.dvm360.com/view/cranial-cruciate-ligament-injuries-dogs-where-go-next/1000
[3] Cranial cruciate ligament disease in the dog (Proceedings): https://www.dvm360.com/view/cranial-cruciate-ligament-disease-dog-proceedings
[4] Diagnosing cranial cruciate ligament pathology: https://www.dvm360.com/view/diagnosing-cranial-cruciate-ligament-pathology

## 临床表现与诊断方法

现有内容全面涵盖了临床症状、体格检查发现和诊断影像学。我将结合来源材料的额外信息来增强鉴别诊断部分。

### 需考虑的鉴别诊断

除了已经描述的全面临床表现外，在评估疑似前十字韧带断裂时，必须考虑几个重要的鉴别诊断。后十字韧带损伤虽然不太常见，但可能表现为类似的跛行，应使用胫骨下沉征进行评估[2]。原发性或继发性关节炎可能模拟前十字韧带病理，特别是在有关节积液和退行性变化的病例中[2]。

淋巴浆细胞性滑膜炎综合征在高达10%接受前十字韧带手术的犬中被诊断，可能引起模拟十字韧带断裂的跛行[3]。这种免疫介导疾病可以通过滑液分析进行鉴别，滑液分析通常显示核细胞计数升高，主要为单核细胞炎症。

其他需要考虑的疾病包括髌骨脱位（可能伴随或引起前十字韧带断裂）、年轻大型品种犬的骨软骨病和膝关节肿瘤[5]。长趾伸肌腱撕脱虽然不常见，但引起膝关节外侧坚实肿胀和特征性放射学变化，包括伸肌窝作为股骨外侧髁的放射透亮缺陷突出[5]。

MRI等先进成像技术允许直接观察十字韧带和半月板，使其在检测体格检查或X光片上不明显的细微病理方面有价值[9]。应力MRI技术可以在临床发现不明确的病例中进一步提高诊断准确性[10]。

### Sources
[1] Diagnosing cranial cruciate ligament pathology: https://www.dvm360.com/view/diagnosing-cranial-cruciate-ligament-pathology
[2] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/227/6/javma.2005.227.883.pdf
[3] Joint Trauma in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/en-au/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[4] Decision making in cranial cruciate injuries (Proceedings): https://www.dvm360.com/view/decision-making-cranial-cruciate-injuries-proceedings
[5] Cranial cruciate ligament disease in the dog (Proceedings): https://www.dvm360.com/view/cranial-cruciate-ligament-disease-dog-proceedings

## 治疗选择

前十字韧带断裂的治疗包括保守管理、各种手术方法和全面的康复方案。最常推荐的手术技术包括用于大型犬的胫骨平台水平截骨术（TPLO）和用于小型患者的关节囊外修复[1]。

**保守管理**
对于体重低于15公斤的犬，可考虑非手术治疗，包括运动限制、体重管理、非甾体抗炎药和物理康复[2]。然而，手术干预通常提供更好的结果，医疗管理在没有并发半月板撕裂的较轻犬中获得更好的预后[3]。

**手术方法**
关节囊外稳定化利用外侧缝合技术，成功率为85-93%，并发症低于20%[2]。TightRope技术提供更好的等距性和优越的材料强度，达到94%良好至优秀的结果，主要并发症率为9%[4]。截骨技术（TPLO、TTA）无论选择何种技术，成功率约为90-95%[2][5]。与关节囊外修复相比，TPLO显示出优越的早期负重恢复，而TTA提供与TPLO相当的长期结果[2][3][5]。

**术后康复**
早期物理治疗干预可防止肌肉萎缩并改善结果[6]。方案包括术后立即冷冻疗法、被动关节活动度练习和渐进性强化活动[7][8]。八周复查方案确保在进展到强化运动之前手术部位适当愈合[6]。全面康复结合治疗性超声、控制性牵引行走、水疗和本体感觉训练，以优化功能恢复[8][9]。

### Sources
[1] Results of a survey of Veterinary Orthopedic Society members: https://avmajournals.avma.org/view/journals/javma/253/5/javma.253.5.586.xml
[2] Choosing cruciate rupture repair methods: https://www.dvm360.com/view/choosing-cruciate-rupture-repair-methods-proceedings
[3] Understanding tibial plateau leveling osteotomies in dogs: https://www.dvm360.com/view/understanding-tibial-plateau-leveling-osteotomies-dogs
[4] Cranial cruciate ligament tears: treatment options: https://www.dvm360.com/view/cranial-cruciate-ligament-tears-treatment-options-proceedings
[5] Surgical management of cranial cruciate ligament disease: https://www.dvm360.com/view/surgical-management-cranial-cruciate-ligament-disease-proceedings
[6] Rehabilitation of the cranial cruciate deficient stifle: https://www.dvm360.com/view/rehabilitation-of-the-cranial-cruciate-deficient-stifle-and-targeted-therapeutic-exercise
[7] Rehabilitation of canine athletes: https://www.dvm360.com/view/rehabilitation-canine-athletes-proceedings
[8] Physical rehabilitation: Improving the outcome in dogs: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems
[9] Importance of rehabilitation in your practice: https://www.dvm360.com/view/importance-rehabilitation-your-practice-how-get-started-proceedings

## 并发症与预后

### 手术并发症

前十字韧带断裂的手术修复根据所采用的技术带来各种并发症。关节囊外缝合修复报告总体并发症率为10-21%，包括25-80%病例的感染、持续关节不稳定和骨关节炎进展[1]。

TPLO手术显示并发症率约为26.3%，潜在并发症包括胫骨骨折、骨髓炎、植入物失败和半月板损伤[1]。TTA手术显示主要并发症率范围为12.3-38.0%，包括感染、植入物失败、胫骨嵴移位和内侧半月板撕裂[1]。

### 半月板损伤考虑因素

至少58%的CCL疾病病例发展为并发内侧半月板损伤，发病率随着韧带断裂程度的进展而增加[1]。术后半月板撕裂可能发生在任何修复技术中。无论是否进行预防性半月板释放，TPLO和TTA手术可能经历5-7%的后续半月板撕裂发生率[1]。

### 骨关节炎发展

除关节囊内修复外的所有手术修复技术都导致长期放射学骨关节炎进展[6]。尽管有手术干预，67%的TTA病例术后发展为进行性骨关节炎[1]。

### 预后因素

手术技术报告约90%良好至优秀的功能结果，无论方法如何[6]。然而，只有11-15%的犬在术后2-6个月时在手术肢体上达到正常的峰值垂直力[1]。保守管理在体重低于15公斤的患者中显示出更好的成功率[7]。

### Sources

[1] Surgical management of cranial cruciate ligament disease: https://www.dvm360.com/view/surgical-management-cranial-cruciate-ligament-disease-proceedings
[6] Managing cruciate disease-Where are we now?: https://www.dvm360.com/view/managing-cruciate-disease-where-are-we-now-proceedings
[7] Choosing cruciate rupture repair methods: https://www.dvm360.com/view/choosing-cruciate-rupture-repair-methods-proceedings
