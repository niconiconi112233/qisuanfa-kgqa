# 伴侣动物脂肪瘤：兽医综合指南

脂肪瘤是兽医临床中最常见的良性肿瘤之一，尤其影响老年犬，较少影响猫。这些脂肪组织生长物虽然通常无害，但需要适当的兽医评估以区分其恶性变体和浸润性形式，后者可能显著影响患者的生活质量。本报告探讨了伴侣动物脂肪瘤的临床表现、诊断方法、治疗选择和预后。关键主题包括犬猫病例的显著流行病学差异、细针抽吸在诊断中的关键作用、简单型和浸润性变体的手术管理策略，以及良性形式完全切除后的良好预后。

## 摘要

伴侣动物的脂肪瘤在兽医实践中呈现出独特的挑战和机遇。流行病学数据显示了显著的物种差异：犬，特别是某些品种（如杜宾犬和拉布拉多寻回犬）的老年肥胖雌性，表现出高度易感性，而猫的发病率明显较低，老年去势雄性暹罗猫最易受影响。细针抽吸仍然是基础诊断工具，显示出特征性的气球状成熟脂肪细胞，但与恶性变体的区分需要仔细的细胞学解释。

| 脂肪瘤类型 | 预后 | 治疗方法 | 复发风险 |
|-------------|-----------|-------------------|-----------------|
| 简单脂肪瘤 | 优秀 | 完全手术切除 | 完全切除后罕见 |
| 浸润性脂肪瘤 | 谨慎 | 广泛手术切缘，可能截肢 | 切除不完全时高 |
| 脂肪肉瘤 | 不良 | 广泛切除+放射治疗 | 尽管治疗仍常见 |

管理方法根据肿瘤类型显著不同。简单脂肪瘤通过直接手术切除提供优异的结果，而浸润性变体需要具有广泛切缘的积极手术干预。放射治疗为不可切除病例提供了有价值的替代方案，实现了超过58个月的令人印象深刻的生存率。由于遗传易感性，预防仍然有限，强调了早期检测和适当治疗干预对最佳患者结果的重要性。

## 疾病概述

脂肪瘤是由成熟脂肪组织组成的良性肿瘤，在犬和猫中都很常见[1]。这些肿瘤代表发育良好的脂肪细胞集合，在皮肤内或皮肤下发展[2]。

在犬中，脂肪瘤是最常见的皮肤肿瘤之一，尤其影响老年肥胖雌性[3]。该疾病表现出明显的品种易感性，杜宾犬、拉布拉多寻回犬、迷你雪纳瑞犬和混种犬风险最高[3]。犬通常在躯干和腿部附近发展脂肪瘤，大多数病例发生在中年至老年动物[3]。

与犬相比，猫表现出不同的流行病学模式。脂肪瘤在猫中相当少见，老年去势雄性暹罗猫表现出最高的易感性[1]。有趣的是，与犬不同，肥胖似乎不是猫脂肪瘤发展的促成因素[1]。当猫出现这些肿瘤时，最常位于腹部[1]。

这些肿瘤通常表现为柔软、离散、可移动的肿块，大小可能显著不同。虽然本质上是良性的，但脂肪瘤需要与其恶性对应物（脂肪肉瘤）和浸润性变体区分，因此兽医评估对于正确诊断和管理至关重要[2][3]。

### Sources

[1] Merck Veterinary Manual Tumors of the Skin in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats

[2] Computed Tomography Differentiates Forms of Adipose Masses in Dogs and Cats: https://www.dvm360.com/view/computed-tomography-differentiates-forms-of-adipose-masses-in-dogs-and-cats

[3] Merck Veterinary Manual Tumors of the Skin in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 临床表现和诊断

脂肪瘤表现为柔软、可移动的皮下肿块，大小可能显著不同[1]。它们通常表现为边界清晰、自由移动的肿块，触诊时感觉柔软或偶尔坚实[2]。脂肪瘤可以从非常小的结节到直径超过4英寸的大肿块[4]。

体格检查显示良性特征，包括离散、通常可压缩的肿块，通常不疼痛且在皮肤下自由移动[4]。然而，浸润性脂肪瘤可能感觉更牢固地附着于下层组织，并可扩散到肌肉和结缔组织[4]。

细针抽吸（FNA）是脂肪瘤的主要诊断方法[6]。抽吸通常产生油腻或油性物质，但细胞学检查是必要的，因为其他病理可能隐藏在脂肪组织中，包括肥大细胞瘤和软组织肉瘤[2]。细胞学上，脂肪瘤显示特征性的气球状成熟脂肪细胞，呈现为透明染色、折叠的细胞，通常成簇排列[1][3]。这些脂肪细胞与正常体脂肪相同，细胞学上无法与良性脂肪瘤区分[1]。

鉴别诊断包括浸润性脂肪瘤、脂肪肉瘤、肥大细胞瘤和软组织肉瘤[2][4]。脂肪肉瘤可以通过其纺锤形边界和大而突出的核在细胞学上区分，与良性脂肪瘤细胞的均匀外观形成对比[2]。当细胞学不确定或怀疑恶性肿瘤时，可能需要进行组织病理学检查[6]。

### Sources
[1] Merck Veterinary Manual Image: https://www.merckvetmanual.com/multimedia/image/fat-cells-typical-balloon-like-cytology
[2] DVM 360 Cytology for 3 common dermatological tumors: https://www.dvm360.com/view/cytology-for-3-common-dermatological-tumors
[3] Merck Veterinary Manual Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[4] MSD Veterinary Manual Tumors of the Skin in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[5] Overview of Tumors of the Skin and Soft Tissues: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/overview-of-tumors-of-the-skin-and-soft-tissues-in-animals
[6] Overview of Tumors reference: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/overview-of-tumors-of-the-skin-and-soft-tissues-in-animals

## 治疗选择和管理

手术干预仍然是犬猫脂肪瘤的主要治疗方法。对于良性脂肪瘤，完全手术切除是治愈性的，通常直接明了[1]。是否切除良性脂肪瘤取决于大小、位置、对正常功能的干扰和美观等因素。

**手术管理**

对于浸润性脂肪瘤，手术治疗带来更大挑战。首选的治疗方法包括具有正常组织广泛切缘的完全手术切除[1]。这种积极方法可能需要在肢体受影响的情况下截肢，特别是当肿瘤显著影响生活质量或导致功能限制时。

术前通过减肥计划进行饮食限制可以帮助外科医生更好地识别肿瘤边界，从而促进手术[1]。这种方法对于肿瘤边界可能被周围脂肪组织模糊的肥胖患者特别有益。

**先进治疗选择**

对于无法完全切除的浸润性脂肪瘤，放射治疗提供了有效的替代方案。常规分次放射治疗已显示出优异的长期生存率，中位生存时间达到1,760天（58.7个月）[2]。这种治疗方式在由于肿瘤位置或范围而无法完全手术切除时特别有价值。

**术后护理**

手术并发症通常不常见，但可能包括伤口愈合延迟，特别是在大肿瘤切除后。适当的伤口管理和适当的术后监测对于最佳结果至关重要。手术后的疼痛管理应解决术后即刻期和与广泛切除相关的任何慢性不适。

### Sources

[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

[2] Radiation Therapy in Animals - Therapeutics: https://www.merckvetmanual.com/therapeutics/radiation-therapy/radiation-therapy-in-animals

## 预防和预后

### 预防措施
脂肪瘤没有特定的预防措施，因为它们代表脂肪组织的良性过度生长，某些品种通常具有遗传易感性[1]。与猫的注射部位肉瘤不同，脂肪瘤与可预防的外部因素（如疫苗或药物）无关[1]。体重管理可能有益，因为脂肪瘤常见于老年肥胖犬，尽管肥胖在猫中似乎不是一个因素[1,4]。

### 预后和复发
简单脂肪瘤通过手术切除具有治愈性的优秀预后[1,4]。这些良性肿瘤不转移，完全切除后很少复发[1]。然而，许多脂肪瘤与周围健康脂肪组织融合，使完全手术切缘难以实现[1,5]。

**浸润性脂肪瘤**尽管转移潜力低，但预后更为谨慎[1]。这些被认为是中等恶性的肉瘤，很少转移但如果不完全切除倾向于局部复发[1]。具有广泛切缘的积极手术切除至关重要，有时需要截肢[1,5]。

**脂肪肉瘤**在脂肪肿瘤中预后最差，具有恶性潜力和局部复发倾向[1,4]。即使广泛手术切除，复发也很常见，通常需要后续放射治疗[1,4]。然而，与其他恶性肿瘤相比，它们的转移率仍然相对较低[1]。

### Sources

[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[2] Tumors of the Skin in Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[3] Tumors of the Skin in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
