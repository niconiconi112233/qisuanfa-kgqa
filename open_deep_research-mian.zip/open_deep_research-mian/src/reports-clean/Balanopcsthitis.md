# 犬猫龟头包皮炎：综合兽医指南

龟头包皮炎是阴茎和包皮黏膜的炎症，代表一种常见的生殖系统疾病，主要影响未去势的雄性犬，而在猫中较为罕见。此病症范围从性成熟犬的轻度生理性分泌物到需要强化医疗管理的严重炎症性疾病。区分正常包皮分泌物与病理性炎症对于适当的兽医干预至关重要。本报告探讨了多因素病因学，包括特发性淋巴浆细胞性炎症以及继发原因，如细菌过度生长、创伤和解剖异常。综合分析涵盖了利用细胞学和内窥镜检查的诊断方法，结合包皮冲洗与靶向抗菌治疗的循证治疗方案，以及影响小动物临床中长期预后的预后因素。

## 疾病概述与流行病学

龟头包皮炎是阴茎或包皮黏膜的炎症，主要发生于犬[1]。该病症涉及阴茎和包皮（覆盖阴茎的皮肤），炎症影响雄性生殖道的这些解剖结构。

该疾病表现出明显的物种易感性，在猫中**罕见**但在犬中常见[1]。在猫中，龟头包皮炎可能与持续性系带或阴茎周围毛发收缩带有关[1]。

轻度龟头包皮炎存在于许多性成熟犬中，通常无需治疗即可自发消退[2]。轻微的黏液性包皮分泌物在许多性成熟犬中被认为是正常的，临床意义不大[1]。然而，更严重的形式需要兽医干预。

虽然现有文献中未广泛记载特定的品种易感性，但由于正常的包皮分泌和暴露于潜在炎症因素的机会增加，该病症似乎更常见于未去势雄性[1][2]。流行病学数据表明，性成熟的未去势雄性犬是发展为临床显著龟头包皮炎的主要风险群体。

在种公犬繁殖力检查期间，诸如持续性系带、肿块或由龟头包皮炎引起的黏膜变化等问题可能阻碍种公犬的正常插入[3]。

### Sources

[1] Balanoposthitis in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/balanoposthitis-in-dogs-and-cats

[2] Reproductive Disorders of Male Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-male-dogs

[3] The Breeding Soundness Examination in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/the-breeding-soundness-examination-in-dogs-and-cats

## 病因学与发病机制

根据其潜在病因，龟头包皮炎可分为原发性或继发性[1]。原发性龟头包皮炎涉及来源不明的特发性淋巴浆细胞性炎症，其特征是没有可识别的诱发因素的情况下慢性炎症细胞浸润[1]。

继发性龟头包皮炎由各种潜在条件引起，包括细菌过度生长、阴茎创伤、阴茎或包皮肿瘤以及草芒等异物[1]。包括尿路感染和尿石症在内的尿路疾病可导致继发性炎症[1]。包茎或嵌顿包茎等解剖异常也易导致龟头包皮炎的发生[1]。

包茎定义为无法将阴茎从包皮中伸出，可能是先天性或获得性的[2][3]。先天性包茎由包皮开口狭窄引起，而获得性形式则由创伤或细菌性皮炎引起的慢性炎症发展而来[2][3]。其病理生理学涉及进行性炎症变化，导致包皮肿胀、尿液积聚和继发性细菌定植[3]。

龟头包皮炎的炎症过程涉及黏膜刺激，破坏了正常的包皮菌群，允许致病性细菌过度生长[1]。这创造了炎症和感染的自我维持循环，导致过多的黏液脓性分泌物和组织损伤[1]。

### Sources

[1] Balanoposthitis in Dogs and Cats - Reproductive System: https://www.merckvetmanual.com/en-au/reproductive-system/reproductive-diseases-of-the-male-small-animal/balanoposthitis-in-dogs-and-cats

[2] The Breeding Soundness Examination in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/the-breeding-soundness-examination-in-dogs-and-cats

[3] A challenging case: Phimosis in a young adult dog: https://www.dvm360.com/view/challenging-case-phimosis-young-adult-dog

## 临床表现与诊断方法

犬龟头包皮炎的主要临床症状是过多的包皮分泌物，通常表现为黏液脓性或黄绿色外观[2]。犬通常表现为持续舔舐包皮和阴茎远端[1]，但除了创伤、异物或蛇咬伤的情况外，很少出现疼痛
