# 犬猫肺动脉高压

## 疾病概述

**定义**

肺动脉高压是指犬猫平均肺动脉压力持续升高超过正常生理极限的状态（默克兽医手册，2024）。在犬中，正常肺动脉收缩压<25 mmHg，根据超声心动图三尖瓣反流速度测量，肺动脉高压分为轻度（30-50 mmHg）、中度（50-80 mmHg）或重度（>80 mmHg）（DVM360，2024）。这种情况由肺血管阻力增加引起，导致右心负荷加重、心输出量减少，并可能危及生命的心血管并发症。

**流行病学背景**

肺动脉高压主要影响小型犬、中老年犬，继发于退行性二尖瓣病的发病率最高（DVM360，2024）。某些品种表现出易感性增加，特别是患有慢性间质性肺病的西高地白梗，其中高达40%会发展为某种程度的肺动脉高压（DVM360，2024）。与犬相比，猫的病例在临床实践中较少被记录，但猫的病例在临床实践中越来越被认识。

最重要的风险因素是心丝虫病（犬恶丝虫），这在流行地区代表了肺动脉高压的主要寄生虫病因（默克兽医手册，2024）。其他易感条件包括肺血栓栓塞、原发性肺部疾病引起的严重低氧血症和左侧充血性心力衰竭。地理分布因心丝虫流行性和媒介存在而显著不同，由于微气候变化和蚊子媒介适应，许多气候区存在全年传播风险。

## 常见病原体

犬猫肺动脉高压主要由寄生虫感染引起，心丝虫病（犬恶丝虫）是最重要的病原体[1]。心丝虫成虫在肺动脉中的机械存在，加上对虫体抗原和沃尔巴克氏体内共生细菌的炎症反应，导致内皮损伤、血管重塑和进行性肺动脉高压[1]。

血管圆线虫（Angiostrongylus vasorum），被称为"法国心丝虫"，在犬中引起严重的肺动脉疾病[2]。这些14-25毫米的虫体栖息在肺动脉中，可导致逐渐进展的肺部疾病、心力衰竭和凝血病[3]。与犬恶丝虫不同，A. vasorum已出现在加拿大东部省份，需要螺类中间宿主[3]。

在猫中，猫圆线虫（Aelurostrongylus abstrusus）常引起肺蠕虫感染[3]。虽然感染这种寄生虫的猫可能发展为严重的肺泡疾病和肺血管变化，包括内皮破坏和血管壁肥厚，但它们通常不会发展为肺动脉高压或右心疾病[3]。

虽然细菌性肺炎是可能的，特别是幼猫伴有发热和炎性白细胞计数的血源性细菌性肺炎[4]，但寄生虫原因仍然是小动物中与肺动脉高压发展相关的主要病原体。肺动脉高压的原发性病毒原因在兽医文献中很少被记录。

### Sources

[1] Heartworm Disease in Dogs, Cats, and Ferrets: https://www.merckvetmanual.com/en/circulatory-system/heartworm-disease/heartworm-disease-in-dogs-cats-and-ferrets
[2] Severe pulmonary hypertension and cardiovascular sequelae in dogs: https://www.dvm360.com/view/severe-pulmonary-hypertension-and-cardiovascular-sequelae-dogs
[3] Canine and feline lungworms (Proceedings): https://www.dvm360.com/view/canine-and-feline-lungworms-proceedings
[4] What Is Your Diagnosis? in: Journal of the American ...: https://avmajournals.avma.org/view/journals/javma/261/1/javma.22.06.0252.xml

## 临床症状和体征

患有肺动脉高压的犬通常表现为运动不耐受、呼吸困难（气短）、咳嗽和晕厥（昏厥发作）[1][2]。这些临床症状是由于左右心室充盈不足导致的氧运输受损、心输出量减少和全身性低血压引起的[1]。

运动不耐受通常是主人首先注意到的迹象，犬表现出不愿进行体力活动或容易疲劳[1][2]。呼吸窘迫最初可能仅在用力时出现，但在严重情况下可能进展到休息时发生[2]。晕厥发作通常发生在运动或兴奋后，是较严重的表现之一[2][4]。

体格检查结果可能包括心脏杂音或分裂S2音、异常肺部声音、腹水和发绀[1]。严重肺动脉高压的临床症状通常是右心衰竭的症状，包括腹水、运动不耐受和颈静脉扩张伴搏动[4]。一些患有严重肺动脉高压的犬在休息时可能看起来相对正常，这使得早期检测具有挑战性[2]。

小型、中老年犬最常受影响，这与继发于退行性二尖瓣病的肺动脉高压高发病率相吻合[1]。某些品种，特别是患有慢性间质性肺病的西高地白梗，表现出增加的易感性，高达40%发展为某种程度的肺动脉高压[1]。

患有轻度至中度肺动脉高压的犬可能无症状，而患有严重疾病的犬可能经历猝死[1][2]。临床症状的严重程度通常与肺动脉压力升高的程度和潜在疾病过程相关。

### Sources

[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment

[2] Systemic and Pulmonary Hypertension in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/systemic-and-pulmonary-hypertension-in-dogs-and-cats

[3] Murmurs in puppies and kittens (Proceedings): https://www.dvm360.com/view/murmurs-puppies-and-kittens-proceedings

[4] Pulmonary Thromboembolism in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pulmonary-thromboembolism-in-dogs-and-cats

## 诊断方法

**临床表现评估**

肺动脉高压的准确诊断始于全面的临床评估。大多数受影响的犬是小型、中老年动物，主人通常报告运动不耐受、咳嗽、呼吸困难和晕厥[1]。体格检查可能发现心脏杂音、分裂S2音、异常肺部声音、腹水和发绀[1]。全面的实验室评估包括全血细胞计数、血清生化谱、心丝虫抗原检测和尿液分析，有助于识别易患肺动脉高压的潜在全身性疾病[1]。

**生物标志物和实验室检测**

心脏生物标志物提供有价值的诊断支持。与无相关肺动脉高压的呼吸系统疾病相比，临床III级肺动脉高压犬的NT-proBNP值升高[1]。心脏肌钙蛋白I浓度在各种临床级别的肺动脉高压犬中通常增加[1]。这些生物标志物有助于确认心脏受累和评估疾病严重程度。

**影像学技术**

超声心动图是肺动脉高压的金标准无创诊断工具[1][2]。三尖瓣反流速度测量使用改良伯努利方程估计肺动脉收缩压，而肺动脉反流速度估计舒张压[1]。正常收缩压<25 mmHg，分为轻度（30-50 mmHg）、中度（50-80 mmHg）和重度（>80 mmHg）[1]。

胸部X线摄影显示支持性发现，包括右侧心脏增大、肺动脉扩张和潜在肺部疾病模式[1][3]。右心导管插入术仍然是明确的诊断方法，但在不稳定患者中需要麻醉并具有高风险[2]。

### Sources
[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[2] The silent killer: pulmonary hypertension (Proceedings): https://www.dvm360.com/view/silent-killer-pulmonary-hypertension-proceedings
[3] Systemic and Pulmonary Hypertension in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/systemic-and-pulmonary-hypertension-in-dogs-and-cats

## 治疗选择

犬猫肺动脉高压的治疗侧重于解决根本原因，同时管理升高的肺动脉压力和相关临床症状[1]。

西地那非（1-3 mg/kg口服每8-12小时一次）是降低肺动脉压力和改善肺动脉高压犬临床症状的最有效药物[2]。这种5型磷酸二酯酶抑制剂促进肺血管舒张，已被证明可提高生活质量并将生存时间从几天延长到平均91天[1]。一些患者通过治疗已存活近两年[1]。

匹莫苯丹，一种提供正性肌力作用和PDE3抑制双重机制药物，已在继发于退行性二尖瓣病的肺动脉高压犬（临床II级）中显示出疗效[1]。然而，它不被认为是其他临床级别肺动脉高压的单药治疗有效药物[1]。匹莫苯丹也显示出在心力衰竭猫中降低肺动脉压力的益处[1]。

支持性护理包括为低氧血症患者提供氧气补充和使用利尿剂管理充血性心力衰竭[1]。治疗潜在疾病至关重要，如心丝虫杀成虫治疗、肺部疾病的抗炎药物或肿瘤原因的适当化疗[1]。

其他磷酸二酯酶抑制剂如茶碱可能在临床III级患者中提供适度益处，而他达拉非（1 mg/kg口服每12-24小时一次）临床数据有限，但由于潜在的全身性低血压应谨慎使用[1,2]。

### Sources
[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[2] Systemic and Pulmonary Hypertension in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/systemic-and-pulmonary-hypertension-in-dogs-and-cats

## 预防措施

### 一级预防策略

全年给予心丝虫预防药物是伴侣动物肺动脉高压预防的基石(1)。含有伊维菌素、米尔贝霉素、塞拉菌素或莫昔克丁的月度预防药物应在所有气候中全年持续给药，因为由于微气候变化和蚊子媒介适应，传播模式可能不可预测(1)。

即使对于接受预防的动物，定期心丝虫检测仍然至关重要。犬应在开始预防后6-7个月进行初始检测，然后进行年度抗原检测筛查(4)。这种预防加监测的双重方法确保早期发现可能进展为肺部并发症的突破性感染。

### 二级预防和监测

由于肺动脉高压最常见继发于心丝虫病、肺血栓栓塞、原发性肺部疾病引起的严重低氧血症和犬左心衰竭(5)，对高危患者的靶向监测变得至关重要。患有蛋白丢失性肾病、心内膜炎、心肌病、坏死性胰腺炎、免疫介导性溶血性贫血、败血症、肿瘤病以及接受手术的犬需要加强监测(6)。

血压测量应仅在已知引起高血压或出现系统性高血压临床问题的犬中进行(5)。定期心血管监测对于高危人群变得越来越重要，通过常规超声心动图评估检测肺动脉高压发展的早期迹象。

### Sources

[1] Heartworm Disease in Dogs, Cats, and Ferrets: https://www.merckvetmanual.com/circulatory-system/heartworm-disease/heartworm-disease-in-dogs-cats-and-ferrets
[2] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[3] How to get the most from the feline physical examination: https://www.dvm360.com/view/how-get-most-feline-physical-examination-lessons-learned-cats-proceedings
[4] 2022 AAHA Canine Vaccination Guidelines (2024 Update): https://meridian.allenpress.com/jaaha/article/60/6/1/503802/2022-AAHA-Canine-Vaccination-Guidelines-2024
[5] Systemic and Pulmonary Hypertension in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/systemic-and-pulmonary-hypertension-in-dogs-and-cats
[6] Pulmonary Thromboembolism in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pulmonary-thromboembolism-in-dogs-and-cats

## 鉴别诊断

肺动脉高压的临床和放射学表现与几种心血管和呼吸系统疾病重叠，因此准确的鉴别诊断对于适当治疗至关重要[1]。

**主要心血管鉴别诊断**包括伴有左侧充血性心力衰竭的退行性二尖瓣病、扩张型心肌病和其他右心衰竭原因。这些疾病可能表现出相似的运动不耐受、咳嗽和呼吸困难，但通常显示不同的心室增大和瓣膜功能障碍超声心动图模式[2]。

**需要鉴别的呼吸系统疾病**包括慢性支气管炎、猫哮喘、间质性肺病和肺血栓栓塞。这些疾病可引起相似的呼吸道症状，其本身也可能继发引发肺动脉高压[1][2]。

**关键鉴别因素**包括超声心动图发现，肺动脉高压显示特定的三尖瓣反流速度>2.8 m/s、右心室变化和肺动脉扩张。胸部X线片可能显示肺动脉增大和右心变化，这些与左侧心脏病模式不同[1]。

**生物标志物**有助于区分病因，升高的NT-proBNP支持心脏病，心脏肌钙蛋白I表明心肌损伤。然而，这些标志物在多种心脏病中可能升高[2]。

**物种特异性考虑**包括犬的心丝虫病，需要抗原检测，以及在猫中与猫哮喘鉴别，猫的肺动脉高压可能继发于慢性气道炎症。

### Sources

[1] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment

[2] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
