# 伴侣动物血管性水肿：临床指南

血管性水肿是小动物兽医实践中的一个重要临床问题，其特征是真皮深层和皮下组织的急性肿胀，最常影响面部区域。这种I型超敏反应常发生在疫苗接种、药物给药或过敏原暴露后，小型犬表现出特别高的易感率。了解快速的病理生理学、识别临床表现并实施适当的治疗方案对兽医从业者至关重要，因为严重病例可能发展为危及生命的过敏反应，需要立即干预。本综合指南 examines 了犬猫特有的流行病学、潜在机制、诊断方法、循证治疗策略和预防措施，为兽医提供了有效管理这种潜在严重疾病所需的临床知识。

## 疾病概述与流行病学

血管性水肿的特征是真皮深层和皮下组织的急性、非凹陷性肿胀，在伴侣动物中通常表现为涉及面部、头部和耳朵的局部水肿性肿胀[1]。这种情况代表一种I型超敏反应，常与荨麻疹（"风团"）一起作为过敏反应的一部分出现[1][2]。

在兽医医学中，血管性水肿最常作为疫苗后不良事件遇到，临床症状通常在接种疫苗后几分钟至2-3小时内出现，尽管主人可能在给药后长达8小时才识别出症状[1][2]。这种情况也可能由药物反应、食物过敏、昆虫叮咬或细菌感染引起[3]。最近的研究表明，血管性水肿被特别归类为涉及头部区域血管性水肿的1型（急性过敏反应）超敏反应[4]。

流行病学数据表明，小型犬面临更高风险，报告的总体疫苗反应率为每10,000只犬38.2例[2]。在一项超过450万只犬的全面5年研究中，31,197次疫苗接种就诊后发生了不良事件（0.19%，或19.4/10,000次就诊）[5]。成年犬（1-3岁）和某些品种包括腊肠犬、法国斗牛犬、波士顿梗、迷你杜宾犬和吉娃娃表现出增加的易感性[2][5]。法国斗牛犬的不良事件发生率最高，为55.9/10,000次就诊，其次是腊肠犬49.4/10,000次就诊[5]。在猫中，报告的疫苗不良事件率为每10,000只接种疫苗的猫51.6例，面部水肿是一种公认的表现形式[2]。

### Sources
[1] Adverse vaccination events (Proceedings): https://www.dvm360.com/view/adverse-vaccination-events-proceedings
[2] Adverse vaccination events: Separating fact from fiction (Proceedings): https://www.dvm360.com/view/adverse-vaccination-events-separating-fact-fiction-proceedings  
[3] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[4] Postvaccinal adverse events (Proceedings): https://www.dvm360.com/view/postvaccinal-adverse-events-proceedings
[5] Breed, smaller weight, and multiple injections are associated with increased adverse event reports within three days following canine vaccine administration: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.03.0181.xml

## 病理生理学与常见原因

犬猫的血管性水肿主要由涉及IgE抗体和肥大细胞脱颗粒的I型超敏反应介导[1]。当先前致敏的动物遇到过敏原时，结合到肥大细胞和嗜碱性粒细胞上的IgE抗体触发快速脱颗粒，在几秒到几分钟内释放包括组胺和肝素在内的预形成介质[2]。

病理生理级联反应涉及多种炎症介质。组胺约占肥大细胞和嗜碱性粒细胞重量的70%，通过组胺受体激活引起血管舒张和血管通透性增加[2]。这导致面部组织的特征性肿胀，特别是眼睛和口鼻周围。此外，花生四烯酸通路激活在暴露后5-30分钟发生，释放前列腺素和白三烯，这些物质持续引起血管变化[2]。

常见诱因包括疫苗，特别是含有佐剂和稳定剂如胎牛血清、卵蛋白、明胶和酪蛋白的疫苗[3][4]。昆虫叮咬和蜇伤是常见原因，犬因蜜蜂、黄蜂或蚂蚁毒液而经历面部血管性水肿[1]。药物反应，特别是对抗生素和非甾体抗炎药，可通过类似的IgE介导机制引发血管性水肿[3]。

食物过敏原代表另一个重要原因，尽管比环境诱因少见[5]。当过敏原交联表面结合的IgE抗体时发生反应，引发产生面部肿胀、荨麻疹的级联反应，如果为全身性反应，可能导致危及生命的过敏反应[1][2]。

### Sources
[1] Hypersensitivity Diseases in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals
[2] Navigating canine anaphylaxis: https://www.dvm360.com/view/navigating-canine-anaphylaxis
[3] Vaccine Failure and Other Adverse Events in Animals: https://www.merckvetmanual.com/pharmacology/vaccines-and-immunotherapy/vaccine-failure-and-other-adverse-events-in-animals
[4] Adverse vaccine reactions in veterinary medicine: an update: https://www.dvm360.com/view/adverse-vaccine-reactions-veterinary-medicine-update
[5] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis

## 临床表现与诊断

伴侣动物的血管性水肿表现为局部急性发作的非凹陷性水肿性肿胀，最常影响头部，特别是口鼻部、眼睑、耳朵和嘴唇[1]。与荨麻疹不同，血管性水肿涉及更深的真皮和皮下组织，形成大的、不对称的肿胀，触摸时可能发热但通常不瘙痒[1][2]。

临床症状发展迅速，通常在接触过敏原后几分钟到几小时内出现[3][4]。肿胀在指压下特征性地"凹陷"，并且是暂时性的，通常在24-48小时内不经治疗即可消退[1][2]。如果血管性水肿涉及喉部、咽部或鼻孔，可能出现呼吸窘迫，这代表兽医急症[1][4]。常见诱因包括疫苗反应、药物过敏（特别是抗生素）、昆虫蜇伤、食物过敏原和外用药物[3][4][5]。

血管性水肿常与荨麻疹一起作为I型超敏反应的一部分出现[3][5]。这种情况可影响任何年龄或品种的犬猫，尽管小型犬表现出更高的反应率[4]。

诊断主要基于临床，依据特征性外观和快速发作。专注于最近接触潜在过敏原的详细病史至关重要[1][5]。实验室检查很少必要，但可能包括显示嗜酸性粒细胞增多的全血细胞计数[1]。治疗包括抗组胺药、皮质类固醇，以及对严重过敏反应使用肾上腺素[3][4][5]。

### Sources
[1] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[2] Allergen-specific immunotherapy for canine atopic dermatitis: Making it work: https://www.dvm360.com/view/allergen-specific-immunotherapy-canine-atopic-dermatitis-making-it-work
[3] Adverse vaccination events (Proceedings): https://www.dvm360.com/view/adverse-vaccination-events-proceedings
[4] Adverse vaccination events: Separating fact from fiction (Proceedings): https://www.dvm360.com/view/adverse-vaccination-events-separating-fact-fiction-proceedings
[5] NY Vet: Skin Conditions That Can Signal an Emergency: https://www.dvm360.com/view/ny-vet-skin-conditions-that-can-signal-an-emergency

## 治疗与管理

**额外抗组胺药选择**
第二代抗组胺药通过阻断组成性和组胺诱导的H-1受体，比第一代药物提供更强的抗炎效果(6)。西替利嗪（1-4 mg/kg口服每24小时一次，持续3-5天）和羟嗪双羟萘酸盐（2 mg/kg口服每12小时一次，持续3-5天）是有效的替代药物(1)。氯雷他定显示出前景，而氯马斯汀在犬中效果有限(1,6)。在猫中，赛庚啶提供双重抗血清素和抗组胺活性，鉴于猫气道对血清素的敏感性，这使其特别有价值(6)。

**替代免疫抑制疗法**
对于糖皮质激素不耐受的患者，环孢素在5-7 mg/kg每日剂量下提供T细胞特异性免疫抑制(6)。霉酚酸酯通过选择性IMPDH酶阻断抑制淋巴细胞增殖(6)。达那唑（5 mg/kg每日2-3次）通过阻断巨噬细胞上的Fc受体在II型免疫介导疾病中显示出疗效(6)。

**辅助疗法**
己酮可可碱（10-15 mg/kg口服每日两次）通过减少TNF-α合成提供抗炎效果(6)。过敏原特异性免疫疗法在特应性患者中达到60-70%的成功率，一些病例在诱导阶段避免使用糖皮质激素时显示出改善(2,3)。必需脂肪酸补充剂和富含omega-3的饮食提供额外的抗炎支持(3)。

### Sources
[1] Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/urticaria/urticaria-hives-wheals-in-animals
[2] DVM 360: https://www.dvm360.com/view/allergen-specific-immunotherapy-canine-atopic-dermatitis-making-it-work
[3] DVM 360: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[4] DVM 360: https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings
[5] DVM 360: https://www.dvm360.com/view/navigating-canine-anaphylaxis
[6] DVM 360: https://www.dvm360.com/view/non-glucocorticoid-immunomodulation-small-animals-proceedings-0

## 预防与预后

**预防措施**

血管性水肿的主要预防策略涉及识别和避免已知诱因[1]。常见罪魁祸首包括疫苗、药物、昆虫叮咬和食物，尽管许多病例诱因不明[2]。对于有既往过敏反应史的患者，当无法避免潜在过敏原暴露时，应考虑预处理方案，包括预先使用抗组胺药和皮质类固醇[2][3]。

环境控制在预防中起着关键作用。仔细记录所有给药的药物、疫苗和治疗有助于识别模式和潜在诱因[1]。对于高危患者，维持紧急治疗方案并随时备有肾上腺素至关重要[1]。过敏原特异性免疫疗法可能对预防选定病例中复发性荨麻疹和血管性水肿有益[4]。

**预后因素**

血管性水肿的预后根据严重程度和及时治疗而有显著差异。简单的局部反应通常在12-48小时内自行消退，预后极佳[4]。然而，过敏反应可能危及生命，如不及时治疗死亡率很高[1]。

关键预后因素包括发作速度、全身受累程度和治疗开始时间。呼吸窘迫与犬过敏反应的死亡相关[1]。患有过敏性血腹的犬代表最危急的病例，需要立即使用肾上腺素和血液制品进行干预以获得最佳结果[1]。成功识别和避免诱因显著改善长期预后。

### Sources

[1] Navigating canine anaphylaxis: https://www.dvm360.com/view/navigating-canine-anaphylaxis
[2] Adverse vaccination events (Proceedings): https://www.dvm360.com/view/adverse-vaccination-events-proceedings
[3] Adverse vaccination events: Separating fact from fiction: https://www.dvm360.com/view/adverse-vaccination-events-separating-fact-fiction-proceedings
[4] Urticaria (Hives, Wheals) in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/urticaria/urticaria-hives-wheals-in-animals
