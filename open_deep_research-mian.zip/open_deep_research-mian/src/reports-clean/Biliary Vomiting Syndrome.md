# 伴侣动物胆汁呕吐综合征

胆汁呕吐综合征（BVS）是一种独特的胃动力障碍，影响犬类，特征是在禁食期间慢性间歇性呕吐胆汁染色液体。这种功能性疾病与传染性或炎症性胃肠道疾病有显著不同，为兽医从业者带来了独特的诊断和治疗挑战。虽然主要影响犬类，猫类很少受累，但BVS需要通过全面的临床评估系统地排除其他呕吐原因。本报告探讨了BVS的病理生理学、临床表现、诊断方法和治疗策略，借鉴当前兽医文献，为面对这一常被误诊疾病的小动物从业者提供循证指导。

## 疾病概述

**定义**
胆汁呕吐综合征是犬的一种功能性胃动力障碍，特征是慢性间歇性呕吐胆汁染色液体，通常发生在长时间禁食期间，最常见于清晨（默克兽医手册，2024年）。该病症代表原发性胃动力功能障碍，而非传染性或炎症性过程，这使其与其他胃肠道疾病相区别。

**流行病学背景**
BVS在犬中常见，但很少影响猫，兽医文献中未记载已确立的品种易感性（DVM360，2024年）。该病症可影响任何年龄或体型的犬，但在大规模流行病学研究中尚未确定具体的患病率。该综合征是小动物实践中常见被误诊的胃肠道疾病之一，通常需要通过全面的诊断评估系统地排除其他原因（DVM360，2024年）。与许多胃肠道疾病不同，BVS具有独特的时间模式和功能特征，这使其区别于伴侣动物的炎症性或传染性呕吐疾病。

## 常见病原体

虽然胆汁呕吐综合征主要是一种非传染性功能性疾病，但几种病原体可能在加剧或模拟BVS症状中发挥次要作用[1][2]。

**螺杆菌属**
*螺杆菌*属常见于健康和呕吐的犬猫中，研究报告称在这两类动物中的患病率高达100%[2]。非*幽门螺杆菌*生物体如*犬螺杆菌*、*猫螺杆菌*、*海尔曼螺杆菌*和*比佐泽龙螺杆菌*在小动物中比*幽门螺杆菌*更常见[2]。虽然胃炎和呕吐与*螺杆菌*感染相关，但尚未确立直接的因果关系[2]。*螺杆菌*作为主要病原体的作用仍不清楚，但同时检测到明显胃炎和*螺杆菌*生物体可能提示*螺杆菌*相关胃炎[2]。

**寄生虫考量**
胃肠道寄生虫可能导致类似BVS的慢性呕吐模式[5][6][7]。*泡翼线虫*属（胃线虫）影响犬和猫，常规粪便检查技术可能不易检测到[6][7]。这些胃线虫可引起胃炎，导致呕吐、食欲不振和黑便，通常在呕吐物中发现完整虫体时确诊[7]。*贾第鞭毛虫*属可引起慢性间歇性呕吐，应考虑在鉴别诊断中[6]。这些寄生虫可能加剧现有的动力障碍，或创造炎症条件而恶化胆汁呕吐发作。

### Sources
[1] Gastritis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-in-small-animals/gastritis-in-small-animals
[2] Helicobacter Infection in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-in-small-animals/helicobacter-infection-in-small-animals
[3] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[4] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease
[5] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[6] Controlling canine and feline gastrointestinal helminths: https://www.dvm360.com/view/controlling-canine-and-feline-gastrointestinal-helminths
[7] Gastrointestinal Parasites of Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/gastrointestinal-parasites-of-dogs

## 临床症状和体征

胆汁呕吐综合征表现出遵循可预测模式的独特临床特征[1]。标志性症状是清晨呕吐胆汁染色液体，通常发生在长时间禁食后胃排空时[1][3]。

患病犬表现出慢性间歇性呕吐行为，发作最典型地发生在清晨[5]。呕吐物因胆汁含量呈黄绿色，通常不含食物颗粒[3]。这种时间模式使BVS区别于其他胃肠道疾病。

呕吐前的行为体征包括恶心表现，如过度流涎、舔唇和频繁吞咽[3]。犬在呕吐发作前可能表现出不安行为或寻求主人关注[3]。一些动物在症状期间表现出抑郁或嗜睡。

与许多其他胃肠道疾病不同，BVS患犬通常在发作间期保持正常食欲，很少显示疾病的全身性体征[5]。除非病情严重或长期存在，否则体重减轻和虚弱不常见[5]。间歇性特征意味着犬在呕吐发作间期看起来完全正常。

物种差异值得注意，因为BVS在犬中常见，但很少影响猫[5]。尚未确立特定的品种易感性，尽管该疾病可影响任何年龄或体型的犬。该综合征代表原发性胃动力障碍，而非传染性或炎症性过程[5]。

### Sources

[1] Bilious Vomiting Syndrome in Dogs: Retrospective Study of 20 Cases (2002-2012): https://meridian.allenpress.com/jaaha/article-abstract/52/3/157/183330/Bilious-Vomiting-Syndrome-in-Dogs-Retrospective
[2] Vomiting in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/vomiting-in-dogs
[3] Diagnostic approach to vomiting (Proceedings): https://www.dvm360.com/view/diagnostic-approach-vomiting-proceedings
[4] Drugs That Affect Digestive Functions in Monogastric Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-digestive-system/drugs-that-affect-digestive-functions-in-monogastric-animals
[5] CVC Highlights: Don't miss these commonly misdiagnosed gastrointestinal diseases: https://www.dvm360.com/view/cvc-highlights-dont-miss-these-commonly-misdiagnosed-gastrointestinal-diseases

## 诊断方法

诊断胆汁呕吐综合征需要系统方法，强调排除其他原因。临床方法始于详细病史采集，重点关注呕吐的时间模式，特别是清晨胆汁染色发作以及与食物摄入的关系[1]。体格检查结果通常是非特异性的，但如果呕吐严重，可能揭示上腹部不适或脱水体征[2]。

最低数据库包括全血细胞计数、综合生化分析和尿液分析，以排除呕吐的系统原因，如肾衰竭、肾上腺皮质功能减退或肝脏疾病[3]。这些基础测试至关重要，因为它们可以排除可能表现出相似临床体征的严重代谢性疾病[9]。

高级影像学在诊断中起着关键作用。腹部X线平片可能识别胃扩张或异物[2]。当有指征时，对比放射学或钡剂检查可以显示胃排空障碍并排除机械性梗阻[1]。腹部超声检查允许评估胃壁厚度并评估肿块或炎症变化[5]。

内窥镜检查代表了诊断胆汁呕吐综合征的金标准，提供胃黏膜和十二指肠的直接可视化，同时允许组织取样[2]。即使黏膜外观正常，也应始终从胃和十二指肠获取多处活检，因为组织学病变可能在没有肉眼异常的情况下存在[2]。该程序还可以识别并发疾病，如慢性胃炎或螺杆菌感染。

胆汁呕吐综合征最终是一个排除性诊断，需要通过适当的测试和治疗试验系统地排除其他原因，包括食物过敏、寄生虫、代谢性疾病和炎症性肠病[9]。

### Sources

[1] Diagnostic approach to vomiting (Proceedings): https://www.dvm360.com/view/diagnostic-approach-vomiting-proceedings
[2] Vomiting and diarrhea--challenging clinical cases: https://www.dvm360.com/view/vomiting-and-diarrhea-challenging-clinical-cases-proceedings
[3] Difficult canine vomiting cases (Proceedings): https://www.dvm360.com/view/difficult-canine-vomiting-cases-proceedings
[4] Diagnosis and management of GI motility disorders: https://www.dvm360.com/view/diagnosis-and-management-of-gi-motility-disorders
[5] Diagnostic strategy for vomiting in dogs and cats: https://www.dvm360.com/view/diagnostic-strategy-vomiting-dogs-and-cats-proceedings
