# 伴侣动物病毒性肺炎

病毒性肺炎是犬猫中一种重要的呼吸系统疾病，特征是由各种病毒病原体引起的肺实质炎症。这种情况通常是继发性细菌感染的门户，大大增加了治疗和预后的复杂性。该疾病在不同物种中表现不同，犬瘟热病毒和犬流感是犬类的主要问题，而猫杯状病毒和疱疹病毒在猫类中占主导地位。本报告探讨了病毒性肺炎的完整临床情况，从最初的病原体接触到诊断挑战、治疗方案和长期结果，为兽医从业者提供在小动物临床实践中管理这些复杂呼吸系统病例的全面指导。

## 摘要

伴侣动物的病毒性肺炎是一种多方面的疾病，需要及时识别和积极的支持性护理。该疾病范围从轻微的上呼吸道症状到危及生命的肺炎，犬瘟热病毒、犬流感、猫杯状病毒和猫疱疹病毒是主要病原体。继发性细菌感染经常使病毒病例复杂化，将可控状况转变为可能致命的肺炎，需要强化抗菌治疗。

诊断成功依赖于将临床评估与分子检测相结合，特别是用于病毒识别的PCR检测和呼吸道样本的细胞学评估。胸部X线摄影显示特征性的间质模式，指导治疗决策。治疗以氧气治疗、继发性感染的抗菌覆盖以及包括雾化和物理治疗在内的全面支持性护理为中心。

通过核心疫苗接种方案进行预防仍然是疾病控制的基石，辅以环境管理和减压策略。预后因病原体毒力、患者年龄、免疫状态和继发性并发症的发展而有很大差异。早期干预显著改善结果，尽管完全恢复可能需要数周的强化管理。兽医从业者必须在呼吸道病例中保持对病毒性肺炎的高度临床怀疑，同时实施全面的诊断和治疗方案以优化患者生存率。

## 疾病概述

病毒性肺炎是由各种病毒病原体引起的肺实质（小气道、间质和肺泡）炎症[1]。这种情况代表了犬猫呼吸系统疾病的重要组成部分，常常导致继发性细菌侵入肺部。

在犬类中，病毒性肺炎通常是全身性疾病表现或传染性气管支气管炎复合体的一部分[2]。犬瘟热病毒感染的嗜上皮阶段伴有间质性肺炎，通常并发继发性细菌感染[2]。犬腺病毒1型和2型、副流感病毒和犬流感（H3N8）可引起轻度至重度肺炎，后者能够产生出血性肺炎[2]。犬流感于2004年首次出现在赛格雷伊猎犬中，代表从马流感的跨物种传播，此后已适应犬类[5][6]。

在猫类中，病毒性呼吸道病原体很少进展为肺炎，但可能导致继发性并发症。猫杯状病毒可从轻度上呼吸道疾病到病毒性肺炎不等，特别是强毒全身性毒株[3]。猫疱疹病毒-1主要针对上呼吸道上皮和结膜，很少超出这些区域引起肺炎[5]。环境因素显著影响疾病发展，包括过度拥挤、空气质量差、卫生条件差、压力、并发疾病和免疫抑制[4]。

风险因素包括幼龄（特别是幼犬和幼猫）、免疫功能受损状态、犬舍或收容所拥挤以及压力[1][4][9]。在收容所环境中每停留一天，CIRDC风险增加3%，使停留时间成为关键的流行病学因素[2][9]。

### Sources
[1] Pneumonia in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/en-au/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[3] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings-0
[4] Feline infectious respiratory disease (Proceedings): https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[5] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings-0
[6] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings
[9] Canine infectious respiratory disease: Challenges and considerations in animal shelters (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings

## 常见病毒病原体和临床表现

犬猫的病毒性肺炎主要由几种关键病原体引起，这些病原体表现出物种特异性模式，并常常导致继发性细菌并发症[1]。**犬瘟热病毒（CDV）**是影响犬类的主要病毒病原体，引起初始的嗜上皮阶段，伴有间质性肺炎[1]。临床症状包括发热、干咳进展为湿性排痰咳嗽伴呼吸音增强，以及包括呕吐和腹泻在内的全身表现[1]。

在猫类中，**猫杯状病毒（FCV）**和**猫疱疹病毒1型（FHV-1）**是主要的病毒性呼吸道病原体[6]。FCV对口腔黏膜和下呼吸道表现出特殊的嗜性，而FHV-1主要影响结膜和鼻腔通道[6]。两种病毒都引起打喷嚏、鼻分泌物、结膜炎、发热和流涎，尽管FCV更常与口腔溃疡相关，而FHV-1与角膜溃疡相关[10]。

**犬流感（H3N8）**引起从轻度犬舍咳嗽样症状到严重出血性肺炎的不同严重程度[2]。大多数病例表现为14-21天的病程，尽管有些表现为高热和脓性鼻分泌物[2]。**犬呼吸道冠状病毒**已成为疫苗接种良好的犬类的另一个重要病原体，影响上呼吸道和下呼吸道[2]。

继发性细菌感染代表所有物种病毒性肺炎发病机制的关键组成部分[1][2][4]。这些并发症通常涉及机会性病原体，包括犬类的*大肠杆菌*、*多杀性巴氏杆菌*、*肺炎克雷伯菌*和*铜绿假单胞菌*[4]。病毒对呼吸道上皮的损伤使患者易发生细菌过度生长和可能需要强化抗菌治疗的严重支气管肺炎[1][4]。

### Sources
[1] Upper airway troubles (Proceedings): https://www.dvm360.com/view/upper-airway-troubles-proceedings
[2] Emerging viral pathogens (Proceedings): https://www.dvm360.com/view/emerging-viral-pathogens-proceedings-0
[4] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[6] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[10] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings

## 诊断方法和技术

伴侣动物病毒性肺炎的诊断需要系统的临床和实验室评估。体格检查应评估呼吸频率、呼吸困难和胸部听诊模式，因为异常肺部声音可能表明肺泡或间质受累[1]。然而，仅凭临床症状不足以进行明确诊断。

**实验室检测**

通过经气管冲洗（TTW）或支气管肺泡灌洗（BAL）对呼吸道样本进行细胞学评估提供有价值的诊断信息[2]。BAL细胞学通常显示炎症细胞增加，中性粒细胞、巨噬细胞和嗜酸性粒细胞是主要细胞类型[4]。巨噬细胞不成比例降低（<80%）或中性粒细胞升高（>20%）表明炎症反应[1]。

**分子诊断**

PCR检测能够快速识别病毒病原体，通常优于培养方法[3]。RT-PCR可以在呼吸道样本、渗出液或血液中检测病毒RNA，尽管阳性结果需要临床相关性[10]。定量PCR可能有助于区分亚临床感染和活动性疾病[11]。对于PCR分析，应使用无菌棉或聚酯头拭子干性提交或使用无菌盐水提交，避免基于琼脂的运输培养基[11]。

**影像学检查**

胸部X线摄影显示特征性模式，包括支气管、间质或混合性肺部模式[6][7]。病毒性肺炎通常表现为间质模式，显示不透明度增加而无完全实变[8]。CT成像可能检测到X线上不可见的细微变化，并在需要时协助手术计划[8]。随着疾病进展，X线片可能显示弥漫性间质和支气管间质不透明度[11]。

**采样技术**

适当的样本收集对于准确诊断至关重要[3]。BAL应使用无菌技术进行，使用适当体积的无菌盐水以获得最佳细胞回收和病原体检测。样本必须及时处理以减少伪影和细胞恶化[11]。

### Sources

[1] Pneumonia in adult dairy cattle (Proceedings): https://www.dvm360.com/view/pneumonia-adult-dairy-cattle-proceedings
[2] Index to Subjects: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/62/12/ajvr.2001.62.2017.pdf
[3] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[4] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[5] A review of canine parainfluenza virus infection in dogs: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[6] Radiographic evaluation of pulmonary patterns and disease (Proceedings): https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[7] Thoracic radiography: Pulmonary interstitial patterns (Proceedings): https://www.dvm360.com/view/thoracic-radiography-pulmonary-interstitial-patterns-proceedings
[8] Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings
[9] Imaging of acute thoracic disease (Proceedings): https://www.dvm360.com/view/imaging-acute-thoracic-disease-proceedings
[10] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[11] Collection and Submission of Laboratory Samples from Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/collection-and-submission-of-laboratory-samples/collection-and-submission-of-laboratory-samples-from-animals

## 治疗策略和预防措施

病毒性肺炎的治疗侧重于支持性护理，因为特异性抗病毒药物有限[1][3]。氧气治疗对低氧血症患者至关重要，通过鼻导管或氧气箱以40-60%浓度输送[1][3]。继发性细菌感染需要基于培养和药敏结果的抗菌治疗（如果可能）[1][4][5]。

经验性抗生素选择包括广谱组合，如氨苄西林联合氟喹诺酮类或氨基糖苷类用于严重病例[4][5]。支持性护理包括通过雾化和叩诊进行肺部物理治疗、必要时使用支气管扩张剂以及维持黏膜纤毛清除的液体治疗[5]。抗菌治疗应在临床和影像学解决后继续一周[1][3]。

预防主要依靠疫苗接种方案。犬的核心疫苗包括瘟热、腺病毒和副流感，而猫接受疱疹病毒和杯状病毒疫苗[6][7][10]。减毒活疫苗比灭活产品提供更快速的保护（3-7天）[6][10]。环境控制措施包括适当隔离受影响的动物，尽可能使用单独的气流，以及使用适当消毒剂进行消毒[1][8]。

减压至关重要，特别是对猫的疱疹病毒再激活[7][10]。这包括最小化操作、提供适当的住房以及维持最佳种群密度以防止与过度拥挤相关的疾病爆发[7][8]。

### Sources
[1] Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Pneumonia in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[3] Pneumonia in Small Animals - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-small-animals?alt=sh&qt=treatment+for+cats+with+severe+bacterial+pneumonia
[4] Rational antibiotic choices for bacterial pneumonia in dogs (Proceedings): https://www.dvm360.com/view/rational-antibiotic-choices-bacterial-pneumonia-dogs-proceedings
[5] Therapy for bacterial pneumonia (Proceedings): https://www.dvm360.com/view/therapy-bacterial-pneumonia-proceedings
[6] Feline viral respiratory disease: To vaccinate or not to vaccinate? (Proceedings): https://www.dvm360.com/view/feline-viral-respiratory-disease-vaccinate-or-not-vaccinate-proceedings
[7] Feline infectious respiratory disease (Proceedings): https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[8] Canine infectious respiratory disease: Challenges and considerations in animal shelters (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings
[9] A retrospective analysis of canine, feline, and equine vaccination guidelines: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.11.0755/javma.24.11.0755.pdf
[10] Feline upper respiratory syndrome (Proceedings): https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings

## 鉴别诊断和预后

### 重叠疾病

病毒性肺炎必须与几种具有相似呼吸道表现的疾病区分开来[1]。细菌性肺炎是主要的鉴别诊断，通常表现出类似的呼吸困难和呼吸窘迫，但通常显示脓性分泌物并对抗生素治疗有反应[1]。

真菌感染，特别是曲霉病和组织胞浆菌病，可以模拟病毒性肺炎，伴有慢性咳嗽和X线上的间质模式[2]。肺肿瘤表现为进行性呼吸困难，但通常影响老年动物并在影像学上显示离散肿块[1]。

### 区分特征

关键区分因素包括发作模式、治疗反应和诊断结果[1]。病毒性肺炎通常急性发作伴有发热和全身症状，而细菌性病例通常显示脓性分泌物和气管冲洗液细菌培养阳性[1]。真菌性肺炎发展更缓慢，X线片上显示结节性间质模式[2]。

## 预后

病毒性肺炎的预后因病毒病原体、患者年龄和并发状况而有显著差异[1]。在没有继发性细菌性肺炎的情况下，恢复通常在临床症状出现后4-5天发生[10]。年轻和免疫功能受损的动物面临更高的死亡风险[7]。

继发性细菌感染显著恶化结果，严重受影响病例的死亡率可能很高[7]。肺炎通常难以逆转，受影响的动物通常有潜在的免疫缺陷，倾向于恶化而非恢复[7]。

早期干预支持性护理和预防继发性感染可提高生存率。发展为急性呼吸窘迫综合征的动物预后谨慎至不良。通过及时、积极的支持性治疗完全恢复是可能的，尽管一些患者可能发展为慢性呼吸道并发症[7]。

### Sources

[1] Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Pneumonia in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[7] The pneumonias of small mammals (Proceedings): https://www.dvm360.com/view/pneumonias-small-mammals-proceedings
[10] Viral Infections Associated with Bovine Respiratory Disease Complex in Cattle: https://www.merckvetmanual.com/respiratory-system/bovine-respiratory-disease-complex/viral-infections-associated-with-bovine-respiratory-disease-complex-in-cattle
