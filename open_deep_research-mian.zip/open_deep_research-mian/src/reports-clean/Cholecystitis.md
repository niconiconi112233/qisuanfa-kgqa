# 伴侣动物胆囊炎

胆囊炎，即胆囊的炎症，在小动物兽医实践中代表着一个重要的临床挑战，主要影响中老年犬，偶尔也影响猫。这种疾病的范围从轻度非坏死性炎症到严重的坏死性疾病，可能导致胆囊破裂和感染性腹膜炎。准确诊断需要结合临床表现和先进的影像学技术，而治疗方法从使用抗生素和支持疗法的医疗管理到紧急胆囊切除术不等。本报告探讨了胆囊炎的病理生理学、诊断方法和治疗策略，强调了早期识别和适当干预对于优化患者预后和预防危及生命的并发症的关键重要性。

## 摘要

胆囊炎是一种复杂的炎症性疾病，需要多方面的兽医管理。该疾病主要通过细菌上行感染影响成年犬，特别是大肠杆菌和肠球菌属，临床表现从餐后轻微不适到伴有黄疸和发热的急性腹部危机不等。

诊断成功取决于将胆囊壁增厚的超声检查结果与白细胞增多和肝酶升高的实验室证据相结合，而胆囊穿刺术可提供明确的细菌鉴定。治疗方案从轻度病例的广谱抗生素医疗管理到严重坏死性疾病的紧急胆囊切除术不等，选择性手术干预显示出显著改善的生存率（死亡率为2%，而紧急手术为20%）。

| 管理方法 | 生存率 | 主要适应症 | 主要优势 |
|-------------------|---------------|-----------------|-------------------|
| 医疗管理 | 不定 | 轻度、非坏死性病例 | 保守、成本效益高 |
| 选择性手术 | 98%生存率 | 早期疾病检测 | 优秀的长期预后 |
| 紧急手术 | 80%生存率 | 破裂、感染性腹膜炎 | 挽救生命的干预措施 |

通过内分泌疾病管理和高风险品种的早期检测进行预防提供了最佳的长期结果，而当医疗管理失败时，及时的手术干预提供了显著的生存优势。

## 疾病概述

胆囊炎是胆囊的炎症，代表了一系列影响这个位于右内侧肝叶和方形肝叶之间的梨形器官的炎症性疾病[1]。胆囊具有重要的生理功能，包括通过水和电解质吸收进行胆汁储存、浓缩和酸化[1]。

胆囊炎通常根据组织病理学特征分为不同类型。非坏死性胆囊炎涉及轻度炎症变化而无组织死亡，而当急性炎症与胆囊壁坏死相关时发生坏死性胆囊炎[2]。气肿性胆囊炎以胆囊组织内气体为特征，代表一种严重的变异，通常与糖尿病相关[1]。

最近的兽医文献表明，胆囊炎已成为犬肝外胆道疾病的重要原因，自2000年以来胆囊黏液囊肿的诊断日益增多[3]。该疾病常作为猫三联炎综合征的一部分出现，涉及并发性胆管炎、胰腺炎和炎症性肠病[4]。

从流行病学角度看，胆囊炎影响中老年犬，中位年龄为10-11岁，对小型到中型品种有偏好，包括设得兰牧羊犬、可卡犬和小型雪纳瑞犬[1][3]。真实发病率仍不确定，可能反映了通过改进的诊断影像技术增加了识别而非实际疾病患病率的增加[3]。

### Sources
[1] Managing disorders of the gallbladder in dogs (Proceedings): https://www.dvm360.com/view/managing-disorders-gallbladder-dogs-proceedings
[2] Examination of the thickness of the different ... - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/85/9/ajvr.24.03.0058.xml
[3] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs
[4] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings

## 常见病原体

犬的胆囊炎主要与细菌感染相关，尽管病毒原因尚未得到充分记录[2]。最常见的分离细菌病原体包括**大肠杆菌**和**肠球菌**属，它们分别代表主要的革兰氏阴性和革兰氏阳性生物[2][4]。

从感染胆囊中频繁培养出的**革兰氏阳性细菌**包括肠球菌属、链球菌属和葡萄球菌属[2][5]。在革兰氏阴性生物中，大肠杆菌占主导地位，其次是假单胞菌属[2][5]。**厌氧细菌**也发挥重要作用，特别是梭菌属、拟杆菌属和芽孢杆菌属[2][5]。

来自十二指肠的**上行感染**代表细菌转移到胆囊的主要途径[6]。这些肠道机会性病原体通过胆道系统逆向迁移，特别是在胆囊动力受损或胆汁淤滞发生时[2]。混合细菌感染很常见，研究报告在15-69%的胆囊炎犬中细菌培养阳性[2][4]。

**气肿性胆囊炎**代表一种与产气细菌相关的严重形式，特别是大肠杆菌和梭菌属[2]。这种情况表明严重的感染性炎症，需要立即手术干预。病理过程涉及胆囊壁组织内的细菌增殖，产生可通过超声检测到的气体[2]。

### Sources

[1] Characterization, treatment, and outcome of bacterial ...: https://avmajournals.avma.org/view/journals/javma/246/9/javma.246.9.982.xml
[2] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/cholecystitis-in-small-animals
[3] Bacterial culture and immunohistochemical detection of ...: https://avmajournals.avma.org/view/journals/javma/260/2/javma.20.10.0552.xml
[4] Diagnosis and management of gallbladder mucocele ...: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml
[5] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

## 临床症状和体征

犬和猫的胆囊炎根据炎症的严重程度和慢性程度表现出不同的临床表现[1]。胆囊炎的临床疾病通常平均约5天，尽管一些动物可能表现出模糊的间歇性症状数月[1]。

**急性表现**的特征是腹痛（可能仅在餐后发生）、发热、呕吐、肠梗阻和轻度至中度黄疸[1]。一些动物可能发展为内毒素休克作为严重并发症[1]。患有中度至重度、可能为坏死性胆囊炎的犬通常表现为厌食、呕吐、腹痛和发热[5]。

**慢性表现**可能包括间歇性症状，如厌食、呕吐和体重减轻[5]。许多患有轻度、非坏死性胆囊炎的动物可能保持无症状或仅显示餐后不适的细微迹象[4]。

**物种特异性模式**表明坏死性胆囊炎更常见于中老年犬，而猫的报道病例似乎较少[1][6]。进展到胆囊破裂的犬通常表现出腹痛、黄疸、心动过速、呼吸急促和发热的经典三联征[1]。患有化脓性胆管炎的猫，通常是年轻猫（中位年龄3.3岁），急性发作表现为发热、嗜睡、脱水和黄疸[10]。

其他临床体征可能包括多尿/多饮、腹泻、腹部膨胀和深腹部触诊时的压痛[1][5]。超声检测到胆囊壁增厚结合影像学检查期间的压痛可能是一些病例中唯一的疾病证据[1]。

### Sources
[1] Cholecystitis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholecystitis-in-small-animals
[2] Coagulation Tests in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/coagulation-tests-in-hepatic-disease-in-small-animals
[3] Canine Cholangiohepatitis - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[4] Cholelithiasis in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholelithiasis-in-small-animals
[5] Managing disorders of the gallbladder in dogs (Proceedings): https://www.dvm360.com/view/managing-disorders-gallbladder-dogs-proceedings
[6] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/cholecystitis-in-small-animals
[7] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals
[8] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[9] Treatment of hepatobiliary disease in dogs and cats (Proceedings): https://www.dvm360.com/view/treatment-hepatobiliary-disease-dogs-and-cats
[10] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease

## 诊断方法

胆囊炎的诊断依赖于临床表现、实验室检测和先进影像学技术的结合[1]。体格检查可能揭示腹痛，特别是餐后不适，以及在更严重病例中的发热和黄疸[1]。深腹部触诊通常会引起患病动物的压痛[1]。

实验室评估通常显示白细胞计数不定，伴有或不伴有中毒性中性粒细胞和左移[1][2]。在一项回顾性研究中，80%的犬出现白细胞增多，75%出现中性粒细胞增多[1]。肝酶活性通常升高，碱性磷酸酶（ALP）和γ-谷氨酰转移酶（GGT）显示中度至显著增加[1]。高胆红素血症的发展取决于慢性程度和胆道受累范围[1]。

超声检查代表胆囊炎诊断的主要影像学方法[1][4]。主要发现包括胆囊壁增厚、胆总管扩张和肝外胆道梗阻的证据[1][4]。胆道系统内气体的检测表明气肿性胆囊炎，需要立即干预[1]。

超声引导下的胆囊穿刺术允许对胆汁进行采样用于细胞学分析和细菌培养[3][4]。胆囊周围液体也可以采样以确认胆汁泄漏[1]。比较腹腔积液与血清中的总胆红素浓度有助于确认胆汁性腹膜炎，积液浓度超过血清水平两倍具有诊断意义[1][4]。

需氧和厌氧联合培养应包括胆汁沉淀物、胆囊壁部分和肝组织，以优化细菌分离[1]。使用罗曼诺夫斯基染色法对胆汁沉淀物进行细胞学检查可以快速识别细菌并指导初始抗菌药物选择[2]。

### Sources

[1] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/cholecystitis-in-small-animals
[2] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis
[3] Managing disorders of the gallbladder in dogs (Proceedings): https://www.dvm360.com/view/managing-disorders-gallbladder-dogs-proceedings
[4] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis

## 治疗选项

犬和猫胆囊炎的治疗涉及医疗和手术方法。医疗管理侧重于支持性护理，包括用于细菌性胆囊炎的广谱抗生素、用于疼痛控制的丁丙诺啡或芬太尼等镇痛药、马罗匹坦等止吐药以及补充电解质的静脉输液治疗[1][2]。在排除肝外胆道梗阻后，可给予熊去氧胆酸[2]。

对于严重病例，包括气肿性胆囊炎、伴有胆汁性腹膜炎的胆囊破裂或引起梗阻的胆石症，手术干预变得必要[1][2][3]。胆囊切除术（胆囊切除）是主要的外科治疗方法，可根据病例复杂性通过腹腔镜或开放方法进行[1][2][4]。腹腔镜胆囊切除术具有减少疼痛、更快恢复和最小发病率的优点，但需要适当的患者选择[4]。

术后护理需要持续的支持性治疗，包括液体管理、疼痛控制和营养支持[1]。应监测患者是否出现胆汁泄漏或感染等并发症[1]。恢复时间各不相同，但对于微创手术，大多数动物可以在1-2周内恢复正常活动，而开放手术方法可能需要数周才能完全恢复[4]。

### Sources
[1] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholecystitis-in-small-animals
[2] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies
[3] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs
[4] Understanding laparoscopy in veterinary surgery: https://www.dvm360.com/view/understanding-laparoscopy-in-veterinary-surgery

## 预防措施

犬和猫胆囊炎的预防侧重于管理导致胆囊炎症的风险因素和基础疾病[1]。中老年犬风险增加，特别是内分泌疾病包括肾上腺皮质功能亢进、甲状腺功能减退和糖尿病，这些疾病创造了胆囊功能紊乱的易感条件[1]。

饮食管理在预防中起着关键作用。高风险患者应避免高脂肪饮食，因为它们会迅速加重发展的黏液囊肿并导致高脂血症[1]。患有高甘油三酯血症或胰腺炎的犬应接受限制脂肪的饮食作为预防护理的一部分[3]。

对于接受医疗管理的胆囊黏液囊肿犬，监测方案包括每4-6周进行生化和超声评估以评估疾病进展[3]。使用熊去氧胆酸（15-25 mg/kg PO q12h）的促胆汁分泌疗法可能通过减少黏液分泌激动剂活性来预防进展[1][3]。

管理易感内分泌疾病至关重要。治疗肾上腺皮质功能亢进、甲状腺功能减退以及在可能时停止皮质类固醇治疗有助于降低风险[3]。定期监测高风险品种，特别是设得兰牧羊犬、小型雪纳瑞犬和可卡犬，可以实现早期检测[1][3]。

使用实时超声检查进行胆囊动力研究可以识别有黏液囊肿形成风险的犬，可能允许在并发症发展之前进行先发制人的干预[1]。早期识别胆囊动力障碍可能需要对高风险患者进行更密切的监测或预防性胆囊切除术。

### Sources
[1] Canine Gallbladder Mucocele: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele
[2] Managing gallbladder mucoceles: https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings
[3] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

## 鉴别诊断

几种疾病在犬和猫中表现出与胆囊炎相似的临床体征，需要通过临床评估和诊断检测进行仔细鉴别[1,2]。

**胆囊黏液囊肿**代表最重要的鉴别诊断，其特征是不移动、非重力依赖性黏液，具有独特的超声"猕猴桃"或星状模式。与胆囊炎不同，黏液囊肿显示黏液从胆囊壁延伸到腔内，内容物固定不随患者体位变化[1]。

**胆石症**可能表现相似，但在超声上显示有移动性胆结石并伴有声影。许多胆结石含有不足的矿物质密度用于放射学可视化，需要超声识别直径≥2mm的结石[4]。

**胆道肿瘤**虽然罕见，但需要通过影像学特征和组织病理学检查进行鉴别。原发性胆囊腺癌在诊断时高度转移[3]。

**胰腺炎**由于胆总管与胰腺组织的解剖接近性，常导致继发性肝外胆道梗阻。临床症状重叠显著，但特定的胰腺标志物和影像学有助于区分原发性胰腺疾病[2,3]。

**鉴别特征**包括胆囊炎的超声胆囊壁增厚、胆石症的重力依赖性移动和黏液囊肿的不移动条纹模式。胆汁的细菌培养有助于识别感染性胆囊炎，而升高的胰腺酶提示并发胰腺炎[2]。

### Sources

[1] Journal of the American Veterinary Medical Association Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml

[2] Merck Veterinary Manual Cholecystitis in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholecystitis-in-small-animals

[3] DVM 360 Managing disorders of the gallbladder in dogs: https://www.dvm360.com/view/managing-disorders-gallbladder-dogs-proceedings

[4] Merck Veterinary Manual Cholelithiasis in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholelithiasis-in-small-animals

## 预后

胆囊炎的预后在医疗和手术管理方法之间差异显著。接受选择性胆囊切除术的犬显示出相当更好的结果，死亡率仅为2%，而非选择性手术为20%[1]。总体手术死亡率根据疾病严重程度和并发症在9-21.7%之间[1][2]。

几个因素对预后产生负面影响，包括胆囊破裂、感染性腹膜炎、高胆红素血症、低白蛋白血症和肝酶升高[1][2]。具有呕吐、嗜睡、厌食和黄疸等临床症状的犬比无症状患者具有显著更高的死亡率[1]。

早期手术干预提供了显著的生存优势，在围手术期存活的患者中预期长期生存和良好的生活质量，特别是在没有肿瘤的情况下[2][3]。早期诊断和干预性胆囊切除术具有实质性的生存优势[3]。

胆囊切除术后，很少发生不良后果，尽管可能发展为脂肪吸收不良引起的间歇性腹痛和腹泻[2]。接受胆肠吻合术的犬仍然易受逆行感染性胆管炎的影响，但通过适当监测通常能很好地耐受该手术[2]。

### Sources
[1] Outcome of elective cholecystectomy for the treatment of gallbladder disease in dogs: https://avmajournals.avma.org/view/journals/javma/252/8/javma.252.8.970.xml
[2] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholecystitis-in-small-animals
[3] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/cholecystitis-in-small-animals
