# 猫慢性鼻窦炎：综合兽医指南

猫慢性鼻窦炎（FCRS）是小动物临床中最具挑战性的上呼吸道疾病之一，影响各年龄段的猫，表现为持续性鼻分泌物、打喷嚏和持续超过四周的呼吸困难。这种进行性疾病显著影响猫的生活质量，并为兽医从业者带来复杂的诊断和治疗挑战。

本报告探讨了FCRS的多因素性质，从FHV-1和FCV等病毒触发因素，到涉及支原体和其他病原体的继发性细菌并发症。评估了包括先进影像学检查、鼻镜检查和分子诊断在内的关键诊断方法，以及结合长期抗生素治疗、抗炎药物和支持性护理的循证治疗方案。分析讨论了关键鉴别诊断，包括鼻肿瘤和真菌感染，同时为这种无法治愈但可管理的疾病提供了现实的预后预期。

## 摘要

猫慢性鼻窦炎是一种复杂的、多因素的疾病，需要综合管理方法而非治愈性解决方案。该病通常始于FHV-1或FCV的病毒损伤，随后发展为猫支原体等生物体的慢性细菌定植。与传统X线摄影相比，CT成像和带活检的鼻镜检查等先进诊断提供了更优的疾病评估，尽管视觉发现与组织病理学之间存在显著差异。

治疗成功取决于持续6-8周的延长抗生素方案，多西环素作为一线治疗药物。包括泼尼松龙和吸入性皮质类固醇在内的抗炎药物提供症状控制，而支持性护理措施提高患者舒适度。通过额窦切除术进行手术干预在难治性病例中提供有限改善。

| 管理方面 | 关键建议 | 预期结果 |
|----------|----------|----------|
| **抗生素治疗** | 多西环素5mg/kg，每12小时一次，持续6-8周 | 初始有效，但可能复发 |
| **抗炎治疗** | 泼尼松龙后使用吸入性皮质类固醇 | 改善症状控制 |
| **诊断影像学** | CT优于X线摄影 | 更好地观察鼻甲破坏 |
| **预后** | 谨慎 - 需要慢性管理 | 改善生活质量，而非治愈 |

通过核心疫苗接种方案和多猫设施的环境管理进行预防仍然至关重要，尽管疫苗预防的是严重疾病而非感染。兽医必须与客户建立现实期望，强调慢性症状管理而非完全解决，同时通过持续的治疗干预专注于改善生活质量。

## 疾病概述

猫慢性鼻窦炎（FCRS）是一种影响猫鼻腔和鼻窦的持续性炎症性疾病[1]。该病特征为慢性或复发性鼻分泌物、打喷嚏和持续超过4周的上呼吸道症状[3]。FCRS是猫慢性上呼吸道疾病最常见的原因之一，尽管其仍 poorly understood[2]。

**流行病学背景**

FCRS可发生于任何年龄的猫，初发年龄报告范围为6个月至20岁[1][2][5][7]。该病无明显的性别或品种易感性[5]。临床症状可能持续数年并表现出复发性[2][5]。该病呈进行性，发病年龄不一，常表现为慢性间歇性或进行性症状[3][5]。

**与急性形式的区别**

与通常影响幼猫并在2-3周内解决的急性上呼吸道感染不同，FCRS是一种可能无限期持续的慢性疾病[6]。慢性炎症变化降低鼻上皮下刺激物受体敏感性，减少正常打喷嚏反应，使分泌物积聚[1]。该病常为排除性诊断，因为许多病例缺乏可识别的特定病因[5][7]。

### Sources
[1] A sniff of what you should know about chronic feline: https://www.dvm360.com/view/rundown-runny-noses-sniff-what-you-should-know-about-chronic-feline-sneezers-and-snufflers
[2] Snots and snuffles: chronic feline upper respiratory: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
[3] Cats with idiopathic chronic rhinosinusitis that develop clinical: https://avmajournals.avma.org/view/journals/javma/261/10/javma.23.04.0186.xml
[4] Understanding a cat's cough: https://www.dvm360.com/view/understanding-cats-cough
[5] Chronic upper respiratory disease in cats (Proceedings): https://www.dvm360.com/view/chronic-upper-respiratory-disease-cats-proceedings
[6] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[7] Chronic rhinitis (Proceedings): https://www.dvm360.com/view/chronic-rhinitis-proceedings

## 常见病原体

猫慢性鼻窦炎涉及多种病原体类型，这些病原体促成疾病的发生和持续[1]。大多数急性上呼吸道感染由猫疱疹病毒1型（FHV-1）引起，尽管猫杯状病毒（FCV）在某些群体中可能更为普遍[1]。

**病毒病原体：** FHV-1和FCV是主要病毒病原体[1]。FHV-1倾向于影响结膜和鼻腔通道，而FCV通常影响口腔黏膜和下呼吸道[1]。这些病毒引起初始呼吸道上皮损伤和鼻甲破坏，为继发性细菌定植创造条件[2]。

**细菌病原体：** 继发性细菌感染常使病毒疾病复杂化。关键细菌病原体包括猫衣原体和猫支原体[1]。支气管败血波氏杆菌也可能促成感染[1]。在慢性鼻炎猫中比在无症状猫中更常分离到支原体种，提示其参与临床症状产生[2]。这些细菌感染常因初始病毒损伤引起的解剖或生理改变而持续存在[2]。

**真菌病原体：** 隐球菌种（*C. neoformans*和*C. gattii*）引起肉芽肿性肿块，导致黏液脓性至出血性鼻分泌物[7]。曲霉病主要由烟曲霉引起，可影响鼻腔通道并导致鼻甲破坏[7,8]。这些真菌感染可能代表免疫受损患者中的原发性病原体或继发性入侵者。

发病机制涉及初始病毒损伤，随后是慢性细菌定植，真菌病原体偶尔在易感猫中使疾病过程复杂化[2]。

### Sources
[1] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[3] Feline herpesvirus and calicivirus infections: What's new?: https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[4] Feline Calicivirus - Cat Owners: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[5] Feline Bronchial Asthma: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-bronchial-asthma
[6] Brain magnetic resonance imaging: https://avmajournals.avma.org/view/journals/javma/262/4/javma.23.08.0454.xml
[7] Upper airway troubles: https://www.dvm360.com/view/upper-airway-troubles-proceedings
[8] Fungal Infections in Dogs: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/fungal-infections-in-dogs
[9] Clinical approach to nasal discharge: https://www.dvm360.com/view/clinical-approach-nasal-discharge-proceedings

## 临床症状和体征

猫慢性鼻窦炎表现出不同的临床表现，严重程度和持续时间各不相同。该病特征为持续超过4周的复发性鼻分泌物，临床症状可能进行性发展且发病时间不一[1]。

**典型临床症状**

标志症状是慢性打喷嚏，常以阵发性发作，伴有持续性或间歇性黏液脓性鼻分泌物[2]。猫通常表现为鼾声（打鼾或鼾音呼吸），这是与打喷嚏和鼻分泌物一起最常见的上呼吸道症状[3]。在更严重的情况下可能出现张口呼吸、呼吸困难和喘息[2]。

鼻分泌物性质从浆液性到黏液脓性不等，可能是单侧或双侧的[4]。分泌物通常对抗生素治疗完全反应，但在停药后3天内复发[4]。其他呼吸道症状包括伴有鼻分泌物的复发性打喷嚏发作，可持续较长时间[1]。

**相关表现**

猫可能发展继发性并发症，包括颌下淋巴结肿大和某些情况下的咳嗽[5]。上呼吸道呼吸困难、嗜睡和食欲减退可能在更晚期疾病中出现[7]。疾病的慢性性质常导致持续性临床症状，显著影响猫的生活质量。

**年龄和疾病模式**

该病表现出可变的发病年龄，可影响不同年龄组的猫[1]。临床症状特征为持续超过4周，区别于急性上呼吸道感染[1]。疾病的进行性意味着如无适当干预，症状通常随时间恶化。

### Sources

[1] Cats with idiopathic chronic rhinosinusitis that develop clinical: https://avmajournals.avma.org/view/journals/javma/261/10/javma.23.04.0186.xml
[2] Upper airway troubles (Proceedings): https://www.dvm360.com/view/upper-airway-troubles-proceedings
[3] Diagnostic dilemmas of the upper respiratory tract: https://www.dvm360.com/view/diagnostic-dilemmas-upper-respiratory-tract-proceedings
[4] Feline viral upper respiratory disease: why it persists!: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[5] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[6] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/en-au/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[7] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings

## 诊断方法

诊断猫慢性鼻窦炎（FCRS）需要结合临床评估和先进诊断的综合方法。诊断通常通过排除其他原因做出，并通过组织病理学确认[1]。

**临床检查和评估**

体格检查应包括仔细评估鼻腔气流通畅性、面部对称性评估、硬腭和软腭触诊以及牙弓检查。应仔细触诊区域淋巴结，如果怀疑隐球菌病，眼底检查可能有帮助[2]。

**先进影像学方法**

计算机断层扫描（CT）优于头颅X线摄影，用于评估整个上呼吸道。CT提供更好的鼻甲破坏可视化，可检测筛板侵犯，并提供疾病程度的更优评估[2]。通过CT，鼻部疾病通常显示不同程度的鼻甲溶解和鼻腔内液体密度增加，鼻窦和鼓泡常受影响[2]。

**鼻镜检查和组织取样**

鼻镜检查允许直接观察鼻腔异常，包括鼻甲破坏、充血、过多黏液和不规则结构。然而，鼻镜变化与组织病理学发现之间存在显著差异[1]。应在可视化下进行活检以获得准确诊断，显示淋巴细胞、浆细胞、嗜酸性粒细胞或中性粒细胞的炎症浸润，以及不同程度的鼻甲溶解和重塑[1]。

**实验室诊断**

鼻活检或冲洗样本的支原体种PCR评估与生物体分离相关，并提供快速结果[2]。在对照组猫和慢性鼻窦炎猫中均通过PCR从组织活检或鼻冲洗中检测到FHV-1，突出了FCRS特有的诊断挑战[1]。分子诊断检测现由兽医诊断实验室为患有呼吸道疾病的猫提供[6]。

### Sources

[1] Chronic upper respiratory disease in cats (Proceedings): https://www.dvm360.com/view/chronic-upper-respiratory-disease-cats-proceedings

[2] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis

[3] A retrospective analysis of canine, feline, and equine respiratory polymerase chain reaction panels performed at the New York State Animal Health Diagnostic Center (January-December 2023): https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.11.0755.xml

## 治疗选择

猫慢性鼻窦炎需要结合药物干预、支持性护理和潜在手术选择的多模式治疗方法[1]。患有慢性疾病的猫通常对抗生素治疗表现出初始反应，使延长治疗方案变得必要[1]。

**药物干预**
一线抗生素治疗包括多西环素（5 mg/kg口服，每12小时一次），因其对常见猫鼻病原体的广谱活性和良好耐受性[2]。替代抗生素包括阿莫西林-克拉维酸、克林霉素或阿奇霉素（5-10 mg/kg，每日一次）[1][3]。恩诺沙星或马波沙星可能对耐药病例有用，阿奇霉素因每周两次给药方案在猫舍环境中变得流行[2]。建议进行6-8周的长期治疗，如果初始阳性反应出现则不更换抗生素[3]。

糖皮质激素是治疗的基石，通常在治疗细菌感染后开始使用泼尼松龙[5]。一旦疾病得到控制，吸入性皮质类固醇如氟替卡松（220mcg，每次2喷，每日两次）可能有效，约需1-2周达到最大疗效[1][5]。使用吡罗昔康（0.3 mg/kg每日一次）的抗炎治疗可能减少黏液产生并改善患者舒适度[1]。

**支持性护理和手术选择**
环境加湿、生理盐水鼻滴剂和定期麻醉鼻冲洗有助于管理分泌物[1]。L-赖氨酸补充（250-500 mg，每日两次）可能减少疱疹病毒复发[1][4]。当药物治疗失败时，额窦切除术可提供显著改善，尽管完全解决仍不常见[1]。主人应了解慢性鼻窦炎预后谨慎，临床症状很少完全消除[1]。

### Sources
[1] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[2] What are the best practices for antibiotic use in feline upper respiratory tract disease: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease
[3] Snots and snuffles: chronic feline upper respiratory syndromes: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
[4] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[5] Chronic rhinitis (Proceedings): https://www.dvm360.com/view/chronic-rhinitis-proceedings

## 预防措施

疫苗接种方案构成猫慢性鼻窦炎预防的基石。含有FHV-1和FCV的核心疫苗应从6-9周龄开始接种，每3-4周加强一次，直至16周龄[1][3]。建议每年加强接种，随后每三年重新接种，尽管疫苗预防的是严重疾病而非感染或携带状态[5]。与胃肠外给药相比，鼻内疫苗可能提供更快速的保护和增强的局部免疫力[3]。

环境控制策略对多猫家庭至关重要。过度拥挤是严重呼吸道疾病爆发的最大单一风险因素[7]。减少种群密度、通过适当笼舍大小和隐藏处最小化压力、实施点清洁方案有助于预防病毒再激活[7]。使用1:32漂白溶液或过氧单硫酸钾进行有效消毒是必要的，因为FCV可在环境中存活数周[8]。

隔离指南要求将有活动性临床症状的猫与一般群体分开，因为这些动物排出的病毒载量显著更高[7]。在收容所环境中应尽量缩短停留时间，因为长期饲养增加感染风险[7]。在接种疫苗前，可能需要2-3天的抗菌预处理以减少鼻分泌物并优化疫苗效力[3]。

易感因素管理包括解决压力、并发疾病、寄生虫感染和营养不良，这些因素损害免疫功能[7]。系统性疫苗接种结合环境控制为预防慢性鼻窦炎发展提供最佳保护[6]。

### Sources
[1] Feline viral upper respiratory disease: why it persists! ... : https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[2] Chronic upper respiratory disease in cats (Proceedings) : https://www.dvm360.com/view/chronic-upper-respiratory-disease-cats-proceedings
[3] Feline viral upper respiratory infection: Why it persists (Proceedings) : https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[4] Feline vaccination: Guidelines, indications, and risks (Proceedings) : https://www.dvm360.com/view/feline-vaccination-guidelines-indications-and-risks-proceedings
[5] Feline Respiratory Disease Complex : https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[6] Feline upper respiratory syndrome (Proceedings) : https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings
[7] Acute feline upper respiratory infection (Proceedings) : https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[8] Understanding a cat's cough : https://www.dvm360.com/view/understanding-cats-cough

## 鉴别诊断

猫慢性鼻窦炎与其他几种疾病有重叠的临床症状，需要通过临床检查和诊断测试进行仔细鉴别[1]。

**肿瘤**是关键的鉴别诊断，大多数鼻肿瘤为恶性且局部侵袭性[1][2]。鼻肿瘤通常引起单侧鼻分泌物和打喷嚏，常伴有鼻衄[1][2]。先进影像学显示广泛的鼻甲破坏和骨溶解，区别于慢性鼻窦炎[2][3]。

**异物**通过影像学研究易于区分，在X线片或CT扫描上明显可见[4]。临床病史常显示单侧分泌物的急性发作，与鼻窦炎的慢性双侧性质形成对比[1]。

**真菌感染**，特别是隐球菌病和曲霉病，引起严重鼻腔炎症伴面部变形[2][5]。隐球菌病产生肉芽肿性肿块，细胞学上可见特征性包囊生物体，而曲霉病在鼻镜检查下可能显示白色/黄色斑块病变[4][5]。

**牙科疾病**表现为牙根脓肿伴牙周受累，常引起破坏性鼻炎[5]。口腔检查显示牙龈炎、牙科病理或口鼻瘘，区别于原发性鼻窦炎[4]。

**鼻咽息肉**主要影响幼猫，引起张口呼吸和呼吸困难伴鼻分泌物[5]。麻醉下直接可视化确认诊断[5]。

**过敏性鼻炎**通常显示季节性模式，组织病理学上为嗜酸性炎症，对抗组胺药和环境控制有反应[2][5]。

### Sources
[1] A sniff of what you should know about chronic feline: https://www.dvm360.com/view/rundown-runny-noses-sniff-what-you-should-know-about-chronic-feline-sneezers-and-snufflers
[2] Snots and snuffles: chronic feline upper respiratory: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
[3] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors
[4] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[5] Upper airway troubles (Proceedings): https://www.dvm360.com/view/upper-airway-troubles-proceedings

## 预后

猫慢性鼻窦炎预后谨慎，因为该病无法治愈[1][6]。管理的主要目标是通过症状控制改善生活质量，而非实现完全解决[1][6]。大多数受影响的猫经历长期慢性症状，伴有需要持续管理的间歇性发作[1][6]。

关键预后因素显著影响结果。CT成像上可见的广泛鼻甲破坏与预后恶化相关[6]。发病年龄和对初始治疗的反应也影响长期管理成功。即使包括抗生素、抗炎药和支持性护理的积极治疗，打喷嚏和黏液脓性分泌物的临床症状也难以控制且几乎总是复发[6]。

生活质量在受影响的猫中差异很大。一些患者实现相对正常的生活，仅有轻微症状，而其他患者则遭受频繁的继发性细菌感染和持续性临床症状。疾病的异质性意味着个体猫可能对治疗方案有不同的反应。

长期管理期望应在诊断过程早期向主人明确传达。然而，通过持续的管理策略，尽管疾病具有慢性性质，许多猫可以实现可接受的症状控制并维持合理的生活质量[6]。

### Sources

[1] Snots and snuffles: chronic feline upper respiratory syndromes (Proceedings): https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
[2] Rhinitis and Sinusitis in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/rhinitis-and-sinusitis-in-cats
[3] How are you managing chronic rhinosinusitis?: https://www.dvm360.com/view/how-are-you-managing-chronic-rhinosinusitis
[4] Chronic upper respiratory disease in cats (Proceedings): https://www.dvm360.com/view/chronic-upper-respiratory-disease-cats-proceedings
[5] Rhinitis and Sinusitis in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/rhinitis-and-sinusitis-in-dogs-and-cats
[6] Chronic nasal discharge in cats - AVMA: https://avmajournals.avma.org/downloadpdf/view/journals/javma/230/7/javma.230.7.1032.pdf
