# 伴侣动物的病毒性角膜炎

病毒性角膜炎是伴侣动物中一种重要的眼科疾病，尤其通过猫疱疹病毒-1型（FHV-1）感染影响猫。这种炎症性角膜疾病如果管理不当，可导致溃疡、瘢痕形成和视力障碍。虽然FHV-1在猫科病例中占主导地位，几乎普遍暴露，但犬的病毒性角膜炎主要涉及犬疱疹病毒-1型和腺病毒-1型。本报告探讨了病毒性角膜炎的全面兽医处理方法，涵盖引起树枝状溃疡和基质疾病的主要病原体（如FHV-1）、包括荧光素染色和PCR检测在内的诊断方法、如泛昔洛韦和西多福韦等当前抗病毒治疗，以及通过疫苗接种方案和压力管理进行预防的策略，以获得最佳的患者预后。

## 摘要

伴侣动物的病毒性角膜炎带来了独特的挑战，需要针对性的治疗方法。FHV-1在猫科病例中占主导地位，暴露率达95%，80%为终身携带者状态，导致成年猫复发性单侧疾病和幼猫严重的双侧临床表现。犬的病毒性角膜炎虽然较少见，但涉及CHV-1和CAV-1，具有特征性的"蓝眼"表现。

| 方面 | 猫科（FHV-1） | 犬科（CHV-1/CAV-1） |
|--------|----------------|----------------------|
| **主要病原体** | 猫疱疹病毒-1型 | 犬疱疹病毒-1型，腺病毒-1型 |
| **流行率** | 95%暴露率 | 较少见 |
| **临床模式** | 复发性单侧（成年猫） | 自限性结膜炎 |
| **关键治疗** | 泛昔洛韦 90mg/kg 每日两次 | 三氟胸苷，全身性阿昔洛韦 |
| **预后** | 终身潜伏伴复发 | 通常良好 |

诊断成功依赖于荧光素染色检测溃疡和临床判断，因为PCR无法区分疫苗接种与感染。治疗进展包括西多福韦的优越疗效和泛昔洛韦改善的生物利用度。通过核心疫苗接种和压力管理进行预防仍然至关重要，尽管疫苗只能降低严重程度而非预防感染。长期管理需要客户教育，使其了解疾病的慢性性质和避免触发因素，以获得最佳结果。

## 猫疱疹病毒-1型角膜炎

猫疱疹病毒-1型（FHV-1）是猫角膜炎的主要病毒性病因，流行病学家估计全球超过95%的猫曾暴露于该病毒[1]。大约80%暴露过的猫成为终身携带者，使FHV-1成为猫群中普遍存在的传染源。

FHV-1通过受感染猫的密切接触，经由呼吸道、口腔和眼部分泌物传播[1]。猫通常在新生儿期获得感染，此时母源抗体水平下降，受压的母猫会重新激活其潜伏病毒[1]。该病毒在神经组织中建立潜伏状态，在压力期间发生再激活，导致疾病复发。

临床表现在不同年龄组间差异显著。幼猫表现为双侧疼痛性结膜炎，分泌物从浆液性进展到黏液脓性，常伴有严重角膜炎，可在幼年动物中引起睑球粘连[1]。成年猫经历复发性单侧疾病，反复影响同一只眼睛，严重病例出现疱疹病毒性角膜炎、角膜溃疡和睑球粘连[3][4]。

诊断主要依靠临床判断，因为PCR无法区分自然感染和疫苗接种[1]。治疗包括局部抗病毒药物，如三氟胸苷、碘苷和西多福韦，全身性泛昔洛韦在40 mg/kg每8小时一次或90 mg/kg每12小时一次的剂量下显示出改善的临床反应[6][7]。辅助治疗包括L-赖氨酸补充，尽管其疗效仍有争议。

### Sources

[1] Herpesvirus and the feline eye: https://www.dvm360.com/view/herpesvirus-and-feline-eye
[2] Feline herpesvirus and calicivirus infections: What's new?: https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[3] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[4] Feline viral upper respiratory disease: why it persists!: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[5] In vivo confocal microscopic features of naturally acquired: https://avmajournals.avma.org/view/journals/ajvr/82/11/ajvr.82.11.903.xml
[6] Antimicrobial Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[7] Oral administration of famciclovir for treatment of spontaneous: https://avmajournals.avma.org/view/journals/javma/249/5/javma.249.5.526.xml

## 犬病毒性角膜炎

犬病毒性角膜炎是一种主要由病毒病原体引起的角膜炎症性疾病，最常见的是犬疱疹病毒-1型（CHV-1）[1]。虽然报道频率低于细菌性角膜炎，但病毒性角膜炎是犬的一种重要眼部疾病，如果不及时治疗，可导致角膜溃疡和视力障碍。

犬疱疹病毒-1型是犬角膜炎的主要病毒性病因，通常在成年犬中引起自限性结膜炎和眼部病毒排毒[2]。此外，犬腺病毒-1型（CAV-1）是传染性犬肝炎的病原体，可通过免疫复合物沉积引起角膜混浊（"蓝眼"）作为继发性表现[3]。这种双侧角膜混浊在急性临床症状消失后7-10天发展，通常自发消退[4]。

诊断依赖于临床表现结合通过结膜或角膜样本的病毒分离或实时PCR检测进行实验室确认[1]。治疗包括局部抗病毒药物，如三氟胸苷、碘苷和更昔洛韦，这些药物特别适用于眼部疱疹病毒（CHV-1）感染[5]。全身性阿昔洛韦可用于新生犬CHV-1感染，剂量为10 mg/kg口服每6小时一次，持续5天[5]。

### Sources
[1] Experimental primary ocular canine herpesvirus-1 infection in ...: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/70/4/ajvr.70.4.513.pdf
[2] Experimental primary ocular canine herpesvirus-1 infection in ...: https://avmajournals.avma.org/view/journals/ajvr/70/4/ajvr.70.4.513.xml
[3] Infectious Canine Hepatitis - Infectious Diseases - Merck Veterinary Manual: https://www.merckvetmanual.com/generalized-conditions/infectious-canine-hepatitis/infectious-canine-hepatitis
[4] Infectious Canine Hepatitis - Generalized Conditions - Merck ...: https://www.merckvetmanual.com/generalized-conditions/infectious-canine-hepatitis/overview-of-infectious-canine-hepatitis
[5] Dosages of Antiviral Drugs: https://www.merckvetmanual.com/multimedia/table/dosages-of-antiviral-drugs

## 诊断方法

病毒性角膜炎的诊断需要全面的眼科检查结合特定的诊断技术[1]。标准眼科检查应包括希林泪液试验、荧光素染色和眼内压测量[2]。荧光素染色对于检测角膜溃疡至关重要，树枝状溃疡是猫疱疹病毒（FHV）感染的特征性表现[1]。玫瑰红染色对于检测与病毒性角膜炎相关的细微上皮损伤可能更敏感[1]。

猫的希林泪液试验可能难以解释，因为交感神经系统可能导致正常猫的值非常低，因此双眼之间的差异比绝对值更重要[3]。该试验应在应用荧光素染色或局部麻醉剂之前进行，以确保测量准确[4]。

实验室诊断包括角膜或结膜刮片的细胞学检查，以识别炎症细胞并排除嗜酸性角膜炎等疾病[1]。PCR检测是一种扩增DNA或RNA序列以检测病原体的分子技术[5]。对于病毒性角膜炎，PCR可检测FHV，但假阴性结果显著，正常猫也可能检测呈阳性[1]。免疫荧光抗体（IFA）检测可用，但由于高假阴性率，其诊断价值存疑[1]。

## 鉴别诊断

病毒性角膜炎的主要鉴别诊断包括细菌性角膜炎、免疫介导性疾病和嗜酸性角膜炎[1,2]。FHV角膜炎必须与细菌性溃疡性角膜炎区分开来，后者通常表现为致密的白色浸润和更严重的疼痛[2]。嗜酸性角膜炎表现为粉白色角膜斑块，通过嗜酸性粒细胞的细胞学识别进行诊断[1]。真菌感染虽然在伴侣动物中罕见，但在适当的地理区域应予以考虑[2]。非溃疡性免疫介导性角膜炎的表现可能与病毒性基质角膜炎相似，但缺乏特征性的溃疡模式[1]。

### Sources
[1] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[2] The red eye: diagnostics and treatment (Proceedings): https://www.dvm360.com/view/red-eye-diagnostics-and-treatment-proceedings
[3] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[5] Polymerase chain reaction - Wikipedia: https://en.wikipedia.org/wiki/Polymerase_chain_reaction

## 治疗选择

伴侣动物病毒性角膜炎的治疗侧重于抗病毒治疗、支持性护理和继发性细菌感染的管理。主要治疗方法包括局部抗病毒药物，全身性治疗保留用于严重或难治性病例[1]。

**局部抗病毒药物**

传统局部抗病毒药物包括1%三氟胸苷、0.1%碘苷和3%阿糖腺苷，它们对猫疱疹病毒-1型显示出不同的有效性[1]。三氟胸苷显示出最高的疗效和角膜穿透力，但可能引起更大的眼部刺激[1]。这些药物需要在临床消退后频繁应用（每日5-6次）10-14天[1]。

**新型抗病毒选择**

0.5%西多福韦溶液对FHV-1提供了优越的体外和体内疗效，每日两次给药，提高了客户依从性[1]。局部更昔洛韦有0.15%凝胶或调配的0.5%溶液[2]。这些新型药物与传统抗病毒药物相比显示出降低的毒性[1]。

**全身性抗病毒治疗**

当局部治疗无效或用于联合治疗时，需要全身性抗病毒药物[2]。泛昔洛韦90 mg/kg每日两次代表最有效的口服选择[1]。阿昔洛韦生物利用度差且有全身毒性风险，因此较少推荐[2]。

**手术干预**

当药物治疗失败或出现并发症时，手术选择变得必要。浅层角膜切除术适用于角膜坏死和其他支持性手术，包括第三眼睑瓣、结膜瓣移植和部分板层角膜移植术[3][5]。治疗包括手术切除受影响的角膜表面，并在适当时用结膜组织瓣覆盖缺损[5]。

**支持性护理**

所有患者都受益于频繁应用含有透明质酸的高质量人工泪液[1]。继发性细菌感染应使用适当的局部抗生素治疗[1][2]。

### Sources
[1] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[2] Antimicrobial Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[3] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] Corneal disease in dogs: there is a hole in my cornea ...: https://www.dvm360.com/view/corneal-disease-dogs-there-hole-my-cornea-proceedings
[5] Disorders of the Cornea in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-cornea-in-cats

## 预防和预后

**预防措施**

疫苗接种仍然是猫病毒性角膜炎预防的基石。FHV-1疫苗包含在核心疫苗接种方案中，显著降低疾病严重程度和病毒排毒持续时间，尽管它们不能预防感染或消除携带者状态[1][7]。鼻内疫苗提供快速免疫，特别适用于收容所和多猫环境中的疫情控制[1][7]。

减少压力至关重要，因为压力会触发病毒再激活和复发感染[1][7][9]。环境管理应尽量减少多猫家庭中的过度拥挤和冲突[1]。适当的卫生和消毒方案有助于预防传播，因为FHV-1通过呼吸道分泌物和污染物传播[1][7]。

**预后因素**

病毒性角膜炎的预后根据几个因素差异显著。幼猫的原发感染具有更高的严重角膜和结膜瘢痕风险[1][9]。有复发疾病的成年猫通常症状较轻，但可能发展出慢性并发症[1][9]。

长期结果取决于压力管理和客户对治疗方案的依从性[1][7]。大约80%的猫发展为终身潜伏感染，在压力期间频繁复发[1][9]。虽然抗病毒治疗不能消除潜伏感染，但在正确使用时能有效控制急性发作[7][9]。

### Sources

[1] Eye Disorders Resulting from Generalized Diseases in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/eye-disorders-resulting-from-generalized-diseases-in-cats
[2] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[3] Herpes Viral Conjunctivitis: A Feline Problem: https://veterinarypartner.vin.com/default.aspx?pid=19239&id=4951824
