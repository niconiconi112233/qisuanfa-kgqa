# 伴侣动物巨食道症

巨食道症是小动物兽医临床中最具挑战性的食道疾病之一，其特征为食道弥漫性扩张和正常蠕动功能丧失。本综合报告探讨了该疾病的多面性，从其病理生理机制到临床管理策略。分析涵盖了先天性与获得性形式的区别、包括放射学和实验室技术的诊断方法，以及强调营养管理和并发症预防的治疗方案。特别关注了品种易感性、吸入性肺炎作为危及生命的并发症的关键作用，以及影响患病犬猫长期预后的预后因素。

## 摘要

本报告揭示了巨食道症是一种需要综合管理策略的复杂疾病。主要研究结果表明，获得性形式比先天性病例更为普遍，其中重症肌无力占获得性病例的25-30%。诊断成功取决于胸部X线摄影与包括乙酰胆碱受体抗体滴度在内的专门检测相结合。治疗以使用贝利椅进行抬高喂食方案和个性化营养方法为中心，而吡啶斯的明等药物干预对重症肌无力病例至关重要。

| 方面 | 先天性 | 获得性 |
|--------|------------|----------|
| **发病** | 断奶期（4周龄） | 成年动物 |
| **预后** | 尚可（20-40%改善） | 谨慎至不良 |
| **主要原因** | 遗传易感性 | 重症肌无力、特发性 |
| **管理** | 可能在6-12个月内缓解 | 终身支持性护理 |

关键预后因素仍是吸入性肺炎的预防，因为呼吸并发症导致74%的死亡率。成功需要早期识别、积极的营养支持以及及时治疗潜在疾病，强调了需要主人依从性和兽医监测的专注投入。

## 疾病概述

巨食道症的特征是食道弥漫性扩张和蠕动消失（缺乏正常的波浪状肌肉收缩）[1]。该综合征涉及食道动力不足，这被认为是导致食道失去有效将食物和液体运输到胃部能力的潜在病理生理机制[1,2]。

该疾病可分为两种主要形式：先天性和获得性。先天性巨食道症不常见，通常在幼犬和幼猫约4周龄开始断奶时出现[1,2]。一些患者可能存在食道功能成熟延迟，随着年龄增长而改善，而其他患者则存在永久性功能障碍[1]。

犬在两种形式中的发病率均远高于猫[1,2]。某些品种对先天性巨食道症表现出易感性，包括纽芬兰犬、杰克罗素㹴、萨摩耶犬、史宾格犬、平滑毛猎狐㹴和沙皮犬[1]。具有家族易感性的其他品种包括爱尔兰雪达犬、大丹犬、德国牧羊犬、拉布拉多寻回犬、中国沙皮犬和迷你雪纳瑞犬[3]。

获得性巨食道症更为常见，通常影响成年动物。大多数病例为特发性，没有可识别的潜在原因[1,2]。然而，继发原因包括重症肌无力（约占获得性病例的25%）、甲状腺功能减退、肾上腺皮质功能减退和各种神经肌肉疾病[1,3]。

### Sources

[1] Esophageal diseases (Proceedings): https://www.dvm360.com/view/esophageal-diseases-proceedings
[2] Gastrointestinal motility disorders (Proceedings): https://www.dvm360.com/view/gastrointestinal-motility-disorders-proceedings
[3] Diseases of the esophagus (Proceedings): https://www.dvm360.com/view/diseases-esophagus-proceedings

## 常见病原体

巨食道症主要是一种非感染性疾病，但几种病原体可通过继发机制或直接食道参与导致或加重疾病。

**病毒性原因**作为巨食道症的主要触发因素相当罕见。犬瘟热病毒损害气道并使动物易受细菌继发感染[1]。虽然犬瘟热可通过中枢神经系统参与引起影响食道功能的神经并发症，但它不被认为是巨食道症发展的主要病原体[2]。历史调查在暴发情况下排除了犬瘟热病毒[3]。

**细菌感染**通常代表继发并发症而非主要原因。与巨食道症暴发相关的食物样本的标准细菌培养方法产生阴性结果[3]。然而，由于吸入反流物质，细菌性肺炎经常发展为危及生命的继发疾病，需要积极的抗生素干预[4]。

**原生生物**可通过神经肌肉损伤直接引起巨食道症。*犬新孢子虫*特别重要，它引起伴有食道受累的神经肌肉疾病，尤其是在6个月以下的幼犬中[5]。该寄生虫破坏颅神经和脊髓内的神经元细胞，产生特征性的巨食道症表现。类似地，*刚地弓形虫*可引起影响神经系统的全身性感染[6]，可能导致食道功能障碍，尽管这比新孢子虫病较少被记录。

**其他传染性病原体**通常通过诊断调查被排除。大多数病例中缺乏明确的感染病因表明巨食道症主要是一种非感染性疾病，病原体扮演继发或机会性角色。

### Sources

[1] Merck Veterinary Manual Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Merck Veterinary Manual Canine Distemper - Infectious Diseases - Merck Veterinary Manual: https://www.merckvetmanual.com/generalized-conditions/canine-distemper/canine-distemper
[3] A comparative analysis of two unrelated outbreaks in Latvia ...: https://avmajournals.avma.org/view/journals/javma/259/2/javma.259.2.172.xml
[4] Merck Veterinary Manual Dilatation of the Esophagus in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/dilatation-of-the-esophagus-in-small-animals
[5] Merck Veterinary Manual Neosporosis in Dogs - Infectious Diseases - Merck Veterinary Manual: https://www.merckvetmanual.com/infectious-diseases/neosporosis-in-dogs/neosporosis-in-dogs
[6] Merck Veterinary Manual Toxoplasmosis in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/toxoplasmosis-in-dogs

## 临床症状和体征

反流是巨食道症的特征性临床症状，必须与呕吐相区分[1]。反流的特点是产生食物或液体的被动运动，而呕吐涉及主动的腹部起伏。胆汁应仅出现在呕吐中，绝不会出现在反流中[1]。

反流时间差异很大--可能在喂食后立即发生或数小时后发生，反流物质通常呈特征性的管状[1]。其他主要体征包括流涎（唾液分泌过多）、口臭和因营养摄入不足导致的体重减轻[1,2]。

呼吸并发症常见且危及生命。犬经常发展为吸入性肺炎，表现为嗜睡、呼吸困难、咳嗽和鼻分泌物[1]。这些呼吸症状可能是主诉而非胃肠道症状。

某些品种表现出特定模式。先天性巨食道症通常在幼犬断奶期间显现，通常在3个月龄时明显[1,2]。刚毛猎狐㹴、迷你雪纳瑞犬、德国牧羊犬、大丹犬和拉布拉多寻回犬发病率较高[1,2]。

体格检查可能发现因食物在食道中积聚导致的颈部腹侧肿胀、吸入引起的肺部啰音和显著体重减轻[1]。患有并发重症肌无力的犬可能表现出全身性神经肌肉无力[1]。

### Sources
[1] Diagnosis and management of megaesophagus in dogs: https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings
[2] Congenital and Inherited Anomalies of the Esophagus in Animals: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/congenital-and-inherited-anomalies-of-the-esophagus-in-animals

## 诊断方法

巨食道症的诊断需要结合临床评估与多种影像学和实验室技术的综合方法。胸部X线摄影检查通常对全身性巨食道症具有诊断意义，显示含有食物、液体或空气的扩张食道[1]。应在对比研究之前拍摄平片，因为平片可能是确定性的或指示内窥镜检查作为首选的下一步[2]。

当平片结果不确定时，使用钡剂的对比食道造影术可确认食道扩张并评估蠕动功能[2]。与静态X线片相比，三相钡剂视频荧光动态造影检查为功能性动力障碍提供了更优越的评估[1]。荧光镜检查允许实时评估食道功能，尽管在一般临床实践中并不常用[3]。

必要的实验室检测包括全血细胞计数、血清生化分析和尿液分析作为最小数据库[4]。对潜在原因的专门检测至关重要：应在所有获得性巨食道症犬中评估乙酰胆碱受体抗体滴度，因为重症肌无力占病例的30%[4]。其他检测可能包括肌酸激酶水平、甲状腺功能检查以评估甲状腺功能减退症，以及怀疑肾上腺皮质功能减退时的ACTH刺激试验[4]。

食道镜检查可排除阻塞性、炎症性和肿瘤性疾病，但必须谨慎进行麻醉管理以防止吸入性肺炎[4]。胸部X线片也必须评估吸入性肺炎，这是一种常见且严重的并发症。

### Sources

[1] Regurgitation, dysphagia, and esophageal dysmotility (Proceedings): https://www.dvm360.com/view/regurgitation-dysphagia-and-esophageal-dysmotility-proceedings
[2] Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats
[3] Clinical Exposures: Why it's important to examine the entire radiographic image: https://www.dvm360.com/view/clinical-exposures-why-its-important-examine-entire-radiographic-image
[4] Diagnosis and management of megaesophagus in dogs (Proceedings): https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings

## 治疗选择

巨食道症治疗需要多模式方法，既解决潜在原因又提供支持性护理。对于重症肌无力相关病例，溴吡啶斯的明（1-3mg/kg 口服 每8-12小时一次）作为一线治疗，免疫抑制剂如泼尼松保留用于难治性病例[1]。西地那非在促进下食管括约肌松弛方面显示出前景，特别是对先天性巨食道症幼犬[6]。

营养管理构成治疗的基石。犬必须使用贝利椅在垂直位置喂食，喂食后保持直立20-30分钟以利用重力[1][7]。食物稠度应个体化--有些犬耐受流质糊状食物，而其他犬则需要肉丸状食物。通常需要多次少量喂食（每天5-6次），首选高热量、低脂饮食[7]。

胃保护剂包括硫糖铝液体和酸抑制剂（法莫替丁、奥美拉唑）有助于管理并发食管炎[7]。促动力药物如甲氧氯普胺可能有助于胃排空，尽管它们对食道蠕动的疗效有限[1][6]。

对于持续反流或营养不良的严重病例，经皮内窥镜胃造口术（PEG）管通过完全绕过食道提供挽救生命的营养支持[1][9]。吸入性肺炎作为主要死亡原因，需要根据培养结果进行4-6周的积极抗生素治疗[1][7]。

### Sources

[1] Diagnosis and management of megaesophagus in dogs: https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings
[2] Successful treatment of megaesophagus with sildenafil: https://avmajournals.avma.org/view/journals/ajvr/86/2/ajvr.24.09.0281.xml
[3] Dilatation of the Esophagus in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/dilatation-of-the-esophagus-in-small-animals
[4] Managing Megaesophagus in Dogs - Veterinary Partner: https://veterinarypartner.vin.com/default.aspx?pid=19239&catId=102899&id=5887292
[5] Canine Idiopathic Megaesophagus - VIN: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3843778&pid=8708
[6] Percutaneous placement of a gastrostomy tube: https://www.dvm360.com/view/percutaneous-placement-gastrostomy-tube-proceedings

## 预防措施

巨食道症的预防侧重于解决潜在原因、实施环境控制和预防危及生命的并发症。由于继发性巨食道症可能由重症肌无力、系统性红斑狼疮和中枢神经系统疾病等引起，及早发现和治疗这些疾病至关重要[1]。

**疫苗接种对预防传染性原因至关重要。**成功预防犬瘟热病毒需要使用改良活病毒疫苗，在6周龄时给幼犬接种，并以3-4周间隔接种直到16周龄[2]。犬瘟热病毒损害气道并使动物易患肺炎，这可能增加巨食道症风险。

**环境毒素预防**包括避免接触重金属（铅）和铊，它们可引起继发性巨食道症[1]。妥善储存化学品和定期对犬舍进行环境评估有助于最大限度减少毒素暴露风险。

**受影响品种的繁殖建议**包括在可能的情况下对先天性形式进行基因检测[3]。对先天性巨食道症易感的品种包括纽芬兰犬、杰克罗素㹴、萨摩耶犬和沙皮犬，其中某些形式显示遗传模式需要谨慎的繁殖决策[3]。

**吸入性肺炎预防**是最关键的管理方案，因为它通常是巨食道症患者的死亡原因[1]。关键策略包括在直立位置喂食犬，前肢抬高，喂食后保持此姿势10-15分钟，并使用频繁的小餐而非大份量[1]。识别早期呼吸症状能够在肺炎危及生命之前及时进行干预。

### Sources

[1] Merck Veterinary Manual Dilatation of the Esophagus: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/dilatation-of-the-esophagus-in-small-animals
[2] Merck Veterinary Manual Canine Distemper: https://www.merckvetmanual.com/generalized-conditions/canine-distemper/canine-distemper
[3] DVM360 Diagnosis and management of megaesophagus in dogs: https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings

## 鉴别诊断

将巨食道症与其他反流原因进行系统区分需要仔细评估多个临床参数[1]。主要鉴别诊断包括无扩张的食道异物、胃食管反流病、食管裂孔疝和无巨食道症的重症肌无力。

食道异物通常在 witnessed 摄入后表现为急性发作反流，与巨食道症的慢性进行性病程形成对比[2]。胸部X线平片通常将异物显示为软组织密度影，而巨食道症则显示特征性的弥漫性食道扩张伴有空气或液体[1]。重要的是，一些巨食道症病例在平片上可能不可见，需要食道造影术进行明确诊断[4]。

胃食管反流病表现为反流、流涎和颈部伸展，但缺乏巨食道症在放射学上显示的全身性食道扩张[3]。然而，区分这些条件可能具有挑战性，因为胃食管反流可能被食管炎加剧甚至由其引起，形成正反馈循环，可能加重反流[8]。

食管裂孔疝表现相似，但在对比研究上显示胃内容物通过食管裂孔的颅侧移位[3]。内窥镜检查发现包括液体在尾侧食道中积聚、食管裂孔开口扩大和胃食管括约肌颅侧移位[6]。

无巨食道症的重症肌无力以全身性神经肌肉无力为主要体征，而仅影响食道的局灶性重症肌无力则产生伴有反流的巨食道症[1]。乙酰胆碱受体抗体检测有助于区分这些表现，尽管可能出现血清阴性病例[1]。

区分因素包括发病时间、放射学发现、全身性无力存在以及对特定诊断测试（如乙酰胆碱受体抗体）的反应[1]。

### Sources

[1] Diagnosis and management of megaesophagus in dogs: https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings
[2] Esophageal foreign bodies, esophagitis and strictures: https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings
[3] Gastrointestinal motility disorders caused by esophageal disease: https://www.dvm360.com/view/gastrointestinal-motility-disorders-caused-by-esophageal-disease
[4] Is it megaesophagus or a normal variation?: https://www.dvm360.com/view/it-megaesophagus-or-normal-variation
[5] Fun with radiographic contrast procedures: https://www.dvm360.com/view/fun-with-radiographic-contrast-procedures-proceedings-0
[6] Regurgitation, dysphagia, and esophageal dysmotility: https://www.dvm360.com/view/regurgitation-dysphagia-and-esophageal-dysmotility-proceedings
[7] A challenging case: Acute-on-chronic vomiting in a German shepherd: https://www.dvm360.com/view/challenging-case-acute-chronic-vomiting-german-shepherd
[8] Common esophageal diseases that are commonly missed: https://www.dvm360.com/view/common-esophageal-diseases-are-commonly-missed-proceedings

## 预后

犬猫巨食道症的预后根据潜在病因和并发症存在而有显著差异[1]。总体预后通常谨慎至不良，生存时间为1-3个月，在某些研究中死亡率达到74%[2]。

**先天性与获得性形式**
先天性巨食道症预后尚可，20-40%的受影响幼犬显示出改善[5]。一些先天性形式的动物可能在6个月龄时"摆脱疾病"，特别是迷你雪纳瑞犬通常在6-12个月内恢复正常[1,5]。然而，大多数长期患有巨食道症的犬倾向于发展为致命性并发症。

**预后因素**
最重要的预后因素包括吸入性肺炎的放射学证据和临床症状发作年龄，两者均与生存时间显著相关[2]。早期诊断、适当的喂食技术和及时识别吸入性肺炎对成功至关重要[5]。患有潜在可治疗疾病如重症肌无力的犬可能在1个月至1年内达到临床缓解，大多数恢复食道张力[5]。

**长期结果**
吸入性肺炎仍然是主要死亡原因，作为一种频繁且常常致命的并发症发生[3,6]。特发性巨食道症动物预后特别差，由于易受反复吸入发作、体重减轻和持续反流的影响[6]。生活质量考虑变得至关重要，因为主人必须承诺终身进行抬高喂食方案并警惕监测呼吸并发症。

### Sources

[1] Disorders of the Esophagus in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-esophagus-in-dogs
[2] Dilatation of the Esophagus in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/dilatation-of-the-esophagus-in-small-animals
[3] Congenital and Inherited Anomalies of the Esophagus in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/congenital-and-inherited-anomalies-involving-the-digestive-system/congenital-and-inherited-anomalies-of-the-esophagus-in-animals
[4] Risk factors for acquired megaesophagus in dogs - JAVMA: https://avmajournals.avma.org/view/journals/javma/211/11/javma.1997.211.11.1406.xml
[5] Diagnosis and management of megaesophagus in dogs - DVM 360: https://www.dvm360.com/view/diagnosis-and-management-megaesophagus-dogs-proceedings
[6] Esophageal disease - DVM 360: https://www.dvm360.com/view/esophageal-disease-proceedings-0
