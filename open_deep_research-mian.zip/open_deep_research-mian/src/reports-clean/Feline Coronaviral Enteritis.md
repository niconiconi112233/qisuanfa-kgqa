# 猫冠状病毒性肠炎

## 疾病概述

猫冠状病毒性肠炎是一种由猫肠道冠状病毒（FECV）引起的胃肠道疾病，FECV是猫冠状病毒（FCoV）的一种良性生物型，通常在受感染的猫中引起轻微、自限性的肠道疾病或保持无症状（默克兽医手册，2024年）。该疾病主要影响肠道的成熟上皮细胞，受感染的猫在感染后可能持续排毒数周至无限期（默克兽医手册，2024年）。

从流行病学角度看，FCoV表现出显著的年龄相关感染模式，0-1岁幼猫的检出率最高，为46.6%，而2-10岁猫为34.1%，10岁以上猫仅为21.6%（JAVMA，2023年）。雄性感染易感性较高，为42.4%，而雌性为34.3%，在4岁以下猫中这种差异尤为明显（JAVMA，2023年）。某些纯种猫系，包括波斯猫、英国短毛猫、巴厘猫、缅甸猫和喜马拉雅猫，表现出发展为临床症状的易感性增加（DVM360，2024年）。

关键的流行病学关注点在于FECV通过内部基因变化突变为猫传染性腹膜炎病毒（FIPV）的潜力，这种转变将一种良性肠道病原体转变为一种能够在巨噬细胞中复制的强毒力全身性疾病（默克兽医手册，2024年）。

## 常见病原体

猫冠状病毒性肠炎由猫冠状病毒（FCoV）引起，这是一种有包膜的单链RNA病毒，属于套式病毒目、冠状病毒科[1]。FCoV根据抗原差异分为两种不同的血清型。血清型I是全球猫群中最普遍的形式，而血清型II则是一种重组形式，其刺突基因被犬冠状病毒刺突基因取代[2]。

该病毒存在两种主要生物型，具有显著不同的致病潜力。猫肠道冠状病毒（FECV）通常引起轻微、自限性的胃肠道疾病或保持亚临床状态[1]。然而，通过在受感染猫体内的内部突变，FECV可转变为猫传染性腹膜炎病毒（FIPV），这是一种能够在巨噬细胞内复制的强毒力生物型[2]。这种关键的生物型转变涉及3c基因的突变以及刺突蛋白融合肽中的特定核苷酸变化[2]。

由于FCoV具有庞大的RNA基因组和较高的突变率，表现出相当大的遗传变异性，导致受感染的猫排出异质性病毒种群，称为准种[2]。该病毒主要在成熟的肠道上皮细胞中复制，受感染的猫可能持续排毒较长时间，从数周到无限期不等[1]。

### Sources
[1] Feline Enteric Coronavirus Infection - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-enteric-coronavirus-infection
[2] Feline Infectious Peritonitis - Merck Veterinary Manual: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis

## 临床症状和体征

猫冠状病毒（FCoV）感染通常表现为轻微、短暂的胃肠道症状或完全无症状[1]。当确实出现临床症状时，通常包括轻微腹泻、呕吐、上呼吸道症状、体重减轻和幼猫生长迟缓[2]。

年龄显著影响疾病表现。0-1岁幼猫的FCoV检出率最高，为46.6%，而2-10岁猫为34.1%，10岁以上猫仅为21.6%[3]。然而，归因于FIP的临床症状偶尔可在10岁以上老年猫中出现，这可能代表持续了数月或数年的慢性感染[1]。

雄性感染率（42.4%）高于雌性（34.3%），这种差异在4岁以下猫中最为显著[3]。某些纯种猫系，特别是波斯猫、英国短毛猫、巴厘猫、缅甸猫和喜马拉雅猫，表现出发展为临床疾病的易感性增加[1]。

当FCoV突变为强毒力FIP形式时，临床表现变得更加严重和多样。渗出性"湿"型导致进行性腹胀、呼吸困难、持续2-5周的发热、厌食和体重减轻[2]。非渗出性"干"型产生影响多个器官的肉芽肿性病变，引起伴有慢性发热、不适和潜在器官系统衰竭的模糊疾病[2]。眼部和神经系统体征可能同时或独立出现，包括前葡萄膜炎、视网膜改变、共济失调、癫痫和精神状态改变[2]。

### Sources
[1] FIP: More complex than we thought!: https://www.dvm360.com/view/fip-more-complex-we-thought-proceedings
[2] Feline Infectious Peritonitis (FIP) - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-infectious-peritonitis-fip
[3] Insights on feline infectious peritonitis risk factors: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.03.0208.xml

## 诊断方法

诊断猫冠状病毒性肠炎面临重大挑战，因为难以区分良性猫肠道冠状病毒（FECV）和致病性FIP病毒（FIPV）。临床表现评估仍是基础，因为伴有腹水或胸腔积液的渗出性形式比非渗出性形式更容易诊断[1]。体格检查发现包括充满液体的扩张肠袢，而实验室评估通常显示中性粒细胞增多、淋巴细胞减少，约75%的非渗出性病例血浆蛋白升高超过7.8 g/dL[1]。

**分子诊断**已成为重要工具，逆转录-聚合酶链反应（RT-PCR）检测可检测各种样本（包括渗出液、血清、血浆和粪便）中的病毒抗原[1]。然而，标准RT-PCR无法区分FIPV和FECV，限制了其诊断特异性[1]。最近的进展包括通过RT-PCR检测循环单核细胞内复制冠状病毒的信使RNA，这表明存在FIP特征性的活跃病毒复制[1]。奥本大学分子诊断实验室等商业实验室提供这种专业检测[1]。

**样本选择显著影响诊断成功率。**腹水与其他样本相比检出率最高，比值比为7.51，而全血检出率明显较低（OR 0.08）[6]。肾脏、淋巴结和尿液样本也产生较高的FCoV检出率和病毒载量[6]。血液中的假阴性结果反映了即使在暴发性FIP病例中也通常不存在或极低的病毒血症[6]。

**渗出液分析**在存在时提供有价值的诊断信息。特征性发现包括高蛋白含量（5-12 g/dL）、腹液中白蛋白:球蛋白比值小于0.81，以及球蛋白分数超过总蛋白的32%[3]。组织病理学仍然是确定性的生前诊断方法，需要通过免疫组织化学检测组织巨噬细胞内的病毒抗原[3]。

### Sources
[1] FIP: More complex than we thought! (Proceedings): https://www.dvm360.com/view/fip-more-complex-we-thought-proceedings
[2] FIP: Research can explain correlation between high titers, poor prognosis: https://www.dvm360.com/view/fip-research-can-explain-correlation-between-high-titers-poor-prognosis
[3] Feline infectious peritonitis (FIP): more complex than we thought (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-fip-more-complex-we-thought-proceedings
[4] Infectious neurologic diseases of puppies and kittens (Proceedings): https://www.dvm360.com/view/infectious-neurologic-diseases-puppies-and-kittens-proceedings
[5] Merck Veterinary Manual Feline Enteric Coronavirus: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/feline-enteric-coronavirus
[6] Journal of the American Veterinary Medical Association Insights on feline infectious peritonitis risk factors and sampling strategies: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.03.0208.xml
