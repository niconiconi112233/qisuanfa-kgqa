# 伴侣动物洋葱中毒症

洋葱中毒症是犬猫中一种严重的兽医急症，由摄入葱属植物引起，包括洋葱、大蒜、韭菜和韭葱。该病症每年通过氧化性溶血影响数千只伴侣动物，导致可能危及生命的海因茨小体贫血。猫表现出特别的易感性，摄入仅5g/kg即可发生中毒，而犬则需要15-30g/kg。日本犬种由于影响红细胞抗氧化防御的遗传因素而表现出更高的易感性。本报告探讨了从初始氧化损伤到溶血级联反应的全面病理生理学、包括海因茨小体识别和鉴别诊断考虑的诊断方案、涵盖净化和输血标准的循证治疗策略，以及针对宠物主人关于所有含葱属植物产品的关键预防措施。

## 疾病概述

洋葱中毒症是一种由摄入葱属植物引起的严重疾病，包括洋葱（Allium cepa）、大蒜（Allium sativum）、韭菜（Allium schoenoprasum）和韭葱（Allium porrum）[1]。这种中毒症通过氧化性溶血影响犬和猫，导致海因茨小体贫血和可能危及生命的并发症[1]。

犬和猫对洋葱中毒症高度易感，猫比犬更敏感[1]。猫摄入仅5 g/kg的洋葱或犬摄入15-30 g/kg的洋葱即可导致临床上显著的血液学变化[1][2]。当动物一次摄入超过其体重0.5%的洋葱时，会持续发生中毒[1]。

日本犬种由于遗传性的高红细胞还原型谷胱甘肽和钾浓度而表现出增加的易感性[1]。常见的暴露来源包括新鲜洋葱、烹饪制品、脱水片、粉末、洋葱汤混合物以及任何含有葱属植物的食物制品[1][2]。烹饪和腐败都不会降低这些植物的毒性潜力[1]。

### Sources
[1] Toxicology Brief: Allium species poisoning in dogs and cats: https://www.dvm360.com/view/toxicology-brief-allium-species-poisoning-dogs-and-cats
[2] A pungent poisoning: Onion toxicosis in a cat: https://www.dvm360.com/view/pungent-poisoning-onion-toxicosis-cat

## 病理生理学和临床表现

伴侣动物洋葱中毒症是由于摄入葱属植物中的含硫氧化剂引起的，这些氧化剂对红细胞造成严重的氧化损伤[1]。这些有机亚砜通过咀嚼或烹饪机械释放，并被胃肠道微生物进一步代谢为高活性的二硫化物化合物[1,2]。

主要机制涉及对红细胞膜的氧化损伤，导致在摄入后24小时内形成海因茨小体[1]。海因茨小体代表沉淀的变性的血红蛋白，当血红蛋白中的巯基被氧化时形成[1,2]。这个过程同时产生高铁血红蛋白血症并降低葡萄糖-6-磷酸脱氢酶活性，最终降低通常保护红细胞免受氧化损伤的谷胱甘肽浓度[2]。

溶血级联反应通常在摄入后约72小时达到峰值，在暴露后3-5天发生显著溶血[1]。临床症状通常仅在显著溶血发展后才显现[1]。初始胃肠道症状包括呕吐和腹泻，随后是贫血的全身性表现，包括嗜睡、虚弱、呼吸急促、心动过速、运动不耐受以及苍白或黄疸的黏膜[1,2]。

猫对洋葱中毒症表现出特别的易感性，因为猫血红蛋白对氧化损伤的易感性增加，具有更高浓度的暴露的β-93半胱氨酸残基[2]。临床症状可在摄入后12小时出现，但更常见于暴露后2-5天[2]。可能观察到因血红蛋白尿引起的深色尿液，造成肾毒性的继发风险[1]。

### Sources
[1] Garlic and Onion (Allium spp) Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/food-hazards/garlic-and-onion-allium-spp-toxicosis-in-animals
[2] Toxicology Brief: Allium species poisoning in dogs and cats: https://www.dvm360.com/view/toxicology-brief-allium-species-poisoning-dogs-and-cats

## 诊断方法和鉴别诊断

洋葱中毒症的诊断主要依赖于患者的暴露史、临床症状和临床病理学确认[1]。全面的饮食史至关重要，包括最近摄入的生、熟、脱水或浓缩的葱属产品[2]。临床症状通常在暴露后3-5天出现，猫在摄入仅5g/kg洋葱后即出现症状[2]。

实验室诊断包括全血细胞计数与网织红细胞计数、血涂片检查海因茨小体和球形细胞、血清生化面板重点关注胆红素和肝酶，以及尿液分析以检测血红蛋白尿[1][2]。海因茨小体在24小时内出现，但临床溶血发生较晚[1]。玻片凝集试验有助于与免疫介导原因区分[4]。

同时的药物暴露或影响红细胞抗氧化防御的状况会增加易感性，包括葡萄糖-6-磷酸脱氢酶缺乏症、锌缺乏症以及同时使用丙泊酚、对乙酰氨基酚或其他氧化性药物治疗[5]。日本犬种由于遗传性的高红细胞谷胱甘肽浓度而表现出增加的易感性[5]。

关键的鉴别诊断包括免疫介导性溶血性贫血（IMHA），表现为球形细胞和Coombs试验阳性，但缺乏海因茨小体[4]。锌中毒症引起类似的血管内溶血，但需要放射学检测金属异物[4]。其他氧化原因包括丙二醇、苯佐卡因、对乙酰氨基酚、铜中毒症以及糖尿病、肝脂质沉积症、甲状腺功能亢进和淋巴瘤等状况[5]。

### Sources
[1] Garlic and Onion (Allium spp) Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/garlic-and-onion-allium-spp-toxicosis-in-animals
[2] A pungent poisoning: Onion toxicosis in a cat: https://www.dvm360.com/view/pungent-poisoning-onion-toxicosis-cat
[3] Image:Heinz body hemolytic anemia, cat-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/image/heinz-body-hemolytic-anemia-cat
[4] Immune-mediated hemolytic anemia: Understanding and diagnosing a complex disease: https://www.dvm360.com/view/immune-mediated-hemolytic-anemia-understanding-and-diagnosing-complex-disease
[5] Toxicology Brief: Allium species poisoning in dogs and cats: https://www.dvm360.com/view/toxicology-brief-allium-species-poisoning-dogs-and-cats

## 治疗选择

伴侣动物洋葱中毒症的治疗需要立即净化、支持性护理和仔细监测溶血性贫血并发症[1]。先进的治疗方案已经得到完善，以优化受影响患者的治疗效果。

**净化和初始管理**
对于最近的暴露，积极的净化包括催吐后给予活性炭[1]。应立即评估基线血液检查，包括血细胞比容（PCV）和全血细胞计数[1]。患者需要在5-7天内或直到贫血稳定期间每1-2天进行一次强化监测。

**输血和氧气支持**
根据贫血严重程度和临床症状，可能需要全血输注和/或浓缩红细胞[1]。对于严重贫血的患者应考虑新鲜全血输注[2]。当严重贫血损害组织氧合时，氧气支持变得至关重要。

**液体管理和监测**
积极的静脉输液治疗支持循环并促进毒素消除[1][2]。患者需要在关键时期住院，持续监测血细胞比容、临床参数和呼吸状态。

**恢复时间线**
贫血通常在摄入后10-14天内解决[1]。胃肠道症状应通过支持性护理进行管理，包括根据需要使用止吐药和清淡饮食。

### Sources
[1] The most common poisons for pets: https://www.dvm360.com/view/the-most-common-poisons-for-pets
[2] Possible IMHA dog-now what?: https://www.dvm360.com/view/possible-imha-dog-now-what

## 预防和预后

### 预防措施

初级预防侧重于客户教育关于有毒葱属植物来源。宠物主人必须被告知，所有形式的洋葱、大蒜、韭菜和韭葱都构成重大风险，包括新鲜、烹饪、脱水、粉末制品以及含有这些成分的食物[1]。环境管理需要严格将所有含葱属植物的产品排除在宠物可接触区域之外，包括人类食物、烹饪制品和含有大蒜或洋葱衍生物的膳食补充剂[2]。

日本犬种由于影响红细胞抗氧化防御的遗传易感性因素需要加强警惕[1]。同时引起氧化损伤的药物（丙泊酚、磺胺类药物、对乙酰氨基酚）或营养缺乏（葡萄糖-6-磷酸脱氢酶缺乏症、锌缺乏症）增加中毒风险并需要仔细监测[1]。

### 预后因素

预后取决于涉及的葱属植物种类、摄入量、开始治疗的时间和溶血性贫血的严重程度[1][2]。猫比犬表现出更高的易感性，摄入仅5 g/kg即可发生中毒，而犬需要15-30 g/kg[2]。临床症状通常在摄入后1-3天内发展，贫血最低点发生在几天后[1][2]。

恢复时间线因贫血严重程度和支持性护理实施而异。接受及时净化和液体治疗的患者通常表现出良好的预后[1]。长期监测应包括暴露后几天内连续全血细胞计数，以检测延迟的溶血发展。

### Sources

[1] Toxicology Brief: Allium species poisoning in dogs and cats: https://www.dvm360.com/view/toxicology-brief-allium-species-poisoning-dogs-and-cats

[2] Garlic and Onion (Allium spp) Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/food-hazards/garlic-and-onion-allium-spp-toxicosis-in-animals
