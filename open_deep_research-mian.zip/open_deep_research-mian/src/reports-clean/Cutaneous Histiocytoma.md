# 犬皮肤组织细胞瘤

皮肤组织细胞瘤是兽医医学中最独特的皮肤肿瘤之一，呈现出快速生长后自发消退的迷人悖论。这种良性朗格汉斯细胞肿瘤主要影响三岁以下的幼犬，占所有犬类皮肤肿瘤的3-14%。尽管表现出侵袭性生长特征和高有丝分裂指数，这些病变仍保持良性生物学行为，通常通过免疫介导机制在无干预情况下消退。

本综合报告探讨了皮肤组织细胞瘤管理的完整范围，从初始临床表现和诊断挑战到治疗决策和预后考虑。重点领域包括与恶性圆形细胞肿瘤（如肥大细胞瘤和淋巴瘤）的鉴别诊断、了解显著的CD8+ T细胞介导的消退过程，以及为受影响患者建立适当的监测方案。

## 疾病概述与流行病学

皮肤组织细胞瘤是犬类的一种良性皮肤肿瘤，代表一种表达特定表面标记（包括CD1和β2-整合素分子）的亲表皮性朗格汉斯细胞组织细胞增生症[1]。该肿瘤被归类为起源于树突细胞谱系的良性增殖性疾病，特别是皮肤中的表皮朗格汉斯细胞[1]。

皮肤组织细胞瘤占犬类所有皮肤肿瘤的3%至14%，使其成为相对常见的皮肤肿瘤[1]。该疾病主要影响幼犬，3岁后发病率显著下降[1]。虽然组织细胞瘤可发生于任何年龄的犬，但绝大多数病例在3岁以下的犬中被诊断出[1]。

已记录几个品种的易感性，包括拳师犬、腊肠犬、可卡犬、大丹犬、设得兰牧羊犬和牛头梗[1]。该疾病没有明显的性别偏好[1]。肿瘤通常表现为单个、快速生长、隆起的纽扣状病变，直径小于2-3厘米[1]。这些病变最常见于四肢、头部、耳朵或颈部[1]。

尽管生长迅速且常有丝分裂指数高，皮肤组织细胞瘤仍保持良性生物学行为[1]。一些犬在诊断时可能表现为多个病变，已有报道组织细胞瘤伴区域淋巴结受累，特别是在沙皮犬中[1]。

### Sources

[1] An overview of canine histiocytic disorders: https://www.dvm360.com/view/overview-canine-histiocytic-disorders

## 病因学与病理生理学

皮肤组织细胞瘤的病因在很大程度上仍不清楚，尽管该疾病起源于树突来源的表皮朗格汉斯细胞(1)。这些肿瘤表达其朗格汉斯细胞谱系特征的表面标记，包括CD1a、CD1b、CD1c、主要组织相容性复合物II、CD11c和E-钙粘蛋白(1)。

病理生理学涉及树突细胞在增殖性组织细胞增生症复合体内的异常增殖(2)。组织细胞由骨髓中的CD34+干细胞前体分化而来，其命运受特定细胞因子组合的影响，包括粒细胞-巨噬细胞集落刺激因子、转化生长因子β、肿瘤坏死因子α和白介素-4(1,2)。

尽管是良性的，组织细胞瘤表现出高有丝分裂指数，形成矛盾的细胞行为(1)。最显著的方面涉及通过CD8+细胞毒性T细胞浸润病变而自发消退(1)。这种独特的免疫介导消退使组织细胞瘤与其他组织细胞疾病区别开来，大多数病例在三个月内无需干预即可消退(1)。不同程度的炎症细胞浸润的存在通常表明正在活跃消退(1)。

### Sources
[1] An overview of canine histiocytic disorders: https://www.dvm360.com/view/overview-canine-histiocytic-disorders
[2] Canine histiocytic sarcoma complex: recent advances: https://www.dvm360.com/view/canine-histiocytic-sarcoma-complex-recent-advances-proceedings

## 临床表现与诊断

皮肤组织细胞瘤通常表现为3岁以下幼犬的单个、界限分明的皮肤结节[1]。这些病变最常见于头部、耳朵和四肢，呈隆起的圆顶状肿块[3]。肿瘤起源于表皮的朗格汉斯细胞，在细胞学检查中表现为具有中等量淡嗜碱性细胞质的单个圆形细胞[1]。

细胞学上，组织细胞瘤细胞以离散的圆形细胞脱落，具有含细染色质和不明显核仁的椭圆形或凹陷核[1]。细胞质的外缘通常比核周区域染色更浅，形成特征性外观[1]。大多数病变在CD8+ T细胞浸润后经历自发消退，因此在细胞学制备中经常观察到小淋巴细胞的存在[1]。

细针抽吸是主要的诊断方法，为细胞学评估提供足够的细胞材料[6]。这些细胞在外观上通常均匀，无明显异型性[1]。明确诊断需要组织病理学检查，这揭示了组织细胞在血管周围的特征性积聚及其典型形态学特征[1][3]。与其他圆形细胞肿瘤（如肥大细胞瘤、淋巴瘤和恶性组织细胞增多症）的鉴别至关重要，因为这些疾病的预后和治疗要求明显不同[1][4]。

### Sources
[1] Differentiating the round cell tumors (Proceedings): https://www.dvm360.com/view/differentiating-round-cell-tumors-proceedings
[2] Pathology in Practice in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/256/5/javma.256.5.559.xml
[3] Neoplastic skin disorders (Proceedings): https://www.dvm360.com/view/neoplastic-skin-disorders-proceedings
[4] Computed tomographic findings and clinical features in dogs ...: https://avmajournals.avma.org/view/journals/javma/259/12/javma.20.11.0635.xml
[5] Pathology in Practice in: Journal of the American Veterinary ...: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0253.xml
[6] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/en-au/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗方法与预后

皮肤组织细胞瘤由于其良性性质和自发消退倾向，通常具有极好的预后[1]。大多数犬组织细胞瘤应被视为良性，并在2-3个月内无需治疗自发消退[2]。管理方法通常遵循保守策略，除非特定指征需要干预。

**治疗选择**

主要治疗方法是观察，因为消退可能在发生后2个月内发生[1]。一旦诊断确认，手术切除是可选的，并且当执行时通常是治愈性的[2]。手术干预的特定指征包括诊断不确定或患者因病变而自残[1]。手术切除的原因还包括病变引起不适或主人有美容顾虑的情况。

**症状管理**

在等待自发消退期间，抗组胺药如羟嗪可能有助于减轻瘙痒[1]。对于单个病变通常不需要其他药物，化疗很少有用[1]。

**预后与消退时间表**

皮肤组织细胞瘤的预后极好，大多数病变在2-3个月内消退[2]。然而，老年犬的组织细胞瘤应被视为潜在恶性，因为它们可能进展为播散性形式[3]。极好的预后主要适用于三岁以下幼犬的典型表现。

### Sources
[1] Neoplastic skin disorders (Proceedings): https://www.dvm360.com/view/neoplastic-skin-disorders-proceedings
[2] Lymphocytic, Histiocytic, and Related Cutaneous Tumors in Animals: https://www.merckvetmanual.com/en-au/integumentary-system/tumors-of-the-skin-and-soft-tissues/lymphocytic-histiocytic-and-related-cutaneous-tumors-in-animals
[3] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0

## 鉴别诊断与临床要点

皮肤组织细胞瘤的主要鉴别诊断包括肥大细胞瘤、淋巴瘤和组织细胞肉瘤，每种都需要仔细评估以与这种良性病变区分。

**肥大细胞瘤**是最关键的鉴别诊断，因为它们是犬类最常见的恶性皮肤肿瘤，临床上可能模拟组织细胞瘤[1]。肥大细胞的特征是在细胞学上具有特征性的异染性细胞质颗粒，尽管分化不良的肿瘤可能很少有颗粒[1]。临床要点：始终使用Wright-Giemsa染色进行细针抽吸，因为Diff-Quik可能使肥大细胞脱颗粒，可能导致误诊[5]。

**淋巴瘤**，特别是皮肤形式，可表现为单个或多个结节，类似组织细胞瘤[1]。细胞学上，与多形性组织细胞相比，淋巴瘤细胞通常在大小和核形态上表现出更多均匀性[10]。亲表皮性皮肤淋巴肉瘤通常在老年犬中表现为进行性脱屑和瘙痒，与组织细胞瘤在幼年动物中的典型快速生长形成对比[1]。

**组织细胞肉瘤**构成最大的诊断挑战，因为两种肿瘤都起源于组织细胞[9]。然而，组织细胞肉瘤发生在老年犬中（特别是伯尔尼山地犬、金毛寻回犬和罗威纳犬），表现出明显的细胞异型性及恶性标准，并且经常显示吞噬血细胞的现象[9]。与良性组织细胞瘤不同，这些肿瘤具有高度侵袭性且预后不良。

鉴别的临床要点包括年龄评估（组织细胞瘤主要影响<3岁的犬）、评估2-3个月内的自发消退，以及认识到可能发生多个组织细胞瘤但仍保持良性行为[6]。当细胞学不确定时，免疫组织化学标记物（CD1a、CD1b、CD1c）可以确认组织细胞瘤诊断[9]。

### Sources
[1] Merck Veterinary Manual Lymphocytic, Histiocytic, and Related Cutaneous Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/lymphocytic,-histiocytic,-and-related-cutaneous-tumors-in-animals
[2] DVM 360 Canine cutaneous mast-cell tumors: Current concepts for patient management: https://www.dvm360.com/view/canine-cutaneous-mast-cell-tumors-current-cocnepts-patient-management
[3] Neoplastic skin disorders (Proceedings): https://www.dvm360.com/view/neoplastic-skin-disorders-proceedings
[4] An overview of canine histiocytic disorders: https://www.dvm360.com/view/overview-canine-histiocytic-disorders
[5] Differentiating the round cell tumors (Proceedings): https://www.dvm360.com/view/differentiating-round-cell-tumors-proceedings

## 预防与主人教育

皮肤组织细胞瘤是一种预后极佳的良性皮肤肿瘤，但主人教育对于获得最佳结果仍然至关重要。大多数组织细胞瘤在三个月内无需干预自发消退[1]。然而，主人应监测病变是否需要兽医注意的迹象，包括溃疡、继发感染或过度瘙痒，这些可能需要手术切除。

预防策略有限，因为这些肿瘤主要通过不明确的机制影响幼犬，可能涉及免疫系统失调[1]。一些犬，特别是沙皮犬，可能发展出多个组织细胞瘤并伴有延迟消退模式[7]。主人应了解，虽然大多数病变自然消退，但多个肿瘤可能需要延长监测期。

关键的主人咨询要点包括识别典型表现为快速生长、隆起、无毛的病变，常见于四肢、头部或颈部[1]。如果病变变得疼痛、感染或三个月后仍未消退，主人应寻求兽医护理。细针抽吸提供明确诊断，并将组织细胞瘤与其他需要不同管理方法的皮肤肿瘤区分开来。

在典型消退期间定期监测有助于确保适当的进展。易感品种的主人应保持对新病变发展的高度警惕。虽然不存在特定的预防措施，但常规兽医检查有助于早期发现和适当管理任何令人担忧的皮肤肿块。

### Sources

[1] An overview of canine histiocytic disorders: https://www.dvm360.com/view/overview-canine-histiocytic-disorders
[2] Deciphering the histiocytic code: https://www.dvm360.com/view/deciphering-histiocytic-code
