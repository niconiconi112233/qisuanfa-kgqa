# 犬猫低钾血症：综合临床指南

低钾血症，定义为血清钾浓度低于正常范围（3.5-5.2 mmol/L），是伴侣动物医学中一种可能危及生命的关键电解质紊乱。这种电解质失衡影响20-30%患有慢性肾病的猫，并且通常继发于由犬细小病毒等传染病引起的胃肠道丢失。该病症通过特征性临床表现显现，包括肌肉无力、猫颈部腹屈和心律失常。本报告探讨了低钾血症的病理生理学、诊断方法和基于证据的治疗方案，强调了物种特异性考虑因素以及识别潜在病因对最佳患者结局的重要性。

## 疾病概述

低钾血症定义为犬猫血清钾浓度低于正常范围。正常的钾稳态主要由肾脏维持，肾脏是体内钾调节的主要部位 [1]。大约80%的滤过钾在近端小管和亨利袢中被重吸收，最终调节在醛固酮影响下于集合管进行 [1]。

体内总钾的至少95%位于细胞内，其中骨骼肌含有60-75%的细胞内钾储备 [2]。这种分布至关重要，因为Na+/K+-ATP酶产生的钾梯度创造了细胞膜上的负电位 [2]。

低钾血症在肾功能不全的猫中尤为常见，在初次就诊时影响20-30%的慢性肾病患者 [1][4]。该情况通常表示全身性钾耗竭，但在高血糖导致的高胰岛素血症病例中除外，此时钾可能已转移到细胞内 [2]。

犬猫正常血清钾浓度范围为3.5至5.2 mmol/L [3]。低钾血症可分为轻度（3.0-3.4 mmol/L）、中度（2.5-3.0 mmol/L）或重度（<2.5 mmol/L）[3]。尿量大的动物肾小管流速增加，通过增强尿钾丢失使其易患低钾血症 [1]。 

### Sources
[1] Therapeutic implications of recent findings in feline renal insufficiency: https://www.dvm360.com/view/therapeutic-implications-recent-findings-feline-renal-insufficiency-proceedings
[2] Overview of Disorders of Potassium Metabolism in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals
[3] Hypokalemia: https://www.ncbi.nlm.nih.gov/books/NBK482465/
[4] Facilitating client management of chronic kidney disease: https://www.dvm360.com/view/facilitating-client-management-chronic-kidney-disease-proceedings

## 常见病原体

伴侣动物的低钾血症通常继发于通过呕吐和腹泻引起显著胃肠道液体丢失的传染病 [1]。最突出的传染性病因是犬细小病毒（CPV），特别影响6周至6个月大、未接种疫苗的幼犬 [1]。

**病毒病原体：** 犬细小病毒是引起犬低钾血症性胃肠炎的主要病毒原因。临床症状通常在感染后5-7天内出现，特征是出血性腹泻 [1]。该病毒破坏快速分裂的肠隐窝上皮细胞，导致绒毛萎缩和肠道屏障功能受损 [3]。血液生化反映脱水和电解质紊乱，包括低钾血症 [4]。这些患者可能通过呕吐和腹泻丢失大量钾，导致肌肉无力、胃肠麻痹、多尿、心律失常和全身不适 [1][2]。

**细菌因素：** 虽然细菌不是直接引起低钾血症的主要病原体，但在细小病毒性肠炎中，细菌穿过受损肠上皮的移位可导致脓毒症和内毒素血症 [2]。由*沙门氏菌*属、*空肠弯曲杆菌*和*产气荚膜梭菌*等生物体引起的继发性细菌感染可通过严重腹泻加剧液体和电解质丢失 [7]。这些病原体经常通过持续的胃肠道丢失导致显著的钾耗竭。

**其他传染性病原体：** 猫泛白细胞减少症病毒引起与犬细小病毒相似的病理生理学，破坏肠隐窝上皮并导致包括钾耗竭在内的液体和电解质丢失 [4]。任何引起严重胃肠炎的传染性病原体都可能通过超过代偿能力的持续丢失导致低钾血症发生。犬和猫的冠状病毒感染可引起大量腹泻，导致电解质失衡 [7]。

### Sources
[1] Canine Parvovirus Infection: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[2] Treatment of severe parvoviral enteritis: https://www.dvm360.com/view/treatment-severe-parvoviral-enteritis-proceedings
[3] Hypertonic phosphate enema intoxication in dogs and cats: https://www.dvm360.com/view/hypertonic-phosphate-enema-intoxication-dogs-and-cats
[4] Therapy and vaccination for a new canine parvovirus: https://www.dvm360.com/view/therapy-and-vaccination-new-canine-parvovirus-proceedings
[5] Infectious diseases of the feline GI system: https://www.dvm360.com/view/infectious-diseases-feline-gi-system-proceedings

## 临床症状和体征

犬猫低钾血症产生一系列临床表现，其严重程度取决于钾耗竭的程度和持续时间。当血清钾浓度降至2.5-3.0 mEq/L以下时，肌肉无力通常变得明显 [1][2]。这种无力特征性地表现为上行性麻痹模式，后肢无力先于躯干和上肢受累出现 [3]。

在猫中，颈部腹屈（头部下垂）是严重低钾血症的特有体征，患病动物颈部肌肉无力，被触摸时感觉"松软" [2][4]。随着钾水平下降，犬和猫也可能表现出跳跃困难、间歇性跖行姿势或完全虚脱 [4]。

心脏表现包括心律失常，由低钾血症对自律性和心室复极的影响引起 [1][2]。虽然与人类患者相比，犬猫的心电图变化不一致，但可能观察到室性心律失常 [1][2]。默克兽医手册指出，当血清钾降至3.0 mEq/L以下时，心脏效应通常变得明显 [5]。

其他临床体征包括多尿和多饮，由尿浓缩能力受损引起，因为低钾血症导致继发性肾源性尿崩症 [1][2]。胃肠道体征可能包括由平滑肌功能障碍引起的麻痹性肠梗阻和便秘 [3][5]。

物种特异性模式包括幼年缅甸猫中记录的一种综合征，特征为反复发作的肢体肌肉无力、颈部腹屈和肌酸激酶浓度升高 [1][2]。这种情况证明了猫科患者对低钾性多肌病的品种易感性。

### Sources

[1] Disorders of potassium (Proceedings): https://www.dvm360.com/view/disorders-potassium-proceedings
[2] Management of hypokalemia and hyperkaemia (Proceedings): https://www.dvm360.com/view/management-hypokalemia-and-hyperkaemia-proceedings  
[3] Hypokalemia - StatPearls - NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/books/NBK482465/
[4] Help cats with hyperaldosteronism hold their heads high: https://www.dvm360.com/view/help-cats-with-hyperaldosteronism-hold-their-heads-high
[5] Hypokalemia - Endocrine and Metabolic Disorders - Merck Manual: https://www.merckmanuals.com/professional/endocrine-and-metabolic-disorders/electrolyte-disorders/hypokalemia

## 诊断方法

现有部分全面概述了低钾血症的诊断方法。为了通过额外的临床见解增强这一基础，几个关键的诊断考虑因素值得强调。

尽管犬猫的心电图变化不一致，心电图监测仍然必不可少 [1]。虽然心电图异常可能细微或不存在，但连续监测有助于检测随着钾水平进一步下降可能发生的潜在危及生命的心律失常 [2]。所描述的心电图变化--包括在较低钾浓度时高尖T波--代表需要立即干预的晚期阶段 [3]。

血气分析提供关键的补充诊断信息，特别是用于识别潜在病因 [5][6]。代谢性酸中毒模式可揭示肾小管酸中毒等疾病，而呼吸性代偿可能表明电解质紊乱的慢性程度 [7]。当与血清钾测量结合时，血气分析有助于区分原发性肾脏与胃肠道丢失，并指导适当的液体治疗选择 [8]。

即时检测分析仪通过实现快速、频繁的监测彻底改变了低钾血症的诊断，这对危重患者至关重要 [8]。这些设备允许实时评估治疗反应，并早期检测可能在实验室送检间隔期间未被注意到的危险钾波动。

### Sources
[1] Arrhythmias related to everyday emergencies: https://www.dvm360.com/view/arrhythmias-related-everyday-emergencies
[2] Collapsing dogs: managing common causes of collapse or syncope (Proceedings): https://www.dvm360.com/view/collapsing-dogs-managing-common-causes-collapse-or-syncope-proceedings
[3] Diagnosing and managing acute kidney injury (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-acute-kidney-injury-proceedings
[5] Arterial blood gas analysis and interpretation in anesthetized patients: https://www.dvm360.com/view/arterial-blood-gas-analysis-and-interpretation-anesthetized-patients
[6] A veterinary technicians guide to reading blood gasses: https://www.dvm360.com/view/veterinary-technician-s-guide-reading-blood-gasses
[7] Acid-base disorders and blood gas analysis (Proceedings): https://www.dvm360.com/view/acid-base-disorders-and-blood-gas-analysis-proceedings
[8] Using blood gases in practice (Proceedings): https://www.dvm360.com/view/using-blood-gases-practice-proceedings

## 治疗选择

犬猫低钾血症的治疗重点是通过静脉和口服补充方案纠正潜在的钾缺乏 [1]。主要治疗方法涉及氯化钾（KCl）给药，剂量根据血清钾浓度和临床症状严重程度确定。

**静脉钾补充**
对于静脉治疗，氯化钾是首选，因为通常需要同时补充氯化物 [1]。存在基于血清钾水平的标准化给药方案：钾<2.0 mEq/L的患者需要在每升维持液中加入80 mEq KCl，而2.1-2.5 mEq/L的患者需要每升60 mEq KCl [1][2]。最大安全输注速率为0.5 mEq/kg/小时，以防止心脏毒性作用 [1][6][8]。

**口服钾补充**
口服葡萄糖酸钾推荐用于维持治疗和较轻病例 [3]。对于患有低钾性肾病的猫，初始剂量范围为每天5-8 mEq，分两次或三次给药，维持剂量通常减少至每天2-4 mEq [1]。当患者能够耐受肠内给药时，首选这种口服途径 [3]。

**监测要求**
在钾补充期间密切监测至关重要，特别是在快速静脉输注时 [2]。血清钾浓度应每天监测一到两次，在积极治疗方案期间进行更频繁的评估 [6]。对于高浓度钾输注，推荐进行心电图监测，以检测过度纠正的早期迹象 [8]。

**难治性病例和镁考虑因素**
低镁血症可加重低钾血症并导致治疗抵抗 [4]。在难治性病例中，可能需要同时补充镁以达到充分的钾纠正 [4]。糖尿病酮症酸中毒需要特别仔细的监测，因为如果补充不足，胰岛素治疗可能引发严重低钾血症 [6]。

### Sources
[1] Guideline for Potassium Supplementation in Dogs and Cats: https://www.merckvetmanual.com/multimedia/table/guideline-for-potassium-supplementation-in-dogs-and-cats
[2] The Fluid Resuscitation Plan in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/therapeutics/fluid-therapy/the-fluid-resuscitation-plan-in-animals
[3] 2024 AAHA Fluid Therapy Guidelines for Dogs and Cats: https://meridian.allenpress.com/jaaha/article/60/4/131/501375/2024-AAHA-Fluid-Therapy-Guidelines-for-Dogs-and
[4] Disorders of Magnesium Metabolism in Cats: https://www.merckvetmanual.com/cat-owners/metabolic-disorders-of-cats/disorders-of-magnesium-metabolism-in-cats
[5] A veterinary technicians guide to reading blood gasses - dvm360: https://www.dvm360.com/view/veterinary-technician-s-guide-reading-blood-gasses
[6] Feline endocrine emergencies (Proceedings): https://www.dvm360.com/view/feline-endocrine-emergencies-proceedings
[7] Guidelines for daily fluid therapy planning: When the going gets tough (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-when-going-gets-tough-proceedings
[8] Guidelines for daily fluid therapy planning: The basics (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-basics-proceedings

## 预防措施

预防低钾血症需要一种综合方法，重点关注饮食管理、适当的液体治疗方案、监测高危患者和环境控制 [1]。

**饮食管理和补充**
慢性肾病患者的治疗性肾脏饮食含有增加的钾水平，以帮助预防低钾血症，这已被证明会导致肾功能不全 [3]。对于低钾血症的猫，如果单独饮食不能维持血清钾浓度高于4.0 mEq/L，应考虑口服葡萄糖酸钾补充 [3]。定期监测血清钾至关重要，初始检查每2至4天一次，直到稳定，之后每2至4周一次 [3]。

**液体治疗方案**
液体治疗期间适当的钾补充对预防至关重要 [1]。犬猫的维持液需求量通常为40-60 ml/kg/天，钾补充量约为1 mEq/kg/天 [1]。使用维持液时，钾应补充至20 mEq/L，而对于补充液，10 mEq/L通常足够 [5]。最大钾输注速率不应超过0.5 mEq/kg/小时，以防止医源性高钾血症 [5]。

**高危患者监测**
危重动物由于口服摄入减少以及胃肠道或尿路丢失增加，常发生低钾血症 [7]。患有糖尿病、慢性肾病或接受长期无钾溶液液体治疗的患者需要特别密切的监测 [2][6]。在患有慢性肾病的猫中，低钾血症可能表现为嗜睡或步态僵硬，而不是典型的颈部腹屈 [6]。

### Sources
[1] Fluid therapy 101 (Proceedings): https://www.dvm360.com/view/fluid-therapy-101-proceedings
[2] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings  
[3] Nutritional management of chronic kidney disease: https://www.dvm360.com/view/nutritional-management-chronic-kidney-disease
[4] Guidelines for daily fluid therapy planning: When the going gets tough (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-when-going-gets-tough-proceedings
[5] Guidelines for daily fluid therapy planning: The basics (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-basics-proceedings
[6] Chronic kidney disease in cats: Hypokalemia, signs, the exam, and staging: https://www.dvm360.com/view/chronic-kidney-disease-in-cats-hypokalemia-signs-the-exam-and-staging
[7] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20

## 鉴别诊断

低钾血症的临床表现与多种其他疾病重叠，需要系统鉴别。主要鉴别诊断包括其他引起相似无力模式的代谢性肌病和神经肌肉疾病 [1]。

**神经肌肉疾病**的症状重叠包括获得性重症肌无力，引起运动诱导的肌肉无力和疲劳。然而，重症肌无力通常对依酚氯铵试验有反应并显示特异性抗体模式 [2]。急性多发性神经根神经炎表现为进行性弛缓性麻痹，但通常影响神经传导而非肌肉膜功能 [2]。

**需要鉴别的代谢性疾病**包括阿狄森氏病（肾上腺皮质功能减退症），在犬中通常引起高钾血症而非低钾血症。其他电解质失衡如低钙血症或低镁血症可引起肌肉无力，但具有独特的血清生化特征 [1]。

**低钾血症的鉴别因素**包括猫血清钾水平低于3.5 mEq/L或牛低于2.5 mmol/L，肌酸激酶（CK）浓度升高，以及猫特有的颈部腹屈 [1]。与神经系统疾病不同，低钾血症保持正常的神经系统检查结果，精神状态和痛觉完整 [1]。

**系统诊断方法**包括测量血清电解质、CK水平以及进行全面的神经系统检查。对钾补充的反应既是诊断也是治疗确认 [1]。

### Sources
[1] Feline Hypokalemic Polymyopathy: https://www.merckvetmanual.com/musculoskeletal-system/myopathies-in-small-animals/feline-hypokalemic-polymyopathy
[2] Inflammatory Disorders of the Peripheral Nerves and Neuromuscular Junction in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/inflammatory-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals

## 预后

犬猫低钾血症的预后差异显著，取决于潜在病因、电解质失衡严重程度和治疗及时性。当低钾血症作为慢性肾病（CKD）的并发症发生时，预后与IRIS分期和整体疾病进展密切相关 [1][2]。

在患有CKD的猫中，中位生存时间与疾病分期相关：IIb期猫约存活763天，III期猫548天，IV期猫仅97天 [1][2]。贫血的存在（通常伴随严重低钾血症）与较短的生存时间相关，但通常与肌酐浓度升高相关 [1][2]。

对于猫低钾性多肌病 specifically，早期诊断和治疗的预后极佳 [3]。当通过适当的钾补充及时纠正低钾血症时，肌肉无力和心脏并发症的临床体征通常迅速缓解 [1][8]。长期和严重的低钾血症可导致难以治疗的肌病 [1][8]。

在猫高醛固酮血症等疾病中，单侧肾上腺肿瘤的手术干预提供了极好的结果，没有转移且存活至出院的猫具有长期生存时间 [6]。药物治疗通常需要终身治疗，长期生存时间不一 [6]。关键预后因素是潜在疾病的早期识别和治疗，因为如果不治疗，严重高钾血症可导致危及生命的心律失常 [10]。

### Sources

[1] Updates in outpatient management of chronic kidney disease: https://www.dvm360.com/view/updates-outpatient-management-chronic-kidney-disease-proceedings
[2] Updates in feline chronic kidney disease: https://www.dvm360.com/view/updates-feline-chronic-kidney-disease-proceedings
[3] Feline Hypokalemic Polymyopathy: https://www.merckvetmanual.com/musculoskeletal-system/myopathies-in-small-animals/feline-hypokalemic-polymyopathy
[4] Management of hypokalemia and hyperkaemia: https://www.dvm360.com/view/management-hypokalemia-and-hyperkaemia-proceedings
[5] Overview of Disorders of Potassium Metabolism in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals
[6] Feline Primary Hyperaldosteronism: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/feline-primary-hyperaldosteronism
[7] Chronic kidney disease in cats: https://www.dvm360.com/view/chronic-kidney-disease-in-cats-hypokalemia-signs-the-exam-and-staging
[8] Overview of Disorders of Potassium Metabolism in Animals (AU): https://www.merckvetmanual.com/en-au/metabolic-disorders/disorders-of-potassium-metabolism/overview-of-disorders-of-potassium-metabolism-in-animals
[9] Guideline for Potassium Supplementation: https://www.merckvetmanual.com/multimedia/table/guideline-for-potassium-supplementation-in-dogs-and-cats
[10] Disorders of Potassium Metabolism in Cats: https://www.merckvetmanual.com/cat-owners/metabolic-disorders-of-cats/disorders-of-potassium-metabolism-in-cats
