# 伴侣动物中的肥厚型心肌病

肥厚型心肌病是影响猫的最常见心脏病，据估计全球约有七分之一的猫患病。这种原发性心肌疾病的特点是左心室壁进行性增厚，可导致危及生命的并发症，包括充血性心力衰竭、动脉血栓栓塞和猝死。虽然许多受影响的猫一生中保持无症状，但那些发展为严重疾病的猫面临显著的发病率和死亡率挑战。

这份全面的兽医报告探讨了猫HCM的多方面性质，从其在缅因猫和布偶猫等品种中的遗传基础到新兴的治疗干预。分析涵盖了诊断复杂性，传统听诊可能会漏诊三分之一的病例；治疗范式从症状管理转向使用雷帕霉素治疗的疾病修饰；以及基于疾病阶段和并发症而显著不同的预后考虑因素。

## 预后

患有肥厚型心肌病的猫的临床前景因疾病严重程度和并发症而差异巨大。患有轻度疾病的无症状猫通常能维持良好的生活质量多年，而发展为充血性心力衰竭的猫则面临仅3个月的中位生存时间。左心房扩大的程度是最关键的预后指标，严重扩大预示着更高的血栓栓塞和猝死风险。

最近的治疗进展为疾病修饰带来了前所未有的希望。FDA在2025年对雷帕霉素的有条件批准标志着从防御性症状管理到进攻性疾病预防的范式转变，临床试验证明在亚临床病例中实际逆转了左心室肥厚。

| 疾病阶段 | 预后 | 关键干预措施 |
|---------------|-----------|------------------|
| 无症状/轻度 | 良好，可正常生活多年 | 监测、基因筛查 |
| 伴有左心房扩大的中度 | 谨慎，抗凝治疗至关重要 | 氯吡格雷、雷帕霉素治疗 |
| 心力衰竭 | 不良，3个月中位生存时间 | 呋塞米、姑息治疗 |

通过心脏生物标志物和超声心动图进行早期检测，并在合适的候选者中结合积极的雷帕霉素治疗，代表了预防猫HCM进展的未来护理标准。

## 疾病概述

肥厚型心肌病（HCM）是一种原发性心肌疾病，特征为涉及心室壁和乳头肌的向心性左心室肥厚[1]。该疾病涉及左心室壁从正常尺寸3-5mm增厚至严重病例中的7-10mm，乳头肌增大是猫的一个一致特征[1]。

HCM是猫最常见的心脏病，影响多达七分之一的猫，尽管绝大多数病例保持亚临床状态[1]。该疾病主要发生在家猫中，很少影响小型犬[1]。年龄分布从6个月到17岁不等，大多数猫在就诊时为中年，尽管该疾病并非出生时就存在，而是随时间发展[1]。

雄性和雌性对HCM的易感性相同，但雄性往往在更早年龄发展出更严重的疾病[1]。品种易感性已有充分记录，HCM在缅因猫和布偶猫中呈家族性，这些品种已鉴定出特定的基因突变[1]。其他常见受影响的品种包括波斯猫、美国短毛猫和英国短毛猫、挪威森林猫、斯芬克斯猫和土耳其梵猫[1][2]。

病理生理学涉及缺陷的心肌细胞导致肌细胞排列紊乱而非有序模式，导致舒张功能障碍和心室充盈受损[2]。

### Sources

[1] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

[2] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies

## 病因学和发病机制

猫的肥厚型心肌病特征为由于内在心肌疾病、激素刺激、心肌浸润或其他非心脏疾病引起的原发性向心性左心室肥厚[1]。该疾病主要影响猫，乳头肌增大是一个一致特征。

**遗传原因：** 在人类中，HCM由肌节基因突变引起。在猫中，已在特定品种中鉴定出心脏肌球蛋白结合蛋白C基因的突变[1]。缅因猫具有A31P突变，将密码子31中的丙氨酸变为脯氨酸，存在于全球约34%的缅因猫中[2][3]。布偶猫携带同一基因的不同突变（C820T或R820W）[2][3]。A31P突变纯合的缅因猫主要发展为临床重要的HCM[1]。

**继发原因：** HCM可由甲状腺功能亢进、肢端肥大症或全身性高血压引起[1][4]。这些情况通过激素刺激或增加心脏后负荷导致心肌肥厚。

**病理变化：** 该疾病涉及心肌细胞的缺陷，导致肌细胞排列紊乱而非有序模式[4]。严重肥厚伴有细胞坏死和随之而来的替代性纤维化（心肌瘢痕）[1]。关键的组织学发现包括伴有纤维排列紊乱和间质纤维化的心肌细胞肥大[6]。

**疾病进展：** HCM导致心室僵硬，阻止舒张期松弛并损害心室充盈[4]。一些猫进展为限制性心肌病或伴有广泛心肌纤维化的"耗竭型"HCM[6]。

### Sources
[1] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Etiology of Feline hypertrophic cardiomyopathy just b. cause (Proceedings): https://www.dvm360.com/view/etiology-feline-hypertrophic-cardiomyopathy-just-b-cause-proceedings
[3] Common inherited diseases of cats (Proceedings): https://www.dvm360.com/view/common-inherited-diseases-cats-proceedings
[4] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[5] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies/1000
[6] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

## 临床表现和诊断

猫肥厚型心肌病的临床表现差异巨大，从无症状到危及生命的表现。许多患有HCM的猫，特别是那些患有轻度至中度疾病的猫，没有表现出临床症状[1]。然而，患有严重疾病的猫可能发展为左心衰竭、全身性血栓栓塞或猝死[1]。

体格检查结果可能微妙但重要。至少三分之一的HCM猫没有心脏杂音，使得听诊作为筛查方法不可靠[1]。当存在时，猫可能有轻微至明显的收缩期心脏杂音和/或奔马律，特别是在严重病例中[1]。在猫患者中，奔马律比杂音更能表明潜在的心肌疾病[3]。

全面的诊断评估需要多种方式。超声心动图仍然是金标准，诊断需要舒张期左心室壁厚度≥6 mm[1][4]。诊断需要评估多个超声心动图视图以识别区域性肥厚模式和乳头肌增大[2]。二尖瓣收缩期前向运动可能造成动态流出道梗阻[1]。

心脏生物标志物提供有价值的筛查工具。NT-proBNP浓度在患有严重疾病的猫中经常升高，特别是那些处于心力衰竭中的猫[1]。定性SNAP检测提供诊所内筛查能力，尽管敏感性低于定量检测[3]。这种生物标志物有助于区分心脏和呼吸原因引起的呼吸困难。

放射学评估可能显示明显的左心房扩大，但如果不存在心房扩大，可能看起来相对正常[1]。心电图异常可能包括各种心律失常，尽管发现通常是非特异性的[1][4]。

### Sources
[1] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Hypertrophic cardiomyopathy--getting into the thick of it: https://www.dvm360.com/view/hypertrophic-cardiomyopathy-getting-thick-it-proceedings
[3] Diagnosing feline myocardial disease: https://www.dvm360.com/view/diagnosing-feline-myocardial-disease
[4] Feline hypertrophic cardiomyopathy, hypertension, and hyperthyroidism: https://www.dvm360.com/view/feline-hypertrophic-cardiomyopathy-hypertension-and-hyperthyroidism-proceedings

## 治疗和管理

猫肥厚型心肌病的医学管理是复杂的，并且主要是症状性的，侧重于管理并发症而非预防疾病进展[1]。β-受体阻滞剂如阿替洛尔（1-2.5 mg/kg 口服 每12小时一次）通常用于降低心率、改善舒张充盈时间和减少二尖瓣收缩期前向运动[1,2]。钙通道阻滞剂如地尔硫卓（1.5-3 mg/kg 口服 每8-12小时一次）可以改善舒张松弛并减少左心室肥厚，尽管临床证据仍然有限[1,2]。

匹莫苯丹（0.25 mg/kg 口服 每12小时一次）可能对患有心力衰竭的猫有益，但在具有显著动态流出道梗阻的猫中禁用[1]。ACE抑制剂在无症状猫中证明益处最小，但一旦发展为心力衰竭可能作为辅助用药有用[1,7]。

对于急性心力衰竭，呋塞米（1-2 mg/kg 静脉/肌肉注射 起初每1-4小时一次，根据呼吸改善情况逐渐减量）仍然是最关键的治疗[1,7]。氧气支持和减压是必要的紧急干预措施。

使用氯吡格雷（18.75 mg/猫 口服 每24小时一次）进行抗凝治疗推荐用于中度至重度左心房扩大、自发性对比显影或既往有血栓栓塞史的猫[1,7,8]。低分子量肝素可在高风险病例中考虑[8]。

长期监测包括无症状猫每6-12个月进行一次定期超声心动图检查，以及具有显著左心房扩大的猫每3-6个月进行一次胸部X光检查[7]。治疗决策应根据疾病严重程度、左心房大小和并发症的存在进行个体化。

### Sources
[1] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[2] Anesthetic management of small animals with preexisting cardiac conditions (Proceedings): https://www.dvm360.com/view/anesthetic-management-small-animals-with-preexisting-cardiac-conditions-proceedings
[3] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[4] Blood pressure: A critical factor (Proceedings): https://www.dvm360.com/view/blood-pressure-critical-factor-proceedings-0
[5] Delayed-release rapamycin halts progression of left ventricular hypertrophy in subclinical feline hypertrophic cardiomyopathy: results of the RAPACAT trial: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.04.0187.xml
[6] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[7] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[8] Current strategies on diagnosis and treatment of feline cardiomyopathy (Proceedings): https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings

## 并发症和预后

猫的肥厚型心肌病可能导致几种危及生命的并发症。最常见的重大并发症包括充血性心力衰竭（CHF）、动脉血栓栓塞（ATE）和猝死[1]。猫可能发展为更严重的疾病导致CHF或猝死，约一半经历CHF的猫有某种诱发事件，如牙科或应激性操作[1]。

动脉血栓栓塞代表一种特别严重的并发症，患有HCM和ATE的猫的平均生存时间范围为61至184天[1]。猝死可发生在患有HCM的猫中，通常没有先前可归因于心脏病的临床症状[2]。原因未知，但可能是由于致命性心律失常、大血栓形成或流出道梗阻急性恶化[2]。临床试验数据显示，即使在药物开发研究期间，大约10%的病例可能发生包括CHF进展和猝死在内的严重不良事件[3]。

预后因疾病阶段和并发症而有显著差异。患有无症状和轻度疾病的猫预后良好，可能多年没有问题[1][4]。然而，一旦猫发展为CHF和动脉血栓栓塞，预后会急剧恶化[1]。患有CHF的猫的生存时间范围为92至654天，中位生存时间为3个月[1][4]。许多轻度受影响的猫具有良好的长期前景，但一旦发展为CHF，预后就变差[4]。左心房扩大的程度作为确定疾病严重程度和结果的重要预后指标[1]。

### Sources
[1] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies/1000
[2] Hypertrophic cardiomyopathy--getting into the thick of it (Proceedings): https://www.dvm360.com/view/hypertrophic-cardiomyopathy-getting-thick-it-proceedings
[3] Delayed-release rapamycin halts progression of left ventricular hypertrophy in subclinical feline hypertrophic cardiomyopathy: results of the RAPACAT trial: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.04.0187.xml
[4] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

## 预防和未来方向

基因筛查对风险品种变得越来越重要，包括缅因猫、波斯猫、布偶猫、英国短毛猫和斯芬克斯猫[1][2]。目前一些基因检测可用，特别是肌球蛋白结合蛋白C的突变，尽管这仍然主要对繁育计划有价值而非临床诊断[1][3]。负责任的繁育实践应在易感品种中纳入心脏筛查以减少疾病传播[3]。

HCM预防和管理的最重大进展是雷帕霉素（西罗莫司），它代表了从症状管理到疾病修饰的范式转变[2]。这种mTOR通路抑制剂已证明在亚临床猫中能够阻止或逆转左心室肥厚[2][4]。在标志性的RAPACAT试验中，每周一次给药的缓释制剂在180天后与安慰剂相比显著降低了最大壁厚[2]。

雷帕霉素治疗现在通过远程医疗协议在美国20个州可用，使面临专科护理地理障碍的猫主人能够获得治疗[3]。该药物在2025年获得FDA有条件批准，标志着首个专门针对猫HCM的治疗药物[4]。当前研究包括已招募210只猫的HALT研究，旨在确认长期临床益处并支持完全FDA批准[4]。

这代表了对抗HCM从防御性策略到进攻性策略的根本转变，提供真正的疾病修饰，而不仅仅是在症状出现时进行管理[4]。

### Sources

[1] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings

[2] Etiology of Feline hypertrophic cardiomyopathy just b. cause (Proceedings): https://www.dvm360.com/view/etiology-feline-hypertrophic-cardiomyopathy-just-b-cause-proceedings

[3] Common inherited diseases of cats (Proceedings): https://www.dvm360.com/view/common-inherited-diseases-cats-proceedings

[4] Novel cardiology therapy for cats is launched: https://www.dvm360.com/view/novel-cardiology-therapy-for-cats-is-launched
