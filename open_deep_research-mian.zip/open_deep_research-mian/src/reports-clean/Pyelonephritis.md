# 伴侣动物肾盂肾炎

肾盂肾炎是一种严重的上尿路感染，影响犬和猫的肾脏和输尿管，主要由细菌从下尿路上行定植引起。虽然尿路感染大约影响14%的犬在其一生中的某个时期，但肾盂肾炎是复杂感染的一个子集，需要延长治疗方案和谨慎管理。

本报告探讨了肾盂肾炎在小动物临床中的临床意义，涵盖了大肠杆菌作为主要致病菌的细菌病原学，从隐匿性慢性病例到急性全身性疾病的多样化临床表现，需要基于培养确认的诊断挑战，根据血浆而非尿药浓度折点指导的抗菌治疗，以及专注于风险因素管理和解剖学矫正以预防复发的预防策略。

## 摘要

伴侣动物肾盂肾炎在兽医临床中呈现重大的诊断和治疗挑战。大肠杆菌作为致病菌占主导地位，其不断增加的抗菌药物耐药模式需要基于培养的治疗而非经验性治疗。临床表现差异很大，从无症状的慢性病例到伴有肾损伤的急性全身性疾病，使得没有适当的实验室确认时诊断特别具有挑战性。

关键诊断发现包括通过膀胱穿刺培养确认的菌尿症，60%病例的超声检查显示肾盂扩张，以及指示肾脏炎症的白细胞管型。治疗需要使用血浆最低抑菌浓度折点来选择抗菌药物，当临床指征明确时，氟喹诺酮类或第三代头孢菌素是经验性治疗的优选药物。

| 方面 | 犬 | 猫 |
|--------|------|------|
| **患病率** | 更常见，14%一生中尿路感染风险 | 比犬少见 |
| **主要病原体** | 大肠杆菌，其次是变形杆菌/葡萄球菌 | 大肠杆菌，其次是葡萄球菌/肠球菌 |
| **临床症状** | 多变的全身症状，肾脏疼痛 | 适当治疗时预后更好 |
| **治疗持续时间** | 当前建议10-14天 | 当前建议10-14天 |

预防侧重于管理易感因素，如针对复发性感染的阴门成形术等解剖学矫正，以及审慎的抗菌药物管理以防止耐药性发展。未来的兽医实践应强调基于培养的诊断和更短、基于证据的治疗方案，以优化患者预后同时保持抗菌药物疗效。

## 疾病概述

肾盂肾炎被定义为涉及肾脏和输尿管的上尿路感染，代表一种影响肾实质和集合系统的严重细菌感染[1]。这种情况发生在细菌从下尿路通过输尿管上行定植于肾脏时，引起肾盂和肾组织的炎症[2]。具体而言，肾盂肾炎是指间质性炎症，通常在肾盂和邻近髓质组织最为严重，与肾脏的细菌感染相关[5]。

尿路感染是犬最常见的传染病，大约影响14%的犬在其一生中的某个时期[1]。然而，猫的细菌性尿路感染比犬少见，并且上行性感染和梗阻性肾病在猫肾盂肾炎发病机制中的重要性尚不清楚[5]。虽然针对伴侣动物肾盂肾炎患病率的全面流行病学数据有限，但这种情况代表需要延长治疗方案的复杂尿路感染的一个子集[3]。

犬和猫的大多数获得性慢性肾病发生在中老年患者中[7]。犬或猫的非遗传性慢性肾病没有明显的品种或性别倾向[6]。肾盂肾炎可作为复杂尿路感染病例的一部分发生，这些感染与宿主防御机制缺陷相关，包括解剖异常、免疫妥协或并发全身性疾病[4]。

### Sources
[1] Managing difficult urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-difficult-urinary-tract-infections-proceedings
[2] Managing routine and difficult urinary tract infections in dogs (Proceedings): https://www.dvm360.com/view/managing-routine-and-difficult-urinary-tract-infections-dogs-proceedings
[3] Hot Literature: Antibiotic guidelines for dogs and cats with urinary tract disease: https://www.dvm360.com/view/hot-literature-antibiotic-guidelines-dogs-and-cats-with-urinary-tract-disease
[4] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings
[5] Diseases of the feline kidney (Proceedings): https://www.dvm360.com/view/diseases-feline-kidney-proceedings
[6] Renal Dysfunction in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[7] Early detection of chronic kidney disease (Proceedings): https://www.dvm360.com/view/early-detection-chronic-kidney-disease-proceedings

## 常见病原体

大肠杆菌是引起犬和猫肾盂肾炎的主要细菌病原体[2]。这种革兰氏阴性生物始终是犬和猫尿路感染中最常见的培养物种，在欧洲研究中占所有细菌分离株的一半以上[1]。

其他重要细菌病原体包括犬的变形杆菌和葡萄球菌属，而猫则显示更高频率的葡萄球菌和肠球菌属[1]。其他尿路致病体包括克雷伯氏菌、链球菌、假单胞菌和肠杆菌属[6]。最近的研究表明，25%的培养阳性标本可能含有多种细菌物种[6]。

抗菌药物耐药模式呈现重大的治疗挑战。大肠杆菌分离株经常显示对阿莫西林-克拉维酸的耐药性，但通常对氟喹诺酮类和第三代头孢菌素保持敏感[3]。欧洲监测数据显示耐药性的地理差异，南部国家相比北部地区显示出更高的总体耐药率[1]。这种模式可能反映了抗菌药物处方法规和监测实践的差异。

多重耐药生物的出现越来越被记录，特别影响复杂感染的治疗选择[5]。这些耐药模式需要基于培养的抗菌药物选择而非经验性治疗，特别是在复发性或持续性病例中。

### Sources
[1] Geographic Patterns of Antimicrobial Resistance in Companion Animal Urinary Tract Infections in Europe: https://www.dvm360.com/view/geographic-patterns-of-antimicrobial-resistance-in-companion-animal-urinary-tract-infections-in-europe
[2] Pyelonephritis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[3] Acute pyelonephritis in cats is frequently caused by Escherichia coli resistant to potentiated penicillins: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml
[5] Hot Literature: Antibiotic guidelines for dogs and cats with urinary tract disease: https://www.dvm360.com/view/hot-literature-antibiotic-guidelines-dogs-and-cats-with-urinary-tract-disease
[6] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings

## 临床症状和体征

犬肾盂肾炎呈现可变的临床表现，可分为全身性和尿路症状[2]。肾盂肾炎的临床症状包括嗜睡、食欲不振、呕吐和腹泻，这些与急性肾损伤引起的全身性疾病相关[2]。发热和腹痛可能发生，但在犬和猫中都不常见[2]。

患有肾盂肾炎的犬通常表现出侧部疼痛的迹象，特别是肾脏周围，发热和全身不适[5]。其他全身症状包括呕吐、食欲减退、过度口渴和过度排尿[5]。肾脏可能突然开始衰竭，患有长期肾盂肾炎的犬可能除过度口渴和排尿外显示很少或没有症状[5]。

犬的尿路症状可能包括频繁排尿、疼痛或排尿困难、尿中带血和在不适当的地方排尿[5]。然而，下尿路症状在肾盂肾炎患者中不太一致[1]。有些犬根本没有尿路症状，使诊断变得具有挑战性[5]。

伴有左移的中性粒细胞增多可为肾盂肾炎提供支持性证据，但并不一致发生[2]。临床表现在急性和慢性形式之间可能有所不同，慢性病例由于症状隐匿或缺失而特别难以识别[5]。

### Sources
[1] Acute pyelonephritis in cats is frequently caused by Escherichia coli resistant to potentiated penicillins but has a better prognosis than other causes of acute kidney injury: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml
[2] Pyelonephritis in Small Animals - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[3] Infectious Diseases of the Urinary System in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/kidney-and-urinary-tract-disorders-of-dogs/infectious-diseases-of-the-urinary-system-in-dogs

## 诊断方法

肾盂肾炎的推定诊断是通过结合临床表现评估与实验室检测和影像学检查做出的[1]。诊断需要通过膀胱穿刺采集的尿液培养阳性确认菌尿症[1]。单独的临床症状是不够的，因为许多患有肾盂肾炎的犬和猫是无症状的或仅显示下尿路感染的症状[7]。

实验室评估包括全血细胞计数、血清生化分析和尿液分析[7]。慢性肾盂肾炎的CBC可能正常，但一些患者可能检测到白细胞增多和伴有左移的中性粒细胞增多[7]。伴有左移的中性粒细胞增多可以是支持性证据，但并不一致发生[1]。

尿液分析显示84%的病例有显微镜下菌尿症，56%的病例有脓尿[3]。其他发现可能包括血尿、蛋白尿和白细胞管型[7]。白细胞管型对肾脏炎症具有诊断意义，通常由肾盂肾炎引起[7]。尿液培养和药敏测试是必要的，因为对于肾盂肾炎病例，应应用血浆最低抑菌浓度折点而非尿液折点[1]。

影像学方法包括超声检查和排泄性尿路造影作为首选方法[7]。支持肾盂肾炎的超声检查发现包括60%病例的肾盂扩张（肾盂扩张），45%病例的输尿管扩张，以及肾盂内高回声黏膜边缘[6,7]。排泄性尿路造影可能显示肾盂扩张和钝化，集合憩室缺乏充盈[7]。

### Sources
[1] Pyelonephritis in Small Animals - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[2] Journal of the American Veterinary Medical Association Acute pyelonephritis in cats is frequently caused by Escherichia coli resistant to potentiated penicillins but has a better prognosis than other causes of acute kidney injury: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml
[3] Diagnostic testing offers early detection of renal disease: https://www.dvm360.com/view/diagnostic-testing-offers-early-detection-renal-disease
[4] Clinical diagnosis of pyelonephritis often presumptive: https://www.dvm360.com/view/clinical-diagnosis-pyelonephritis-often-presumptive

## 治疗选择

肾盂肾炎的抗菌药物治疗应由尿液培养和药敏结果指导，而非经验性选择[1]。肾盂肾炎作为急性肾损伤原因的总体患病率相对较低；因此，经验性抗菌药物应仅在具有高度临床怀疑的病例中开始，例如当尿液沉渣检查中发现菌尿症时[1]。

由于肾盂肾炎是一种组织感染，在提交样本时必须告知微生物学实验室这一关注点，确保使用血浆最低抑菌浓度折点而非尿液折点[1]。这种区别对于青霉素类尤为重要，因为最常见的致病生物大肠杆菌根据血浆折点通常对青霉素类耐药[1]。

对于经验性治疗，在大多数地区，氟喹诺酮类或第三代头孢菌素是合理的选择[1]。虽然普拉多沙星为猫提供了方便的口服给药，但它应在第二代氟喹诺酮类不适合时保留使用[1]。兽医应注意氟喹诺酮类在猫中的视网膜病变不良反应，特别是恩诺沙星[1]。

当前治疗持续时间建议为10-14天，这是从人类医学证据推断的，因为兽医特定数据仍然有限[1]。历史上，推荐4-8周的疗程[6]。临床医生应在抗菌药物停用后1-2周内重新检查患者，以评估持续的肾损伤[1]。

包括液体治疗和管理易感因素在内的支持性护理是治疗的重要组成部分[7]。患者需要根据疾病严重程度进行不同级别支持性护理的住院治疗[7]。

### Sources

[1] Pyelonephritis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[6] Diseases of the feline kidney (Proceedings): https://www.dvm360.com/view/diseases-feline-kidney-proceedings
[7] How to manage recurrent urinary tract infections: https://www.dvm360.com/view/how-to-manage-recurrent-urinary-tract-infections

## 预防措施和鉴别诊断

肾盂肾炎复发的预防依赖于全面的风险因素管理和抗菌药物管理[1][2]。先前的氟喹诺酮类使用和延长住院时间显著增加犬的细菌耐药风险，而三个月内接受多种抗生素暴露的猫面临更高的耐药威胁[1]。对于患有复发性革兰氏阳性尿路感染的犬，睡前使用阿莫西林进行预防性抗菌治疗可防止再感染[7]。然而，每隔几周的脉冲抗生素治疗无效并促进耐药性发展[4]。

解剖学矫正对预防复发至关重要[4]。阴门成形术有效解决母犬继发于外阴皮炎的再感染[4]。感染性尿石的手术切除通常是解决复发性尿路感染所必需的[4]。对于复发性革兰氏阴性感染，可考虑使用第一代头孢菌素或呋喃妥因进行预防性治疗[4]。

鉴别诊断包括几种症状重叠的疾病。非感染原因引起的急性肾损伤呈现类似的氮质血症但缺乏阳性尿液培养结果[2]。下尿路感染表现为类似的排尿困难但没有全身性疾病或严重氮质血症[2]。输尿管梗阻引起急性氮质血症伴有肾盂扩张，但通常最初尿液培养为阴性。

关键区分因素包括尿液沉渣检查中的菌尿症、阳性培养结果以及肾盂肾炎中的并发全身症状[2]。猫急性肾盂肾炎在适当治疗时通常比其他急性肾损伤原因显示出更好的预后[1]。

### Sources

[1] Acute pyelonephritis in cats is frequently caused by: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml
[2] Pyelonephritis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[3] Alternative therapeutic options for management of chronic: https://www.dvm360.com/view/alternative-therapeutic-options-management-chronic-or-recurring-urinary-tract-disease-dog-and-cat-pr
[4] Diagnosing and managing recurrent urinary tract infections: https://www.dvm360.com/view/diagnosing-and-managing-recurrent-urinary-tract-infections-proceedings
[5] Resistant urinary tract infections (Proceedings): https://www.dvm360.com/view/resistant-urinary-tract-infections-proceedings
[6] Managing difficult urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-difficult-urinary-tract-infections-proceedings
[7] Hot Literature: Antibiotic guidelines for dogs and cats with: https://www.dvm360.com/view/hot-literature-antibiotic-guidelines-dogs-and-cats-with-urinary-tract-disease
