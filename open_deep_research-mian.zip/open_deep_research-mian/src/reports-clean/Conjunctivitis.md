# 伴侣动物结膜炎

结膜炎是兽医临床中最常见的眼部疾病之一，影响犬和猫，并具有明显的物种特异性特征。这种结膜炎症性疾病因其多样的病因和潜在的慢性化而构成重要的临床挑战。考虑到全球近95%的猫曾暴露于主要病原体猫疱疹病毒1型，其中40%在其一生中会经历复发性感染，理解其病理生理学、诊断方法和治疗策略变得至关重要。本报告探讨了结膜炎的综合管理，涵盖病毒性和细菌性病原体、从急性分泌物到慢性角膜并发症的临床表现、包括PCR和细胞学在内的先进诊断方法、循证治疗方案以及在伴侣动物实践中成功长期管理所必需的预防策略。

## 疾病概述

结膜炎被定义为结膜的炎症，结膜是一层薄薄的粘膜，衬在眼睑内侧并覆盖巩膜前表面[1]。结膜由两个解剖区域组成：睑结膜（衬在眼睑内）和球结膜（覆盖眼球表面），两者都含有在炎症期间会充血和血管增多的血管[2]。

结膜炎是伴侣动物中最常见的眼部疾病之一，特别是在猫中[1]。流行病学数据显示，结膜炎是犬和猫中最常见的角膜疾病，尽管两者之间的潜在病理生理学存在显著差异[3]。在猫中，几乎所有病例都是由原发性病原体感染引起的，而犬则更常因其他潜在疾病发展为继发性结膜炎[2]。

具体到猫，研究表明全球95%的猫曾暴露于猫疱疹病毒1型（FHV-1），这是主要的致病因子，至少80%是潜伏携带者[1]。此外，大约40%的潜伏感染猫将在其一生中经历复发性感染[4]。结膜具有多种保护功能，包括通过杯状细胞产生泪膜、通过淋巴组织防御病原体，以及对角膜的机械保护[5]。当发炎时，这些保护机制受损，导致特征性临床症状，包括充血、水肿和眼部分泌物。

### Sources

[1] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[2] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[3] A refresher on the cornea: https://www.dvm360.com/view/a-refresher-on-the-cornea
[4] Feline corneal diseases: herpesvirus and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[5] Getting ready for the eye patient (Proceedings): https://www.dvm360.com/view/getting-ready-eye-patient-proceedings

## 常见病原体

猫和犬结膜炎涉及多种病毒、细菌和其他传染性病原体。**病毒病原体**是主要原因，其中猫疱疹病毒1型（FHV-1）最为重要[1]。FHV-1在几乎所有康复的猫中建立终身潜伏感染，应激诱导的病毒再激活导致复发性结膜炎[6]。猫杯状病毒（FCV）也常引起结膜炎，受感染的猫成为持续排毒者[6]。在犬中，犬疱疹病毒1型（CHV-1）可引起结膜炎，特别是在新生犬中。

**细菌原因**通常是病毒感染的继发。猫衣原体是引起慢性结膜炎的重要原发性细菌病原体，特别是在猫中[1,7,8]。支原体属越来越被认为是猫和犬的重要呼吸道病原体，常引起结膜炎并伴有呼吸道症状[6,7,10]。继发性细菌感染通常涉及正常呼吸道菌群，包括葡萄球菌、链球菌、巴氏杆菌和大肠杆菌[9]。

**其他传染性病原体**包括支气管败血波氏杆菌，可作为呼吸道疾病复合体的一部分引起结膜炎[7,9]。真菌病原体如隐球菌和曲霉菌偶尔在全身感染中引起结膜受累[7,10]。寄生虫原因罕见，但可能包括犬的鼻螨[7]。

### Sources

[1] Prevalence of feline herpesvirus 1, Chlamydophila felis, and Mycoplasma spp: https://avmajournals.avma.org/view/journals/ajvr/68/6/ajvr.68.6.643.xml
[2] Feline viral upper respiratory infection: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[3] Nasal disorders in the dog and cat: https://www.dvm360.com/view/nasal-disorders-dog-and-cat-proceedings
[4] Best practices for antibiotic use in feline upper respiratory tract disease: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease
[5] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-animal-shelters
[6] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings

## 临床症状和体征

伴侣动物结膜炎表现出特征性的临床表现，在犬和猫患者之间存在差异。在犬中，典型体征包括粘液性或粘液脓性分泌物、结膜充血、眼睑痉挛和继发于泪液减少的角膜变化[1]。犬干性角膜结膜炎（KCS）最一致的临床体征是粘液性分泌物，常以绳索状附着在角膜上[1]。

猫结膜炎表现出明显的物种特异性模式。感染猫疱疹病毒1型（FHV-1）的猫在原发性感染期间通常表现为双侧结膜炎、呼吸道疾病和发热[2]。大多数猫在没有特定抗病毒治疗的情况下在7-10天内从原发性感染中恢复，尽管新生猫更容易发生严重的角膜和结膜瘢痕形成[2]。

**物种特异性差异**在犬和猫之间值得注意。在猫中，与其他病原体相比，FHV-1引起更严重的结膜充血和眼部分泌物[3]。复发性FHV-1感染在成年猫中通常表现为单侧结膜炎或溃疡性角膜炎，没有呼吸道症状[2]。猫衣原体感染产生更明显的水肿（"肿胀"），而FHV-1主要表现为充血模式[4]。

**品种易感性**在患有KCS的犬中特别存在，其中可卡犬、斗牛犬和短头颅品种表现出更高的易感性[1]。在猫中，波斯猫、喜马拉雅猫和暹罗猫表现出角膜腐肉形成的易感性[2]。

非典型表现包括猫的嗜酸性角膜炎，其特征是角膜上出现粉白色炎性斑块，通常影响年轻至中年的绝育雄性[2]。慢性病例可能发展为角膜血管化和色素沉着，如果不治疗可能导致视力受损[1]。

### Sources
[1] Diagnosis and treatment of dry eye in dogs: https://www.dvm360.com/view/diagnosis-and-treatment-of-dry-eye-in-dogs
[2] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[3] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[4] Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases

## 诊断方法

对犬和猫结膜炎的全面诊断评估需要系统的临床检查结合适当的实验室检测。完整的眼科检查应包括荧光素染色以识别角膜溃疡、评估结膜分泌物特征以及评估潜在原因[7]。

**先进成像技术**

使用10-20 MHz探头的超声检查可以在不透明妨碍观察时检查眼内内容物，并可指导眼内内容物的细针穿刺[9]。标准超声检查可以在较大的鸟类中检测视网膜脱离，并评估周围眶结构是否有眶后脓肿或肿瘤[6]。计算机断层扫描和磁共振成像提供有关眼部及其周围结构的额外诊断信息[6]。

**设备和准备**

基本诊断设备包括明亮光源、Schirmer泪液试纸、荧光素染色剂、丙对卡因、眼压计设备（Tono-Pen/Tono-Vet/Schiotz）、头戴式放大镜和直接检眼镜[9]。检查应在安静、昏暗的房间中以系统方法进行，对患者进行最小限度的约束[8]。

**细胞学和样本采集**

使用阴道细胞刷或手术刀背面的结膜细胞学提供快速诊断信息[10]。样本应从深层溶解性溃疡、化脓性病变或对治疗无反应的慢性病例中采集[9]。正常结膜显示单层单形上皮细胞，存在一些淋巴细胞[10]。然而，培养通常是不必要的，因为健康的结膜即使在临床上正常时也经常生长微生物[10]。

### Sources
[6] Avian ophthalmology (Proceedings): https://www.dvm360.com/view/avian-ophthalmology-proceedings
[7] The eyes have it: Conjunctivitis as a window to the body: https://www.dvm360.com/view/eyes-have-it-conjunctivitis-window-body
[8] Physical Examination of the Eye in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals
[9] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings
[10] The angry 'conj': How to calm down those red eyes: https://www.dvm360.com/view/angry-conj-how-calm-down-those-red-eyes

## 治疗选择

现有内容提供了全面的治疗方法，但几种额外的治疗方式值得纳入。对于由解剖学异常或严重继发性条件引起的结膜炎，可能需要手术干预。睑内翻修复需要手术矫正以消除引起慢性结膜炎的根本刺激[1]。猫的樱桃眼虽然不如犬常见，但需要手术复位脱出的第三眼睑腺，以防止慢性干眼并发症[5]。

支持性手术程序包括结膜或第三眼睑瓣和睑缝合术，用于严重的角膜并发症[8]。这些保护措施保护受损的角膜组织免受进一步创伤，同时促进愈合。临时眼罩通过减少光线暴露和苍蝇刺激，同时防止细菌传播，提供类似的好处[8]。

对于衣原体结膜炎，系统性多西环素（每日10 mg/kg）仍然是猫的标准治疗，至少持续4周[6]。所有家庭猫都需要同时治疗，无论临床症状如何[6]。在牲畜中，土霉素和土拉霉素对衣原体感染显示出疗效[8]。

疼痛管理考虑包括用于诊断程序的局部麻醉剂，但由于角膜毒性，这些绝不应用于治疗[4]。对于有显著继发性葡萄膜炎的病例，1%阿托品眼膏可防止疼痛的睫状体痉挛，尽管由于瞳孔散大，治疗后的动物需要遮阴处[8]。

### Sources
[1] Disorders of the Eyelids in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/eye-disorders-of-dogs/disorders-of-the-eyelids-in-dogs
[4] Local Anesthetics for the Eye in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/local-anesthetics-for-the-eye-in-animals
[5] Image Quiz: Can you name these ophthalmic conditions?: https://www.dvm360.com/view/image-quiz-can-you-name-these-ophthalmic-conditions
[6] Chlamydial Conjunctivitis in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals
[8] Infectious Keratoconjunctivitis in Cattle and Small Ruminants: https://www.merckvetmanual.com/eye-diseases-and-disorders/infectious-keratoconjunctivitis/infectious-keratoconjunctivitis-in-cattle-and-small-ruminants

## 预防措施和鉴别诊断

### 预防措施

伴侣动物结膜炎的预防主要集中在管理潜在疾病和环境因素。结膜炎本身没有特定的疫苗接种方案，尽管猫的常规FVRCP疫苗接种有助于减轻猫疱疹病毒（FHV-1）感染的严重程度[1][2]。疫苗可以预防疾病，但不能预防感染或携带状态，推荐使用非佐剂改良活疫苗[2]。

环境控制策略包括在多宠物家庭中保持适当的卫生，避免过度拥挤，并最小化触发病毒复发的应激因素[2]。对于FHV-1管理，L-赖氨酸补充剂（每日250-500mg）可能有助于减少病毒排毒和复发频率[3]。

在急性传染性结膜炎暴发期间，建议隔离受影响的动物，特别是在衣原体感染迅速传播的收容所环境中[3]。在FCV暴发期间，需要严格的检疫措施和屏障护理以防止传播[2]。

### 鉴别诊断

结膜炎的主要鉴别诊断包括干性角膜结膜炎（干眼症）、葡萄膜炎和青光眼。干眼症表现为Schirmer泪液试验值降低（犬<15mm/分钟）、角膜外观暗淡，并常有浅表角膜血管新生[1]。

葡萄膜炎表现为结膜充血、房水闪光、瞳孔缩小，通常眼内压降低，这与结膜炎眼压正常形成对比[1]。青光眼表现为眼内压升高（>25mmHg）、巩膜血管扩张和角膜水肿[1]。鉴别特征包括疼痛分布模式和相关的临床症状，如畏光和视力变化。

### Sources

[1] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings

[2] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings

[3] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
