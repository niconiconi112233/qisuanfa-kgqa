# 伴侣动物中的马拉色菌皮炎

马拉色菌皮炎是小动物兽医临床中最常见的继发性皮肤病之一，由共生酵母菌*厚皮马拉色菌*的过度生长引起。当易感因素破坏皮肤的自然屏障功能时，这种机会性病原体从正常的皮肤栖息者转变为致病生物。该疾病特别影响患有潜在过敏性疾病、特定品种易感性和皮肤褶皱等解剖因素的犬。虽然在猫中较少见，但全身性感染通常表明存在严重的潜在疾病，如副肿瘤综合征。了解宿主免疫力、环境因素和酵母菌生物学之间的复杂相互作用对于有效诊断和管理这种常见的皮肤病至关重要。

## 摘要

马拉色菌皮炎体现了伴侣动物机会性皮肤感染的复杂性，在特定情况下，正常的共生生物会变得具有致病性。该疾病的管理需要全面的方法，既要解决酵母菌过度生长问题，也要处理潜在的易感因素，如过敏性疾病和内分泌疾病。主要诊断发现包括细胞学上特征性的椭圆形出芽酵母菌，治疗结合了局部抗真菌药物（如氯己定-咪康唑香波）和全身性药物（如伊曲康唑，在适用时）。

| 方面 | 犬 | 猫 |
|--------|------|------|
| 患病率 | 非常常见，尤其与异位性皮炎相关 | 较少见，常继发于严重疾病 |
| 主要部位 | 趾间、褶皱区域、耳朵 | 分布不定 |
| 潜在原因 | 过敏、品种易感性、皮肤褶皱 | 副肿瘤综合征、胸腺瘤 |
| 预后 | 适当管理下预后极佳 | 良好，但取决于潜在疾病 |

通过适当的抗真菌治疗获得良好预后强调了通过细胞学检查进行准确诊断和处理并存疾病的重要性。长期成功需要维持方案和管理易感因素，特别是在遗传易感品种和过敏患者中，马拉色菌免疫疗法显示出有希望的结果。

## 疾病概述

马拉色菌皮炎是犬和猫中非常常见的浅表真菌性皮肤病，由*马拉色菌*属（特别是*厚皮马拉色菌*）的过度生长引起[1]。这些嗜脂性酵母菌是正常的共生生物，在伴侣动物出生后不久定植于皮肤、粘膜和耳道，主要存在于皮肤粘膜区域、耳朵和趾间区域[1]。在正常情况下，*马拉色菌*以极低数量作为健康皮肤菌群的一部分存在。

该生物体既是共生生物又是机会性病原体。世界兽医皮肤病学协会报告称，导致从正常栖息者转变为病原体的因素仍在研究中，但可能包括宿主免疫反应的改变以及与其他生物体（如*葡萄球菌*属）的相互作用[1]。易感条件包括湿度增加、表面脂质改变和角质层屏障功能破坏[1]。

多个犬品种表现出对马拉色菌皮炎的易感性，包括西施犬、拉萨犬、可卡犬、杰克罗素梗、西部高地白梗、金毛寻回犬和拉布拉多寻回犬[9]。该疾病在患有异位性皮炎的犬中尤其常见，常导致*马拉色菌*超敏反应[1]。虽然在犬中极为常见，但猫的全身性马拉色菌皮炎较为罕见，通常与更严重的潜在疾病相关，如副肿瘤综合征[6]。

### Sources
[1] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[6] Update on treatment of Malassezia dermatitis (Proceedings): https://www.dvm360.com/view/update-treatment-malassezia-dermatitis-proceedings
[9] Malassezia Dermatitis: Is it Complicating your Life?: https://www.dvm360.com/view/malassezia-dermatitis-it-complicating-your-life

## 病因学和发病机制

厚皮马拉色菌是伴侣动物马拉色菌皮炎的主要致病生物体[2]。这种嗜脂性酵母菌作为正常犬猫皮肤上的共生生物存在，特别是在褶皱区域（嘴唇、外阴、腋窝、趾间）、口腔和肛门粘膜表面、耳道和肛门腺[2]。

从共生状态到致病状态的转变涉及复杂的宿主-病原体相互作用。与念珠菌感染不同，马拉色菌皮炎与近期抗生素给药无关；相反，表面葡萄球菌生物体与马拉色菌之间存在共生关系，常见并发感染[2]。在受影响的犬中已发现I型和IV型超敏反应，这表明宿主免疫反应而非生物体毒力决定疾病发展[2]。

多种易感因素破坏正常的皮肤稳态并促进酵母菌过度生长[1][2]。这些包括过敏性疾病（异位性皮炎、食物过敏）、内分泌疾病（甲状腺功能减退、肾上腺皮质功能亢进）和解剖因素如过度皮肤褶皱[1][2]。影响皮肤屏障功能或皮肤脂质含量的疾病为马拉色菌繁殖创造了有利条件[2]。

病理生理学涉及多种炎症级联反应。马拉色菌产生脂肪酶代谢表面游离脂肪酸，导致皮肤pH值改变、炎症类二十烷酸释放和正常皮肤屏障功能下降[2]。补体激活可能通过马拉色菌抗原的经皮吸收发生，进一步促进皮肤炎症[2]。某些品种如巴吉度犬表现出遗传易感性，维持较高的基线马拉色菌种群并增加皮炎易感性[6]。

### Sources
[1] Skin infections, MRSI, perpetuating factors,topicals, antibiotics and more: https://www.dvm360.com/view/skin-infections-mrsi-perpetuating-factorstopicals-antibiotics-and-more-proceedings
[2] Diagnosis and treating of Malassezia dermatitis: https://www.dvm360.com/view/diagnosis-and-treating-malassezia-dermatitis-proceedings
[3] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[4] Otitis Externa in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[5] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis
[6] Canine Atopic Dermatitis - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis

## 临床表现和诊断

**犬的临床症状**

马拉色菌皮炎在犬中通常以瘙痒和红斑为主要症状[1]。常见的临床发现包括苔藓样变、油腻性渗出物、干燥鳞屑、丘疹、斑块、脱毛、毛囊管型、甲沟炎和色素沉着[1]。常观察到具有特征性霉味的湿性皮炎[1]。瘙痒程度从轻微到剧烈不等，值得注意的是，红斑可能仅伴有轻微瘙痒，特别是在趾间区域[1]。

病变通常影响趾间空间、褶皱区域、面部、甲褶、口周区域、耳廓和肘部屈肌表面[1]。一个重要的临床线索是当以前季节性瘙痒变为非季节性，或者分布改变涉及非典型区域如腹侧颈部时[1]。

**猫的临床症状**

在猫中，马拉色菌皮炎引起不同程度的瘙痒，比犬中少见[2]。该疾病通常与严重的潜在疾病相关，如副肿瘤综合征[2]。患有副肿瘤性皮肤病的猫常发展为继发性马拉色菌皮炎[2]。

**诊断方法**

通过细胞学鉴定马拉色菌生物体对诊断至关重要[1]。常见的采样方法包括胶带印片和在受影响区域的直接印片[1]。对于干燥皮肤，推荐使用手术刀片进行表面刮取[1]。使用Diff-Quik染色时，只有第三种染色剂（亚甲蓝）足以快速处理[1]。

犬的诊断阈值是皮肤上>1个酵母菌/高倍视野（400X），而在耳朵中>5个酵母菌/HPF被视为异常[2]。然而，一些犬可能对极低数量的酵母菌产生超敏反应，使这些指南具有相对性[2]。必须采集多个部位，因为马拉色菌数量可能因动物舔舐而减少[1]。

### Sources
[1] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis
[2] Update on treatment of Malassezia dermatitis (Proceedings): https://www.dvm360.com/view/update-treatment-malassezia-dermatitis-proceedings

## 治疗方法

马拉色菌皮炎的综合治疗需要多模式方法，针对感染控制和潜在的易感因素。抗真菌治疗选择应考虑感染严重程度、患者健康状况和主人对治疗复杂性的期望[1]。

**局部治疗**

局部治疗是管理局部感染和预防复发的基础。含有2%氯己定和2%咪康唑的药用香波显示出强效证据，通常每周应用两次[1,3]。其他有效的局部药物包括硫化硒、酮康唑、克霉唑和含有吡罗克酮乙醇胺的新配方[1,5]。含有抗真菌成分（如咪康唑或特比萘芬）的免洗护发素提供持续的治疗接触[5]。

**全身性抗真菌药物**

对于全身性感染或仅对局部治疗无反应的病例，需要全身性抗真菌药物。伊曲康唑（5-10 mg/kg每日）和酮康唑（7-10 mg/kg每日）在犬中显示出中等到强效的证据[1,2]。伊曲康唑脉冲疗法（每周连续2天，持续3周）显示出与连续给药相当的疗效[1]。氟康唑和特比萘芬获得的证据较弱，但仍是可行的替代选择[1,2]。在猫中，由于安全问题，伊曲康唑和氟康唑优于酮康唑[1]。

**联合治疗和耐药性管理**

除非感染非常局限，否则结合局部和全身治疗可提供最佳治疗效果[4]。含有吡罗克酮乙醇胺的产品在解决新出现的抗真菌耐药性问题方面显示出希望，但需要更多对照研究[4,6]。治疗持续时间应在临床解决后继续14天，最少21天疗程[4]。

**潜在疾病的管理**

成功的长期管理需要识别和控制易感因素，如过敏性疾病、内分泌疾病或解剖异常[1,4]。并发细菌感染常伴随马拉色菌皮炎，应同时处理[4]。

### Sources
[1] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[2] Update on atopic dermatitis (Proceedings): https://www.dvm360.com/view/update-atopic-dermatitis-proceedings
[3] Time for topicals: A spot-on guide to treating dermatologic diseases: https://www.dvm360.com/view/time-for-topicals-a-spot-on-guide-to-treating-dermatologic-diseases
[4] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis
[5] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis/1000
[6] Topical therapies in veterinary dermatology: https://www.dvm360.com/view/topical-therapies-in-veterinary-dermatology

## 预防和长期管理

预防马拉色菌皮炎复发需要解决潜在的易感因素并实施适当的长期管理策略[1]。最关键的方面是识别和治疗破坏皮肤屏障功能的主要疾病，包括过敏性疾病（异位性皮炎、食物过敏）、内分泌疾病（甲状腺功能减退、肾上腺皮质功能亢进）和外寄生虫[1][2]。

**环境控制和维持治疗**
必须管理促进酵母菌过度生长的环境因素，包括过度湿度、皮肤脂质改变和并发细菌感染[2]。对于维持预防，由于毒性和耐药性担忧，通常优先选择局部治疗而非口服药物[1]。每三天使用2%氯己定和2%咪康唑香波定期洗澡可显著减少马拉色菌种群，维持方案根据个体患者需求调整[1]。

**过敏患者的免疫疗法**
马拉色菌过敏原免疫疗法是管理并发过敏性皮炎患者复发性感染的有希望方法[2]。大多数皮肤科医生现在常规将马拉色菌酵母提取物纳入犬过敏原疫苗中，这种免疫疗法似乎能有效减少感染频率并减少对抗真菌药物的依赖[1]。这种有针对性的方法解决了导致疾病发展的潜在超敏反应。

**品种特异性考虑**
某些品种存在遗传易感性，巴吉度犬维持较高的基线马拉色菌种群并增加感染风险[2]。对于易复发的遗传易感患者，可能需要定期监测和脉冲疗法[2]。

### Sources
[1] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[2] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis

## 鉴别诊断和预后

### 鉴别诊断

马拉色菌皮炎因其与其他皮肤病的临床相似性而带来几个诊断挑战[1]。主要鉴别诊断包括异位性皮炎、食物过敏和由葡萄球菌属引起的细菌性脓皮症[1][4]。这些疾病常与马拉色菌感染并存，特别是在异位性皮炎犬中，50%的病例可能并发酵母菌皮炎[4]。

其他重要鉴别包括内分泌疾病如甲状腺功能减退，这可能导致酵母菌过度生长[4]。还必须考虑皮肤癣菌病，尽管在犬中比马拉色菌感染少见[1]。在猫中，应评估副肿瘤综合征和胸腺瘤相关皮肤病，因为全身性马拉色菌皮炎常继发于这些严重的潜在疾病[2][3]。

区分马拉色菌皮炎主要依赖于细胞学检查，显示特征性的椭圆形出芽酵母菌及其"足印"外观[3]。正常计数为皮肤上≥1个酵母菌/高倍视野，耳中≥5个/视野[3]。

### 预后

马拉色菌皮炎的预后通常通过适当的抗真菌治疗极佳[3]。大多数病例在局部或全身治疗2-3周内反应[3]。然而，可能需要长期管理，因为该疾病经常复发，特别是当潜在的易感因素持续存在时[1][4]。

对治疗的反应既是诊断工具也是预后指标[4]。并发细菌感染或潜在过敏性疾病的病例可能需要延长治疗疗程和维持治疗以预防复发[1][3]。

### Sources

[1] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[2] Update on malassezia dermatitis in dogs and cats (Proceedings): https://www.dvm360.com/view/update-malassezia-dermatitis-dogs-and-cats-proceedings
[3] Update on treatment of Malassezia dermatitis (Proceedings): https://www.dvm360.com/view/update-treatment-malassezia-dermatitis-proceedings
[4] Malassezia Dermatitis: Is it Complicating your Life?: https://www.dvm360.com/view/malassezia-dermatitis-it-complicating-your-life
