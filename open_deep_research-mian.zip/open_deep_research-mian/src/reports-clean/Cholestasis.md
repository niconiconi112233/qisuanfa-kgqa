# 伴侣动物胆汁淤积：综合性兽医综述

胆汁淤积是犬猫中一种重要的肝胆疾病，其特征是胆汁流动受损，导致胆汁成分在肝细胞和胆管内积聚。这种情况影响所有年龄段的动物，犬猫患者表现出不同的症状。犬通常继发于胆囊炎/胆囊肝炎综合征和胆囊黏液囊肿而发生胆汁淤积，而猫则常表现为胆囊炎，作为涉及并发炎症性肠病和胰腺炎的三联炎综合征的一部分。本报告探讨了小动物临床实践中胆汁淤积性疾病的病理生理学、临床表现、诊断方法和治疗策略，强调了物种特异性考虑因素和循证治疗方案。

## 摘要

本综合性综述综合了当前关于犬猫胆汁淤积管理的兽医知识，揭示了物种间不同的病理生理学模式和治疗方式。犬主要通过涉及革兰氏阴性菌的细菌感染和胆囊疾病引起的机械性梗阻而发生胆汁淤积，而猫则常表现为作为三联炎综合征一部分的炎症性胆囊炎。

关键诊断发现包括碱性磷酸酶显著升高（严重病例中≥100倍正常值）超过ALT活性、高胆红素血症和特征性超声改变。治疗成功取决于多模式方法，包括对梗阻性疾病的手术干预、靶向抗菌治疗和支持性药物，如熊去氧胆酸和S-腺苷甲硫氨酸。

| 预后因素 | 犬 | 猫 |
|---|---|---|
| **良好结果** | 肝外胆管梗阻的早期手术干预 | 肝脂质沉积症：积极支持治疗下60-88%存活率 |
| **治疗持续时间** | 病例解决需2-4周 | 肝脂质沉积症解决需14-21天 |
| **长期管理** | 慢性胆囊炎需要持续监测 | 通常完全康复；复发罕见 |

临床成功需要及时识别黄疸、适当的诊断检查（包括组织病理学）和物种特异性治疗方案。未来的兽医实践应强调早期干预，特别是厌食猫的营养支持，以优化患者结果并防止进展为不可逆的肝损伤。

## 疾病概述与流行病学

胆汁淤积是一种病理状况，其特征是胆汁流动受损，导致胆汁酸、胆红素和其他胆汁成分在肝细胞和胆管内积聚[1]。这种情况可分为两种主要类型：肝内胆汁淤积，由于肝实质或小胆管功能障碍而发生；肝外胆汁淤积，由于肝脏外大胆管的机械性梗阻引起[1][2]。

在犬中，胆汁淤积通常继发于犬胆囊炎/胆囊肝炎综合征（CCHS），该综合征常与胆囊黏液囊肿和肝外胆管梗阻相关[1]。所有年龄段的犬都可能受影响，但需要胆囊疾病手术干预的犬往往比年轻患者年龄更大（平均年龄140.5个月）[1]。此外，胆汁淤积也可能发生在患有胆石症（胆结石）的犬中，这种情况在中年至老年动物中更常见，在小品种犬中发病率更高[3]。

在猫中，胆汁淤积最常见的是作为胆囊炎/胆囊肝炎复合体的一部分，占猫肝胆疾病的很大比例[2]。中性粒细胞性胆囊炎影响不同年龄的猫，但更常见于青年至中年猫，而淋巴细胞性胆囊炎通常始于4岁以下的猫[2]。与犬不同，猫的胆汁淤积常作为"三联炎综合征"的一部分发生，涉及并发炎症性肠病和胰腺炎[2]。

### Sources
[1] Canine Cholangiohepatitis - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[2] Treatment of hepatobiliary disease in dogs and cats: https://www.dvm360.com/view/treatment-hepatobiliary-disease-dogs-and-cats
[3] Cholelithiasis in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/cholelithiasis-in-small-animals

## 病因学与病理生理学

犬猫的胆汁淤积由多种病因因素引起，这些因素破坏了正常的胆汁流动，导致特征性的病理生理变化。理解这些机制对于适当的临床管理至关重要。

**感染性病因**
细菌感染是胆汁淤积的一个重要原因，特别是在犬中。犬胆囊炎/胆囊肝炎综合征（CCHS）通常涉及革兰氏阴性菌，经常分离出肠球菌和大肠杆菌[1]。在猫中，化脓性胆囊炎通常以大肠杆菌为主要病原体，同时伴有肠球菌、拟杆菌和其他肠道细菌[2]。这些感染通常是由于肠道细菌上行移位或全身性疾病期间的血行播散引起的。

**肿瘤性病因**
原发性肝肿瘤和转移性肿瘤通常通过机械性梗阻或实质替代引起胆汁淤积。胆管腺癌是猫中最常见的原发性恶性肝肿瘤，可能来源于肝内或肝外胆管[4]。在患有胆汁淤积的猫中，胆管肿瘤可能是囊性的，可能导致肝内或肝外胆管树扩张和梗阻[3]。累及肝脏的淋巴瘤可能通过弥漫性肝浸润或胆管梗阻引起黄疸，常表现为副肿瘤性小管性胆汁淤积[4]。

**代谢性和药物性病因**
肾上腺皮质功能亢进和其他内分泌疾病可通过糖皮质激素诱导的肝病变引起继发性胆汁淤积。苏格兰梗犬表现出品种特异性易感性，易患与异常肾上腺类固醇生成相关的空泡性肝病，产生过量孕激素和雄激素[1]。药物性胆汁淤积是一个重要但可能被低估的原因，许多药物可通过可预测或特异性的机制引起肝损伤[6]。

**病理生理机制**
病理生理学涉及胆汁流动停滞，导致导管周围中性粒细胞浸润、水肿和导管扭曲。血清碱性磷酸酶活性的最大增加发生在患有弥漫性或局灶性胆汁淤积性疾病的犬中，包括肝外胆管梗阻、胰腺炎相关肝病和胆管癌[2]。如果不治疗，进行性炎症可导致胆管增生、门静脉周围纤维化，最终发展为胆汁性肝硬化。

### Sources
[1] Canine Cholangiohepatitis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[2] Enzyme Activity in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/enzyme-activity-in-hepatic-disease-in-small-animals
[3] Clinical approach to icterus in the cat (Proceedings): https://www.dvm360.com/view/clinical-approach-icterus-cat-proceedings
[4] Hepatic Neoplasia in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-neoplasia-in-small-animals
[5] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[6] Drug-induced liver injury (Proceedings): https://www.dvm360.com/view/drug-induced-liver-injury-proceedings

## 临床症状和体征

胆汁淤积根据潜在原因和严重程度表现出不同的临床表现。最显著的体征是黄疸（黄疸），约70%的患病动物出现此症状[1]。在犬中，临床症状最初可能很轻微，呕吐、腹泻、体重减轻、多尿/多饮和食欲减退是常见的非特异性发现[1]。

体格检查显示许多病例存在黄疸、肝肿大、脱水和身体状况不佳[1]。犬在触诊时可能表现出腹部不适，特别是在急性情况下[4]。患有胆囊炎的猫常表现为发热、嗜睡，并可能显示腹痛[4]。

## 诊断方法

实验室评估对诊断至关重要。典型的胆汁淤积模式显示碱性磷酸酶（ALP）活性显著增加，高于丙氨酸氨基转移酶（ALT）活性[2]。在犬中，ALP的最大增加（≥100倍正常值）发生在弥漫性胆汁淤积性疾病中[2]。γ-谷氨酰转移酶（GGT）通常与ALP升高平行，但在猫中可能不太明显[4]。

高胆红素血症很常见，患有相似疾病的猫比犬具有更高的胆红素浓度[4]。由于维生素K吸收不良，可能出现凝血异常，影响约45%的病例[4]。

腹部超声是首选的影像学检查方法，显示高回声肝实质，并可能识别胆道异常[1][4]。"猕猴桃切片"外观是胆囊黏液囊肿的特征性表现[1]。然而，明确诊断通常需要肝活检，因为单独的超声检查无法诊断胆囊炎[4]。

组织病理学仍然是诊断的金标准，需要至少包含15个门管区的足够组织样本[6]。当怀疑涉及细菌时，肝组织和胆汁的培养有助于抗生素选择[4]。

### Sources
[1] Canine liver enzymes-so many questions!: https://www.dvm360.com/view/canine-liver-enzymes-so-many-questions
[2] Enzyme Activity in Hepatic Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/enzyme-activity-in-hepatic-disease-in-small-animals
[3] Diagnostic approach in dogs with increased ALP activity ...: https://www.dvm360.com/view/diagnostic-approach-dogs-with-increased-alp-activity-proceedings
[4] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[5] Abnormal liver enzymes: A practical clinical approach ...: https://www.dvm360.com/view/abnormal-liver-enzymes-practical-clinical-approach-proceedings
[6] Liver Biopsy in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/liver-biopsy-in-small-animals

## 治疗与管理

胆汁淤积治疗需要多模式方法，侧重于解决潜在原因、支持肝细胞功能和管理并发症。治疗策略根据病情是急性还是慢性以及是否存在机械性梗阻而有所不同[1]。

**手术治疗**
对于涉及肝外胆管梗阻（EHBDO）的病例，手术干预是必要的。最佳管理需要识别和治疗潜在原因，包括仔细检查胆道结构和胆囊是否有黏液囊肿、胆石症或通畅性问题[3]。在脓毒性胆囊疾病病例中，胆囊切除术是适应症，并提供强大的生存优势[3]。

**药物治疗**
抗菌治疗是化脓性胆汁淤积治疗的基石。推荐最初使用三联抗生素方案，结合甲硝唑（每12小时7.5 mg/kg）、氟喹诺酮类和广谱青霉素[3]。治疗持续时间从已解决病例的2-4周到炎症性肠病等慢性过程的数月不等[3]。

**支持性药物**
利胆剂通过增加胆汁流量来帮助机械清洁。熊去氧胆酸（10-15 mg/kg，每12小时随食物分服）增加胆汁酸依赖性流量[3]。S-腺苷甲硫氨酸（SAMe）每日18-40 mg/kg空腹服用，支持谷胱甘肽合成并增加非胆汁酸依赖性胆汁流量[1][3]。维生素E（每日10-15 IU/kg）提供抗氧化支持，而维生素K1（皮下注射0.5 mg/kg）解决胆汁淤积患者的凝血病[3]。

**营养管理**
充足的热量摄入对于防止分解代谢至关重要。应提供高质量、易消化的蛋白质（占可消化千卡热量的15-20%），除非存在肝性脑病[9]。脂肪限制通常是不必要的，因为它提供重要的能量密度和适口性[9]。

**监测与随访**
连续评估包括全血细胞计数、肝酶（ALT、ALP）和总胆红素，有助于指导治疗持续时间和有效性[5]。餐前和餐后总血清胆汁酸测量可用于评估胆汁淤积患者的肝功能[4]。

### Sources
[1] Pharmacological management of canine and feline liver disease: https://www.dvm360.com/view/pharmacological-management-canine-and-feline-liver-disease-proceedings
[3] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[4] Hepatic Function Tests in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/hepatic-function-tests-in-small-animals
[5] Enzyme Activity in Hepatic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/laboratory-analyses-and-imaging-in-hepatic-disease-in-small-animals/enzyme-activity-in-hepatic-disease-in-small-animals
[9] Treatment of liver disease: Medical and nutritional aspects: https://www.dvm360.com/view/treatment-liver-disease-medical-and-nutritional-aspects-sponsored-nestle-purina

## 预防与预后

### **预防措施**

**一级预防：** 胆汁淤积主要是一种继发性疾病，这限制了传统的预防策略[1]。然而，几种措施可以减少风险因素。保持适当的体重至关重要，因为肥胖使猫易患肝脂质沉积症，这常导致继发性胆汁淤积[2]。定期兽医检查能够早期发现和治疗通常引发胆汁淤积发作的疾病，如炎症性肠病、胰腺炎和甲状腺功能亢进。

**二级预防：** 在任何厌食期间进行积极的营养支持至关重要，特别是在超重猫中[3]。环境压力管理，包括减少寄养时间、家庭变化和饮食调整，有助于预防诱发事件。及时治疗并发疾病可防止进展为胆汁淤积性肝病[4]。

### **预后因素与预期结果**

**良好预后指标：** 早期诊断和干预显著改善结果，肝脂质沉积症在积极治疗时显示60-88%的存活率[5]。年龄较小、就诊时较高的中位钾和红细胞压积水平与更好的存活率相关。胆红素水平在7-10天内下降50%表明对治疗反应良好[6]。

**不良预后指标：** 并发胰腺炎显著恶化肝脂质沉积症病例的预后[3]。晚期纤维化或肝硬化的发展代表不良长期结果，尽管这种进展在淋巴细胞性胆囊炎中不常见。肝外胆管梗阻无论潜在原因如何都具有谨慎至不良的预后，围手术期发病率和死亡率较高[7]。

**长期结果：** 肝脂质沉积症要么在14-21天内解决，要么证明是致命的；不会发生慢性存活[8]。在成功病例中，通常完全康复且无残留功能障碍，康复后复发罕见。慢性胆囊炎可能通过适当的药物治疗实现长期缓解，尽管自发性周期和临床发作可能在整个患者生命过程中发生。

### Sources

[1] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings

[2] Liver disease and treatment in dogs and cats (Proceedings): https://www.dvm360.com/view/liver-disease-and-treatment-dogs-and-cats-proceedings

[3] Hepatic lipidosis maximizing a successful outcome (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-maximizing-successful-outcome-proceedings

[4] Disorders of the Liver and Gallbladder in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats

[5] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies

[6] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease

[7] Feline hepatobiliary disease: What's new in diagnosis and therapy? (Proceedings): https://www.dvm360.com/view/feline-hepatobiliary-disease-whats-new-diagnosis-and-therapy-proceedings

[8] Feline Hepatic Lipidosis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
