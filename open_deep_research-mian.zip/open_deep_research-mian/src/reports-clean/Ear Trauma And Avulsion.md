# 耳部创伤与撕脱

耳部创伤和撕脱是伴侣动物中的重大急症，范围从轻微的撕裂伤到完全的耳廓撕脱。这些损伤通常由狗打架、车祸以及因潜在耳部疾病导致过度抓挠而造成的自我创伤引起。耳部的复杂解剖结构，涉及皮肤、软骨、血管和神经结构，使得正确的评估和治疗对于获得最佳结果至关重要。本报告探讨了耳部创伤的全面兽医管理，涵盖病原学并发症、诊断方法、手术修复技术以及在犬猫成功治疗中必需的预防策略。

## 预后

伴侣动物耳部创伤和撕脱的预后因损伤严重程度、组织活力和及时干预而有显著差异。完全性组织撕脱需要立即手术处理，其结果取决于软骨损伤程度和血管受损情况。继发性细菌感染会显著增加恢复的复杂性，特别是当革兰氏阴性菌如假单胞菌在受损组织中形成生物膜时。

伤后6小时内进行早期干预可以实现一期闭合，获得最佳的美观和功能结果。延迟治疗会增加感染风险，并可能需要重建手术，延长愈合时间。疼痛管理方案显著影响患者在恢复期间的舒适度和依从性。

| 预后因素 | 良好结果 | 不良结果 |
|-------------------|--------------|--------------|
| 治疗时间 | <6小时 | >24小时 |
| 组织活力 | 粉红色、出血边缘 | 蓝黑色、无活力 |
| 污染程度 | 干净伤口 | 重度污染 |
| 继发感染 | 无/已控制 | 已形成生物膜 |

成功的结果需要主人在2-3周的愈合期内配合更换绷带、抗菌治疗和活动限制。

## 常见病原体

耳部创伤和撕脱造成污染性伤口，易受原发性和继发性细菌感染的影响。受损的皮肤屏障和组织失活为机会性病原体提供了最佳条件。

**原发性细菌病原体**通常包括革兰氏阳性球菌，特别是葡萄球菌属和链球菌属[1]。细胞学评估通常显示伴有球菌的炎症细胞，表明葡萄球菌或链球菌感染[1]。伪中间葡萄球菌（以前称为中间葡萄球菌）是犬类皮肤感染的主要病原体，通常产生β-内酰胺酶[2]。

**继发性细菌入侵者**通常涉及创伤后的革兰氏阴性菌。假单胞菌属、变形杆菌属、克雷伯菌属和棒状杆菌属通常定植于创伤的耳部组织[1]。细胞学中的杆状生物通常表明铜绿假单胞菌、大肠杆菌或奇异变形杆菌[2]。这些革兰氏阴性病原体由于生物膜形成和固有的抗生素耐药性而特别成问题。

**机会性病原体**包括肠球菌和各种在受损组织环境中增殖的厌氧菌[2]。在创伤伤口中，需氧菌和厌氧菌的混合感染很常见[3]。

当正常组织屏障被破坏时，这些生物的致病潜力会显著增加，因此通过细胞学检查快速识别和靶向抗菌治疗对于成功的伤口管理至关重要。

### Sources

[1] Diagnosing and managing ear disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-ear-disease-proceedings
[2] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/en/ear-disorders/otitis-externa/otitis-externa-in-animals
[3] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

## 临床症状和体征

耳部创伤和撕脱表现出需要仔细评估的明显体格检查结果。急性出血模式通常表现为撕裂组织的活动性出血，血液积聚在耳道或周围区域[1]。组织损伤程度差异很大，从部分厚度撕裂伤到耳廓节段的完全撕脱。

疼痛评估显示受影响动物的反应各不相同。犬可能表现出摇头、抓挠受影响的耳朵，或不愿让头部被操作[1]。猫通常表现出更微妙的疼痛行为，包括躲藏、活动减少或对处理产生攻击性反应[2]。生理性疼痛指标包括心率、呼吸率升高和高血压，但这些参数并非耳部创伤特有[1]。

体格检查结果包括创伤部位周围的肿胀、血肿形成和组织失活[3]。穿透性创伤可能造成深部伤口，潜在的软组织损伤超出可见的损伤路径[3]。钝性创伤可导致挤压伤，伴有明显的肿胀和瘀伤模式。

品种特异性考虑影响表现的严重程度。具有突出、暴露耳朵的短头颅品种由于解剖学脆弱性可能遭受更广泛的损伤[3]。像可卡犬这样的长耳品种在正常活动期间面临更高的创伤风险，而竖耳品种在受伤时可能表现出更明显的不对称。

完整的神经系统评估应评估面神经功能和霍纳综合征体征，因为更深的耳部创伤可能影响周围的神经结构[3]。当怀疑耳道创伤时，应仔细进行耳镜检查以确定鼓膜完整性。

### Sources
[1] Recognition and Assessment of Pain in Animals: https://www.merckvetmanual.com/therapeutics/pain-assessment-and-management/recognition-and-assessment-of-pain-in-animals
[2] Assessing pain in pets: https://www.dvm360.com/view/assessing-pain-in-pets
[3] Trauma in Emergency Medicine in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/specific-diagnostics-and-therapy/trauma-in-emergency-medicine-in-small-animals

## 诊断方法

伴侣动物耳部创伤和撕脱的诊断评估需要系统的临床检查和适当的影像学方法。**耳镜检查**构成耳部创伤评估的基础[1]。耳镜能够可视化外耳道和鼓膜，允许评估耳道完整性、是否存在碎屑或血液以及鼓膜穿孔情况[2]。

**临床评估**从耳部外部结构的评估开始，包括耳廓、耳廓软骨和周围组织的撕裂伤、血肿或撕脱伤[3]。**视频耳镜**可能比手持式耳镜提供额外的放大倍率和更优越的耳道和鼓膜可视化效果[1]。**气导耳镜检查**有助于确定鼓膜活动性并识别创伤后的中耳积液或出血[2]。

**细胞学检查**耳道内容物或吸出的液体有助于识别继发性感染或炎症过程。应使用棉签获取渗出物，滚涂到玻璃载玻片上，用快速染色法染色，并在显微镜下检查细菌、酵母菌、炎症细胞和吞噬作用的证据[1]。当怀疑细菌污染时，特别是在穿透性伤口或慢性病例中，应采用**培养方法**。

**影像学方法**为复杂创伤病例提供关键的诊断信息。**计算机断层扫描（CT）或MRI**应在严重、慢性创伤且对适当治疗无反应的病例中进行，提供骨结构、软组织损伤和中耳受累的优越细节[1][7]。当增生组织妨碍鼓膜充分可视化或当神经系统症状伴随耳部创伤时，应进行**骨性鼓泡的X线摄影**检查[1]。

**并发损伤评估**是必要的，因为耳部创伤通常伴随需要全面评估的头部创伤[3]。

### Sources

[1] Otitis Externa in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Otoscope Exam - StatPearls - NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/sites/books/NBK553163/
[3] Trauma in Emergency Medicine in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/specific-diagnostics-and-therapy/trauma-in-emergency-medicine-in-small-animals
[4] Computed tomographic findings in dogs with head trauma and ...: https://avmajournals.avma.org/view/journals/ajvr/78/9/ajvr.78.9.1085.xml
[5] 7 steps for a full ear workup - dvm360: https://www.dvm360.com/view/7-steps-full-ear-workup
[6] Ceruminous Gland Tumors in Small Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-in-small-animals/ceruminous-gland-tumors-in-small-animals
[7] What Is Your Diagnosis? in: Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/243/6/javma.243.6.775.xml

## 治疗选择

耳部创伤和撕脱的治疗需要多模式方法，结合手术修复、伤口管理、疼痛控制和抗菌治疗。初级伤口管理包括使用35mL注射器和19号针头以7-8 psi压力的无菌生理盐水进行彻底灌洗[2][3]。手术清创去除无活力组织，评估皮肤活力至关重要--蓝黑色、皮革样或白色组织通常需要切除[3]。

手术闭合选项取决于污染水平和组织可用性。一期闭合适用于伤后6小时内的干净伤口，而延迟一期闭合（伤后3-5天）适用于污染伤口[2][5]。对于广泛组织丢失，重建技术包括网状皮肤移植和用于逐渐接近伤口边缘的可调水平褥式缝合[1][4]。

疼痛管理是必要的，应包括阿片类镇痛剂如吗啡（犬0.5-1.0 mg/kg肌注/皮下注射，猫0.05-0.1 mg/kg）或氢吗啡酮，持续时间为4-6小时[8]。多模式方案可能包括曲马多、利多卡因恒速输注以及在适当情况下使用非甾体抗炎药如卡洛芬[8]。

对于肮脏或感染的伤口，应立即开始使用广谱杀菌剂（第一代头孢菌素）进行**抗菌治疗**[3][5]。绷带包扎需要三层：直接接触敷料、吸收性衬垫和保护性外层[2]。对于耳廓血肿，手术引流配合褥式缝合可消除死腔，通常结合糖皮质激素灌注[7]。

### Sources
[1] DVM 360 Wound repair: Dog ear correction techniques: https://www.dvm360.com/view/wound-repair-dog-ear-correction-techniques
[2] Merck Veterinary Manual Wound Management - Special Pet Topics: https://www.merckvetmanual.com/special-pet-topics/emergencies/wound-management
[3] Merck Veterinary Manual Initial Wound Management in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/initial-wound-management-in-small-animals
[4] DVM 360 3 reconstruction techniques to close problem wounds: https://www.dvm360.com/view/3-reconstruction-techniques-close-problem-wounds
[5] DVM 360 Wound management: basic principles: https://www.dvm360.com/view/wound-management-basic-principles-proceedings
[6] Merck Veterinary Manual Auricular Hematomas in Dogs, Cats, and Pigs: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs
[7] DVM 360 Pain management for small animal clinical patients: https://www.dvm360.com/view/pain-management-small-animal-clinical-patients-critical-care-and-peri-operative-analgesics-proceedin
[8] DVM 360 Surgery of the ear: https://www.dvm360.com/view/surgery-ear-proceedings

## 预防措施

环境管理构成了预防伴侣动物耳部创伤和撕脱的基石。应每周进行定期耳部检查，以识别炎症、分泌物或结构变化的早期迹象，这些可能易导致损伤[1]。宠物主人必须使用适当的清洁技术保持正确的耳部卫生--绝不应将棉签插入耳道，因为它们会将碎屑推得更深并造成创伤[2]。

行为改变侧重于解决导致过度摇头和抓挠的潜在疾病。及早干预外耳炎、过敏反应或寄生虫感染可防止自我损伤造成的继发性创伤[1]。耳廓血肿的发病机制通常涉及因瘙痒引起的摇头或抓挠造成的创伤，因此及时治疗瘙痒性疾病至关重要[3]。

对于具有垂耳或狭窄耳道的高风险品种，防护设备变得必不可少。具有下垂耳廓的犬应定期修剪和清洁耳朵，以防止水分积聚[4]。游泳的犬受益于防护耳罩和使用局部收敛剂进行彻底的游泳后干燥方案，以减少浸渍[4]。

主人教育在预防策略中仍然至关重要。兽医应示范正确的耳部清洁技术，并强调识别早期预警信号的重要性，包括头部倾斜、耳朵抓挠和分泌物[2]。这使兽医能够在创伤性并发症发展之前进行及时干预。

### Sources
[1] Ear Infections and Otitis Externa in Dogs: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/ear-infections-and-otitis-externa-in-dogs
[2] 12 tips for easier cat and dog ear care: https://www.dvm360.com/view/12-tips-easier-cat-and-dog-ear-care
[3] Auricular Hematomas in Dogs, Cats, and Pigs - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/auricular-hematomas-in-dogs-cats-and-pigs
[4] Otitis Externa in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

## 鉴别诊断

将耳部创伤和撕脱与其他耳部疾病区分需要系统评估临床表现、分布模式和诊断结果[1,2]。

**耳血肿**表现为耳廓凹面的波动性肿胀，通常在摇头或抓挠后出现。与创伤性撕裂伤不同，血肿保持皮肤完整性，同时在皮肤和软骨之间形成充满液体的肿胀[1,5]。

**外耳炎**引起耳道内的炎症，伴有特征性的分泌物和气味，而耳部创伤主要影响外部结构。然而，这两种情况可能共存，因为创伤可能易导致继发性感染[2]。

**单侧与双侧表现**提供关键的诊断线索。创伤性损伤总是单侧的，而双侧问题通常表明寄生虫、代谢、过敏或自身免疫原因[3]。

**肿瘤**必须通过活检来区分，因为耳道肿瘤可以模拟创伤性变化。临床症状包括单侧慢性分泌物和摇头，但与炎症性增生不同，肿瘤性生长不会通过局部治疗而消退[7]。

**免疫介导性疾病**如落叶型天疱疮或血管炎通常影响多个身体部位，包括脚垫、面部和皮肤黏膜交界处，这与局部创伤性病变形成对比[6,8]。

**犬耳缘皮肤病**包括品种特异性疾病，如腊肠犬的斑秃或垂耳品种的皮脂溢，这些表现为慢性、进行性变化，而不是急性创伤性损伤[8]。

### Sources

[1] Successful surgical management of aural hematoma with ...: https://avmajournals.avma.org/downloadpdf/view/journals/javma/263/5/javma.24.09.0571.pdf
[2] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[3] Feline otitis (Proceedings): https://www.dvm360.com/view/feline-otitis-proceedings
[4] Surgery of the ear (Proceedings): https://www.dvm360.com/view/surgery-ear-proceedings-1
[5] Miscellaneous Diseases of the Pinna in Dogs and Cats - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/miscellaneous-diseases-of-the-pinna-in-dogs-and-cats
[6] Tumors of the Ear Canal in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-canal-and-middle-ear/tumors-of-the-ear-canal-in-animals
[7] Disorders of the Outer Ear in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/disorders-of-the-outer-ear-in-dogs
[8] Practical approach to diagnosing and managing ear disease in the dog (Proceedings): https://www.dvm360.com/view/practical-approach-diagnosing-and-managing-ear-disease-dog-proceedings
