# 伴侣动物角膜炎

角膜炎，即透明角膜的炎症，是兽医实践中影响犬猫的最重要眼部疾病之一。本综合报告探讨了角膜炎的多面性，从影响高达80%猫的猫疱疹病毒1型等传染性病因，到德国牧羊犬的慢性浅表性角膜炎等免疫介导性疾病。分析涵盖了关键诊断方法，包括荧光素染色和希氏泪液测试，探讨了从局部抗生素到结膜瓣移植手术等药物和手术治疗方式，并讨论了影响临床表现和预后的品种特异性易感性。理解这些不同方面对于兽医从业者有效诊断、治疗和长期管理这种可能威胁视力的疾病至关重要。

## 疾病概述与流行病学

角膜炎被定义为角膜的炎症，角膜是形成眼球外纤维层前部的透明、无血管结构[2]。在犬和猫中，角膜厚度小于1毫米，具有四个组织学层次：上皮层、基质层、后弹力膜和内皮层[2]。角膜通过屏障和泵功能保持相对脱水状态（deturgescence），通过规则的胶原板层排列以及缺乏血管、色素或瘢痕来维持光学清晰度[2]。

根据角膜上皮完整性，角膜炎可分为溃疡性和非溃疡性[2]。角膜上皮缺失构成溃疡，允许液体进入基质，形成特征性的蓝白色蜂窝状水肿外观[2]。溃疡性角膜炎根据角膜受累深度可分为浅表性、基质层和后弹力膜膨出[2]。

不同类型的角膜炎存在特定的品种易感性。短头颅品种由于面部构型常发生内侧眼睑内翻和暴露性角膜炎[6]。德国牧羊犬对慢性浅表性角膜炎（血管翳）表现出明显的易感性[7]。波士顿梗、腊肠犬和吉娃娃对角膜内皮营养不良表现出品种偏好性[7]。在猫中，疱疹病毒相关角膜炎是一个重要的病因学，需要特殊的管理方法[6]。

### Sources
[1] In vivo confocal microscopic features of naturally acquired: https://avmajournals.avma.org/view/journals/ajvr/82/11/ajvr.82.11.903.xml
[2] Understanding how the cornea heals offers insights into: https://www.dvm360.com/view/understanding-how-cornea-heals-offers-insights-treatment

## 常见病原体

伴侣动物的角膜炎涉及多种传染性和非传染性病因学。**病毒病原体**是主要原因，其中猫疱疹病毒1型（FHV-1）是猫中最显著的[2]。FHV-1影响高达80%的猫作为潜伏携带者，其中约40%经历复发性临床疾病[3]。在犬中，犬疱疹病毒1型可引起角膜炎，但不如在猫中常见[1]。

**细菌病原体**常使病毒性角膜炎复杂化或引起原发性疾病。常见分离株包括葡萄球菌、链球菌和假单胞菌属[6]。在猫中，猫衣原体也可能导致结膜炎，但通常不会引起角膜溃疡[2]。

**真菌性角膜炎**主要发生在马中，但也可影响犬和猫，特别是在免疫功能低下的患者中。曲霉属和镰刀菌属是最常分离的[6]。

**非传染性原因**同样重要。干性角膜结膜炎（KCS）由免疫介导的泪腺破坏引起[10]。异物、眼睑异常或暴露性角膜炎引起的创伤可能易继发细菌感染[6]。**免疫介导性疾病**包括犬的慢性浅表性角膜炎（血管翳）和猫的嗜酸性角膜炎[3][6]。

### Sources

[1] Experimental primary ocular canine herpesvirus-1 infection: https://avmajournals.avma.org/view/journals/ajvr/70/4/ajvr.70.4.513.xml
[2] Herpesvirus and the feline eye: https://www.dvm360.com/view/herpesvirus-and-feline-eye
[3] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[6] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[10] Disorders Involving Cell-mediated Immunity (Type IV Reactions) in Dogs: https://www.merckvetmanual.com/dog-owners/immune-disorders-of-dogs/disorders-involving-cell-mediated-immunity-type-iv-reactions-in-dogs

## 临床症状与诊断方法

伴侣动物的角膜炎表现为特征性的眼部疼痛体征，包括眼睑痉挛、流泪增加（流泪）、畏光和结膜充血[1]。受影响的眼睛通常表现出角膜变化，如混浊、血管形成和色素沉着，与正常明亮、透明的角膜表面相比，呈现暗淡、无光泽的外观[1]。

角膜荧光素染色是诊断的基础，揭示保留染料的上皮缺损[1]。在点状角膜炎中，多灶性点状角膜混浊特征性地保留荧光素染色[1]。希氏泪液测试（STT）是必需的，测量水样泪液产生，犬的正常值>15 mm/min[1]。值<10 mm/min表明临床干性角膜结膜炎，而10-14 mm之间的读数需要临床相关性分析[1]。

先进的诊断方法包括在应用荧光素之前进行的角膜细胞学检查和培养技术，以避免抑制细菌生长[2]。赖特-吉姆萨染色显示细胞碎片、上皮细胞和炎症浸润，而特殊染色如戈莫里六胺银可以识别真菌元素[2]。对于疑似传染性角膜炎，深层角膜刮片提供细胞学检查和微生物培养的样本[2]。

专业成像技术提高诊断准确性。通过CT或MRI的横断面成像比普通X射线更好地显示疾病范围，特别是对于可能涉及骨骼的慢性病例[6]。泪膜破裂时间（TFBUT）评估泪膜质量，正常值约为20秒，而立即破裂表明睑板腺炎或泪液质量缺乏[4]。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] Ophthalmology Challenge: Aggressive ulcerative keratitis in a dog: https://www.dvm360.com/view/ophthalmology-challenge-aggressive-ulcerative-keratitis-dog
[4] Management of tear film disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0
[6] Aspergillosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/fungal-infections/aspergillosis-in-animals

## 治疗选择与管理

医疗管理是犬猫角膜炎治疗的基石。局部抗生素作为大多数角膜疾病的预防性治疗，常用妥布霉素和三联抗生素制剂[4]。对于感染性基质层溃疡，积极的抗生素治疗可能需要初期每小时给药，根据培养结果选择强化氨基糖苷类或氟喹诺酮类[4]。

免疫调节疗法在特定类型的角膜炎中起着关键作用。局部环孢素（0.2-2%）和他克莫司（0.02-0.03%）有效治疗免疫介导性疾病如血管翳和干性角膜结膜炎[4]。这些药物改善泪液产生并减少角膜炎症，治疗反应通常需要2-3个月[4]。

抗病毒治疗是猫疱疹性角膜炎的必要治疗。局部抗病毒药物包括1%三氟胸苷、0.1%碘苷和0.5%西多福韦，每日两次给药[5]。泛昔洛韦（62.5-90 mg/kg口服）提供全身性抗病毒治疗，并表现出优异的安全性[5]。L-赖氨酸补充剂（250-500 mg每日两次）作为辅助治疗，在病毒复制期间与精氨酸利用竞争[5]。

手术干预对于不愈合的溃疡和深层基质层缺损是必要的。线性网格角膜切开术通过破坏异常基底膜，对惰性溃疡显示出80%的成功率[4]。完全浅表角膜切除术达到100%的成功率，但需要全身麻醉和显微外科专业知识[4]。结膜瓣为深度超过角膜50%的深层溃疡提供即时结构支撑和血液供应[4]。

疼痛管理包括局部阿托品用于散瞳和舒适，结合口服曲马多和非甾体抗炎药[4]。

### Sources
[1] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[2] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[3] Feline corneal diseases: herpesvirus and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[4] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[5] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals

## 预防措施与鉴别诊断

**预防措施**

环境管理是角膜炎预防的基石[1]。对于慢性浅表性角膜炎（血管翳），通过室内饲养或防护眼镜减少紫外线辐射暴露至关重要，特别是在疾病更具侵袭性的高海拔环境中[2]。通过适当的湿度水平和定期眼部清洁维持适当的眼部卫生和泪膜稳定性可以预防继发性角膜炎的发展。

品种特异性预防关注构型易感性。短头颅品种需要通过鼻眦成形术增强角膜保护以减少暴露性角膜炎，而易患眼睑内翻的品种需要早期手术矫正[2]。定期希氏泪液测试有助于在角膜损伤发生前检测早期干性角膜结膜炎[6]。

目前，没有针对角膜炎预防的特定疫苗接种方案，因为大多数形式是免疫介导的或继发于解剖异常，而非原发性传染病[1][2]。

**鉴别诊断**

关键鉴别诊断包括角膜溃疡，表现为荧光素摄取并常伴有疼痛，与非溃疡性角膜炎形式形成对比[3]。葡萄膜炎可模拟角膜炎，但通常表现为房水闪辉、瞳孔缩小和眼内压降低[9]。青光眼引起角膜水肿，但显示眼内压升高，与大多数角膜炎情况不同[6]。

免疫介导性疾病需要区分德国牧羊犬中表现为双侧下颞部受累的慢性浅表性角膜炎（血管翳），以及腊肠犬中表现为多灶性角膜混浊并保留荧光素的点状角膜炎[2][6]。角膜营养不良表现为双侧、对称、无血管沉积物，而变性通常是单侧并伴有相关炎症[3]。

### Sources

[1] Veterinary ophthalmology for the technician: https://www.dvm360.com/view/veterinary-ophthalmology-technician-proceedings
[2] Canine corneal diseases: https://www.dvm360.com/view/canine-corneal-diseases-secrets-transparency-greater-federal-stimulus-proceedings
[3] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[4] Ocular diseases of nontraditional and exotic pets: https://www.dvm360.com/view/ocular-diseases-nontraditional-and-exotic-pets-proceedings
[5] Complicated corneal ulcer: https://www.dvm360.com/view/complicated-corneal-ulcer-avoiding-disasters-proceedings
[6] Canine keratitis: https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[7] Feline keratitis and conjunctivitis: https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[8] Feline uveitis: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[9] Current approaches to uveitis: https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings

## 预后与并发症

犬猫角膜炎的预后因类型、深度和潜在原因而有显著差异。对于浅表性角膜炎，适当治疗的预后通常良好[1]。深层溃疡性角膜炎通过强化医疗管理显示良好结果，一项研究中的所有13只猫均达到完全缓解，中位愈合时间为21天[1]。

溃疡深度是关键的预后因素。对于超过角膜深度50%的基质层溃疡，建议手术干预，而融化性溃疡如果不积极治疗可能在12-24小时内进展至穿孔[2]。细菌病原体，特别是铜绿假单胞菌和β-溶血性链球菌，由于快速角膜破坏而显著恶化预后[2][3]。

品种易感性影响结果。患有慢性浅表性角膜炎的德国牧羊犬需要终身抗炎治疗但对治疗反应良好[3]。中老年犬，特别是拳师犬的惰性溃疡，单独清创的成功率为50%，手术角膜切开术的成功率为80%[2]。

潜在并发症包括角膜穿孔、视力丧失和慢性瘢痕形成。角膜内皮疾病通过大疱形成易导致复发性溃疡，但由于犬猫内皮细胞再生能力差而无法逆转[2]。长期管理通常需要持续的局部药物治疗，特别是对于免疫介导性疾病，频率根据临床反应调整。

### Sources

[1] Medical Management of Deep Ulcerative Keratitis: https://www.dvm360.com/view/medical-management-of-deep-ulcerative-keratitis
[2] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[3] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
