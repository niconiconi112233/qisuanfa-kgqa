# 犬猫输尿管梗阻

输尿管梗阻代表一种关键的兽医急症，需要在伴侣动物中立即识别和干预。这种从肾脏到膀胱的尿液流动的机械性或功能性阻塞，可迅速从细微的临床症状进展为危及生命的尿毒症，特别是在输尿管直径仅为0.4毫米的猫中。该病主要影响中老年猫，常导致慢性肾脏病的急性失代偿。本报告探讨了输尿管梗阻的多方面性质，涵盖其流行病学模式、草酸钙尿石作为主要病因、从轻微氮质血症到严重尿毒症危机的不同临床表现、先进的诊断影像学要求，以及从高风险手术干预到微创治疗（如输尿管支架植入和皮下旁路系统）的演变，这些治疗彻底改善了患者的预后。

## 疾病概述与流行病学

输尿管梗阻是一种机械性或功能性阻塞，阻止尿液正常通过输尿管（连接肾脏和膀胱的肌性管道）流动[1]。这种情况代表一种泌尿系统急症，可发生在输尿管路径的任何位置，从肾盂到输尿管膀胱连接处[1]。

从解剖学上讲，输尿管在三个自然狭窄点特别容易发生梗阻：肾盂输尿管连接处、输尿管跨过血管处以及输尿管进入膀胱的输尿管膀胱连接处[1]。这些狭窄通道容易受到尿石、血凝块或其他阻塞物质的阻塞[1]。

输尿管梗阻在猫中比在犬中更常见，猫由于其输尿管直径较小而特别容易受影响[1]。该病对中老年动物有明显偏好，通常影响10岁以上的猫[2]。雄性猫的发病率似乎略高，但两性均可受影响[1]。

输尿管梗阻的流行病学意义显著增加，特别是在患有并发慢性肾脏病（CKD）的猫中。任何急性尿毒症动物都应考虑输尿管梗阻的可能性，尤其是有CKD病史的猫[1]。完全性输尿管梗阻可在2至4周内导致不可逆的肾损伤，而慢性部分性梗阻则导致进行性输尿管积水和肾积水[2]。

### Sources

[1] Obstructive Uropathy in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats

[2] Urinary obstruction or functional urinary retention (Proceedings): https://www.dvm360.com/view/urinary-obstruction-or-functional-urinary-retention-proceedings

## 常见病原与病因学

犬猫输尿管梗阻不是由传染性病原体引起的，而是由机械性或功能性原因引起的。最常见的病因是输尿管结石，特别是草酸钙结石，占猫上尿路尿石的70%以上[1]。这些结石通常较小且多发，经常同时影响双肾和输尿管。

非结石性病因包括输尿管狭窄，可能由先前的创伤或炎症发展而来，以及影响三角区的新生物肿块如移行细胞癌[2][3]。血凝块或"干燥固化的血液"（阻塞性血石）也可能造成梗阻，炎性碎屑和粘液栓同样可以导致梗阻[1][3]。

医源性原因代表另一个重要类别，包括导尿管插入程序或手术干预的并发症[3][4]。导致输尿管损伤的创伤可引起狭窄形成和随后的梗阻。输尿管支架植入过程中的技术并发症也可能导致梗阻，尽管这些干预措施对于治疗良性输尿管梗阻（无论位置或原因如何）仍然有效[2]。

猫由于其输尿管腔直径仅为0.4毫米而特别容易受影响，即使是微小的结石也可能造成梗阻[1]。物种特异性差异值得注意，包括暹罗猫、波斯猫、缅甸猫和喜马拉雅猫在内的纯种猫显示肾结石风险增加[1]。该病通常影响中老年动物。

### Sources
[1] Acute ureteral obstruction (Proceedings): https://www.dvm360.com/view/acute-ureteral-obstruction-proceedings-0
[2] Technical and clinical outcomes of ureteral stenting in cats: https://avmajournals.avma.org/view/journals/javma/244/5/javma.244.5.559.xml
[3] Urinary obstruction or functional urinary retention (Proceedings): https://www.dvm360.com/view/urinary-obstruction-or-functional-urinary-retention-proceedings
[4] Urethral obstruction in cats: Catheters and complications (Proceedings): https://www.dvm360.com/view/urethral-obstruction-cats-catheters-and-complications-proceedings

Looking at the existing section content and the provided source material, I'll synthesize the information to enhance the Clinical Symptoms and Signs section for ureteral obstruction.

## 临床症状与体征

输尿管梗阻的临床表现根据梗阻的慢性程度、位置和完全性而有很大差异。**急性输尿管梗阻**通常表现为严重的腹部或背部疼痛，导致猫蹲伏、躲藏或表现出非典型的攻击性和暴躁行为[1]。这种疼痛是由输尿管快速扩张和肾包膜拉伸引起的，这些结构神经支配丰富[2]。然而，与人类相比，动物中由输尿管绞痛引起的明显疼痛较少被识别[3]。

**慢性或部分性梗阻**通常表现更为微妙。患有慢性、非梗阻性或部分梗阻性输尿管结石的犬或猫可能仅因轻度氮质血症而被评估，如果对侧肾脏功能正常，临床症状可能不明显[2]。

**双侧梗阻**或单一功能肾脏的急性单侧梗阻会产生严重的全身性症状，包括嗜睡、厌食、呕吐和尿毒症体征[1][3]。这些猫通常看起来濒死、体温过低和高钾血症，类似于晚期尿道梗阻病例[2]。患有输尿管梗阻的猫经常因严重氮质血症（中位血清肌酐>17 mg/dL）、代谢性酸中毒和高钾血症（中位血清钾6.8 mmol/L）而接受血液透析治疗[2]。

**单侧输尿管梗阻**常常未被诊断，因为未受影响肾脏的代偿性肥大防止了氮质血症的发生[1][2]。然而，当对侧肾脏患病时，会出现尿毒症的临床症状。检查时，受影响的肾脏通常可触及肿大并有压痛[1][2]。

**物种特异性模式**显示，当输尿管梗阻导致并发肾衰竭时，猫通常表现为嗜睡、呕吐和厌食[3]。许多受影响的猫（83%）表现为氮质血症，先前存在的慢性肾脏病急性失代偿是常见情况[3]。

### Sources

[1] Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats

[2] Acute ureteral obstruction (Proceedings): https://www.dvm360.com/view/acute-ureteral-obstruction-proceedings-0

[3] Managing ureteral and renal calculi in cats (Proceedings): https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings

## 诊断方法

诊断输尿管梗阻需要结合体格检查、实验室评估和先进影像技术的综合方法[1]。与尿道梗阻不同，后者通常基于病史和临床发现即可明确诊断，输尿管梗阻呈现更大的诊断挑战，因为下尿路症状常常缺失，且触诊时膀胱保持不充盈状态[1]。

体格检查可能揭示可触及的肿大且有压痛的肾脏，特别是在急性梗阻病例中[1]。实验室分析通常显示氮质血症，这种氮质血症通常严重且进行性加重，除非梗阻是最近发生的，或者在单侧病例中存在足够的对侧肾脏功能[1]。由于存在危险的高钾血症风险，所有病例都应评估血清钾浓度[1]。

**影像学对于明确诊断至关重要。**腹部超声检查作为主要的影像学方式，能有效检测肾盂和输尿管扩张[1][4]。X线平片检查提供有关肾脏大小、形状和位置的有价值信息，同时筛查不透射线的尿石和液体积聚[4][5]。X线和超声结合可以在约90%的受影响猫中检测到输尿管结石[5]。

**先进影像技术**包括计算机断层扫描和排泄性尿路造影，这些技术对于表征输尿管结石和确定个体肾脏功能特别有帮助[5]。当肾盂扩张时，顺行肾盂造影可能有用，特别是在无尿患者中，传统造影研究可能不足[6]。通过闪烁显像方法的定量评估可以确认梗阻程度并估计每个肾脏的功能贡献[5]。

任何急性尿毒症动物都应考虑输尿管梗阻的可能性，特别是有慢性肾脏病病史的猫[1]。可能需要多次超声评估来确定进行性梗阻，因为在急性发作后几天内可能不会发生扩张[5]。

### Sources

[1] Obstructive Uropathy in Dogs and Cats - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-small-animals
[2] Imaging the urinary tract: Correct use of radiography and ultrasonography (Proceedings): https://www.dvm360.com/view/imaging-urinary-tract-correct-use-radiography-and-ultrasonography-proceedings
[3] Acute ureteral obstruction (Proceedings): https://www.dvm360.com/view/acute-ureteral-obstruction-proceedings-0
[4] Ureteral Stones : Symptoms, Diagnosis, Treatment & Prevention: https://my.clevelandclinic.org/health/diseases/16514-ureteral-stones
[5] Acute uremia (Proceedings): https://www.dvm360.com/view/acute-uremia-proceedings

## 治疗选择

输尿管梗阻的治疗包括初步的医学稳定，然后在保守治疗失败时进行确定性干预。医学管理包括静脉输液治疗、利尿剂如甘露醇，以及猫的平滑肌松弛剂如哌唑嗪（0.25-0.5 mg/kg 口服 每12-24小时一次）或坦索罗辛（0.004-0.006 mg/kg 口服 每12-24小时一次）[1]。

在24-72小时内对医学管理无反应的梗阻需要手术或微创干预[1]。传统手术选择包括输尿管切开术、输尿管膀胱再植术和肾盂切开取石术，但由于猫输尿管直径极小（0.4毫米），这些手术带来相当大的风险[1][2]。即使是轻微的术后炎症也可能损害管腔，导致狭窄形成或尿液泄漏[2]。

微创替代方案已成为首选方案。输尿管支架植入为良性输尿管梗阻提供了有效治疗，无论位置或结石数量如何[1]。皮下输尿管旁路（SUB）系统为医学治疗失败的猫提供了另一种可行选择[1]。这些技术需要专业设备和专业知识，但与传统手术相比显示出改善的预后[2]。

术后护理必须解决潜在的梗阻后利尿问题，这在梗阻解除后可能发生，需要仔细监测液体和电解质[1]。物种特异性考虑包括猫输尿管手术的并发症率高于犬，这使得微创方法在猫患者中特别有价值[2]。

### Sources
[1] Obstructive Uropathy in Dogs and Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats
[2] Managing ureteral and renal calculi in cats (Proceedings): https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings

## 预防措施与鉴别诊断

### 预防措施

输尿管梗阻的预防主要集中在管理潜在的易感条件，而不是直接干预。[1] 最关键的预防策略包括预防尿石症的饮食管理，因为尿石是输尿管梗阻的常见原因。预防草酸钙的处方饮食包括减少膳食蛋白质、钙和钠，而预防鸟粪石的饮食则具有较低的蛋白质、镁和磷含量。[1] 

高水分饮食和增加饮水量被普遍推荐，以降低尿液浓度并减少结晶尿形成。[1] 常规监测方案应包括尿液分析、影像学检查和肾功能测试，特别是在患有慢性肾脏病的猫中，因为代偿性肥大可能掩盖单侧梗阻。[1] [2]

### 鉴别诊断

输尿管梗阻必须与几种引起相似临床表现的疾病进行鉴别。[1] [3] 主要鉴别诊断包括尿道梗阻，其表现为下尿路症状如尿频和排尿困难，以及触诊时充盈、疼痛的膀胱。[1] 肾盂肾炎表现出类似的氮质血症，但通过细菌尿培养阳性以及通常发热或感染的全身性体征来区分。[3]

其他需要鉴别的氮质血症原因包括慢性肾脏病、肾毒性物质引起的急性肾损伤和肾小球疾病。[2] [4] 慢性肾脏病通常表现为逐渐发作伴多尿/烦渴，而急性过程则表现为快速恶化。[2] 影像学检查，特别是超声检查，对于通过识别肾积水、输尿管积水或阻塞性病变来区分输尿管梗阻至关重要。[1]

### Sources

[1] Merck Veterinary Manual Obstructive Uropathy in Dogs and Cats - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats

[2] Merck Veterinary Manual Renal Dysfunction in Dogs and Cats - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats

[3] Acute pyelonephritis in cats is frequently caused by: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.08.0488.xml

[4] Merck Veterinary Manual Glomerular Disease in Dogs and Cats - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/glomerular-disease-in-dogs-and-cats
