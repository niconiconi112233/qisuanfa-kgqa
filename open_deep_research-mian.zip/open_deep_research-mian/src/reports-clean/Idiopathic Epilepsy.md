# 伴侣动物特发性癫痫：临床指南

特发性癫痫是影响伴侣动物的最重要神经系统疾病之一，其特征为反复发作的无诱因癫痫，且无可识别的潜在脑部病理改变。这种情况在兽医实践中构成了重大的诊断和治疗挑战，需要全面了解物种特异性表现、系统性诊断方法和基于证据的治疗方案。

本报告检查了区分犬科和猫科表现的流行病学模式，探讨了从轻微局灶性癫痫到全身性强直-阵挛性发作的临床表现，并详细介绍了准确诊断所必需的诊断排除过程。分析涵盖了当前的药物干预措施，包括一线抗惊厥药物和新兴疗法，同时讨论了影响犬猫长期预后的关键鉴别诊断和预后因素。

## 摘要

特发性癫痫在犬类和猫类群体中呈现出不同的挑战，犬类表现出强烈的品种易感性和遗传因素，影响高达5%的某些品种，而猫类则显示出较低的患病率（1%），且无明显遗传基础。诊断方法依赖于系统性排除代谢性、毒性和结构性原因，特别强调年龄特异性鉴别诊断以及正常发作间期神经系统检查的关键重要性。

治疗成功的关键在于个体化的抗惊厥方案，苯巴比妥作为基础治疗药物，在约75%的犬中作为单一疗法可实现癫痫控制。物种特异性考虑至关重要，因为溴化钾在猫中会危及生命的支气管痉挛，而新型药物如左乙拉西坦为难治性病例和肝功能受损患者提供了有价值的替代选择。

| 方面 | 犬类 | 猫类 |
|--------|------|------|
| 患病率 | 0.62-5%（因品种而异） | 高达1% |
| 遗传成分 | 强烈的品种易感性 | 无证据 |
| 发病年龄 | 6个月-6年 | 4个月-14年 |
| 一线治疗 | 苯巴比妥、溴化钾 | 仅苯巴比妥 |

通过适当的管理，长期预后仍然良好，尽管25-30%的病例会发展为需要复杂联合治疗的难治性癫痫。成功在很大程度上取决于主人的依从性、治疗药物监测以及以减少癫痫发作频率而非完全消除为目标的现实期望。未来的兽医实践应强调早期干预、系统性诊断方案和个体化治疗方法，以优化患病动物及其主人的生活质量。

## 疾病概述与流行病学

特发性癫痫是一种神经系统疾病，其特征为反复发作的无诱因癫痫，且无可识别的潜在结构性脑部病变或代谢原因[1]。它代表了一种排除性诊断，需经过全面调查以排除其他癫痫病因后才能确定。当遗传决定的神经元异常导致癫痫阈值降低，引起大脑自发性放电时，就会发生这种情况[1]。

流行病学数据显示了显著的物种差异。在犬类中，一般人群的癫痫患病率为0.62%至0.82%[2]，特发性癫痫的估计高达5%[3]。研究表明，92%患有癫痫的犬是纯种犬，表明存在强烈的遗传成分[3]。多个犬种表现出遗传易感性，包括德国牧羊犬、金毛寻回犬、拉布拉多寻回犬、比格犬和爱尔兰猎狼犬[1]。发病年龄通常在6个月至6岁之间，73%的病例在3岁前出现[1]。在某些品种中，雄性似乎更常受影响[1,3]。

在猫类中，癫痫患病率较低，占人口的1%[1]。猫特发性癫痫表现出不同特征，中位癫痫发病年龄为3.8岁（范围4个月至14岁）[4]。与犬类不同，猫中没有遗传起源的证据[5]。大多数受影响的猫是家养短毛猫，未观察到性别偏好[4]。

### Sources

[1] Primary epilepsy: what it is and isn't (Proceedings): https://www.dvm360.com/view/primary-epilepsy-what-it-and-isnt-proceedings
[2] Comparison of caregivers' assessments of clinical outcome in ...: https://avmajournals.avma.org/view/journals/javma/261/7/javma.22.10.0469.xml
[3] Canine idiopathic epilepsy: pathogenesis and clinical ...: https://www.dvm360.com/view/canine-idiopathic-epilepsy-pathogenesis-and-clinical-characteristics
[4] Journal Scan: Epilepsy of unknown cause in cats: What is it?: https://www.dvm360.com/view/journal-scan-epilepsy-unknown-cause-cats-what-it
[5] DVM 360 Journal Scan: Current understanding of feline epilepsy, diagnostic testing, and treatment: https://www.dvm360.com/view/journal-scan-current-understanding-feline-epilepsy-diagnostic-testing-and-treatment

## 临床表现与诊断方法

特发性癫痫表现为多种癫痫类型，从轻微局灶性癫痫（如摇头或寻求关注行为）到全身性强直-阵挛性癫痫[1]。犬可能表现出简单局灶性癫痫（意识保持）和复杂局灶性癫痫（意识受损），并可能出现继发性全身化[2]。典型癫痫阶段包括先兆（不安、流涎、寻求关注）、发作期（实际癫痫持续数秒至数分钟）和发作后期（定向障碍、暂时性失明持续数分钟至数小时）[3]。

在特发性癫痫中，癫痫发作之间的神经系统检查结果通常正常[2]。然而，犬可能在延长的发作后期表现出异常，这可能持续长达三到四天[5]。全面的诊断评估包括基础血液检查（CBC、生化面板、尿液分析）、甲状腺测试和胆汁酸刺激测试，以排除代谢原因[2][5]。

高级诊断涉及MRI和脑脊液分析，特别推荐用于6岁以上发病的犬、发作间期有神经系统缺陷的犬或易患自身免疫性脑膜脑炎的品种[2]。EEG和功能性MRI是正在研究中的新兴诊断工具[6]。诊断遵循排除过程，在排除结构性病变、代谢疾病和中毒后，对1-6岁且发作间期检查正常的犬确认特发性癫痫[2][5]。

### Sources
[1] Merck Veterinary Manual Anticonvulsants for Emergency Treatment of Seizures in Dogs and Cats: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-nervous-system/anticonvulsants-for-emergency-treatment-of-seizures-in-dogs-and-cats
[2] DVM 360 A veterinary neurologist's clinical approach to epilepsy: https://www.dvm360.com/view/a-veterinary-neurologist-s-clinical-approach-to-epilepsy
[3] DVM 360 Emergency management of seizures (Proceedings): https://www.dvm360.com/view/emergency-management-seizures-proceedings
[4] DVM 360 Seizures (Proceedings): https://www.dvm360.com/view/seizures-proceedings
[5] DVM 360 What's new, what's tried-and-true: An update on small animal seizure management: https://www.dvm360.com/view/what-s-new-what-s-tried-and-true-update-small-animal-seizure-management
[6] DVM 360 Ortho or neuro? A guide to deciphering gait abnormalities: https://www.dvm360.com/view/ortho-or-neuro-guide-deciphering-gait-abnormalities

## 治疗与管理

特发性癫痫的治疗集中在长期抗惊厥治疗上，以控制癫痫发作的频率和严重程度，同时最小化不良反应[1]。

**一线药物**包括犬类的苯巴比妥和溴化钾。苯巴比妥（每12小时2.5-3 mg/kg）仍然是金标准，作为单一疗法在约75%的犬中实现癫痫控制[2]。溴化钾（每日40-50 mg/kg）可作为单一疗法或与苯巴比妥联合用于难治性病例[3]。对于猫，苯巴比妥是首选的一线药物，因为溴化钾在该物种中会引起嗜酸性支气管痉挛[2]。

**第二代药物**用于难治性病例包括左乙拉西坦（每8小时20 mg/kg）和唑尼沙胺（每日两次5-10 mg/kg）[1]。左乙拉西坦在需要每日三次给药的猫以及肝病患者中特别有价值，因为其肝脏代谢最小[4]。

**治疗药物监测**对苯巴比妥和溴化钾至关重要，目标浓度分别为20-30 μg/ml和100-300 mg/dl[1]。应在两周后检查血药浓度，然后每6-12个月检查一次，避免使用可能吸收药物的老虎顶管[2]。

**紧急管理**涉及苯二氮卓类药物（地西泮0.5 mg/kg静脉注射）用于活动性癫痫，对于难治性癫痫持续状态使用丙泊酚或戊巴比妥麻醉[5]。非药物方法包括饮食调整，生酮饮食在某些犬中显示出减少癫痫发作频率的前景[6]。

### Sources
[1] Anticonvulsants: what's new and exciting?: https://www.dvm360.com/view/anticonvulsants-whats-new-and-exciting-proceedings
[2] An update on small animal seizure management: https://www.dvm360.com/view/what-s-new-what-s-tried-and-true-update-small-animal-seizure-management
[3] Treatment plans for the routine and difficult-to-control epileptic: https://www.dvm360.com/view/treatment-plans-routine-and-difficult-control-epileptic-proceedings
[4] Newer options for medically managing refractory canine epilepsy: https://www.dvm360.com/view/newer-options-medically-managing-refractory-canine-epilepsy
[5] Emergency management of seizures: https://www.dvm360.com/view/emergency-management-seizures-proceedings
[6] Anticonvulsants for Emergency Treatment of Seizures in Dogs and Cats: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-nervous-system/anticonvulsants-for-emergency-treatment-of-seizures-in-dogs-and-cats

## 鉴别诊断

将特发性癫痫与其他引起癫痫的疾病区分开来需要基于年龄、个体特征和神经系统检查结果的系统性评估。患有特发性癫痫的动物通常表现为发作间期神经系统状态正常，而结构性脑部疾病通常导致持续性神经系统缺陷[1]。

**基于年龄的鉴别方法：**在1岁以下的犬中，考虑代谢性疾病（低血糖、门体分流）、毒素、先天性异常（脑积水）和感染性原因[2]。对于1-6岁的动物，特发性癫痫最有可能，尽管结构性原因仍然可能。在5岁以上的犬中，脑肿瘤、血管疾病和代谢性疾病变得越来越重要[2]。

**关键鉴别包括：**颅外原因如肝脏疾病、低血糖、电解质紊乱和毒素暴露。颅内结构性原因包括肿瘤（原发性或转移性）、炎症性疾病（肉芽肿性脑膜脑炎）、感染因子（犬瘟热、弓形虫病）、创伤和血管意外[1][2]。

## 预后

特发性癫痫的预后在适当治疗下通常良好，尽管完全无癫痫发作并不常见。治疗目标集中在将癫痫发作频率减少到每三个月少于一次，同时最小化药物副作用[2]。

**预后因素：**患有结构性癫痫的犬比患有特发性癫痫的犬预后更差[3]。品种特异性因素影响结果，边境牧羊犬和澳大利亚牧羊犬经历更严重的癫痫。生活质量考虑包括癫痫控制和主人负担[3]。

**长期结果：**通过适当的管理，大多数癫痫犬维持正常寿命和良好的生活质量。然而，难治性病例占癫痫患者的25-30%，需要复杂的联合治疗方案。主人依从性和经济考虑显著影响长期成功[4]。

### Sources
[1] Seizures: Forming the differential diagnoses list (Proceedings): https://www.dvm360.com/view/seizures-forming-differential-diagnoses-list-proceedings
[2] Take a practical approach to the management of seizures in dogs: https://www.dvm360.com/view/take-practical-approach-management-seizures-dogs
[3] ACVIM Releases Consensus Statement on Seizure Management in Dogs: https://www.dvm360.com/view/acvim-releases-consensus-statement-on-seizure-management-in-dogs
[4] Coughs of the brain: Seizure control in dogs with idiopathic epilepsy: https://www.dvm360.com/view/coughs-brain-seizure-control-dogs-with-idiopathic-epilepsy
