# 犬猫皮下脓肿

皮下脓肿是小动物兽医实践中常见且重要的临床挑战，通过不同的流行病学模式和风险因素影响犬和猫。这些位于皮肤下方脂肪组织中的局部感染通常由咬伤、创伤或细菌污染引起，雄性猫由于领地争斗行为而表现出特别的易感性。

本综述全面检查了伴侣动物皮下脓肿的多方面性质，涵盖了由葡萄球菌和链球菌种主导的多微生物细菌病因、从疼痛性结节性肿胀到慢性引流性病变的特征性临床表现，以及包括细胞学检查和细菌培养在内的基本诊断方法。该报告详细介绍了结合手术引流和靶向抗菌治疗循证治疗方案、强调环境管理和绝育益处的预防策略，以及包括肿瘤形成和异物反应在内的关键鉴别诊断。

## 摘要

犬猫皮下脓肿是多微生物感染，需要结合手术引流、靶向抗菌治疗和预防策略的综合管理。该病症表现出明显的物种模式，雄性猫因打斗行为风险最高，而犬则发展出品种特异性易感性，如趾间毛囊炎。

主要临床发现从疼痛性结节性病变发展到慢性引流道，通过细胞学检查和细菌培养确诊。适当选择抗生素治疗成功率可达70%，但20%的病例会复发。葡萄球菌和链球菌种在细菌分离株中占主导地位，而猫通常携带多杀性巴氏杆菌。

| 方面 | 犬 | 猫 |
|--------|------|------|
| 主要风险因素 | 异物、品种易感性 | 雄性攻击行为、咬伤 |
| 常见部位 | 趾间、侧腹 | 腹股沟、腹侧腹部 |
| 治疗成功率 | 约70%治愈率 | 14天内98%改善 |
| 复发风险 | 约20%复发率 | <5%需要再治疗 |

预防措施包括绝育、室内饲养和及时伤口护理可显著降低感染风险，而适当的引流技术和培养指导的抗生素治疗可优化这种可控制但可能复发疾病的治疗结果。

## 疾病概述

皮下脓肿是皮下组织层内脓性物质的局部积聚，位于真皮和下方筋膜或肌肉之间[1]。这些炎症性病变在细菌突破皮肤屏障并在皮肤表面下方的脂肪组织中建立感染时发展。

伴侣动物中的流行病学模式显示出明显的物种和品种差异。研究表明，猫对皮下感染表现出雄性易感性，特别与咬伤或打斗引起的皮肤脓肿和引流伤口相关[2]。在犬中，特发性颈部脓肿显示出季节性趋势，在9月和10月达到高峰，表明环境或行为风险因素[3]。

风险因素包括咬伤创伤、异物穿透、免疫抑制状态和年龄相关的易感性模式。年轻的大型品种犬风险增加，每增加1公斤体重直至15公斤都与脓肿发展的几率增加相关[3]。雄性猫因领地争斗行为导致穿刺伤而特别脆弱。皮下组织与较深组织相比相对血管化不良，创造了细菌可以在减少免疫监视下增殖的环境。

### Sources
[1] Subcutaneous administration: https://en.wikipedia.org/wiki/Subcutaneous_administration
[2] Nocardiosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/nocardiosis/nocardiosis-in-animals
[3] Idiopathic cervical abscesses in dogs follow seasonal trends: https://avmajournals.avma.org/view/journals/javma/262/10/javma.24.03.0228.xml

## 常见病原体

犬猫皮下脓肿通常由涉及多种细菌种类的多微生物感染引起。葡萄球菌种，特别是假中间葡萄球菌（以前称为中间葡萄球菌），是从犬皮肤感染中分离的最常见病原体[1]。这些凝固酶阳性葡萄球菌经常产生β-内酰胺酶，导致抗菌药物耐药模式。

链球菌种是与皮下脓肿相关的另一组主要病原体[1]。在猫中，多杀性巴氏杆菌代表从脓肿中最常分离的病原体，其次是β-溶血性链球菌[2]。其他常见鉴定的细菌种类包括普雷沃菌种、犬链球菌、凝固酶阴性葡萄球菌种、中间葡萄球菌、梭杆菌种、大肠杆菌和卟啉单胞菌种[2]。

兼性和专性厌氧菌在脓肿形成中起重要作用[1]。这些包括类杆菌种，它们促成许多皮下感染的复杂多微生物性质。脓肿内的厌氧环境为这些病原体增殖创造了有利条件。

偶尔分离的其他细菌病原体包括作为继发入侵者的变形杆菌种、假单胞菌种和肠杆菌种[1]。不太常见的是，可能遇到放线菌和诺卡氏菌种，特别是与异物反应或慢性引流道相关[3]。马红球菌感染也可能引起化脓性肉芽肿性皮下脓肿，特别是在免疫抑制动物中[4]。

### Sources
[1] Clinical Exposures: A dog with a nonhealing flank wound: https://www.dvm360.com/view/clinical-exposures-dog-with-nonhealing-flank-wound
[2] Single-injection antibiotic treatment for cats with abscesses: https://www.dvm360.com/view/research-updates-single-injection-antibiotic-treatment-cats-with-abscesses-and-infected-wounds
[3] Inflammatory and Infectious Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/inflammatory-and-infectious-diseases-of-the-spinal-column-and-cord-in-animals
[4] Rhodococcus Infection in Animals: https://www.merckvetmanual.com/generalized-conditions/rhodococcus-infection/rhodococcus-infection-in-animals

## 临床症状和体征

犬猫皮下脓肿表现出特征性的局部和全身表现，从初始感染到成熟经历不同阶段。早期体征通常包括在创伤部位发展的坚实、可触及的结节性病变，逐渐进展累及区域真皮和皮下组织[1]。

**局部表现**包括疼痛性、充满脓液的肿胀，最初可能类似于典型的猫咬伤脓肿，但通过标准引流和抗生素治疗无法解决[4]。随着感染成熟，病变变得脱毛和溃疡，发展出多个小直径瘘管，伴有浆液性至浆液粘液性引流[6]。周围组织通常显示多灶性紫色病变，代表皮肤变薄区域[6]。

**全身体征**通常轻微且非特异性，包括低热、嗜睡、食欲不振、局部疼痛或瘙痒和体重减轻[6]。当全身疾病发展时，全身性体征变得更加明显，尽管传播仍然不常见[6]。患有趾间脓肿的犬通常表现出明显的跛行和过度舔舐受影响区域[4]。

**物种特异性模式**显示出显著差异。患有非典型分枝杆菌脂膜炎的猫通常表现为慢性溃疡性或结节性引流感染，最常影响腹股沟和腹侧腹部区域，因为IV组分枝杆菌对脂肪组织有偏好[6]。犬更常发展继发于咬伤、异物穿透或品种特异性易感性的脓肿，如中国沙皮犬、拉布拉多寻回犬和英国斗牛犬的趾间毛囊炎[4]。

进展通常跨越数月至数年，初始结节性病变逐渐浸润周围脂肪组织并在皮肤内形成特征性的同心扩散模式[6]。

### Sources
[1] Merck Veterinary Manual Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[4] MSD Veterinary Manual Abscesses Between the Toes (Interdigital Furunculosis) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/abscesses-between-the-toes-interdigital-furunculosis-in-dogs
[6] The clinical signs and diagnosis of feline atypical mycobacterial panniculitis: https://www.dvm360.com/view/clinical-signs-and-diagnosis-feline-atypical-mycobacterial-panniculitis

## 诊断方法

临床检查仍然是犬猫皮下脓肿诊断的基石。体格触诊通常揭示波动性、温暖、疼痛的肿胀，与周围组织界限清晰[1]。覆盖的皮肤可能显示红斑、水肿或创伤证据，如穿刺伤或咬痕。

**细针穿刺抽吸（FNA）和细胞学检查**提供快速诊断确认。抽吸材料通常包含中性粒细胞、巨噬细胞、细胞碎片和细菌生物体[1]。细胞学评估可以区分脓肿与其他软组织肿块，如血清肿、血肿或肿瘤形成。

**细菌培养和敏感性测试**应对所有抽吸材料进行，以识别致病病原体并指导抗菌治疗[1]。考虑到伴侣动物实践中抗菌药物耐药细菌的日益流行，这一点尤为重要。

**超声检查**是皮下脓肿的优秀诊断工具，特别是在临床检查不确定时[2]。超声可以确定脓肿腔的大小、深度和范围，识别隔膜或分隔，并指导治疗性引流程序。实时成像允许评估流体稠度，并有助于区分脓肿和实体肿块[2]。

**放射学检查**在皮下脓肿诊断中效用有限，除非怀疑同时存在骨髓炎或异物[3]。然而，它可能在厌氧感染情况下显示气体阴影，或帮助识别潜在诱发因素，如穿透性异物。

### Sources
[1] Subcutaneous administration - Wikipedia: https://en.wikipedia.org/wiki/Subcutaneous_administration
[2] Merck Veterinary Manual Ultrasonography in Animals - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/ultrasonography-in-animals
[3] Merck Veterinary Manual Diagnostic Imaging - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging

## 治疗选择

皮下脓肿治疗需要结合手术引流、抗菌治疗和支持性护理的多模式方法。手术引流是治疗的基石，通常使用标准切开引流技术或在存在广泛污染时放置闭合式负压引流管[1]。引流部位应使用温热等渗盐水彻底冲洗，以去除碎屑和细菌污染。

抗生素选择应尽可能由培养和敏感性测试指导。对于经验性治疗，一线抗菌药物包括头孢氨苄（20-30 mg/kg 口服 每12小时一次）、阿莫西林-克拉维酸（13.75 mg/kg 口服 每12小时一次）或克林霉素（犬10-20 mg/kg 口服 每12小时一次；猫12.5-25 mg/kg 口服 每12小时一次）[1]。治疗持续时间通常为21-42天，持续至临床缓解后5-7天。

引流管选择取决于伤口特征。像Penrose引流管这样的被动引流管利用重力和毛细作用进行引流，需要重力依赖性放置[3]。主动引流利用负压将液体抽入收集储器，与被动系统相比降低细菌迁移风险[3]。引流管应保留至液体量减少且呈非脓性，细胞学评估指导移除时机[3]。

使用芬太尼、羟吗啡酮或氢吗啡酮等阿片类药物进行疼痛管理对动物舒适至关重要[2]。伤口护理包括每日监测、使用引流系统时适当包扎，以及保持手术部位周围清洁[2]。并发症可能包括需要修正手术的治疗失败或抗生素耐药性发展，特别是耐甲氧西林葡萄球菌[1]。

### Sources

[1] Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[2] Management of dogs and cats with septic peritonitis: https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[3] Drains in Wound Management of Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/drains-in-wound-management-of-small-animals

## 预防措施

预防皮下脓肿需要关注环境管理和行为改变的多方面方法。室内饲养显著减少咬伤暴露，这是皮下脓肿形成最常见的诱发因素[1]。对于确实外出的猫，监督进入或封闭的室外区域可最小化与其他动物的攻击性遭遇。

绝育通过减少游荡行为和领地攻击性提供实质性益处，特别是在雄性猫中，从而减少咬伤事件[1]。这种手术干预还减少激素对雄性间攻击性的影响，这通常在繁殖季节发生并导致打斗伤害。

适当的伤口管理对于预防感染进展至脓肿形成至关重要[2]。立即用适当溶液清洁任何咬伤或穿刺伤，并及时进行兽医评估可防止细菌定植和随后的脓肿发展。

虽然针对引起脓肿病原体的特定疫苗接种方案有限，但保持FIV、FeLV和狂犬病的最新疫苗接种很重要，因为这些病毒可通过可能同时引入形成脓肿细菌的咬伤传播[3]。此外，通过适当卫生设施和避免拥挤的住房条件，防止暴露于被耐药细菌污染的环境有助于降低感染风险。

减少宠物之间压力和攻击性互动的环境丰富和行为管理策略可显著减少咬伤发生和随后的脓肿形成。

### Sources

[1] Preventing and managing spay/neuter complications ...: https://www.dvm360.com/view/preventing-and-managing-spayneuter-complications-proceedings
[2] Wound Bandages and Dressings for Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/wound-bandages-and-dressings-for-small-animals
[3] Building your exotic animal caseload (Proceedings): https://www.dvm360.com/view/building-your-exotic-animal-caseload-proceedings

## 鉴别诊断

几种情况可能模拟皮下脓肿，需要通过临床检查和诊断测试仔细区分。肿瘤性疾病，特别是软组织肉瘤和肥大细胞瘤，可能表现为类似脓肿的波动性肿块[1]。细针穿刺抽吸细胞学检查对于区分炎症细胞和肿瘤细胞群至关重要，脓肿显示主要是中性粒细胞和细菌，而肿瘤显示均匀细胞群[1]。

异物肉芽肿代表常见的鉴别诊断，特别是当存在慢性引流道时[2]。这些病变在细胞学检查中通常含有多核巨细胞和异物，与细菌脓肿中看到的化脓性炎症形成对比[1]。超声检查可以有效识别异物为周围低回声组织内的高回声线性结构[2]。

血清肿和血肿在临床上可能相似，但含有清澈至浆液血性液体，细胞学检查无炎症细胞或细菌[1]。真菌肉芽肿，包括暗色丝孢霉病，可表现为类似脓肿的病变，但在细针穿刺抽吸中显示特征性色素生物体[3]。

关键区分特征包括细胞学发现（炎症性与肿瘤性细胞）、对抗菌治疗的反应、慢性程度以及必要时的高级影像学发现[1][2]。

### Sources
[1] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[2] Clinical Exposures: A dog with a nonhealing flank wound: https://www.dvm360.com/view/clinical-exposures-dog-with-nonhealing-flank-wound
[3] Diagnosing unusual fungal diseases: Phaeohyphomycosis: https://www.dvm360.com/view/diagnosing-unusual-fungal-diseases-phaeohyphomycosis

## 预后

犬猫皮下脓肿的预后因多种因素而有显著差异。通过适当的抗生素治疗，预期临床治愈率约为70%[1]。然而，复发代表一个相当大的问题，大约20%的接受治疗的犬在初始治疗后数月或数年经历复发[1]。

**治疗反应和愈合**
大多数患有皮下脓肿的猫表现出良好的治疗结果。研究表明，98%接受头孢维星治疗的猫在14天内达到缓解或显著改善，而接受口服头孢氨苄的为95%[1]。大多数猫（95%）只需要一个疗程的抗生素治疗[1]。

**治疗持续时间和成功因素**
治疗持续时间随感染严重程度而变化。一般来说，浅表感染应在表面愈合后治疗7天（通常3-4周），而如果持续改善，深部感染可能需要治疗8-12周[5]。耐甲氧西林葡萄球菌感染的临床缓解可能比甲氧西林敏感性感染需要更长时间，主要是由于感染慢性而非细菌毒力[5]。

**影响恢复的因素**
对于仅涉及局部皮肤的病例预后最有利。然而，异物的存在显著影响结果，如需要手术探查和延长治疗期的病例所示[4]。完全去除异物和适当引流显著改善愈合前景。治疗应持续至临床病变消退且细胞学评估显示正常结果[5]。

**并发症和长期管理**
虽然罕见，但可能发生严重并发症，特别是当脓肿与较深感染或全身受累相关时。可能发生继发性细菌感染，需要额外的治疗干预[3]。大多数经历复发的动物对使用相同抗生素方案的再治疗反应良好。

### Sources
[1] Single-injection antibiotic treatment for cats with abscesses: https://www.dvm360.com/view/research-updates-single-injection-antibiotic-treatment-cats-with-abscesses-and-infected-wounds
[3] Treatment of canine sepsis: First identify, eradicate the cause: https://www.dvm360.com/view/treatment-canine-sepsis-first-identify-eradicate-the-cause
[4] Clinical Exposures: A dog with a nonhealing flank wound: https://www.dvm360.com/view/clinical-exposures-dog-with-nonhealing-flank-wound
[5] Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
