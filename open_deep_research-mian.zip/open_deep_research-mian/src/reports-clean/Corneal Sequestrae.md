# 猫角膜腐片

角膜腐片是一种独特且具有临床重要性的眼部疾病，仅影响猫类，其特征是在角膜基质内形成独特的棕色至黑色坏死区域。由于病因复杂、品种易感性以及可能导致角膜穿孔等严重并发症，该病对兽医从业者构成诊断和治疗挑战。

本综合报告探讨了角膜腐片的多因素性质，阐述了猫疱疹病毒1型作为主要病原体的关键作用，同时涉及其他促成因素。分析涵盖了使该病在猫科患者中具有特征性的临床表现、结合临床观察和先进检测方法的诊断方法，以及从药物治疗到手术干预的循证治疗策略。特别关注了波斯猫、喜马拉雅猫和暹罗猫的品种特异性易感性、治疗后的复发模式以及影响临床结果的长期预后因素。

## 摘要

角膜腐片是一种独特的猫科特异性疾病，需要全面了解其病毒病因、临床表现和治疗复杂性。该病主要由猫疱疹病毒1型感染引起，在33%的病例中检测到该病毒，波斯猫、喜马拉雅猫和暹罗猫表现出显著的易感性。特征性的棕黑色中央角膜混浊提供了直接诊断依据，将其与眼球表面黑色素瘤等罕见鉴别诊断区分开来。

| 治疗方法 | 适应症 | 结果 | 复发风险 |
|-------------------|-------------|----------|-----------------|
| 药物治疗 | 舒适的猫，炎症轻微 | 自然脱落需数月 | 不定，有穿孔风险 |
| 浅层角膜切除术 | 标准手术方法 | 结果良好 | 可能2周内复发 |
| 结膜瓣移植术 | 深层腐片，需要结构支撑 | 可能降低复发率 | 报告复发率较低 |

治疗成功取决于腐片深度和选择的干预措施。虽然手术角膜切除术能提供快速解决，但无论采用何种技术，复发仍是一个重大问题。使用抗病毒药物和支持性护理的药物治疗提供保守选择，但存在穿孔风险。总体预后从谨慎到良好不等，向主人告知可能的复发至关重要。长期管理应强调同时进行抗病毒治疗、减轻压力和定期监测，以优化这种具有挑战性的猫科眼部疾病的治疗结果。

## 疾病概述与流行病学

角膜腐片是一种独特的角膜疾病，其特征是角膜内形成棕色至黑色变色的坏死组织区域[1]。这种情况仅发生在猫身上，代表一种病理过程，其中部分角膜基质变黑并坏死，形成所谓的"腐片"[2]。

腐片表现为琥珀色、棕色或黑色变色区域，其深度和大小差异很大[1]。近期的超微结构研究表明，这种暗色物质与黑色素颗粒一致[3]。这种坏死组织由死亡的结缔组织、血管组成，并被炎症包围[2]。受影响区域通常在角膜中央或附近发展，最终可能从角膜表面隆起并突出[2]。

角膜腐片表现出明显的品种易感性，虽然所有猫科品种都可能发生，但在波斯猫、喜马拉雅猫和暹罗猫中患病率增加[2][3][4]。该病影响各种年龄的猫，但波斯猫、喜马拉雅猫和重点色猫表现出特别的易感性[5]。这种疾病引起明显的疼痛和周围角膜炎症，影响猫的眼部健康和舒适度[2]。

### Sources
[1] Image Quiz: Can you name these ophthalmic conditions?: https://www.dvm360.com/view/image-quiz-can-you-name-these-ophthalmic-conditions
[2] Disorders of the Cornea in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-cornea-in-cats
[3] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[4] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[5] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings

## 常见病原体

角膜腐片主要是一种由多因素病因引起的非传染性疾病。然而，猫疱疹病毒1型(FHV-1)是与腐片发展相关的最重要病原体[1]。通过PCR分析，约33%的腐片样本中检测到该病毒，表明在许多病例中存在直接的病毒参与[5]。

FHV-1通过直接的细胞病变作用引起初始角膜上皮损伤，导致树突状和地理性溃疡，这些溃疡易导致腐片形成[1]。大多数猫角膜溃疡由FHV-1感染引起，因此在腐片病例中病毒参与的可能性很高[5]。研究表明，在实验环境中，FHV-1实验接种后给予局部皮质类固醇治疗可诱导腐片形成[1]。

其他病原体偶尔也会促成腐片发展。在33%的腐片样本中检测到弓形虫，但其意义尚不清楚[5]。继发性细菌感染可能使现有腐片复杂化，但不被认为是主要致病因子[5]。

非传染性因素在发病机制中起重要作用。由眼睑内翻、兔眼和泪膜异常引起的慢性摩擦性刺激创造了易感条件[1][2]。环境应激源和免疫抑制治疗可触发FHV-1复发，启动导致腐片形成的级联反应[5]。

### Sources
[1] Feline keratitis and conjunctivitis (Proceedings): https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[2] Disorders of the Cornea in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-cornea-in-cats
[3] Eye Disorders Resulting from Generalized Diseases in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/eye-disorders-resulting-from-generalized-diseases-in-cats
[4] The Cornea in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[5] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings

## 临床表现与诊断

### 临床症状与体征

角膜腐片表现为中央或旁中央角膜的特征性棕黑色混浊[1]。腐片呈现为从浅琥珀色到黑色的变色斑块，由坏死基质组成，周围有角膜血管化和炎症[1][2]。最初，在完整上皮下的前基质内可能发展出小暗区，该区域可被玫瑰红染色，偶尔可被荧光素轻微染色[3]。随着病情进展，基质斑点变得更大更暗，最终失去上皮覆盖[3]。

临床症状包括不同程度的眼睛疼痛、角膜溃疡、血管化和眼部分泌物[5]。多个浅层角膜血管通常环绕腐片[2]。该病引起周围角膜组织的疼痛和炎症[1]。

### 品种特异性模式

虽然角膜腐片在所有猫品种中都会发生，但波斯猫、喜马拉雅猫和暹罗猫表现出显著更高的易感性[1][3][5]。重点色品种风险也增加[6]。这种情况仅发生在猫身上，在其他物种中尚未有记录[1][5]。

### 诊断方法

诊断主要基于特征性的临床表现，由于猫的角膜色素沉着罕见，这被认为是特征性的[5]。当上皮受损时，荧光素染色可显示角膜溃疡[5]。玫瑰红染色在检测早期病变方面可能比荧光素更有效[5]。

角膜细胞学和组织病理学可确认诊断。组织学上，腐片显示变性胶原、溃疡和不同程度的炎症[5]。近期研究表明，暗色物质由黑色素颗粒组成[5]。

### 鉴别诊断

主要鉴别诊断是眼球表面黑色素瘤，它发生在周边角膜缘而非中央[5]。其他引起混浊的角膜疾病包括猫疱疹病毒性角膜炎、嗜酸性角膜炎和真菌感染，但这些极为罕见[5]。中央位置和特征性的黑色外观通常可将腐片与其他角膜病理区分开来[6]。

### Sources

[1] Merck Veterinary Manual Disorders of the Cornea in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-cornea-in-cats
[2] Merck Veterinary Manual Image Corneal sequestrum, domestic cat: https://www.merckvetmanual.com/multimedia/image/corneal-sequestrum-domestic-cat
[3] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[4] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/243/12/javma.243.12.1751.xml
[5] DVM 360 Feline corneal diseases: https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[6] DVM 360 Corneal disease: https://www.dvm360.com/view/corneal-disease-proceedings

## 治疗选择

角膜腐片的治疗涉及药物和手术方法，手术通常提供最快速的解决方案[1]。药物治疗包括局部抗病毒药物（如碘苷）以治疗潜在的猫疱疹病毒、广谱抗生素预防感染，以及含有透明质酸盐或卡波姆的厚眼用润滑剂[2][7]。局部干扰素在某些情况下可能有助于减少角膜变色[7]。单独药物治疗适用于舒适且炎症轻微的猫，尽管始终存在角膜穿孔的风险，且自然腐片脱落可能需要数月时间[1][2]。

手术干预是首选治疗方法，特别是对于药物治疗无法缓解疼痛的病例[1][7]。浅层角膜切除术是主要的手术选择，涉及在显微镜引导下仔细切除坏死组织[9]。对于深层腐片，可能需要结膜瓣移植或角膜结膜转位瓣来提供结构支撑和血液供应[2][7]。与单独角膜切除术相比，角膜结膜转位技术可能降低复发率[2]。

术后护理包括继续抗病毒治疗、局部抗生素和必要时使用全身镇痛药进行疼痛管理[7]。伊丽莎白圈可防止愈合期间自伤。应告知客户，腐片可能在手术切除后复发，因此长期监测至关重要[2][7]。

### Sources
[1] The dos and don'ts of treating ocular disease in cats (Proceedings): https://www.dvm360.com/view/dos-and-donts-treating-ocular-disease-cats-proceedings
[2] Feline corneal diseases: Herpes and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[7] Feline corneal diseases: herpesvirus and more (Proceedings): https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[9] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings

## 预后与长期管理

角膜腐片猫的预后因几个关键因素而有显著差异[1,2]。经历自发脱落的浅层腐片通常预后最良好[1]。然而，一些腐片可能在数月内自然脱落，而其他腐片可能向角膜深处迁移，在少数情况下可能导致眼球破裂[1]。

手术干预通常提供良好结果，但复发是一个值得注意的问题。文献表明角膜腐片可能在手术切除后复发，一些作者报告腐片可能在单独角膜切除术后两周内复发[1]。研究表明，接受移植手术的患者与仅接受角膜切除术的患者之间复发率没有差异[1]。然而，一些眼科医生认为移植手术可能降低腐片复发率[2]。

由于已从腐片中分离出猫疱疹病毒(FHV)，建议在角膜和结膜愈合前同时进行抗病毒治疗[7]。治疗FHV感染也可能有助于预防易感猫的复发。L-赖氨酸补充和减轻压力可能额外支持长期管理[2]。

适当治疗下总体预后保持谨慎到良好，但无论初始位置和选择的治疗方法如何，都应告知主人可能的复发[1]。单独药物治疗存在包括角膜穿孔在内的风险[8]。

### Sources

[1] Feline corneal diseases: herpesvirus and more: https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[2] Feline corneal diseases: Herpes and more: https://www.dvm360.com/view/feline-corneal-diseases-herpes-and-more-proceedings
[7] Feline keratitis and conjunctivitis: https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[8] The dos and don'ts of treating ocular disease in cats: https://www.dvm360.com/view/dos-and-donts-treating-ocular-disease-cats-proceedings
