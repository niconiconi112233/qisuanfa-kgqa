# 伴侣动物尿酸盐尿石症

尿酸盐尿石症是犬类第三常见的尿路结石类型，影响约8%的犬科患者。由于其X线可透性及复杂的潜在病理生理学，该病症提出了独特的诊断和治疗挑战。与其他结石类型不同，尿酸盐结石源于遗传性代谢缺陷（特别是携带SLC2A9基因突变的大麦町犬）或由门体分流引起的获得性肝功能障碍。本报告探讨了品种特异性易感性、需要特殊技术的诊断影像学局限性、利用低嘌呤饮食和别嘌呤醇治疗的药物溶解方案，以及综合预防策略。理解这些机制对于兽医从业者管理这种需要终身饮食管理和监测的复发性疾病至关重要。

## 疾病概述与流行病学

尿酸盐尿石症是指在伴侣动物尿路中形成主要由尿酸铵组成的尿路结石 [1]。它是犬类第三常见的结石类型，约占所有犬类尿路结石的8% [1]。

**品种易感性与流行病学**

存在明显的品种易感性，大麦町犬是受影响的典型品种，因其尿酸转运存在先天性代谢缺陷 [1][2]。在大麦町犬、英国斗牛犬和黑俄罗斯梗犬中已鉴定出编码尿酸转运蛋白的SLC2A9基因突变 [1][10]。雄性大麦町犬比雌性更常受影响，大多数病例发生在1-4岁之间，6岁后发病率下降 [2]。

**病因学分类**

犬类尿酸盐尿石症存在两种主要病因 [1]。首先，先天性代谢错误导致高尿酸尿症，主要发生在大麦町犬中，其肝脏将尿酸转化为可溶性尿囊素的能力下降，导致尿酸排泄过多 [1]。其次，先天性门脉血管异常导致尿铵排出增加，特别影响3岁以下的迷你雪纳瑞、约克夏梗和西施犬 [2]。与品种相关病例不同，门脉血管相关的尿路结石无明显性别倾向 [2]。

### Sources

[1] Urolithiasis in Dogs - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs

[2] Canine uroliths (Proceedings): https://www.dvm360.com/view/canine-uroliths-proceedings

[10] Validation of a urine test and characterization of the putative genetic mutation for hyperuricosuria in Bulldogs and Black Russian Terriers: https://avmajournals.avma.org/view/journals/ajvr/71/8/ajvr.71.8.909.xml

## 病理生理学与常见病因

犬和猫的尿酸盐尿石症涉及影响嘌呤代谢和尿排泄的复杂代谢紊乱。理解这些潜在机制对于正确诊断和治疗至关重要。

**正常尿酸代谢与基因突变**

在健康犬中，来自嘌呤代谢的尿酸在肝脏中转化为尿囊素，后者高度可溶且易于排泄 [1]。然而，某些品种，特别是大麦町犬，转化能力受损，将大部分核酸代谢产物以相对不溶的尿酸盐形式排出 [2]。编码尿酸转运蛋白的SLC2A9基因突变导致受影响犬出现高尿酸尿症和高尿酸血症 [1][5]。这种基因缺陷已在大麦町犬、英国斗牛犬和黑俄罗斯梗犬中被鉴定 [2]。

**门体分流**

门脉血管异常是尿酸盐结石形成的另一主要原因 [3][4]。患有门体分流的犬因滤过的氨负荷增加而导致尿铵排出增加 [2]。这些血管畸形阻碍了肝脏对嘌呤的正常代谢，创造了有利于尿酸盐结晶的条件 [3][4]。肝脏中的尿酸酶通常将尿酸转化为水溶性尿囊素，但门体分流绕过了这一肝功能 [3][4]。

**临床意义**

当在无高尿酸尿症易感性的品种中发现尿酸盐结石时，应进行门体分流检查 [2]。遗传易感性与肝功能障碍共同创造了一个环境，使相对不溶的尿酸盐化合物沉淀并形成结石。

### Sources
[1] Diagnosis and treatment of urolithiasis in client-owned ...: https://avmajournals.avma.org/view/journals/javma/247/6/javma.247.6.650.xml
[2] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[3] Portosystemic shunt in dogs and cats (Proceedings): https://www.dvm360.com/view/portosystemic-shunt-dogs-and-cats-proceedings
[4] Portosystemic shunt in dog and cat (Proceedings): https://www.dvm360.com/view/portosystemic-shunt-dog-and-cat-proceedings
[5] Urolithiasis and the impact of nutritional management: https://www.dvm360.com/view/urolithiasis-and-the-impact-of-nutritional-management

## 临床表现与诊断

尿酸盐结石通常表现为典型的下尿路症状，包括排尿困难、血尿和尿频 [1][2]。患有尿道梗阻的雄性犬可能表现出排尿尝试失败、包皮滴血、嗜睡、厌食和呕吐 [1]。

**尿液分析结果**

尿液分析显示尿液pH值呈酸性（通常6.0-8.0），因为尿酸盐结石在酸性条件下更易形成 [2][3]。尿沉渣中可能观察到尿酸盐结晶，但可能与无定形尿酸盐或尿酸结晶难以区分 [3]。在某些受影响的猫中，尿液可能呈芥末黄色 [3]。无并发细菌感染的猫常见血尿 [3]。

**影像学挑战**

尿酸盐结石在普通X光片上具有X线可透性，给诊断带来显著挑战 [1][2]。这些结石的放射密度与软组织相似，通常无法通过标准X线摄影可靠检测，除非其直径至少为3mm [2]。双重对比膀胱造影比普通X线摄影更敏感，假阴性率仅为4.5%，而普通X线摄影为13% [2]。

**先进诊断方法**

超声检查对X线不透和X线可透的尿路结石均有极好的检测能力，假阴性率仅为3.5% [2]。对于确诊，定量尿路结石分析至关重要，因为使用标准偏振光显微镜无法区分黄嘌呤结晶与其他嘌呤代谢产物 [3]。

### Sources
[1] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[2] Managing urolithiasis (Proceedings): https://www.dvm360.com/view/managing-urolithiasis-proceedings-0
[3] How would you manage feline xanthine urocystoliths?: https://www.dvm360.com/view/how-would-you-manage-feline-xanthine-urocystoliths

## 治疗策略

尿酸盐尿石症的管理需要多模式方法，根据结石位置和患者稳定性结合药物溶解、手术干预和紧急治疗方案 [1]。

**药物溶解方案**
饮食干预是治疗的基石，采用低嘌呤、碱化蛋白质限制饮食，如希尔斯处方粮u/d [1]。尿液碱化至pH>7可增加尿酸盐溶解度并促进溶解 [2]。可添加别嘌呤醇（15 mg/kg 口服 每12小时一次）作为黄嘌呤氧化酶抑制剂，但需严格遵循低嘌呤饮食以防止黄嘌呤结石形成 [1,2]。约50%的大麦町犬在一个月内可实现完全溶解 [2]。

**微创移除技术**
排尿性尿液压推进术通过用无菌盐水扩张膀胱并用力挤压，有效移除小尿酸盐结石（犬>10kg者<5mm，小型雄性犬1-3mm）[7]。激光碎石术和膀胱镜取石术在拥有专业设备时为较大结石提供了替代方案 [7]。这些技术在保持疗效的同时最小化手术创伤。

**手术选择**
膀胱切开术仍是不适合溶解或微创移除的结石的金标准 [2]。手术干预应包括术后完整的X线评估以确保无残留碎片 [7]。对于复发性病例，可考虑阴囊尿道造口术，但需去势且存在较高感染风险 [8]。

**紧急管理**
尿道梗阻需要立即稳定治疗，包括静脉晶体液、疼痛管理，以及当钾>7.5 mEq/dL时使用葡萄糖酸钙纠正高钾血症 [6]。使用直肠尿道压迫的"捏压-冲洗"技术进行逆行冲洗可有效缓解大多数梗阻，将紧急尿道切开术转为择期膀胱切开术 [9]。

### Sources

[1] DVM360: Nutritional and medical management of canine urolithiasis: https://www.dvm360.com/view/nutritional-and-medical-management-canine-urolithiasis-part-2-proceedings

[2] Merck Veterinary Manual: Urolithiasis in Dogs: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs

[3] DVM360: Crystals, stones, and diets: https://www.dvm360.com/view/crystals-stones-and-diets-proceedings

[4] Merck Veterinary Manual: Overview of Urolithiasis in Small Animals: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/overview-of-urolithiasis-in-small-animals

[5] Merck Veterinary Manual: Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats

[6] DVM360: Surgery STAT: Pinch and flush: https://www.dvm360.com/view/surgery-stat-pinch-and-flush-relieving-urethral-obstructions-male-dogs

## 预防与长期管理

尿酸盐尿石症的预防侧重于全面的饮食管理和监测策略。预防的基石包括喂养低嘌呤饮食，利用蛋清或素食蛋白质来源，同时保持足够的蛋白质水平 [1][5]。对于犬，推荐几种治疗性饮食，包括皇家兽用粮Urinary UC、希尔斯处方粮d/d鸡蛋大米和普瑞纳兽用粮Hypoallergenic HA [2]。

优化水摄入对所有患者至关重要 [5]。目标尿液比重在犬中应低于1.020，在猫中应低于1.030，以保持足够的稀释度 [1][5]。这可通过喂食湿粮、在干粮中加水以及提供饮水机来实现 [1]。

尿液碱化可能有益，因为尿酸盐结晶在酸性尿液中更易沉淀 [1][2]。对于患有尿酸盐结石的猫，建议保持中性至碱性尿液pH值 [5]。补充柠檬酸钾有助于实现碱性pH值，同时作为钙螯合剂 [1]。

对于有遗传易感性的犬，特别是携带SLC2A9转运蛋白突变的大麦町犬和英国斗牛犬，基因筛查可识别高风险个体 [4]。通过每3-6个月进行一次X线检查进行定期监测，可在结石足够小时通过排尿性尿液压推进术进行微创移除的早期检测 [4]。

长期药物治疗可能包括低剂量别嘌呤醇（5-7 mg/kg 每12-24小时一次），当单独饮食管理不足时使用，但必须严格遵循低嘌呤饮食以防止黄嘌呤结石形成 [4]。

### Sources
[1] Nutritional management of urolithiasis in dogs and cats: https://www.dvm360.com/view/nutritional-management-of-urolithiasis-in-dogs-and-cats
[2] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings
[3] Nephrolithiasis and ureterolithiasis in the canine and feline: https://www.dvm360.com/view/nephrolithiasis-and-ureterolithiasis-canine-and-feline-medical-and-surgical-patient-proceedings
[4] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[5] Urinalysis - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/urinalysis

## 鉴别诊断与预后

**尿酸盐与其他尿路结石的鉴别**

尿酸盐结石必须与犬猫中最常见的鸟粪石和草酸钙结石区分开 [1]。**草酸钙和鸟粪石是犬类最常见的结石类型** [1]，而**猫中最常见的尿路结石类型是草酸钙、磷酸铵镁和尿酸盐** [3]。

关键鉴别特征包括影像学表现 - 尿酸盐结石通常X线可透，需要造影检查或超声检查才能检测，而鸟粪石和草酸钙结石X线不透 [2]。品种易感性有助于鉴别：大麦町犬因编码尿酸转运蛋白的SLC2A9基因突变而遗传易感尿酸盐结石 [1]。

**并发疾病**

当在无高尿酸尿症易感性的品种中发现尿酸盐结石时，应进行门体分流检查，包括血清胆汁酸检测 [1]。**患有尿酸盐结石的犬需考虑的两个主要病因是先天性高尿酸尿症和先天性门脉血管异常** [1]。

**预后与预期结果**

**尿酸盐结石在高尿酸尿症犬中高度复发** [1]。通过适当管理，包括低嘌呤饮食和必要时使用别嘌呤醇，**据报道尿酸盐结石在大麦町犬中约有一半时间可完全溶解，大约在1个月内发生** [1]。患有门脉血管异常的犬需要尽可能手术矫正以获得最佳长期预后。

### Sources
[1] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[2] Stones vs. crystals: Management and prevention (Proceedings): https://www.dvm360.com/view/stones-vs-crystals-management-and-prevention-proceedings
[3] Urolithiasis in Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-cats
