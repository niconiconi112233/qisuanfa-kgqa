# 犬疥螨病：综合兽医指南

犬疥螨病是由寄生虫性螨虫犬疥螨（Sarcoptes scabiei var. canis）引起的一种疾病，是小动物兽医临床中最具挑战性和传染性的皮肤病之一。这种高度瘙痒的疾病会影响所有年龄和品种的犬，由于螨虫检测的困难性，常常带来诊断难题。该病的人畜共患潜力和在动物间的快速传播，使其成为兽医专业人士、宠物主人和公共卫生的重要关注点。本报告全面探讨了犬疥螨病的临床谱系，从其特征性的剧烈瘙痒和分布模式，到现代诊断方法和治疗方案，为有效管理和预防策略提供了基本指导。

## 摘要

犬疥螨病是一种高度可控但具有挑战性的寄生虫性疾病，需要及时识别和综合治疗。该疾病的标志是剧烈瘙痒、特征性分布影响耳缘和受压部位以及高传染率，需要立即干预。现代诊断方法结合临床评估、耳廓-足底反射和皮肤刮片检查，同时认识到30-70%的假阴性率，以指导治疗决策。治疗成功依赖于全身性杀螨剂如塞拉菌素，当遵循适当方案时预后极佳。

| 方面 | 关键特征 |
|------|----------|
| **病原体** | 犬疥螨，17-21天生命周期 |
| **临床症状** | 剧烈、皮质类固醇抵抗性瘙痒，丘疹结痂性皮疹 |
| **诊断挑战** | 30-70%刮片假阴性，治疗性试验常具确诊意义 |
| **治疗成功率** | 使用塞拉菌素/大环内酯类药物效果极佳，2-4周内改善 |
| **预防** | 同时治疗接触动物，环境消毒 |

成功管理需要同时治疗所有接触动物，实施严格的环境消毒方案，并警惕具有挑战性的"隐匿性疥螨"表现。适当治疗的良好预后强调了兽医实践中早期识别和综合治疗方法的重要性。

## 疾病概述

犬疥螨病，又称疥癣，是由寄生虫性螨虫犬疥螨（Sarcoptes scabiei var. canis）引起的一种高度传染性皮肤病[1]。这种 microscopic 外寄生虫钻入皮肤的角质层，雌螨在其中挖掘隧道产卵[1]。完整的生命周期在宿主上完成，大约需要17-21天[1]。

该病在全球范围内分布，影响所有品种和年龄的犬，但在幼犬、老年犬和免疫功能低下的个体中更为常见[1,3]。犬疥螨病通过直接接触在犬之间轻易传播，也可通过被污染的寝具、刷子和其他污染物间接传播[1]。

虽然该螨虫对犬具有宿主特异性，但它具有人畜共患性，可以暂时感染与感染犬接触的人类和其他动物[1]。潜伏期从10天到8周不等，取决于包括感染严重程度、解剖位置、螨虫负荷以及个体犬的免疫状态和卫生状况等因素[1]。

### Sources
[1] Mite Infestation (Mange, Acariasis, Scabies) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs
[2] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[3] Differential diagnoses for the itchy and scratchy (Proceedings): https://www.dvm360.com/view/differential-diagnoses-itchy-and-scratchy-proceedings

## 常见病原体

犬疥螨病由犬疥螨（Sarcoptes scabiei var. canis）引起，这是一种高度传染性的蛛形纲寄生虫[1]。成年螨虫微小，体长0.2-0.6毫米，呈大致圆形形态，覆盖着小的三角形刺[2]。雌螨明显大于雄螨，拥有四对短腿[2]。

该螨虫对犬科动物成员表现出严格的宿主特异性，包括犬、狐狸、狼和郊狼，但可发生跨物种传播至猫和人类[3]。犬疥螨在宿主犬身上完成其整个17-21天的生命周期[2]。雌螨在角质层深处挖掘隧道，在穿过皮肤时在身后产卵[3]。

环境生存特性取决于温度和湿度。在室温下，所有生命阶段可在宿主体外存活2-6天[3]。在低温和高湿度的最佳条件下，雌螨表现出延长的环境持久性，可在宿主体外存活4-21天[3]。这种有限但重要的环境生存能力有助于通过被污染的寝具、美容设备和环境表面进行间接传播[2]。

### Sources

[1] MSD Veterinary Manual Mite Infestation (Mange, Acariasis, Scabies) in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs

[2] MSD Veterinary Manual Mange in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats

[3] DVM 360 If you think it's scabies, treat it: https://www.dvm360.com/view/if-you-think-its-scabies-treat-it

## 临床症状和体征

犬疥螨病以剧烈瘙痒为其标志性特征[1,2]。瘙痒通常是持续且严重的，常常使犬和主人都无法入睡[1]。这种瘙痒通常对止痒药甚至免疫抑制剂量的皮质类固醇无反应[3]。

原发性病变开始为小的丘疹结痂性皮疹，伴有红斑和脱毛[1]。这些迅速发展为厚实的黄色结痂，并因自伤性创伤而出现广泛抓痕[1,5]。继发性和酵母菌感染常见于受损皮肤区域[1]。

分布模式具有特征性，病变通常从腹侧腹部、胸部、耳缘、肘部和跗关节开始[1,3]。如果不治疗，病情会全身化[1]。耳廓-足底反射在约95%的疥螨病犬中呈阳性，但只有80%具有该反射的犬实际上患有疥螨病[6]。

慢性病例发展为皮脂溢、严重的皮肤增厚伴皱褶形成、外周淋巴结肿大和消瘦[4]。区域性淋巴结肿大很常见[2]。有些犬可能因剧烈抓挠而出现角膜溃疡或耳血肿[3]。

"隐匿性疥螨"发生在美容良好的犬身上，定期洗澡去除了结痂和鳞屑，尽管持续瘙痒，但使螨虫检测变得困难[1,4]。非典型表现，包括局限性形式，越来越被认识到[4]。

### Sources

[1] Mite Infestation (Mange, Acariasis, Scabies) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs

[2] Update on Demodicosis and other mite-caused dermatoses (Proceedings): https://www.dvm360.com/view/update-demodicosis-and-other-mite-caused-dermatoses-proceedings

[3] If you think it's scabies, treat it: https://www.dvm360.com/view/if-you-think-its-scabies-treat-it

[4] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats

[5] The mighty mites of companion animals (Proceedings): https://www.dvm360.com/view/mighty-mites-companion-animals-proceedings

[6] The CSI approach to pruritic pets: https://www.dvm360.com/view/csi-approach-pruritic-pets-interviewing-witnesses-owners-assessing-crime-scene-skin-proceedings

## 诊断方法

由于螨虫检测具有挑战性，诊断犬疥螨病需要多种方法。深层皮肤刮片是主要的诊断方法，在耳缘、肘部和跗关节的结痂病变处进行，直到出现毛细血管出血[1]。应从丘疹或脱毛区域获得多个广泛表浅刮片，因为疥螨生活在角质层中且数量通常很少[2]。

耳廓-足底反射可以通过轻柔抓挠耳缘引发，导致犬用后腿抓挠，尽管该测试缺乏特异性，并且在没有耳部受累时可能呈阴性[1]。在4X至10X放大倍数下进行显微镜检查可以在矿物油制剂中发现螨虫、卵或粪便颗粒[2]。

诊断挑战很大，30-70%的病例出现刮片假阴性[1][5]。"隐匿性疥螨"在美容良好的犬身上表现出特殊困难，定期洗澡去除了结痂和鳞屑，尽管持续瘙痒，但使螨虫证明变得困难[3]。一种用于检测特异性抗体的商业ELISA测试已经开发出来，可能被证明是有用的[1]。

使用糖溶液对多个刮片进行浓缩和漂浮可能会提高诊断率[1]。当找不到螨虫但临床症状强烈提示疥螨病时，应进行治疗性试验，并通过治疗反应提供最明确的诊断[1][5]。

### Sources
[1] MSD Veterinary Manual Mange in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[2] DVM 360 Obtaining a skin scraping: https://www.dvm360.com/view/obtaining-skin-scraping
[3] MSD Veterinary Manual Mite Infestation in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs
[4] DVM 360 Update Diagnosis and control of mite infestations: https://www.dvm360.com/view/update-diagnosis-and-control-mite-infestations-dogs-and-cats-proceedings
[5] DVM 360 The technicians role in veterinary dermatology: https://www.dvm360.com/view/technician-s-role-veterinary-dermatology-proceedings

## 治疗选择

犬疥螨病治疗主要依赖于全身性和局部性杀螨剂，有几种FDA批准的选项可用[1]。塞拉菌素滴剂（6-12 mg/kg）单次给药或每月两次治疗可提供有效控制，并且对伊维菌素敏感品种安全[1]。咪多丁-莫昔克丁组合提供了另一种FDA批准的选项，以2.5 mg/kg莫昔克丁的剂量间隔四周给药两次[1]。

标签外使用的大环内酯类药物包括米尔贝肟（2 mg/kg每周一次，持续3-4周）和伊维菌素（200 mcg/kg每两周一次）[1]。然而，伊维菌素需要仔细考虑MDR1基因状态，因为具有ABCB1突变的品种由于血脑屏障处P-糖蛋白功能缺陷而面临增加的神经毒性风险[4]。在易感品种（包括柯利犬、边境牧羊犬和澳大利亚牧羊犬）中使用伊维菌素前，建议进行MDR1突变检测[4,6]。

较新的异噁唑啉类化合物（阿福拉纳、氟雷拉纳、沙罗拉纳）显示出良好的疗效，但缺乏FDA对疥螨病的批准[1]。传统局部治疗包括硫磺石灰浴，这对幼犬非常有效且安全，每七天应用一次[1,3]。继发性细菌感染需要同时进行抗菌治疗[1]。

由于疥癣的高度传染性，所有接触动物都必须接受治疗[1,3]。治疗应持续到临床症状消失并获得阴性皮肤刮片为止[1]。

### Sources

[1] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[2] Mite Infestation (Mange, Acariasis, Scabies) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/mite-infestation-mange-acariasis-scabies-in-dogs?query=otodectes+cynotis+mites
[3] White feet, maybe treat? Testing for the MDR-1 gene in collie breeds: https://www.dvm360.com/view/white-feet-maybe-treat-testing-mdr-1-gene-collie-breeds-proceedings-0
[4] Just Ask the Expert: The best way to treat ivermectin toxicosis: https://www.dvm360.com/view/just-ask-expert-best-way-treat-ivermectin-toxicosis

## 预防措施

预防犬疥螨病需要全面的环境管理、接触动物治疗和适当的隔离方案，以打破传播循环并防止重新引入。

环境消毒至关重要，因为犬疥螨在室温下可在宿主体外存活2-6天，雌螨在最佳条件下可能存活长达21天[1]。所有寝具、玩具、美容设备和织物物品都应热水清洗或更换。感染犬所在的区域应彻底清洁并用适当的杀螨产品处理。

同时治疗所有接触动物至关重要，无论临床症状如何，因为可能存在无症状携带者并成为再感染的来源[1]。这包括家庭、寄养设施或与感染动物有过接触的繁育操作中的所有犬。

必须在诊断后立即实施严格的隔离方案。感染动物应与其他动物隔离，并仅在防护设备下处理，以最小化人畜共患传播风险[1]。工作人员在处理疑似或确诊病例时应戴手套并保持良好卫生习惯。

定期预防用药策略对高风险人群尤为重要。每月应用塞拉菌素（Revolution）可有效预防疥螨病，同时控制跳蚤、耳螨和其他外寄生虫[6][7][8]。这种方法对流行地区的动物、繁育设施或频繁接触其他犬的动物特别有价值。

### Sources
[1] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[6] Does Wolbachia change treatment for heartworm disease?: https://www.dvm360.com/view/does-wolbachia-change-treatment-heartworm-disease-proceedings
[7] Update on treatment of flea allergic dermatitis: https://www.dvm360.com/view/update-treatment-flea-allergic-dermatitis-proceedings
[8] Flea control and insecticides: https://www.dvm360.com/view/flea-control-and-insecticides-proceedings

## 鉴别诊断

犬疥螨病必须与几种具有相似临床特征的瘙痒性疾病进行区分。最重要的鉴别诊断包括特应性皮炎、食物过敏、跳蚤过敏性皮炎、蠕形螨病、姬螯螨病和其他寄生虫性疾病[1]。

**特应性皮炎**通常影响面部、足部、耳朵、腋窝和腹侧区域，常见季节性模式。与疥螨病不同，特应性患者很少表现出对皮质类固醇无反应的剧烈瘙痒[2]。此外，特应性皮炎通常在1-3岁之间开始，并有品种易感性。

**食物过敏**表现为影响面部、足部、耳朵和肛周区域的非季节性瘙痒。关键区别特征是缺乏季节性和潜在的并发胃肠道症状[7]。食物过敏患者可能有继发性细菌感染，但通常缺乏疥螨病的特征性分布模式。

**跳蚤过敏性皮炎**引起剧烈瘙痒，主要影响身体后三分之一，包括背腰骶区域和大腿内侧[6]。分布与疥螨病明显不同，后者特征性影响耳缘、肘部和跗关节。

**蠕形螨病**可通过深层皮肤刮片显示毛囊内特征性蠕形螨来区分[2]。局限性蠕形螨病通常影响幼犬，出现局灶性脱毛，而全身性形式可能因继发性细菌感染而瘙痒。

**姬螯螨病**表现为过度背侧脱屑（"行走皮屑"）和不同程度的瘙痒[3]。螨虫和椭圆形卵通常在表浅皮肤刮片或跳蚤梳子上可见，不像疥螨诊断那样具有挑战性。

疥螨病的关键区别特征包括对抗炎剂量皮质类固醇无反应的剧烈瘙痒、特征性分布模式（耳缘、肘部、跗关节）、影响多个动物的传染性以及阳性的耳廓-足底反射[4][5]。

### Sources
[1] Merck Veterinary Manual - Mite Infestation (Mange, Acariasis, Scabies) of Cats: https://www.merckvetmanual.com/en-au/cat-owners/skin-disorders-of-cats/mite-infestation-mange-acariasis-scabies-of-cats
[2] Merck Veterinary Manual - Mange in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[3] The technicians role in veterinary dermatology: https://www.dvm360.com/view/technician-s-role-veterinary-dermatology-proceedings
[4] Watch for these red flags in your veterinary derm exams: https://www.dvm360.com/view/watch-for-these-red-flags-in-your-veterinary-derm-exams
[5] Managing fleas and mites: https://www.dvm360.com/view/managing-fleas-and-mites-proceedings
[6] How to identify the pruritic dog: https://www.dvm360.com/view/how-identify-pruritic-dog
[7] Food allergies in the dog and cat: https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings

## 预后

犬疥螨病在适当治疗下预后通常极佳[1]。患有疥癣的犬通常对现代治疗干预反应良好，在开始适当治疗后几周内可实现临床缓解。

**预期临床结果**
大多数犬在开始治疗后2-4周内显示出显著改善[2]。病变和瘙痒的完全缓解通常在完成推荐治疗方案后发生。疥螨病的特征性剧烈瘙痒一旦开始有效的杀螨治疗通常会迅速减轻。

**治疗反应和恢复**
当遵循正确的诊断和治疗方案时，成功率很高。塞拉菌素和其他大环内酯类药物显示出优异的疗效，大多数病例实现完全缓解[2]。治疗必须持续至少6周，以覆盖两个完整的螨虫生命周期并确保清除所有发育阶段[3]。

**影响恢复的因素**
继发性细菌感染可能使恢复复杂化，必须与抗疥螨治疗同时处理[2]。患有慢性、全身性感染的犬可能因严重的皮肤损伤、继发性和免疫功能受损而需要更长时间愈合。美容良好的"隐匿性疥螨"犬可能诊断延迟，可能延长临床病程[2]。

**复发和长期管理**
通过与感染动物或受污染环境接触可能发生再感染。所有接触动物应同时治疗以防止再感染循环[3]。环境消毒和持续的跳蚤控制计划有助于防止未来暴露。通过适当的管理方案，长期预后仍然极佳。

### Sources
[1] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings
[2] Mange in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[3] Challenges in the diagnosis and management of skin ...: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0572.xml
