# 伴侣动物的尾腺增生

尾腺增生是一种影响犬猫尾部上腺的重要皮肤病，其特征是尾基部的皮脂腺异常增生。这种受激素影响的疾病主要影响未去势的雄性动物，并可能导致继发性并发症，包括细菌感染和自体创伤。了解这一疾病对兽医从业者至关重要，因为早期识别和适当治疗可显著改善预后。

本综合报告探讨了尾腺增生的病理生理学、临床表现和管理方法。主要发现包括未去势雄性动物具有强烈的激素易感性、手术干预结合去势的有效性，以及实施适当治疗时的良好预后。该报告综合了当前的兽医知识，为该疾病的诊断、治疗选择和长期管理提供了实用指导。

## 疾病概述

尾腺增生是影响猫尾部上腺的局部角化障碍性疾病(1)。尾部上腺位于尾巴的背侧，包含众多正常情况下产生蜡样分泌物的皮脂腺(1)。这种疾病表现为这些特殊腺体的异常增生和活动，导致皮脂分泌过多和毛囊角化过度。

这种综合征主要影响未去势的雄性猫，原因是激素影响，虽然较轻微的形式也可能出现在雌性和已去势的雄性中(1)。该疾病在解剖学上特异性地发生在尾部上腺集中的尾区。与其他小动物的增生性疾病不同，尾腺增生与猫尾部皮脂装置的独特解剖结构直接相关(2)。

流行病学显示强烈的性别倾向，未去势的雄性猫最常受影响(1)。然而，在某些情况下，该疾病在去势后仍可能持续存在，表明除了简单的激素影响外还有其他因素。年龄分布和品种倾向在兽医文献中没有充分记载，表明当解剖和激素因素一致时，这种疾病可能影响不同人口统计特征的猫(2)。

### Sources

[1] Localized keratinization syndromes (Proceedings): https://www.dvm360.com/view/localized-keratinization-syndromes-proceedings
[2] Mammary Hypertrophy in Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/mammary-hypertrophy-in-cats

## 常见病原体

尾腺增生主要是一种非感染性疾病，由激素影响而非病原体驱动[1]。该疾病主要影响未去势的雄性犬，原因是雄激素对尾部上腺的过度刺激，导致皮脂腺增生和毛囊堵塞[1]。

继发性细菌感染通常使尾腺增生病例复杂化。当继发性脓皮症发生时，葡萄球菌属是最常分离的病原体[2][3]。伪中间葡萄球菌在犬类皮肤感染中特别普遍，尽管也可能遇到其他葡萄球菌种类，包括金黄色葡萄球菌和施氏葡萄球菌[2]。

马拉色菌属（一种共生酵母）在脂溢性疾病中经常引起继发性感染[2][3]。尾腺增生特有的皮脂成分改变和毛囊堵塞为马拉色菌过度生长创造了有利条件，特别是在受影响的尾部上腺区域的油性、蜡样环境中。

与增生性变化相关的皮肤屏障功能受损，加上抓挠或舔舐造成的自体创伤，使受影响的动物易患这些机会性感染[3]。继发性感染通常对临床症状（包括瘙痒、炎症和恶臭）有显著贡献，使其识别和治疗成为成功管理的关键。

### Sources

[1] Mystery dermatology cases: A potpourri of interesting cases (Proceedings): https://www.dvm360.com/view/mystery-dermatology-cases-potpourri-interesting-cases-proceedings
[2] Update on atopic dermatitis (Proceedings): https://www.dvm360.com/view/update-atopic-dermatitis-proceedings
[3] Seborrhea in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/seborrhea/seborrhea-in-animals

## 临床症状和体征

尾腺增生通常表现为尾部上腺（位于尾基背侧）的逐渐肿胀和增大。这种疾病表现为坚实的隆起肿块，直径可能从几毫米到几厘米不等[1]。

病变通常呈现光滑的圆顶状外观，可能无毛或显示脱毛区域。在某些情况下，增大的腺体可能发生溃疡或感染，导致继发性并发症，包括结痂、分泌物或恶臭[1]。

患有尾腺增生的犬可能表现出行为迹象，如过度舔舐、咀嚼或咬患处。这种自体创伤可导致进一步的炎症和继发性细菌感染。

该疾病进展缓慢，病变在数周到数月内逐渐增大。与炎症过程不同，尾腺增生病变通常不会时好时坏，而是显示持续的生长模式。

**物种特异性模式**显示犬主要受影响，特别是未去势的雄性，原因是激素对皮脂腺活动的影响。中年至老年犬显示较高的发病率。猫很少发生显著的尾腺增生，尽管偶尔可能出现轻微的皮脂腺增大[1]。

鉴别诊断包括肛周腺腺瘤、皮脂腺瘤和其他皮肤附属器肿瘤，这些在肛周和尾区可能呈现相似的大体形态特征。

### Sources
[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 诊断方法

诊断尾腺增生需要系统的临床检查和针对性的诊断测试，以确认该疾病并排除鉴别诊断。

**临床检查**

体格检查显示特征性发现，包括尾部背侧区域的增大、坚实、结节状肿块[1]。受影响区域通常呈现为隆起的圆顶状病变，可能无毛或伴有脂溢症[1]。触诊常可沿尾基识别多个坚实结节，覆盖的皮肤可能显得增厚或变色[1]。

**实验室诊断**

细针抽吸细胞学是主要的诊断工具，显示丰富的皮脂细胞具有特征性的多边形形态和颗粒状细胞质[1]。这些肝样细胞与肝细胞非常相似，在显微镜检查下显示出独特的聚集模式[1]。细胞质呈现细颗粒状和双嗜性，含有明显核仁的圆形至卵圆形细胞核[1]。

当怀疑继发性细菌感染时，特别是存在脓性分泌物或炎症时，应进行细菌培养和药敏试验[2]。常见分离物包括马拉色菌属和各种可能使增生性疾病复杂化的细菌病原体[2]。

**额外测试**

皮肤刮片有助于排除蠕形螨病，而真菌培养则排除皮肤癣菌病[2]。在难治性病例中，组织病理学检查可确认皮脂腺增生并将其与腺瘤或腺癌区分开来。活检还可识别任何可能导致慢性尾部创伤和随后腺体增生的潜在过敏性疾病[2]。

### Sources
[1] Clinical Exposures: Canine circumanal gland adenoma: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[2] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗选择

### 局部治疗
尾腺增生的局部治疗包括频繁使用含有过氧化苯甲酰、硫或水杨酸的抗脂溢洗发水进行清洁[1]。这些角质溶解剂有助于去除过多的角蛋白并减少皮脂腺活动。局部莫匹罗星（2%）在相关疾病中显示出优异效果，63%的受治疗猫显示改善，尽管4%出现局部反应[3]。

### 全身用药
全身治疗可能包括针对继发性细菌感染的抗生素，特别是当涉及中间葡萄球菌时[3]。对于严重病例，口服维甲酸类药物如异维A酸（1-2 mg/kg/天）或阿维A酯可能有助于减少皮脂腺增生[2]。抗炎药物可能有助于控制相关炎症。

### 手术干预
去势通常是主要的手术治疗方法，特别是对于患有"公猫尾"的未去势雄性猫，因为它解决了激素对皮脂腺的潜在影响[3]。然而，去势并不总能解决该疾病，因为习得性行为和腺体变化可能持续存在。在严重、难治性病例中，可考虑手术切除受影响的腺体组织。

### 继发性感染的管理
继发性细菌或酵母菌感染需要根据细胞学和培养结果进行特定的抗菌治疗。全身性抗生素应尽可能根据药敏试验选择[3]。局部抗菌药可作为局部感染的辅助治疗。

### Sources
[1] Localized keratinization syndromes (Proceedings): https://www.dvm360.com/view/localized-keratinization-syndromes-proceedings
[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[3] Localized keratinization syndromes (Proceedings): https://www.dvm360.com/view/localized-keratinization-syndromes-proceedings

## 预防措施

现有章节内容提供了关于尾腺增生预防措施的全面信息。来源材料为这些建议提供了宝贵的额外支持，特别是关于去势和环境管理方法的重要性。

去势仍然是尾腺增生的主要预防干预措施，特别是在未去势的雄性犬中[4]。这与兽医预防性医疗保健指南一致，该指南强调生殖咨询和绝育或去势，除非专门用于繁殖目的[4]。腺体增生的睾酮依赖性质使这一干预措施对长期预防特别有效。

定期梳理和环境卫生仍然是预防的重要组成部分。保持清洁的生活条件可减少接触环境病原体和刺激物，这些因素可能导致继发性并发症[4]。适当的饲养做法支持整体免疫功能并减少可能加剧增生性疾病的压力相关因素。

常规兽医检查有助于早期识别易感因素并允许及时干预[4]。兽医指南推荐的综合预防性医疗保健方法包括定期体格检查和适当的诊断测试，以识别可能增加腺体疾病易感性的潜在疾病。

虽然尾腺增生没有特定的疫苗，但保持当前的疫苗接种计划支持整体免疫系统功能[4]。这种对预防医学的综合方法有助于降低可能使现有增生性疾病复杂化的并发感染风险。

### Sources

[1] Overview of endocrine skin diseases (Proceedings): https://www.dvm360.com/view/overview-endocrine-skin-diseases-proceedings
[2] Resection via carbon dioxide laser for the treatment of canine: https://avmajournals.avma.org/view/journals/ajvr/86/5/ajvr.25.01.0004.xml
[3] Chinchillas - Exotic and Laboratory Animals: https://www.merckvetmanual.com/en-au/exotic-and-laboratory-animals/rodents/chinchillas
[4] Practice Guidelines - avmajournals.avma.org: https://avmajournals.avma.org/downloadpdf/view/journals/javma/239/5/javma.239.5.625.pdf

## 鉴别诊断

尾腺增生必须与几种可在尾部背侧区域呈现相似临床体征的疾病区分开来[1]。

**皮脂腺疾病**代表主要的鉴别考虑因素。原发性脂溢症和皮脂腺炎可引起相似的脱屑、油腻和腺体增大模式。然而，皮脂腺炎通常呈现更弥漫的毛囊角蛋白管形成和"幼犬毛"滞留，而尾腺增生仍然局限于尾部上腺区域[2]。

**肿瘤性疾病**包括皮脂腺瘤、腺癌和耵聍腺肿瘤可模拟增生性变化[3]。鉴别特征包括不对称生长模式、溃疡和恶性过程中更具侵袭性的临床行为，与增生典型的对称、非溃疡性表现相对[4]。

**继发性感染性皮炎**由细菌性脓皮症或马拉色菌过度生长引起，可产生相似的炎症变化，伴有脱屑和气味。然而，感染性疾病通常对抗微生物治疗有反应，并在细胞学上显示炎症细胞浸润，与腺体增生中主要观察到的增生性变化形成对比[5]。

**内分泌疾病**如甲状腺功能减退和肾上腺皮质功能亢进可导致继发性皮脂腺功能障碍，应通过适当的激素检测排除，特别是当存在全身性体征时[6]。

### Sources

[1] Merck Veterinary Manual Glossary: https://www.merckvetmanual.com/resourcespages/glossary
[2] "Don't dress your itchy dog in black": A case approach to seborrhea: https://www.dvm360.com/view/dont-dress-your-itchy-dog-black-case-approach-seborrhea-proceedings
[3] Just under the surface: Cytology of the skin: https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[4] Diagnostic otology: https://www.dvm360.com/view/diagnostic-otology-proceedings
[5] Hypersensitivity Diseases in Animals: https://www.merckvetmanual.com/immune-system/immunologic-diseases/hypersensitivity-diseases-in-animals
[6] Common endocrine dermatopathies in dogs: https://www.dvm360.com/view/common-endocrine-dermatopathies-dogs

## 预后

当提供适当治疗时，犬猫尾腺增生的预后通常良好。完全手术切除通常在达到足够手术切缘时可实现确定性治愈，局部复发风险最小[1]。总体生存率和临床结果是有利的，因为这些病变主要呈良性。

对于代表大多数病例的良性皮脂腺增生，手术切除是治愈性的，具有优异的长期预后。切除后恢复通常迅速，大多数动物在术后数天至数周内恢复正常活动[1]。

几个因素影响总体预后。腺体受累程度、继发性细菌感染的存在和动物的整体健康状况可能影响恢复时间和结果。老年动物可能需要更密切的术后监测，因为潜在的并发疾病，尽管增生本身很少引起全身性并发症[1]。

长期管理考虑包括常规监测其他皮脂腺部位新增生病变的发展，因为某些动物可能易患复发发作。然而，这些后续病变可以使用类似的手术方法进行治疗，同样具有有利的结果[1]。

当实现具有适当切缘的完全切除时，原手术部位的复发并不常见，这支持了该疾病良好的总体预后[1]。

### Sources

[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
