# 犬猫淋巴瘤

## 疾病概述

淋巴瘤是影响伴侣动物最常见的造血系统恶性肿瘤之一，源于不同解剖部位淋巴细胞的恶性转化（Merck Veterinary Manual, 2024）。这种肿瘤性疾病在犬猫之间的临床表现、生物学行为和治疗反应方面表现出显著的异质性。

**定义**
淋巴瘤是一种起源于淋巴细胞的恶性肿瘤，可发生于淋巴器官，包括淋巴结、脾脏、骨髓、胸腺以及结外部位如胃肠道、皮肤、眼睛和中枢神经系统（Merck Veterinary Manual, 2024）。该疾病包含多个不同的亚型，具有不同的细胞形态学、免疫表型和临床行为模式。

**流行病学背景**
犬淋巴瘤的年发病率约为每10万只犬13-24例，使其成为兽医学中最常诊断的癌症之一（DVM360, 2024）。该疾病呈现双峰年龄分布，高峰出现在6-9岁的犬，另一个高峰出现在10岁以上的老年犬（Merck Veterinary Manual, 2024）。

犬的品种易感性已有充分记载，金毛寻回犬、拉布拉多寻回犬、拳师犬、斗牛犬和苏格兰梗显示出显著增加的风险（DVM360, 2024）。大型犬的总体发病率高于小型犬。

猫淋巴瘤呈现不同的流行病学模式，随着FeLV疫苗接种计划的广泛实施，该疾病现在主要影响老年猫（中位年龄9-12岁）（DVM360, 2024）。历史上与FeLV相关的淋巴瘤通常影响幼猫（中位年龄2-3岁），但现代病例大多为逆转录病毒阴性，发生在老年患者中。

**解剖学分类**
多中心性淋巴瘤是犬最常见的类型，占病例的80-85%，特征是全身性外周淋巴结肿大（DVM360, 2024）。胃肠道淋巴瘤占犬病例的不到10%，但在猫中是主要类型，特别影响小肠和肠系膜淋巴结。纵隔淋巴瘤涉及前纵隔淋巴结或胸腺，在年轻大型犬中更常见。皮肤淋巴瘤表现为原发性皮肤受累，而结外形式可影响几乎任何器官系统，包括眼睛、中枢神经系统和肾脏（Merck Veterinary Manual, 2024）。

## 常见病原体

猫白血病病毒（FeLV）是猫淋巴瘤最重要的病毒病因之一[1]。FeLV被归类为逆转录病毒，可整合到宿主细胞DNA中，直接导致恶性淋巴细胞转化[1]。历史上，FeLV相关淋巴瘤极为常见，感染与纵隔、多中心性和脊髓形式的淋巴瘤密切相关[1]。

猫免疫缺陷病毒（FIV）虽然主要与免疫抑制相关，但也可通过免疫功能障碍机制使猫易患淋巴样恶性肿瘤[1]。FeLV疫苗的广泛使用在过去几十年中显著降低了病毒相关淋巴瘤的发病率[2]。

环境因素在淋巴瘤发展中起重要作用。在犬中，几个假设的病因包括苯氧乙酸类除草剂的环境污染、磁场暴露和化学致癌物[2,3]。流行病学证据表明，家庭环境烟草烟雾作为一种化学致癌物，增加了猫的淋巴瘤风险[2]。

染色体异常和免疫功能障碍是额外的 contributing factors [2,3]。太阳辐射和各种化学品可导致淋巴细胞的恶性转化[5]。这些因素可能独立或与病毒感染协同作用，促进伴侣动物淋巴瘤的发展。

### Sources
[1] Feline Leukemia Virus Disease: https://www.merckvetmanual.com/infectious-diseases/feline-leukemia-virus/feline-leukemia-virus-disease
[2] Treating lymphoma in dogs and cats: https://www.dvm360.com/view/treating-lymphoma-dogs-and-cats
[3] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs
[4] Canine lymphoma: The naive patient (Proceedings): https://www.dvm360.com/view/canine-lymphoma-naive-patient-proceedings
[5] Malignant Lymphoma in Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/blood-disorders-of-dogs/malignant-lymphoma-in-dogs

## 临床症状和体征

**多中心性淋巴瘤**是最常见的形式，占病例的80-85%[1]。标志性体征是外周淋巴结快速、无痛性肿大，可能达到正常大小的3-10倍[2]。晚期疾病引起全身性症状，包括严重嗜睡、虚弱、发热、厌食和脱水[3]。

**胃肠道淋巴瘤**占犬病例的不到10%[2]。局灶性肠道病变产生管腔梗阻体征，包括呕吐、便秘和腹痛。弥漫性受累引起破坏性体征：由于吸收不良导致的厌食、呕吐、腹泻和体重减轻[2]。

**纵隔淋巴瘤**仅影响少数病例，特征是前纵隔淋巴结或胸腺肿大[3]。晚期疾病因胸腔积液、肺压迫或前腔静脉综合征导致呼吸窘迫[3]。

**皮肤淋巴瘤**表现为单个隆起性溃疡性结节或全身性弥漫性鳞屑性病变，常涉及外周淋巴结和皮肤黏膜交界处[3]。

**副肿瘤综合征**常见，特别是10-40%淋巴瘤病例中的高钙血症[3]。这引起多尿、烦渴、肌无力，并可能危及生命的并发症[6]。其他综合征包括贫血、血小板减少和恶病质[1]。

**物种差异**存在于犬和猫之间。猫淋巴瘤通常影响老年、逆转录病毒阴性的猫，伴有胃肠道疾病，与犬中主要的多中心性形式形成对比[1]。

### Sources

[1] Lymphoma in dogs and cats (Proceedings): https://www.dvm360.com/view/lymphoma-dogs-and-cats-proceedings
[2] Malignant Lymphoma in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/blood-disorders-of-dogs/malignant-lymphoma-in-dogs
[3] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs
[4] Urinary obstruction secondary to bladder lymphoma in a dog: https://www.dvm360.com/view/clinical-exposures-urinary-obstruction-secondary-bladder-lymphoma-dog
[5] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[6] Paraneoplastic syndromes (Proceedings): https://www.dvm360.com/view/paraneoplastic-syndromes-proceedings-0

## 诊断方法

**临床表现评估**

体格检查显示典型的淋巴瘤发现，包括淋巴结肿大、器官肿大和全身性症状[1]。临床分期使用WHO系统评估疾病程度并提供预后信息[5]。完整分期包括彻底的体格检查、全血细胞计数、血清生化面板、尿液分析、胸部X光片和骨髓抽吸[5]。

**细胞学和组织病理学诊断**

肿大淋巴结的细针抽吸和细胞学为显示单形性淋巴母细胞群的高级别淋巴瘤提供快速初步诊断[1]。然而，组织活检和组织病理学对于确认惰性淋巴瘤和确定特定变体是强制性的[1]。小细胞淋巴瘤的诊断不能仅通过细针抽吸细胞学进行，需要组织活检[4]。全层活检允许结构评估和确定性诊断[1]。

**高级诊断测试**

使用免疫组织化学、流式细胞术或抗原受体重排PCR（PARR）的免疫表型分型确定B细胞与T细胞谱系[5]。PARR测试对淋巴样肿瘤的敏感性约为85%，特异性为95%，可在各种样本类型上进行，包括风干的细胞学涂片[5]。流式细胞术需要新鲜抽吸物但提供快速免疫表型分型[5]。

**影像学和分期**

CT或MRI的高级影像学评估疾病程度，特别是对于鼻淋巴瘤[3]。腹部超声评估胃肠道受累情况，并为患有肠淋巴瘤的猫建立基线测量值[4]。区域淋巴结抽吸和胸部X光片筛查转移性疾病[2,3]。

### Sources
[1] All canine lymphomas are not created equal (Proceedings): https://www.dvm360.com/view/all-canine-lymphomas-are-not-created-equal-proceedings
[2] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors
[3] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[4] Unique Aspects of Feline Lymphoma: https://www.dvm360.com/view/unique-aspects-of-feline-lymphoma
[5] Update on canine lymphoma: Where are we going? ...: https://www.dvm360.com/view/update-canine-lymphoma-where-are-we-going-proceedings

## 治疗选择

淋巴瘤治疗在犬和猫之间差异显著，需要针对物种特异性反应的不同方案。犬淋巴瘤的金标准是使用CHOP方案（环磷酰胺、羟基柔红霉素[阿霉素]、长春新碱[Oncovin]和泼尼松龙）的联合化疗，达到80-90%的完全缓解率，中位生存时间为12个月[1][2]。

对于犬，单药阿霉素是最有效的单药治疗选择，反应率为75-80%，中位生存期为5-7个月。COP方案（环磷酰胺、长春新碱、泼尼松龙）提供了一种更简单、成本更低的替代方案，达到约75%的反应率，中位生存期为6-8个月[3]。

猫淋巴瘤治疗的反应率低于犬方案。接受CHOP治疗的大细胞淋巴瘤猫达到50-75%的反应率，中位生存期为6-9个月。然而，达到完全缓解的猫通常比犬活得更长，中位生存期接近2年[1][4]。

物种特异性考虑至关重要。单药阿霉素在猫中的活性低于犬。对于猫小细胞胃肠道淋巴瘤，联合苯丁酸氮芥（15 mg/m²每3周一次）和泼尼松龙治疗提供良好的长期控制，中位生存期为1-3年[1]。

放射治疗是局限性淋巴瘤的有效治疗方法，特别是猫鼻淋巴瘤，可达到超过1.5年的中位生存时间[5]。支持性护理包括管理化疗引起的毒性，厌食是接受CHOP治疗的猫中最常见的不良反应[1]。

### Sources
[1] Unique Aspects of Feline Lymphoma: https://www.dvm360.com/view/unique-aspects-of-feline-lymphoma
[2] What's next? Rescue protocols for canine lymphoma: https://www.dvm360.com/view/whats-next-rescue-protocols-canine-lymphoma
[3] Update on canine lymphoma: Where are we going?: https://www.dvm360.com/view/update-canine-lymphoma-where-are-we-going-proceedings
[4] Practical lymphoma management (Proceedings): https://www.dvm360.com/view/practical-lymphoma-management-proceedings
[5] Just Ask the Expert: How do you treat cats with intestinal lymphoma?: https://www.dvm360.com/view/just-ask-expert-how-do-you-treat-cats-with-intestinal-lymphoma

## 预防措施

伴侣动物淋巴瘤的预防集中在控制已知风险因素，特别是在猫中，FeLV疫苗接种是预防的基石。2020年AAHA/AAFP猫疫苗接种指南建议FeLV疫苗接种作为1岁以下猫的核心疫苗，低风险成年猫为非核心疫苗[3]。FeLV疫苗应给小猫接种，一年后重复接种，一些数据表明良好的免疫力持续超过一年[2]。

环境管理在淋巴瘤预防中起着关键作用。流行病学证据将家庭环境烟草烟雾与猫淋巴瘤风险增加联系起来，使无烟环境变得重要[1]。对于犬，避免接触苯氧乙酸类除草剂和其他可疑的环境污染物可能降低风险[1,7]。最近的研究证实，接触除草剂处理草坪的犬尿液除草剂水平增加，除草剂使用与癌症风险增加相关。

感染的猫需要严格的室内隔离以防止病毒传播并降低继发感染风险。FeLV阳性猫应至少每年接受两次体格检查，定期监测包括全血细胞计数、生化分析和尿液分析[4]。所有感染的猫都应绝育以防止垂直传播。

常规筛查仍然至关重要，包括在首次兽医就诊时测试所有小猫，在进入未感染猫家庭之前测试猫，以及户外猫的年度测试[3,5]。早期识别使适当的管理成为可能，并防止传播给易感人群。

### Sources
[1] Treating lymphoma in dogs and cats: https://www.dvm360.com/view/treating-lymphoma-dogs-and-cats
[2] Feline leukemia virus (Proceedings): https://www.dvm360.com/view/feline-leukemia-virus-proceedings
[3] Feline Leukemia Virus (FeLV) - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-leukemia-virus-felv
[4] Living with FeLV-infected cats: A guide for veterinarians and their clients: https://www.dvm360.com/view/living-with-felv-infected-cats-guide-veterinarians-and-their-clients
[5] Feline Leukemia Virus Disease: https://www.merckvetmanual.com/infectious-diseases/feline-leukemia-virus/feline-leukemia-virus-disease
[6] Update on transitional cell carcinoma (Proceedings): https://www.dvm360.com/view/update-transitional-cell-carcinoma-proceedings
[7] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs

## 鉴别诊断

在评估伴侣动物淋巴瘤时，几种情况可能表现出相似的临床体征，需要仔细鉴别。

**感染性病因**
犬全身性淋巴结腺病的两个常见鉴别诊断是恶性淋巴瘤和组织胞浆菌病[1]。分枝杆菌感染，特别是鸟分枝杆菌，可模仿淋巴瘤，表现为全身性淋巴结肿大、发热和体重减轻[1]。立克次体病，包括埃里希体病和落基山斑疹热，应予以考虑，特别是当伴随关节肿胀和淋巴结肿大时[1]。在猫中，发热的感染性原因比原发性免疫疾病或肿瘤更常见[2]。

**真菌性疾病**
全身性真菌感染常引起淋巴结肿大和器官受累，可模仿淋巴瘤。最重要的真菌鉴别诊断包括皮炎芽生菌、荚膜组织胞浆菌、粗球孢子菌和新型隐球菌[3][4]。球孢子菌病常与犬骨炎引起的严重骨痛相关[2]。这些真菌肺炎表现出的体重减轻、发热和器官肿大与淋巴瘤相似[2]。

**炎症性肠病与淋巴瘤**
在猫患者中，区分炎症性肠病（IBD）和小细胞淋巴细胞性淋巴瘤存在显著的诊断挑战[5][6]。两种情况都可能导致相同的临床体征和肠道组织病理学变化[6]。然而，小细胞（淋巴细胞性，低级别）淋巴瘤可能极难与IBD区分，因为疾病可能是局灶性的或仅存在于更深的肠壁层中[6]。抗原受体重排聚合酶链反应（PARR）在区分猫肠淋巴瘤和IBD方面显示出高敏感性[7]。

**其他肿瘤性疾病**
淋巴瘤是犬眼最常见的转移性肿瘤，也是犬肿瘤性葡萄膜炎的最常见原因[8]。肿大的外周淋巴结应进行抽吸，以区分肿瘤原因和由原发性免疫介导疾病或感染性疾病引起的增生[2]。

### Sources
[1] Fungal Infections in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/fungal-infections-in-dogs
[2] Fungal Pneumonia in Small Animals - Respiratory System: https://www.merckvetmanual.com/respiratory-system/fungal-pneumonia-in-small-animals/fungal-pneumonia-in-small-animals
[3] Systemic fungal diseases (Proceedings): https://www.dvm360.com/view/systemic-fungal-diseases-proceedings
[4] Frustrating fungal diseases (Proceedings): https://www.dvm360.com/view/frustrating-fungal-diseases-proceedings
[5] Managing feline gastrointestinal lymphoma: https://www.dvm360.com/view/managing-feline-gastrointestinal-lymphoma-proceedings
[6] Managing IBD and diarrhea in adult cats: https://www.dvm360.com/view/managing-ibd-and-diarrhea-adult-cats-proceedings
[7] CVC Highlight: Practical GI function testing for veterinarians: https://www.dvm360.com/view/cvc-highlight-practical-gi-function-testing-veterinarians
[8] Canine ocular manifestations of systemic disease: https://www.dvm360.com/view/canine-ocular-manifestations-systemic-disease-when-primary-problem-isnt-eye-proceedings
