# 猫疱疹病毒感染

猫疱疹病毒1型（FHV-1）是影响全球家猫的最重要病毒性疾病之一，全球猫群暴露率高达95%。这种α疱疹病毒引起急性呼吸道疾病并建立终身潜伏感染，为兽医从业者带来持续的管理挑战。该病毒在应激期间能够重新激活并引起反复的眼部和呼吸道并发症，使其在个体猫和多猫环境中成为持续关注的问题。本报告探讨了FHV-1的综合兽医处理方法，涵盖诊断策略、循证治疗方案、疫苗接种计划以及携带猫的长期管理，以优化临床结果和生活质量。

## 摘要

猫疱疹病毒1型呈现复杂的临床挑战，需要多模式管理策略。几乎所有猫都通过自然暴露感染该病毒，建立永久性潜伏感染，并可能在猫的一生中因应激而重新激活。诊断方法强调PCR和病毒分离而非血清学，树突状角膜溃疡作为特征性体征。治疗以泛昔洛韦为主要抗病毒药物，在幼猫中显著加速恢复，在慢性病例中减少并发症。

| 管理方面 | 急性期 | 慢性期 |
|-------------------|-------------|---------------|
| 主要治疗 | 泛昔洛韦 + 支持性护理 | L-赖氨酸补充，应激管理 |
| 诊断重点 | PCR，病毒分离 | 临床体征，复发模式 |
| 预后 | 治疗后高存活率 | 终身携带状态，症状可控 |
| 预防策略 | 暴露风险时立即接种疫苗 | 环境控制，应激减少 |

长期成功取决于客户教育，使其了解慢性鼻炎虽然无法治愈但可管理的性质，以及减少应激的重要性。疫苗接种提供保护性益处并可能减少病毒排毒，而在多猫环境中环境管理对于防止疫情传播仍然至关重要。

## 疾病概述

猫疱疹病毒1型（FHV-1），又称猫病毒性鼻气管炎（FVR），是一种具有脂质包膜的双链DNA病毒，引起猫呼吸道疾病复合症[1][2]。作为α疱疹病毒，FHV-1主要靶向上呼吸道和结膜的上皮细胞，初次感染后在三叉神经节建立潜伏感染[2][3]。

FHV-1在全球家猫群体中广泛分布，并影响野生和外来猫科动物[4]。专家认为全球95%以上的猫已暴露于FHV-1[5]。该病毒具有高度传染性，通过直接接触、气溶胶飞沫和污染物传播[4]。大多数猫通过自然暴露或疫苗接种变为血清阳性[2][3]。

流行病学特征是急性感染后的携带状态。康复后，猫可能携带病毒数月，间歇性病毒排毒由创伤、并发疾病、分娩、寄养或社会等级变化等应激因素触发[2][3]。这种复发模式有助于病毒在群体内持续存在。幼猫、老年猫和短头颅品种猫对严重疾病表现显示出更高的易感性[4]。

### Sources

[1] Clinical trial underway for feline herpesvirus treatment in shelter cats: https://www.dvm360.com/view/clinical-trial-underway-for-feline-herpesvirus-treatment-in-shelter-cats
[2] Update on viral diseases in cats (Proceedings): https://www.dvm360.com/view/update-viral-diseases-cats-proceedings
[3] Feline viral upper respiratory infection: Why it persists (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[4] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/en-au/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[5] Vaccination of Exotic Mammals: https://www.merckvetmanual.com/exotic-and-laboratory-animals/vaccination-of-exotic-mammals/vaccination-of-exotic-mammals

## 发病机制和临床表现

猫疱疹病毒1型（FHV-1）通过与口咽部、结膜和鼻部的感染分泌物直接接触建立感染[1]。该病毒主要影响呼吸道上皮和鼻甲，造成的损伤可导致慢性鼻炎和鼻窦炎[2]。

初次感染后，FHV-1在神经组织中建立终身潜伏感染，特别是三叉神经节、视神经、角膜和扁桃体[2]。估计80-100%的感染猫发展为潜伏感染，约45%的潜伏感染猫经历间歇性病毒排毒[2][6]。病毒以非复制状态持续存在，直到因应激、皮质类固醇给药或其他免疫抑制因素而重新激活[2]。

急性初次感染通常表现为双侧结膜炎、呼吸道症状包括体温达105°F（40.5°C）和打喷嚏，以及脓性鼻分泌物[3]。临床症状在轻度病例中持续5-10天，在严重病例中可达6周[3][7]。

复发感染与初次疾病显著不同[4]。在成年猫中，复发感染常见单侧结膜炎或无呼吸道症状的溃疡性角膜炎[4]。复发性疾病通常反复影响同一只眼睛，而对侧眼睛保持正常[5]。

眼部表现包括角膜溃疡，其中树突状溃疡被认为是FHV-1的特征性表现[4][8]。其他并发症包括睑球粘连形成、角膜坏死和嗜酸性角膜炎[2]。

### Sources
[1] Feline herpesvirus and calicivirus infections: https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[2] Feline herpesvirus and calicivirus infections: https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[3] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[4] Feline corneal diseases: https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[5] Herpesvirus and the feline eye: https://www.dvm360.com/view/herpesvirus-and-feline-eye
[6] Effects of orally administered raltegravir in cats: https://avmajournals.avma.org/view/journals/ajvr/80/5/ajvr.80.5.490.xml
[7] Update on viral diseases in cats: https://www.dvm360.com/view/update-viral-diseases-cats-proceedings
[8] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 诊断方法和鉴别诊断

猫疱疹病毒（FHV-1）诊断主要依靠病毒检测方法而非血清学，因为大多数猫因自然暴露或疫苗接种而血清阳性[1]。金标准诊断方法仍然是使用口咽部、鼻部和结膜拭子进行病毒分离，但由于FHV-1在环境中的脆弱性，仔细的样本处理至关重要[2]。

聚合酶链反应（PCR）为检测病毒遗传物质提供高灵敏度，并日益商业化可用。然而，PCR可检测亚临床和潜伏感染，约25%的健康猫中发现FHV-1 DNA，需要仔细的临床相关性分析[3]。实时PCR与常规PCR方法相比提供改进的灵敏度和特异性[2]。

通过免疫荧光测定（IFA）进行抗原检测提供快速、廉价的结果，但灵敏度相对较低，特别是在慢性病例中[3]。对于急性感染，细胞学检查可能在初次感染期间揭示核内包涵体，尽管这些是罕见发现[6]。

重要的鉴别诊断包括细菌病原体（猫衣原体、支原体属、支气管败血波氏杆菌）、其他病毒因子（猫杯状病毒、猫传染性腹膜炎病毒）以及非传染性原因如过敏性鼻炎或肿瘤[5]。FHV-1特征性地影响结膜和鼻道并可能引起角膜溃疡，而猫杯状病毒通常涉及口腔黏膜和呼吸道并伴有口腔溃疡[4]。树突状角膜溃疡是FHV-1感染的特征性表现[6]。临床表现评估结合适当的实验室检测能够准确识别病原体并选择靶向治疗。

### Sources
[1] The dos and don'ts of treating ocular disease in cats (Proceedings): https://www.dvm360.com/view/dos-and-donts-treating-ocular-disease-cats-proceedings
[2] Viral diagnostics: What do the results mean? (Proceedings): https://www.dvm360.com/view/viral-diagnostics-what-do-results-mean-proceedings
[3] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[4] Merck Veterinary Manual Feline Respiratory Disease Complex - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[5] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[6] How to approach the squinty cat (Proceedings): https://www.dvm360.com/view/how-approach-squinty-cat-proceedings

## 治疗策略和预防措施

现有内容全面涵盖了猫疱疹病毒的治疗策略和预防措施。可用资料支持并强化了几个关键方面，特别是关于疫苗接种方案和环境控制措施。

**疫苗接种时间和方案**
最佳疫苗接种策略强调进入收容所时立即给药以获得最大保护益处[2]。对于寄养设施和猫舍，疫苗理想情况下应在进入前至少一周给予以建立保护性免疫[2]。鼻内疫苗可能在72小时内提供更快速的保护，而皮下疫苗需要6-7天[4]。

**多猫环境中的环境管理**
在烈性全身性疾病（VSD）爆发期间，特别是由猫杯状病毒引起的，严格的隔离措施和屏障护理协议对于防止疾病传播至关重要[1]。环境消毒仍然至关重要，使用适当的消毒剂如漂白剂（杯状病毒1:32稀释）并在整个设施中保持适当的卫生实践[6][7]。

**额外治疗考虑**
现有的泛昔洛韦方案仍然是抗病毒治疗的基石，临床研究证明显著加速恢复和减少并发症[1]。广谱抗生素的支持性护理对于管理继发性细菌感染仍然至关重要，而L-赖氨酸补充可能在应激期间预防病毒重新激活方面提供额外的预防益处[4]。

### Sources
[1] Viral respiratory pathogens: https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings
[2] Feline upper respiratory syndrome: https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings-0
[3] Evaluation of orally administered famciclovir in cats: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/72/1/ajvr.72.1.85.pdf
[4] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[5] Feline infectious respiratory disease: https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[6] Viral respiratory pathogens: https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings
[7] Feline viral respiratory disease: To vaccinate or not to vaccinate?: https://www.dvm360.com/view/feline-viral-respiratory-disease-vaccinate-or-not-vaccinate-proceedings
[8] Feline upper respiratory syndrome: https://www.dvm360.com/view/feline-upper-respiratory-syndrome-proceedings-0

## 预后和长期管理

猫疱疹病毒（FHV-1）感染的预后因疾病严重程度和管理方法而异。虽然急性感染在适当的支持性护理下通常具有高存活率，但感染的慢性性质带来持续挑战。研究表明，受影响猫的存活率预计很高，前提是能够提供抗菌、水合和营养支持[1]。

长期管理侧重于控制复发发作而非实现治愈。约100%从急性FHV-1感染康复的猫成为慢性携带者，潜伏病毒持续存在于三叉神经节等组织中[1]。应激管理至关重要，因为生理或药理应激可触发病毒重新激活和临床复发[1]。证据表明，接种疫苗的猫在重新激活后可能排毒较少，尽管疫苗接种是否减少重新激活可能性仍不清楚[4]。

通过持续的治疗干预可显著改善生活质量。长期L-赖氨酸补充（每日250-500mg）有助于减少发作性病毒重新激活[1]。泛昔洛韦在管理复发感染方面显示出前景，轶事报告建议每日一次给予125mg片剂的1/4至1/8，至少10天，可减少复发[1]。

最新研究显示幼猫的令人鼓舞的结果。接受泛昔洛韦的轻度疾病幼猫比接受标准治疗的幼猫早4-5天完全康复，且较少发展为角膜并发症[2]。然而，客户必须理解慢性鼻炎/鼻窦炎永远不会完全治愈，持续的管理侧重于症状控制和生活质量改善[9]。

### Sources
[1] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings
[2] Antiviral medication for feline herpes accelerates recovery in kittens with upper respiratory disease: https://www.dvm360.com/view/antiviral-medication-for-feline-herpes-accelerates-recovery-in-kittens-with-upper-respiratory-disease
[3] Snots and snuffles: chronic feline upper respiratory syndromes: https://www.dvm360.com/view/snots-and-snuffles-chronic-feline-upper-respiratory-syndromes-proceedings
[4] Feline viral respiratory disease: To vaccinate or not to vaccinate?: https://www.dvm360.com/view/feline-viral-respiratory-disease-vaccinate-or-not-vaccinate-proceedings
