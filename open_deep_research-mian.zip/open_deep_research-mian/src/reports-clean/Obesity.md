# 宠物疾病：肥胖症

肥胖症已成为当今兽医实践中影响伴侣动物的最普遍营养性疾病。在猫中的患病率高达60%，在狗中为56%，这一流行病代表着一场严重的健康危机，显著影响动物的寿命和生活质量。本综合报告将肥胖症作为一种复杂的代谢疾病进行探讨，探索其多因素病因、临床表现和基于证据的管理策略。分析涵盖了使用体况评分系统的诊断方法、结合饮食管理和药物选择的治疗干预，以及预防措施在对抗小动物实践中这一日益增长的健康威胁中的关键作用。

## 摘要

本报告揭示肥胖症是一种影响超过一半伴侣动物的复杂代谢性疾病，对兽医实践具有重要意义。主要研究结果表明，肥胖症使狗的寿命缩短约2年，同时使动物易患糖尿病、骨科疾病和免疫功能下降。与传染病不同，肥胖症源于能量失衡而非病原体，尽管它会造成免疫功能受损状态，增加感染易感性。

成功的治疗需要多模式方法，结合限制热量的治疗性饮食、结构化运动计划和行为的改变。9分制体况评分系统提供可靠的诊断，而使用地洛他肽的药物干预为狗提供了额外的选择。专注于绝育后饮食调整和份量控制的预防策略被证明是最有效的。

关键的鉴别诊断包括甲状腺功能减退症、肾上腺皮质功能亢进症和糖尿病 mellitus，需要仔细的实验室评估。在主人坚持配合的情况下，预后仍然良好，但长期成功需要永久性的生活方式改变，而非临时干预。鉴于其流行比例和严重的健康后果，肥胖症管理代表着综合兽医护理的重要组成部分，需要立即关注和持续的干预策略。

## 疾病概述

伴侣动物的肥胖症被定义为由于长期正能量平衡导致的脂肪组织过度堆积[1]。狗的体重超过理想体重15%时被视为超重，超过理想体重30%时被视为肥胖[2]。同样，猫根据评估脂肪组织分布的体况评分系统被分类为超重或肥胖。

在发达国家，狗和猫的肥胖症患病率已达到流行程度。目前估计表明，美国有24-44%的狗和猫超重或肥胖[3]。最近的调查显示，到2018年，有60%的猫和56%的狗被归类为超重或肥胖，增长惊人[4]。来自不同地区的研究报告显示，狗的患病率在22-40%之间，成年猫约为35%，而在10-11岁的老年猫中观察到更高的比率（45%）[5]。

风险因素包括品种易感性（狗中的拉布拉多寻回犬、金毛寻回犬、可卡犬；猫中的混血猫和曼岛猫）、绝育状态（通过降低25%的新陈代谢率增加风险）、年龄增长、体力活动减少和不适当的喂养方式[6]。环境因素如公寓居住、主人的喂养行为和高适口性的商业食品对这一流行病有显著贡献[7]。

### Sources
[1] Obesity (Proceedings): https://www.dvm360.com/view/obesity-proceedings
[2] Obesity: Health risks and management in dogs and cats (Proceedings): https://www.dvm360.com/view/obesity-health-risks-and-management-dogs-and-cats-proceedings
[3] Obesity management traditional and new approaches (Proceedings): https://www.dvm360.com/view/obesity-management-traditional-and-new-approaches-proceedings
[4] The pet obesity epidemic: are we loving our pets to death?: https://www.dvm360.com/view/the-pet-obesity-epidemic-are-we-loving-our-pets-to-death-
[5] Obesity: Health risks and management in dogs and cats (Proceedings): https://www.dvm360.com/view/obesity-health-risks-and-management-dogs-and-cats-proceedings
[6] Obesity in dogs, Part 1: Exploring the causes and consequences of canine obesity: https://www.dvm360.com/view/obesity-dogs-part-1-exploring-causes-and-consequences-canine-obesity
[7] Obesity: the skinny on fat (Proceedings): https://www.dvm360.com/view/obesity-skinny-fat-proceedings

## 常见病原体

与许多传染病不同，狗和猫的肥胖症主要不是由病毒或细菌病原体引起的。肥胖症从根本上说是一种由慢性能量失衡引起的代谢紊乱，而非传染过程[1]。

然而，某些病原体可能间接导致肥胖症发展或使体重管理复杂化。继发性细菌感染是肥胖宠物常见的并发症，因为它们的免疫功能受损[2]。肥胖动物对细菌和真菌感染的抵抗力下降，经常发展为慢性或复发性疾病，如膀胱炎、皮炎和呼吸道感染[2]。

病原体与肥胖之间的关系通常是双向的。肥胖通过脂肪因子介导的慢性炎症造成免疫功能受损状态，使宠物更容易受到机会性感染[1]。相反，慢性感染可能触发反调节激素释放，可能加重代谢功能障碍和胰岛素抵抗[3]。

压力相关因素，包括引起慢性炎症的环境病原体，可能通过激素紊乱间接导致体重增加[3]。此外，用于治疗传染病的药物，特别是糖皮质激素和某些抗生素，可能使动物易患体重增加和代谢并发症[2]。

虽然没有特定的病毒或细菌因子直接导致肥胖症，但临床医生应考虑到肥胖患者需要仔细监测继发性感染，并且成功的体重管理可能改善免疫功能并降低感染易感性。

### Sources

[1] Obesity in dogs, Part 1: Exploring the causes and consequences of canine obesity: https://www.dvm360.com/view/obesity-dogs-part-1-exploring-causes-and-consequences-canine-obesity

[2] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats

[3] Discovering the reasons underlying difficult-to-control diabetes in cats: https://www.dvm360.com/view/discovering-reasons-underlying-difficult-control-diabetes-cats

## 临床症状和体征

狗和猫肥胖症的临床表现特征是脂肪组织过度堆积，通常定义为两个物种的体重超过理想体重20%以上[1]。体重超过理想体重10-20%的动物被视为超重[1]。体格检查揭示了最明显的表现：可见和可触及的覆盖肋骨、腹部和其他身体区域的多余脂肪。

**典型体征**
患有肥胖症的狗和猫通常表现为运动耐力下降、嗜睡和正常体力活动困难[1][4]。由于多余脂肪组织的隔热特性，不耐热很常见。呼吸变化可能包括运动不耐力、活动时呼吸困难，在严重情况下，出现肥胖性低通气综合征[3][4]。

**品种特异性模式**
某些狗品种表现出更高的肥胖易感性，包括拉布拉多寻回犬、凯恩梗、骑士查理王小猎犬、苏格兰梗、腊肠犬、比格犬和可卡犬[1][3][4]。这些品种可能比其他品种更早或更严重地出现肥胖。相反，视觉猎犬似乎对肥胖发展具有天然抵抗力[3][4]。在猫中，混血猫被发现比纯种猫有更高的超重风险[6]。

**继发性并发症**
肥胖动物经常发展为继发性健康问题，这些成为其临床表现的一部分。这些问题包括表现为跛行或不愿活动的骨科问题、因无法正常梳理引起的皮肤病问题以及某些母犬的尿失禁[3][4]。与多余脂肪组织相关的慢性炎症状态导致各种代谢紊乱，可能表现为并发的临床症状[3][4]。

### Sources
[1] Nutrition in Disease Management in Small Animals: https://www.merckvetmanual.com/management-and-nutrition/nutrition-small-animals/nutrition-in-disease-management-in-small-animals
[2] Diabetes Mellitus in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[3] The pet obesity epidemic: are we loving our pets to death?: https://www.dvm360.com/view/the-pet-obesity-epidemic-are-we-loving-our-pets-to-death-
[4] Obesity in dogs, Part 1: Exploring the causes and consequences of canine obesity: https://www.dvm360.com/view/obesity-dogs-part-1-exploring-causes-and-consequences-canine-obesity
[5] Hypothyroidism in Animals - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[6] Is that cat too fat? Feline obesity and a program for weight loss (Proceedings): https://www.dvm360.com/view/cat-too-fat-feline-obesity-and-program-weight-loss-proceedings

## 诊断方法

诊断狗和猫的肥胖症依赖于临床评估工具和体况评分系统的组合[1]。体况评分（BCS）是兽医实践中最实用和最广泛使用的诊断方法。经验证的9分制BCS系统最常用，其中每分代表大约10-15%的体重，6-7/9分表示超重，8-9/9分表示肥胖[1][2]。

9分制BCS、5分制BCS和S.H.A.P.E.（体型、健康和身体评估）系统是有效的工具，当由经过培训的人员执行时，与双能X射线吸收测量法（DEXA）有良好的相关性[1]。BCS评估涉及对特定解剖位置（包括肋骨笼、腰部、腹部和腰围）的脂肪沉积进行视觉和触觉评估[1][2]。

肌肉状况评分（MCS）应与BCS同时使用，以评估肌肉质量并检测可能在超重动物中发生的肌肉萎缩[1]。先进的诊断方法如DEXA、CT和MRI可以提供精确的身体成分测量，但由于成本和设备要求，在常规实践中不常用[1]。

基础实验室检测可能包括全血细胞计数和生化面板，以排除可能导致体重增加的潜在内分泌疾病，如甲状腺功能减退症或肾上腺皮质功能亢进症[5][7][8]。

### Sources
[1] The importance of assessing body composition of dogs and cats: https://avmajournals.avma.org/view/journals/javma/251/5/javma.251.5.521.xml
[2] Fight the giant: https://www.dvm360.com/view/fight-giant
[3] Study Suggests Fatter Cats May Live Longer: https://www.dvm360.com/view/study-suggests-fatter-cats-may-live-longer/1000
[4] Evaluation of the use of muscle condition score: https://avmajournals.avma.org/view/journals/ajvr/80/6/ajvr.80.6.595.xml
[5] Obesity in dogs, Part 1: https://www.dvm360.com/view/obesity-dogs-part-1-exploring-causes-and-consequences-canine-obesity
[6] Diagnostic laboratory medicine: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.263.s1.s4.xml
[7] Types of Veterinary Medical Tests: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/types-of-veterinary-medical-tests
[8] Laboratory Tests Routinely Performed: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/laboratory-tests-routinely-performed-in-veterinary-medicine

## 治疗选择

有效的肥胖症管理需要多方面的方法，结合饮食治疗、运动计划、行为改变和可能的药物干预[1]。饮食干预是治疗的基石，利用专门配制的治疗性减肥饮食，这些饮食限制脂肪和能量，同时保持足够的蛋白质水平以保留瘦体重[1]。

运动计划应个体化定制并与饮食治疗相结合以最大化效果[1]。合适的活动包括低冲击步行、游泳、水疗和猫的互动游戏[6]。物理康复可以帮助保持肌肉质量，同时增加能量消耗[10]。

使用地洛他肽（Slentrol）的药物干预仅适用于狗，其作为微粒体甘油三酯转移蛋白抑制剂，可减少食欲并减少脂肪吸收[6]。由于肝脂质沉积的担忧，该药物禁用于猫。

行为改变至关重要，解决与食物相关的态度和主人的喂养习惯[1]。许多宠物因喂养过程中的社交纽带而超重，需要用低热量零食和活动替代高热量奖励[1]。

每2-4周进行一次体重评估的定期监测可确保最佳进展，目标体重减轻为每周体重的1-2%[1]。坚持需要控制所有热量来源，包括限制在每日摄入量10%以内的零食，并解决导致过量卡路里消耗的环境因素[9]。

### Sources

[1] Obesity in dogs, Part 2: Treating excess weight with a multiple-modality approach: https://www.dvm360.com/view/obesity-dogs-part-2-treating-excess-weight-with-multiple-modality-approach

[6] Managing weight loss in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-weight-loss-dogs-and-cats-proceedings

[9] Successful weight loss programs (Proceedings): https://www.dvm360.com/view/successful-weight-loss-programs-proceedings

[10] Obesity and orthopedic disease: a relationship to remember: https://www.dvm360.com/view/obesity-and-orthopedic-disease-relationship-remember

## 预防措施

有效的肥胖症预防需要结合喂养管理、环境控制和早期干预策略的综合方法。绝育后饮食管理至关重要，因为绝育宠物比未绝育动物需要少25-33%的卡路里[1]。兽医团队应在手术时向主人咨询关于减少卡路里摄入，以防止在这个高风险期间体重增加。

喂养实践在预防中起着核心作用。使用每天两次提供的预先测量的餐食进行份量控制喂养，可以防止大多数狗变得肥胖[2]。完整和均衡的零食产品应仅占总每日卡路里的10%，以防止营养缺乏[2]。多次小餐有助于模拟自然狩猎行为，同时控制份量[3]。

每次兽医就诊时进行定期体况评分，可以在肥胖症发展之前进行早期检测和干预[4]。经验证的9分制体况评分系统与测量体脂的双能X射线吸收测量法有很强的相关性，并为兽医团队提供一致的评估[4]。

环境丰富化至关重要，特别是对于缺乏自然运动机会的室内猫[1]。互动玩具、笔灯和狩猎喂食器鼓励身体活动。对于狗，应尽早建立定期步行和低冲击运动计划。

主人教育是成功预防的基础。许多主人低估了宠物的实际食物摄入量，因此完整的饮食史和预先称量的食物份量比主人测量的份量更有效[3]。生长曲线图可用于监测幼犬发育，确保健康的生长模式，从而降低日后肥胖风险[3]。

### Sources
[1] Caring for the emotional well-being of animals: https://www.dvm360.com/view/caring-for-the-emotional-well-being-of-animals
[2] Feeding Practices in Small Animals: https://www.merckvetmanual.com/management-and-nutrition/nutrition-small-animals/feeding-practices-in-small-animals
[3] How Does Your Dog Measure Up? New Growth Charts Could Provide the Answer: https://www.dvm360.com/view/how-does-your-dog-measure-up-new-growth-charts-could-provide-the-answer
[4] The importance of assessing body composition of dogs and cats and methods available for use in clinical practice: https://avmajournals.avma.org/view/journals/javma/251/5/javma.251.5.521.xml

## 鉴别诊断

狗和猫的肥胖症必须与几种表现出相似临床症状（特别是体重增加）的内分泌和代谢疾病进行鉴别[1]。甲状腺功能减退症经常被怀疑是肥胖狗的主要鉴别诊断，但常常被过度诊断，许多狗尽管补充了甲状腺激素仍未能减轻体重[1]。鉴别特征包括总T4低、通过平衡透析测量的游离T4浓度低以及TSH浓度升高，尽管在某些甲状腺功能减退的狗中TSH可能保持正常[1]。

肾上腺皮质功能亢进症（库欣综合征）是一个关键的鉴别诊断，因为它经常与肥胖症和糖尿病 mellitus 共存[2][3]。患有并发肾上腺皮质功能亢进症的狗尽管使用大剂量胰岛素仍表现出超过400 mg/dL的持续性高血糖、尿皮质醇:肌酐比值升高以及特征性临床症状，包括烦渴、贪食和肌肉无力[2][3]。

糖尿病 mellitus 本身可能与单纯肥胖症混淆，但其区别在于持续性高血糖、糖尿和果糖胺浓度升高[4]。肥胖和糖尿病之间的关系是复杂的，肥胖使动物易患胰岛素抵抗和糖尿病发展[5]。其他鉴别诊断包括在发情后期未绝育母犬中的肢端肥大症，这会导致生长激素诱导的胰岛素抵抗[6]，以及可能影响代谢调节的各种传染病。

### Sources
[1] Merck Veterinary Manual Hypothyroidism in Animals - Endocrine System - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[2] Merck Veterinary Manual Cushing Disease (Pituitary-Dependent Hyperadrenocorticism) in Animals - Endocrine System - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-pituitary-gland/cushing-disease-pituitary-dependent-hyperadrenocorticism-in-animals
[3] DVM 360 Hyperadrenocorticism and Diabetes in Dogs: https://www.dvm360.com/view/hyperadrenocorticism-and-diabetes-in-dogs
[4] Merck Veterinary Manual Diabetes Mellitus in Dogs and Cats - Endocrine System - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[5] DVM 360 Obesity as an endocrine disease (Proceedings): https://www.dvm360.com/view/obesity-endocrine-disease-proceedings
[6] DVM 360 Identifying the reasons behind difficult-to-control diabetes in dogs: https://www.dvm360.com/view/identifying-reasons-behind-difficult-control-diabetes-dogs

## 预后

狗和猫肥胖症的预后在适当的体重管理下通常是有利的，尽管长期成功需要持续的生活方式改变[1]。使用传统卡路里限制和运动方法的减肥计划在正确实施和监测时通常能取得成功的结果[1]。然而，治疗期间的体重平台期是常见的挑战，可能需要调整管理计划[1]。

保持瘦体况对寿命有深远的预后意义。研究表明，体况理想的狗比超重的狗大约多活2年，一项综合研究显示中位寿命延长15%[2][3]。超重和肥胖的宠物面临早期死亡和严重健康并发症（包括糖尿病 mellitus 和骨关节炎）的显著增加风险[1]。对预期寿命的影响被认为是猫主人决定是否遵循兽医减肥建议的最重要因素[4]。

一些狗可能对传统体重管理方法没有反应，需要替代方法，如地洛他肽（Slentrol），尽管一旦停止治疗，体重可能反弹[1]。长期成功需要通过持续的卡路里限制和运动进行持续管理，即使在药物干预之后[1]。预后最终取决于主人对持续饮食和生活方式改变的承诺，因为肥胖症管理需要永久性的行为改变，而非临时干预。

### Sources
[1] Obesity management traditional and new approaches: https://www.dvm360.com/view/obesity-management-traditional-and-new-approaches-proceedings
[2] The pet obesity epidemic: are we loving our pets to death?: https://www.dvm360.com/view/the-pet-obesity-epidemic-are-we-loving-our-pets-to-death-
[3] The importance of assessing body composition of dogs and cats: https://avmajournals.avma.org/view/journals/javma/251/5/javma.251.5.521.xml
[4] Information about life expectancy related to obesity is most: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.12.0703.xml
