# 伴侣动物尺骨骨干骨折

尺骨骨干骨折在小动物兽医实践中是一项重大的骨科挑战，涉及尺骨骨干中段的断裂。这些创伤性损伤通常由机动车事故、跌倒和高冲击创伤引起，需要及时诊断和适当治疗以恢复肢体功能。本报告探讨了犬猫尺骨骨干骨折的综合管理，涵盖流行病学模式、临床表现和诊断方法、从保守治疗到先进手术技术的当前治疗方法，以及预期结果和潜在并发症。理解这些骨折的复杂性对于兽医从业者优化患者护理和实现成功的功能恢复至关重要。

## 摘要

伴侣动物的尺骨骨干骨折需要全面评估和个体化治疗方法以获得最佳结果。疾病概述显示，这些骨折主要影响尺骨骨干中段，创伤是主要原因，而患者因素如年龄和体重会显著影响并发症风险。

临床诊断主要依靠放射影像学检查，此前体格检查发现急性跛行、疼痛和局部肿胀。必须仔细评估并发损伤，特别是桡骨骨折，因为这些骨骼之间存在功能关系。

治疗方法从稳定骨折的保守外部固定，到使用切开复位内固定、外骨骼固定器或板-杆结构等替代技术的手术干预。在适当的管理下，预后通常良好，但可能出现包括骨不连、畸形愈合和骨性融合等并发症。

| 治疗方法 | 愈合时间 | 并发症率 | 最佳应用 |
|-----------------|--------------|-------------------|------------------|
| 外部固定 | 6-12周 | 可变 | 稳定、最小移位的骨折 |
| 钢板ORIF | 9-12周 | 26%（22%轻微，3%严重） | 大多数骨干骨折 |
| 外固定器 | 6-12周 | 低 | 复杂/骨不连病例 |

成功的管理需要仔细考虑骨折特征、患者因素和手术专业知识，以最大限度地减少并发症并恢复功能性肢体使用。

## 疾病概述和流行病学

尺骨骨干骨折是犬猫前臂两块骨骼之一--尺骨骨干（骨干）的断裂。这些骨折涉及尺骨的中部，与近端或远端区域不同。尺骨与桡骨共同构成前臂的结构基础，在负重和前肢功能中起着至关重要的作用[1]。

关于伴侣动物尺骨骨干骨折特定发生率的流行病学数据在现有文献中有限。然而，骨折模式和易感性受多种因素影响，包括患者年龄、体重和活动水平。低体重和高龄已被确定为某些尺骨手术并发症的风险因素[1]。

尺骨骨干骨折的常见原因包括机动车事故、跌倒和高冲击损伤造成的创伤。骨折在骨干区域内的位置影响愈合潜力，因为皮质骨（在骨干中占主导地位）的愈合方式与干骺端区域的松质骨不同[2]。周围的软组织包膜和损伤机制显著影响初始骨折严重程度和随后的愈合反应[2]。骨性融合可继发于桡骨和尺骨骨折，形成包含两块骨骼的单个骨痂[3]。

### Sources

[1] Lower body weight and increasing age are significant risk factors: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0232.xml

[2] Changes in fracture treatment which help practitioners: https://www.dvm360.com/view/changes-fracture-treatment-which-help-practitioners-proceedings

[3] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings

## 临床表现和诊断

尺骨骨干骨折的临床症状总是包括急性跛行、疼痛和局限于前臂的肿胀[1]。体格检查通常显示在触诊断裂的尺骨骨干时有局部压痛，如果发生移位则可能出现不稳定性。患肢通常表现为负重跛行，其严重程度取决于骨折构型和移位程度。

诊断影像学检查对明确诊断至关重要。放射摄影术仍然是主要的诊断工具，可清晰显示骨折模式，包括简单、粉碎性、斜形、横向或螺旋形构型[1][2]。真正的头尾侧和内外侧放射投影对于准确评估骨折位置、移位和并发损伤至关重要。计算机断层扫描可用于复杂病例，以更好地描绘骨折模式并评估并发损伤[3]。

必须仔细评估并发损伤，特别是桡骨骨折，因为桡骨和尺骨作为双骨单位功能，需要同步愈合[4]。评估应包括肘关节和腕关节的相关创伤或不稳定性检查。

鉴别诊断包括其他创伤性疾病，如软组织损伤、关节脱位和其他长骨骨折[1]。将尺骨骨干骨折与骨骺损伤区分开来至关重要，特别是在未成熟动物中，生长板参与显著影响治疗方法和预后。

### Sources
[1] Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[2] Diagnostic Imaging: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging
[3] Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[4] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings

## 治疗方法

犬猫尺骨骨干骨折的治疗需要仔细评估骨折特征、患者因素和主人期望，以确定最佳管理策略。

**保守治疗**
对于具有良好愈合潜力的年轻动物，稳定、最小移位的骨折可考虑使用夹板进行外部固定[1]。这种方法相对便宜且无创伤，但需要每周更换绷带并仔细监测压疮或湿绷带引起的并发症[1]。

**手术技术**
使用骨板进行切开复位内固定（ORIF）是大多数尺骨骨干骨折的金标准，提供刚性稳定和解剖复位[2][3]。ORIF治疗的骨折中有26%出现并发症，其中22%为轻微并发症，3%为严重并发症[3]。

外骨骼固定器为复杂骨折提供了极好的多功能性，允许针以各种角度放置，以最大化在小碎片中的抓持力[1]。线性外固定器在治疗骨不连病例方面表现出特别的成功，没有系统骨折、裂纹或松动等并发症[4]。

**替代技术**
螺钉配合张力带钢丝代表了一种针对特定骨折类型的可行替代方案[5]。使用生物性骨合成原则的板-杆结构已在骨干骨折中显示出成功[6]。

**决策因素**
对于活跃、健康的犬，无论不稳定性程度如何，都倾向于手术干预，特别是在年轻动物中，早期干预可防止关节炎进展。低体重和高龄是某些手术后并发症的重要风险因素[7]。

### Sources
[1] Managing physeal and articular fractures (Proceedings) - dvm360: https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[2] Assessment of fracture healing after minimally invasive plate: https://avmajournals.avma.org/view/journals/javma/241/6/javma.241.6.744.xml
[3] Open reduction and cranial bone plate fixation of fractures: https://avmajournals.avma.org/view/journals/javma/250/12/javma.250.12.1419.xml
[4] Treatment of nonunion cases with linear external fixation in: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[5] Screw with tension band wiring method is an: https://avmajournals.avma.org/view/journals/ajvr/86/7/ajvr.24.12.0375.xml
[6] Biomechanical comparison of a 3.5-mm conical coupling: https://avmajournals.avma.org/view/journals/ajvr/78/6/ajvr.78.6.712.xml
[7] Lower body weight and increasing age are significant risk: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0232.xml

## 预后和并发症

在适当治疗下，伴侣动物尺骨骨干骨折的预后通常良好，尽管有几个因素影响结果。愈合通常在6-12周内发生，年轻动物表现出更快的骨愈合率。大多数犬在术后两周内恢复肢体使用，骨折完全愈合通常在9-12周内实现[2]。

**并发症和风险因素**

常见并发症包括骨不连、延迟愈合、畸形愈合和植入物失败。低体重和高龄显著增加犬的并发症风险。桡骨和尺骨骨折后的骨性融合代表一种特定并发症，其中两骨之间的骨折骨痂形成阻止了生长过程中的正常滑动运动，可能导致异步生长畸形[1]。

**特定治疗结果**

微创钢板骨合成术（MIPO）与传统开放方法相比显示出优越的骨痂形成，一些病例早在4-6周就显示愈合[4]。可生物降解钢板在玩具犬种中显示出有希望的结果，11例中有10例在9-12周内实现愈合，没有放射学骨质疏松[2]。

**预后因素**

关键预后指标包括骨折构型、患者年龄、体重、手术技术选择和术后依从性。具有充分骨片间稳定的简单骨折通常无并发症愈合，而粉碎性骨折需要更长的愈合期并带来更高的并发症风险。

### Sources
[1] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings
[2] Repairing fractures by using biodegradable bone plates: https://www.dvm360.com/view/research-update-repairing-fractures-using-biodegradable-bone-plates
[3] Managing physeal and articular fractures: https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[4] Changes in fracture treatment which help practitioners: https://www.dvm360.com/view/changes-fracture-treatment-which-help-practitioners-proceedings
