# 伴侣动物甲状腺功能减退症：综合临床指南

甲状腺功能减退症是小动物兽医实践中最常见的内分泌疾病之一，尤其影响中大型中年犬。这种状况是由甲状腺激素缺乏引起的，影响多个器官系统，产生多样化的临床表现，可能对诊断准确性构成挑战。该疾病隐匿的起病和非特异性症状常常导致诊断延迟，因此系统性地了解其病理生理学、临床表现和治疗方案对兽医从业者至关重要。本报告探讨了目前基于证据的诊断和管理犬甲状腺功能减退症的方法，解决了常见的诊断陷阱、治疗策略和监测要求，以优化现代兽医实践中的患者预后。

## 疾病概述

甲状腺功能减退症是伴侣动物中常见的内分泌疾病，由甲状腺激素（T4和T3）缺乏引起[1]。这种状况在犬中**最常见**，但也罕见地发生在其他物种，包括猫和马[1]。

**分类和类型：**
原发性甲状腺功能减退症占犬临床病例的95%以上，由甲状腺腺体本身的破坏引起[1]。两个最常见的原因是淋巴细胞性甲状腺炎（免疫介导）和甲状腺腺体的特发性萎缩[1]。继发性甲状腺功能减退症不常见，通常由垂体功能障碍引起[1]。

先天性甲状腺功能减退症很少发生，可能是原发性（甲状腺性）或继发性（垂体性）[1]。在猫中，医源性甲状腺功能减退症是最常见的形式，通常在甲状腺功能亢进治疗后发生[1]。

**流行病学背景：**
甲状腺功能减退症通常影响4-10岁的犬，没有明显的性别偏好，尽管它通常影响中型到大型品种[1]。易感品种包括金毛寻回犬、杜宾犬、爱尔兰雪达犬、迷你雪纳瑞和腊肠犬[1]。在猫中，成年猫中自然发生的甲状腺功能减退症极为罕见[1]。

### Sources
[1] Hypothyroidism in Animals - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals

## 病因学和病理生理学

犬甲状腺功能减退症主要由甲状腺腺体通过两种主要病理过程破坏引起。**淋巴细胞性甲状腺炎**是一种免疫介导的疾病，是最常见的原因，其特征是淋巴细胞、浆细胞和巨噬细胞的弥漫性浸润，导致进行性滤泡破坏和继发性纤维化[1]。**特发性甲状腺萎缩**构成第二个主要原因，涉及甲状腺实质的丧失并被脂肪组织替代，没有炎症浸润[1][5]。

超过95%的犬甲状腺功能减退症病例来自获得性原发性甲状腺功能减退症，这两种机制占绝大多数病例[1][4][8]。由垂体TSH缺乏引起的继发性甲状腺功能减退症很少发生，通常由垂体肿瘤或畸形引起[8]。由下丘脑功能障碍引起的三发性甲状腺功能减退症在犬中尚未有记录[8]。

甲状腺激素缺乏的病理生理后果是广泛的，由于T3和T4在细胞代谢中的基本作用，几乎影响所有器官系统[5]。甲状腺激素水平降低导致基础代谢率降低、蛋白质合成改变以及碳水化合物、脂肪和蛋白质代谢紊乱[5]。这些代谢变化表现为特征性临床症状，包括嗜睡、体重增加和寒冷不耐。

先天性甲状腺功能减退症虽然罕见，但可能由甲状腺发育不全或激素生成障碍引起，在关键发育时期发生时导致不成比例的侏儒症和精神发育受损[5]。

### Sources
[1] Disorders of the thyroid gland (Proceedings): https://www.dvm360.com/view/disorders-thyroid-gland-proceedings
[2] Endocrinology | Veterinary News & Animal Health: https://www.dvm360.com/clinical/endocrinology?page=12
[3] Dermatology | Veterinary News & Animal Health: https://www.dvm360.com/clinical/dermatology?page=21
[4] Hypothyroidism in Animals - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[5] Disorders of the Thyroid Gland in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/hormonal-disorders-of-dogs/disorders-of-the-thyroid-gland-in-dogs
[6] Diagnosis and treatment of canine hypothyroidism: https://www.dvm360.com/view/diagnosis-and-treatment-canine-hypothyroidism-and-thyroiditis-proceedings

## 临床表现和诊断

甲状腺功能减退症呈现多变的临床表现，影响多个器官系统，这是由于甲状腺激素的广泛代谢影响[1]。临床症状通常是非特异性的，起病隐匿，使诊断具有挑战性[2]。

**代谢症状**：犬通常表现出嗜睡、精神迟钝、食欲未增加的体重增加、运动不耐和维持体温困难[1][2]。这些代谢效应反映了甲状腺激素缺乏特征性的细胞代谢降低。

**皮肤表现**：皮肤和被毛变化是最常见的临床症状，出现在约三分之二的甲状腺功能减退犬中[1][2]。这些包括影响躯干、颈部腹侧和尾部的双侧对称性脱毛；干燥、鳞状皮肤；毛发再生不良；和继发性脓皮症[2]。在严重病例中可能发生黏液性水肿，导致面部浮肿和皮肤褶皱增厚[3]。

**诊断方法**：总T4（TT4）作为初始筛查试验，灵敏度约为90%[1]。然而，由于非甲状腺疾病的影响，单独使用TT4特异性较差[1][4]。通过平衡透析法测定的游离T4（fT4 by EqD）提供更高的准确性和特异性，受非甲状腺因素的影响较小[1][4]。

**实验室检测挑战**：甲状腺功能正常的病综合征可显著降低全身性疾病犬的TT4浓度，使解释复杂化[3]。TSH测量在升高时支持诊断，但20-40%的甲状腺功能减退犬有正常的TSH浓度[3]。抗甲状腺球蛋白抗体可能干扰激素测量，需要通过平衡透析法测定fT4进行准确评估[3]。

**解释考虑因素**：品种特异性变异、药物（特别是NSAIDs）和并发疾病都可能影响甲状腺激素测量[4]。明确诊断需要临床怀疑，并辅以适当的甲状腺激素检测和对左甲状腺素治疗的反应[2]。

### Sources
[1] Understanding and diagnosing canine hypothyroidism: https://www.dvm360.com/view/understanding-and-diagnosing-canine-hypothyroidism
[2] Diagnosis and treatment of canine hypothyroidism and thyroiditis: https://www.dvm360.com/view/diagnosis-and-treatment-canine-hypothyroidism-and-thyroiditis-proceedings
[3] Hypothyroidism in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[4] Canine hypothyroidism: Shield your patients from overdiagnosis: https://www.dvm360.com/view/canine-hypothyroidism-shield-your-patients-overdiagnosis

## 治疗、管理和预后

**治疗方案**
合成左甲状腺素（T4）是甲状腺功能减退症的首选治疗方法[1]。推荐剂量为0.10 mg/10磅（20 μg/kg），每日一次[1]。这是对传统每日两次方案的显著更新，因为研究表明由于24小时细胞内转化过程，每日一次给药在生物学上是合适的[1]。

为获得一致的生物利用度，首选品牌制剂而非仿制药制剂[3]。患有并发心脏病的犬应从推荐剂量的50%开始，以防止代谢失稳[3]。对于有特殊需求的犬，也有液体甲状腺素制剂可用[5]。可以使用每日两次的给药开始治疗，在达到临床反应后转换为每日一次的治疗[5]。

**监测要求**
初始监测在治疗6周后进行，使用峰值（服药后4-6小时）或谷值（服药前）T4水平[2][5]。峰值水平应为高正常至轻度升高，而谷值水平应保持低正常[2][5]。通过平衡透析法测定的游离T4无论采样时间如何都能提供一致的读数，且受生物利用度变化的影响较小[1]。

甲状腺激素水平应在开始治疗后3个月和6个月进行评估，之后每6个月评估一次[2][5]。TSH测量可以补充监测先前基线TSH水平升高的犬[1]。

**管理和结果**
临床改善通常在2周内开始，症状完全解决需要4-6周[2]。皮肤变化可能需要几个月才能完全解决[2]。通过适当的治疗和监测，甲状腺功能减退犬有极好的预后[3]。定期监测确保最佳管理，并通过终身左甲状腺素补充维持正常的生活质量[1][5]。

### Sources
[1] Canine hypothyroidism: Supplementation and monitoring updates: https://www.dvm360.com/view/canine-hypothyroidism-supplementation-and-monitoring-updates
[2] Progress in the diagnosis and management of canine hypothyroidism: https://www.dvm360.com/view/progress-diagnosis-and-management-canine-hypothyroidism-proceedings
[3] Hypothyroidism in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[4] Diagnosis and treatment of canine hypothyroidism and thyroiditis: https://www.dvm360.com/view/diagnosis-and-treatment-canine-hypothyroidism-and-thyroiditis-proceedings
[5] Hypothyroidism in dogs (Proceedings): https://www.dvm360.com/view/hypothyroidism-dogs-proceedings
