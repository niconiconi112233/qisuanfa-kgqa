# 伴侣动物口腔嗜酸性肉芽肿

口腔嗜酸性肉芽肿是一种具有挑战性的免疫介导性疾病，影响犬和猫的口腔，其特征是炎症性病变，可显著影响生活质量。本临床综述全面检查了这种超敏反应的复杂病理生理学，该病在犬中主要影响北极品种和骑士查理王小猎犬，而在猫中则没有明显的品种倾向性。该报告综合了当前兽医知识中关于诊断方法的信息，从细胞学评估到专门的病理组织学技术，并探讨了基于证据的治疗方案，从皮质类固醇治疗到新型免疫抑制剂，为有效的临床管理和长期预防策略提供了基本指导。

## 疾病概述

口腔嗜酸性肉芽肿是嗜酸性肉芽肿复合体（EGC）的一种特定形式，主要影响猫和犬的口腔[1]。EGC代表炎症性皮肤反应，通常与超敏性疾病相关，其特征是嗜酸性粒细胞浸润组织[1]。

在猫中，口腔嗜酸性肉芽肿通常发生在口腔内，表现为丘疹至结节性病变[1]。该病也可能影响面部、下巴（猫下巴水肿）和脚垫[1]。尽管其名称如此，该病并不总是产生真正的肉芽肿，嗜酸性粒细胞脱颗粒产物覆盖但不改变胶原[1]。

流行病学显示，在猫中没有明显的年龄或品种倾向性，尽管一些报告表明雌性猫可能易患此病[4]。在犬中，口腔嗜酸性肉芽肿最常见于北极圈品种和骑士查理王小猎犬[1]。最常见的口腔病变包括嗜酸性溃疡和嗜酸性斑块，而线性肉芽肿在口腔中很少被识别[5]。

猫嗜酸性肉芽肿最常见于口腔或后腿呈线性分布[5]。据报道，猫的淋巴瘤和嗜酸性肉芽肿比犬更常见[1]。嗜酸性肉芽肿复合体影响犬和猫，在舌头、嘴唇和腭部引起隆起、溃疡性病变[2]。

该病最好被理解为一种超敏反应模式，而不是特定的疾病实体[3]。潜在原因可能包括食物过敏、跳蚤过敏性皮炎和异位性皮炎，尽管许多病例仍为特发性[1][4]。

### Sources

[1] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings

[2] O is for oral masses of the benign kind: https://www.dvm360.com/view/abcs-veterinary-dentistry-o-oral-masses-benign-kind

[3] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings

[4] Gingivitis, stomatitis, and other oral lesions (Proceedings): https://www.dvm360.com/view/gingivitis-stomatitis-and-other-oral-lesions-proceedings-0

[5] Diverse group of diseases culprits for feline eosinophilic granulomas: https://www.dvm360.com/view/diverse-group-diseases-culprits-feline-eosinophilic-granulomas

## 常见病原体

口腔嗜酸性肉芽肿没有特定的传染性病原体作为主要致病因子。与许多其他口腔疾病不同，该病代表一种免疫介导的超敏反应，而不是直接的传染过程[1]。

然而，几种病毒因子与猫口腔炎症性疾病相关，这些疾病可能复杂化或触发嗜酸性病变。猫疱疹病毒-1和猫杯状病毒通常与口腔炎症性疾病有关，其中杯状病毒在患有慢性口腔炎症的猫中尤为显著[2][3]。猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）也可能通过免疫抑制导致口腔炎症性疾病[2]。

细菌参与通常是原发性炎症过程的继发现象。机会性细菌感染可在溃疡性嗜酸性病变内发展，但细菌不被认为是该病的主要触发因素[1]。

真菌因子虽然作为嗜酸性肉芽肿的触发因素较少见，但已与包括嗜酸性粒细胞增多症的全身性疾病相关联。荚膜组织胞浆菌已在受影响犬和猫的中性粒细胞、单核细胞以及罕见的嗜酸性粒细胞中被记录[4]。隐球菌病和其他真菌感染可能在嗜酸性疾病的鉴别诊断中带来挑战，特别是当它们引起全身性嗜酸性粒细胞增多症时[3]。

最重要的致病因素是过敏原而非传染性因子。食物过敏原、包括花粉和尘螨在内的环境过敏原以及昆虫超敏反应（特别是跳蚤唾液）被认为是主要触发因素[5]。来自食碗或环境物质的接触过敏原也可能启动表征嗜酸性肉芽肿复合体的超敏反应[1]。

### Sources
[1] Gingivitis, stomatitis, and other oral lesions in cats (Proceedings): https://www.dvm360.com/view/gingivitis-stomatitis-and-other-oral-lesions-cats-proceedings
[2] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[3] Blindness and a history of cutaneous nodules in a cat: https://www.dvm360.com/view/challenging-case-blindness-and-history-cutaneous-nodules-cat
[4] Canine and feline histoplasmosis: A review of a widespread fungus: https://www.dvm360.com/view/canine-and-feline-histoplasmosis-review-widespread-fungus
[5] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings

## 临床症状和体征

现有部分内容准确捕捉了口腔嗜酸性肉芽肿的临床表现。默克兽医手册证实，犬口腔嗜酸性肉芽肿表现为口腔内"溃疡性或赘生性肿块，或隆起的斑块或结节"，西伯利亚哈士奇和骑士查理王小猎犬风险更高[1]。这些病变通常表现为"红色至黄色隆起结节，表面呈乳头状"[2]。

在猫中，该病表现为三种不同的变体。嗜酸性溃疡（惰性溃疡）表现为"边界清楚、单侧或双侧的侵蚀性至溃疡性病变，最常见于上唇"[10]。嗜酸性斑块表现为"剧烈瘙痒的渗出性病变，可出现在猫身体的任何部位"[10]。嗜酸性肉芽肿表现为"皮肤中的坚实结节"，变体包括后大腿的线性肉芽肿和影响下巴和嘴唇的"胖下巴"病变[10]。

默克手册强调，外周嗜酸性粒细胞增多症在各形式间有所不同，"在惰性溃疡中很少见"，但在"嗜酸性斑块中常见"[10]。这证实了早期关于三种猫变体之间嗜酸性粒细胞增多症差异模式的观察。

### Sources

[1] Eosinophilic Lesions in Dogs - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/eosinophilic-inflammatory-skin-diseases/eosinophilic-lesions-in-dogs
[2] Eosinophilic granuloma complex in cats and dogs (Proceedings): https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings
[3] Gingivitis, stomatitis, and other oral lesions (Proceedings): https://www.dvm360.com/view/gingivitis-stomatitis-and-other-oral-lesions-proceedings-0
[4] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[5] Eosinophilic Skin Diseases in Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/eosinophilic-inflammatory-skin-diseases/eosinophilic-skin-diseases-in-cats

## 诊断方法

临床表现评估构成口腔嗜酸性肉芽肿诊断的基础。在麻醉下进行彻底的口腔检查是必要的，因为在清醒猫中对口腔肿块进行细针抽吸通常是不可能的[1]。病变通常表现为上唇边界清楚的溃疡性病变或口腔其他部位的坚实结节性肿块[1]。

细胞学检查是最快、最具成本效益的诊断方法。从病变获得的印片显示主要是嗜酸性粒细胞炎症伴中性粒细胞[2]。Romanowsky型染色（Diff-Quick）可用于初步细胞学评估[1]。然而，单独细胞学可能显示局限性，因为外周嗜酸性粒细胞增多症仅在50-60%的病例中出现，且组织嗜酸性粒细胞增多症根据病变位置而异[3]。

组织病理学检查提供明确诊断，必须进行以区分嗜酸性肉芽肿与其他疾病[6]。在大多数情况下，建议进行切口活检用于诊断目的[4]。组织学上，局灶性嗜酸性肉芽肿显示围绕被嗜酸性粒细胞脱颗粒产物覆盖的胶原纤维的肉芽肿性炎症反应[5,6]。

特殊染色方法提高诊断准确性。过碘酸-雪夫（PAS）染色有助于排除可能模拟嗜酸性病变的真菌感染[2]。额外评估应包括蠕形螨的毛干检查、伍德灯检查以及在适当时进行皮肤癣菌培养[3]。

### Sources
[1] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[2] Differential diagnoses for draining tract lesions in dogs and ...: https://www.dvm360.com/view/differential-diagnoses-draining-tract-lesions-dogs-and-cats-proceedings
[3] Eosinophilic Skin Diseases in Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/eosinophilic-inflammatory-skin-diseases/eosinophilic-skin-diseases-in-cats
[4] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[5] Eosinophilic granuloma complex in cats and dogs ...: https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings
[6] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings

## 治疗选项

### 药物干预

**皮质类固醇**是口腔嗜酸性肉芽肿的主要免疫抑制治疗[1]。泼尼松龙方案通常涉及初始剂量1-2 mg/kg口服每24-48小时一次，逐渐减量至最低有效剂量[2]。注射用皮质类固醇如Depomedrol可每2周给药一次，共3次治疗[1]。

**免疫抑制剂**用于难治性病例。环孢素以5-7 mg/kg每日一次给药4-6周，通过钙调神经磷酸酶抑制和T细胞抑制有效治疗猫嗜酸性肉芽肿复合体[3]。硫唑嘌呤可以2 mg/kg每日一次使用2周，然后每48小时一次，尽管猫需要密切监测骨髓抑制[5]。苯丁酸氮芥以2 mg/m²每48小时一次提供另一种免疫抑制剂选择[5]。

**抗生素治疗**处理继发性细菌感染。Clavamox（阿莫西林-克拉维酸）和甲氧苄啶-磺胺（Ditrim 120mg）是常用处方药[1]。替代疗法包括α-干扰素以30-60单位口服每日一次，给药7天，停药7天[1]。

### 非药物方法

**饮食管理**涉及排除饮食以识别和避免食物过敏原，特别是猫中的牛肉、鱼和奶制品[6]。**手术干预**可能包括CO₂激光手术切除病变[1]。环境改变如使用陶瓷或不锈钢食碗和处理潜在过敏提供支持性护理。

### Sources

[1] Feline dermatology (Proceedings): https://www.dvm360.com/view/feline-dermatology-proceedings
[2] Excessive Immune Function in Animals: https://www.merckvetmanual.com/immune-system/immunologic-diseases/excessive-immune-function-in-animals
[3] A busy clinician's review of cyclosporine: https://www.dvm360.com/view/busy-clinicians-review-cyclosporine
[5] Drugs Used to Treat Inflammatory Bowel Disease in Monogastric Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-digestive-system/drugs-used-to-treat-inflammatory-bowel-disease-in-monogastric-animals
[6] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis

## 预防措施

口腔嗜酸性肉芽肿的有效预防集中在识别和消除潜在过敏触发因素。通过环境评估和详细饮食史收集进行综合过敏原识别构成预防护理的基础[1][2]。

环境控制措施包括实施严格的跳蚤预防方案，因为跳蚤过敏性皮炎通常触发嗜酸性反应。每月外用跳蚤预防剂结合定期吸尘和场所处理的环境跳蚤控制显著减少过敏发作[1][4]。治疗所有接触动物对于最大控制至关重要。

饮食管理需要仔细选择含有新型蛋白质或水解蛋白质的低过敏性饮食。持续4-6周的排除饮食有助于识别食物过敏原，由于质量控制标准，处方饮食优于非处方选择[2][5]。常见过敏原如牛肉、鸡肉、奶制品和小麦应在易感患者中避免。相关蛋白质之间可能发生交叉反应，需要全面的饮食限制。

长期监测方法涉及定期口腔检查以检测早期病变发展和评估治疗反应[1][3]。食物过敏患者需要终身饮食管理和定期监测。环境过敏原避免策略，包括空气过滤和定期清洁，有助于最大限度地减少对屋尘螨和花粉的暴露。过敏原免疫治疗在异位性猫中可能提供极好的预防益处，反应率约为50%[3][4]。

### Sources

[1] ACVC 2016: Feline Skin Syndromes - The Frustrating Feline Triad & More: https://www.dvm360.com/view/feline-skin-syndromes-the-frustrating-feline-triad-and-more
[2] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings
[3] Cats can itch too! Feline pruritic diseases and treatment (Proceedings): https://www.dvm360.com/view/cats-can-itch-too-feline-pruritic-diseases-and-treatment-proceedings
[4] Having a complex over eosinophilic granuloma complex? (Proceedings): https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[5] Food hypersensitivity in the dog and cat: now what do I feed? (Proceedings): https://www.dvm360.com/view/food-hypersensitivity-dog-and-cat-now-what-do-i-feed-proceedings

## 鉴别诊断

口腔嗜酸性肉芽肿必须与几种具有重叠临床和组织学特征的疾病区分开来。恶性肿瘤代表主要的鉴别诊断，包括鳞状细胞癌（猫中最常见的口腔肿瘤，占60-80%的病例）、纤维肉瘤（占口腔肿瘤的10-20%）和黑色素瘤[1][2]。这些肿瘤通常表现为溃疡性口腔肿块，使视觉区分具有挑战性。

非肿瘤性疾病也需要考虑。疱疹病毒皮炎产生持续性溃疡性面部病变伴嗜酸性粒细胞浸润，组织病理学上可能显示病毒包涵体[3]。浆细胞性足皮炎虽然主要影响脚垫，但可能涉及口腔组织，并显示大量浆细胞浸润而非嗜酸性肉芽肿性炎症[3]。

明确诊断依赖于组织病理学检查，因为仅凭临床表现无法可靠地区分嗜酸性肉芽肿与其模拟疾病[6]。区分嗜酸性肉芽肿的关键组织学特征包括伴嗜酸性粒细胞覆盖胶原纤维的肉芽肿性皮炎，而鳞状细胞癌显示不规则上皮索伴角化[4]。与感染性肉芽肿不同，嗜酸性肉芽肿通常在特殊染色上缺乏微生物并对抗炎治疗有反应[6]。

### Sources

[1] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[2] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[3] ACVC 2017: Understanding Skin Disease in Cats: https://www.dvm360.com/view/understanding-skin-disease-in-cats
[4] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[5] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[6] Eosinophilic granuloma complex in cats and dogs (Proceedings): https://www.dvm360.com/view/eosinophilic-granuloma-complex-cats-and-dogs-proceedings

## 预后

当实施适当治疗并确定潜在原因时，口腔嗜酸性肉芽肿的预后通常良好[1]。当可以确定和控制潜在过敏原因时，病变通常永久消退，除非动物再次遇到致敏过敏原[1]。大多数病变表现出有或无治疗时的波动模式，使不可预测的复发模式成为该病的特征[1]。

治疗反应根据病变类型和治疗方法而异。嗜酸性斑块对抗生素治疗显示出极好反应，研究表明病变大小减少96.2%[2]。异位性猫对脱敏治疗的反应范围为50-75%，大多数猫在三至六个月内显示改善[3]。必需脂肪酸在四个嗜酸性肉芽肿病例中产生阳性结果，但在嗜酸性斑块中未显示益处[1]。

该病代表终身管理挑战而非可治愈疾病[4]。早期诊断和治疗对最佳结果很重要[5]。通过适当治疗可实现完全病变消退，但一旦病变消退，药物剂量应减量至最低可能水平[1]。

长期管理考虑包括监测复发和处理易感因素如并发过敏、跳蚤控制和环境触发因素。接受慢性皮质类固醇治疗的猫需要定期监测糖尿病，糖尿病可能因频繁甲基强的松龙注射而发生[1]。

### Sources

[1] Diverse group of diseases culprits for feline eosinophilic granulomas: https://www.dvm360.com/view/diverse-group-diseases-culprits-feline-eosinophilic-granulomas
[2] Journal Scan: Tackling feline eosinophilic plaques with antibiotics: https://www.dvm360.com/view/journal-scan-tackling-feline-eosinophilic-plaques-with-antibiotics  
[3] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis
[4] Having a complex over eosinophilic granuloma complex?: https://www.dvm360.com/view/having-complex-over-eosinophilic-granuloma-complex-proceedings
[5] a retrospective study of 38 cases: https://avmajournals.avma.org/view/journals/javma/261/S2/javma.23.06.0312.xml
