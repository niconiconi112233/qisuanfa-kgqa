# 伴侣动物的吸入性肺炎

吸入性肺炎是兽医临床中最危急的呼吸道急症之一，发生在胃肠道内容物被吸入犬猫肺部时。这种情况在消化系统和呼吸系统之间形成了危险的交叉，通常在反流、呕吐或麻醉并发症后迅速发展。虽然犬面临的风险显著高于猫，短头颅品种的易感性增加四倍，但77%的整体存活率表明，及时识别和适当治疗可以带来良好的预后。本综合分析探讨了管理这种潜在致命疾病所需的复杂病理生理学、诊断挑战和循证治疗方案。

## 疾病概述

吸入性肺炎定义为因胃肠道内容物吸入肺部而引起的肺实质炎症[1]。这种情况代表了兽医学中最常见的呼吸道与消化道之间的病理学联系[1]。

吸入性肺炎可表现为吸入性肺炎（仅为炎症）或真正的吸入性肺炎（炎症伴有继发性细菌感染）[2]。炎症的严重程度取决于吸入物质的体积、成分和pH值[2]。

虽然全面的流行病学数据仍然有限，但研究表明，77%的吸入性肺炎犬能够存活至出院[3]。短头颅品种面临特别高的风险，这些犬的吸入性肺炎风险是其他患者的四倍[4][5]。

最常见的诱发条件包括食管疾病（39%的病例）、引起呕吐的疾病（38%）和神经系统疾病（27%）[3]。引起巨食道的重症肌无力是食管和神经系统疾病类别中最常见的潜在诊断[3]。其他风险因素包括喉功能障碍、麻醉后并发症和品种特异性解剖倾向[2][3]。

猫患吸入性肺炎的频率远低于犬，而细菌性肺炎在其他健康的伴侣动物中很少见[6]。

### Sources

[1] Aspiration-related respiratory disorders in dogs: https://avmajournals.avma.org/view/journals/javma/253/3/javma.253.3.292.xml
[2] Aspiration Pneumonia in Pets and People: https://www.dvm360.com/view/aspiration-pneumonia-in-pets-and-people/1000
[3] Common disorders associated with aspiration pneumonia: https://www.dvm360.com/view/research-updates-common-disorders-associated-with-aspiration-pneumonia-dogs-and-influence-underlying
[4] The latest surgical options for brachycephalic obstructive: https://www.dvm360.com/view/latest-surgical-options-brachycephalic-obstructive-airway-syndrome
[5] Canine infectious respiratory disease: https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings
[6] Bacterial pneumonia (Proceedings): https://www.dvm360.com/view/bacterial-pneumonia-proceedings

## 常见病原体

犬猫的吸入性肺炎主要由混合细菌种群引起，主要包括革兰氏阴性需氧菌和厌氧生物[1]。最常见的分离革兰氏阴性病原体包括克雷伯氏菌、假单胞菌、肠杆菌、变形杆菌和大肠杆菌种类[1]。

厌氧菌起着特别重要的作用，占小动物细菌性肺炎病例的25%[2]。除非采用特定的厌氧培养方法，这些生物在常规诊断培养中常被忽视[2]。常见的厌氧病原体包括来自口咽腔的杆状细菌[1]。

口咽共生菌常参与吸入性肺炎的发病机制。犬猫的正常鼻腔和口腔菌群包括各种细菌，如表皮葡萄球菌、非溶血性链球菌种类和棒状杆菌[4]。当被吸入时，这些通常为共生生物在下呼吸道环境中可变得具有致病性。

混合需氧、微需氧和厌氧细菌生物通常被报道为猫肺炎的原因，常表现为杆状形态[1]。类似西蒙斯氏菌的细菌（已知为犬猫的咽部栖息者）也可能参与其中[3]。

吸入性肺炎的多微生物性质反映了口咽部存在的多样化细菌种群，当通过吸入事件引入无菌下气道时，这些细菌变得具有致病性。

### Sources

[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/261/1/javma.22.06.0252.xml
[2] Airway lavage (Proceedings): https://www.dvm360.com/view/airway-lavage-proceedings
[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/69/5/ajvr.69.5.572.xml
[4] Nasal disorders in the dog and cat (Proceedings): https://www.dvm360.com/view/nasal-disorders-dog-and-cat-proceedings

## 临床症状和体征

吸入性肺炎在犬猫中表现为特征性的呼吸系统和全身临床表现。初始体征通常与导致吸入的原发疾病过程相关[1]。嗜睡和厌食是常见的早期发现[1]。

呼吸道体征包括干性非 productive 咳嗽和湿性 productive 咳嗽[1]。患者可能出现发热、白细胞增多和呼吸窘迫，在严重情况下可能进展为需要氧疗或机械通气的低氧血症[1]。呼吸困难或呼吸急促、运动不耐受和呼吸急促是常见表现[3,4]。

体格检查显示特定的听诊发现。在肺实变存在的地方可检测到湿啰音或浊音区[1]。在更严重的情况下，呼吸音减弱或几乎听不到[4]。蓝色黏膜表示因氧合不良引起的发绀[3,4]。

可能发展出特征性的甜味、异味呼吸，随着疾病进展变得更加浓烈[3,4]。这通常伴有鼻分泌物，可能呈红棕色或绿色[3,4]。偶尔，可以在鼻分泌物或咳出物质中识别出吸入物质的证据，如油滴[3,4]。

猫对无味产品如矿物油引起的吸入性肺炎特别敏感[3]。提示异物吸入的病史仍然是最重要的诊断线索[3,4]。在观察到或怀疑反流发作后急性发作呼吸窘迫是常见现象[7]。

### Sources
[1] Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] Aspiration Pneumonia in Large Animals - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/aspiration-pneumonia-in-large-animals/aspiration-pneumonia-in-large-animals
[3] Pneumonia in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/pneumonia-in-cats
[4] Pneumonia in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[5] Etiology and clinical outcome in dogs with aspiration ... - AVMA: https://avmajournals.avma.org/view/journals/javma/233/11/javma.233.11.1748.xml

## 诊断方法

吸入性肺炎的诊断依赖于临床表现、影像学发现和气道采样技术的组合[1]。诊断方法必须系统化，因为吸入性肺炎在兽医学中缺乏特定的生物化学标志物[1]。

**临床表现评估**
诊断需要识别观察到或怀疑的反流/呕吐发作，随后急性发作呼吸困难、咳嗽或呼吸急促[1]。与下呼吸道疾病一致的体格检查发现支持诊断，特别是当结合识别诱发条件时，包括麻醉、食管功能障碍、喉部疾病或意识水平降低[1]。

**放射学评估** 
胸部X光显示具有颅腹侧分布的特征性肺泡模式，通常影响右前叶、右中叶和左前肺叶[5]。关键放射学体征包括空气支气管征、叶征和轮廓效应[5]。放射学变化的严重程度有助于评估疾病程度，尽管它可能与临床结局没有直接相关性[1]。

**高级影像学**
高分辨率CT和支气管镜检查在可用时提供额外的诊断信息[3]。与常规X光相比，CT提供更优越的细节来识别支气管扩张和评估疾病分布[3]。

**气道采样**
气管内冲洗、支气管肺泡灌洗或气管内冲洗可获得细胞学和细菌培养的样本[8,9]。细胞学评估通常显示中性粒细胞炎症伴有变性中性粒细胞[10]。定量细菌培养有助于区分真正感染和污染，生长>1.7 x 10³ CFU/ml被认为是显著的[9]。需氧和厌氧培养都是必要的，因为高达25%的细菌性肺炎涉及厌氧病原体[8]。

### Sources
[1] Etiology and clinical outcome in dogs with aspiration pneumonia: https://avmajournals.avma.org/view/journals/javma/233/11/javma.233.11.1748.xml
[2] Aspiration-related respiratory disorders in dogs: https://avmajournals.avma.org/view/journals/javma/253/3/javma.253.3.292.xml
[3] Radiographic evaluation of pulmonary patterns and disease: https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[4] Airway lavage: https://www.dvm360.com/view/airway-lavage-proceedings
[5] Diagnosing and managing canine eosinophilic bronchopneumopathy: https://www.dvm360.com/view/diagnosing-and-managing-canine-eosinophilic-bronchopneumopathy

## 治疗选择

吸入性肺炎治疗需要多模式方法，将抗菌治疗与积极的支持性护理措施相结合[1]。与许多肺炎病例不同，抗生素通常是犬吸入性肺炎的一线治疗，因为吸入物质中细菌定植的可能性很高[1]。

**抗菌治疗**  
通常在没有培养结果的情况下开始经验性广谱抗生素组合。有效方案包括氨苄西林联合氟喹诺酮类或氨基糖苷类用于住院患者[2]。对于稳定、血氧正常的患者，口服选择包括阿莫西林/克拉维酸、氟喹诺酮类或甲氧苄啶-磺胺[2]。在严重病例中，治疗时间通常延长2-3个月，在放射学解决后继续2周[4]。

**支持性护理**  
氧疗对低氧血症患者至关重要，通过氧舱或鼻导管以40-60%浓度输送[3][5]。高渗盐水雾化帮助移动呼吸道分泌物并改善气道清除[1]。通过静脉输液充分补水防止分泌物干燥，促进咳出[4]。

**监测和护理**
密切监测包括脉搏血氧饱和度（维持SpO2 >90%）和住院期间每3-4天定期胸部X光检查[4][5]。叩诊（胸部叩击）刺激 productive 咳嗽，而控制性运动促进分泌物清除[4]。营养支持和通过促动力药物或鼻胃管预防进一步吸入至关重要[5]。

### Sources
[1] Aspiration Pneumonia in Pets and People: https://www.dvm360.com/view/aspiration-pneumonia-in-pets-and-people/1000
[2] Rational antibiotic choices for bacterial pneumonia in dogs (Proceedings): https://www.dvm360.com/view/rational-antibiotic-choices-bacterial-pneumonia-dogs-proceedings
[3] Pneumonia in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/pneumonia-in-dogs
[4] Treating canine bacterial pneumonia: Beyond antibiotics (Proceedings): https://www.dvm360.com/view/treating-canine-bacterial-pneumonia-beyond-antibiotics-proceedings
[5] Pneumonia in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats

## 预防措施

吸入性肺炎预防侧重于识别高风险患者并实施围手术期安全方案。主要预防策略包括适当的麻醉管理，包括最小化麻醉持续时间、确保正确的气管内导管充气以及在手术前给予抗酸剂和促动力药物[1]。

对于风险患者，包括患有巨食道、神经系统疾病或喉部疾病的患者，特殊的喂养方案至关重要。患有巨食道的犬应直立喂养以防止反流和随后的吸入[2]。

围手术期风险缓解需要仔细注意麻醉技术。兽医人员必须经过适当培训进行口服液体给药，确保液体输送速度不超过动物吞咽速度[3]。在麻醉期间，充分的气道保护至关重要，特别是在诱导过程中，此时吸入风险最高[3]。

环境控制包括在治疗期间适当的患者约束，如果发生反流，立即停止口服液体给药[3]。对于住院患者，在恢复期间头部抬高定位可减少吸入风险。管饲程序需要特殊预防措施，因为该程序本身具有吸入风险，必须仔细执行以防止肺炎发展[4]。

客户教育在预防中起着至关重要的作用。宠物主人应了解正确的用药技术并识别易导致吸入的食管疾病或神经系统疾病的早期迹象[2]。

### Sources
[1] 10 tips for talking to veterinary clients about anesthetic risk: https://www.dvm360.com/view/10-tips-talking-veterinary-clients-about-anesthetic-risk
[2] Aspiration Pneumonia in Pets and People: https://www.dvm360.com/view/aspiration-pneumonia-in-pets-and-people
[3] Aspiration Pneumonia in Large Animals - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/aspiration-pneumonia-in-large-animals/aspiration-pneumonia-in-large-animals
[4] Tips for puppy resuscitation (Proceedings): https://www.dvm360.com/view/tips-puppy-resuscitation-proceedings

## 鉴别诊断

吸入性肺炎必须与几种临床表现重叠的呼吸系统疾病进行鉴别[1]。最具挑战性的鉴别是其他原因引起的细菌性肺炎，它具有相似的放射学模式和临床体征[1]。关键区分因素包括在呼吸道体征之前有呕吐、反流或麻醉事件的病史，这强烈提示吸入性肺炎[2]。

真菌性肺炎表现为慢性呼吸道体征和放射学上的粟粒状结节模式，与吸入性肺炎的急性发作和肺泡模式形成对比[1]。猫哮喘表现为呼气性呼吸困难伴有支气管模式，可能显示右中叶肺不张，与吸入性肺炎特征性的腹侧肺泡分布不同[2]。

心源性肺水肿显示背侧和肺门分布模式伴有心脏增大，而吸入性肺炎通常影响腹侧肺区域而没有原发性心脏变化[3]。由癫痫或创伤等原因引起的非心源性肺水肿显示尾背侧分布，缺乏吸入性肺炎的腹侧偏好[3]。

急性肺损伤和急性呼吸窘迫综合征需要满足特定的诊断标准，包括双侧浸润和PaO2/FiO2比率，将它们与典型的吸入性肺炎表现区分开来[4]。创伤引起的肺挫伤在放射学上可能相似，但伴有同时发生的胸部损伤如肋骨骨折或气胸[3]。

### Sources

[1] The pneumonias of small mammals (Proceedings): https://www.dvm360.com/view/pneumonias-small-mammals-proceedings
[2] Lower respiratory disease in cats (Proceedings): https://www.dvm360.com/view/lower-respiratory-disease-cats-proceedings  
[3] Radiographic evaluation of pulmonary patterns and disease (Proceedings): https://www.dvm360.com/view/radiographic-evaluation-pulmonary-patterns-and-disease-proceedings
[4] Acute lung injury and acute respiratory distress syndrome: https://www.dvm360.com/view/acute-lung-injury-and-acute-respiratory-distress-syndrome-two-challenging-respiratory-disorders

## 预后

犬吸入性肺炎的预后通常良好，存活率根据研究人群在77%至83%之间[1,2]。然而，死亡率可能很显著，特别是在术后病例中，在一般兽医人群中接近25%[1]。

已经评估了多个预后因素。与预期相反，肺浸润的放射学严重程度与存活结局无关[2]。在一项研究中，具有最严重放射学评分（18-24）的犬全部存活至出院[2]。同样，与吸入性肺炎相关的多种潜在疾病过程的存在不会对存活率产生不利影响[2]。

住院时间和重症监护要求也与结局没有显著相关性[2]。存活者通常需要5.0 ± 4.5天的住院时间，这与非存活者的5.4 ± 4.5天相当[2]。

年龄似乎是一个重要的预后因素，患者年龄增加与更高的死亡风险相关[1]。吸入原因不影响存活率，无论是与食管疾病、神经系统疾病还是麻醉后并发症相关[2]。

患有复发性或严重吸入性肺炎的受影响犬，预后通常谨慎到不良[3]。早期识别和适当治疗对于最佳结局仍然至关重要，因为在严重情况下，吸入性肺炎可进展为急性呼吸窘迫综合征，后者具有极高的死亡率[2,4]。

### Sources

[1] Low incidence of postoperative nausea, vomiting: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.21.05.0237.xml

[2] Etiology and clinical outcome in dogs with aspiration pneumonia: https://avmajournals.avma.org/view/journals/javma/233/11/javma.233.11.1748.xml

[3] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/249/9/javma.249.9.1003.xml

[4] Acute lung injury and acute respiratory distress syndrome: Two challenging respiratory disorders: https://www.dvm360.com/view/acute-lung-injury-and-acute-respiratory-distress-syndrome-two-challenging-respiratory-disorders
