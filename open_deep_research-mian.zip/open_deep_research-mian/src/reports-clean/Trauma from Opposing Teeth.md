# 伴侣动物对合牙创伤

对合牙创伤是犬猫中一种重要的牙科疾病，由咬合异常引起，异常的牙齿排列在正常下颌运动过程中造成破坏性接触。这种机械损伤大约影响50%的纯种犬，其中短头颅品种和玩具品种表现出特别的易感性。该病症范围从简单的牙齿对牙齿磨损到包括口腔鼻瘘形成和牙髓疾病在内的严重并发症。本报告探讨了临床表现模式、包括牙科X线摄影在内的诊断方法，以及从保守的正畸干预到手术拔除的治疗策略。重点关注领域包括品种特异性易感性、早期干预方案和影响小动物兽医实践成功结果的长期预后因素。

## 疾病概述和病理生理学

对合牙创伤是伴侣动物中一种重要的牙科疾病，定义为由对合牙之间或牙齿与口腔软组织之间的异常接触导致的组织损伤。该病症主要源于咬合异常（异常的咬合模式），其中上颌骨和下颌骨牙齿之间的正常排列被破坏[1]。

其病理生理学涉及机械性创伤，当错位牙齿在正常下颌运动、咀嚼或闭口过程中造成不适当的接触时发生。最常见的机制涉及II类咬合异常（深覆合）中的下颌犬齿撞击硬腭，其中下颌相对上颌较短[1,3]。相反，在III类咬合异常（反合）中，上颌切牙可能创伤下颌牙龈或口底[3]。

从流行病学角度看，咬合异常大约影响50%的纯种犬，尽管并非所有病例都会导致创伤性损伤[8]。短头颅品种由于选择性培育短面部特征而易患III类咬合异常[4]。某些品种表现出特定模式：设得兰牧羊犬易患上颌犬齿前向移位（矛状犬齿），而体重低于22磅的小型品种经常经历导致创伤性接触的牙齿拥挤[8]。

该病症可能源于发育异常、阻碍恒牙正常位置的滞留乳牙，或下颌生长阶段的牙齿锁结[3,8]。早期识别和干预至关重要，因为未经治疗的病例可能进展为包括口腔鼻瘘形成、牙髓疾病和慢性疼痛在内的严重并发症[7,8]。

### Sources
[1] Merck Veterinary Manual Dental Disorders of Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/dental-disorders-of-cats
[2] Merck Veterinary Manual Dentofacial Trauma in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/dentofacial-trauma-in-small-animals
[3] Merck Veterinary Manual Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
[4] Merck Veterinary Manual Soft Tissue Trauma of the Mouth in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/soft-tissue-trauma-of-the-mouth-in-small-animals
[5] Merck Veterinary Manual Tooth Resorption in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals
[6] DVM 360 Veterinary orthodontics: Some cases require braces: https://www.dvm360.com/view/veterinary-orthodontics-some-cases-require-braces
[7] DVM 360 The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[8] DVM 360 Dental Corner: Canine orthodontics: Providing healthy occlusions: https://www.dvm360.com/view/dental-corner-canine-orthodontics-providing-healthy-occlusions
[9] DVM 360 Defining dental malocclusions in dogs: https://www.dvm360.com/view/defining-dental-malocclusions-dogs

## 临床表现和诊断

犬猫的对合牙创伤表现出与咬合异常和牙齿对牙齿接触相关的独特临床症状。该病症主要通过异常的牙齿磨损模式和受影响牙齿的结构损伤表现出来[1][3]。临床检查显示牙齿对牙齿创伤导致异常磨损，通常暴露牙本质或牙髓[3]。这种破坏性接触将咬合力集中在特定牙齿上，而不是像正常咬合那样分散在多个牙齿上。

受影响的解剖结构包括对合牙齿的牙冠表面，常见表现涉及下颌犬齿与上颌切牙或相邻牙齿的接触[1][3]。下颌基底部狭窄的犬齿经常接触硬腭，导致创伤、疼痛和潜在的口腔鼻瘘形成[3][9]。患者可能因创伤性咬合而表现出咀嚼困难、口腔疼痛和行为变化[3][9]。

诊断影像学，特别是牙科X线摄影，对于全面评估至关重要[2][4]。当临床检查表明存在龈下病理或评估咬合异常时，应获取X线片[4]。全口X线片可以在口腔检查看似正常时识别病理，并且对于评估损伤程度很有价值[4]。咬合异常的评估需要评估正常牙齿排列模式，其中下颌牙齿应在剪刀咬合关系中咬合于上颌牙齿的舌侧[1][8]。

诊断方法包括清醒检查和在麻醉下评估，以全面评估所有牙齿表面和咬合关系[8]。经过培训的技术人员进行清醒口腔评估有助于识别牙结石积聚并鼓励早期干预[2]。

### Sources
[1] Dental and oral examination: The normal oral cavity: https://www.dvm360.com/view/dental-and-oral-examination-normal-oral-cavity-dogs-and-cats-proceedings
[2] Before the breath becomes unbearable: How vet techs can convince anyone a pet needs a dental: https://www.dvm360.com/view/breath-becomes-unbearable-how-vet-techs-can-convince-anyone-pet-needs-dental
[3] Malocclusion and tooth-on-tooth trauma: https://www.dvm360.com/view/malocclusion-and-tooth-tooth-trauma
[4] How to obtain the best dental radiographs: https://www.dvm360.com/view/how-obtain-best-dental-radiographs
[5] Evaluation of the diagnostic yield of dental radiography and cone-beam computed tomography: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[6] Advanced dental procedures for pets: What's possible?: https://www.dvm360.com/view/advanced-dental-procedures-for-pets-what-s-possible
[7] Equine malocclusions: Are you overfiling?: https://www.dvm360.com/view/equine-malocclusions-are-you-overfiling
[8] Initial screening for dental abnormalities identified by labial: https://avmajournals.avma.org/view/journals/ajvr/85/9/ajvr.24.03.0085.xml
[9] Pediatric dentistry: An overview of common problems you'll: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice

## 治疗方法和管理

对合牙创伤的治疗侧重于消除创伤性接触，同时在可能的情况下保留牙齿功能。应始终优先选择侵入性最小的方法，并考虑患者的年龄、整体健康状况和主人依从性[1]。

**正畸管理**
正畸干预代表了一种保守治疗方法，适用于牙齿移动可以消除创伤性接触的病例。乳牙列期间的简单技术如阻断性正畸可以预防以后更复杂的问题。然而，复杂病例需要转诊给兽医牙科专家，因为经验不足的尝试可能会造成额外创伤[1]。

**牙冠降低和活髓治疗**
对于造成创伤性咬合的牙齿，牙冠高度降低结合活髓治疗提供了一种比拔牙侵入性更小的替代方案。这种技术在降低的高度上维持牙齿形态和功能，需要无菌程序和药物刺激牙本质沉积。长期的X线监测对于评估治疗成功至关重要[2]。

**拔牙决策**
当保守治疗有禁忌或失败时，需要完全拔牙。这代表了最具侵入性的选择，但通常提供明确的解决方案，且随访要求最少。术后10-14天的检查通常足以评估愈合成功[1]。

**疼痛管理和监测**
利用多模式方法进行全面疼痛控制，确保患者在整个治疗和恢复阶段的舒适，术后密切监测对于安全至关重要[3]。

### Sources
[1] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[2] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[3] Lecture Link: Postanesthesia monitoring pointers for small animals: https://www.dvm360.com/view/lecture-link-postanesthesia-monitoring-pointers-small-animals

## 预防和预后

### 预防措施

早期干预是预防伴侣动物对合牙创伤的基石。在幼犬和幼猫健康检查期间进行定期口腔检查，能够在咬合异常造成显著组织损伤之前识别它们[1]。乳牙滞留应立即处理，因为它们可能使恒牙移位并造成创伤性接触模式[1]。

对于高风险品种，特别是短头颅犬和易患拥挤的玩具品种，预防性拔除有问题的乳牙可以预防永久性咬合异常[2]。小型犬可能需要在一岁前进行专业牙科清洁，以解决加剧牙齿错位的早期牙周病[3]。

认识品种易感性有助于制定有针对性的预防策略。设得兰牧羊犬和波斯猫显示矛状犬齿（上颌犬齿近中移位）的风险增加，而标准贵宾犬和长头颅品种易患下颌基底部狭窄的犬齿[4]。玩具犬和小型品种犬对乳牙滞留表现出遗传易感性，这可能导致牙齿锁结和随后的创伤[4]。

### 长期结果和预后

创伤性牙齿对组织接触的预后因干预时间而异显著。通过正畸矫正或策略性拔除早期治疗咬合异常通常产生优异的结果[2]。然而，延迟治疗允许进行性组织损伤和继发并发症。

在乳牙列6-8周龄时进行的阻断性正畸通过消除不良牙齿锁结并允许不受限制的下颌生长获得最佳效果[4]。对于恒牙列咬合异常，存在多种治疗选择，包括正畸移动、结合活髓治疗的牙冠截断或拔牙，成功率取决于早期干预[4]。

1期牙周病通过专业清洁和家庭护理仍然可逆，而晚期牙周炎（2-4期）导致永久性附着丧失[1]。附着丧失超过50%的牙齿预后谨慎至不良，通常需要拔除[1]。

对于涉及上颌犬齿创伤导致口腔鼻瘘形成的严重病例，需要拔牙和手术修复，大多数患者预期愈合良好[1]。

### Sources

[1] Merck Veterinary Manual Dentofacial Trauma in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/dentofacial-trauma-in-small-animals
[2] DVM 360 Defining dental malocclusions in dogs: https://www.dvm360.com/view/defining-dental-malocclusions-dogs
[3] DVM 360 Strengthening oral health: A call to action for veterinary practices: https://www.dvm360.com/view/strengthening-oral-health-a-call-to-action-for-veterinary-practices
[4] DVM360 Normal occlusion or malocclusion: that is the question: https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
