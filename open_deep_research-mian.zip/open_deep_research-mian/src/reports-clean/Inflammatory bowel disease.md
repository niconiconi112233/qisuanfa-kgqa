# 犬猫炎症性肠病：综合临床指南

炎症性肠病（IBD）是兽医实践中最具挑战性的慢性胃肠道疾病之一，通过遗传、免疫功能障碍和环境因素之间的复杂相互作用影响犬猫。这种疾病以肠道黏膜中持续的炎症细胞浸润为特征，需要系统性的诊断方法来区分肠淋巴瘤等疾病，并采用谨慎的序贯治疗方案。本报告探讨了IBD的多方面性质，从德国牧羊犬和暹罗猫的品种特异性易感性到包括水解蛋白饮食和免疫抑制方案在内的先进治疗策略。内容综合了当前兽医界关于病理生理学、临床表现、诊断挑战和小动物临床医生遇到循证管理方法的知识。

## 摘要

对炎症性肠病的全面研究揭示了一种需要多领域系统性临床方法的复杂疾病。该疾病的多因素病因涉及德国牧羊犬和中国沙皮犬等品种的遗传易感性，结合黏膜免疫功能障碍和微生物菌群失调，形成自我持续的炎症循环。

| 方面 | 主要发现 |
|--------|-------------|
| **诊断** | 序贯方法：粪便检查→饮食试验→内窥镜活检 |
| **治疗** | 水解蛋白饮食优于新型蛋白；序贯抗生素→免疫抑制治疗 |
| **预后** | 80%反应率；并发淋巴瘤的中位生存期为2-3年 |
| **挑战** | 区分肠淋巴瘤需要PARR检测 |

从水解蛋白饮食开始，经过靶向抗生素治疗到免疫抑制药物的序贯治疗方案为成功管理提供了基础。然而，区分IBD与肠淋巴瘤（特别是小细胞变异型）的关键挑战需要包括PARR检测在内的先进诊断技术。由于80%的患者对治疗反应良好，早期识别和系统性管理方案为维持患病伴侣动物的生活质量提供了实质性希望。

## 疾病概述和流行病学

炎症性肠病（IBD）指一组特发性、慢性胃肠道疾病，其特征是炎症细胞浸润到肠道黏膜中[1]。IBD包括导致胃肠道内慢性炎症的各种疾病，影响小肠和大肠[2]。

病因涉及遗传因素、饮食抗原、肠道菌群和黏膜免疫系统之间的复杂相互作用[3]。发病机制集中于对腔内抗原的不适当免疫反应，黏膜屏障完整性丧失使细菌和饮食抗原引发持续的免疫刺激和炎症[3]。

**品种易感性**：在犬中，德国牧羊犬、中国沙皮犬、巴仙吉犬、软毛小麦色梗犬易感，而暹罗猫显示易感性增加[2][4]。IBD通常影响中年动物，但可发生在任何年龄，包括仅4个月大的患者[2][5]。

**炎症细胞类型**：淋巴浆细胞性炎症在两个物种中最常见，其次是嗜酸性形式[4]。嗜酸性变异型预后较差，可能对治疗更具抵抗力[2]。肉芽肿性IBD罕见且通常对治疗无反应[2]。

**解剖分布**：疾病可能选择性累及胃、小肠或结肠，临床症状因受累区域而异[3]。在猫中，IBD可能是"三联炎"的一部分，与胆管炎和胰腺炎同时发生[2]。

### Sources
[1] Idiopathic inflammatory bowel disease in dogs and cats: https://avmajournals.avma.org/view/journals/javma/201/10/javma.1992.201.10.1603.pdf
[2] Inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings
[3] Management of inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/management-inflammatory-bowel-disease-proceedings
[4] Feline inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/feline-inflammatory-bowel-disease-proceedings
[5] Advances in managing inflammatory bowel disease: https://www.dvm360.com/view/advances-managing-inflammatory-bowel-disease

## 病因学和病理生理学

犬猫炎症性肠病源于遗传易感性、环境因素、免疫系统功能障碍和微生物菌群失调之间的复杂相互作用[1]。发病机制涉及遗传成分，某些品种如德国牧羊犬和爱尔兰雪达犬显示易感性，表明遗传因素有助于疾病易感性[1]。

黏膜免疫系统功能障碍在IBD发展中起核心作用。该疾病涉及肠道相关淋巴组织（GALT）的免疫调节缺陷，导致对通常无害抗原（包括共生细菌和饮食成分）的不适当免疫反应[2]。这导致正常耐受机制破坏和持续的炎症细胞浸润，主要是固有层中的淋巴细胞和浆细胞[3]。

微生物菌群失调代表IBD病理生理学的关键组成部分。研究表明，患有IBD的猫肠道微生物群显著改变，潜在致病细菌如肠杆菌科、大肠杆菌和梭菌属种群增加，而有益细菌种群减少[2]。这些细菌变化与促炎细胞因子（特别是IL-8）产生增加相关，并有助于黏膜结构变化，包括绒毛萎缩和融合[2]。

环境因素包括饮食、感染和压力可触发或加剧遗传易感动物的疾病。这些元素之间的复杂相互作用创造了一个自我持续的循环，其中炎症增加肠道通透性，允许更多抗原暴露和进一步的免疫系统激活，最终导致慢性肠病[3]。

### Sources
[1] Decoding chronic enteropathy in canine patients: https://www.dvm360.com/view/decoding-chronic-enteropathy-in-canine-patients
[2] Managing IBD and diarrhea in adult cats (Proceedings): https://www.dvm360.com/view/managing-ibd-and-diarrhea-adult-cats-proceedings
[3] Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals

## 临床表现和诊断方法

炎症性肠病的临床症状反映胃肠道受累的解剖位置[1]。小肠IBD通常表现为食欲不振、体重减轻、呕吐和腹泻，尽管猫可能有效保存水分使小肠腹泻难以检测[1]。大肠受累产生频繁排出含有黏液和明显血液的小量粪便[1]。混合受累主要表现为大肠症状但包括体重减轻和呕吐[2]。

其他临床表现包括餐后疼痛、肠鸣音、腹痛和吃草行为[2]。值得注意的是，猫可能仅表现为呕吐而无腹泻，这不同于通常表现出两种症状的犬[2]。猫患者在全血计数中可能有轻度贫血或轻度白细胞增多，但结果可能正常[3]。

诊断工作从全面的粪便检查和使用硫酸锌漂浮法检测贾第鞭毛虫的寄生虫排除开始[1]。实验室评估包括CBC、生化概况、T4和尿分析以排除鉴别诊断[1]。WSAVA已建立指南，要求胃肠道症状超过3周持续时间、对饮食试验和驱虫药反应不完全、活检显示黏膜炎症的组织学病变以及对免疫调节治疗的临床反应用于IBD诊断[4]。

钴胺素和叶酸水平提供有价值的信息，低钴胺素和高叶酸提示细菌过度生长[1]。腹部超声评估肠壁厚度、正常分层和肠系膜淋巴结病[1]。明确诊断需要组织活检，最好通过内窥镜进行，每个部位至少6-7个样本以避免挤压伪影[1]。

### Sources
[1] Feline inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/feline-inflammatory-bowel-disease-proceedings
[2] Inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings
[3] Treating IBD and lymphoma without a biopsy: https://www.dvm360.com/view/treating-ibd-and-lymphoma-without-a-biopsy
[4] Managing IBD in cats (Proceedings): https://www.dvm360.com/view/managing-ibd-cats-proceedings

## 治疗策略和管理

炎症性肠病的管理遵循系统性的序贯方法，根据疾病严重程度和患者反应进行调整[1]。治疗从饮食修改开始作为治疗的基石，水解蛋白饮食由于其优于新型蛋白饮食的疗效而成为首选的一线方法[1][2]。对于疑似IBD的猫，应喂食水解蛋白饮食4-6周作为唯一食物来源，不允许任何零食[2]。

**序贯治疗方案**

推荐的治疗序列从抗寄生虫药物（芬苯达唑50 mg/kg/天，持续3-5天）开始，然后进行3-4周的饮食修改，如需要再进行抗生素治疗[6]。甲硝唑（每12小时10 mg/kg）和泰乐菌素（每12小时10-80 mg/kg）是常用的抗生素，具有抗菌和免疫调节作用[1][6]。然而，当前对微生物组破坏的理解已导致减少对长期抗生素治疗的依赖[1]。

**免疫抑制治疗**

当饮食和抗生素干预失败时，皮质类固醇成为主要治疗[1][7]。泼尼松龙优于泼尼松，特别是在猫中，初始剂量为每12小时1-2 mg/kg[3]。临床症状改善后，剂量应逐渐减至最低有效维持剂量[3]。对于难治性病例，额外的免疫抑制药物包括犬用硫唑嘌呤（初始每天2 mg/kg）、环孢素（每12小时5 mg/kg）或猫用苯丁酸氮芥（每2-3天2 mg）[3][5][7]。

**蛋白丢失性肠病管理**

伴有蛋白丢失性肠病的严重病例需要积极的联合治疗[6][8]。苯丁酸氮芥-泼尼松龙组合已被证明比硫唑嘌呤-泼尼松龙方案对这些病例更有效[6]。超低脂饮食对并发淋巴管扩张的患者至关重要[8]。辅助治疗包括钴胺素补充（每周皮下注射250 μg，持续6周，然后每月一次）、抗血栓治疗和支持性营养护理[3][8]。

### Sources

[1] Diagnosis and management of IBD in dogs and cats: https://www.dvm360.com/view/diagnosis-and-management-of-ibd-in-dogs-and-cats
[2] Managing inflammatory bowel disease in cats (Proceedings): https://www.dvm360.com/view/managing-inflammatory-bowel-disease-cats-proceedings
[3] Managing IBD in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-ibd-dogs-and-cats-proceedings
[4] Advances in managing inflammatory bowel disease: https://www.dvm360.com/view/advances-managing-inflammatory-bowel-disease/1000
[5] Gut check: Practical treatment of inflammatory bowel disease: https://www.dvm360.com/view/gut-check-practical-treatment-inflammatory-bowel-disease
[6] Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals
[7] Management of inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/management-inflammatory-bowel-disease-proceedings
[8] Care of dogs with protein-losing enteropathy (Proceedings): https://www.dvm360.com/view/care-dogs-with-protein-losing-enteropathy-proceedings

## 鉴别诊断和预后

现有内容全面涵盖了IBD的鉴别诊断和预后。我将其与新来源材料综合以增强特定方面。

需要与IBD区分的关键疾病包括肠淋巴瘤、外分泌胰腺功能不全和各种感染性肠病[1]。肠淋巴瘤，特别是小细胞淋巴瘤，构成最大的诊断挑战，因为临床症状通常与IBD相同[2]。低级别消化道淋巴瘤与IBD具有相似的超声特征，包括弥漫性小肠增厚伴壁层保留[3]。区分因素包括抗原受体重排聚合酶链反应（PARR）检测，该检测在68-90%的病例中检测到淋巴瘤，尽管阴性结果不能排除淋巴瘤[1]。

重要的感染性鉴别包括幽门螺杆菌、组织胞浆菌病、腐霉菌属和猫传染性腹膜炎，这些疾病可能在临床恶化前最初对免疫抑制治疗有反应[1]。这些感染性疾病往往最初对免疫抑制类固醇反应良好，然后经历突然的临床恶化[1]。外分泌胰腺功能不全代表一个重要的鉴别诊断，特别是在猫中，77-100%的病例存在组织水平钴胺素缺乏[7]。

**预后**根据疾病严重程度和治疗反应差异显著[1]。大约80%的患者对治疗反应良好，主要目标是控制临床症状而非完全缓解[1]。当正确区分和治疗时，小细胞淋巴瘤的中位生存时间为2-3年，猫可能在癌症进展前死于其他原因[9]。不良预后因素包括伴有腹水或水肿的严重临床症状、低血清白蛋白和低钴胺素血症[1]。然而，一些具有这些负面指标的患者仍可显示临床改善，因此不应拒绝治疗[1]。大约20%患有IBD的犬对标准饮食和免疫抑制治疗无反应[1]。

### Sources
[1] Diagnosis and management of IBD in dogs and cats: https://www.dvm360.com/view/diagnosis-and-management-of-ibd-in-dogs-and-cats
[2] Inflammatory bowel disease: Diagnostic and treatment approaches: https://www.dvm360.com/view/inflammatory-bowel-disease-diagnostic-and-treatment-approaches-proceedings
[3] Feline lymphoma: diagnosis and treatment: https://www.dvm360.com/view/feline-lymphoma-diagnosis-and-treatment
[7] Exocrine pancreatic insufficiency in dogs and cats: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[9] Treating IBD and lymphoma without a biopsy: https://www.dvm360.com/view/treating-ibd-and-lymphoma-without-a-biopsy
