# 犬猫IV类错颌畸形

IV类错颌畸形，也称为歪颌或上下颌不对称，代表了伴侣动物临床中最复杂的牙齿异常之一。这种骨骼性错颌畸形的特点是颌骨发育不对称，即上颌骨或下颌骨的一侧生长与对侧不同，导致中线偏离和功能障碍。与其他具有可预测模式的错颌畸形类别不同，IV类错颌畸形因其三维特性和多变表现而呈现出独特的诊断和治疗挑战。早期识别至关重要，因为在乳牙期进行干预性治疗可获得最佳结果，而延迟干预可能需要复杂的正畸或外科治疗管理。本报告探讨了IV类错颌畸形的综合兽医处理方法，涵盖其遗传基础、包括锥形束CT在内的诊断影像学方案、从干预性正畸到手术拔除的治疗方式，以及育种计划中遗传咨询的关键重要性。

## 疾病概述与分类

IV类错颌畸形，也称为上下颌不对称或"歪颌"，代表了兽医牙科分类系统中的复杂骨骼性错颌畸形(1)。美国兽医牙科学院将其认定为一个独特的类别，其特征是上颌骨和下颌骨的不对称生长模式，即颌骨的一侧发育与对侧不同(2)。

这种情况表现为三种主要形式：前后向错位（前后差异，一侧表现为近中错颌或远中错颌）、侧向错位（中线对齐丧失并偏离）和背腹向错位（异常间隙阻碍正常口腔闭合）(2)。"歪颌"一词被认为是描述各种单侧咬合异常的非专业术语，不建议在专业领域使用(1)。

IV类错颌畸形通常被认为是显性遗传的，而单个牙齿错位则可能是隐性遗传的(8)。IV类错颌畸形的特定流行病学数据有限，尽管错颌畸形总体上会影响具有不同品种易感性的伴侣动物。这种情况可发生于犬和猫，不对称的下颌或上颌发育通常源于骨骼成熟过程中的差异生长模式(2)。与其他可能具有明确品种倾向的错颌畸形类别不同，IV类似乎在各个品种中零星发生。

### Sources

[1] Defining dental malocclusions in dogs: https://www.dvm360.com/view/defining-dental-malocclusions-dogs

[2] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion

[3] Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics

## 病因学与病理生理学

IV类错颌畸形，也称为不对称性骨骼错颌或歪颌，通过遗传易感性和发育中断之间的复杂相互作用而发展[1]。主要病因涉及影响颌骨不成比例发育的遗传因素，其中上颌骨长度比下颌骨长度更容易通过选择性育种进行调控[1]。这造成了颌骨关系的内在不稳定性。

关键的病理生理机制集中在恒牙萌出相对于颌骨生长的时机[1]。当颌骨在恒牙萌出期间存在异常关系时，牙列就会被锁定在异常位置。如果这种情况单侧发生，它会允许一侧颌骨继续延长，而另一侧生长停止，导致不对称中线不匹配[1]。

遗传易感在软骨发育不全品种中尤为明显，其中软骨发育不全基因具有可变的外显率，通过面部特征的独立遗传产生严重的错颌畸形[2,3]。导致骨骼错颌畸形的基因通常是显性遗传的，而单个牙齿错位可能是隐性遗传的[4]。

环境因素包括颌骨发育期间的创伤，可通过颞下颌关节脱位或发育不良干扰正常生长模式，导致错颌畸形[5]。然而，大多数错颌畸形是遗传性的而非创伤诱导的，育种实践无意中选择了损害正常咬合的骨骼差异[2,3]。这代表了主要的遗传病因而非继发性环境原因。

### Sources

[1] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals

[2] DVM 360 Defining dental malocclusions in dogs: https://www.dvm360.com/view/defining-dental-malocclusions-dogs

[3] Oral diagnosis: Hard tissue valuation (Proceedings): https://www.dvm360.com/view/oral-diagnosis-hard-tissue-valuation-proceedings

[4] Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics

[5] Managing TMJ in companion animals: https://www.dvm360.com/view/managing-tmj-companion-animals

## 诊断方法

IV类错颌畸形的诊断需要使用临床检查和先进影像学技术进行全面评估。现有的临床表现信息显示了全面评估的重要性，但额外的诊断工具可提高诊断准确性和治疗规划。

锥形束计算机断层扫描（CBCT）已成为兽医牙科诊断的有价值影像技术[1][2]。VetCAT IQ™代表了一种紧凑、移动式的3D CBCT系统，将先进影像直接带到患者身边，提供头部、牙齿、鼻窦、眼睛和大脑解剖结构的高分辨率可视化[2]。与传统放射摄影相比，该技术提供了卓越的诊断能力，特别对于需要三维评估的复杂错颌畸形病例。

数字牙科放射摄影相比传统胶片系统具有显著优势[3]。现代数字系统提供95%的辐射暴露减少，同时在数秒内提供快速图像处理[3]。对于IV类错颌畸形评估，诊断性牙科X光片必须包括牙齿根尖周围2-3毫米的骨骼，并清晰显示牙槽骨水平[4]。

系统的放射摄影方案对于全面评估至关重要[4]。分角技术仍然是最常用的方法，为根尖研究提供最小失真和可重复的定位[3]。特殊技术包括管移位法（SLOB规则）有助于在二维X光片上区分三维结构，对于识别多根牙的根病理特别有价值[3]。

### Sources
[1] NewTom 5G Cone Beam CT (CBCT): http://marketplace.dvm360.com/product/newtom-5g-cone-beam-ct-cbct
[2] Chicago Exotics Animal Hospital implements novel imaging system: https://www.dvm360.com/view/chicago-exotics-animal-hospital-implements-new-3d-ct-imaging-system
[3] Oral Radiology - WSAVA2007: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3860716&pid=11242&print=1
[4] Diagnostic dental radiographs: A concise how-to: https://www.dvm360.com/view/diagnostic-dental-radiographs-concise-how

## 治疗选择与管理

IV类错颌畸形的治疗需要全面评估和个体化方法。有多种治疗方式可用，选择基于错颌畸形的严重程度、患者年龄和存在的创伤程度[1]。

**干预性正畸**
乳牙期的早期干预提供最佳结果。对于下颌短小的患者，拔除乳下颌犬齿和切齿可允许下颌不受阻碍地发育。在下颌前突病例中，拔除上颌中央和中间切齿可允许成年切齿更靠前萌出[1]。这种干预方法在4-8周龄时进行最有效，以允许最大程度的颌骨延长[2]。

**正畸治疗**
引起创伤性咬合的受影响犬齿可由兽医牙科医生正畸移动到非创伤性位置[2]。正畸治疗涉及放置附着于上颌犬齿和切齿的倾斜平面，为下颌犬齿创建斜面，在口腔闭合时引导正确定位[3]。然而，需要多次麻醉，并且遗传咨询至关重要，因为大多数错颌畸形是遗传性的[2]。

**活髓牙冠修复**
活髓牙冠修复提供了一种比拔牙创伤更小的替代方法，同时保持牙齿功能[2]。该技术需要无菌操作、放置药物刺激牙本质形成以及终身放射学监测[2]。

**手术拔除**
当其他治疗不适用时，完全拔除仍然是一个可行的选择，尽管它是最具侵入性的方法[2]。正确的手术技术，包括瓣膜创建、骨移除和仔细闭合，对于预防并发症至关重要[4]。

### Sources

[1] Current concepts in veterinary dentistry (Proceedings): https://www.dvm360.com/view/current-concepts-veterinary-dentistry-proceedings
[2] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
[3] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[4] Surgical tooth extractions (Proceedings): https://www.dvm360.com/view/surgical-tooth-extractions-proceedings

## 预防与预后

**预防措施**

早期检测方案侧重于定期口腔检查和主人教育[1]。遗传咨询对育种计划至关重要，因为错颌畸形主要通过牙齿大小与颌骨大小比例失调或上下颌骨大小差异遗传[1]。育种者应避免繁殖有确定错颌问题的动物，特别是在已延续遗传缺陷的纯种品系中[2]。

环境因素在预防中作用有限，尽管适当的营养和避免硬质咀嚼玩具可预防继发性创伤[2]。干预性正畸可能对幼年动物有帮助 - 在舌向错位（"基底狭窄"位置）病例中拔除乳下颌犬齿，或移除特定乳牙以允许颌骨不受阻碍地发育[5]。

IV类错颌畸形（不对称性骨骼错颌）的特征是上颌-下颌关系不对称，通常表现为侧向错位导致歪颌[6]。遗传咨询至关重要，因为大多数错颌畸形都有遗传成分，育种建议侧重于防止特征传播[7]。在乳牙发育期间通过选择性拔除相互锁定的牙齿进行早期干预，可能使颌骨发育到其遗传潜力[7]。

**长期结果与预后**

预后因错颌畸形类型和严重程度而有显著差异。具有未成熟根结构的年轻动物的简单牙齿移动病例比复杂骨骼差异病例有更好的结果[2]。治疗成功很大程度上取决于恒牙萌出和颌骨成熟前的早期干预[5]。

IV类错颌畸形因其不对称性质而呈现独特挑战，需要根据功能要求从牙齿移动到拔除的个体化治疗方法[4]。

**随访护理**

每6-12个月定期进行牙科检查对于监测治疗效果和检测错位牙齿的继发性牙周疾病至关重要[3]。持续的家庭护理和专业牙科清洁有助于预防与拥挤或旋转牙齿相关的并发症，这些牙齿难以有效清洁。

### Sources

[1] Oral diagnosis: Hard tissue valuation (Proceedings): https://www.dvm360.com/view/oral-diagnosis-hard-tissue-valuation-proceedings
[2] Orthodontics (Proceedings): https://www.dvm360.com/view/orthodontics-proceedings  
[3] How to approach pet dental care year-round: https://www.dvm360.com/view/how-to-approach-pet-dental-care-year-round
[4] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[5] Current concepts in veterinary dentistry (Proceedings): https://www.dvm360.com/view/current-concepts-veterinary-dentistry-proceedings
[6] 9 types of oral pathology: https://www.dvm360.com/view/9-types-oral-pathology
[7] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
