# 伴侣动物副肿瘤综合征

副肿瘤综合征是发生在原发肿瘤部位远端的系统性临床表现，影响约15%患淋巴瘤的犬，并构成患癌伴侣动物发病的重要原因。这些非转移性效应可能表现为潜在恶性肿瘤的首个临床症状，因此识别这些综合征对于早期诊断和干预至关重要。本报告探讨了复杂的病理生理学、从高钙血症到神经功能障碍的多样化临床表现，以及基于循证的诊断和治疗方法。重点关注的领域包括最常见的表现，如恶性肿瘤体液性高钙血症、副肿瘤性重症肌无力和代谢紊乱，以及它们对犬猫患者预后和生活质量的影响。

## 摘要

伴侣动物的副肿瘤综合征是复杂的多系统疾病，其引起的发病通常比潜在肿瘤本身更为严重。最显著的表现包括高钙血症（影响45-65%的高钙血症犬）、47%患胸腺瘤犬出现的神经并发症（如重症肌无力），以及深刻影响生活质量的全身性症状。

**关键临床见解：**

| 综合征类型 | 主要表现 | 预后 | 治疗优先级 |
|---------------|----------------------|-----------|-------------------|
| 恶性肿瘤相关高钙血症 | 代谢功能障碍 | 可变，取决于肿瘤控制 | 积极液体治疗 + 双膦酸盐 |
| 副肿瘤性重症肌无力 | 运动诱发性虚弱 | 胸腺瘤切除术后良好 | 手术切除肿瘤 |
| 神经性副肿瘤综合征 | 进行性虚弱/萎缩 | 无肿瘤控制时较差 | 支持性护理 + 原发肿瘤治疗 |

成功的管理需要双重关注原发肿瘤治疗和综合征特异性干预。通过系统性筛查方案（尤其是在老年患者中）早期识别，可以在危及生命的并发症发展之前进行干预。这些综合征通常作为疾病进展的生物标志物，其缓解通常随着成功的肿瘤控制而实现，而复发则表明转移扩散或治疗失败。

## 疾病概述

副肿瘤综合征是由于肿瘤对机体结构或功能的影响而发生在原发肿瘤部位远端的系统性临床表现[1]。在伴侣动物中，这些综合征代表了癌症的常见并发症，某些肠道肿瘤与副肿瘤表现（如低血糖和多尿/烦渴）相关[2]。

癌症约占10岁以上伴侣动物所有死亡原因的50%，因此了解肿瘤相关并发症至关重要[1]。副肿瘤综合征背后的病理生理机制涉及各种肿瘤相关因素，包括体液肽的释放、膜结合配体的异常表达，以及负责正常生理稳态的酶通路的失调[1]。

约15%患淋巴瘤的犬会发展为副肿瘤综合征相关的高钙血症，在纵隔受累的犬中这一比例增至40%[3]。约45%至65%的高钙血症犬和10%至30%的高钙血症猫存在潜在肿瘤[1]。与副肿瘤性高钙血症相关的最常见癌症包括犬的T细胞淋巴瘤和肛周腺腺癌，而在猫中最常报道的是淋巴瘤、支气管源性癌和鳞状细胞癌[1]。这些综合征通常显著增加患者发病率，有时可能是导致癌症诊断的首个临床症状[4]。

### Sources
[1] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
[2] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings
[3] Practical lymphoma management (Proceedings): https://www.dvm360.com/view/practical-lymphoma-management-proceedings
[4] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats

## 常见病原体

副肿瘤综合征不是由传染性病原体引起的，而是由癌症本身的非转移性效应引起的[1]。然而，病毒感染可通过导致继发性免疫缺陷而显著复杂化副肿瘤综合征，使伴侣动物易患机会性感染。

病毒诱导的免疫缺陷是患有副肿瘤综合征动物中临床上最重要的感染性并发症[1]。犬瘟热病毒感染并破坏淋巴细胞，导致严重的联合免疫缺陷，并增加对通常可控制的病原体（如肺孢子虫和弓形虫）的易感性[1]。猫泛白细胞减少症病毒导致急性白细胞减少，而犬猫的细小病毒感染会造成严重的免疫抑制，导致包括曲霉菌病、毛霉菌病和念珠菌病在内的真菌感染[1]。

猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）尤为重要，它们引起中性粒细胞减少、抗体合成减少、细胞免疫力降低，并增加继发感染的易感性[1]。这些病毒性免疫缺陷可重新激活潜伏感染，并为机会性病原体创造有利条件。

虽然细菌和真菌不是副肿瘤综合征的主要原因，但接受环孢素等治疗的免疫功能低下动物面临细菌感染（53%的病例）和包括隐球菌病、皮肤癣菌病和系统性念珠菌病在内的真菌感染风险增加[2]。涉及毛癣菌属的浅表性脓疱性皮肤癣菌病可使副肿瘤状况复杂化，特别是在免疫抑制患者中[3]。

### Sources

[1] Merck Veterinary Manual Secondary Immunodeficiencies in Animals: https://www.merckvetmanual.com/immune-system/immunologic-diseases/secondary-immunodeficiencies-in-animals

[2] DVM 360 Infections in immunocompromised pets: https://www.dvm360.com/view/infections-immunocompromised-pets-proceedings

[3] Canine and feline pemphigus foliaceus: Improving your chances of a successful outcome: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome

## 临床症状和体征

副肿瘤综合征表现为多样化的临床表现，不仅包括传统的全身性症状，还包括显著的神经学表现。犬猫的神经性副肿瘤综合征通常表现为脊髓和颅神经反射减弱或消失、弛缓性虚弱、肌张力降低以及肢体或头部肌肉麻痹[1]。这些体征通常在1-2周内发展为神经源性肌肉萎缩，常伴有发音困难[1]。

副肿瘤性重症肌无力是最具临床意义的表现之一，特别是在患胸腺瘤的犬中，其中47%发展为并发重症肌无力[1]。患病动物表现出特征性的运动诱发性虚弱，休息后改善，常伴有僵硬、震颤和严重的运动不耐受[2][3]。因重症肌无力导致四肢虚弱的犬通常在活动几步后即出现虚弱和塌陷[5]。

神经并发症也可表现为周围神经病变，通常与各种肿瘤类型相关，包括胰岛素瘤、多发性骨髓瘤、淋巴瘤和乳腺腺癌[1]。临床症状包括反射减弱、弛缓性虚弱的进行性肌肉萎缩，影响犬和猫[1][3]。

全身性症状仍然是突出特征，患病动物常表现为严重虚弱、运动不耐受和全身性衰退[1][5]。这些系统性表现在生活质量影响方面往往超过原发肿瘤，因此识别这些综合征对于适当的患者管理和就疾病进展和预后与客户沟通至关重要[6]。

早期识别这些神经学表现至关重要，因为副肿瘤综合征可能是潜在恶性肿瘤的首个临床表现，有可能在更可治疗的阶段发现肿瘤[1]。

### Sources
[1] Paraneoplastic Disorders of the Nervous System in Animals: https://www.merckvetmanual.com/nervous-system/paraneoplastic-disorders-of-the-nervous-system/paraneoplastic-disorders-of-the-nervous-system-in-animals
[2] Disorders of the Peripheral Nerves and Neuromuscular Junction in Dogs: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-dogs
[3] Disorders of the Peripheral Nerves in Cats: https://www.merckvetmanual.com/cat-owners/brain-spinal-cord-and-nerve-disorders-of-cats/disorders-of-the-peripheral-nerves-in-cats
[4] Congenital and Inherited Disorders of the Nervous System in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs
[5] Exercise intolerance in retrievers: https://www.dvm360.com/view/exercise-intolerance-retrievers
[6] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats

## 诊断方法

诊断犬猫的副肿瘤综合征需要系统性的方法，结合临床评估与全面的实验室和影像学检查[1]。诊断的挑战在于识别这些癌症的继发性表现，同时将其与原发性疾病过程区分开来。

**临床表现评估**

体格检查是初步诊断的基石，特别注意触诊外周淋巴结和进行直肠检查以评估肛门腺是否有腺癌[1]。兽医应评估如全身性淋巴结病等体征，这可能提示潜在的淋巴瘤导致副肿瘤性高钙血症[2]。

**实验室检测**

通过全血细胞计数进行血液学评估可揭示异常，包括再生性或非再生性贫血、血小板减少和中性粒细胞增多，这些可能表明潜在肿瘤[1]。血清生化谱对于检测副肿瘤综合征至关重要，特别是高钙血症、高球蛋白血症和低血糖症[1]。

**激素和钙代谢测定**

对于疑似副肿瘤性高钙血症，离子钙测量提供了钙状态的最准确评估[3]。同时评估甲状旁腺激素（PTH）和甲状旁腺激素相关蛋白（PTHrP）浓度至关重要，因为恶性肿瘤体液性高钙血症通常表现为离子钙增加和PTHrP升高，而PTH保持抑制状态[3]。

**影像学检查**

胸部X线片适用于评估前纵隔肿块、肺转移和胸腔淋巴结[1]。通过X线摄影或超声进行腹部影像学检查有助于识别器官功能障碍和潜在的原发肿瘤[1]。CT或MRI等先进影像学检查可能对全面的肿瘤分期和治疗规划是必要的[4]。

### Sources
[1] Early detection of cancer requires persistent checks: https://www.dvm360.com/view/early-detection-cancer-requires-persistent-checks
[2] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs
[3] Hypercalcemia in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-parathyroid-glands-and-disorders-of-calcium-regulation-in-dogs-and-cats/hypercalcemia-in-dogs-and-cats
[4] Ocular manifestations of systemic disease--when the eye is not the primary disease (Proceedings): https://www.dvm360.com/view/ocular-manifestations-systemic-disease-when-eye-not-primary-disease-proceedings

## 治疗选择

副肿瘤综合征的治疗需要双重方法：处理潜在肿瘤和管理特定的综合征表现[1][2]。

**原发肿瘤治疗**构成治疗的基石。成功的肿瘤切除或控制通常能解决相关的副肿瘤综合征。对于恶性肿瘤相关高钙血症（最常见的副肿瘤综合征），初始支持性治疗包括使用等渗盐水溶液进行积极的液体治疗和给予速尿[2]。

**药物干预**因综合征类型而异。对于高钙血症，双膦酸盐如帕米膦酸盐（1-2 mg/kg静脉输注2小时）通过诱导破骨细胞凋亡提供强效的抗吸收作用[2]。糖皮质激素可能有益，特别是对于淋巴瘤相关的高钙血症，但应推迟使用直至明确诊断，以避免掩盖淋巴增殖性疾病[2]。

**手术方法**在可行时专注于肿瘤切除。对于肛门囊腺癌，建议进行广泛边缘的积极手术，通常需要包括放射治疗在内的多模式治疗[4]。患胸腺瘤的犬在手术切除后显示出良好的预后，即使肿瘤负荷大或伴有副肿瘤综合征[8]。

**支持性护理措施**解决危及生命的并发症。低血糖患者需要频繁喂养高蛋白、复合碳水化合物饮食，糖皮质激素提供有益的胰岛素抵抗[7]。对于肥大性骨病，对症治疗包括口服镇痛药、双膦酸盐和姑息性放射治疗[5]。

**紧急处理**方案对于严重表现至关重要。弥散性血管内凝血需要新鲜冷冻血浆和低分子量肝素治疗，以稳定患者进行明确的手术干预[7]。

### Sources

[1] Outpatient IV KL infusions were well-tolerated in dogs and cats with cancer: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0595.pdf
[2] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
[3] Thymoma in an 11-year-old dog: Radiation oncology perspective: https://www.dvm360.com/view/thymoma-11-year-old-dog-radiation-oncology-perspective
[4] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dog
[5] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[6] Paraneoplastic syndromes: What's the big deal?: https://www.dvm360.com/view/paraneoplastic-syndromes-whats-big-deal-proceedings
[7] Paraneoplastic syndromes (Proceedings): https://www.dvm360.com/view/paraneoplastic-syndromes-proceedings-0
[8] Clinical features, treatment options, and outcome in dogs with thymoma: https://avmajournals.avma.org/view/journals/javma/243/10/javma.243.10.1448.xml

## 预防措施

副肿瘤综合征的预防主要集中在早期癌症检测和监测高危患者，因为这些状况是由潜在恶性肿瘤而非传染性病原体引起的[1]。常规筛查方案应包括彻底的体格检查，注意外周淋巴结、直肠触诊（特别是针对肛门囊肿块），以及仔细评估头颈部区域，包括眼球后推和颈部淋巴结评估[1]。

年度老年宠物检查结合胸部X线普查可能能够在副肿瘤表现出现之前早期发现肺部肿瘤[2]。对于易患特定癌症的品种，如肺癌风险增加的拳师犬或易患原发性肺部肿瘤的老年母猫，应加强监测方案[2]。常规血液生化谱可以在临床症状出现之前识别副肿瘤性高钙血症，促使对潜在恶性肿瘤进行调查[1]。

环境因素可能影响癌症发展和随后的副肿瘤综合征风险。生活在吸烟家庭中的犬，特别是中头型和短头型品种，肺癌发病率增加[2]。与农村环境相比，城市环境与更高的肿瘤发生率相关，可能是由于更大的污染物暴露[2]。

早期识别癌症疼痛和症状对于及时干预至关重要。疼痛管理方案应预先实施，因为肥大性骨病等疼痛性副肿瘤综合征可显著损害生活质量[4]。虽然没有特定的疫苗可预防副肿瘤综合征，但通过标准疫苗接种方案和预防性护理维持整体健康有助于支持免疫功能[3]。

### Sources
[1] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
[2] An update on diagnosing and treating primary lung tumors: https://www.dvm360.com/view/update-diagnosing-and-treating-primary-lung-tumors  
[3] Paraneoplastic syndromes in dogs and cats - dvm360: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[4] Understanding and recognizing cancer pain in dogs and cats: https://www.dvm360.com/view/understanding-and-recognizing-cancer-pain-dogs-and-cats

## 鉴别诊断

副肿瘤综合征由于与许多其他疾病重叠的临床症状而呈现诊断挑战。准确的鉴别诊断需要系统性地评估多个器官系统，并考虑原发性疾病和继发性表现[1]。

**需要鉴别的主要疾病包括非恶性起源的高钙血症。** 原发性甲状旁腺功能亢进是最重要的鉴别诊断，因为45-65%的高钙血症犬和10-30%的高钙血症猫存在潜在肿瘤，而原发性甲状旁腺疾病则占比较少[1]。阿狄森氏病、慢性肾功能衰竭和维生素D中毒也必须通过适当的内分泌检测和生化分析排除[2]。

**代谢性疾病经常模拟副肿瘤表现。** 肝皮综合征可以表现与胰高血糖素瘤相关的浅表坏死性皮炎相同，需要胰腺影像学检查和胰高血糖素测量进行鉴别[3]。内分泌疾病如甲状腺功能减退症和肾上腺皮质功能减退症可引起类似副肿瘤效应的继发性并发症，需要全面的激素评估[2]。

**传染病和免疫介导性疾病呈现显著的重叠诊断。** 自身免疫性皮炎、超敏反应和传染性病原体可产生与副肿瘤综合征相同的临床症状[3]。通过适当的培养、活检和免疫学测试进行系统性排除对于准确诊断变得至关重要。

**鉴别特征包括多系统受累的急性发作，特别是当影响不寻常的解剖位置或呈现非典型临床模式时。** 并发肿瘤的存在、肿瘤标志物升高以及对针对潜在恶性肿瘤的特异性治疗的反应，提供了与原发性器官功能障碍区分的关键诊断依据[1][2]。

### Sources

[1] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats

[2] Hypercalcemia in Dogs and Cats - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-parathyroid-glands-and-disorders-of-calcium-regulation-in-dogs-and-cats/hypercalcemia-in-dogs-and-cats

[3] A challenging case: Glucagonoma-associated superficial necrolytic dermatitis in a dog: https://www.dvm360.com/view/challenging-case-glucagonoma-associated-superficial-necrolytic-dermatitis-dog

## 预后

犬猫副肿瘤综合征的预后因特定综合征类型、潜在肿瘤特征和治疗反应而异[1]。副肿瘤综合征可能随着原发疾病的治疗而缓解，并在缓解结束或疾病已转移到身体其他部位时复发[1]。

临床结果在很大程度上取决于潜在的恶性肿瘤。患胸腺瘤的犬，即使肿瘤负荷大或伴有副肿瘤综合征，手术后也有良好的预后[2]。据报道，存活过初始围手术期的胃肠道间质瘤（GIST）犬仅通过手术切除就有良好的预后，中位生存期为37.4个月[5]。相比之下，有明显转移性疾病的犬预后最差，中位生存期为68至136天[2]。

对于影响45-65%高钙血症犬和10-30%高钙血症猫的恶性肿瘤相关高钙血症，及时诊断和积极治疗可以改善结果[9]。副肿瘤综合征可成为个体患者的标志或生物标志物，监测实验室参数有助于评估治疗反应[1]。

几个预后因素影响恢复和疾病进展。在某些情况下，副肿瘤综合征可能比原发肿瘤本身引起更高的发病率，成为生活质量决策和客户沟通的重要关注点[1]。早期识别和干预通常改善结果，因为副肿瘤综合征可能是复发性疾病的第一个迹象，甚至在检测到明显的肿瘤复发之前[4]。

### Sources
[1] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[2] Hepatic Neoplasia in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-neoplasia-in-small-animals
[3] Clinical features, treatment options, and outcome in dogs with: https://avmajournals.avma.org/view/journals/javma/243/10/javma.243.10.1448.xml
[4] Paraneoplastic syndromes (Proceedings): https://www.dvm360.com/view/paraneoplastic-syndromes-proceedings-1
[5] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[6] Treating paraneoplastic hypercalcemia in dogs and cats: https://www.dvm360.com/view/treating-paraneoplastic-hypercalcemia-dogs-and-cats
