# 伴侣动物的牙齿吸收

牙齿吸收是一种进行性、非感染性的牙齿疾病，影响高达67%的猫和较小比例的狗。这种病理过程涉及特化的破牙细胞，这些细胞会系统地破坏牙齿结构，尽管临床表现细微，但通常会引起显著疼痛。该疾病病因不明，特别是其特发性形式，给兽医从业者带来了重大的诊断和管理挑战。本报告探讨了管理牙齿吸收所必需的临床表现、诊断方法和治疗方案，同时强调了牙科X光摄影在准确分类中的关键作用以及当前小动物实践中预防策略的局限性。

## 疾病概述

牙齿吸收是一种进行性、非感染性的牙齿病理，其特征是被称为破牙细胞的特化细胞系统性地破坏矿化牙齿组织（默克兽医手册，2024年）。这种情况代表了伴侣动物中最常见的牙齿疾病之一，在猫科患者中尤为普遍。

流行病学数据显示了疾病患病率的显著物种差异。在猫中，牙齿吸收影响约28-67%的种群，使其成为最常见的猫科牙齿疾病之一（DVM360，2024年）。患病率随年龄显著增加，研究表明，5岁以上的猫与较年幼的动物相比表现出明显更高的牙齿吸收率。某些品种可能表现出更高的易感性，但兽医文献中全面的品种特异性患病率研究仍然有限。

在狗中，牙齿吸收的发生频率低于猫，但仍然代表一种临床上重要的疾病。下颌第一磨牙和前磨牙在犬科患者中最常受影响，而猫科牙齿吸收通常影响下颌第三和第四前磨牙以及第一磨牙（默克兽医手册，2024年）。

疾病分类系统根据X光表现区分1型和2型吸收。1型病变保持正常的牙周韧带间隙和牙齿射线不透性，而2型病变显示牙槽骨粘连，伴有牙齿密度降低以及牙周韧带间隙变窄或消失（DVM360，2024年）。这种分类系统对于确定适当的治疗方案和预后至关重要。

## 常见病原体

牙齿吸收不是由病毒或细菌等传染性病原体引起的[1]。这种情况代表了一种非感染性的病理过程，与龋齿或其他微生物引起的牙齿疾病有着根本的不同。

主要机制涉及被称为破牙细胞的特化细胞，这些细胞与骨组织中发现的破骨细胞几乎完全相同[1]。这些破牙细胞靶向牙齿结构，并导致矿化牙齿组织（包括釉质、牙本质和牙骨质）的进行性吸收。细胞活动是通过直接酶解牙齿成分发生的，而不是通过细菌或病毒致病机制。

虽然某些形式的牙齿吸收可能与牙周病的炎症有关，但吸收过程本身是由破牙细胞活性介导的，而不是由病原体引起的[1][4]。外部炎症性吸收可能继发于边缘性牙周炎，但其潜在机制仍然是破牙细胞对炎症刺激反应的细胞破坏。

牙齿吸收的特发性形式，在猫中特别常见，发生在没有任何可识别的感染病因的情况下[4]。已经研究了各种理论，包括饮食因素和机械应力，但没有特定的病原体被确定为这种进行性牙齿疾病的致病因素。

### Sources

[1] Merck Veterinary Manual Tooth Resorption in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals
[4] Feline tooth resorption and caudal stomatitis (Proceedings): https://www.dvm360.com/view/feline-tooth-resorption-and-caudal-stomatitis-proceedings

## 临床症状和体征

患有牙齿吸收的猫通常表现出细微或没有临床症状，这使得该疾病难以检测[1]。最常见的行为变化包括吞咽困难、流涎、厌食和脱水[2]。与牙齿吸收相关的其他行为指标包括用嘴的一侧咀嚼、食欲下降、掉落食物、对着食物或水碗嘶嘶叫、躲藏或攻击性增加[4]。主人可能会观察到摇头、打喷嚏、掉落食物、完全拒绝进食，或者猫在试图进食时对着食物碗嘶嘶叫并逃跑[2]。

许多猫尽管有疼痛性病变，却没有表现出明显的疼痛迹象[3]。最常见的表现实际上可能是无症状的猫，病变仅在常规牙科检查中发现[3]。当出现临床症状时，通常包括厌食、流涎、拒绝进食饮食中的硬质部分和全身不适[3]。

从视觉上看，牙齿吸收可能表现为局限于单个牙齿的牙龈发红，这为临床医生提供了一个警示信号[5]。口腔检查时，牙齿吸收病变的特征是在受影响牙齿处出现局部的、樱桃红色的、有时是增生性的牙龈炎[3]。一种诊断技术涉及用断裂的木质棉签的细尖端轻轻刺激可疑病变，这通常会引发强烈的下颌震颤反应[3]。

当病变向冠方进展进入牙冠时，疼痛源于暴露的牙本质小管和牙髓刺激[2]。局限于牙根牙骨质的早期病变通常不痛，但可以探查到的可见病变明确与不适有关[3]。

### Sources
[1] Feline dental problems (Proceedings): https://www.dvm360.com/view/feline-dental-proceedings-proceedings
[2] Feline odontoclastic resorptive lesions (Proceedings): https://www.dvm360.com/view/feline-odontoclastic-resorptive-lesions-proceedings
[3] Dental Corner: How to detect and treat feline odontoclastic resorptive lesions: https://www.dvm360.com/view/dental-corner-how-detect-and-treat-feline-odontoclastic-resorptive-lesions
[4] 9 types of oral pathology: https://www.dvm360.com/view/9-types-oral-pathology
[5] Classifying tooth resorption in cats and dogs: https://www.dvm360.com/view/classifying-tooth-resorption-in-cats-and-dogs

## 诊断方法

牙齿吸收的诊断需要在麻醉下进行全面的口腔检查并结合全口牙科X光摄影[1]。仅靠临床检查是不够的，因为大约60%的牙齿结构位于牙龈缘下方，在清醒检查时不可见[2]。

**临床检查结果**
在麻醉下，应使用牙科探针检查每颗牙齿，以检测表面缺陷、松动度以及在釉牙骨质界处特征性的樱桃红色增生性牙龈组织[3]。当探针勾住吸收性病变边缘时，会产生独特的"乒"声[4]。早期病变可能隐藏在牙垢和牙菌斑下，需要在检查前进行彻底的洁治[5]。

**必要的影像学技术**
口内牙科X光摄影对于准确诊断、分类和治疗计划至关重要[6]。仅影响牙骨质或釉质的1期病变通常仅通过临床检查识别，因为它们不显示X光变化[6]。晚期病变表现为在釉牙骨质界处有扇贝状边缘的局灶性或多灶性X线透射区[7]。

**分类和分期**
X光评估决定了类型和分期分类[1]。1型病变显示正常的牙周韧带间隙伴有局灶性X线透射区，而2型病变显示牙周韧带间隙变窄或消失，牙齿射线不透性降低，表明存在牙槽骨粘连[2]。五个分期描述了从釉质受累（1期）到牙冠完全缺失并伴有牙根残留（5期）的疾病进展[6]。

### Sources
[1] Classifying tooth resorption in cats and dogs: https://www.dvm360.com/view/classifying-tooth-resorption-in-cats-and-dogs
[2] The ABCs of veterinary dentistry: X is for intraoral x-rays: https://www.dvm360.com/view/the-abcs-of-veterinary-dentistry-x-is-for-intraoral-x-rays
[3] Dental Corner: How to detect and treat feline odontoclastic resorptive lesions: https://www.dvm360.com/view/dental-corner-how-detect-and-treat-feline-odontoclastic-resorptive-lesions
[4] Feline odontoclastic resorptive lesions (Proceedings): https://www.dvm360.com/view/feline-odontoclastic-resorptive-lesions-proceedings
[5] Periodontal disease in cats: Current best practices for diagnosis, treatment and prevention: https://www.dvm360.com/view/periodontal-disease-in-cats-current-best-practices-for-diagnosis-treatment-and-prevention
[6] Tooth Resorption in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals
[7] The importance of feline oral health (Proceedings): https://www.dvm360.com/view/importance-feline-oral-health-proceedings

## 治疗选择

牙齿吸收的治疗取决于准确的X光分类为1型或2型病变[1]。对于牙周韧带间隙完整的1型吸收，需要使用传统手术技术完全拔除牙冠和牙根[1][2]。对于牙根严重吸收且没有可辨别牙周韧带的2型病变，可以采用牙冠切除术和有意保留牙根的治疗方法[1][2]。

牙冠切除术涉及使用高速手机上的圆形碳化钨或金刚砂车针去除所有到达骨水平的牙齿结构，然后用5-0可吸收缝线材料缝合牙龈[2][3]。这种技术需要创建一个保守的牙周瓣，并确保在牙槽嵴处或略低于牙槽嵴处完全去除牙冠[1][3]。

多根牙每次都需要分割，将其转变为单根牙拔除[4][5]。关键技术包括创建适当的粘骨膜瓣、去除足够的颊侧骨以及应用"三十秒规则"--即施加20-30秒的轻柔持续压力以逐渐断裂牙周纤维[4]。结合术前和术后药物治疗以及区域神经阻滞的疼痛管理方案是取得成功结果所必需的[4]。

拔牙前后的完整X光评估确认了牙根的正确去除并指导治疗计划[4][5]。适当的器械，包括锋利的牙挺、牙撬和水冷车针，对于减少牙根折断或拔除不完全等并发症至关重要[5]。

### Sources
[1] Extractions in cats: indications, techniques and complications: https://www.dvm360.com/view/extractions-cats-indications-techniques-and-complications-proceedings
[2] Off with the crown?: https://www.dvm360.com/view/with-crown
[3] Tooth resorption in cats: https://www.dvm360.com/view/tooth-resorption-cats
[4] Surgical tooth extractions: https://www.dvm360.com/view/surgical-tooth-extractions-proceedings
[5] Taking the bite out of tooth extractions: https://www.dvm360.com/view/taking-bite-out-tooth-extractions

## 预防措施

目前对牙齿吸收预防的理解因该疾病的病因不明而受到很大限制[1][2]。由于特发性牙齿吸收的具体原因仍未确定，特别是在影响高达67%的猫中，无法建立有针对性的预防策略[1]。默克兽医手册指出"特发性病变无法预防，因为其病因不明"[2]。

最重要的预防方法侧重于通过定期牙科检查进行早期检测。在麻醉下进行全面的牙科评估并拍摄全口口内X光片是必不可少的，因为牙齿吸收无法仅通过清醒检查可靠地诊断[1]。由于高达86%接受牙科治疗的猫从X光片提供的额外临床有用信息中获益，这些影像学研究对于早期检测至关重要[4]。

一旦患者出现牙齿吸收的证据，应每年进行麻醉下的口腔检查和完整的X光评估，因为该疾病是进行性的，并且可能逐年快速变化[1][2]。2019年AAHA牙科护理指南强烈建议对所有牙科患者进行全口牙科X光检查，以避免忽略不明显的疾病[3]。

对于继发于牙周病的炎症性吸收，包括每日刷牙和牙菌斑控制的口腔卫生措施可以减缓疾病进展[2][9]。然而，对于影响多颗牙齿的特发性形式，除了在病变变得临床明显时进行密切监测和早期治疗外，没有特定的预防措施[1]。

### Sources

[1] Tooth resorption: Name it to tame it in your veterinary patients: https://www.dvm360.com/view/tooth-resorption-name-it-tame-it-your-veterinary-patients
[2] Tooth Resorption in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/tooth-resorption-in-small-animals
[3] Merck Veterinary Manual Periodontal Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[4] The importance of feline oral health (Proceedings): https://www.dvm360.com/view/importance-feline-oral-health-proceedings
[5] Dental prophylaxis: New oral medicaments and home care options (Proceedings): https://www.dvm360.com/view/dental-prophylaxis-new-oral-medicaments-and-home-care-options-proceedings

## 鉴别诊断

几种牙齿疾病可能模仿牙齿吸收，需要仔细的X光和临床评估来区分它们。牙周病经常出现类似的局部牙龈炎症和骨质丢失，特别是在1型牙齿吸收病例中[1]。然而，牙周病通常表现出明显的牙周袋形成，并保持正常的牙齿射线不透性，这与吸收性病变中特征性的密度降低不同。

牙齿折裂可能表现出类似的牙冠缺陷和继发性牙髓受累[1]。折裂牙齿通常显示清晰的外伤史并在X光片上保持正常的牙根结构，而牙齿吸收则表现为进行性牙根溶解或被骨样组织替代[2]。

牙髓疾病可引起根尖X线透射区，类似于吸收性变化[1]。关键的鉴别特征是牙髓病理通常起源于牙髓腔并向根尖方向延伸，而牙齿吸收通常从颈区外部开始并向内进展[2]。

龋齿虽然在猫中罕见且在狗中不常见，但可能产生类似于吸收性病变的牙冠缺损[1]。龋齿病变在牙科探查时感觉柔软并显示棕色变色，而吸收性缺损通常表现为被肉芽组织覆盖的、坚硬的、充满粉红色组织的缺损[2]。

外部炎症性吸收与替代性吸收的不同之处在于在X光片上保持可见的牙周韧带间隙，表明是炎症性而非粘连过程[2]。

### Sources
[1] Radiographic diagnosis of canine oral pathology: https://www.dvm360.com/view/radiographic-diagnosis-canine-oral-pathology-proceedings
[2] Tooth resorption in cats: https://www.dvm360.com/view/tooth-resorption-cats
