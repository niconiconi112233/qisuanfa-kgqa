# 伴侣动物三尖瓣反流

三尖瓣反流是犬猫中的一种重要心脏疾病，包括先天性瓣膜发育不良和后天性瓣膜关闭不全。该病症涉及血液从右心室异常反流至右心房，若不治疗可导致进行性右侧心力衰竭。虽然三尖瓣反流比左侧瓣膜病少见，但对兽医临床医生而言，其诊断和治疗具有独特挑战。某些品种，特别是拉布拉多寻回犬和德国牧羊犬，对先天性三尖瓣发育不良表现出更高的易感性。本综述全面探讨了小动物临床实践中获得最佳患者治疗效果所需的病理生理学、临床表现、诊断方法和治疗策略。

## 预后与管理总结

伴侣动物三尖瓣反流的预后因潜在病因和疾病严重程度而异。患有退行性三尖瓣疾病的猫在适当医疗管理下可存活数年，而伴有扩张型心肌病的犬预后更为谨慎，特别是杜宾犬在充血性心力衰竭状态下存活4-6个月，而巨型犬种可能存活约一年。

| 预后因素 | 良好预后 | 不良预后 |
|-------------------|-------------------|--------------|
| 物种 | 患退行性疾病的猫 | 患扩张型心肌病的犬 |
| 品种 | 巨型犬（大丹犬） | 杜宾犬 |
| 临床症状 | 无症状性杂音 | 晕厥、心律失常 |
| 疾病阶段 | 早期发现 | 难治性心力衰竭 |

通过品种特异性筛查和超声心动图评估进行早期发现至关重要。使用利尿剂、ACE抑制剂和匹莫苯丹的药物治疗可有效控制症状并提高生活质量。兽医临床医生应重点防止患病动物繁殖，并对易感品种实施定期心脏筛查方案，以优化长期预后。

## 疾病概述

伴侣动物三尖瓣反流是指在收缩期血液通过三尖瓣从右心室异常反流至右心房。该病症包括先天性三尖瓣发育不良和后天性三尖瓣关闭不全[1][2]。

**三尖瓣发育不良**定义为三尖瓣瓣叶或三尖瓣复合体任何组分的先天性畸形，包括腱索缩短或缺失以及瓣叶增厚，后者可能粘连于心室壁[2]。犬先天性心脏病的患病率估计低于1%，其中三尖瓣发育不良是较不常见的缺陷之一[3]。

**品种易感性**已有明确记载，拉布拉多寻回犬和德国牧羊犬是三尖瓣发育不良最常见的受累品种[2]。该疾病可发生于犬和猫，但在犬中更为常见[1]。

**发病年龄**因疾病是先天性还是后天性而异。先天性三尖瓣发育不良出生时即存在，但临床症状可能要等到数月或数年后才出现，具体取决于严重程度。该疾病可能伴有其他并发先天性异常，包括二尖瓣发育不良、间隔缺损或狭窄性病变[2]。

### Sources
[1] Congenital diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/congenital-diseases-dog-and-cat-proceedings
[2] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals
[3] Overview of Congenital and Inherited Anomalies of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/overview-of-congenital-and-inherited-anomalies-of-the-cardiovascular-system-in-animals
[4] Current strategies on diagnosis and treatment of feline cardiomyopathy (Proceedings): https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings

## 常见病原体

犬猫三尖瓣反流可由感染性原因引起，但与先天性畸形和后天性退行性疾病相比，这些病例占少数。

**细菌性心内膜炎**
感染性心内膜炎很少影响小动物的三尖瓣[1]。从患有感染性心内膜炎的犬猫中最常分离出的细菌包括链球菌属、葡萄球菌属、克雷伯菌属和大肠杆菌[1]。巴尔通体也是犬心内膜炎的公认病因，但通常影响主动脉瓣[1]。当三尖瓣受感染时，可引起腹水和颈静脉搏动[1]。

**先天性 vs. 后天性鉴别**
后天性感染性三尖瓣反流的主要鉴别诊断是先天性三尖瓣发育不良[2]。三尖瓣发育不良是一种先天性畸形，最常见于拉布拉多寻回犬和德国牧羊犬[3]。与感染性心内膜炎不同，发育不良的瓣膜表现为瓣叶畸形、腱索缩短或缺失，以及出生时即存在的结构异常[3]。

**病毒性原因**
虽然病毒病原体可引起心肌炎导致继发性瓣膜关闭不全，但三尖瓣的直接病毒感染在兽医文献中未见充分记载。大多数三尖瓣反流是由结构异常而非原发性感染过程引起的。

### Sources
[1] Infectious Endocarditis in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats
[2] Current strategies on diagnosis and treatment of feline cardiomyopathy (Proceedings): https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings
[3] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals

## 临床症状和体征

三尖瓣反流根据疾病严重程度表现出从无症状到有症状阶段的可变临床表现[1]。在早期阶段，尽管存在瓣膜功能障碍，许多动物仍保持无症状[1]。

**运动不耐受**是最常见的临床表现之一，表现为活动耐力降低、虚弱和疲劳[2][3][4]。这是由于肺血流量减少和心输出量受损所致。随着病情进展，动物可能因右心容量负荷过重而出现**呼吸急促**和**呼吸困难**[1]。

**右侧心力衰竭体征**随着疾病进展变得显著。这些包括**腹水**（腹腔积液）、**颈静脉怒张**，可能还有胸腔积液[1][5][6]。右心房压力增加损害静脉回流，导致这些充血体征。患有中重度三尖瓣发育不良的犬通常有明显右心房扩张，以及后腔静脉扩张和肝肿大[6]。

**心脏杂音**是关键的诊断发现，通常表现为**在右侧心尖部最响亮的全收缩期杂音**[1][5][6]。一些资料将其描述为**5/6级右侧心尖部、粗糙、带状、全收缩期杂音**[7]。然而，一些动物尽管存在瓣膜功能障碍，可能没有可听到的杂音，特别是轻度疾病患者[1][6]。

存在**品种特异性模式**，拉布拉多寻回犬和德国牧羊犬对三尖瓣发育不良表现出易感性[1]。**房性心律失常**，特别是阵发性室上性心动过速，可能作为并发症出现[1]。

进展通常遵循从无症状杂音检测到运动受限的模式，然后在晚期病例中出现右侧充血体征[3][5]。

### Sources
[1] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals
[2] Description of clinical findings, diagnosis, and treatment of ...: https://avmajournals.avma.org/view/journals/javma/263/8/javma.24.08.0560.xml
[3] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings
[4] Epicardial pacemaker placement is associated with low ...: https://avmajournals.avma.org/view/journals/javma/262/10/javma.24.04.0232.xml
[5] Merck Veterinary Manual Tricuspid Valve Dysplasia in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/tricuspid-valve-dysplasia-in-animals
[6] Murmurs in puppies and kittens (Proceedings): https://www.dvm360.com/view/murmurs-puppies-and-kittens-proceedings
[7] ECG of the Month in: Journal of the American Veterinary ...: https://avmajournals.avma.org/view/journals/javma/248/11/javma.248.11.1245.xml

## 诊断方法

体格检查发现包括收缩期杂音，通常在右侧第四肋间隙靠近肋软骨连接处听诊最清晰[1]。患有中重度三尖瓣反流的犬，杂音可能可闻及，但轻度三尖瓣反流的犬在听诊时通常没有可检测到的杂音[2]。

超声心动图仍然是诊断和评估三尖瓣反流严重程度的金标准[3]。彩色血流和频谱多普勒技术在右胸骨旁和左心尖切面评估反流束。最大三尖瓣反流速度测量有助于计算跨瓣压力梯度，从而区分轻度、中度和重度疾病状态[3]。

胸部X线和心电图可能显示右心室和心房扩大，但这些发现是非特异性的[4]。体格检查、超声心动图评估和支持性诊断测试的结合使临床医生能够全面评估疾病严重程度，并根据血流动力学影响指导适当的治疗决策。

NT-proBNP检测是一种有价值的心脏生物标志物，其从拉伸的心室心肌释放，与疾病严重程度成正比[5]。该生物标志物有助于区分心源性和非心源性呼吸困难原因，并在评估三尖瓣反流患者时提供额外的诊断支持。

### Sources
[1] Performing a cardiovascular physical examination: https://www.dvm360.com/view/performing-cardiovascular-physical-examination
[2] Murmurs in puppies and kittens (Proceedings): https://www.dvm360.com/view/murmurs-puppies-and-kittens-proceedings
[3] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[4] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[5] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 治疗选择

三尖瓣反流的医疗管理仍然是治疗的主要手段，重点是在存在右侧充血性心力衰竭时进行控制。基础治疗包括利尿剂如呋塞米以管理液体积聚和腹水[1]。ACE抑制剂如依那普利或贝那普利通常用于减少全身充血并抑制肾素-血管紧张素系统的激活[2]。

匹莫苯丹是一种正性肌力药和血管扩张剂，常用于继发于三尖瓣反流的充血性心力衰竭犬[3]。该药物已被证明可改善心脏病犬的生活质量和生存时间[4]。对于患有心肌衰竭和心力衰竭的猫，匹莫苯丹可能有益，特别是那些接受最大剂量呋塞米但仍患有难治性充血性心力衰竭的猫[5]。

对于难治性液体积聚病例，可添加其他利尿剂如螺内酯和氢氯噻嗪[2]。三尖瓣反流的早期治疗旨在管理慢性症状，可能包括使用利尿剂减少血管内容量[6]。

三尖瓣修复或置换的手术选择在兽医学中极为有限。与人类医学中瓣膜修复是常规操作不同，在体外循环下进行手术瓣膜修复或置换仅由少数经验丰富的心脏外科医生成功实施[8]。这些手术费用昂贵且死亡率高，限制了其在中大型品种成年犬中的应用。

大多数病例需要姑息性医疗管理，重点是通过适当的药物治疗方案控制右侧心力衰竭症状并优化生活质量。

### Sources

[1] Infectious Endocarditis in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats

[2] Acquired cardiac diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings

[3] Heart failure and scary arrhythmias (Proceedings): https://www.dvm360.com/view/heart-failure-and-scary-arrhythmias-proceedings

[4] Treatment of Cardiovascular Disease in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/treatment-of-cardiovascular-disease-in-dogs

[5] Current strategies on diagnosis and treatment of feline cardiomyopathy (Proceedings): https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings

[6] Management of heart failure (Proceedings): https://www.dvm360.com/view/management-heart-failure-proceedings

[7] Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats

[8] Murmurs in puppies and kittens (Proceedings): https://www.dvm360.com/view/murmurs-puppies-and-kittens-proceedings

## 预防措施

三尖瓣反流的预防主要侧重于管理遗传易感性并对高风险品种实施筛查方案。繁殖建议至关重要，因为某些品种对导致三尖瓣反流的疾病表现出更高的易感性[1]。

**繁殖建议和筛查**
拉布拉多寻回犬和德国牧羊犬易患三尖瓣发育不良，需要谨慎的繁殖选择[7]。患有先天性心脏缺陷的犬不应繁殖，因为在大多数情况下遗传原因可能或确实存在[6]。通过超声心动图进行繁殖前心脏筛查至关重要，特别是因为一些三尖瓣异常可能不会产生可听到的杂音[8]。

**早期发现策略**
在常规检查期间定期进行心脏听诊可早期发现提示三尖瓣反流的杂音[1]。A期监测包括心脏病高风险犬，如杜宾犬（扩张型心肌病风险）和骑士查理王小猎犬（二尖瓣反流风险），通过定期听诊或超声心动图进行[1]。

**易感疾病的管理**
预防包括控制可能导致继发性三尖瓣反流的潜在疾病。这包括通过预防心丝虫病来管理肺动脉高压，治疗慢性呼吸系统疾病，以及处理可能进展为右侧受累的左侧心力衰竭[1][5]。心脏病患者的血压监测有助于预防可能加重瓣膜反流的高血压相关并发症[9]。

### Sources
[1] Management of acquired canine heart disease: part 1 & 2: https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings
[5] Acquired cardiac diseases of the dog and cat: https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings
[6] Congenital and Inherited Disorders of the Cardiovascular System in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/congenital-and-inherited-disorders-of-the-cardiovascular-system-in-dogs
[7] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals
[8] Congenital diseases of the dog and cat: https://www.dvm360.com/view/congenital-diseases-dog-and-cat-proceedings
[9] Back to basics: clinical cardiovascular exam and diagnostic testing: https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings

## 鉴别诊断

三尖瓣反流有几种鉴别诊断，必须通过临床评估和诊断测试仔细区分。

**先天性心脏缺陷**是主要的鉴别诊断组。房间隔缺损（ASD）通常导致右侧容量负荷过重，但由于肺动脉瓣血流量增加而非可闻及的反流，通常只产生柔和的收缩期杂音[2]。室间隔缺损（VSD）以其特征性的响亮全收缩期杂音易于区分，该杂音在右侧胸部听诊最清晰，常伴有可触及的震颤[1,2]。动脉导管未闭表现为左侧心底部特征性的连续性"机器样"杂音和洪脉[1,2]。

**肺动脉狭窄**造成右心室压力负荷过重，导致继发性三尖瓣反流。鉴别特征是左侧心底部的递增-递减收缩期喷射性杂音，X线片上常可见狭窄后肺动脉扩张[1]。超声心动图显示狭窄病变并允许评估压力梯度。

**后天性三尖瓣疾病**包括类似于二尖瓣病的退行性改变，特别是在小型犬中。然而，原发性三尖瓣反流通常没有可闻及的杂音，使筛查具有挑战性[5]。

**肺动脉高压**常导致继发性三尖瓣反流，是一个关键的鉴别诊断。临床症状包括运动不耐受、晕厥和发绀[6]。超声心动图评估显示三尖瓣反流速度升高（>3.5 m/s提示肺动脉高压）和右心室改变[6]。

关键鉴别因素包括杂音特征、潜在结构异常的超声心动图发现，以及通过反流束的多普勒评估评估肺动脉压力。

### Sources

[1] Congenital heart disease (Proceedings): https://www.dvm360.com/view/congenital-heart-disease-proceedings
[2] Cardiac Shunts in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/cardiac-shunts-in-animals
[5] Congenital diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/congenital-diseases-dog-and-cat-proceedings
[6] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment

## 预后

三尖瓣反流的预后因潜在病因、疾病严重程度和并存疾病的存在而有显著差异。对于患有影响三尖瓣的退行性瓣膜病的猫，适当治疗可使其存活数年，尽管治疗通常仅在心力衰竭体征出现时才开始[1]。

涉及三尖瓣反流的心脏病在不同物种和品种之间的生存时间差异很大。患有扩张型心肌病并出现充血性心力衰竭的犬，生存期通常较差。患有充血性心力衰竭的杜宾犬经治疗后通常存活4-6个月，而像大丹犬和爱尔兰猎狼犬这样的巨型犬通常有更好的预后，即使患有充血性心力衰竭也可能存活约一年[2]。

关键预后因素包括心律失常和晕厥的存在。患有慢性退行性瓣膜病的犬可能因三尖瓣退行性变或继发性肺动脉高压而发展为右侧心力衰竭[3]。室性心律失常，特别是在杜宾犬等品种中，显著恶化预后并可能导致心源性猝死[4]。

生活质量考虑在管理三尖瓣反流中至关重要。虽然治疗可以控制液体积聚的体征并改善心功能，但潜在疾病的进行性性质意味着大多数患者将经历运动耐力下降并最终发展为难治性心力衰竭[4]。

### Sources

[1] Acquired Heart and Blood Vessel Disorders in Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/acquired-heart-and-blood-vessel-disorders-in-cats

[2] Oh my, myopathy!?!: https://www.dvm360.com/view/oh-my-myopathy

[3] Managing chronic valvular disease (Proceedings): https://www.dvm360.com/view/managing-chronic-valvular-disease-proceedings

[4] Management of acquired canine heart disease: part 1 & 2 (Proceedings): https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings
