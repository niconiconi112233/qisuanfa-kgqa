# 伴侣动物慢性牙龈口炎

慢性牙龈口炎是兽医医学中最具挑战性的炎症性口腔疾病之一，尤其影响猫，导致严重、疼痛的口腔病变，显著降低生活质量。这种使人衰弱的疾病特征是口腔黏膜持续炎症，呈现独特的鲜红色鹅卵石样组织外观，影响所有年龄和品种的猫。该报告探讨了涉及猫杯状病毒和疱疹病毒等病毒病原体、免疫功能障碍和口腔微生物群失衡的复杂多因素病因学。重点领域包括利用组织病理学和先进影像学的诊断方法，从完全拔牙到干细胞治疗和大麻素等新兴疗法的综合治疗策略，以及影响受影响患者长期结果的预后因素。

## 摘要

慢性牙龈口炎作为一种复杂的免疫介导性疾病出现，对伴侣动物具有显著的临床影响。该病表现为多因素病因，涉及猫杯状病毒（见于50-100%的病例）、疱疹病毒1型以及以多克隆丙种球蛋白病和淋巴细胞-浆细胞浸润为特征的免疫功能障碍。诊断需要在麻醉下进行综合评估，包括组织病理学和牙科X线摄影，其独特的尾部口炎模式将其与其他口腔炎症性疾病区分开来。

治疗方法成功率差异很大：

| 治疗方法 | 成功率 | 临床结果 |
|---|---|---|
| 完全前臼齿/臼齿拔除 | 80%良好反应 | 60%治愈，20%显著改善 |
| 干细胞治疗 | 72%阳性反应 | 难治性病例的新兴选择 |
| 单纯药物治疗 | 变化，暂时性 | 需要终身支持性护理 |

大约20%的病例即使在完全拔牙后仍然难治，需要终身使用非甾体抗炎药和免疫调节药物进行管理。早期手术干预可提供最佳结果，避免长期依赖皮质类固醇。包括大麻素和ω干扰素在内的新疗法的出现为以前无法治疗的病例带来了希望，强调了兽医口腔医学中多模式治疗方法的重要性。

## 疾病概述与流行病学

猫慢性牙龈口炎（FCGS）是一种严重的炎症性疾病，特征是口腔黏膜持续炎症，表现为充血、增生和溃疡组织，呈现特征性的鲜红色鹅卵石样外观[1]。这种使人衰弱的疾病可影响任何年龄和品种的猫，包括家养短毛猫，这与早期报道提出的纯种猫易感性相反[3]。

FCGS的流行率数据仍然有限但令人担忧。在美国，大约13.1%在兽医诊所检查的猫患有牙龈炎，24.2%患有牙结石[1][4]。一项涉及4,858只猫的英国初级保健研究报告了特定的FCGS患病率为0.7%[1][4]。然而，由于诊断挑战和临床实践中的漏报，这些数字可能低估了真实患病率。

已确定多个流行病学风险因素。免疫抑制状态，特别是猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）感染，可能增加易感性，尽管一些研究发现逆转录病毒感染与FCGS发展之间无显著相关性[1]。在一项涉及8,982只患有包括牙龈口炎在内的口腔疾病的大型研究中，14.2%的猫FeLV和/或FIV呈阳性[1]。多猫家庭可能通过病毒传播和压力因素呈现增加的风险，但关于家庭构成的具体数据需要进一步研究。

### Sources
[1] Feline stomatitis/gingivitis: How frustrating is that? (Proceedings): https://www.dvm360.com/view/feline-stomatitisgingivitis-how-frustrating-proceedings
[2] Dental radiographic findings in cats with chronic ...: https://avmajournals.avma.org/view/journals/javma/244/3/javma.244.3.339.xml
[3] Dental Corner: Feline gingivostomatitis: How to relieve the oral discomfort: https://www.dvm360.com/view/dental-corner-feline-gingivostomatitis-how-relieve-oral-discomfort
[4] The importance of feline oral health (Proceedings): https://www.dvm360.com/view/importance-feline-oral-health-proceedings

## 病因学与发病机制

猫慢性牙龈口炎（FCGS）具有复杂的、多因素的病因，涉及病毒病原体、免疫功能障碍和口腔微生物群失衡[1]。该病被认为是一种免疫介导性疾病，由对多种抗原的不适当炎症反应引起[2]。

**病毒病原体**
多种病毒因子与FCGS相关。可以从50%到100%的受影响猫中分离出猫杯状病毒（FCV），高达88%患有口炎的猫在唾液中同时排出FCV和猫疱疹病毒1型（FHV-1）[1]。FHV-1感染引起口腔溃疡，并在大约30%的受影响猫中建立潜伏性、持续性感染[3]。虽然10%到81%患有口炎的猫可能猫免疫缺陷病毒（FIV）呈阳性，但猫白血病病毒（FeLV）患病率持续较低，为0%到17%[1]。

**免疫学机制**
FCGS表现出明显的免疫介导特征。受影响的猫表现出多克隆丙种球蛋白病，血清IgG、IgM和IgA浓度增加，大约三分之一的病例还有IgE增加[1]。口腔病变内明显的淋巴细胞-浆细胞浸润表明慢性炎症发病机制[1]。该病被认为代表了对斑块滞留表面或牙周韧带上的斑块细菌的过度免疫反应[2]。

**微生物群和细菌因素**
包括汉塞巴尔通体（*Bartonella henselae*）在内的细菌可能起次要作用，表现出口腔炎症的猫比健康猫更可能感染巴尔通体[1]。然而，细菌可能对发病机制起次要作用，因为广泛的上皮下圆形细胞浸润导致上皮破裂、溃疡和随后的细菌感染[1]。

### Sources
[1] Feline stomatitis: How to treat a diseae of unknown etiology: https://www.dvm360.com/view/feline-stomatitis-how-treat-diseae-unknown-etiology
[2] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[3] Feline viral skin diseases (Proceedings): https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings

## 临床表现与诊断

### 临床症状与体征
患有慢性牙龈口炎的猫表现出独特的临床表现。猫表现出部分到完全厌食，通常避免饮食中的硬质部分，伴有流涎（流口水）、口臭、体重减轻和口腔疼痛[1]。体格检查显示牙龈炎、口炎，以及可能的腭炎、舌炎、唇炎、咽炎和下颌淋巴结病[1]。

口腔炎症通常是广泛的，受影响的组织表现为溃疡、增生和充血[1]。严重炎症的常见部位是腭舌褶外侧（尾部口炎）[1]。尾部口炎的存在将FCGS与其他炎症性口腔黏膜疾病区分开来[2]。炎症性病变常被误认为是口腔感染，但慢性牙龈口炎代表的是炎症而非感染[1]。

### 诊断方法
诊断需要在全身麻醉下进行综合评估。完整的患者评估包括体格检查、全血细胞计数、血清化学分析谱以及猫白血病病毒和猫免疫缺陷病毒的血清学检测[1]。实验室结果通常无异常，除了口腔病变、下颌淋巴结病和高球蛋白血症[1]。

口腔内牙科X线摄影是必要且对正确诊断至关重要[1]。先进的影像技术，特别是计算机断层扫描（CT）和磁共振成像（MRI），对诊断、建立准确预后和治疗计划特别有帮助[3]。

明确诊断需要在几个活动性炎症组织部位使用4毫米皮肤活检打孔器进行组织学检查[1]。组织学检查通常显示浆细胞性口炎或淋巴细胞-浆细胞性口炎[1]。

### Sources
[1] Dental Corner: Feline gingivostomatitis: How to relieve the oral discomfort: https://www.dvm360.com/view/dental-corner-feline-gingivostomatitis-how-relieve-oral-discomfort
[2] Erosive and ulcerative stomatitis in dogs and cats: which: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0573.xml
[3] Veterinary dentistry and oral surgery for geriatric patients: https://www.dvm360.com/view/veterinary-dentistry-and-oral-surgery-geriatric-patients

I need to synthesize the existing section content with the source material to expand the Treatment Approaches section. The existing content is already comprehensive and well-structured, so I'll integrate the new information on cannabinoids while maintaining the established flow and organization.

## 治疗方法

慢性牙龈口炎治疗遵循以减轻炎症和提供疼痛缓解为中心的多模式方法。手术干预仍然是金标准，拔牙显示出最高的成功率。研究表明，80%的猫对完全前臼齿和臼齿拔除反应良好，60%达到临床治愈，另外20%显示显著改善[1]。

医疗管理包括抗炎治疗，尽管选择存在挑战。甲基强的松龙醋酸酯（每三周皮下注射20毫克/猫）提供短期缓解，但长期使用存在糖尿病和医源性肾上腺皮质功能亢进的风险[2]。针对革兰氏阴性厌氧菌的抗生素治疗可能提供初步益处，尽管效果随时间减弱[2]。

新的治疗方法为难治性病例显示出希望。猫重组ω干扰素已在杯状病毒阳性猫中显示出成功，一例病例报告显示在皮下和口服给药后病情缓解[1]。干细胞治疗代表了一种新兴的治疗方式，加州大学戴维斯分校在临床试验中报告了72%的阳性反应率[3]。大麻素治疗已成为另一种选择，研究表明每天一次口服给予约1毫克/公斤稀释在水中的CBD基粉末，对患有慢性牙龈口炎的猫提供轻微益处，特别是在防止快速体重减轻方面与安慰剂组相比[4]。其他实验性疗法包括环孢素、牛乳铁蛋白和组织减容的激光消融[1][2]。

大约20%的病例即使在完全拔牙后仍然难治，需要终身支持性护理，包括吡罗昔康等非甾体抗炎药和免疫调节药物[2]。建议早期手术干预以避免长期依赖皮质类固醇并优化治疗结果。

### Sources
[1] Potential help for refractory feline chronic gingivo-stomatitis: https://www.dvm360.com/view/potential-help-refractory-feline-chronic-gingivo-stomatitis-proceedings
[2] Dental Corner: Feline gingivostomatitis: How to relieve the oral discomfort: https://www.dvm360.com/view/dental-corner-feline-gingivostomatitis-how-relieve-oral-discomfort
[3] UC Davis veterinary hospital debuts Stomatitis Clinic: https://www.dvm360.com/view/uc-davis-veterinary-hospital-debuts-stomatitis-clinic
[4] Cannabinoids and pain in small animal medicine: https://www.dvm360.com/view/cannabinoids-and-pain-in-small-animal-medicine

## 预防与预后

目前，伴侣动物慢性牙龈口炎预防没有特定的疫苗接种方案[1]。然而，常规的猫杯状病毒和疱疹病毒疫苗接种可能有助于减少病毒相关的口腔炎症，因为这些病毒经常在受影响的猫中发现[1,9]。环境管理侧重于压力减轻和通过定期兽医牙科护理维持最佳口腔卫生[9]。

每日口腔卫生实践是预防的基石。使用宠物安全牙膏定期刷牙、氯己定漱口水和适当的洁牙咀嚼玩具可以显著减少牙菌斑积聚[7]。应在麻醉下进行专业牙科清洁，每年一次或根据个体患者需要推荐进行[1,7,10]。

预后因治疗方法和患者反应而有很大差异。在猫慢性牙龈口炎中，全口拔牙在大约60%的病例中实现治愈或显著改善，另外20%显示显著改善[1,6]。然而，大约20%的猫发展为难治性口炎，需要终身管理[1,6]。

早期干预提供最有利的结果。通过包括手术拔除和适当医疗管理的积极治疗，许多患者可以实现长期缓解[1,6,9]。不良预后指标包括延迟诊断、广泛组织受累、并发免疫抑制疾病和家庭护理依从性不足[1,9]。定期监测和关于口腔卫生维护的主人教育对于最佳长期管理和预防疾病复发至关重要。

### Sources

[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[2] Feline stomatitis/gingivitis: How frustrating is that? (Proceedings): https://www.dvm360.com/view/feline-stomatitisgingivitis-how-frustrating-proceedings
[3] Dental Pain and Inflammation-Acute and Chronic: https://www.dvm360.com/view/dental-pain-and-inflammation-acute-and-chronic
[4] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings
[5] The gold standard of veterinary oral health care (Proceedings): https://www.dvm360.com/view/gold-standard-veterinary-oral-health-care-proceedings
