# 宠物中的葡萄和葡萄干中毒

葡萄和葡萄干中毒是犬类中最危险的食物相关中毒之一，可在摄入后72小时内导致致命的急性肾衰竭。尽管经过数十年的研究，确切的中毒机制仍不清楚，但肾小管细胞中酒石酸积累是主要理论。这种中毒对犬类的影响不可预测，没有确定的安全阈值--即使在易感动物中，单颗葡萄也被证明是致命的。

本报告探讨了目前对葡萄和葡萄干中毒的理解，从涉及有机酸转运缺陷的病理生理学到从胃肠不适到少尿性肾衰竭的临床进展。主要主题包括使用连续肾功能监测的早期诊断方法、强调立即净化和积极液体治疗的循证治疗方案，以及决定患者是完全康复还是进展为致命肾衰竭的预后因素。

## 疾病概述和病理生理学

葡萄和葡萄干中毒是犬类的一种危及生命的疾病，特征是急性胃肠道症状进展为少尿或无尿性肾衰竭[1]。这种中毒偶尔在摄入葡萄、葡萄干、赞廷醋栗（葡萄属）和罗望子（罗望子属）后报告[1]。病例主要在犬类中有记录，猫和雪貂有轶事报告，但这些物种没有已发表的病例报告[1]。

确切的中毒机制仍不清楚，给临床管理带来挑战[2]。已经提出了几种假设，包括存在肾毒素、农药污染、重金属污染、高维生素D浓度和霉菌毒素污染，但调查结果均为阴性[2]。

最广泛接受的理论涉及酒石酸作为毒性原理[1]。犬类缺乏其他物种中存在的有机酸转运体，导致酒石酸在近端肾小管细胞中积累[1]。这一机制得到了近期研究的支持，这些研究表明酒石酸会诱导犬肾细胞而非人肾细胞的毒性，并且有机阴离子转运体抑制可防止毒性[1]。不同水果的酒石酸含量不同，导致毒性程度不同[1]。通常，每4.5公斤体重超过一颗葡萄或葡萄干可能含有足够的酒石酸以引起肾脏效应[1]。

受影响的犬通常在摄入后72小时内发展为少尿或无尿性肾衰竭[1]。组织病理学发现包括肾小管坏死、转移性矿化和肾小管上皮再生的证据[2]。

### Sources
[1] Grape, Raisin, and Tamarind - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/grape-raisin-and-tamarind-vitis-spp-tamarindus-spp-toxicosis-in-dogs
[2] Raisins and grapes: Potentially lethal treats for dogs - dvm360: https://www.dvm360.com/view/raisins-and-grapes-potentially-lethal-treats-dogs

## 诊断方法

葡萄和葡萄干中毒的诊断主要依赖于详细的接触史和临床表现，因为没有特定的实验室检测可以检测毒性化合物[1]。诊断基于患者病史、临床症状和连续实验室监测的综合判断[1]。

**病史和临床评估**
详细记录过去72小时内摄入葡萄或葡萄干的病史至关重要[1]。应仔细评估植物可获得性、潜在接触机会和植物消耗证据[2]。

**实验室检查结果**
连续监测肾脏参数对诊断和预后至关重要。血清肌酐浓度通常相对于血尿素氮(BUN)水平不成比例地升高[1]。在接触后12-24小时，临床病理异常包括氮质血症、高磷酸盐血症和高钙血症[5]。基础血液检查应包括肾功能值和红细胞压积/总蛋白，并在48-72小时内每24小时重复一次[3]。

**尿液分析**
尿液分析显示等渗尿，常见颗粒管型[5]。少尿或无尿被视为关键发展，尿液产生监测对预后至关重要[1][3]。

**影像学研究**
虽然诊断通常不需要影像学检查，但可能需要进行影像学检查以排除急性肾衰竭的其他原因或评估并发症[1]。

关键诊断挑战是区分葡萄/葡萄干中毒与其他急性肾衰竭原因，特别是乙二醇中毒和其他肾毒性接触[1]。

### Sources
[1] Grape, Raisin, and Tamarind (Vitis spp, Tamarindus spp) Toxicosis in Dogs: https://www.merckvetmanual.com/toxicology/food-hazards/grape-raisin-and-tamarind-vitis-spp-tamarindus-spp-toxicosis-in-dogs
[2] Toxic plants (Proceedings): https://www.dvm360.com/view/toxic-plants-proceedings-0
[3] The most common poisons for pets: https://www.dvm360.com/view/the-most-common-poisons-for-pets
[4] The usual suspects: Top 10 toxins poisonous to pets: https://www.dvm360.com/view/usual-suspects-top-10-toxins-poisonous-pets
[5] Tasty treats pets should avoid (Proceedings): https://www.dvm360.com/view/tasty-treats-pets-should-avoid-proceedings

## 治疗选择

葡萄和葡萄干中毒的有效治疗需要立即干预，重点是净化、支持性护理和肾脏保护[1]。早期胃净化是无症状患者治疗的基石。

**净化方案**应在稳定患者中迅速启动。可使用罗匹尼罗(2.7-5.4 mg/m²，结膜)、阿扑吗啡(0.03-0.04 mg/kg，IV首选)或3%过氧化氢(1-2 mL/kg，PO，最大45 mL)诱导呕吐[1]。在摄入后6小时内诱导呕吐仍然有效，大量摄入可能在接触后12小时仍能排出水果物质[2]。活性炭的效果仍不确定，但可能仍有益处[1]。

**静脉液体治疗**构成支持性护理的基础。对于大量摄入或在12小时内出现腹泻的情况，建议进行至少48小时的积极静脉液体利尿[1]。2024年AAHA液体治疗指南建议采用针对个体患者需求的定向液体处方，而不是标准化速率[3]。液体治疗维持肾脏灌注，增强毒素消除，并防止管型引起的肾小管阻塞[4]。

**少尿/无尿的管理**需要额外干预。对于少尿患者，多巴胺(0.5-3 mcg/kg/min，IV)、呋塞米(2 mg/kg，IV)或两者联合可能刺激尿液产生[1]。然而，少尿/无尿是预后不良的指标[2]。无尿患者除非开始腹膜透析或血液透析，否则不太可能存活[1]。

**监测参数**包括在48-72天内每天评估BUN、肌酐和磷[2]。在整个治疗过程中必须监测肾功能和液体平衡[1]。

### Sources
[1] Grape, Raisin, and Tamarind - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/grape-raisin-and-tamarind-vitis-spp-tamarindus-spp-toxicosis-in-dogs
[2] Raisins and grapes: Potentially lethal treats for dogs - dvm360: https://www.dvm360.com/view/raisins-and-grapes-potentially-lethal-treats-dogs
[3] 2024 AAHA Fluid Therapy Guidelines for Dogs and Cats: https://meridian.allenpress.com/jaaha/article/60/4/131/501375/2024-AAHA-Fluid-Therapy-Guidelines-for-Dogs-and
[4] Prevalence of acute kidney injury and outcome in cats treated as inpatients versus outpatients following lily exposure: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml

## 预防措施

葡萄和葡萄干中毒预防的基石是完全避免所有葡萄制品[1]。必须教育宠物主人从宠物环境中清除葡萄、葡萄干、赞廷醋栗和罗望子，并且永远不要将这些水果作为零食提供。这包括隐藏来源，如含有葡萄干糊的格兰诺拉麦片棒、什锦果仁和烘焙食品，尽管葡萄酒和葡萄果酱与中毒无关[1]。

教育努力应强调这种毒性的不可预测性，因为没有确定的安全阈值，且个体易感性差异很大[1]。据报道，在某些犬中，单颗葡萄就能引起毒性，使任何接触都具有潜在危险[1]。应指导客户如果发生摄入，立即寻求兽医护理，因为在18小时内早期干预比延迟治疗显著改善结果[1]。

## 鉴别诊断

葡萄和葡萄干中毒必须与犬猫中其他急性肾损伤原因区分开来。主要鉴别包括乙二醇中毒，其表现为相似的肾衰竭，但通常显示特征性草酸钙结晶尿并对特定解毒剂有反应[1]。胆钙化醇中毒引起高钙血症和高磷酸盐血症伴随肾损伤，这将其与葡萄中毒区分开来[1]。

NSAID中毒表现为胃肠道和肾脏症状，但通常有明确的药物接触史[1]。猫中的百合中毒引起相似的急性肾损伤，但仅影响猫科动物，并有独特的植物材料接触史[1]。

## 预后

葡萄和葡萄干中毒的预后关键取决于干预时机和肾衰竭的发展。在18小时内接受及时净化和液体治疗的犬通常预后良好，大多数只出现轻微的胃肠道症状[1]。

然而，当治疗延迟超过18小时时，预后变得谨慎到不良[1]。一旦发展为少尿或无尿性肾衰竭，大多数犬尽管接受积极治疗仍会死亡或需要安乐死[1]。据报道，由葡萄干引起急性肾衰竭的犬的死亡率高达50-75%[3]。建议在接触后连续三天监测血清化学，因为此期间后的正常值表明不太可能进展为肾衰竭[2]。

### Sources
[1] Grape, Raisin, and Tamarind (Vitis spp, Tamarindus spp) Toxicosis in Dogs: https://www.merckvetmanual.com/toxicology/food-hazards/grape-raisin-and-tamarind-vitis-spp-tamarindus-spp-toxicosis-in-dogs
[2] Today's Daily Dose: Raisin and grape poisoning: https://www.dvm360.com/view/todays-daily-dose-raisin-and-grape-poisoning
[3] Raisins and grapes: Potentially lethal treats for dogs: https://www.dvm360.com/view/raisins-and-grapes-potentially-lethal-treats-dogs
