# 伴侣动物中的弯曲菌病

弯曲菌病是兽医实践中影响犬猫的最重要的人畜共患细菌性胃肠炎疾病之一。由弯曲菌属引起，这种感染既是伴侣动物的临床关注点，也是通过人畜共患传播构成的公共卫生风险，带来双重挑战。本报告全面审视了弯曲菌病的临床谱系，从主要致病生物空肠弯曲菌、大肠弯曲菌、乌普萨拉弯曲菌和赫尔维蒂弯曲菌，到包括特殊培养技术和PCR检测的诊断方法，再到强调支持性治疗和审慎使用抗菌药物的综合治疗方案。分析涵盖了关键方面，包括该疾病对幼龄动物的易感性、特征性黏液血性腹泻表现、抗菌药物耐药模式以及兽医从业者管理这种常见胃肠道病原体必需的预防策略。

## 疾病概述和常见病原体

弯曲菌病是由弯曲菌属引起的细菌性胃肠炎，这些螺旋形、微需氧、革兰氏阴性细菌定植于伴侣动物的胃肠道[1]。该疾病是最重要的人畜共患细菌感染之一，犬和猫作为人类传播的重要储存宿主[1,2]。

从流行病学角度看，弯曲菌属在全球家畜中普遍存在，在6个月以下的犬、受应激动物、卫生条件差的动物、并发寄生虫感染或食用自制饮食的动物中患病率最高[4]。感染率因生活环境而异，在救助机构和寄养犬舍中观察到最高患病率[4]。

影响伴侣动物的主要致病菌种包括空肠弯曲菌空肠亚种、大肠弯曲菌、乌普萨拉弯曲菌和赫尔维蒂弯曲菌[1]。空肠弯曲菌空肠亚种是研究最广泛的菌种，可引起犬猫腹泻，而乌普萨拉弯曲菌是临床样本中最常被识别的菌种[4]。大肠弯曲菌影响多种动物物种并显示出日益增加的抗菌药物耐药性[1]。赫尔维蒂弯曲菌专门引起犬猫肠炎[1]。这些嗜热性弯曲菌属在伴侣动物医学中具有最高的疾病影响和患病率[1]。

### Sources
[1] Enteric Campylobacteriosis in Animals: https://www.merckvetmanual.com/digestive-system/enteric-campylobacteriosis/enteric-campylobacteriosis-in-animals
[2] Table: Global Zoonoses: https://www.merckvetmanual.com/multimedia/table/global-zoonoses
[3] Campylobacteriosis in Birds: https://www.merckvetmanual.com/poultry/campylobacteriosis-in-birds/campylobacteriosis-in-birds
[4] Bacterial diarrhea and related public health concerns: https://www.dvm360.com/view/bacterial-diarrhea-and-related-public-health-concerns-proceedings

## 临床症状、体征和诊断方法

弯曲菌病在犬猫中呈现不同的临床表现。幼龄动物（通常6个月以下）最常受影响，临床症状从无症状携带到急性胃肠道疾病[1]。最典型的表现包括急性发作的黏液性腹泻，可能含有血液和胆汁条纹[1,3]。呕吐、发热、里急后重和厌食常伴随腹泻发作[1]。

腹泻持续时间在犬中通常为5-15天，但间歇性症状可能持续数周或数月[1,3]。一些受感染动物，特别是猫，可能保持无症状携带者状态同时排出病原体[2]。与其他胃肠道病原体如贾第鞭毛虫、沙门氏菌或细小病毒的并发感染可加剧临床严重程度[1]。

诊断方法始于使用直接盐水涂片的新鲜粪便检查，以识别特征性的"海鸥翼"或"海鸥形"弯曲杆状细菌[1,2]。革兰氏染色的粪便细胞学检查可显示弯曲菌属的独特形态[2]。然而，细菌培养仍是金标准，需要特殊的微需氧条件和选择性培养基[1,3]。培养敏感性受该生物体挑剔特性和对环境条件易感性的限制[3]。

基于PCR的分子检测与传统培养方法相比提供了更高的敏感性和快速的病原体识别[3]。新鲜粪便样本应在2天内运送到实验室，使用Cary-Blair等运输培养基在4°C下最佳储存以维持生物体活力[4]。重要的是，空肠弯曲菌已在健康猫和腹泻猫中被识别，需要在临床症状背景下谨慎解释阳性结果[2]。

### Sources
[1] Infectious diseases of the GI tract in dogs and cats: https://www.dvm360.com/view/infectious-diseases-gi-tract-dogs-and-cats-proceedings
[2] How to manage feline chronic diarrhea, Part I: Diagnosis: https://www.dvm360.com/view/how-manage-feline-chronic-diarrhea-part-i-diagnosis
[3] Merck Veterinary Manual Enteric Campylobacteriosis in Animals: https://www.merckvetmanual.com/digestive-system/enteric-campylobacteriosis/enteric-campylobacteriosis-in-animals
[4] Disorders Caused by Bacteria in the Digestive System of Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-caused-by-bacteria-in-the-digestive-system-of-dogs

## 治疗选择和预防措施

犬猫弯曲菌病的治疗涉及治疗干预和预防策略。大多数病例是自限性的，需要支持性护理而非特定的抗菌药物治疗[1]。

**支持性护理**：主要治疗包括静脉输液治疗以解决脱水、急性病例禁食24-48小时以及提供清淡饮食[2]。高纤维饮食可能有益于有大肠症状的患者。

**抗菌药物治疗**：当需要治疗中重度临床症状时，红霉素（10-15 mg/kg 口服 每8小时一次）被认为是首选治疗方法[5]。替代抗生素包括氟喹诺酮类、泰乐菌素、四环素和头孢西丁，尽管没有比较疗效研究[5]。然而，不建议对健康携带者进行治疗，因为抗生素可能无法清除感染且可能发生再感染[5]。

**耐药性关注**：弯曲菌迅速产生抗生素耐药性，因此审慎使用至关重要[2]。空肠弯曲菌对青霉素类和头孢菌素类具有固有耐药性[3]。已有耐药菌株记录，包括对多种抗菌药物显示耐药性的多重耐药空肠弯曲菌分离株[7]。

**预防策略**：有效预防依赖于严格的生物安全措施，包括处理生食时的适当卫生、接触宠物后彻底洗手以及避免接触受污染的水源[6]。目前没有针对伴侣动物的特定疫苗。

**环境控制**：防止接触潜在来源如生禽肉、受污染的水和受感染的野生动物至关重要[5]。幼龄动物和免疫功能低下宠物由于易感性增加需要特别保护。

### Sources

[1] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[2] Campylobacteriosis in Birds - Poultry - Merck Veterinary Manual: https://www.merckvetmanual.com/poultry/campylobacteriosis-in-birds/campylobacteriosis-in-birds
[3] New tax law: https://avmajournals.avma.org/view/journals/javma/252/6/javma.252.6.626.pdf
[5] Bacterial diarrhea and related public health concerns (Proceedings): https://www.dvm360.com/view/bacterial-diarrhea-and-related-public-health-concerns-proceedings
[6] Management and prevention of feline infectious gastrointestinal diseases (Proceedings): https://www.dvm360.com/view/management-and-prevention-feline-infectious-gastrointestinal-diseases-proceedings
[7] Drug-resistant Campylobacter outbreak linked to puppies from pet stores: https://www.dvm360.com/view/drug-resistant-campylobacter-outbreak-linked-puppies-pet-stores

## 鉴别诊断和预后

### 鉴别诊断

弯曲菌病必须与犬猫中其他急性和腹泻原因相鉴别。最重要的鉴别诊断包括细菌性肠道病原体，如沙门氏菌属、大肠杆菌、产气荚膜梭菌和艰难梭菌[1]。这些生物体可产生相似的临床症状，如黏液性血性腹泻，伴有不同程度的全身性疾病。

应考虑病毒性病因，包括犬细小病毒、冠状病毒和轮状病毒，特别是在幼龄动物中[1]。基于PCR的检测越来越多地用于区分弯曲菌属和识别其他病原体如沙门氏菌[2]。寄生虫感染如贾第鞭毛虫、毛滴虫、等孢球虫和各种蠕虫也可能呈现相似的胃肠道症状[3]。非感染性原因包括食物反应性肠病、抗生素反应性肠病和需要免疫抑制治疗的慢性肠病[3]。

在猫中，细菌培养通常对诊断弯曲菌病收效较低，但当怀疑感染性腹泻时，应培养包括弯曲菌属在内的特定病原体[4]。

### 预后和临床结果

犬猫弯曲菌病的预后通常良好。大多数感染是自限性的，轻度临床症状可自行缓解[1]。6个月以下的幼龄动物通常经历持续5-15天的腹泻，可能从水样到带血和黏液[1]。

一些受感染动物没有临床症状，可能成为慢性携带者[1]。携带状态的持续时间差异很大--一些动物迅速清除感染，而其他动物可能长期携带弯曲菌属[1]。这种携带状态从治疗和人畜共患角度来看都很重要。

并发症不常见，但在严重病例中可能包括脱水，特别是在非常幼小的动物中。大多数患者通过支持性护理完全康复，除非出现全身症状，否则通常不需要抗菌治疗[1]。

### Sources
[1] Introduction to Digestive Disorders of Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/introduction-to-digestive-disorders-of-dogs
[2] Diagnostic approach to diarrhea (Proceedings): https://www.dvm360.com/view/diagnostic-approach-diarrhea-proceedings
[3] Diagnostic approach to chronic diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[4] Feline diarrheal syndromes: Common and not-so-common disorders (Proceedings): https://www.dvm360.com/view/feline-diarrheal-syndromes-common-and-not-so-common-disorders-proceedings
