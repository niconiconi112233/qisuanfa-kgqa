# 伴侣动物中的中性粒细胞增多症

中性粒细胞增多症是小动物临床中最常见的血液学异常之一，定义为循环中性粒细胞计数高于正常参考范围。这种情况是一个关键的诊断指标，通常反映了需要立即兽医关注的基础炎症过程、感染或应激反应。理解中性粒细胞增多症对兽医至关重要，因为它为疾病严重程度提供了有价值的见解，指导治疗决策，并有助于监测治疗反应。本报告探讨了犬猫中性粒细胞增多症的全面方面，涵盖了从细菌感染和全身性真菌病到应激诱导反应的多种病因，以及使用全血细胞计数和外周血涂片评估的诊断方法、针对基础病因的靶向治疗策略和影响患者预后的预后考虑因素。

## 总结

犬猫的中性粒细胞增多症是一种复杂的血液学疾病，需要系统性的诊断评估来区分生理性和病理性原因。该疾病包含多种病因，从大肠杆菌等细菌感染和包括曲霉菌属在内的真菌病原体，到应激诱导的皮质类固醇反应和潜在的肿瘤过程。临床表现差异显著，严重病例显示发热和全身炎症，而轻度升高可能表示兴奋或皮质类固醇效应。

| 病因类别 | 关键特征 | 诊断线索 | 预后 |
|---|---|---|---|
| 细菌感染 | 左移、中毒性变化 | 培养阳性、发热 | 使用抗菌药物良好 |
| 应激反应 | 仅成熟中性粒细胞增多 | 无左移、淋巴细胞减少 | 优秀 |
| 真菌疾病 | 表现多样 | 地域病史、影像学检查 | 不定 |
| 肿瘤性 | 存在异常细胞 | 骨髓评估 | 谨慎 |

有效管理需要通过全血细胞计数解读、血涂片评估和在适当情况下的靶向抗菌治疗来识别潜在原因。预后从生理性原因的优秀到肿瘤性疾病的谨慎不等，强调了在兽医实践中准确鉴别诊断的重要性。

## 疾病概述与流行病学

中性粒细胞增多症定义为循环中性粒细胞浓度高于正常参考范围[1]。犬的正常中性粒细胞值为2.9-12.0 × 10³/µL（占白细胞总数的58-85%），而猫为2.5-12.5 × 10³/µL（占白细胞总数的45-64%）[1]。

中性粒细胞的产生和调节通过骨髓产生和组织需求之间的复杂平衡实现[4]。骨髓维持成熟中性粒细胞的储存储备，可在炎症反应期间快速动员[4]。当组织需求超过骨髓输送能力时，不成熟中性粒细胞（杆状核）被释放到循环中，形成所谓的"左移"[4]。

中性粒细胞增多症常见于幼年至中年的犬猫，没有报道特定的品种倾向。这种情况可以是生理性的（应激诱导或兴奋反应）或病理性的（炎症反应）[4]。雌性犬可能显示略高的基础中性粒细胞计数，尽管这因个体和品种而异[3]。

病理生理学涉及骨髓释放增加、中性粒细胞边缘化减少，或响应各种刺激（包括细菌感染、炎症、应激、皮质类固醇给药或肿瘤形成）的中性粒细胞产生增强[4]。

### Sources
[1] Hematology (Complete Blood Count) Reference Ranges: https://www.merckvetmanual.com/multimedia/table/hematology-complete-blood-count-reference-ranges
[2] Clinical Hematology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[3] Leukogram Abnormalities in Animals: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[4] Evaluation of the hemogram: What do those numbers mean?: https://www.dvm360.com/view/evaluation-hemogram-what-do-those-numbers-mean-proceedings

## 常见病原体和病因

犬猫的中性粒细胞增多症源于多种感染性和非感染性原因。**细菌感染**是主要驱动因素，因为中性粒细胞是抵抗细菌病原体的第一道防线[1]。常见的细菌原因包括大肠杆菌、沙门氏菌和弯曲杆菌属，特别是在胃肠道炎症病例中[7][9]。

**真菌病原体**是中性粒细胞增多症的重要原因，特别是全身性真菌病。曲霉菌属引起局部鼻部和播散性疾病，后者在德国牧羊犬中更常见[2]。荚膜组织胞浆菌在胃肠道感染期间经常触发中性粒细胞反应[7]。其他真菌原因包括粗球孢子菌（山谷热）、隐球菌属和皮炎芽生菌[2]。

**非感染性炎症疾病**通常导致中性粒细胞增多症[1]。慢性肠病，包括淋巴浆细胞性肠炎，在活动性炎症期间持续升高中性粒细胞计数[9]。炎症性肠病和结肠炎常表现为中性粒细胞增多症，作为全身炎症反应的一部分[7][9]。

**应激和皮质类固醇效应**通过减少中性粒细胞边缘化和增加骨髓释放引起成熟中性粒细胞增多症而无左移[1][6]。**肿瘤过程**，特别是造血系统恶性肿瘤如粒细胞白血病，可产生显著的中性粒细胞增多症，没有专门检测可能难以与反应性原因区分[6]。

### Sources

[1] Leukogram Abnormalities in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[2] Fungal Infections in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/fungal-infections-in-dogs
[6] Clinical Hematology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/en-au/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[7] Colitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals
[9] Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals

## 临床症状和体征

犬猫的中性粒细胞增多症表现各异，与基础炎症疾病过程相关的临床表现。最一致的发现是绝对中性粒细胞计数升高，通常超过犬2.7-9.5 × 10⁹/L的参考范围[1]。犬通常表现出2.9-12.0 × 10³/mcL的成熟中性粒细胞增多症，而猫显示2.5-12.5 × 10³/mcL[3]。

体格检查发现通常反映原发性炎症状况而非中性粒细胞增多症本身。患有严重中性粒细胞增多症（>50,000 WBC/μL且≥50%中性粒细胞）的犬常表现为发热、心动过速和全身炎症迹象[2]。中性粒细胞增多症主要由炎症引起，结构变化包括胞质嗜碱性、Döhle小体和细小空泡化，表明骨髓产生加速[4]。

临床严重程度与中性粒细胞升高模式相关。兴奋诱导的中性粒细胞增多症产生成熟中性粒细胞增多症而无左移，而炎症反应根据组织需求与骨髓产生显示不同模式[2]。在猫中，中性粒细胞增多症可能与炎症、皮质类固醇或肾上腺素相关，猫表现出与犬不同的应激反应[4]。

存在物种特异性模式，猫表现出兴奋诱导的淋巴细胞增多可能达到参考上限值的两倍，而犬很少显示这种反应[2]。品种倾向包括影响核低分叶模式的Pelger-Huët异常等状况[2]。

### Sources

[1] Neutrophil-to-lymphocyte ratio is increased in dogs with acute congestive heart failure: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.03.0131.xml

[2] Leukogram Abnormalities in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals

[3] Table: Hematology (Complete Blood Count) Reference Ranges-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/hematology-complete-blood-count-reference-ranges

[4] White Blood Cell Disorders of Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/blood-disorders-of-cats/white-blood-cell-disorders-of-cats

## 诊断方法

全血细胞计数（CBC）是评估犬猫中性粒细胞增多症的主要诊断工具[1]。适当的评估需要解读自动化分析仪的定量数据和外周血涂片检查的定性评估[2]。

中性粒细胞计数根据物种特异性参考范围进行评估，犬正常值为2.9-12.0 × 10³/μL，猫为2.5-12.5 × 10³/μL[1]。CBC差异计数提供绝对中性粒细胞计数，这比百分比在准确解读中更具临床相关性[2]。

外周血涂片评估是必要的，因为自动化分析仪无法可靠识别形态学异常或不成熟中性粒细胞[4]。血涂片显示中性粒细胞的中毒性变化，包括胞质嗜碱性、Döhle小体和胞质空泡化，这表明响应严重炎症的骨髓产生加速[2]。左移（不成熟中性粒细胞或杆状核细胞增加）的存在提供关于炎症过程的关键信息[5]。

当潜在原因仍不清楚或怀疑造血系统肿瘤时，骨髓评估变得必要[7]。骨髓细胞学可以区分产生增加、产生减少或引起中性粒细胞增多症的浸润性疾病[6]。

其他实验室检查可能包括血液和尿液培养以排除菌血症、血清生化以识别器官特异性炎症，以及诊断性影像学检查以定位潜在炎症病灶[7]。根据临床病史和地理位置可能需要进行传染病检测。

### Sources
[1] Merck Veterinary Manual Table: Hematology (Complete Blood Count) Reference Ranges: https://www.merckvetmanual.com/multimedia/table/hematology-complete-blood-count-reference-ranges
[2] Merck Veterinary Manual Leukogram Abnormalities in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[3] DVM 360 Complete blood count interpretation - cells and numbers (Proceedings): https://www.dvm360.com/view/complete-blood-count-interpretation-cells-and-numbers-proceedings
[4] DVM 360 Why a blood smear evaluation should be performed with every CBC: https://www.dvm360.com/view/why-a-blood-smear-evaluation-should-be-performed-with-every-cbc
[5] DVM 360 Three-minute peripheral blood film evaluation: The leukon: https://www.dvm360.com/view/three-minute-peripheral-blood-film-evaluation-leukon
[6] DVM 360 A case-based approach to hematologic interpretation (Proceedings): https://www.dvm360.com/view/case-based-approach-hematologic-interpretation-proceedings
[7] DVM 360 Immune-mediated neutropenia (Proceedings): https://www.dvm360.com/view/immune-mediated-neutropenia-proceedings

## 治疗选择和预防措施

犬猫中性粒细胞增多症的管理主要侧重于治疗潜在原因而非中性粒细胞增多症本身[1]。治疗方法通过诊断工作确定的具体病因指导。

**抗菌治疗**
当怀疑或确认细菌感染时，适当的抗菌治疗是必要的。对于肾盂肾炎病例，氟喹诺酮类或第三代头孢菌素是合理的经验性选择，尽管治疗应基于培养和药敏结果[2]。治疗持续时间建议已从历史上的4-6周方案发展为目前的10-14天疗程，患者在治疗后1-2周进行监测[2]。

**糖皮质激素治疗**
对于应激诱导的中性粒细胞增多症，抗炎剂量的泼尼松/泼尼松龙（犬1-2 mg/kg每日，猫约为该剂量的两倍）可能适用于引起应激反应的状况[3]。然而，短期糖皮质激素给药在健康犬中显示有限的剂量反应效应，仅在较高剂量（4 mg/kg每日）观察到显著变化[5]。

**支持性护理方案**
全面的支持性护理包括使用平衡晶体溶液的液体治疗。维持液体需求计算为30 × 体重（kg）+ 70 mL每24小时[8]。对于化疗诱导的中性粒细胞减少症患者，当中性粒细胞计数降至1.0 × 10⁹/L以下时，可考虑预防性抗菌药物，尽管由于抗菌药物耐药性担忧，这仍有争议[1]。

**监测和评估**
定期监测包括至少每日两次评估水合状态、体重和尿量[8]。应评估患者并发症，包括导管相关感染、液体过载和电解质异常[8]。

### Sources
[1] DVM 360 Antibiotic prophylaxis in veterinary chemotherapy: When its worth the risk: https://www.dvm360.com/view/antibiotic-prophylaxis-veterinary-chemotherapy-when-it-s-worth-risk
[2] Merck Veterinary Manual Pyelonephritis in Small Animals - Urinary System - Merck Veterinary Manual: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/pyelonephritis-in-small-animals
[3] Inflammation, stress, or something else? - dvm360: https://www.dvm360.com/view/inflammation-stress-or-something-else-
[4] Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia
[5] Evaluation of dose-response effects of short-term oral: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/81/4/ajvr.81.4.317.pdf
[6] Leukogram Abnormalities in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[7] DVM 360 Treatment of Feline Pemphigus Foliaceus in General Practice: https://www.dvm360.com/view/treatment-of-feline-pemphigus-foliaceus-in-general-practice
[8] Maintenance Fluid Plan in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/therapeutics/fluid-therapy/maintenance-fluid-plan-in-animals

## 鉴别诊断和预后

**鉴别诊断：**
中性粒细胞增多症的关键鉴别诊断包括皮质类固醇诱导的应激反应、兴奋反应和真正的炎症性疾病[1]。皮质类固醇诱导的反应表现为成熟中性粒细胞增多症、淋巴细胞减少症、单核细胞增多症和嗜酸性粒细胞减少症，但缺乏左移和中毒性变化[1]。兴奋反应引起快速白细胞增多症，伴有成熟中性粒细胞增多症和可能的淋巴细胞增多症，在猫中特别明显[1]。

真正的炎症性中性粒细胞增多症必须通过左移和中毒性变化的存在与这些生理反应区分[1]。其他鉴别诊断包括造血细胞肿瘤，特别是白血病和淋巴瘤，可能表现为异常白细胞[1]。单核细胞增多症通常伴随慢性炎症性疾病，但不能证明传染病的存在[2]。

**预后因素：**
预后根据潜在病因差异显著。皮质类固醇给药引起的中性粒细胞增多症表现为中性粒细胞计数增加2,000-5,000个细胞/mm³，骨髓释放加速[6]。当存在细菌感染时，恢复取决于快速实施适当的抗菌治疗。

在肿瘤性疾病中，中性粒细胞增多症可作为预后指标。当生理性原因引起的中性粒细胞增多症得到适当识别时，总体生存率优秀，尽管潜在恶性肿瘤尽管有初始治疗反应仍具有谨慎的长期预后。

### Sources
[1] Leukogram Abnormalities in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[2] Managing and preventing feline febrile diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings
[3] Immunosuppressive Therapies in Organ Transplantation - Page 5 - Medscape: https://www.medscape.com/viewarticle/437182_5
