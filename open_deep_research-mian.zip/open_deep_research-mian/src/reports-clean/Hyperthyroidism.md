# 猫甲状腺功能亢进症：综合兽医指南

猫甲状腺功能亢进症是影响老年猫的最常见内分泌疾病，在10岁以上猫中的患病率高达10%。这种多系统疾病因其复杂的临床表现、多种治疗方式以及频繁发生的并发疾病而使管理决策复杂化，从而对兽医实践产生根本性影响。

本报告全面探讨了猫甲状腺功能亢进症的管理范围，从识别典型和非典型表现到长期预后考量。重点关注领域包括疑难病例的先进诊断方法、包括新兴疗法在内的全面治疗比较，以及患有并发慢性肾病（一种影响高达50%甲状腺功能亢进患者的合并症，显著影响治疗选择和结果）的关键管理策略。

## 摘要

猫甲状腺功能亢进症体现了老年猫医学的复杂性，要求兽医在管理重要合并症的同时平衡多种治疗方法。该疾病影响10%的10岁以上猫，70%的病例为双侧甲状腺受累，高达50%的患者并发慢性肾病。

治疗成功率因方法而异：放射性碘治疗达到95%的有效率，但导致高达75%的猫发生甲状腺功能减退症，而甲巯咪唑在适当监测下可提供良好控制。关键的管理挑战涉及患有隐匿性肾病的猫，其中15-49%在治疗后出现氮质血症，需要通过甲巯咪唑试验进行仔细的治疗前评估。

| 治疗方法 | 有效率 | 主要优势 | 主要局限性 |
|---|---|---|---|
| 放射性碘 | 95% | 单次治疗，副作用少 | 治疗后甲状腺功能减退症(75%) |
| 甲巯咪唑 | 可变 | 可逆，成本效益高 | 需要长期依从性 |
| 甲状腺切除术 | 高 | 永久治愈 | 甲状旁腺功能减退风险 |
| 饮食管理 | 90% | 非侵入性 | 需要专用喂养 |

对非典型表现（包括甲状腺风暴和隐匿性甲状腺功能亢进症）的早期识别，结合基于并发疾病状态的适当治疗选择，决定了这种日益普遍疾病的最佳患者结果。

## 疾病概述

猫甲状腺功能亢进症是一种常见的内分泌疾病，特征是自主甲状腺组织过度产生甲状腺激素（T4和T3）[1]。这种状况导致临床甲状腺毒症，通过增加代谢率和交感神经系统激活影响几乎每个身体系统[2]。

病理生理学涉及功能性甲状腺腺瘤或腺瘤样增生作为主要原因，约70%的病例为双侧受累，15-20%为单侧受累[1][2]。甲状腺癌占猫病例的不到3%，与狗不同，在狗中它是甲状腺功能亢进症的主要原因[1]。该疾病表现为具有自主功能的主要甲状腺疾病，独立于垂体或下丘脑调节[2]。

流行病学上，甲状腺功能亢进症主要影响老年猫，95%超过8岁，平均年龄13岁[2][4]。在三级医疗机构中，猫群的发病率估计高达2%[3]。在美国，该疾病影响10%的10岁以上猫[4]。没有性别偏好，尽管纯种猫（特别是暹罗猫和喜马拉雅猫）与家养混种猫相比表现出较低的易感性[2][4]。环境因素包括室内生活、罐装食品消费（特别是鱼/肝脏口味）和猫砂使用与风险增加相关[4]。

### Sources
[1] Hyperthyroidism in Animals - Endocrine System: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hyperthyroidism-in-animals
[2] Hyperthyroidism in cats (Proceedings): https://www.dvm360.com/view/hyperthyroidism-cats-proceedings-0
[3] What's new with hyperthyroidism in cats (Proceedings): https://www.dvm360.com/view/whats-new-with-hyperthyroidism-cats-proceedings
[4] ACVC 2016: Hyperthyroidism in Cats - What You Need to Know: https://www.dvm360.com/view/hyperthyroidism-in-cats-what-you-need-to-know

## 临床症状和诊断方法

### 非典型表现和不寻常表现

除了典型的甲状腺功能亢进表现外，猫可能表现出不寻常的临床表现，可能使诊断复杂化。甲状腺风暴代表急性甲状腺毒症的最严重形式，特征是发热、从躁动到昏迷的中枢神经系统效应、包括心动过速和充血性心力衰竭的心血管并发症以及胃肠道-肝功能障碍[1]。甲状腺风暴中的猫可能表现为严重的呼吸窘迫、伴有腹屈的肌肉无力、伴有视网膜改变的高血压，甚至猝死[1]。

### 先进诊断影像学和检测

虽然血清甲状腺激素检测仍然是诊断的基石，但影像学方法提供了有价值的补充信息。使用锝-99m高锝酸盐的甲状腺闪烁扫描是识别活动性甲状腺组织和量化疾病严重程度的金标准，在轻度或隐匿性病例中特别有价值[8][9]。该技术可以检测异位甲状腺组织并区分良性和恶性疾病。甲状腺超声检查可以识别肿块和回声改变，虽然结果依赖于操作者，可能将淋巴结或血管误认为甲状腺组织[9]。

### 复杂病例中的诊断挑战

亚临床甲状腺功能亢进症发生在猫甲状腺激素升高但没有明显临床症状时，而隐匿性甲状腺功能亢进症发生在临床症状存在但甲状腺激素水平保持正常时[2]。这些具有挑战性的病例需要仔细解读完整的甲状腺功能面板，可能受益于重复检测或T3抑制测试等专门程序。此外，约40%的甲状腺功能亢进猫存在钴胺素缺乏症，需要给受影响患者补充[9]。

### Sources

[1] Unusual manifestations of feline hyperthyroidism and thyroid storm: https://www.dvm360.com/view/unusual-manifestations-feline-hyperthyroidism-and-thyroid-storm-proceedings
[2] Recognizing and confirming feline hyperthyroidism: https://www.dvm360.com/view/recognizing-and-confirming-feline-hyperthyroidism
[8] Hyperthyroidism in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hyperthyroidism-in-animals
[9] ACVC 2016: Hyperthyroidism in Cats - What You Need to Know: https://www.dvm360.com/view/hyperthyroidism-in-cats-what-you-need-to-know

## 治疗选择和管理策略

猫甲状腺功能亢进症的综合管理涉及四种主要治疗方法：甲巯咪唑药物治疗、放射性碘治疗、甲状腺切除术和饮食管理。治疗选择取决于患者健康状况、主人依从性和经济考虑[1]。

**药物治疗**
甲巯咪唑仍然是一线抗甲状腺药物，有口服和经皮制剂可用[1][4]。标准初始剂量为每日两次2.5 mg，大多数猫需要5-7.5 mg/天以达到最佳控制[1]。经皮给药减少胃肠道副作用同时保持疗效[4]。定期监测包括前三个月的CBC和血清生化分析，以检测潜在并发症包括肝毒性和血液恶液质[1][4]。

**放射性碘治疗**
放射性碘（¹³¹I）因其高疗效和最小副作用而被认为是首选治疗方法[2]。这种治疗在95%的病例中通过单次治疗实现甲状腺功能正常，并选择性破坏高功能性甲状腺组织[3]。治疗后甲状腺功能减退症发生在2-7%的病例中[1]。

**手术和替代选择**
双侧甲状腺切除术提供确定性治疗，最近的研究表明与单独使用甲巯咪唑相比生存率提高[5]。限制碘治疗饮食在专用喂养时可使约90%的猫的甲状腺激素正常化[1]。新型经皮治疗包括乙醇和热消融，尽管这些具有更高的并发症率[3]。

### Sources
[1] Feline hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hyperthyroidism-proceedings-2
[2] Evaluation of a novel, sensitive thyroid-stimulating hormone: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.12.0278.xml
[3] The options for treating feline hyperthyroidism: https://www.dvm360.com/view/options-treating-feline-hyperthyroidism
[4] Feline hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hyperthyroidism-proceedings-0
[5] Comparison of survival times of cats with hyperthyroidism: https://avmajournals.avma.org/view/journals/javma/262/11/javma.24.01.0057.xml

## 并发症和并发疾病

甲状腺功能亢进症经常与老年猫的其他疾病同时发生，造成复杂的管理挑战。慢性肾病（CKD）是最重要的合并症，影响15%至50%的甲状腺功能亢进猫[1]。这种肾病通常被甲状腺功能亢进症对肾小球滤过率的影响所"掩盖"，可能仅在成功治疗后才显现[1]。

心脏并发症尤其普遍，甲状腺毒性心脏病影响大量甲状腺功能亢进猫[4]。心肌损伤标志物心脏肌钙蛋白I升高已在甲状腺功能亢进猫中得到证实[1]。成功的甲状腺功能亢进治疗通常导致肌钙蛋白水平降低，表明心脏损伤的可逆性[1]。

当存在CKD时，治疗修改变得必要。甲巯咪唑药物治疗应作为一线治疗，使用最低有效剂量并接受参考范围上限的T4水平[2]。限制碘饮食在氮质血症患者中是禁忌的[2]。

治疗后甲状腺功能减退症可能在确定性治疗后发展。在一项评估甲状腺癌放射性碘治疗的研究中，所有七只猫在治疗后都变得甲状腺功能减退，其中四只需要L-甲状腺素补充[6]。定期监测甲状腺功能和仔细评估临床症状决定何时需要甲状腺激素替代治疗[7]。

甲巯咪唑试验仍然推荐用于所有甲状腺功能亢进猫，无论初始尿液浓缩能力如何，因为50%发展为治疗后肾衰竭的猫尿比重>1.035[2]。试验应达到一个月的甲状腺功能正常，并定期监测肾功能参数、血压和甲状腺功能。

### Sources
[1] Unusual manifestations of feline hyperthyroidism and thyroid storm (Proceedings): https://www.dvm360.com/view/unusual-manifestations-feline-hyperthyroidism-and-thyroid-storm-proceedings
[2] Managing comorbidities in senior cats: https://www.dvm360.com/view/managing-comorbidities-in-senior-cats
[4] Feline hypertrophic cardiomyopathy, hypertension, and hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hypertrophic-cardiomyopathy-hypertension-and-hyperthyroidism-proceedings
[6] Feline hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hyperthyroidism-proceedings
[7] Feline hyperthyroidism (Proceedings): https://www.dvm360.com/view/feline-hyperthyroidism-proceedings-2

## 鉴别诊断和预后

### 鉴别诊断

猫甲状腺功能亢进症与老年猫常见的其他几种疾病有重叠的临床症状。**糖尿病**表现出类似的多食、体重减轻、多尿和多饮[1]。然而，糖尿病猫通常表现出持续性高血糖和糖尿，与甲状腺功能亢进猫不同[1]。**慢性肾病（CKD）**也引起多尿、多饮和体重减轻，但受影响的猫通常表现出食欲减退而非多食[2]。氮质血症和低尿比重的实验室发现有助于区分CKD和甲状腺功能亢进症。

**胃肠道疾病**包括炎症性肠病和淋巴肉瘤可以模仿甲状腺功能亢进症的体重减轻和食欲增加。**肝病**可能表现出相似的临床症状和肝酶升高，尽管肝功能障碍标志物与甲状腺功能亢进症中看到的模式不同[3]。

关键区分因素是血清总T4浓度测量，这在甲状腺功能亢进症中升高。可触及的甲状腺结节强烈支持甲状腺功能亢进症诊断，因为正常甲状腺无法触及[3]。

### 预后

治疗成功率因治疗方法而异。放射性碘治疗显示出优异的疗效，大多数猫在1-2个月内达到甲状腺功能正常[4]。然而，高达75%的猫发生治疗后甲状腺功能减退症，可能影响生存[5]。

甲巯咪唑药物治疗在适当使用时显示出良好控制，尽管长期依从性和监测是必需的[4]。甲状腺切除术提供永久治愈，但带来甲状旁腺功能减退的风险[4]。

关键的预后因素是并发肾病。研究表明15-49%的甲状腺功能亢进猫在治疗后发展为氮质血症，因为甲状腺功能亢进症掩盖了潜在的CKD[6]。发展为氮质血症的甲状腺功能减退症猫与甲状腺功能正常的猫相比生存时间显著缩短[5]。总体而言，当适当管理和监测时，甲状腺功能亢进猫的预后是有利的，大多数都能获得良好的生活质量。

### Sources

[1] Diabetes Mellitus in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats

[2] Risk factors associated with the development of chronic kidney disease in cats: https://avmajournals.avma.org/view/journals/javma/244/3/javma.244.3.320.xml

[3] Geriatric endocrinology: Hyperthyroidism (Proceedings): https://www.dvm360.com/view/geriatric-endocrinology-hyperthyroidism-proceedings

[4] Feline hyperthyroidism: Management and options for treatment: https://www.dvm360.com/view/feline-hyperthyroidism-management-and-options-treatment

[5] Feline iatrogenic hypothyroidism: https://www.dvm360.com/view/feline-iatrogenic-hypothyroidism

[6] Managing the hyperthyroid cat with renal disease (Proceedings): https://www.dvm360.com/view/managing-hyperthyroid-cat-with-renal-disease-proceedings
