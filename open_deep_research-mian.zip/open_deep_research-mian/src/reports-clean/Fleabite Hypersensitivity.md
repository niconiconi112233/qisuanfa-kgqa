# 伴侣动物跳蚤叮咬超敏反应

跳蚤叮咬超敏反应是兽医实践中影响犬猫最常见的过敏性皮肤病。这种对跳蚤唾液抗原的I型超敏反应在患病率上显示出显著增加，过去十年报告的猫病例增加了67%，犬病例增加了12.5%。该疾病的临床意义不仅限于简单的皮肤刺激，由于其症状与其他过敏性皮炎重叠，以及受影响的猫的细致梳理行为可能消除跳蚤的物理证据，常常带来复杂的诊断挑战。本综述全面探讨了病理生理学、临床表现、诊断方法以及基于证据的治疗策略，这些对于在小动物实践中成功管理这种日益普遍的疾病至关重要。

## 疾病概述

跳蚤过敏性皮炎（FAD）是一种对跳蚤唾液抗原的I型超敏反应，是犬猫中最常见的过敏性皮肤病[1][2]。当易感动物通过反复暴露于跳蚤叮咬而对跳蚤过敏原（主要来自猫栉头蚤）产生致敏时，就会发展成这种疾病[2][3]。

**流行病学背景**

最近的流行病学数据显示FAD患病率显著增加，Banfield宠物医院报告2008年至2017年间猫病例增加了67%，犬病例增加了12.5%[1]。2017年，在Banfield医院检查的每10,000只猫中有170只被诊断为FAD，每10,000只狗中有154只[1]。这种增加与跳蚤侵染率的上升相一致，可能归因于气候变化使跳蚤能够全年生存，以及宠物在室内度过更多时间，而跳蚤在恒温环境中繁盛[1]。

临床症状可能是季节性的或全年性的，这取决于地理位置和环境条件[2][3]。较暖的气候通常表现为非季节性发作，而温带地区可能表现出与跳蚤活动增加相一致的季节性模式[2]。该疾病影响任何年龄的动物，尽管初始致敏通常发生在较年轻的动物中，临床症状在反复暴露于跳蚤后变得明显[2][5]。

### Sources

[1] Banfield: Flea allergy dermatitis up 67% in cats, 13% in dogs in past 10 years: https://www.dvm360.com/view/banfield-flea-allergy-dermatitis-67-cats-13-dogs-past-10-years

[2] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis

[3] Derm Jeopardy -"How to make fleas flee" (Proceedings): https://www.dvm360.com/view/derm-jeopardy-how-make-fleas-flee-proceedings

[4] Another itchy cat, now what (Proceedings): https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings

[5] The pruritic dog: Differential diagnoses (Proceedings): https://www.dvm360.com/view/pruritic-dog-differential-diagnoses-proceedings

## 常见病原体

猫栉头蚤（猫蚤）是跳蚤叮咬超敏反应的主要致病因子，是与家养动物相关的最具优势和竞争力的跳蚤种类[1]。这种无处不在的外寄生虫侵染多种宿主，包括猫、狗、雪貂以及各种野生动物，如浣熊、负鼠、臭鼬，甚至考拉[2]。

跳蚤生命周期包括四个阶段：卵、幼虫、蛹和成虫。雌性跳蚤在初次吸血后每天可产40-50个卵，卵落入环境中，在适宜条件（65-75°F，相对湿度75%）下经过3-8周发育[2]。蛹阶段是最具抵抗力的阶段，占生命周期的20%，但达到80-90%的存活率[2]。

除了猫栉头蚤外，其他跳蚤种类也可能导致超敏反应，尽管它们在伴侣动物中较少见[4]。猫蚤不仅作为引起过敏反应和不适的直接病原体，还充当多种疾病病原体的媒介[3]。

猫栉头蚤通过摄取猫血传播各种血源性病原体，包括巴尔通体属、立克次体属、沃尔巴克氏体属、血浆体属，甚至猫白血病病毒[1][6]。环境因素显著影响跳蚤种群，夜间动物如负鼠、浣熊和野猫是环境污染的主要来源，而不是通常被指责的松鼠等野生动物[2]。

### Sources
[1] Flea-associated illnesses in cats: https://www.dvm360.com/clinical/parasitology?page=36
[2] Fleas: They are happiest at home: https://www.dvm360.com/view/fleas-they-are-happiest-home
[3] Reverse Vaccinology: A New Approach to Controlling Cat Fleas: https://www.dvm360.com/view/reverse-vaccinology-a-new-approach-to-controlling-cat-fleas
[4] Flea control challenges: Rumors and reality: https://www.dvm360.com/view/flea-control-challenges-rumors-and-reality-proceedings
[5] Another itchy cat, now what: https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings
[6] Managing and preventing feline febrile diseases: https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings

## 临床症状和体征

猫跳蚤叮咬超敏反应表现出与犬表现不同的独特临床模式。最具特征性的皮肤病变是粟粒状皮炎，表现为小的1-5毫米结痂性丘疹，通常比看到更容易被感觉到[1]。这些病变可能表现为红斑或色素沉着斑，几乎可以出现在身体的任何部位。

头部和颈部瘙痒是猫跳蚤超敏反应的另一种常见表现模式[1]。背腰部、腹股沟和大腿后部区域经常受影响，尽管这种模式不如犬那样一致，有些病例仅表现为颈部受累[2]。

嗜酸性肉芽肿复合病变，包括惰性溃疡、线性肉芽肿和嗜酸性斑块，可能因长期暴露于跳蚤而继发发展[2]。因过度梳理导致的自发性脱毛很常见，特别影响腹部、前腿、头部和颈部或后腿[2]。

与犬不同，猫是细致的梳理者，它们经常清除所有跳蚤证据，同时仍表现出严重的瘙痒症状[1]。猫瘙痒的临床症状包括舔舐、抓挠、啃咬、摇头、舔爪和拔毛[1]。主人可能报告呕吐物或粪便中频繁出现毛球，表明过度梳理行为。

慢性病例可能发展为继发性细菌感染，特别是与自发性创伤和炎症相关的嗜酸性斑块相关的葡萄球菌性脓皮症[1]。双侧外耳炎通常伴随猫过敏性皮炎疾病，包括跳蚤叮咬超敏反应。

### Sources
[1] A clinical approach to feline atopic dermatitis: https://www.dvm360.com/view/a-clinical-approach-to-feline-atopic-dermatitis
[2] Another itchy cat, now what (Proceedings): https://www.dvm360.com/view/another-itchy-cat-now-what-proceedings

## 诊断方法

诊断跳蚤过敏性皮炎（FAD）依赖于临床评估结合多种诊断方法。诊断主要基于病史、临床症状、跳蚤或跳蚤碎屑的存在以及排除其他瘙痒性疾病[1]。

**临床评估和体格检查**  
体格检查侧重于识别特征性病变模式和跳蚤侵染证据。在犬中，典型体征包括下背部、尾根和大腿后部的丘疹结痂性病变[1]。猫通常在面部、颈部和背部出现粟粒状皮炎[1]。临床医生应仔细分开毛发以揭示跳蚤粪便，这些粪便呈现为红黑色圆柱形颗粒，湿润时溶解产生红棕色[1]。

**跳蚤检测技术**  
细齿跳蚤梳（每英寸32齿）有助于检测跳蚤和粪便，特别是在被过度梳理的动物身上[1]。检查宠物寝具中的卵、幼虫和粪便提供额外证据。然而，极度超敏的动物可能因过度自我梳理而几乎没有跳蚤，使跳蚤检测具有挑战性[1]。

**皮内皮肤测试**  
皮内皮肤测试可以支持推定性FAD诊断。阳性即时反应特征为风团比阴性对照大3-5毫米，在15-20分钟评估，并在24小时再次评估延迟反应[1]。然而，阳性结果仅表示过敏原暴露，不一定表示活动性临床疾病[1,3]。

**血清学检测**  
针对跳蚤特异性唾液抗原的血清IgE检测提供与皮内测试相似的诊断价值[1,3]。当用于免疫疗法配方时，两种测试具有相当的治疗成功率[3]。

**结果解释**  
测试结果必须与临床病史和季节性模式相关联[1,4]。阳性过敏测试不排除并存疾病，需要全面的鉴别诊断，包括特应性皮炎、食物过敏、疥螨病和细菌感染[1]。

### Sources
[1] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[2] Allergy specific immunotherapy: how to maximize the results: https://www.dvm360.com/view/allergy-specific-immunotherapy-how-maximize-results-proceedings
[3] Scratching a veterinary dermatology itch: What's the latest on allergen-specific immunotherapy?: https://www.dvm360.com/view/scratching-veterinary-dermatology-itch-whats-latest-allergen-specific-immunotherapy
[4] Update on canine atopy: Diagnosis and management: https://www.dvm360.com/view/update-canine-atopy-diagnosis-and-management-proceedings

## 治疗选择

现有部分提供了跳蚤叮咬超敏治疗方式的全面概述，我将补充来源材料中关于新型免疫调节方法和替代治疗考虑的额外见解。

**免疫调节方法**
虽然核心治疗策略仍然围绕跳蚤控制和抗炎药物，但新兴的免疫调节疗法提供了额外选择。对于患有严重或难治性病例的犬患者，新型JAK抑制剂如ilunocitinib（Zenrelia）提供每日一次口服给药，具有靶向瘙痒通路抑制作用[6,8]。改良的环孢菌素制剂在一线治疗被证明不足时继续作为有价值的替代方案，特别是在需要长期免疫抑制的病例中[6,7]。

**渐进式治疗概念**
治疗应遵循渐进式方法，认识到不同的疾病阶段可能需要在患者一生中使用不同的治疗组合[6]。将奥拉替尼与lokivetmab或局部皮质类固醇等药物联合使用可以为急性发作管理提供协同效应，同时维持长期控制[6,7]。这种多模式策略对于需要维持治疗的严重受影响患者特别有价值。

**监测和调整**
即使有一致的治疗方案，突破性瘙痒也会周期性发生，可能需要临时或永久性治疗修改[8]。定期监测确保最佳患者结果，同时最大限度地减少长期用药的潜在不良影响。

### Sources
[1] Flea allergy dermatitis: What's new? (Proceedings): https://www.dvm360.com/view/flea-allergy-dermatitis-whats-new-proceedings
[2] Flea Allergy Dermatitis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[3] Fleas in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/fleas-in-dogs-and-cats
[4] Fleas be gone: Current treatment strategies (Proceedings): https://www.dvm360.com/view/fleas-be-gone-current-treatment-strategies-proceedings
[5] A systematic review of allergen immunotherapy: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0576.xml
[6] Canine atopic dermatitis: a roadmap to individualized, multimodal treatment: https://www.dvm360.com/view/canine-atopic-dermatitis-a-roadmap-to-individualized-multimodal-treatment
[7] Dermatology advancements: An overview of the latest treatment options: https://www.dvm360.com/view/dermatology-advancements-an-overview-of-the-latest-treatment-options
[8] Think like a dermatologist: untangling itch: https://www.dvm360.com/view/think-like-a-dermatologist-untangling-itch

## 预防措施

全年跳蚤预防代表了跳蚤叮咬超敏反应管理的基石[1]。跳蚤是无处不在的寄生虫，可以在恶劣的环境条件下生存，因此无论季节或气候如何，一致的预防方案都至关重要[1]。

**多宠物家庭管理**
家庭中的所有宠物必须同时接受治疗，因为跳蚤依赖宿主可用性来生存[1,2]。即使是室内猫也可能获得跳蚤，未经治疗的动物成为环境污染的持续来源。治疗依从性需要处理所有宠物，无论其室内/户外状态如何[2]。

**关于跳蚤生物学的客户教育**
了解跳蚤生命周期动态有助于主人在治疗期间保持现实期望[6]。客户需要了解环境污染，即3-8周前沉积的卵尽管当前进行治疗仍可能继续作为成虫出现[7]。这种知识防止主人在治疗初期仍观察到跳蚤时过早停止治疗[6,7]。

**环境控制策略**
环境管理侧重于宠物花费大部分时间的区域，特别是睡眠区域[8]。定期吸尘、用热水洗涤宠物寝具以及使用昆虫生长调节剂处理地毯区域可以减少环境跳蚤负担[8]。对于户外环境，消除积水和维护庭院区域可减少跳蚤友好栖息地[1]。

**治疗效果监测**
CAPC指南建议每年重新检测和一致的每月预防方案以确保充分保护[2]。定期兽医检查允许根据个体患者反应和环境因素进行治疗的调整[2]。

### Sources

[1] Parasite control in pets requires year-round vigilance: https://www.dvm360.com/view/parasite-control-pets-requires-year-round-vigilance
[2] CAPC primary guidelines: https://www.dvm360.com/view/capc-primary-guidelines
[6] Fleas: Fables, facts, and proven solutions (Sponsored by Merial): https://www.dvm360.com/view/fleas-fables-facts-and-proven-solutions-sponsored-merial
[7] Flea control challenges: Rumors and reality (Proceedings): https://www.dvm360.com/view/flea-control-challenges-rumors-and-reality-proceedings
[8] What every technician should know about flea control (Proceedings): https://www.dvm360.com/view/what-every-technician-should-know-about-flea-control-proceedings

## 鉴别诊断

跳蚤叮咬超敏反应的临床表现与犬猫中其他几种瘙痒性皮肤病有显著重叠。最常见的鉴别诊断包括特应性皮炎、食物过敏、疥螨病、接触性皮炎、皮肤癣菌病和马拉色菌皮炎[1]。

**特应性皮炎**具有相似的分布模式，特别影响面部、足部和屈曲区域。然而，特应性皮炎在许多情况下通常显示季节性模式，并且对皮质类固醇反应良好，而跳蚤叮咬超敏反应经典地影响背侧尾干区域[1]。

**食物过敏**表现为非季节性瘙痒，可能包括胃肠道体征，但病变分布通常涉及"耳朵和后部"模式，而不是跳蚤过敏性皮炎的背侧干偏好[2]。食物不良反应需要8-12周的排除饮食试验才能明确诊断[3]。

**疥螨病**可以模拟跳蚤叮咬超敏反应的剧烈瘙痒，但通常影响耳缘、肘部和腹侧区域。皮肤刮片和经验性治疗反应有助于区分这些疾病[2]。**接触性皮炎**通常显示与过敏原暴露区域相对应的病变分布，而**皮肤癣菌病**表现为圆形脱毛性病变，需要真菌培养才能明确诊断[1]。

**马拉色菌皮炎**通常表现为伴随细菌感染、明显的足部瘙痒、面部摩擦和特征性的有异味的油腻性皮脂溢[4]。与跳蚤过敏性皮炎不同，马拉色菌通常不显示经典的背侧干分布模式。

一个关键的诊断方法是确定瘙痒是否先于病变出现，因为过敏患者通常先抓挠并发展继发感染，而感染性或寄生虫性原因可能在瘙痒发展前就显示病变[2]。

### Sources
[1] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings
[2] Diagnosing dermatologic disorders in dogs: https://www.dvm360.com/view/diagnosing-dermatologic-disorders-dogs
[3] Food allergy vs. atopy (Proceedings): https://www.dvm360.com/view/food-allergy-vs-atopy-proceedings
[4] Dermatological Problems in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

## 预后

跳蚤过敏性皮炎（FAD）的预后在实施适当跳蚤控制的情况下通常极好[1]。大多数受影响的犬猫在开始全面跳蚤管理方案后的4-8周内临床症状显著改善[1]。然而，完全解决可能需要2-3个月，因为现有的环境跳蚤生命阶段即使在成虫跳蚤消除后仍会继续成熟和出现[1]。

几个关键因素影响恢复结果。主人依从性是最重要的预后因素，因为跳蚤预防药物的不一致应用或未能治疗所有家庭宠物显著降低治疗成功率[8]。超敏反应的严重程度也影响预后 - 极度超敏的动物可能经历延长的恢复期并需要额外的对症治疗[1]。

长期管理考虑对于维持有利结果至关重要。强烈建议终身跳蚤控制以防止再次侵染，因为许多主人在直接问题解决后就停止预防药物[1]。FAD通常与特应性皮炎并存，这可能使管理复杂化，并可能需要包括免疫抑制药物在内的多模式治疗方法[6]。

潜在并发症包括继发性和酵母菌感染，特别是在发展为苔藓化和色素沉着的慢性病例中[1]。这些继发感染可能需要额外的抗菌治疗并延长恢复时间。通过适当的跳蚤控制和主人教育，绝大多数FAD病例获得极好的长期控制和生活质量[8]。

### Sources

[1] Flea Allergy Dermatitis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/fleas-and-flea-allergy-dermatitis/flea-allergy-dermatitis-in-dogs-and-cats
[6] Managing fleas and mites (Proceedings): https://www.dvm360.com/view/managing-fleas-and-mites-proceedings
[8] What every technician should know about flea control (Proceedings): https://www.dvm360.com/view/what-every-technician-should-know-about-flea-control-proceedings
