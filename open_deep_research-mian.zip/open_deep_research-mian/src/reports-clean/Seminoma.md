# 犬猫精原细胞瘤：小动物临床实践指南

精原细胞瘤是伴侣动物医学中一种重要的睾丸肿瘤，与支持细胞瘤和间质细胞瘤并列为最常见的三种睾丸肿瘤之一。这种恶性生殖细胞肿瘤主要影响老年未去势雄性犬，隐睾动物的风险显著增加。虽然精原细胞瘤的转移潜力较低，但其与滞留睾丸的关联以及引起临床并发症的可能性，使得兽医从业者了解其诊断、治疗和预防至关重要。本综合指南探讨了在小动物实践中管理精原细胞瘤病例所需的流行病学、临床表现、诊断方法、治疗方案和预防策略。

## 摘要

精原细胞瘤是一种高度可管理的睾丸肿瘤，若得到正确诊断和治疗，预后极佳。该肿瘤的低转移率（<5%的病例）和对手术去势的优异反应使早期干预非常成功。关键临床见解包括与隐睾症的强关联（风险增加13倍）、睾丸不对称的特征性表现，以及超声检查对确诊的重要性。

| 方面 | 主要发现 |
|--------|--------------|
| **预后** | 极佳 - <5%转移率，手术可治愈 |
| **预防** | 早期去势可消除风险；隐睾管理至关重要 |
| **诊断** | 超声检查为主要影像学方法；组织病理学为确诊手段 |
| **治疗** | 手术去势为金标准；转移病例需辅助治疗 |

证据强烈支持通过早期去势方案和积极管理隐睾动物来实施全面的预防策略。兽医从业者应优先对未去势雄性动物进行定期睾丸检查，并对出现不对称睾丸肿大的老年犬保持高度怀疑。未来实践应侧重于向宠物主人教育去势益处，并为繁育计划提供遗传咨询，以减少遗传性隐睾症的传播。

## 疾病概述

精原细胞瘤是一种起源于犬猫睾丸生精小管的恶性生殖细胞肿瘤[1]。它是伴侣动物中最常见的三种睾丸肿瘤之一，与间质细胞瘤和支持细胞瘤并列[1][2]。

原发性睾丸肿瘤在老年犬中相当常见，精原细胞瘤是三种主要肿瘤类型之一[1]。睾丸肿瘤在未去势老年雄性犬中最常见，精原细胞瘤在此群体中相当常见[5]。隐睾症的发病率据报道为成年犬的1%至15%，这显著增加了睾丸肿瘤的风险[5]。与睾丸正常下降的犬相比，隐睾犬发生睾丸肿瘤的风险增加13倍[4]。

腹股沟睾丸的犬往往更频繁地发生精原细胞瘤，这是由于腹股沟管的过渡温度，这似乎刺激了生精细胞系的肿瘤生长[5]。大约75%的受影响隐睾犬为单侧隐睾，右侧睾丸滞留的频率几乎是左侧的两倍[5]。精原细胞瘤在不到5%的病例中发生转移，且很少产生雌激素[4]。

### Sources

[1] Surgery of the urogenital system (Proceedings): https://www.dvm360.com/view/surgery-urogenital-system-proceedings

[2] Abnormal reproductive ultrasononography in dogs and toms (Proceedings): https://www.dvm360.com/view/abnormal-reproductive-ultrasononography-dogs-and-toms-proceedings

[4] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease

[5] A dog with an enlarged prostate and bloody preputial discharge: https://www.dvm360.com/view/challenging-cases-internal-medicine-dog-with-enlarged-prostate-and-bloody-preputial-discharge

## 临床症状和体征

犬精原细胞瘤的临床表现因肿瘤位置和激素活性而异。最常见的表现是睾丸不对称，伴有单侧或双侧睾丸肿大[1]。有滞留睾丸（隐睾症）的犬发生精原细胞瘤的风险增加，通常表现为腹部肿块而非阴囊肿胀[1,2]。

与精原细胞瘤相关的副肿瘤综合征可包括雌性化体征，但与支持细胞瘤相比，这些表现较少见。当出现时，雌性化可能表现为男子女性型乳房、对称性双侧脱毛和行为改变[1]。一些病例出现排尿困难或其他泌尿生殖系统症状[1]。

非典型表现包括转移性疾病，这对精原细胞瘤来说是不寻常的行为。罕见病例有记录显示骨转移引起痛觉过敏和疼痛，这代表了异常的生物学行为，因为精原细胞瘤通常表现出相对良性的特征[5]。大多数精原细胞瘤仍局限于睾丸组织。

三种最常见的睾丸肿瘤（精原细胞瘤、支持细胞瘤和莱迪希细胞瘤）在犬中的发生频率几乎相等，因此在没有组织病理学检查的情况下，临床鉴别具有挑战性[1,2]。现有兽医文献中未充分记载品种特异性模式。

### Sources
[1] Pathology in Practice: https://avmajournals.avma.org/view/journals/javma/259/S2/javma.21.05.0231.xml
[2] Pathology in Practice: https://avmajournals.avma.org/downloadpdf/view/journals/javma/259/S2/javma.21.05.0231.pdf
[3] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/246/11/javma.246.11.1183.xml
[4] An Unusual Case of Metastatic Seminoma in a Dog: https://meridian.allenpress.com/jaaha/article/51/6/401/183315/An-Unusual-Case-of-Metastatic-Seminoma-in-a-Dog

## 诊断方法

精原细胞瘤的全面诊断评估需要系统整合临床检查、高级影像学、细胞学采样和确定性组织病理学确认[1][2]。体格检查仍然是基础，重点是双侧睾丸触诊，以评估大小不对称、质地变化和阴囊内容物内的肿块检测[3]。

超声检查是睾丸评估的主要影像学方法[1]。高分辨率B型超声显示精原细胞瘤为均质性低回声睾丸内病变，可评估肿瘤大小、边缘和内部结构[4]。彩色多普勒超声可能显示肿瘤组织内的血管模式改变，但其发现不如形态特征特异。

血清肿瘤标志物分析提供重要的诊断信息[5]。约30%的精原细胞瘤病例出现β-人绒毛膜促性腺激素（β-hCG）升高，而40-60%的患者乳酸脱氢酶（LDH）可能升高[4]。值得注意的是，纯精原细胞瘤中甲胎蛋白（AFP）保持正常；任何升高都提示混合性生殖细胞肿瘤成分，需要非精原细胞瘤治疗方案。

超声引导下细针抽吸细胞学可提供初步的细胞特征[3]。然而，根治性腹股沟睾丸切除术仍然是确定性的诊断和治疗程序，提供完整的组织标本用于综合组织病理学评估，包括结构评估、有丝分裂指数测定和免疫组织化学染色模式。

分期程序包括胸部、腹部和盆腔计算机断层扫描，以评估潜在的转移性疾病[5]。根据临床表现和血清标志物水平，可能需要进行额外的影像学研究以进行全面疾病分期。

### Sources
[1] Merck Veterinary Manual Ultrasonography in Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/ultrasonography-in-animals
[2] Merck Veterinary Manual Diagnostic Imaging: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging
[3] Merck Veterinary Manual Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[4] Testicular Seminoma - Verywell Health: https://www.verywellhealth.com/seminoma-overview-4788344
[5] Seminoma - StatPearls - NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/sites/books/NBK560513/

## 治疗方案

犬精原细胞瘤的主要治疗是**手术去势（睾丸切除术）**，这仍然是金标准干预措施[1]。完全双侧睾丸切除术通常对大多数精原细胞瘤产生优异结果，特别是当肿瘤局限且无转移时[1]。对于涉及慢性阴囊增生的特定病例，**必须进行阴囊切除术并建议后续放射治疗**[11]。

**化疗方案**可能适用于转移性疾病或手术不完全切除的病例。基于卡铂的方案在兽医肿瘤学中显示出前景，尽管精原细胞瘤的特定方案需要仔细监测重复治疗后的累积性中性粒细胞减少症[7]。顺铂是另一种选择，但绝不能用于猫，因为有致命性肺水肿风险[10]。

**放射治疗**作为一种重要的辅助方式，特别适用于不完全切除的肿瘤或局部侵犯病例[6][8]。根据肿瘤特征和患者因素，可采用常规分割根治性放射治疗（连续工作日10-20次分割）和立体定向放射治疗技术[6][8]。

**支持性护理措施**侧重于管理治疗相关副作用并维持生活质量。止吐药物如马罗匹坦（Cerenia）在管理化疗引起的呕吐方面非常有效，其疗效优于传统止吐药[2]。疼痛管理和营养支持在整个治疗过程中仍然是重要组成部分。

### Sources
[1] DVM 360 Advances in veterinary oncology: From a melanoma vaccine to genetic testing: https://www.dvm360.com/view/advances-in-veterinary-oncology-from-a-melanoma-vaccine-to-genetic-testing
[2] DVM 360 Top 10 recent advances in veterinary oncology (Proceedings): https://www.dvm360.com/view/top-10-recent-advances-veterinary-oncology-proceedings
[6] Merck Veterinary Manual Radiation Therapy in Animals - Therapeutics - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/radiation-therapy/radiation-therapy-in-animals
[7] Journal of the American Veterinary Medical Association Retrospective analysis of carboplatin-induced cumulative neutropenia in cancer-bearing dogs: https://avmajournals.avma.org/view/journals/javma/262/11/javma.24.02.0109.xml
[8] Merck Veterinary Manual Radiation Therapy - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/radiation-therapy/radiation-therapy?autoredirectid=12767
[10] DVM 360 Intracavitary and intralesional chemotherapy in dogs and cats: https://www.dvm360.com/view/intracavitary-and-intralesional-chemotherapy-dogs-and-cats
[11] DVM 360 Surgery of the urogenital system (Proceedings): https://www.dvm360.com/view/surgery-urogenital-system-proceedings

## 预防措施

精原细胞瘤最有效的预防策略是早期去势，特别是在性成熟之前[1][5]。早期绝育完全消除了睾丸肿瘤的风险，并提供额外的健康益处，包括预防良性前列腺增生[1]。然而，最近的证据表明可能需要考虑品种特异性时间安排[1]。

隐睾动物需要特殊的管理关注。有滞留睾丸的犬发生睾丸肿瘤的风险显著增加，由于温度条件改变，隐睾睾丸更频繁地发生精原细胞瘤[1][4]。所有隐睾睾丸的完全手术切除至关重要，建议进行组织病理学检查以确认完全睾丸组织切除并评估肿瘤[1]。

繁育计划应实施遗传咨询，因为隐睾症表现出遗传模式[1][4]。受影响的犬不应繁殖，因为这会延续遗传易感性。细针抽吸可以帮助区分肿瘤类型，包括精原细胞瘤，支持早期干预决策[2]。

应为未去势雄性犬建立定期睾丸检查方案。每月触诊可以检测睾丸大小、质地或对称性的变化，这些可能表明正在发展的肿瘤[3]。任何异常都应立即进行兽医评估和超声检查以评估睾丸形态[2]。

### Sources
[1] Do we need a paradigm shift in canine neutering?: https://www.dvm360.com/view/do-we-need-a-paradigm-shift-in-canine-neutering-
[2] Abnormal reproductive ultrasononography in dogs and toms (Proceedings): https://www.dvm360.com/view/abnormal-reproductive-ultrasononography-dogs-and-toms-proceedings
[3] 5 tips to put a lid on litters: https://www.dvm360.com/view/5-tips-put-lid-litters
[4] Reproductive Disorders of Male Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-male-dogs
[5] Abnormal conditions of the stud (Proceedings): https://www.dvm360.com/view/abnormal-conditions-stud-proceedings

## 鉴别诊断

精原细胞瘤必须与其他睾丸肿瘤和非肿瘤性疾病进行鉴别，这些疾病可能表现出相似的临床体征。犬中最常见的三种睾丸肿瘤包括精原细胞瘤、支持细胞瘤和间质细胞瘤（也称为莱迪希细胞瘤）[1][7]。

支持细胞瘤可以通过其特征性激素效应来区分，多达50%产生雌激素并引起雌性化体征，包括前列腺肿大、乳腺发育、对称性脱毛和吸引其他雄性犬[7]。这些肿瘤可能在不到15%的病例中发生转移[7]。相比之下，精原细胞瘤很少产生激素效应或转移，发生在不到5%的病例中[7]。

间质细胞瘤通常表现出很少的临床体征，不产生雌激素或转移[7]。它们通常在常规检查中偶然发现，被认为比其他睾丸肿瘤问题较少。

需要鉴别的非肿瘤性疾病包括睾丸炎和附睾炎，这些疾病表现为疼痛、睾丸肿大和阴囊水肿[8]。这些炎症性疾病可以通过其急性发作、相关发热和超声检查可见的炎症变化与精原细胞瘤区分开来。

彩色血流多普勒超声检查对鉴别诊断特别有价值，有助于排除睾丸扭转、嵌顿性阴囊疝、血肿，并区分实体肿块与炎症性疾病[8]。细针抽吸和组织病理学检查提供这些疾病之间的确定性鉴别。

### Sources

[1] Neoplasia of Ferrets: https://www.merckvetmanual.com/exotic-and-laboratory-animals/ferrets/neoplasia-of-ferrets
[2] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
[3] Orchitis and Epididymitis in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/reproductive-system-diseases-of-male-dogs-and-cats/orchitis-and-epididymitis-in-dogs-and-cats

## 预后

犬精原细胞瘤的预后通常极佳，主要由于肿瘤的低转移潜力[1]。精原细胞瘤的转移率极低，发生在不到5%的病例中，使其成为伴侣动物中最可治疗的睾丸肿瘤之一[1]。

手术去势在绝大多数病例中提供治愈性结果。低转移率使去势作为主要治疗高度成功，大多数犬在肿瘤切除后实现完全康复[1]。然而，当发生转移时，预后变得更加谨慎，因为结果根据转移的位置和程度而广泛变化[1]。

术后监测应包括定期体格检查，特别注意区域淋巴结，因为精原细胞瘤可以转移到这些结构。建议长期随访以检测任何复发或延迟并发症，尽管完全手术切除后复发很少见。

影响预后的因素包括肿瘤大小、转移存在、并发睾丸病理学和犬的整体健康状况。双侧睾丸受累或需要手术切除双侧睾丸的犬在适当管理下预后极佳。早期发现和及时手术干预是实现最佳结果的关键预后因素。

### Sources
[1] Testicular cancer remains easily preventable disease: https://www.dvm360.com/view/testicular-cancer-remains-easily-preventable-disease
