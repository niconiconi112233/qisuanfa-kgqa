# 伴侣动物复杂冠折

复杂冠折是小动物临床中最紧急的牙科急症之一，影响10-29%的犬猫，创伤导致牙髓组织暴露于口腔细菌。这种情况需要立即识别和干预，以防止不可逆的牙髓炎、细菌入侵和疼痛并发症。本报告探讨了牙髓暴露的病理生理学、从细微疼痛行为到明显组织出血的临床表现，以及综合治疗方法，包括成功率达80%的活髓治疗和成功率达94%的根管治疗。分析了预防策略、预后因素和长期管理方案，为兽医提供基于证据的方法，以保存受影响伴侣动物的牙科功能并消除疼痛。

## 疾病概述与病理生理学

复杂冠折是犬猫中一种重要的牙科急症，其特征是骨折导致牙髓组织暴露于口腔环境[1][2]。当创伤破坏保护性牙釉质和下方牙本质层时，会发生这些骨折，直接暴露含有血管、神经和成牙本质细胞的中央牙髓腔[2][3]。这种情况也可称为"板状骨折"，特别影响上颌第四前臼齿[4]。

牙齿结构的解剖对于理解病理生理学至关重要。最外层的牙釉质提供保护，而较软的牙本质含有连接中央牙髓的微小管[6]。一旦牙髓暴露，口腔细菌立即通过这些途径入侵，引发不可逆的牙髓炎并最终导致牙髓坏死[2][5]。检查时通常可见中央红点或骨折部位出血[5]。

从流行病学角度看，10-29%的小动物患者发生牙齿骨折，犬中最常受影响的是犬齿和上颌第四前臼齿[1]。在猫中，犬齿特别容易受损，因为牙髓腔几乎延伸到牙冠尖端[1]。牙髓暴露后的病理生理级联反应包括细菌入侵、炎症、组织坏死，并可能扩散到根尖周组织，形成疼痛的脓肿和骨破坏[2]。

18个月以下的幼年动物面临特别紧急的情况，因为牙髓暴露可能是紧急情况，需要在24-48小时内治疗以获得最佳活髓治疗效果[1][6]。病理生理学随年龄而异，因为未成熟牙齿具有较大的牙髓腔和更大的愈合潜力，而成熟牙齿的根尖孔已闭合[2][6]。

### Sources
[1] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options
[2] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
[3] Complicated crown fracture, dog: https://www.merckvetmanual.com/multimedia/image/complicated-crown-fracture-dog
[4] Pulpitis, crown fracture, dog: https://www.merckvetmanual.com/multimedia/image/pulpitis-crown-fracture-dog
[5] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[6] Differentiating tooth fractures and exploring treatment options: https://www.dvm360.com/view/differentiating-tooth-fractures-and-exploring-treatment-options

## 临床表现与诊断

复杂冠折表现出明显的临床症状，需要及时识别和系统评估。受影响的动物通常表现出急性疼痛行为，包括单侧咀嚼、食物掉落、过度流涎、用爪抓脸和拒绝硬质食物或玩具[1]。许多患者最初可能不会表现出明显的临床症状，因为牙科疼痛在伴侣动物中常常表现得很微妙[2]。

视觉检查显示直接牙髓暴露，在骨折部位可见特征性的粉红色牙髓组织。在猫中，任何牙冠缺失都应引起对复杂骨折的怀疑，因为牙髓腔几乎延伸到牙冠尖端[2]。牙冠活动度可能表明同时存在根部受累，特别是在冠根骨折中[3]。

诊断确认需要在麻醉下进行口腔检查，使用牙科探针评估牙髓暴露情况[5]。牙科X线摄影对所有病例都是必需的，以评估根尖周病理、根部完整性和周围骨骼健康[2][4]。先进的诊断技术包括适当的牙周探查和记录，以评估整体口腔健康状况[5]。在洁牙程序后，用牙科探针进行彻底探查可确保对所有牙面进行全面评估[5]。

最常受影响的牙齿因物种和生活方式而异，上颌第四前臼齿（食肉齿）在宠物犬中经常受累，而犬齿在工作犬和野猫中占主导地位[2]。

### Sources
[1] Tooth fracture: Should you ever just "wait and see?" (Proceedings): https://www.dvm360.com/view/tooth-fracture-should-you-ever-just-wait-and-see-proceedings
[2] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[3] Evaluating periodontal probing depth and furcation ...: https://avmajournals.avma.org/view/journals/ajvr/86/2/ajvr.24.09.0260.xml
[4] Dentistry A to Z: "I" is for innovation: https://www.dvm360.com/view/dentistry-a-to-z-i-is-for-innovation
[5] 10 steps to scale like a pro: https://www.dvm360.com/view/10-steps-scale-pro

## 治疗方法与管理

犬猫的复杂冠折需要及时干预，以防止疼痛和继发并发症。有几种治疗方法可供选择，每种方法都有特定的适应症和成功率[1]。

**活髓治疗**是年轻动物急性骨折（48小时内）最保守的方法。该程序包括切除受感染的冠部牙髓，应用矿物三氧化物凝聚体（MTA）作为盖髓剂，并用复合材料修复牙冠[1]。在受伤后两天内进行时成功率最高，48小时后治疗成功率显著下降[1][2]。最新研究表明，在适当指征下，活髓治疗在犬中保持80%的成功率[3]。该程序保持牙髓活力，在适当的患者中预后良好。

**根管治疗**适用于慢性骨折或活髓治疗禁忌的情况。这涉及完全去除牙髓、根管清洁和塑形，并用牙胶尖和封闭剂材料填充。研究报告犬根管治疗的成功率约为94%[4]。这种方法允许保留牙齿，同时消除疼痛和感染。

**拔牙**当由于晚期牙周病、主人限制或医生限制而无法进行牙髓治疗时，仍然是一个可行的选择。手术拔牙技术确保完全去除根部并适当关闭创口[2]。

**牙冠修复**可能在成功的牙髓治疗后推荐，特别是对于功能重要的牙齿如犬齿和食肉齿。金属冠为工作犬提供最佳耐久性[2]。

治疗选择取决于骨折时间、患者年龄、牙周健康状况、主人期望和医生专业知识。无论选择何种治疗方式，所有复杂骨折都需要立即关注。

### Sources
[1] The ABCs of veterinary dentistry: A to C: https://www.dvm360.com/view/abcs-veterinary-dentistry-c
[2] Managing fractured and worn teeth (Proceedings): https://www.dvm360.com/view/managing-fractured-and-worn-teeth-proceedings
[3] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.pdf
[4] Vital pulpotomy, root canal therapy, avulsion, luxation (Proceedings): https://www.dvm360.com/view/vital-pulpotomy-root-canal-therapy-avulsion-luxation-proceedings

## 预防、预后和长期护理

### 预防措施
复杂冠折的一级预防侧重于适当的咀嚼物选择和环境管理。主人应避免提供硬物，包括动物骨头（生或熟）、尼龙玩具、牛蹄和压缩零食，这些都可能导致牙齿骨折[1]。防止笼子咀嚼行为至关重要，因为这可能通过慢性磨损使牙齿易于骨折[1]。在常规兽医就诊期间进行定期清醒口腔检查，能够在并发症发展之前早期检测到骨折牙齿[2]。

### 预后和治疗成功
复杂冠折的预后因治疗时机和方式而显著不同。适当进行活髓治疗时保持80%的成功率[2]，但成功率与时间相关。受伤后24-48小时内治疗可获得最佳结果，骨折后超过7天进行治疗时成功率下降至0%[2]。根管治疗显示出优异的长期效果，犬中仅有5%的失败率[2]。战略牙齿（犬齿和食肉齿）通常优先考虑牙髓治疗而非拔牙，以保留功能[3]。

### 术后护理和随访
成功的牙髓治疗需要全面的术后监测。每6-12个月的X线随访对于检测治疗失败或疾病进展至关重要[2][3]。患者在初始愈合期间需要饮食调整，食用软质食物。必须监测修复体的完整性，特别是金属冠，在一项研究中，19个金属冠中有17个在32个月随访时保持完整[2]。

### Sources
[1] The ABCs of veterinary dentistry: T is for treatment: https://www.dvm360.com/view/abcs-veterinary-dentistry-t-treatment
[2] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[3] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
