# 猫主动脉血栓栓塞：综合临床指南

猫主动脉血栓栓塞（FATE）是伴侣动物医学中最具破坏性的心血管急症之一，影响高达28%的肥厚性心肌病患猫。本综合指南探讨了血栓形成和栓塞背后的复杂病理生理学，从魏尔啸三联征到血管活性介质释放。该报告探讨了诊断方法，包括经典的"5P"表现、体温等预后指标，以及从紧急稳定到长期抗凝策略的不断发展的治疗方案。最新研究结果挑战了对高凝状态模式的传统理解，同时揭示了生存率和生活质量考量，这些因素指导了这一挑战性疾病中的临床决策。

## 疾病概述与病理生理学

猫主动脉血栓栓塞（ATE），也称为"鞍状血栓"，是一种破坏性的心血管并发症，影响约12-28%的肥厚性心肌病（HCM）患猫[1]。ATE是一种栓塞性疾病，血栓在扩大的左心房内形成，随后脱落并通过体循环[2]。主动脉三分叉是最常见的栓塞部位，影响近90%的病例[2]。

病理生理学核心是魏尔啸三联征：血液淤滞、内皮损伤和高凝状态[1][2]。左心房扩大导致血流淤滞，表现为自发性超声心动图对比（SEC）形成[2]。这种停滞的血液环境促进红细胞和血小板聚集。扩大的心房内的内皮损伤提供血栓形成表面，而心脏病患猫通过升高的凝血酶-抗凝血酶复合物和D-二聚体表现出高凝状态的实验室证据[2]。

栓塞后，组织损伤由缺血和随后的再灌注损伤共同引起[2]。血栓栓子释放血管活性介质，包括血清素和血栓素A2，导致侧支血管严重收缩并限制灌注恢复[2]。这一病理生理级联反应解释了为什么简单的动脉闭塞实验在临床严重程度和结果上与自然发生的ATE有显著差异。

### Sources
[1] Aortic thromboembolism in cats (Proceedings) - dvm360: https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings
[2] How to handle feline aortic thromboembolism - dvm360: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism

## 临床表现与诊断

猫主动脉血栓栓塞（FATE）通常表现为急性严重临床症状，主人常报告猫在事件发生前行为正常[1]。经典表现遵循"5P"原则：疼痛（Pain）、苍白（Pallor）、无脉（Pulselessness）、感觉异常（Paresthesia）和瘫痪（Paralysis）[1]。

体格检查显示后肢脉搏消失或微弱、后肢疼痛、反射减弱/消失、四肢冰冷、甲床发绀和腓肠肌僵硬[1]。大多数病例（90%）当血栓停留在主动脉三分叉时涉及双侧后肢瘫痪或轻瘫，但部分动脉闭塞时可能出现单侧表现[4]。体温是关键的预后指标，低温与不良结局强烈相关[4]。

诊断确认依赖于通过几种方法记录动脉闭塞。足背动脉多普勒超声可评估血流，信号缺失表明闭塞[4]。后肢和体循环之间的差异葡萄糖和乳酸测量提供支持性证据，缺血肢体的葡萄糖显著降低，乳酸升高[1][4]。

实验室异常通常包括肌酸激酶显著升高、高钾血症（来自肌肉坏死或再灌注）和肾灌注减少引起的氮质血症[4]。凝血参数（PT/aPTT）在就诊时通常正常，而D-二聚体仅在50%的病例中升高[4]。胸部X光片常显示心脏扩大（88%的病例），如果存在充血性心力衰竭，可能显示肺水肿[4]。超声心动图对于识别潜在心脏病至关重要，并可显示心内血栓或自发性超声对比[1][4]。

### Sources

[1] Aortic thromboembolism in cats (Proceedings): https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings
[2] Merck Veterinary Manual Pathological Thrombosis in Animals: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/pathological-thrombosis-in-animals
[3] Merck Veterinary Manual Thrombosis, Embolism, and Aneurysm in Animals: https://www.merckvetmanual.com/circulatory-system/thrombosis-embolism-and-aneurysm/thrombosis-embolism-and-aneurysm-in-animals
[4] How to handle feline aortic thromboembolism: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism

## 治疗与管理

主动脉血栓栓塞的治疗需要立即紧急稳定和长期管理策略。对于患有血栓或血栓栓子的动物，必须诊断和管理任何潜在疾病过程，并提供良好的支持性护理，包括疼痛管理[1]。维持足够的组织灌注至关重要。

**紧急稳定**侧重于使用氢吗啡酮（0.1-0.2 mg/kg，皮下、肌肉或静脉注射，每4-6小时）或丁丙诺啡（0.01-0.03 mg/kg，皮下、肌肉、静脉注射或颊部给药，每6-8小时）进行疼痛控制[1]。使用布托啡诺（0.4 mg/kg，静脉或肌肉注射）镇静可提供抗焦虑作用[3]。低氧血症患者（PaO2 < 80 mmHg）应通过氧舱或鼻导管接受氧气补充。

**抗血栓治疗**包括几种选择。普通肝素是最常用的初始治疗：猫250-300 U/kg，皮下注射，每6小时；狗250 U/kg，皮下注射，每6小时[1]。低分子量肝素如依诺肝素（猫0.75-1 mg/kg，皮下注射，每6-12小时）或达肝素（猫75 U/kg，皮下注射，每6小时）是替代选择[1]。

目前，氯吡格雷（18.75 mg/猫，口服，每24小时）是唯一被证明可增加猫血栓事件后生存时间的治疗[1][4]。Xa因子抑制剂如利伐沙班和阿哌沙班正在研究中，但仍很昂贵[1]。

**溶栓治疗**使用组织纤溶酶原激活剂存在再灌注损伤和高钾血症的风险，但在急性病例中可考虑使用[1][4]。

### Sources

[1] Pathological Thrombosis in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/pathological-thrombosis-in-animals
[2] Aortic thromboembolism in cats (Proceedings): https://www.dvm360.com/view/aortic-thromboembolism-cats-proceedings
[3] Thrombosis, Embolism, and Aneurysm in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/thrombosis-embolism-and-aneurysm/thrombosis-embolism-and-aneurysm-in-animals
[4] How to handle feline aortic thromboembolism: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism

## 预后与预防

最新研究表明，猫主动脉血栓栓塞的预后因素不仅限于温度和肢体受累情况。一项对97只猫的综合研究发现，在各种治疗方式下，出院生存率仍然很低，为27-35%[1]。就诊时的温度仍是最关键的预后指标，当直肠温度降至96°F（35.6°C）时，生存概率降至25%以下[2]。

近期凝血研究的有趣发现表明，当使用粘弹性监测仪测试时，患有ATE的猫可能不会表现出预期的高凝状态模式。这挑战了传统理解，表明血栓栓塞可能主要由血液淤滞和内皮损伤引起，而非纯粹的高凝状态[1]。

对于度过初始危机的猫，中位生存时间为117-345天，无论预防性治疗如何，复发率显著为37-50%[2,3]。生活质量考量包括永久性神经功能缺损、肌肉挛缩和持续的心脏管理需求。

预防策略侧重于左心房扩大的高危猫的抗凝治疗。当前证据支持氯吡格雷（每日18.75 mg）对预防复发有效，近期研究显示氯吡格雷和利伐沙班之间等效[2]。然而，通常不建议对左心房大小正常的猫进行预防性抗凝[4]。通过每6-12个月进行超声心动图密切监测，有助于在临床症状出现前识别需要干预的猫。

### Sources
[1] AVMA Journals Feline aortic thromboembolism with and without congestive: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/85/8/ajvr.24.03.0065.pdf
[2] How to handle feline aortic thromboembolism - dvm360: https://www.dvm360.com/view/how-handle-feline-aortic-thromboembolism
[3] Arterial Thromboembolism in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/arterial-thromboembolism-in-dogs-and-cats
[4] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
