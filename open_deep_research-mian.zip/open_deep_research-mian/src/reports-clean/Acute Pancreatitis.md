# 伴侣动物的急性胰腺炎

急性胰腺炎是小动物临床中最具挑战性的急症之一，犬猫之间截然不同的临床表现可能使早期识别复杂化。犬通常表现为呕吐和腹痛等典型症状，而猫往往只表现出轻微的嗜睡和厌食，导致诊断和治疗延迟。本报告探讨了目前对急性胰腺炎病理生理学的理解，从主导临床表现的特发性病例到在迷你雪纳瑞犬中观察到的品种特异性易感性。分析涵盖了使用胰腺脂肪酶免疫反应性检测的循证诊断方法，强调早期营养支持而非传统禁食的现代治疗方案，以及包括新兴的犬CAPS评分系统在内的预后因素。

## 摘要

伴侣动物的急性胰腺炎呈现出独特的挑战，需要针对物种的诊断和治疗方法。该病在很大程度上仍是特发性的，尽管迷你雪纳瑞犬显示出与遗传因素和高甘油三酯血症相关的显著品种易感性。临床识别在猫中尤其困难，其微妙的症状如嗜睡（81%）和厌食（87%）与犬更明显的呕吐（90%）和腹痛（58%）形成鲜明对比。

诊断准确性严重依赖胰腺脂肪酶免疫反应性（PLI）检测，SNAP检测在犬中提供超过80%的敏感性，而超声检查的敏感性有限，在犬中仅为68%，在猫中为35%。治疗已从传统的禁食发展为强调立即液体治疗、使用丁丙诺啡等阿片类药物进行积极疼痛管理以及早期肠内营养以预防并发症的循证方案。

预后随疾病严重程度差异巨大，CAPS评分系统正成为犬有价值的预后工具，而患有单次轻度发作的猫与反复严重发作的猫相比显示出极好的结果。

## 疾病概述与流行病学

急性胰腺炎是影响犬猫的胰腺炎症性疾病[1]。当胰腺酶（特别是胰蛋白酶原转化为胰蛋白酶）过早激活导致胰腺组织自身消化时，就会发生这种情况。这个过程会引发局部炎症、水肿、出血，并可能导致全身性并发症[1]。

大多数病例是特发性的，尽管已确定了几种品种易感性。迷你雪纳瑞犬的比例显著过高，推测有类似于人类遗传性胰腺炎的遗传易感性[1]。约克夏梗、可卡犬、腊肠犬和贵宾犬也显示出较高的患病率[1]。猫没有记录在案的品种易感性，尽管据报道平均年龄为9.5岁的家养短毛猫通常受影响[3]。

真实患病率仍不清楚，特别是在猫中。研究表明，猫胰腺炎影响1.3%至67%的猫，尸检研究显示的比率远高于之前认识的水平[2][4]。慢性胰腺炎在猫中似乎更常见（占病例的60%），而急性形式在犬中占主导[4]。在猫中没有明确识别出年龄、性别或品种易感性[4]。

### Sources
[1] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[2] Diagnosing and managing feline pancreatitis (Sponsored by IDEXX Laboratories): https://www.dvm360.com/view/diagnosing-and-managing-feline-pancreatitis-sponsored-idexx-laboratories
[3] Association between pancreatitis and chronic kidney disease: https://avmajournals.avma.org/view/journals/javma/262/5/javma.23.11.0615.xml
[4] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-2

## 病因学与风险因素

犬猫急性胰腺炎的大多数病例是特发性的，已确定几个风险因素[1]。饮食不当是犬常见的诱发因素，通常涉及摄入高脂肪食物、餐桌残羹或不适当的食物[1,3]。严重的高甘油三酯血症（通常血清浓度≥500 mg/dL）是犬胰腺炎的风险因素，但在猫中不是[1]。

**品种易感性与代谢因素**
迷你雪纳瑞犬由于遗传易感性和高甘油三酯血症倾向而比例显著过高[1,4]。其他患病率增加的品种包括约克夏梗、可卡犬、腊肠犬、贵宾犬和雪橇犬[1,3]。肾上腺皮质功能亢进在一些研究中被确定为风险因素[1]。糖尿病、慢性肾病、肿瘤、充血性心力衰竭和自身免疫性疾病等合并症可能导致胰腺炎症[4]。

**创伤、手术与医源性原因**
交通事故或猫高楼综合征造成的严重钝性创伤可导致胰腺炎[1]。手术和麻醉相关的胰腺低灌注被认为是风险因素[1]。许多药物被认为是潜在原因，包括胆碱酯酶抑制剂、钙、溴化钾、苯巴比妥、L-天冬酰胺酶、雌激素、水杨酸盐、硫唑嘌呤、噻嗪类利尿剂和长春花生物碱[1]。

**感染性与毒性原因**
在犬中，感染性原因包括犬巴贝斯虫和利什曼原虫[1]。猫胰腺炎可能与弓形虫、伪猫次睾吸虫和猫传染性腹膜炎有关[1]。大多数药物应被视为潜在的胰腺炎触发因素，在兽医患者中很少有被明确确认的[1]。

### Sources

[1] Merck Veterinary Manual Pancreatitis in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[2] Journal of the American Veterinary Medical Association Management of acute-onset pancreatitis in dogs: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.02.0107.xml
[3] Merck Veterinary Manual Pancreatitis and Other Disorders of the Pancreas in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/pancreatitis-and-other-disorders-of-the-pancreas-in-dogs
[4] DVM 360 Breaking down acute canine pancreatitis: https://www.dvm360.com/view/breaking-down-acute-canine-pancreatitis

## 临床表现与诊断方法

急性胰腺炎犬猫的临床症状差异显著。在犬中，严重病例通常表现为厌食（91%）、呕吐（90%）、虚弱（79%）和腹痛（58%）[1]。猫表现出更不特异的症状，包括嗜睡（81%）、厌食（87%）和脱水（54%），呕吐（46%）和腹痛（19%）的发生率明显低于犬[1]。两个物种的轻度病例可能保持亚临床状态或表现为嗜睡和食欲下降等模糊症状[1]。

体格检查结果包括脱水、腹痛（虽然常未被识别）以及严重病例中潜在的全身性并发症[1]。实验室异常通常是非特异性的，但可能包括中性粒细胞增多、肝酶升高和氮质血症[2]。

**胰腺脂肪酶免疫反应性（PLI）是胰腺炎最特异和敏感的诊断检测** [1]。SNAP cPL和SNAP fPL检测提供半定量评估，而Spec cPL和Spec fPL提供定量测量，在犬中敏感性超过80%[2]。已经开发出各种即时免疫分析法，尽管较新的检测在临床使用前需要可靠的分析验证[3]。腹部超声检查的敏感性有限--在犬中高达68%，在猫中为35%--使其具有操作者依赖性[1,2]。超声检查结果包括胰腺肿大、液体积聚和提示坏死或纤维化的回声改变[1]。CT等先进成像技术在兽医医学中仍处于研究阶段[1]。

### Sources
[1] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats
[2] Pancreatitis in dogs and cats (Proceedings): https://www.dvm360.com/view/pancreatitis-dogs-and-cats-proceedings
[3] Understanding lipase assays in the diagnosis of pancreatitis: https://avmajournals.avma.org/view/journals/javma/260/11/javma.22.03.0144.xml

## 治疗策略与管理

急性胰腺炎的循证治疗侧重于支持性护理，包括液体治疗、疼痛管理、止吐剂和营养支持。使用平衡等渗晶体液的静脉液体治疗（犬初始推注10-15 mL/kg；猫5-10 mL/kg）可纠正脱水并维持胰腺灌注[1][7]。可同时使用胶体治疗，合成胶体在猫中以2-5 mL/kg推注或在犬中以5-20 mL/kg推注，随后连续输注，猫中高达10 mL/kg/天或犬中高达20 mL/kg/天[2][3]。

疼痛管理至关重要，对于中度至重度疼痛，可使用丁丙诺啡（0.01-0.05 mg/kg静脉注射、肌肉注射、经口粘膜给药，每6-12小时一次）或芬太尼连续输注（2-10 mcg/kg/小时）等阿片类药物[1][5]。止吐治疗包括马罗匹坦（1 mg/kg口服或皮下注射，每24小时一次）、昂丹司琼（0.1-0.2 mg/kg静脉注射，每12小时一次）或甲氧氯普胺（0.2-0.4 mg/kg每8小时一次或1-2 mg/kg/24小时连续输注）[1][2][5]。

早期肠内营养至关重要，而不是传统的禁食方法[1][7]。不呕吐的猫应立即喂食，而长期厌食的猫需要放置饲管[1]。如果怀疑胃肠道溃疡，应使用法莫替丁（0.5-1.0 mg/kg每12小时一次）等胃保护剂[1]。监测参数包括水合状态、疼痛评估、电解质平衡（特别是钾和钙）和血糖水平[1][7]。

### Sources
[1] The Fluid Resuscitation Plan in Animals - Therapeutics: https://www.merckvetmanual.com/en-au/emergency-medicine-and-critical-care/fluid-therapy/the-fluid-resuscitation-plan-in-animals
[2] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings
[3] A criticalist's view of canine pancreatitis (Proceedings): https://www.dvm360.com/view/criticalists-view-canine-pancreatitis-proceedings
[5] What a pain in the gut: Canine pancreatitis: https://www.dvm360.com/view/what-pain-gut-canine-pancreatitis
[7] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats

## 鉴别诊断与预后

**鉴别诊断**

猫的急性胰腺炎必须与几种表现出相似临床症状的疾病相鉴别[1]。炎症性肠病作为猫三体炎综合征的一部分经常与胰腺炎同时发生，使诊断具有挑战性[1][2]。脂肪肝表现为呕吐、嗜睡和黄疸，但通常显示碱性磷酸酶显著升高而GGT水平正常，这与胰腺炎不同[3]。

胆管炎/胆管肝炎综合征具有包括呕吐、发热和腹痛在内的共同临床特征，但化脓性形式通常显示明显的细菌感染迹象和肝肿大[4]。胰腺和胆管之间的常见解剖连接解释了它们经常同时出现的原因[1][2]。

**CAPS评分与预后指标**

CAPS（犬急性胰腺炎严重程度）评分是一种新型的临床评分系统，用于预测犬急性胰腺炎的短期死亡[5]。虽然特定的猫预后评分系统有限，但急性胰腺炎的预后在严重程度上差异巨大[6]。患有胰腺炎的犬猫预后直接与疾病严重程度、胰腺坏死范围、全身性并发症的发生、疾病持续时间和合并疾病的存在相关[7]。

**预后因素与结果**

患有单次轻度胰腺炎发作的猫预后极佳[6]。然而，反复严重胰腺炎发作的预后要谨慎得多[6]。10-20岁患有胰腺炎的猫与对照组相比，慢性肾病的患病率显著更高[8]。猫急性胰腺炎的预后需要谨慎，积极的液体治疗和营养支持至关重要[6][7]。

### Sources
[1] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[2] Cholangiohepatitis (Proceedings): https://www.dvm360.com/view/cholangiohepatitis-proceedings
[3] Managing vomiting in cats (Proceedings): https://www.dvm360.com/view/managing-vomiting-cats-proceedings
[4] Disorders of the Liver and Gallbladder in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats
[5] Evaluation of diagnostic and prognostic usefulness of: https://avmajournals.avma.org/view/journals/javma/259/6/javma.259.6.631.xml
[6] Feline pancreatitis (Proceedings): https://www.dvm360.com/view/feline-pancreatitis-proceedings-1
[7] Treating pancreatitis (Proceedings): https://www.dvm360.com/view/treating-pancreatitis-proceedings
[8] Association between pancreatitis and chronic kidney disease: https://avmajournals.avma.org/view/journals/javma/262/5/javma.23.11.0615.xml
