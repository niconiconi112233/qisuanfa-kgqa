# 伴侣动物低钠血症

低钠血症，定义为犬血清钠浓度低于140 mEq/L或猫低于149 mEq/L，是兽医实践中的一种严重电解质紊乱。这种情况通常表现为稀释现象而非绝对钠缺乏，发生在患者无法充分排泄摄入的水分或经历渗透压高于摄入量的体液流失时。由于渗透压受到机体的严格调控，该疾病是严重潜在疾病的标志。本报告探讨了犬猫低钠血症的病理生理学、临床表现、诊断方法和治疗策略，特别强调纠正方案以预防渗透性脱髓鞘综合征等破坏性并发症。

## 疾病概述与病理生理学

犬猫低钠血症定义为犬血清钠浓度低于140 mEq/L或猫低于149 mEq/L [1]。这种电解质紊乱发生在患者无法充分排泄摄入的水分，或尿和非显性液体流失的总渗透压高于摄入或输注液体的渗透压时 [2]。

这种情况通常表现为稀释现象而非绝对钠缺乏 [1]。在兽医患者中，低钠血症常见于严重充血性心力衰竭，表现为慢性稀释性低钠血症，此时过度的体液潴留稀释了钠浓度 [1]。其基本病理生理学涉及正常水和钠平衡调节的破坏。

下丘脑中的渗透压受体构成水平衡调节的主要传入机制，而血管加压素释放和口渴反应则作为传出机制 [2]。容量耗竭，即使低至5-10%，也能降低血管加压素释放的阈值并增加渗透调节敏感性 [2]。当患者在持续饮水的同时出现水排泄受损时，会产生稀释效应，尽管存在持续的钠流失，仍导致低钠血症 [2]。

常见原因包括通过呕吐、腹泻或利尿剂导致富钠液体流失，以及肾上腺皮质功能减退或精神性烦渴导致的水摄入增加 [3]。低钠血症也可能发生在因充血性心力衰竭、严重肝病或肾病综合征导致血容量过多的患者中，此时水排泄受损与非渗透性血管加压素释放相结合，导致稀释性低钠血症 [2]。

### Sources
[1] Nutritional management of heart disease (Proceedings): https://www.dvm360.com/view/nutritional-management-heart-disease-proceedings
[2] Sodium and water balance (Proceedings): https://www.dvm360.com/view/sodium-and-water-balance-proceedings
[3] Seizures: etiologies and developing a diagnostic plan (Proceedings): https://www.dvm360.com/view/seizures-etiologies-and-developing-diagnostic-plan-proceedings

## 病因学与临床表现

现有内容全面涵盖了伴侣动物低钠血症的主要原因。然而，额外的医源性原因值得提及。不当的液体治疗构成了重要的医源性风险，特别是在不适当使用低渗液体或高估维持液体需求量时 [5][8]。

抗利尿激素分泌不当综合征（SIADH）也可由头部创伤引起，正如人类医学中所指出的，脑损伤会触发各种机制，包括渗透压受体功能改变和不当的血管加压素释放 [6]。这种情况在患有神经系统疾病的兽医患者中可能未被充分认识。

当严重高血糖将水分吸入细胞外间隙时，糖尿病可导致稀释性低钠血症，血糖每增加100 mg/dl，钠浓度大约下降2.4 mEq/L [5][7]。这代表了假性低钠血症，随着血糖水平正常化而纠正。

神经系统表现仍然是最令人担忧的临床体征，特别是当钠浓度降至130 mEq/L以下时 [6]。在纠正严重低钠血症时，重症监护监测变得至关重要，因为超过每小时0.5 mEq/L的过快纠正可导致渗透性脱髓鞘综合征，造成包括痉挛性四肢轻瘫和吞咽困难在内的破坏性神经系统后遗症 [6]。

### Sources
[1] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[2] Emergency management of Addison's disease (Proceedings): https://www.dvm360.com/view/emergency-management-addisons-disease-proceedings
[3] Canine hypoadrenocorticism (Proceedings): https://www.dvm360.com/view/canine-hypoadrenocorticism-proceedings-0
[4] Renal Dysfunction in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/renal-dysfunction-in-dogs-and-cats
[5] Disorders of sodium (Proceedings): https://www.dvm360.com/view/disorders-sodium-proceedings
[6] Sodium concentration, ECF volume, and the treatment of severe hypo/hypernatremia (Proceedings): https://www.dvm360.com/view/sodium-concentration-ecf-volume-and-treatment-severe-hypohypernatremia-proceedings
[7] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[8] Laboratory assessment of critically ill patients: It's not just the basics that are important (Proceedings): https://www.dvm360.com/view/laboratory-assessment-critically-ill-patients-its-not-just-basics-are-important-proceedings

## 诊断方法与鉴别诊断

### 临床评估方法

对于任何需要液体治疗的患病犬猫，血清电解质测定在兽医实践中都是必不可少的 [1]。主要关注点是确定是否存在低钠血症或高钠血症，因为这两种情况都可能导致严重的临床并发症。

初步评估应包括侧重于灌注参数和脱水状态的体格检查。脱水的临床体征包括干燥的粘膜、皮肤弹性丧失和眼球凹陷，这些有助于估计液体缺乏量 [1]。

### 实验室检测

**血清钠测量**是基石性诊断试验，正常值范围为135-145 mEq/L [4]。应同时评估血清渗透压，因为正常血清渗透压为290-310 mOsm/L [4]。在糖尿病患者中，低钠血症通常继发于葡萄糖相关的高渗状态，在充分水合的动物中通常不需要特殊治疗 [2]。

**ACTH刺激试验**在怀疑肾上腺皮质功能减退时至关重要，因为单次基础皮质醇不足以诊断，并且在患有肾上腺皮质功能减退的犬中可能正常 [5]。内源性ACTH测量可区分原发性和继发性肾上腺皮质功能减退，ACTH升高表明为原发性疾病 [5]。

**尿液检查**包括比重，有助于评估浓缩能力。正常动物在禁水后应能将尿液浓缩至>1.030（犬）或>1.035（猫）[3]。

### 鉴别诊断

关键鉴别诊断包括糖尿病、慢性肾功能衰竭、肾上腺皮质功能减退（表现为高钾血症、低钠血症、低氯血症）[1,5]、肾上腺皮质功能亢进、肝病和精神性烦渴 [3]。当排除其他原因后，改良的禁水试验可区分中枢性尿崩症、肾源性尿崩症和原发性烦渴 [3]。

### Sources
[1] Measuring serum electrolytes great ally in diagnosis: https://www.dvm360.com/view/measuring-serum-electrolytes-great-ally-diagnosis-treatment
[2] The latest management recommendations for cats and dogs: https://www.dvm360.com/view/latest-management-recommendations-cats-and-dogs-with-nonketotic-diabetes-mellitus
[3] Diagnostic approach to polyuria and polydipsia: https://www.dvm360.com/view/diagnostic-approach-polyuria-and-polydipsia-proceedings-0
[4] The Fluid Resuscitation Plan in Animals: https://www.merckvetmanual.com/therapeutics/fluid-therapy/the-fluid-resuscitation-plan-in-animals
[5] Hypoadrenocorticism in dogs (Proceedings): https://www.dvm360.com/view/hypoadrenocorticism-dogs-proceedings

## 治疗与预防

低钠血症治疗侧重于谨慎纠正钠以预防并发症。纠正速率不应超过每小时0.5 mEq/L以避免脑桥中央髓鞘溶解，因为快速纠正可导致严重的神经系统并发症 [1]。液体选择至关重要 - 等渗晶体液如乳酸林格氏液或生理盐水是容量复苏的首选 [1][2]。

**液体治疗方案**包括犬猫维持速率40-60 mL/kg/天，犬休克剂量为80-90 mL/kg，猫为40-60 mL/kg，以分次推注方式给予 [1][4]。对于胶体支持，羟乙基淀粉剂量为犬10-20 mL/kg，猫5-10 mL/kg [1]。高渗盐水（犬3-5 mL/kg，猫2-4 mL/kg）可用于10-20分钟内的低容量复苏 [2]。

**监测方案**需要在急性治疗期间每4-6小时频繁评估体循环灌注参数、血压和电解质水平 [3]。体积描记变异指数（PVI）值高于20表明血容量不足，需要液体补充 [3]。

**预防策略**侧重于治疗低钠血症的根本原因，包括处理导致抗利尿激素分泌不当、胃肠道流失或肾性钠消耗的疾病。客户教育应强调识别电解质失衡的早期体征，并在可能导致液体和电解质流失的疾病发作时及时寻求兽医护理。

### Sources
[1] Guidelines for daily fluid therapy planning: When the going gets tough (Proceedings): https://www.dvm360.com/view/guidelines-daily-fluid-therapy-planning-when-going-gets-tough-proceedings  
[2] Fluid therapy and the role of the endothelial glycocalyx: https://www.dvm360.com/view/fluid-therapy-and-the-role-of-the-endothelial-glycocalyx  
[3] A new way to monitor and individualize your fluid therapy plan: https://www.dvm360.com/view/new-way-monitor-and-individualize-your-fluid-therapy-plan  
[4] Fluid therapy 101 (Proceedings): https://www.dvm360.com/view/fluid-therapy-101-proceedings

## 预后

犬猫低钠血症的预后因严重程度、根本原因和纠正速度而有显著差异 [1]。轻度低钠血症通常患者耐受良好 [1]。通过及时识别和适当治疗，大多数患有低钠血症的犬在短期和长期内都应表现良好 [1]。

然而，低钠血症是相对严重疾病的标志，因为渗透压受到机体的严格控制 [2]。低钠血症的发生与猫和犬的不良结局相关，在医院环境中发生高钠血症的患者比保持正常钠血症的患者预后更差 [2]。与猫脓毒症相关的临床病理异常包括低钠血症，这与不良结局相关 [4]。

最严重的并发症是渗透性脱髓鞘综合征，特别是当慢性低钠血症纠正过快时 [1][3]。这种并发症可包括癫痫发作，也包括较轻的神经系统体征，如失明、震颤、抽搐、共济失调和异常行为 [3]。长期存在的低钠血症导致脑组织中保护性渗透活性物质的形成，使快速纠正可能变得危险，需要谨慎管理 [2]。

当低钠血症由心力衰竭继发的水潴留引起时，持续性低钠血症表明预后不良 [3]。治疗必须侧重于改善循环而非给予钠，后者可能加重充血 [3]。大多数病例对适当的液体治疗和改善有效循环容量等条件的治疗反应良好，这是急诊环境中最常见的原因 [2]。

### Sources
[1] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings-1
[2] Using blood gases in practice (Proceedings): https://www.dvm360.com/view/using-blood-gases-practice-proceedings
[3] Fluid therapy: Hold the salt (Proceedings): https://www.dvm360.com/view/fluid-therapy-hold-salt-proceedings
[4] Clinical and immunologic assessment of sepsis and the: https://avmajournals.avma.org/view/journals/javma/238/7/javma.238.7.890.xml
