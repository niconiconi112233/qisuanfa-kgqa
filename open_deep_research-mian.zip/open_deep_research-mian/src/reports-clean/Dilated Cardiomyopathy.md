# 犬猫扩张型心肌病

扩张型心肌病（DCM）是影响伴侣动物，特别是大型和巨型品种犬的最重要心脏疾病之一。这种进行性疾病涉及心肌细胞丧失和心脏收缩力下降，导致心室扩张并可能引发致命性心力衰竭。尽管历史上猫的DCM常见于牛磺酸缺乏症，但随着饮食改善，猫DCM现在主要为特发性。该疾病表现出强烈的品种易感性，杜宾犬、大丹犬和爱尔兰猎狼犬风险最高。本报告探讨了DCM的多因素病因，从遗传易感性到FDA对无谷物犬粮调查中最近强调的饮食因素。了解DCM的临床表现、诊断方法、治疗方案和预后对于在小动物临床中管理这种具有挑战性的心血管疾病的兽医从业人员至关重要。

## 疾病概述

扩张型心肌病（DCM）的特征是心肌细胞数量和/或功能进行性丧失，同时伴有心脏收缩力下降[1]。该疾病是大型和巨型品种犬心脏功能障碍的最常见原因，而在现今猫中较为罕见[1,2]。

DCM主要影响中老年雄性犬，品种易感性最高记录在苏格兰猎鹿犬（6.0%）、杜宾犬（5.8%）、爱尔兰猎狼犬（5.6%）、大丹犬（3.9%）和拳师犬（3.4%）[2]。雄性患病率几乎是雌性的两倍（0.66% 对比 0.34%）[2]。该疾病在爱尔兰猎狼犬、纽芬兰犬和杜宾犬中表现出常染色体显性遗传模式[2]。

病理生理学涉及进行性心肌细胞丧失，导致心室扩张和收缩功能受损。随着心脏收缩功能恶化，心输出量最初下降但通过RAAS（肾素-血管紧张素-醛固酮系统）代偿而恢复正常[1]。经过数年的代偿益处后，过度RAAS激活导致有害的液体潴留，即使在疾病晚期也会出现水肿或积液[1]。

在猫中，牛磺酸缺乏症历史上是大多数DCM病例的原因，但自商业饮食中补充牛磺酸以来，大多数猫病例现在为特发性原发性疾病[1]。

### Sources

[1] Dilated Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/dilated-cardiomyopathy-in-dogs-and-cats

[2] Managing dilated cardiomyopathy (Proceedings): https://www.dvm360.com/view/managing-dilated-cardiomyopathy-proceedings

## 常见病原体

犬猫的扩张型心肌病（DCM）具有多种病因因素，而非特定的传染性病原体[1]。病因包括化学毒素，最显著的是多柔比星（阿霉素），它通过组胺和儿茶酚胺介导的微血管痉挛诱导心肌衰竭[1,2]。其他化学毒素如棉酚和莫能菌素也被牵涉其中[1,2]。

病毒感染代表另一个病因类别，其中细小病毒被特别提及为潜在原因[1,2]。然而，克氏锥虫等感染也可能导致心肌病[1]。犬细小病毒可引起在子宫内感染或出生后不久至约8周龄幼犬的心肌感染、坏死和心肌炎[3]。

遗传因素起着重要作用，特别是在杜宾犬和拳师犬中，家族易感性提示心肌细胞存在可遗传的代谢缺陷[1,2]。营养缺乏，特别是牛磺酸缺乏，代表猫和偶尔犬（特别是小型品种或食用无谷物饮食的犬）的重要可逆原因[1]。

大多数病例仍为特发性，确切病因未知[1,2]。该疾病可能代表多种状况而非单一实体，提出的各种机制包括免疫介导过程和微血管痉挛[2]。与传染性疾病不同，DCM通常没有特定的致病生物体，而是由影响心肌功能的多因素原因引起。

### Sources
[1] Merck Veterinary Manual Dilated Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/dilated-cardiomyopathy-in-dogs-and-cats
[2] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[3] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/canine-parvovirus

## 临床症状和体征

DCM表现出多变的临床表现，一旦临床症状显现通常进展迅速[1]。典型体征包括呼吸困难、慢性咳嗽、运动不耐受和虚弱，主人通常在就诊前仅注意到几周[2]。

左心衰竭通常表现为肺水肿伴有呼吸困难和咳嗽，而右心衰竭表现为腹水、腹部膨周和外周水肿[1][2]。晕厥和突然崩溃可能发生，特别是在易患心律失常的品种中[2]。

体格检查通常在左心尖处发现柔和的收缩期心脏杂音、股动脉脉搏减弱以及伴有脉搏缺失的心律失常[1]。舒张早期奔马律（S3心音）是一个重要发现，在维持窦性心律的犬中最易察觉[2]。

品种特异性模式值得注意。杜宾犬和拳师犬常表现为室性心律失常、晕厥和猝死，X光片上心脏增大不明显[1][2]。巨型品种更常发展为心房颤动和伴有腹水的右侧心力衰竭[2]。可卡犬倾向于发展为双心室衰竭，可能对治疗反应更好[2]。

患有DCM的猫通常表现为严重、快速进展的呼吸道症状，原因是肺水肿和/或胸腔积液，临床症状通常对治疗无效[1]。

### Sources
[1] Dilated Cardiomyopathy in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/dilated-cardiomyopathy-in-dogs-and-cats
[2] Managing dilated cardiomyopathy (Proceedings) - dvm360: https://www.dvm360.com/view/managing-dilated-cardiomyopathy-proceedings

## 诊断方法

扩张型心肌病的诊断评估依赖于多模态方法，结合临床评估与先进成像和生物标志物检测[1]。超声心动图是诊断DCM的金标准，能够评估心腔扩大、量化收缩功能并评估舒张参数[1]。这种成像方式可以表征特定形式的心肌病并将DCM与其他心脏疾病区分开来。

心电图为检测与DCM相关的常见心律失常提供有价值的信息，包括心房颤动、室性心律失常和传导异常[1]。然而，许多情况下ECG发现可能正常，限制了其作为独立测试的诊断敏感性[4]。动态心电图监测对于检测间歇性心律失常至关重要，当与NT-proBNP检测结合用于筛查隐匿性DCM时特别有价值[3]。

胸部X光检查对于评估心脏大小和检测提示充血性心力衰竭的肺水肿或胸腔积液仍然至关重要[5]。心脏生物标志物，特别是NT-proBNP和心肌肌钙蛋白I，在诊断中扮演越来越重要的角色[3]。NT-proBNP水平高于特定阈值可以区分心源性和非心源性呼吸困难原因，并有助于识别临床前疾病阶段[2,3]。

品种特异性筛查方案至关重要，特别是对于高风险品种如杜宾犬，定期超声心动图监测和生物标志物评估可以在临床症状发展前检测隐匿性疾病[4]。

### Sources
[1] Diagnosis of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/diagnosis-of-cardiovascular-disease-in-animals
[2] NT-proBNP Testing: An important tool for veterinary practitioners: https://www.dvm360.com/view/nt-probnp-testing-an-important-tool-for-veterinary-practitioners
[3] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[4] Management of acquired canine heart disease: part 1 & 2: https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings
[5] New perspectives on diagnosis and treatment of canine congestive heart failure: https://www.dvm360.com/view/new-perspectives-diagnosis-and-treatment-canine-congestive-heart-failure-proceedings

## 治疗选择

DCM治疗侧重于全面的药物管理结合营养支持和精心护理[1]。基础药物治疗包括匹莫苯丹（0.25-0.3 mg/kg口服每12小时一次），这是一种提供正性肌力和血管扩张作用的双重作用药物[1][2]。该药物通过钙敏化增强心脏收缩力，同时降低后负荷和前负荷[2]。

袢利尿剂，特别是呋塞米（慢性管理时1-6 mg/kg口服每8-12小时一次），对于通过清除积聚液体来管理充血性心力衰竭至关重要[3]。ACE抑制剂如依那普利或贝那普利（0.25-0.5 mg/kg口服每12-24小时一次）提供平衡的血管扩张并帮助抵消神经激素激活[3][5]。当联合使用时，这些药物形成犬心力衰竭的标准三联疗法[1][3]。

抗心律失常药物对于管理室性心律失常可能是必要的，索他洛尔和美西律是常用选择[3]。螺内酯可在晚期病例中提供额外的利尿支持并最小化心脏重塑[1]。

营养干预在DCM管理中起着关键作用。推荐牛磺酸补充（根据犬大小250-1000 mg每日两次）和左旋肉碱（1000-3000 mg每日两次），特别是对于易患缺乏症的品种[3][6][7]。研究表明，24只牛磺酸缺乏性DCM犬中有23只在饮食改变并补充牛磺酸后表现出显著改善[7]。

护理包括监测呼吸频率、体重、运动耐受性和肾功能[4]。饮食钠限制和omega-3脂肪酸补充可能提供额外的心血管益处[8]。

### Sources
[1] Tool Kit Essentials for Canine Congestive Heart Failure: https://www.dvm360.com/view/tool-kit-essentials-for-canine-congestive-heart-failure
[2] Pimobendan: Understanding its cardiac effects in dogs with myocardial disease: https://www.dvm360.com/view/pimobendan-understanding-its-cardiac-effects-dogs-with-myocardial-disease
[3] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[4] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings
[5] Angiotensin-converting Enzyme Inhibitors for Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/angiotensin-converting-enzyme-inhibitors-for-use-in-animals
[6] Journal Scan: DCM and boutique dog foods: Can taurine supplementation help?: https://www.dvm360.com/view/journal-scan-dcm-and-boutique-dog-foods-can-taurine-supplementation-help
[7] Nutritional management of heart disease (Proceedings): https://www.dvm360.com/view/nutritional-management-heart-disease-proceedings

## 预防措施

目前，没有可用的疫苗接种方案用于预防扩张型心肌病，因为DCM主要是遗传性或获得性心脏疾病而非传染性疾病[1]。然而，几种预防策略可以帮助降低风险并实现早期检测。

**饮食考虑**
FDA对无谷物犬粮的调查揭示了与饮食相关DCM的显著关联[1]。在2018年1月至2019年4月期间，FDA收到553例犬DCM报告，其中超过90%食用含有豌豆、扁豆和豆类等豆类的无谷物饮食[1]。大多数受影响的犬在发展为DCM前食用这些饮食一年或更长时间[1]。兽医应向客户咨询这些饮食风险，并在医学适当时建议从无谷物饮食转换。

**品种特异性筛查**
高风险品种包括杜宾犬、大丹犬、拳师犬和爱尔兰猎狼犬需要定期心脏监测[2]。NT-proBNP检测结合动态心电图监测可以在临床症状发展前检测隐匿性DCM[2]。在易感品种中进行年度超声心动图筛查能够早期识别心脏变化。

**早期检测策略**
主人常规测量睡眠呼吸频率可以检测早期肺水肿，正常犬维持每分钟低于30次的呼吸频率[2]。在健康检查期间定期听诊可能揭示需要进一步调查的早期杂音或心律失常。

### Sources
[1] Veterinarians receive VIN Veritas Award for research on diet-related canine dilated cardiomyopathy: https://www.dvm360.com/view/veterinarians-receive-vin-veritas-award-for-research-on-diet-related-canine-dilated-cardiomyopathy
[2] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

## 鉴别诊断

扩张型心肌病必须与几种表现出重叠临床症状的心脏疾病进行鉴别。最重要的鉴别包括二尖瓣疾病、心包积液和其他心肌病[1]。

**二尖瓣疾病**与DCM的鉴别特别具有挑战性，因为严重的二尖瓣反流可导致继发性左心室扩张和收缩功能障碍，模仿原发性DCM[2]。然而，品种易感性有助于区分这些疾病 - 大型品种犬很少发生显著的原发性瓣膜疾病，使DCM在这些患者中更为可能[2]。

**心包积液**可表现为类似的虚弱、崩溃和心脏压塞体征。然而，非常轻微的心包积液实际上可能是继发于严重右心疾病（如DCM或严重三尖瓣反流）的表现，但血流动力学上无意义[1]。超声心动图通过识别心包间隙内的液体积聚与心室腔扩张可轻易区分这些情况[1]。

**其他心肌病**包括肥厚型和限制型必须考虑，特别是在猫中。通过超声心动图评估壁厚度、心腔尺寸和收缩功能参数如缩短分数（严重DCM中<20%）有助于区分这些疾病[2]。**致心律失常性右心室心肌病（ARVC）**主要影响拳师犬，表现为室性心律失常而非收缩功能障碍，大多数病例在超声心动图上心脏外观正常[4]。缩短分数的目视估计可以可靠地识别DCM特征性的严重收缩功能障碍[3]。

NT-proBNP检测和心肌肌钙蛋白水平可以支持诊断但不能确定存在的心脏疾病类型[5]。诊断方法结合品种评估、超声心动图评估和生物标志物检测，以准确区分DCM与这些鉴别诊断[2]。

### Sources
[1] Pericardial effusion: causes and clinical outcomes in dogs: https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings-0
[2] Dilated and arrhythmogenic cardiomyopathy in dogs: https://www.dvm360.com/view/dilated-and-arrhythmogenic-cardiomyopathy-dogs-proceedings
[3] Visual (eyeball) estimation by observers with varying: https://avmajournals.avma.org/view/journals/ajvr/86/5/ajvr.24.12.0384.xml
[4] Arrhythmogenic Right Ventricular Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/arrhythmogenic-right-ventricular-cardiomyopathy-in-dogs-and-cats
[5] MVC 2018: Advances in Feline Heart Disease Diagnosis: https://www.dvm360.com/view/mvc-2018-advances-in-feline-heart-disease-diagnosis

## 预后

扩张型心肌病的预后在无症状和有症状病例间差异显著，在物种和品种间也存在明显差异。无症状和轻度疾病的猫预后良好，可能无症状存活多年，通常最终死于非心脏原因[1]。然而，一旦猫发展为充血性心力衰竭（CHF）或动脉血栓栓塞，预后急剧恶化，CHF生存时间为92至654天，动脉血栓栓塞为61至184天[1]。

在犬中，预后通常较差，特别是对于有症状病例。在匹莫苯丹引入之前，大多数有症状杜宾犬在诊断后前三个月内死亡，中位生存时间为6-10周[3]。约25%在心力衰竭就诊后2周内死亡，40%在4周内，65%在8周内[3]。其他品种情况稍好，心力衰竭犬50%在首3个月内死亡，75%在6个月内[3]。包括大丹犬、爱尔兰猎狼犬和牛头獒在内的巨型品种即使处于充血性心力衰竭，治疗时预后通常更 favorable，可能存活约一年[5]。

左心房扩大是猫的关键预后指标[1]。就诊时有心房颤动、较低缩短分数和增加的收缩期末直径的犬生存期缩短[3]。在杜宾犬中，猝死约占死亡原因的30%，而心力衰竭是更常见的死亡原因[3]。充血性心力衰竭杜宾犬治疗的典型生存时间通常为四至六个月[5]。DCM犬的预后仍然谨慎，初次诊断一年后死亡率超过90%[4]。

### Sources

[1] Caring for cats with cardiomyopathies: https://www.dvm360.com/view/caring-cats-with-cardiomyopathies
[2] Managing feline cardiomyopathies (Proceedings): https://www.dvm360.com/view/managing-feline-cardiomyopathies-proceedings
[3] Dilated cardiomyopathy-born under a bad sign (Proceedings): https://www.dvm360.com/view/dilated-cardiomyopathy-born-under-bad-sign-proceedings
[4] Dilated cardiomyopathy: Look for multiple disease entities: https://www.dvm360.com/view/dilated-cardiomyopathy-look-multiple-disease-entities
[5] Oh my, myopathy!?!: https://www.dvm360.com/view/oh-my-myopathy
