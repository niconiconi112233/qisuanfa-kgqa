# 犬猫卵巢残留综合征

卵巢残留综合征（ORS）是影响已绝育雌性犬猫的一种重要术后并发症，发生在卵巢子宫切除术后功能性卵巢组织残留的情况下。这种情况表现为发情行为和激素周期性的恢复，有时在初始绝育手术后数年才出现。由于手术过程中的解剖学挑战，ORS在猫中似乎更为普遍，研究表明71%的猫科生殖病例表现出该综合征。本报告探讨了ORS的全面兽医处理方法，包括阴道细胞学和激素检测等诊断方法，从传统剖腹术到先进腹腔镜技术的手术治疗选择，以及在初始绝育手术中最大限度减少发生的关键预防策略。

## 疾病概述与流行病学

卵巢残留综合征（ORS）是一种影响已绝育雌性犬猫的术后疾病，其特征是卵巢子宫切除术后发情体征的恢复[1][2]。ORS发生在绝育手术过程中未完全手术切除后，功能性卵巢组织仍留在腹腔内[2]。

特别是在猫中，ORS似乎更为普遍，一项临床研究报告称，送诊专科医师的猫科生殖病例中有71.0%被诊断为ORS[3]。由于猫的解剖结构使得在手术中更难以分解卵巢固有韧带并将卵巢外化，该病被认为在猫中更为常见[2]。

ORS的临床体征可能在术后7天至10年内的任何时间出现，症状在卵巢子宫切除术后14天至9年内的任何时间表现[2][4]。一旦症状出现，受影响的动物通常表现出正常的发情行为周期性和季节性，包括脊柱前凸、鸣叫和漫游行为[4]。

ORS的确切流行病学模式和品种易感性需要更多研究。然而，尚未证明ORS的发生率与卵巢子宫切除术时的年龄或猫的品种之间存在相关性，该综合征在新毕业兽医实施的绝育动物中也不更常见[3]。该疾病影响犬和猫，但物种间的具体发生率因临床环境而异。

### Sources
[1] Feline reproduction: An overview (Proceedings): https://www.dvm360.com/view/feline-reproduction-overview-proceedings
[2] Merck Veterinary Manual Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[3] Feline reproduction FAQs (Proceedings): https://www.dvm360.com/view/feline-reproduction-faqs-proceedings
[4] MSD Veterinary Manual Reproductive Disorders of Female Dogs: https://www.merckvetmanual.com/dog-owners/reproductive-disorders-of-dogs/reproductive-disorders-of-female-dogs

## 病因学与病理生理学

卵巢残留综合征发生在先前已接受卵巢子宫切除术的雌性动物体内仍有功能性卵巢组织时[1]。主要原因包括原始手术过程中的手术错误、在卵巢子宫切除术时未能切除异位卵巢外组织以及卵巢组织的自体移植[2]。

导致ORS的手术因素包括对卵巢蒂的视野不充分、结扎技术不当以及未能识别附属卵巢组织。解剖学考虑在猫中尤为重要，由于猫的解剖结构使得在手术中更难以分解卵巢固有韧带并将卵巢外化，该病可能更为常见[2]。

病理生理学涉及残留卵巢组织的持续激素产生。由于未能完全切除所有卵巢组织，生殖激素的持续分泌导致发情前期和发情期的临床症状[2]。这种激素活动可导致单侧或部分卵巢切除术后卵巢肥大，并可能诱发其他病理变化的发展，包括卵巢、乳腺或阴道肿瘤或子宫残端蓄脓[2]。

实验研究表明，卵巢组织在自体移植后可以重新血管化，游离的卵巢残留物在缝合到肠系膜上时可变得有活力和功能[4]。

### Sources

[1] Ovarian remnant syndrome in dogs and cats: https://avmajournals.avma.org/downloadpdf/view/journals/javma/236/5/javma.236.5.548.pdf
[2] Ovarian Remnant Syndrome in Small Animals - Reproductive: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[3] Laparoscopic treatment of ovarian remnant syndrome: https://avmajournals.avma.org/view/journals/javma/245/11/javma.245.11.1251.xml
[4] Ovarian remnant syndrome: revascularization of free-floating: https://meridian.allenpress.com/jaaha/article/37/3/290/175344/Ovarian-remnant-syndrome-revascularization-of-free

## 临床体征与诊断方法

受影响的雌性动物表现出正常的发情体征，包括阴门肿胀、尿液标记、行为变化如烦躁不安和增加鸣叫，以及对雄性的吸引力[1]。在猫中，临床症状包括单调的嚎叫、脊柱前凸（抬高后躯并伴有尾部侧偏）和增加的亲昵行为[1]。体征可能在卵巢子宫切除术后7天至10年内的任何时间首次出现，通常恢复正常发情周期周期性[1]。

**诊断方法**

行为发情期间的阴道细胞学显示>90%的角质化上皮细胞，支持雌激素存在[1][6]。这种廉价的测试能准确检测犬和猫体内的功能性卵巢组织[6]。

激素检测通过在观察到发情后2-3周或给予GnRH（25 mcg肌注）后测量血清孕酮浓度>2 ng/mL来确认诊断[1]。抗苗勒管激素（AMH）检测提供另一种诊断选择，阳性结果表明卵巢组织存在[1]。黄体生成素（LH）检测显示已绝育雌性动物的浓度升高，除非在发情期间进行检测[1]。

GnRH刺激试验包括在发情期间肌内注射25 mcg，然后在2-3周后测量孕酮以确认黄体组织形成[1]。

### Sources
[1] Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[6] Feline reproduction: An overview (Proceedings): https://www.dvm360.com/view/feline-reproduction-overview-proceedings

I apologize, but the provided source material does not contain any relevant information about ovarian remnant syndrome in companion animals. The sources consist of UPS shipping tracking pages, veterinary journal websites, and AVMA organization pages, none of which contain clinical information about ovarian remnant syndrome treatment and surgical management.

Since I cannot find appropriate veterinary sources to supplement the existing section content with new information, I will preserve the existing content as it appears to be well-sourced and comprehensive:

## 治疗选择

卵巢残留综合征的治疗涉及通过剖腹探查手术切除残留的卵巢组织[1]。手术的最佳时机是在诱导排卵后3-6周，此时黄体形成使得在探查过程中更容易识别小的残留物[1]。单孔腹腔镜（SPL）已成为传统腹中线剖腹术的有效替代方案，在保持手术疗效的同时提供更小的侵入性[2]。

在手术探查过程中，兽医系统地检查两个卵巢蒂，因为大多数残留物位于这些部位[1]。外科医生必须仔细检查卵巢床和周围组织是否有任何残留的卵巢材料。任何可疑组织都应切除并提交进行组织学评估以确认卵巢组织[1]。

潜在的并发症包括难以定位小的残留物和卵巢组织切除不完全。药物治疗通常不作为主要治疗方法有效，因为该病需要物理切除功能性卵巢组织。术后护理包括监测发情行为的恢复和潜在的并发症。

当实现完全手术切除时，预后通常良好，成功手术后临床症状预期会缓解[1][2]。

### Sources
[1] Ovarian Remnant Syndrome in Small Animals - Reproductive: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[2] Single-Port Laparoscopic Treatment and Outcome of Dogs with: https://meridian.allenpress.com/jaaha/article/56/2/114/435282/Single-Port-Laparoscopic-Treatment-and-Outcome-of

## 预防与预后

### 预防策略

卵巢残留综合征的手术预防侧重于在初始绝育手术过程中完全切除卵巢组织[1][2]。正确的手术技术包括确保卵巢蒂有足够的视野并完全切除所有卵巢组织，包括潜在的异位卵巢外组织[2]。通过子宫角而非被脂肪遮蔽的卵巢组织进行结扎和横断可以降低ORS风险，特别是在老年肥胖患者中，脂肪沉积可能遮蔽卵巢解剖结构[1]。

腹腔镜方法可能通过视频放大增强卵巢组织的可视化为ORS预防提供优势，与开放手术相比可能确保更完全的卵巢切除[5]。与卵巢子宫切除术相比，卵巢切除术的较小切口和改善的视野也可能降低ORS风险[4]。

### 预后与长期结果

ORS在完全手术切除残留卵巢组织后的预后通常良好[2][6]。治疗涉及探查手术以识别和切除残留卵巢组织，大多数残留物位于卵巢蒂[2][6]。手术最好在排卵诱导后3-6周内进行，此时黄体的存在使得小的残留物更容易识别[2][6]。

### 潜在并发症

如果未经治疗，ORS可能导致严重并发症，包括乳腺肿瘤、阴道肿瘤、卵巢肿瘤和子宫残端蓄脓，这是由于残留组织的持续激素分泌所致[2][6]。在完全手术切除并适当组织学确认卵巢组织切除后，复发率很低[2]。

### Sources
[1] Performing an ovariectomy in dogs and cats: https://www.dvm360.com/view/performing-ovariectomy-dogs-and-cats
[2] Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/en-au/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
[3] is removal of the uterus necessary? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/239/11/javma.239.11.1409.xml
[4] Female sterilization procedures: https://www.dvm360.com/view/female-sterilization-procedures
[5] How to perform a two-portal laparoscopic ovariectomy: https://www.dvm360.com/view/how-perform-two-portal-laparoscopic-ovariectomy
[6] Ovarian Remnant Syndrome in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/ovarian-remnant-syndrome-in-small-animals
