# 伴侣动物低血糖症

低血糖症，定义为犬和猫血糖浓度低于60 mg/dL，是一种需要立即兽医干预的关键代谢紧急情况。这种情况严重影响中枢神经系统，因为神经元依赖葡萄糖来产生足够的ATP，而葡萄糖耗竭会导致脑水肿和潜在的神经元死亡。

本报告探讨了伴侣动物低血糖症的多方面性质，涵盖了从胰岛素瘤和木糖醇毒性到败血症和肝病的多种病因。分析包括使用即时血糖仪和先进影像学的诊断方法、使用葡萄糖治疗的紧急治疗方案，以及包括药物治疗和手术干预的长期管理策略。特别关注品种特异性易感性、高危人群的预防策略，以及影响患病犬猫临床结果的预后因素。

## 疾病概述与病理生理学

犬猫低血糖症定义为血清葡萄糖浓度低于60 mg/dL（3.3 mmol/L）[1][2]。在正常犬患者中，禁食通常不会导致低血糖，因此血糖水平低于此阈值几乎总是表明存在器质性疾病或实验室错误[1]。

正常葡萄糖稳态涉及当血糖超过110 mg/dL时刺激胰岛素分泌，而当血糖降至60 mg/dL以下时抑制胰岛素分泌并释放反调节激素（肾上腺素、胰高血糖素、皮质醇、生长激素）[1][2]。当这种调节机制因胰岛素作用过度、葡萄糖生成不足或葡萄糖利用增加而失效时，就会发生低血糖。

病理生理后果主要影响中枢神经系统。葡萄糖不依赖胰岛素进入神经元（下丘脑饱腹中枢除外），神经元葡萄糖浓度降低导致ATP产生不足[1]。这导致血管通透性增加、血管痉挛、血管扩张和脑水肿，最终因缺氧导致神经元死亡[1]。组织病理学变化在大脑皮层、基底神经节、海马和血管运动皮层最为明显。

低血糖可由多种机制引起，包括胰岛素瘤（最常见于中老年犬）、肝病、败血症、肾上腺皮质功能减退症和医源性胰岛素过量[1][2]。新生犬猫低血糖症常见，这是由于其糖原储备最少且葡萄糖生成的代谢能力有限[3][4]。正常新生动物血糖范围为90-140 mg/dL，低于30-40 mg/dL被认为具有临床意义[4]。临床表现取决于血糖下降的严重程度和速度。

### Sources
[1] Logical approach to diagnosis and management of hypoglycemia (Proceedings): https://www.dvm360.com/view/logical-approach-diagnosis-and-management-hypoglycemia-proceedings
[2] Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[3] Management of the Neonate in Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-the-neonate/management-of-the-neonate-in-dogs-and-cats
[4] The ABC's of managing critical problems in neonates (Proceedings): https://www.dvm360.com/view/abcs-managing-critical-problems-neonates-proceedings

## 病因学及风险因素

犬猫低血糖症由多种病因因素引起，物种和年龄组之间存在显著差异。最常见的原因包括胰岛素瘤、毒物摄入、败血症、肝功能障碍和内分泌疾病[1]。

**木糖醇毒性**是犬低血糖的一个主要原因，剂量超过100 mg/kg时通过快速胰岛素释放在30-60分钟内引起严重低血糖[1][2]。摄入含木糖醇产品（包括无糖口香糖、烘焙食品和药物）的犬面临严重风险，而猫不受木糖醇引起的低血糖影响[1]。

**胰岛素瘤和肿瘤性病因**影响两个物种，胰腺β细胞肿瘤分泌过量胰岛素。在犬中，胰岛素瘤最常见于中老年动物，大多数病例表现为恶性行为且转移率高[9][10]。恶性乳腺癌和肾肿瘤可能产生胰岛素样物质（IGF-1、IGF-2），特别是在犬中[4]。胰岛素瘤是犬最常见的胰腺肿瘤，尽管总体发病率仍然较低，在猫中很少见[11]。

**肾上腺皮质功能减退症**通过糖皮质激素缺乏引起低血糖，影响葡萄糖生成途径。这种内分泌疾病在年轻至中年雌性犬中更常见，某些品种表现出易感性，包括大丹犬、标准贵宾犬和西部高地白梗[8]。

**肝病和门体分流**是重要原因，特别是在幼犬中。肝性脑病常见于小型梗类犬，包括迷你雪纳瑞、约克夏梗、凯恩梗、澳大利亚牧牛犬、古代英国牧羊犬和马尔济斯犬[6][12]。**幼犬低血糖症**作为特发性综合征发生在玩具品种犬生命的前六个月，这与影响糖原分解的相对肝脏不成熟有关[13]。

### Sources
[1] Logical approach to diagnosis and management of hypoglycemia (Proceedings): https://www.dvm360.com/view/logical-approach-diagnosis-and-management-hypoglycemia-proceedings
[2] New findings on the effects of xylitol ingestion in dogs: https://www.dvm360.com/view/new-findings-effects-xylitol-ingestion-dogs
[4] Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[6] Congenital and Inherited Disorders of the Nervous System in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/congenital-and-inherited-disorders-of-the-nervous-system-in-dogs
[8] Addison Disease (Hypoadrenocorticism) in Animals: https://www.merckvetmanual.com/endocrine-system/the-adrenal-glands/addison-disease-hypoadrenocorticism-in-animals
[9] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings-1
[10] Sweet dreams: Use of low-dose dexmedetomidine for perioperative management of canine insulinoma: https://www.dvm360.com/view/sweet-dreams-use-of-low-dose-dexmedetomidine-for-perioperative-management-of-canine-insulinoma
[11] Ferret endocrine conditions (Proceedings): https://www.dvm360.com/view/ferret-endocrine-conditions-proceedings
[12] Hepatic Portal Venous Hypoperfusion in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/hepatic-portal-venous-hypoperfusion-in-small-animals
[13] Congenital and Inherited Cerebral Disorders in Animals: https

## 诊断方法

**血糖阈值和实验室监测对低血糖诊断至关重要**。犬血清葡萄糖浓度<60 mg/dL几乎总是由器质性疾病或实验室错误引起，因为正常健康动物很少因禁食导致低血糖[1][2]。葡萄糖的肾阈值因物种而异 - 犬约为180 mg/dL，猫为200-280 mg/dL[1]。

**患者侧血糖监测使用手持式血糖仪**，具有物种特异性设置，如具有犬猫设置的AlphaTRAK 2血糖监测仪[1]。iSTAT分析仪提供优异的准确性，常用于急诊和普通诊疗环境。然而，血液浓缩患者可能因红细胞浓度较高影响测量算法而显示人为的低血糖水平[1]。

**连续血糖监测（CGM）系统**通过每15分钟记录一次间质葡萄糖浓度提供实时监测，可持续长达14天。虽然未专门为兽医患者校准，但CGM在犬猫中均取得成功，尽管一些患者在CGM和血糖读数之间显示出显著差异，特别是在低血糖水平时[3]。

**先进影像学模式有助于识别潜在病因**。双期增强CT血管造影（CTA）优于常规超声检测犬胰岛素瘤，因为这些高血管肿瘤通常在动脉期显示明显强化[8]。对比增强超声（CEUS）可能有助于检测常规超声上不明显的胰腺病变[7]。

### Sources
[1] DVM 360 Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[2] DVM 360 Logical approach to diagnosis and management of hypoglycemia: https://www.dvm360.com/view/logical-approach-diagnosis-and-management-hypoglycemia-proceedings
[3] Merck Veterinary Manual Diabetes Mellitus in Dogs and Cats: https://www.merckvetmanual.com/endocrine-system/the-pancreas/diabetes-mellitus-in-dogs-and-cats
[4] DVM 360 Detection of feline insulinoma with contrast-enhanced ultrasonography: https://www.dvm360.com/view/detection-of-feline-insulinoma-with-contrast-enhanced-ultrasonography
[5] DVM 360 Insulinoma in a senior pit bull: Radiology perspective: https://www.dvm360.com/view/insulinoma-senior-pit-bull-radiology-perspective

## 治疗选择

**紧急管理**
严重低血糖的紧急治疗需要立即使用静脉葡萄糖溶液进行干预。对于有意识的患者，可将玉米糖浆或葡萄糖凝胶涂抹于口腔黏膜以快速吸收[2]。一旦建立血管通路，应缓慢推注50%葡萄糖并根据效果调整剂量，随后在晶体液中持续输注5%葡萄糖[1][2]。

**药物治疗**
泼尼松作为低血糖管理的主要长期药物治疗，特别适用于胰岛素瘤病例。起始剂量为0.5 mg/kg/天，可根据需要逐渐增加，泼尼松通过刺激糖原异生和拮抗胰岛素作用发挥作用[1]。

二氮嗪代表另一种治疗选择，可阻断胰腺胰岛素分泌同时刺激肝脏葡萄糖生成。起始剂量从5 mg/kg每12小时开始，可根据需要增加至30 mg/kg[1][4]。

**手术干预**
对于引起复发性低血糖的胰岛素瘤病例，胰腺肿瘤手术切除提供了最有效的长期管理。完全切除肿瘤可改善低血糖及相关神经症状，当所有可见肿瘤成功切除时，生存时间可超过两年[1]。然而，全面的探查手术至关重要，因为诊断时30-50%的病例已存在转移性疾病[4]。

### Sources
[1] Merck Veterinary Manual Islet Cell Tumors in Dogs and Cats: https://www.merckvetmanual.com/endocrine-system/the-pancreas/islet-cell-tumors-in-dogs-and-cats
[2] Merck Veterinary Manual Xylitol Toxicosis in Dogs: https://www.merckvetmanual.com/toxicology/food-hazards/xylitol-toxicosis-in-dogs
[3] DVM 360 Glucose requires monitoring in the canine/feline veterinary patient: https://www.dvm360.com/view/glucose-requires-monitoring-in-the-canine-feline-veterinary-patient
[4] DVM 360 Logical approach to diagnosis and management of hypoglycemia: https://www.dvm360.com/view/logical-approach-diagnosis-and-management-hypoglycemia-proceedings

## 预防与监测

有效的预防和监测策略对管理伴侣动物低血糖症至关重要。高危人群包括玩具品种幼犬、长时间活动期间的猎犬以及接受胰岛素治疗的糖尿病宠物[1]。定期血糖监测通过早期检测和干预有助于预防低血糖危象。

使用为兽医用途校准的便携式血糖仪进行家庭血糖监测，为宠物主人提供有价值的实时数据[1][2][3][4]。为兽医校准的即时血糖仪已证明在测量犬猫血糖浓度方面具有临床准确性，使其适用于兽医和家庭环境[4]。当宠物表现出虚弱、嗜睡或行为改变等临床症状时应测量血糖。干预的关键阈值通常低于60 mg/dl[1]。

对于糖尿病患者，应每2至4小时进行一次血糖曲线监测，持续12至24小时，当血糖降至150 mg/dL以下时应每小时测量[5]。这些曲线有助于在临床症状出现前检测亚临床低血糖，并指导胰岛素剂量调整[5]。

主人教育是低血糖预防的基石。宠物主人必须了解正确的胰岛素储存、处理和给药技术，以预防医源性低血糖[1]。一致的喂食时间和适当的份量控制有助于维持稳定的血糖水平。应急准备包括教导主人识别低血糖症状并在寻求兽医护理前立即给予口服葡萄糖或玉米糖浆治疗[1]。

### Sources

[1] Endocrine emergencies (Proceedings): https://www.dvm360.com/view/endocrine-emergencies-proceedings
[2] Two human portable glucometers and a veterinary point-of-care glucometer for measurement of blood glucose concentration in dogs: https://avmajournals.avma.org/view/journals/ajvr/86/6/ajvr.24.10.0317.xml
[3] Accuracy of a flash glucose monitoring system in healthy dogs: https://avmajournals.avma.org/view/journals/ajvr/86/2/ajvr.24.08.0242.xml
[4] A veterinary-calibrated point-of-care glucometer accurately measures blood glucose: https://avmajournals.avma.org/view/journals/ajvr/85/9/ajvr.24.05.0146.xml
[5] The secret to successful at-home glucose monitoring: https://www.dvm360.com/view/the-secret-to-successful-at-home-glucose-monitoring-simplicity

## 鉴别诊断与预后

**鉴别诊断**

低血糖表现的关键鉴别诊断包括分泌胰岛素的肿瘤（胰岛素瘤）、败血症、肝病、肾上腺皮质功能减退症和胰腺外肿瘤[1]。胰岛素瘤是犬猫中最常见的引起低血糖的功能性胰腺肿瘤[2]。

应将胰岛细胞增生症视为犬胰岛素瘤的罕见鉴别诊断，特别是当临床症状和临床病理异常在部分胰腺切除术后消失时[2]。重要的鉴别特征包括样本处理错误（人为性低血糖）、提示败血症的红细胞增多症或白细胞增多症，以及与肝病或肾上腺皮质功能减退症一致的血清生化异常[3]。

胰腺外肿瘤引起的副肿瘤性低血糖症是另一个重要的鉴别诊断，胃肠道间质瘤（GIST）和大型肝脏或胃肠道肿瘤能够导致葡萄糖消耗[5]。木糖醇中毒虽然主要被视为中毒，但在出现急性低血糖的犬中必须考虑[7]。

**预后**

预后因潜在病因和治疗反应而有显著差异。对于胰岛素瘤，接受手术治疗的犬的中位生存时间（381天，范围20-1758）比仅接受药物治疗（74天，范围8-508）更长[3]。然而，接受药物治疗的犬通常总体接受的治疗较不积极。

在经历低血糖发作的糖尿病猫中，与持续患糖尿病的猫相比，达到临床缓解与更长的生存时间相关。诊断时并发肾功能显著恶化预后，肌酐浓度每增加10-μg/dl，死亡风险增加5%[4]。

### Sources

[1] 02-10-0489 - AVMA: https://avmajournals.avma.org/downloadpdf/view/journals/javma/223/6/javma.2003.223.812.pdf
[2] Resolution of hyperinsulinemic hypoglycemia following partial...: https://avmajournals.avma.org/view/journals/javma/253/7/javma.253.7.893.xml
[3] Logical approach to diagnosis and management of hypoglycemia: https://www.dvm360.com/view/logical-approach-diagnosis-and-management-hypoglycemia-proceedings
[4] Journal Scan: Survival data and prognostic factors in cats with newly diagnosed diabetes: https://www.dvm360.com/view/journal-scan-survival-data-and-prognostic-factors-cats-with-newly-diagnosed-diabetes
[5] Paraneoplastic syndromes in dogs and cats - dvm360: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[6] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[7] Xylitol Toxicosis in Dogs - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/food-hazards/xylitol-toxicosis-in-dogs
