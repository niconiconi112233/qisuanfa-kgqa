# 伴侣动物咬伤

咬伤是最常见的兽医急症之一，每年影响数千只犬和猫，并可能危及生命的并发症。这些创伤性损伤造成"冰山效应"，即小的表面穿刺伤掩盖了广泛的潜在组织损伤、细菌污染和全身感染风险。体重低于10公斤的小型犬面临不成比例的风险，胸部和腹部伤口的预后尤其严重。本报告探讨了咬伤的复杂病理生理学，从涉及巴斯德菌和厌氧菌种的多微生物污染到先进的诊断成像技术。对基于证据的治疗方案、抗菌药物选择策略和决定患者结果的关键预后因素进行了系统分析，以指导伴侣动物临床实践中的临床决策。

## 疾病概述和常见病原体

### 疾病概述

伴侣动物的咬伤是由其他动物的牙齿造成的创伤性损伤，导致穿刺伤、撕裂伤和组织挤压损伤[1]。这些损伤不仅对皮肤，而且通过撕裂和挤压机制对深层组织造成显著损害[1]。犬的下颌在压缩过程中可施加150-450 psi的力量，造成典型的"冰山效应"，即小的表面穿刺伤掩盖了广泛的潜在组织损伤[1]。

体重低于10公斤的小型犬，特别是未绝育的雄性梗犬，在咬伤受害者中比例过高[1]。头部、颈部和四肢是最常受影响的解剖部位，其次是胸部和腹部[1]。与大型犬相比，小型犬更容易遭受胸部和腹部损伤[1]。

### 常见病原体

由于口腔菌群的多微生物性质，所有咬伤都必须被视为被污染[1]。动物口腔中存在多种厌氧菌、需氧菌、革兰氏阴性菌和革兰氏阳性菌[1]。常见的需氧菌分离株包括中间型葡萄球菌、肠球菌属、凝固酶阴性葡萄球菌和大肠杆菌[2]。从咬伤中经常培养出巴斯德菌属、链球菌属和大肠杆菌[3]。

常见的厌氧病原体分离株包括类杆菌属、放线菌属、梭杆菌属、芽孢杆菌属、梭菌属和棒状杆菌属[2,3]。猫的口腔中特别含有大量的多杀性巴斯德菌[1]。挤压损伤造成的失活组织环境为细菌增殖提供了理想的基质[1]。

虽然罕见，但病毒可以通过咬伤传播。狂犬病病毒是最重要的病毒性关注点，通过含有病毒的唾液通过咬伤引入组织而传播[4]。该病毒在大多数犬中的潜伏期范围为21-80天，尽管这可能差异很大[4]。狂犬病传播需要通过新鲜伤口或完整的粘膜接触受感染的唾液[4]。

### Sources

[1] Managing gunshot wounds and serious bite wounds: https://www.dvm360.com/view/managing-gunshot-wounds-and-serious-bite-wounds-proceedings
[2] Dog-bite wounds: bacteriology and treatment outcome in 37: https://meridian.allenpress.com/jaaha/article/37/5/453/175686/Dog-bite-wounds-bacteriology-and-treatment-outcome
[3] Patterns of bacterial culture and antimicrobial - AVMA: https://avmajournals.avma.org/view/journals/javma/260/8/javma.21.04.0180.xml
[4] Merck Veterinary Manual Rabies in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/rabies-in-dogs

## 临床表现和诊断方法

犬和猫的咬伤表现出特征性的临床模式，需要系统评估[1]。新鲜伤口通常显示穿刺痕迹、撕裂伤或组织撕脱，伴有周围瘀伤和肿胀[1]。临床检查显示多个成簇的穿刺伤、组织挤压损伤和深层结构的潜在损伤[1]。

并发症取决于伤口位置。胸部咬伤可能导致气胸、血胸或呼吸窘迫，需要立即关注[1,4]。腹部伤口可能导致严重的内部损伤，包括出血、胃肠道穿孔或器官创伤[4]。攻击者和受害者动物之间的体型差异影响损伤严重程度[1]。

诊断评估从在镇静或麻醉下彻底探查伤口开始，以确定穿透深度并识别异物[4]。放射成像检测骨骼受累、牙齿碎片或气胸[4,5]。实验室评估包括全血细胞计数和生化面板，以评估全身影响[1]。

细菌培养和药敏试验指导抗菌药物选择，尽管经验性治疗通常立即开始[1]。如果可能，应通过抽吸或深部组织活检而非表面拭子收集标本[7]。细胞学检查区分炎症和感染过程，并有助于识别需要手术干预的并发症[4]。

### Sources

[1] Open wound management in dogs and cats: https://www.dvm360.com/view/open-wound-management-in-dogs-and-cats
[2] Manage bite wounds: not just skin deep: https://www.dvm360.com/view/manage-bite-wounds-not-just-skin-deep
[3] Trauma in Emergency Medicine in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/specific-diagnostics-and-therapy/trauma-in-emergency-medicine-in-small-animals
[4] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml

## 治疗策略和预防措施

**即时治疗方案**

咬伤的初步管理需要及时评估和稳定患者[1]。首要优先事项是通过直接压力控制活动性出血，并处理呼吸或心血管功能障碍。稳定后，彻底探查伤口、用无菌盐水大量冲洗和积极清创失活组织是必不可少的[2]。

**抗菌治疗**

所有咬伤都应被视为被污染，需要广谱抗生素覆盖[3]。革兰氏阳性球菌通常从咬伤中培养出来，多杀性巴斯德菌在猫咬伤中尤其普遍[5]。初始治疗通常包括阿莫西林-克拉维酸或第一代头孢菌素，等待培养结果。

**伤口管理选择**

手术缝合仅适用于清洁、充分清创且有足够皮肤覆盖的伤口[1]。污染伤口需要开放管理，重复包扎和清创，直到形成健康的肉芽组织[2]。引流系统，包括用于浅表伤口的Penrose引流管和用于更深部损伤的封闭式负压引流管，可防止液体积聚和感染[2]。

**预防策略**

预防以遵循AAHA指南的当前疫苗接种方案为中心，该指南推荐犬的核心疫苗包括狂犬病、犬瘟热、细小病毒和腺病毒，猫的核心疫苗包括猫泛白细胞减少症、疱疹病毒和杯状病毒[7]。环境管理包括适当的动物处理技术、行为训练和避免引发攻击性相遇的情况。

### Sources

[1] Wound Management - Special Pet Topics: https://www.merckvetmanual.com/special-pet-topics/emergencies/wound-management
[2] Manage bite wounds: not just skin deep: https://www.dvm360.com/view/manage-bite-wounds-not-just-skin-deep
[3] Managing gunshot wounds and serious bite wounds (Proceedings): https://www.dvm360.com/view/managing-gunshot-wounds-and-serious-bite-wounds-proceedings
[5] Cat bites: The peril beyond the pain (script): https://www.dvm360.com/view/cat-bites-peril-beyond-pain
[7] Preventative Health Care for Small Animals: https://www.merckvetmanual.com/management-and-nutrition/preventative-health-care-and-husbandry-in-small-animals/preventative-health-care-for-small-animals

## 鉴别诊断和预后

### 鉴别诊断

咬伤需要与几种表现相似的疾病进行鉴别。**撕脱伤**表现为广泛的皮肤丧失，但通常由剪切力而非穿刺创伤引起[1]。**锐器造成的撕裂伤**产生清洁、线性的伤口，没有咬伤中特征性的穿刺模式和组织挤压[1]。

**坏死性筋膜炎**是一个严重的鉴别诊断，表现为快速传播的细菌软组织感染，最初可能类似于感染的咬伤，但进展更具侵袭性[2]。**压疮**由长时间压力引起的坏死发展而来，缺乏与咬伤相关的创伤史[1]。

### 预后因素

几个因素显著影响咬伤预后。**伤口位置**严重影响结果，胸部伤口尽管表面创伤最小，但可能导致内部器官损伤[1][3]。**猫咬伤**由于其小而穿透的性质经常感染，而**犬咬伤**在表面下造成更广泛的组织损伤[1]。

**治疗时间**影响预后，因为延迟干预会增加细菌污染[8]。**年龄和体重**也影响生存率，死亡率几率每年增加7%，每公斤体重减少14%[3]。**初级缝合**在严重污染的伤口中可能禁忌，需要在24-72小时后延迟缝合[8]。

### 预期结果

大多数无并发症的咬伤如果早期治疗，在适当管理下愈合良好[2]。然而，**通常不建议完全伤口闭合**，因为存在污染问题[1]。**延迟初级缝合**或**二期愈合**通常提供更好的结果，尽管愈合时间延长[8]。对于手术裂开病例，二次修复后的生存率达到83%，中位住院时间为2天[2]。当内部结构受损时，特别是影响胸部或腹部的犬咬伤，可能发生严重并发症[1]。

### Sources

[1] Management of Specific Wounds in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/management-of-specific-wounds-in-small-animals

[2] Evaluation of early and systematic ultrasound examination to: https://avmajournals.avma.org/view/journals/javma/263/1/javma.23.10.0599.xml

[3] Animal Trauma Triage Score, Modified Glasgow Coma Scale: https://avmajournals.avma.org/view/journals/javma/261/6/javma.22.11.0531.xml

[8] Initial Wound Management in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/initial-wound-management-in-small-animals
