# 犬细小病毒性肠炎

犬细小病毒性肠炎是影响幼犬的最重要传染病之一，有可能迅速发展为危及生命的并发症。这种高度传染性的病毒性疾病由犬细小病毒（CPV）及其不断演变的变体引起，尽管已有数十年的疫苗可用，但仍持续挑战着兽医从业者。该病毒在环境中的持久性，加上其对肠道中快速分裂细胞的偏好，为易感人群的严重临床结果创造了完美条件。

本综合分析审视了对细小病毒性肠炎的当前理解，从CPV-2变体的分子特征到基于证据的治疗方案。该报告综合了当代诊断方法，探讨了包括单克隆抗体治疗在内的新兴治疗干预措施，并评估了对群体健康管理至关重要的预防策略。

## 疾病概述

犬细小病毒性肠炎是由犬细小病毒（CPV）引起的一种急性、高度传染性的病毒性疾病，CPV是一种单链、无包膜DNA病毒，属于食肉原细小病毒1种（Merck兽医手册）。该病毒大约在1978年从猫泛白细胞减少症病毒进化而来，由于其高度传染性和环境稳定性而迅速在全球传播（Merck兽医手册）。

CPV表现出显著的环境持久性，在室内至少存活2个月，在室外如果避免阳光直射可能存活数年（Merck兽医手册）。病毒通过粪口途径传播，感染犬在疾病急性期通过粪便排出大量病毒。

该疾病主要影响6周至6月龄的幼犬，特别是那些未接种疫苗或未完成完整疫苗接种的幼犬（Merck兽医手册）。某些品种表现出更高的易感性，包括罗威纳犬、杜宾犬、英国史宾格犬、德国牧羊犬和比特犬类品种（Merck兽医手册）。在成年犬中，未绝育公犬比未绝育母犬表现出更高的疾病易感性（Merck兽医手册）。

病毒针对快速分裂的细胞，特别是肠隐窝上皮、骨髓和淋巴组织，导致特征性的出血性肠炎临床综合征，伴随免疫抑制（Merck兽医手册）。

## 常见病原体

犬细小病毒性肠炎由犬细小病毒（CPV）引起，这是一种单链、无包膜DNA病毒，从猫泛白细胞减少症病毒（FPV）进化而来[1]。该病毒属于食肉原细小病毒1种，该种还包括FPV和水貂肠炎病毒[2]。

自出现以来，CPV经历了显著的抗原进化。原始毒株CPV-2在很大程度上已被三个主要变体取代：CPV-2a、CPV-2b和CPV-2c[1]。在北美，临床疾病主要归因于CPV-2b，而较新毒株CPV-2c的感染越来越常见，已在至少15个州被确认[3]。

CPV-2c代表了一个显著的进化发展，具有特定的氨基酸突变，包括衣壳蛋白中第426位残基从天冬氨酸变为谷氨酸[1]。该变体最初在意大利被确认，但此后已在美国各地传播。尽管存在这些遗传差异，但尚未发现特定CPV毒株与临床疾病严重程度之间的关联[3]。

当前疫苗对所有流行毒株（包括较新变体）提供交叉保护[1]。与RNA病毒相比，该病毒表现出显著的遗传稳定性，但仍保持足够的突变率以产生这些临床上相关的抗原变体。

### Sources
[1] Update on viral diseases in dogs (Proceedings): https://www.dvm360.com/view/update-viral-diseases-dogs-proceedings
[2] Merck Veterinary Manual Feline Panleukopenia - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/infectious-diseases/feline-panleukopenia/feline-panleukopenia
[3] Merck Veterinary Manual Canine Parvovirus Infection (Parvoviral Enteritis in Dogs) - ...: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/canine-parvovirus

## 临床症状和体征

犬细小病毒性肠炎的临床症状通常在感染后5-7天内出现，但可能在暴露后2至14天内的任何时间出现[1]。初始表现通常是非特异性的，包括嗜睡、厌食和发热，在24-48小时内迅速进展为更具特征性的胃肠道症状[1]。

标志性的临床表现是出血性小肠腹泻，伴随呕吐。然而，约25%的犬可能表现为非出血性腹泻[1]。体格检查结果通常包括精神抑郁、发热、脱水和扩张、充满液体的肠袢[1]。腹痛需要立即检查以排除肠套叠作为潜在并发症。

严重受影响的动物可能表现出与脓毒性休克一致的体征，包括虚脱、毛细血管再充盈时间延长、脉搏质量差、心动过速和低温[1]。当中枢神经系统体征出现时，通常继发于低血糖、脓毒症或电解质异常，而非直接的病毒影响[1]。

某些品种表现出更高的易感性，包括罗威纳犬、杜宾犬、英国史宾格犬、德国牧羊犬和比特犬类犬种[1]。在六个月以上的犬中，未绝育公犬比未绝育母犬表现出更高的疾病易感性[1]。亚临床感染很常见，应激因素可能加剧临床表现[1]。

### Sources
[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs) - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/canine-parvovirus

## 诊断方法

犬细小病毒性肠炎的准确诊断依赖于多种方法，快速抗原检测是临床诊断的基石。**粪便抗原检测结合典型临床症状和实验室结果（白细胞减少症）是诊断细小病毒性肠炎最常见的方法**[1]。

**用于粪便抗原检测的商业ELISA试剂盒**广泛可用，对所有CPV毒株具有良好的至极佳的敏感性和特异性[2]。ELISA和免疫迁移检测试剂盒都显示出高准确性，尽管**最近接种过疫苗的犬可能会短暂排出被试剂盒检测到的抗原**[3]。在疾病早期，当病毒排出量低时，由于严重腹泻的稀释效应，或当抗体结合病毒抗原时，可能出现假阴性结果[1][3]。

**替代诊断方法包括PCR检测、电子显微镜和从粪便样本中进行病毒分离**[2]。与抗原检测相比，PCR检测提供更高的敏感性，即使抗原检测呈阴性时也能检测到病毒[4]。**使用鼻拭子的初步数据表明，PCR在检测病毒方面比ELISA抗原检测或病毒分离更敏感**[5]。

**支持诊断的实验室发现**包括中度至重度白细胞减少症，以淋巴细胞减少和中性粒细胞减少为特征，通常在疾病过程中发展[2]。其他异常可能包括低白蛋白血症、电解质失衡和肝酶升高。

**影像学研究**很少用于诊断，但在严重受影响的病例中，腹部X线片可能显示扩张、充满液体的肠袢[2]。

### Sources

[1] Diagnosing common infectious diseases: https://www.dvm360.com/view/diagnosing-common-infectious-diseases-what-do-all-those-new-tests-titers-pcrs-and-blue-dots-really-0
[2] Canine Parvovirus Infection - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[3] Serologic Test Kits - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/serologic-test-kits
[4] Viral diagnostics - DVM360: https://www.dvm360.com/view/viral-diagnostics-what-do-results-mean-proceedings
[5] Emerging respiratory infections: https://www.dvm360.com/view/emerging-respiratory-infections-proceedings

## 治疗选择

犬细小病毒性肠炎的治疗需要积极的支持性护理，液体治疗是管理的基石[1]。静脉注射平衡电解质溶液可纠正脱水并补充持续丢失，当无法进行监测时，经验性补充氯化钾（20-40 mEq/L）和葡萄糖（2.5-5%）[1]。

由于受损肠上皮的细菌易位风险和伴随的中性粒细胞减少症，抗菌治疗是必需的[1]。β-内酰胺类抗生素如氨苄西林（22 mg/kg静脉注射，每8小时一次）提供革兰氏阳性和厌氧菌覆盖，而严重病例需要恩诺沙星或庆大霉素提供额外的革兰氏阴性菌覆盖，持续5-7天[1,3]。

止吐治疗控制导致脱水持续恶化的呕吐[1]。马罗匹坦（1 mg/kg静脉注射/皮下注射，每24小时一次）和昂丹司琼（0.5 mg/kg静脉注射，每8小时一次）同样有效，而甲氧氯普胺提供额外的促动力效应[1,3]。

在12小时内进行早期肠内营养相比传统的禁食能改善临床结果和肠道屏障功能[1]。新鲜冷冻血浆输注（3-5 ml/磅）适用于严重低蛋白血症（白蛋白<2.0 g/dL），以恢复胶体渗透压并提供蛋白酶抑制剂[3,4]。

新兴疗法包括单克隆抗体治疗，在实验研究中显示100%的存活率，而对照组为43%[1]。粪便微生物群移植将住院时间从6天减少到3天[1]。通过适当的支持性护理，存活率达到70-90%[1]。

### Sources
[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[2] Early administration of canine parvovirus monoclonal antibody: https://avmajournals.avma.org/view/journals/javma/262/4/javma.23.09.0541.xml
[3] Treatment of severe parvoviral enteritis (Proceedings): https://www.dvm360.com/view/treatment-severe-parvoviral-enteritis-proceedings
[4] Managing patients with parvoviral enteritis (Proceedings): https://www.dvm360.com/view/managing-patients-with-parvoviral-enteritis-proceedings

## 预防措施

疫苗接种代表犬细小病毒预防的基石。**建议在6-8周、10-12周和14-16周龄时接种减毒活疫苗**，然后每年加强接种，之后每三年接种一次[1]。当前疫苗对所有CPV毒株（包括较新的CPV-2c变体）提供同等的良好保护[1]。对于怀孕母犬或非常年幼的幼犬（6-8周以下），由于潜在的心肌损伤风险，优选灭活疫苗[1]。

环境消毒至关重要，因为**CPV可以在环境中长时间保持活性**--在室内至少2个月，在室外如果避免阳光直射可能数年[1]。有效的消毒剂包括**稀释漂白剂（1:30比例）、过一硫酸钾或加速过氧化氢**[1]。季铵盐消毒剂对细小病毒不可靠[1]。

严格的隔离方案对受感染动物至关重要。人员必须遵循**隔离住房、穿隔离衣和戴手套程序、频繁清洁和足浴**[1]。在收容所环境中，应在入所时立即接种疫苗，幼犬每两周重新接种一次，直到18周龄[2]。只有完全接种疫苗的犬才应被引入最近发生过细小病毒的环境[1]。

### Sources

[1] Merck Veterinary Manual Canine Parvovirus Infection: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/canine-parvovirus

[2] Tools for managing shelter outbreaks of canine parvovirus: https://www.dvm360.com/view/tools-managing-shelter-outbreaks-canine-parvovirus-proceedings

## 鉴别诊断

几种疾病可能表现出与犬细小病毒性肠炎相似的临床症状，因此准确鉴别对适当治疗至关重要[1]。最重要的鉴别诊断包括冠状病毒性肠炎、急性出血性腹泻综合征和肠道寄生虫病。

冠状病毒性肠炎通常影响绒毛顶端上皮而非隐窝细胞，导致比细小病毒更短的恢复期[1]。与细小病毒不同，冠状病毒很少引起严重的淋巴细胞减少或中性粒细胞减少[2]。急性出血性腹泻综合征表现出类似的出血性腹泻，但与产气荚膜梭菌过度生长相关，通常发生在成年犬中，没有细小病毒特征性的白细胞减少[4]。

严重淋巴细胞减少至绝对淋巴细胞减少是细小病毒性肠炎与其他严重腹泻原因（包括沙门氏菌病和出血性胃肠炎）区别的关键特征[2]。肠道寄生虫病，特别是钩虫，可引起出血性腹泻，但很少产生细小病毒所见的显著血液学变化[1]。

结合信号特征（年轻、未接种疫苗的犬）、临床表现和实验室发现--特别是伴有淋巴细胞减少和中性粒细胞减少的严重白细胞减少症--有助于将细小病毒性肠炎与这些鉴别诊断区分开来[1][2]。当临床怀疑度高时，商业粪便抗原检测提供快速、特异性的确认[1]。

### Sources

[1] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/en/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs

[2] Therapy and vaccination for a new canine parvovirus (Proceedings): https://www.dvm360.com/view/therapy-and-vaccination-new-canine-parvovirus-proceedings

[3] The Digestive System in Animals: https://www.merckvetmanual.com/digestive-system/digestive-system-introduction/the-digestive-system-in-animals

[4] Antibiotics in canine GI disease: when to use and when to ditch: https://www.dvm360.com/view/antibiotics-in-canine-gi-disease-when-to-use-and-when-to-ditch
