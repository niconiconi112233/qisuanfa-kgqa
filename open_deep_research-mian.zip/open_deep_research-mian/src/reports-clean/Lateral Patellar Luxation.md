# 伴侣动物的髌骨外侧脱位

髌骨外侧脱位是一种影响犬猫膝关节的独特骨科疾病，其特征是髌骨从股骨滑车沟向肢体外侧移位。与更常见的髌骨内侧脱位不同，外侧脱位主要影响大型和巨型犬种，并带来独特的诊断和治疗挑战。本综合报告探讨了外侧脱位特有的流行病学模式、其特征性临床表现（包括四级严重程度分类系统）、强调品种特异性结构差异的诊断方法，以及从保守治疗到复杂手术干预的治疗策略。该分析综合了当前兽医文献，为从业人员提供在小动物临床中管理这种情况的循证指导。

## 疾病概述

**定义**

髌骨外侧脱位是一种骨科疾病，指髌骨（膝盖骨）从股骨滑车沟向外侧移位，远离身体中线（默克兽医手册，2024年）。这种情况表现为髌骨向膝关节外侧移位，与更常见的内侧脱位模式相反。

**流行病学背景**

髌骨外侧脱位表现出与内侧脱位明显不同的品种易感模式。大型犬有20%的外侧脱位，而小型犬仅为2%，巨型犬则表现出33%的外侧脱位（DVM360，2024年）。这种情况在小型犬中罕见，但在大型犬中更常见，通常与髋外翻和髋关节发育不良相关（DVM360，2024年）。流行病学数据显示，体型与外侧和内侧脱位患病率之间存在明显的反比关系，外侧脱位主要影响体型较大的犬患者。发病年龄因品种大小而异，但与广泛记录的内侧脱位统计数据相比，外侧脱位的具体患病率数据仍然有限。

## 临床症状和体征

现有内容对髌骨外侧脱位的临床体征提供了极好的覆盖。我将把这些与新的来源材料结合起来，以增强特定方面，同时保持既定结构。

髌骨外侧脱位表现出与更常见的内侧脱位不同的特征性临床体征。受影响的动物通常表现出跛行或以独特的跳跃步态行走，它们会抬起腿几步然后恢复负重[1]。这种间歇性跛行模式在II级病例中尤为明显。

**分级系统和体格检查体征：**
严重程度遵循标准化的四级分类系统[1,2]。I级动物表现出轻微、不频繁的临床症状，可手动脱位但易于复位。II级表现为间歇性跛行，屈曲时自发脱位，伸展时复位。III-IV级表现出逐渐加重的严重程度，伴有持续性跛行和明显的肢体畸形[1,2]。

**品种特异性模式：**
与内侧脱位不同，髌骨外侧脱位表现出独特的品种易感模式[3,4]。大型犬有20%的外侧脱位，而小型犬仅为2%，巨型犬则表现出33%的外侧脱位[4]。髌骨外侧脱位在小型犬中罕见，但在大型犬中更常见，通常与髋外翻和髋关节发育不良相关[4]。

**体格检查发现：**
患有外侧脱位的犬可能表现出"膝内翻"外观（膝外翻），与内侧病例中看到的"弓形腿"姿势相反[2,3]。患有3级和4级外侧脱位的犬可能有"膝内翻"外观或膝外翻[3]。触诊可发现髌骨向滑车沟外侧移位。缝匠肌前部走向和膝关节轮廓变化在检查期间提供额外的诊断线索[2]。

### Sources
[1] Patellar Luxation in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/patellar-luxation-in-dogs-and-cats
[2] Patella luxations (Proceedings): https://www.dvm360.com/view/patella-luxations-proceedings
[3] Patella luxation (Proceedings): https://www.dvm360.com/view/patella-luxation-proceedings
[4] Managing patellar luxations (Proceedings): https://www.dvm360.com/view/managing-patella-luxations-proceedings

## 诊断方法

体格检查是髌骨外侧脱位评估的主要诊断工具[1]。临床检查从步态评估和同时触诊两个膝关节开始，以比较对称性、肌肉质量，并检测关节积液或关节周围纤维化[1]。用拇指和食指触诊髌骨，以评估其相对于股骨髁和滑车沟的位置[1,3]。

髌骨稳定性测试包括伸展膝关节并尝试将髌骨向外侧推动，然后在保持压力的同时屈曲关节[1,3]。胫骨内旋或外旋可以促进脱位或复位--外旋通常有助于复位外侧脱位[1]。检查应评估活动范围内的轨迹，因为正常髌骨会返回滑车沟，而脱位髌骨则保持偏离[1,3]。最近的研究表明，易患髌骨脱位的犬膝关节内旋松弛度增加，提供了额外的诊断见解[6]。

标准侧位和头尾位X线片评估结构并排除并发疾病[1,3]。脱位的髌骨在放射学上可能可见，尽管I级和II级脱位是间歇性的，在成像期间可能显示已复位[1,3]。包括膝关节的腹背位骨盆X线片有助于评估股骨内翻/外翻畸形，但定位必须精确以避免误导性发现[1]。

当X线片结果不确定时，CT或MRI的先进成像提供对骨骼畸形和软组织结构的优越评估[2]。与内侧脱位的鉴别诊断依赖于移位方向和相关的结构异常--外侧脱位主要影响大型犬，可能表现为膝外翻，而内侧脱位通常表现为膝内翻[1,5]。

### Sources

[1] Patella luxation: Diagnosis and surgical decision making (Proceedings): https://www.dvm360.com/view/patella-luxation-diagnosis-and-surgical-decision-making-proceedings

[2] Complications after corrective surgery for lateral patellar luxation in dogs: 36 cases (2000-2011): https://avmajournals.avma.org/view/journals/javma/244/4/javma.244.4.444.xml

[3] Managing patellar luxations (Proceedings): https://www.dvm360.com/view/managing-patella-luxations-proceedings

[4] Patella luxations (Proceedings): https://www.dvm360.com/view/patella-luxations-proceedings

[5] The seven most common reasons Fido might limp into your clinic (Sponsored by Purina Veterinary Diets): https://www.dvm360.com/view/seven-most-common-reasons-fido-might-limp-your-clinic-sponsored-purina-veterinary-diets

[6] Internal rotational laxity of the stifle is increased in dogs: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0154/javma.25.03.0154.pdf

## 治疗选择

髌骨外侧脱位的治疗包括保守和手术方法，选择基于脱位级别、患者因素和临床严重程度。保守管理包括抗炎药物、体重控制和物理康复锻炼，重点是活动范围和肌肉强化[1]。

手术干预通常需要用于3-4级脱位，可能涉及多种同时进行的手术。核心技术包括滑车沟加深（楔形截骨、块状截骨或软骨成形术）、外侧关节囊折叠术和胫骨结节转位术[2]。治疗选择取决于个体病例解剖结构，而不是遵循针对特定级别的严格方案。

术后护理强调2-4周的活动限制控制，随后是逐渐康复，包括被动活动范围练习、控制性牵引散步和物理治疗模式[2]。术后冷疗10-15分钟有助于控制炎症和疼痛[7]。

物理康复对于获得最佳结果至关重要，包括治疗前热疗、治疗性练习如跑步机行走和水疗，以及强化活动[6,7]。长期管理的基础包括体重控制、运动疗法和抗炎药物或补充剂[4]。

治疗选择的决策标准包括脱位级别、患者年龄、并发疾病和主人期望。幼犬的2-4级脱位通常会进展并需要及时手术矫正，而脱位稳定的成年患者可能对保守管理有反应[8]。

### Sources

[1] Sporting dog injuries: https://www.dvm360.com/view/sporting-dog-injuries
[2] Diagnosing and treating strains and sprains (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-strains-and-sprains-proceedings
[3] Osteoarthritis in cats: Still a mass of unknowns: https://www.dvm360.com/view/osteoarthritis-cats-still-mass-unknowns
[4] Diagnosing and treating rear limb disorders in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-rear-limb-disorders-dogs-proceedings
[5] Stabilization of a vertebral fracture by a monolateral external: https://avmajournals.avma.org/view/journals/javma/260/12/javma.21.03.0137.xml
[6] Physical rehabilitation: Improving the outcome in dogs with orthopedic problems: https://www.dvm360.com/view/physical-rehabilitation-improving-outcome-dogs-with-orthopedic-problems
[7] CVC highlight: DIY veterinary rehabilitation for patients with patella and cruciate injuries: https://www.dvm360.com/view/cvc-highlight-diy-veterinary-rehabilitation-patients-with-patella-and-cruciate-injuries
[8] Patella luxation (Proceedings): https://www.dvm360.com/view/patella-luxation-proceedings
