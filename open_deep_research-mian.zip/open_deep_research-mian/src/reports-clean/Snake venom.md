# 伴侣动物的蛇毒中毒

蛇毒中毒是一种严重的兽医急症，据估计每年在北美影响约150,000只犬和猫。本综合报告探讨了伴侣动物毒蛇咬伤的病理生理学、临床表现和管理，主要关注占病例99%的蝮蛇毒中毒。分析涵盖了重要的诊断方法，包括凝血病评估，强调抗蛇毒治疗时机的循证治疗方案，以及影响生存结果的预后因素。特别关注物种特异性毒液特征，从导致组织坏死的溶血性蝮蛇效应到需要呼吸支持的神经毒性珊瑚蛇表现，为兽医从业者提供这种时间敏感性疾病可行的临床指导。

## 疾病概述与流行病学

蛇毒中毒是毒蛇通过咬伤将毒液注入犬和猫体内，导致局部组织损伤并可能危及生命的全身毒性反应[1]。这种情况代表了一种重要的兽医急症，需要立即进行医疗干预。

在美国，估计每年有150,000只犬和猫被毒蛇咬伤[2][3]。北美约99%的毒蛇咬伤是由蝮蛇科（Crotalidae）造成的，包括响尾蛇、铜头蛇和水栖棉口蛇[3]。其余病例涉及眼镜蛇科蛇类，主要是珊瑚蛇，它们生活在美国南部林地或沼泽地区[2]。

从地理上看，大多数咬伤发生在4月至10月间的南部和西南各州，这与温暖月份蛇类活动增加和宠物户外活动增多相吻合[2]。蝮蛇咬伤的发生频率远高于眼镜蛇科咬伤[2]。由于体型较小且倾向于激怒蛇类，猫通常表现出比犬更严重的临床症状，通常导致躯干受到攻击性咬伤[3]。

死亡率差异显著，估计范围从1%到30%不等，在犬中比其他动物更常见[2]。然而，由于致死毒液剂量与体重相关，较大动物的死亡率相对较低[2]。

### Sources

[1] Snakebite in Animals: A Brief Refresher: https://www.dvm360.com/view/snakebite-in-animals-a-brief-refresher
[2] Snake bite: Pit vipers, part 1 (Proceedings): https://www.dvm360.com/view/snake-bite-pit-vipers-part-1-proceedings
[3] Snakebite!: https://www.dvm360.com/view/snakebite-0

## 常见毒蛇种类及毒液类型

北美毒蛇属于两个主要科，具有不同的毒液特征[1]。**蝮蛇科**（蝮蛇）包括响尾蛇、铜头蛇和棉口蛇，广泛分布于整个大陆。**眼镜蛇科**仅由珊瑚蛇代表，限于美国南部地区[1]。

蝮蛇毒液主要是溶血性的，引起组织坏死、凝血病和抗凝效应[1]。然而，一些物种如莫哈维响尾蛇产生神经毒性毒液，导致肌肉颤动和中枢神经系统抑制[1][2]。这些蛇拥有长而铰接的毒牙，能够深度注入毒液[1]。

珊瑚蛇毒液主要是神经毒性的，由影响神经系统的小蛋白质组成[2]。这些蛇有固定而短的毒牙，需要长时间接触才能注入毒液[2]。临床效应包括影响神经肌肉、呼吸和心血管系统的下行性麻痹[2]。

澳大利亚眼镜蛇科表现出额外的复杂性，其毒液具有神经毒性、肌肉毒性、促凝性、抗凝性或溶血性[1]。虎蛇和棕蛇特别引起明显的心血管异常[1]。

约25%的蝮蛇咬伤导致"干咬"而没有注入毒液[1][2]。北美每年有150,000-300,000只动物遭受蝮蛇咬伤[1]。由于体型相对毒液量较小，犬的致命性毒液中毒比其他家养动物更常见[1]。

### Sources

[1] Snakebites in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/snakebite/snakebites-in-animals

[2] Venomous snakes poisonous to pets: Part I: https://www.dvm360.com/view/venomous-snakes-poisonous-pets-part-i

## 临床表现与诊断方法

蛇毒中毒的临床症状因蛇类而异。蝮蛇科（蝮蛇）咬伤通常引起严重的局部组织损伤，伴有快速肿胀、变色和从咬伤部位扩散的潜在组织坏死[1]。血液或血清可能从毒牙伤口渗出，但毒牙痕迹并不保证毒液注入[1]。全身症状包括虚弱、呕吐、低血压和心律失常[1]。

眼镜蛇科毒液中毒表现为轻微的局部症状但明显的神经系统症状。珊瑚蛇咬伤导致四肢轻瘫、流涎、呼吸急促、浅呼吸、咽反射减弱、共济失调和肌肉颤动[1]。澳大利亚眼镜蛇科咬伤可能引起虚脱、呕吐、震颤和凝血病[1]。

诊断检测应包括全血细胞计数、凝血谱、生化面板和尿液分析[3]。关键发现包括血小板减少、贫血和严重病例中的棘红细胞增多症[1][3]。凝血病发生在约60%的病例中，延长的凝血时间和低纤维蛋白原血症最常见[7]。澳大利亚有蛇毒检测试剂盒，但在兽医患者中很少使用[1]。

严重程度评分系统有助于客观监测病情进展[7]。鉴别诊断包括创伤、脓肿、蜘蛛咬伤、蜱麻痹、肉毒中毒和昆虫叮咬过敏反应[1][3]。

### Sources

[1] Merck Veterinary Manual Snakebites in Animals: https://www.merckvetmanual.com/toxicology/snakebite/snakebites-in-animals

[2] VIN Snakebite: Facing the Challenges - WSAVA2013: https://www.vin.com/apputil/content/defaultadv1.aspx?id=5709822&pid=11372&print=1

[3] DVM 360 Snakebite in Animals: https://www.dvm360.com/view/snakebite-in-animals-a-brief-refresher

[4] VIN Approach and Management of Viper Snake Bites: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=22915&catId=124655&id=8896651&ind=413&objTypeID=17

[5] American Journal of Veterinary Research: https://avmajournals.avma.org/view/journals/ajvr/79/5/ajvr.79.5.532.xml

[6] Merck Veterinary Manual Snakebite - Special Pet Topics: https://www.merckvetmanual.com/special-pet-topics/poisoning/snakebite

[7] DVM 360 Snake bite: Pit vipers, part 1: https://www.dvm360.com/view/snake-bite-pit-vipers-part-1-proceedings

## 治疗方案与管理

紧急稳定治疗从立即静脉注射晶体液开始，以对抗低血压和休克[1]。动物应保持安静并限制活动以防止毒液扩散，优先考虑将其送往兽医设施而非现场急救措施[1]。速效皮质类固醇可能在最初24小时内对患者有益，以控制休克并减少组织损伤，但不建议长期使用[1]。

抗蛇毒是中和蛇毒的唯一直接机制，在毒液注入后6小时内给药时最有效，即使在咬伤后≥24小时给药也可能出现临床改善[1]。北美蝮蛇有多种抗蛇毒可用，包括马源多价抗蛇毒、羊源F(ab)片段抗蛇毒和马源F(ab)2片段抗蛇毒[1]。F(ab)制剂提供较低的过敏反应风险和更快的复溶速度[1]。给药应作为静脉输注缓慢开始，整个初始剂量应在30分钟内给予[6]。犬和猫的平均剂量为一到两瓶，尽管较小的患者由于毒液与体重比较高而需要更高剂量[6]。

支持性护理包括监测凝血病发展，因为棘红细胞增多症和出血性疾病是严重毒液中毒的早期指标[1]。凝血异常可能需要血液制品和低剂量肝素（每60分钟皮下注射5-10 U/kg或每8小时皮下注射50-100 U/kg）[1]。阿片类镇痛药提供疼痛管理，而由于凝血病风险应避免使用非甾体抗炎药[1]。

对于眼镜蛇科毒液中毒，治疗侧重于呼吸支持，澳大利亚病例可能需要机械通气6-8小时，而珊瑚蛇咬伤可能需要长达72小时[4]。美国不再生产珊瑚蛇抗蛇毒，尽管一些从业者从墨西哥进口[1]。当存在组织坏死时，使用广谱抗菌药物如阿莫西林-克拉维酸[1]。

### Sources
[1] Snakebites in Animals - Toxicology: https://www.merckvetmanual.com/toxicology/snakebite/snakebites-in-animals
[2] Snakebite in Animals: A Brief Refresher: https://www.dvm360.com/view/snakebite-in-animals-a-brief-refresher
[3] Snake bite: Pit vipers, part 2 (Proceedings): https://www.dvm360.com/view/snake-bite-pit-vipers-part-2-proceedings

## 预防与预后

**预防措施**

宠物蛇毒中毒最有效的预防措施涉及环境管理和主人教育[1]。宠物主人应了解其地理区域内毒蛇的栖息地，避免让宠物无人看管地在高风险区域（如林地、岩石地形和高草区）漫游，这些地方可能有蛇类藏身[2]。

疫苗接种代表一种专门的预防选择。CAT疫苗（蝮蛇抗毒素类毒素）在改善响尾蛇毒液暴露后的生存率和生存时间方面显示出前景，尽管它可能只对某些物种提供有限保护[2]。该疫苗可能减轻毒液中毒的严重程度，但不能消除蛇咬伤后立即兽医护理的需求。

**预后因素与结果**

蛇毒中毒的预后因多种因素而异。蛇的种类、毒液中毒程度、患者体型、咬伤位置和治疗开始时间是关键决定因素[3]。在犬和猫中，胸部或腹部咬伤的死亡率通常高于头部或四肢咬伤[3]。

眼镜蛇科咬伤幸存者通常完全康复，几乎没有长期后遗症[3]。然而，由于组织坏死，蝮蛇毒液中毒可能导致显著的长期并发症，可能需要截肢或导致永久性功能丧失[3]。严重毒液中毒后肢体水肿可能持续数月[1]。

最初6小时内的早期干预显著改善结果，因为抗蛇毒治疗在这个关键窗口期最有效[3]。新的治疗方法，如瓦雷普拉地布，可能有助于减少珊瑚蛇毒液中毒病例的临床症状持续时间[1]。

### Sources

[1] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0275/javma.25.04.0275.xml
[2] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/76/3/ajvr.76.3.272.xml
[3] Snakebites in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/snakebite/snakebites-in-animals
