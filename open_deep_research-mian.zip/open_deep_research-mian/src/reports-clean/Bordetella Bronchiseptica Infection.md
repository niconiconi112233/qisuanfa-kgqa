# 伴侣动物支气管败血波氏杆菌感染

支气管败血波氏杆菌是小动物临床上一种重要的呼吸道病原体，既是犬窝咳的主要病因，也是猫上呼吸道疾病的重要致病因素。这种革兰氏阴性细菌表现出显著的环境持久性和广泛的宿主范围能力，使其在收容所、犬舍和多宠物家庭等高密度饲养环境中尤为棘手。该感染具有独特的诊断和管理挑战，因为它可引起从轻度上呼吸道症状到严重肺炎的疾病，具有向免疫功能低下个体人畜共患传播的潜力，并且经常作为多微生物呼吸道疾病复合体的一部分出现。本报告探讨了兽医学实践中有效管理支气管败血波氏杆菌感染所必需的发病机制、临床表现、诊断方法、治疗方案和预防策略。

## 疾病概述

支气管败血波氏杆菌是一种革兰氏阴性、需氧的球杆菌，属于产碱菌科中的波氏菌属[1]。这种高度运动的病原体是犬传染性呼吸道疾病复合体（CIRDC）的主要细菌病原体之一，通常被称为"犬窝咳"[2]。

该微生物表现出显著的环境持久性，可以在宿主体外存活较长时间，促进在犬舍、收容所和寄养设施等高密度饲养环境中的传播[3]。支气管败血波氏杆菌表现出广泛的宿主范围能力，自然感染犬、猫、兔和其他各种哺乳动物物种，使其在多物种环境中成为重要关注点[3]。

从流行病学角度看，该细菌在收容所群体中表现出高患病率，其中拥挤和压力是疾病发展的主要风险因素[2]。支气管败血波氏杆菌可作为原发性病原体，特别是在6个月以下的犬中，但通常在病毒损伤呼吸道后引起继发感染[1]。持续的潮湿会增强环境污染，根据条件不同，病原体可存活数小时至数周[4]。与副流感病毒和犬腺病毒2型的合并感染最为常见，导致更严重的疾病表现[1]。

### Sources

[1] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

[2] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.12.0776/javma.24.12.0776.pdf

[3] Feline viral upper respiratory disease: why it persists!: https://www.dvm360.com/view/feline-viral-upper-respiratory-disease-why-it-persists-proceedings

[4] Canine infectious respiratory disease complex: management and prevention in canine populations (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin

## 发病机制和临床表现

**发病机制和毒力机制**

支气管败血波氏杆菌利用多种毒力因子在犬和猫中引起疾病[1]。该微生物通过黏附素附着于纤毛呼吸道上皮，并产生损害黏液纤毛清除系统的毒素，破坏正常的呼吸道防御机制[1]。这种纤毛停滞效应使动物易患继发感染，并在与病毒病原体结合时产生病理协同作用[3]。

该细菌既可作为原发性病原体（特别是在6个月以下的幼犬中），也可在病毒损伤呼吸道后作为机会性入侵者[1][7]。与犬副流感病毒和腺病毒的合并感染比单一病原体感染导致更严重的临床疾病[1][3]。治疗通常侧重于管理继发性细菌感染，因为参与犬传染性呼吸道疾病复合体的大多数病原体是病毒性的，对于显示细菌感染迹象的犬，推荐多西环素作为一线经验性治疗[2]。

**临床表现**

临床症状范围从轻度上呼吸道疾病到严重肺炎[1][6][7]。在单纯性犬窝咳中，犬表现出特征性的干性、刺耳的"鹅鸣"咳嗽，通过气管触诊容易诱发，通常不伴有发热或全身性疾病[7]。复杂病例进展为支气管肺炎，伴有发热、脓性鼻分泌物、抑郁、厌食和 productive 咳嗽[1]。

幼年和处于拥挤环境中的动物面临更严重疾病的高风险[1][7]。幼犬特别容易患肺炎，而虚弱的成年犬可能发展为慢性支气管炎[7]。临床症状通常在暴露后5-10天出现，在单纯性病例中持续10-20天[7]。在收容所环境中，由于拥挤、压力和继发病原体负荷，支气管败血波氏杆菌可引起更严重的疾病[6]。

### Sources

[1] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[2] What are the best practices for antibiotic use in canine infectious respiratory disease complex?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-canine-infectious-respiratory-disease-complex
[3] A review of canine parainfluenza virus infection in dogs: https://avmajournals.avma.org/view/journals/javma/240/3/javma.240.3.273.xml
[4] Collaboration with the clinical microbiology laboratory: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.12.0776/javma.24.12.0776.pdf
[5] Pneumonia in Dogs and Cats - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[6] Canine infectious respiratory disease: Challenges and considerations in animal shelters (Proceedings): https://www.dvm360.com/view/canine-infectious-respiratory-disease-challenges-and-considerations-animal-shelters-proceedings
[7] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 诊断方法和鉴别诊断

**诊断方法**

细菌培养仍然是确诊支气管败血波氏杆菌感染的金标准，尽管它可以从健康猫中分离出来，使解释变得具有挑战性[1]。当怀疑支气管败血波氏杆菌感染时，应将口咽、气管或深部鼻培养拭子样本收集到活性炭Amies转运培养基中[1]。实时PCR检测在临床环境中提供优势，猫URD检测面板可同时检测支气管败血波氏杆菌和其他呼吸道病原体[1]。然而，PCR检测无法区分活动性感染和携带状态[1]。

**样本采集技术**

适当的样本采集对于准确诊断至关重要[4]。应通知实验室临床怀疑情况，以确保使用适当的培养培养基和程序[1]。对于细菌培养，可采集鼻咽或气管拭子进行PCR检测以评估临床症状[6]。

**鉴别诊断**

支气管败血波氏杆菌必须与其他引起相似症状的呼吸道病原体区分开来。在猫中，主要鉴别诊断包括猫疱疹病毒-1（更严重的鼻部症状和角膜炎）、猫杯状病毒（口腔溃疡）、猫衣原体（严重结膜炎）和支原体属[1][7]。在犬中，犬窝咳的鉴别诊断包括犬副流感病毒、犬腺病毒-2和犬流感[6]。与其他猫上呼吸道病原体相比，支气管败血波氏杆菌更常引起咳嗽[1]。

### Sources

[1] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[2] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.12.0776/javma.24.12.0776.pdf
[3] Kennel Cough - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[4] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 治疗方案和预防策略

### 抗微生物治疗
对于感染支气管败血波氏杆菌的犬，治疗方案根据疾病严重程度而异。单纯性犬窝咳通常在14天内无需治疗即可缓解，仅需支持性护理[1][2]。出现全身症状、肺炎证据或疾病持续超过14天的犬需要抗生素干预[1]。

一线经验性治疗是多西环素（5 mg/kg口服每12小时一次或10 mg/kg每24小时一次，持续7-10天），因为它对支气管败血波氏杆菌和支原体属具有优异疗效[2][3]。对于不能耐受多西环素的犬，阿莫西林-克拉维酸（11 mg/kg口服每12小时一次）可作为替代选择[3]。四环素类和喹诺酮类是良好的经验性选择，因为它们能够在支气管组织中达到治疗浓度[1]。

### 支持性护理
支持性管理包括雾化治疗、气道湿化、适当营养、补水和休息[1]。应尽量减少烟草烟雾等环境压力因素，并将患者隔离以防止疾病传播[1][2]。

### 疫苗接种方案
支气管败血波氏杆菌疫苗有活体鼻内注射或胃肠外灭活制剂[4][5]。鼻内疫苗提供快速免疫（一周内），对≥3周龄的幼犬单次给药[4][5]。建议每年重新接种疫苗，在高风险环境中每6-12个月加强一次[4]。

美国动物医院协会建议基于风险的疫苗接种，特别是对于经常光顾美容设施、寄养犬舍、狗公园或收容所的犬[5]。

### 环境管理
有效预防需要隔离受感染动物并实施适当的卫生规程，包括洗手、使用个人防护设备和表面消毒[2][6]。

### Sources
[1] Managing of bronchial disease in dogs and cats: https://www.dvm360.com/view/managing-bronchial-disease-dogs-and-cats-proceedings
[2] What are the best practices for antibiotic use in pneumonia, bronchitis and pyothorax: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-pneumonia-bronchitis-and-pyothorax
[3] What are the best practices for antibiotic use in canine infectious respiratory disease complex: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-canine-infectious-respiratory-disease-complex
[4] Canine vaccine update (Proceedings): https://www.dvm360.com/view/canine-vaccine-update-proceedings
[5] New formulation for kennel cough vaccine is available: https://www.dvm360.com/view/new-formulation-for-kennel-cough-vaccine-is-available
[6] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough

## 预后和管理考虑因素

犬和猫支气管败血波氏杆菌感染的预后通常良好，只要给予适当管理。单纯性传染性气管支气管炎通常在14天内无需特定治疗即可缓解[1][2]。然而，不良预后指标包括嗜睡、发热、呼吸困难和打喷嚏，这可能表明疾病进展为伴有肺炎的复杂疾病[1]。

**多猫环境管理**
在多猫环境中，感染控制至关重要，因为支气管败血波氏杆菌具有高度传染性。受感染动物应在开始抗生素治疗后至少隔离48-72小时，直到临床症状改善[2]。该微生物可在康复后排出数周，使收容所和猫舍环境中的管理复杂化。患有犬窝咳的犬应与其他犬分开饲养以防止传播[3]。

**人畜共患风险和人类安全**
支气管败血波氏杆菌具有人畜共患潜力，特别是对于免疫功能低下个体，包括囊性纤维化、慢性肉芽肿病和其他吞噬功能缺陷患者[2][4]。人类感染最可能发生在儿童和免疫功能低下的成年人中，风险最高的人群包括酒精性营养不良、血液恶性肿瘤和并发HIV感染的个体[1]。兽医应向宠物主人提供感染控制措施的建议。

**长期监测**
大多数病例完全康复而无后遗症。支气管败血波氏杆菌的多西环素治疗可能需要长达30天的延长治疗时间，特别是在管理同一环境中共同生活的多只动物的合并感染时[1]。需要延长治疗的复杂感染动物应监测治疗反应和潜在并发症。

### Sources
[1] Canine infectious disease update (Proceedings): https://www.dvm360.com/view/canine-infectious-disease-update-proceedings
[2] Some Feline Respiratory Infections Can Cross Species Lines: https://www.dvm360.com/view/some-feline-respiratory-infections-can-cross-species-lines
[3] Kennel Cough - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/kennel-cough
[4] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals
