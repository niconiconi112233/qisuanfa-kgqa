# 伴侣动物的股骨颈骨折

股骨颈骨折是犬和猫中严重的骨科急症，由于可能导致包括缺血性坏死和永久性跛行在内的破坏性并发症，需要立即进行兽医干预。这些关节内损伤最常见于幼年动物的骨骺分离，但它们也可能在任何年龄因高能量创伤而发生。

本报告探讨了股骨颈骨折的全面兽医管理，涵盖了这些骨折带来的解剖学挑战、从急性无法负重跛行到年轻雄性猫双侧受累的各种临床表现，以及手术规划所需的关键诊断影像。分析包括详细的治疗方案，比较了使用无头空心螺钉的内固定技术与股骨头切除术，对功能恢复至关重要的康复策略，以及决定犬和猫长期预后的预后因素。

## 疾病概述与流行病学

股骨颈骨折是涉及犬和猫股骨头与股骨干之间狭窄区域断裂的骨科损伤 [1]。股骨颈由关节囊包裹的松质骨组成，是支撑股骨头在髋臼内的关键解剖结构 [1]。

**解剖学考量**
近端股骨包括股骨头和颈、大转子（臀肌附着点）、小转子（髂腰肌附着点）和转子下区域 [1]。股骨头和大部分股颈被包裹在髋关节囊内，因此这些骨折属于关节内损伤 [1]。

**发病率与人口统计学特征**
股骨颈骨折在未成熟犬中最常以骨骺骨折（Salter-Harris I型）的形式出现，是最常见的近端股骨骨折类型 [1]。一种特殊的病理形式影响2岁以下的雄性猫，称为干骺端骨病，可能表现为双侧性 [1]。在猫中，双侧股骨骨骺分离发生在12个月以上、超重的去势雄性猫中，称为猫骨骺发育不良综合征 [1]。一份病例报告记录了一只1.3岁去势雄性英国短毛猫因慢性跛行而发生双侧股骨骨骺骨折 [2]。

**常见原因**
主要原因包括车辆创伤和其他高能量撞击 [1]。病理性骨折继发于潜在疾病，特别是在年轻雄性猫中，肥胖和早期去势是易感因素 [1][2]。骨骺通常在犬6-9个月和猫7-10个月时闭合 [1]。

### Sources
[1] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[2] Anesthesia Case of the Month in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/260/6/javma.21.05.0255.xml

## 临床表现与诊断方法

股骨颈骨折通常表现为急性发作的严重后肢跛行，患犬拒绝在患肢上负重 [1]。犬常表现出患肢缩短的外观并以异常姿势支撑患腿 [2]。由于废用，患肢的肌肉萎缩发展迅速，特别是在大腿肌肉 [1]。

体格检查显示在操作髋关节时有剧烈疼痛、捻发音和活动范围受限 [2]。犬可能表现出患肢外旋的特征性姿势。关节积液和髋关节周围的软组织肿胀可能可触及。

**诊断影像**对于确认诊断和手术规划至关重要。标准正交X线片（腹背位和侧位视图）仍然是主要的诊断工具 [3]。影像学发现包括股骨颈连续性中断、骨碎片移位以及潜在的并发髋部病变。计算机断层扫描（CT）等先进影像学技术为复杂骨折和手术规划提供了更优的细节 [2]。

股骨颈骨折的**分类**需考虑骨折位置、移位情况和患者年龄。骨骺骨折在幼犬中代表Salter-Harris I型损伤，而真正的股骨颈骨折则发生在颈部本身 [4]。多个平行的克氏针为两种骨折类型提供了最佳稳定性 [1][4]。

**鉴别诊断**包括髋关节发育不良、Legg-Calvé-Perthes病（特别是在玩具品种中）、创伤性髋关节脱位以及其他急性后肢跛行的原因 [2][5]。在幼犬中，应考虑股骨头骨骺滑脱。在年轻雄性猫中，病理性股骨颈骨折可继发于干骺端骨病 [4]。

### Sources
[1] The use of fully threaded headless cannulated screws for: https://avmajournals.avma.org/view/journals/ajvr/85/10/ajvr.24.05.0133.xml
[2] Severely comminuted femoral fractures (Proceedings): https://www.dvm360.com/view/severely-comminuted-femoral-fractures-proceedings
[3] Assessment and management of pelvic fractures in dogs: https://www.dvm360.com/view/assessment-and-management-pelvic-fractures-dogs-and-cats-proceedings
[4] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[5] Idiopathic arteriopathy-induced focal osteonecrosis of the: https://avmajournals.avma.org/view/journals/javma/257/9/javma.257.9.937.xml

## 治疗方案与手术管理

小动物的股骨颈骨折需要仔细评估以确定最佳治疗方法。对于年轻患者的稳定、轻微移位骨折，可考虑保守治疗，但大多数病例需要手术干预 [1]。

**手术治疗方案**
主要手术选择包括使用针或螺钉进行内固定与股骨头颈切除术（FHO）。最新研究表明，全螺纹无头空心螺钉在股骨颈骨折的内固定治疗中显示出良好的效果 [1,6]。多个小针（克氏针）或螺钉必须放置在股骨颈内，由于该部位受力大，解剖复位至关重要 [4]。任何程度的复位不良导致的运动都会引起微动和不愈合，最终导致植入物失败 [4]。

大多数兽医外科医生主张将FHO作为首选治疗方法，在适当选择的病例中取得了优异的临床效果 [1]。治疗包括手术切除患侧股骨头和颈，并配合早期术后物理治疗以刺激患肢使用 [6]。恢复预后极佳 [6]。

**决策因素**
治疗方案的选择取决于患者年龄、骨折稳定性、骨质量和主人期望 [1]。患者大小显著影响结果，小型犬通常比大型犬获得更好的功能结果 [2]。

**术后护理与康复**
即时术后管理侧重于使用围手术期镇痛药（包括硬膜外吗啡、麻醉药皮肤贴剂和非甾体抗炎药）进行疼痛控制 [9]。应在前三天每天应用冷疗4-5次 [2]。物理治疗对临床恢复至关重要，必须包括早期被动活动范围练习，以防止关节挛缩 [4,9]。

### Sources
[1] Juvenile bone and joint diseases: large dogs, rear legs: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-rear-legs-and-small-dogs-proceedings
[2] Rehabilitation of canine athletes (Proceedings): https://www.dvm360.com/view/rehabilitation-canine-athletes-proceedings
[3] Severely comminuted femoral fractures (Proceedings): https://www.dvm360.com/view/severely-comminuted-femoral-fractures-proceedings
[4] Fully threaded headless cannulated screws provide similar ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.03.0104/ajvr.25.03.0104.xml
[5] Aseptic Necrosis of the Femoral Head in Dogs - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/aseptic-necrosis-of-the-femoral-head-in-dogs
[6] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats

## 预后与结果

伴侣动物股骨颈骨折的预后因治疗方法、患者年龄和骨折特征而有显著差异 [1][2]。对于手术修复的股骨颈骨折，当实现稳定固定时，大多数动物预期功能恢复 [3]。各种手术技术的成功率从65%到100%不等，关节囊缝合术显示83-90%的成功率 [2]。

年龄是关键的预后因素。受伤时小于5个月的动物面临更大的髋部畸形和退变风险，因为股骨头和颈的生长不完全 [3]。到5个月大时，80%的股骨头和颈生长已完成，这使得年轻动物更适合进行股骨头切除术而非骨折修复 [3]。

常见并发症包括股骨头缺血性坏死，这可能在创伤后发生并影响愈合 [2][6]。固定不当可能导致不愈合 [3]。再脱位是不同手术稳定技术中最常见的并发症 [2]。

长期结果取决于治疗时机和方法。在4-5天内进行早期手术干预可优化结果 [2]。与大型犬相比，小型犬通过股骨头切除术通常显示出更好的功能结果，而大型犬的恢复可能不太理想 [2]。无论采用何种治疗方法，都可能预期出现不同程度的退行性关节病 [2]。

### Sources
[1] Acute canine coxofemoral disease and chronic: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0272/javma.25.04.0272.pdf
[2] Canine craniodorsal hip luxation: Management and treatment: https://www.dvm360.com/view/canine-craniodorsal-hip-luxation-management-and-treatment
[3] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[4] Surgery STAT: Micro total hip replacement for cats and: https://www.dvm360.com/view/surgery-stat-micro-total-hip-replacement-cats-and-small-dogs
[5] Teach clients about feline weight loss: https://www.dvm360.com/view/teach-clients-about-feline-weight-loss
[6] Aseptic Necrosis of the Femoral Head in Dogs: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/aseptic-necrosis-of-the-femoral-head-in-dogs
