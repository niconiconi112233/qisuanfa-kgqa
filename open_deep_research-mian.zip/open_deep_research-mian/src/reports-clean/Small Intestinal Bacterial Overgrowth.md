# 伴侣动物小肠细菌过度生长

小肠细菌过度生长（SIBO），现在更准确地称为抗生素反应性腹泻（ARD）或小肠菌群失调，是影响犬猫的一种重要胃肠道疾病。这种情况涉及正常肠道微生物群的破坏，导致慢性间歇性腹泻、吸收不良和营养缺乏。德国牧羊犬对此综合征表现出特别的易感性。

本综合报告探讨了SIBO在兽医实践中的病理生理学、诊断挑战和治疗方式。关键主题包括从基于细菌培养的诊断转向临床反应模式、钴胺素和叶酸检测作为诊断指标的作用，以及使用益生元与传统抗生素治疗的新兴治疗方法。报告还讨论了鉴别诊断考虑因素，特别是区分SIBO与外分泌胰腺功能不全和炎症性肠病，同时强调了长期管理策略对最佳患者结果的重要性。

## 疾病概述

小肠细菌过度生长（SIBO）定义为小肠内不利细菌的扩张[1]。该病症现在更准确地称为抗生素反应性腹泻（ARD）或小肠菌群失调，反映了导致临床症状的小肠微生物群复杂的定性和定量紊乱[1][2]。

SIBO/ARD代表了正常肠腔微生物群的紊乱，这可能是原发性的，也可能是继发于外分泌胰腺功能不全等潜在疾病[3]。该综合征常见于年轻的大型犬种，德国牧羊犬明显过度代表[2][6]。这种品种易感性可能反映了异常的微生物-粘膜相互作用和小肠粘膜表面IgA分泌缺陷[7]。

发病机制涉及防止细菌过度生长的正常保护机制的破坏，包括胃酸分泌、肠道蠕动和胰液的抗菌特性[1][2]。风险因素包括饮食变化、抗生素使用、免疫抑制以及影响胃肠道功能的并存疾病[1][4]。在猫中，SIBO从未被明确识别，尽管继发性小肠菌群失调伴随各种肠道疾病发生[6]。

### Sources
[1] Small intestinal dysbiosis (Proceedings): https://www.dvm360.com/view/small-intestinal-dysbiosis-proceedings
[2] Antibiotic-responsive diarrhea in dogs (Proceedings): https://www.dvm360.com/view/antibiotic-responsive-diarrhea-dogs-proceedings
[3] Exocrine pancreatic insufficiency in dogs and cats in: https://avmajournals.avma.org/view/journals/javma/262/2/javma.23.09.0505.xml
[4] Bacterial diarrhea and related public health concerns (Proceedings): https://www.dvm360.com/view/bacterial-diarrhea-and-related-public-health-concerns-proceedings
[5] Inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings-0
[6] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[7] Decoding chronic enteropathy in canine patients: https://www.dvm360.com/view/decoding-chronic-enteropathy-in-canine-patients

I notice that all the provided source material relates to human medicine rather than veterinary medicine. The sources discuss human SIBO, Mayo Clinic human medical information, and human medications. Since this report specifically requires veterinary information about Small Intestinal Bacterial Overgrowth in companion animals (dogs and cats), I cannot use these human medical sources to write the veterinary section.

The existing section content already provides comprehensive veterinary information about bacterial pathogens in SIBO for dogs and cats, sourced from appropriate veterinary references including the Merck Veterinary Manual and veterinary journals. 

Since the provided source material is not relevant to veterinary medicine, I will maintain the existing section content as it already covers the required topic with appropriate veterinary sources.

## 常见病原体

小肠细菌过度生长（SIBO）涉及小肠内细菌数量的异常增加，破坏了正常的微生物生态系统。在健康的犬猫中，小肠内的细菌浓度通常较低，计数低于10^5菌落形成单位/毫升[1]。

SIBO中的致病机制涉及细菌活性而非特定病原体。细菌通过胆汁盐去结合、脂肪酸羟基化以及竞争钴胺素和其他维生素等营养物质导致吸收不良[1]。这种细菌对正常消化过程的干扰导致了SIBO的特征性临床症状。

十二指肠液的定量细菌培养历来被认为是诊断的金标准，尽管在明显健康的犬中可能发现超过10^5总菌落形成单位/毫升或10^4专性厌氧菌落形成单位/毫升的细菌计数[1]。区分正常和病理性细菌群体的确切阈值在兽医专家中仍有争议。

继发性小肠菌群失调通常伴随SIBO发生，代表了肠道微生物群的更广泛破坏[1]。许多细菌种类可以通过竞争这种必需维生素导致钴胺素缺乏，使血清钴胺素测量成为有用的诊断指标，尽管它无法区分细菌消耗和吸收受损[2]。

### Sources

[1] Merck Veterinary Manual Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[2] Diagnosing intestinal dysbiosis: https://www.dvm360.com/view/diagnosing-intestinal-dysbiosis

## 临床症状和体征

小肠细菌过度生长（SIBO）表现为慢性小肠腹泻，其特征是间歇性[1]。这种腹泻模式与急性感染性原因不同，有助于将SIBO与其他胃肠道疾病区分开来。在某些情况下可能出现体重减轻，特别是当吸收不良变得严重时[1]。

典型的临床表现包括慢性腹泻、体重减轻和食欲改变（厌食或多食）[4]。许多受影响的犬尽管体重逐渐减轻但仍保持旺盛的食欲，有时表现为食粪症和异食癖[4]。重要的是，大量患有吸收不良性小肠疾病的犬猫尽管存在严重的肠道病理，但粪便正常，尤其是猫比犬更好地保存水分[1]。

临床症状包括慢性间歇性腹泻，如果病情持续，还会出现体重减轻[2]。患者还可能表现出由导致细菌过度生长的基础疾病过程引起的额外临床症状[2]。德国牧羊犬似乎特别易患抗生素反应性腹泻，这是一种与SIBO密切相关的疾病[5]。血清叶酸浓度升高和钴胺素浓度同时升高支持SIBO的存在，这在外分泌胰腺功能不全的犬中有47%被报告[3]。

### Sources
[1] IBD is not the most common GI problem (Proceedings): https://www.dvm360.com/view/ibd-not-most-common-gi-problem-proceedings
[2] Diagnosing intestinal dysbiosis: https://www.dvm360.com/view/diagnosing-intestinal-dysbiosis
[3] Canine EPI: Concurrent and secondary diseases: https://www.dvm360.com/view/canine-epi-concurrent-and-secondary-diseases
[4] Antibiotic-responsive diarrhea in dogs (Proceedings): https://www.dvm360.com/view/antibiotic-responsive-diarrhea-dogs-proceedings
[5] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 诊断方法

诊断犬的小肠细菌过度生长（SIBO）需要系统的方法，结合临床表现评估、实验室测试和专业诊断方法。SIBO诊断的金标准传统上是通过内窥镜或剖腹术获得的十二指肠液的定量细菌培养[1]。然而，这种方法具有挑战性、昂贵且需要专业实验室专业知识，使其不适用于常规临床使用[2]。

**实验室检测**

血清钴胺素和叶酸浓度作为SIBO有价值的初步诊断指标。患有SIBO的犬通常表现为血清钴胺素浓度降低和血清叶酸浓度升高[1]。这种模式源于细菌对钴胺素的竞争和细菌产生叶酸。然而，这些变化并不高度敏感，只有50%的SIBO犬显示叶酸升高，25%显示钴胺素降低[2]。两种异常的组合对SIBO诊断具有高度特异性但敏感性低[2]。

**临床评估**

SIBO越来越多地通过临床反应模式而非特定测试来识别。该病症现在通常被称为"抗生素反应性腹泻"，反映了对治疗反应的诊断依赖[4]。临床表现通常包括慢性小肠腹泻，通常是间歇性的，某些情况下可能出现体重减轻[4]。

**影像学和其他方法**

腹部超声可能揭示与潜在易感条件相关的发现，但对SIBO诊断没有特异性发现[4]。普通X光片同样显示低诊断率，除非存在并发症[1]。其他非侵入性诊断测试，如血清未结合胆汁酸浓度、呼气氢浓度以及13C-木糖和13C-胆汁酸测试，尚未被证明对诊断有一致的用途[5]。

### Sources
[1] Workup of dogs with chronic diarrhea: https://www.dvm360.com/view/workup-dogs-with-chronic-diarrhea-basics-proceedings
[2] Small intestinal dysbiosis (Proceedings): https://www.dvm360.com/view/small-intestinal-dysbiosis-proceedings
[3] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[4] Diagnostic approach to diarrhea (Proceedings): https://www.dvm360.com/view/diagnostic-approach-diarrhea-proceedings
[5] Antibiotic-responsive diarrhea in dogs (Proceedings): https://www.dvm360.com/view/antibiotic-responsive-diarrhea-dogs-proceedings

## 治疗选择

小肠细菌过度生长的治疗采用多模式方法，结合药物干预、饮食管理和支持性护理[1]。泰乐菌素是首选抗生素，剂量为25 mg/kg口服每12小时一次，持续6周[1]。替代抗生素包括甲硝唑（10-20 mg/kg，口服，每12小时一次）[4]。

饮食管理在治疗成功中起着关键作用。益生元，特别是饮食中1%的低聚果糖（FOS），与单独使用抗生素相比显示出持续益处[2]。FOS补充饮食显示出较慢起效但粪便一致性持续改善，而抗生素效果快速但在停药后短暂[2]。

益生菌作为有价值的辅助治疗，有助于恢复正常的肠道微生物群[1]。推荐高消化率饮食或水解蛋白饮食以获得最佳营养同化[6]。

维生素补充至关重要，特别是对水平低于正常的患者进行钴胺素（维生素B12）补充。当血清浓度低时，需要肠外钴胺素补充（每周皮下注射500 μg）[3,4]。

基础疾病的管理对治疗成功至关重要。患有外分泌胰腺功能不全的犬需要酶补充[1,4]。一些患者可能需要延长或终身的抗菌治疗，特别是那些在停用抗生素后临床症状复发的患者[1]。

### Sources

[1] Small intestinal dysbiosis (Proceedings): https://www.dvm360.com/view/small-intestinal-dysbiosis-proceedings
[2] Iams Nutrition Insider for the Veterinary Team: https://www.dvm360.com/view/iams-nutrition-insider-veterinary-team-comparing-prebiotics-and-antibiotics-treating-sibo-dogs-spons
[3] Tips to treat persistent cases of chronic diarrhea in pets: https://www.dvm360.com/view/tips-treat-persistent-cases-chronic-diarrhea-pets-sponsored-nestle-purina
[4] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[5] The latest insights on inflammatory bowel disease: https://www.dvm360.com/view/iams-nutrition-insider-latest-insights-inflammatory-bowel-disease-sponsored-iams
[6] Malabsorption Syndromes in Small Animals (AU): https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 预防措施

预防小肠细菌过度生长需要多方面的方法，针对潜在的易感条件，维持肠道健康，并实施适当的饮食策略[1][2]。

**饮食管理和肠道健康**
低脂肪和低纤维含量的高消化率饮食有助于减少细菌过度生长的底物可用性[3]。益生元补充，特别是低聚果糖（FOS），通过促进有益细菌同时抑制病原菌种类提供显著的预防益处[1][2]。临床研究表明，与抗生素治疗相比，FOS补充饮食提供粪便一致性的持续改善，而抗生素显示出快速但短暂的效果[1]。这些益生元产生支持肠粘膜健康和创造抗炎条件的短链脂肪酸[2]。

**处理易感条件**
预防涉及识别和管理导致SIBO易感的基础疾病。定期监测钴胺素水平至关重要，因为缺乏通常伴随肠道菌群失调发生并需要肠外补充[3][7]。通过常规粪便检查和适当的驱虫方案进行适当的寄生虫控制有助于预防继发性细菌过度生长[9]。

**环境和医疗考虑**
谨慎使用抗生素至关重要，因为不适当或延长的抗生素治疗可能破坏正常的肠道微生物群并促进菌群失调[7]。定期健康监测，包括评估血清叶酸和钴胺素浓度，能够及早发现小肠功能障碍[7]。减少压力和保持稳定的喂养常规也有助于支持最佳胃肠道功能和微生物平衡。

### Sources
[1] Iams Nutrition Insider for the Veterinary Team: https://www.dvm360.com/view/iams-nutrition-insider-veterinary-team-comparing-prebiotics-and-antibiotics-treating-sibo-dogs-spons
[2] For the Veterinary Team: Understanding the benefits of prebiotics: https://www.dvm360.com/view/veterinary-team-understanding-benefits-prebiotics-sponsored-iams
[3] Dietary management of GI diseases in dogs and cats: https://www.dvm360.com/view/dietary-management-gi-diseases-dogs-and-cats-proceedings
[7] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[9] Tips to treat persistent cases of chronic diarrhea in pets: https://www.dvm360.com/view/tips-treat-persistent-cases-chronic-diarrhea-pets-sponsored-nestle-purina

## 鉴别诊断

SIBO必须与其他引起相似胃肠道症状的疾病区分开来。关键鉴别诊断包括外分泌胰腺功能不全（EPI）、炎症性肠病（IBD）和寄生虫感染[1]。

**外分泌胰腺功能不全（EPI）**是一个重要的鉴别诊断，因为它经常导致继发性细菌过度生长。EPI表现为消化不良、尽管多食但体重减轻、以及大量、苍白的粪便[1]。区分EPI和原发性SIBO需要血清胰蛋白酶样免疫反应性（TLI）测试，这对胰腺功能具有高度敏感性和特异性[2]。

**炎症性肠病（IBD）**与SIBO有许多共同的临床特征，包括慢性腹泻、体重减轻和吸收不良。两种疾病都可能导致低钴胺素血症和血清叶酸浓度改变[1]。然而，IBD通常需要通过肠活检进行组织病理学确认，而SIBO可能对抗生素治疗有反应而无需侵入性诊断。

**寄生虫感染**，特别是贾第鞭毛虫，必须通过使用多个样本和专业技术（如硫酸锌漂浮或ELISA测试）的综合粪便检查来排除[2]。与SIBO不同，寄生虫感染通常通过适当的抗寄生虫治疗完全解决。

**区分因素**包括对特定治疗的反应：SIBO通常对甲硝唑等抗生素迅速反应，而EPI需要胰腺酶替代治疗，IBD可能需要免疫抑制药物[1][2]。此外，钴胺素缺乏伴正常或升高的叶酸水平可能提示SIBO，而EPI通常由于细菌对内因子的竞争导致钴胺素水平降低[2]。

### Sources
[1] Inflammatory bowel disease: Diagnostic and treatment approaches: https://www.dvm360.com/view/inflammatory-bowel-disease-diagnostic-and-treatment-approaches-proceedings
[2] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 预后

犬猫小肠细菌过度生长（SIBO）的预后因基础原因和治疗反应而有显著差异[1]。大多数患有抗生素反应性肠病（ARE）（以前称为SIBO的首选术语）的动物在实施适当治疗时显示出良好的初始临床改善[1]。

接受益生元补充的犬显示出与抗生素治疗相当的疗效，值得注意的是，用益生元治疗的动物在完成治疗后没有复发，而许多单独用抗生素治疗的犬则复发[1]。这表明益生元通过预防临床复发可能提供优越的长期结果。

然而，SIBO/ARE的复发很常见。患有这种疾病的犬似乎复发更频繁，特别是在停用抗生素治疗后[2]。允许共生细菌引起临床症状的宿主防御机制的基础缺陷不太可能消失，这意味着受影响的动物通常需要持续管理[3]。

长期预后取决于通过饮食调整、抗菌治疗或微生物群调节实现持续缓解的能力。对治疗反应良好的动物，这种疾病通常可以被控制而不是治愈，需要主人理解这些结果之间的区别[3]。需要终身管理的可能性各不相同，一些患者需要间歇性治疗，而其他患者需要更持续的治疗干预。

### Sources
[1] For the Veterinary Team: Understanding the benefits of prebiotics (Sponsored by Iams): https://www.dvm360.com/view/veterinary-team-understanding-benefits-prebiotics-sponsored-iams
[2] Decoding chronic enteropathy in canine patients: https://www.dvm360.com/view/decoding-chronic-enteropathy-in-canine-patients
[3] IBD is not the most common GI problem (Proceedings): https://www.dvm360.com/view/ibd-not-most-common-gi-problem-proceedings
