# 伴侣动物牙周炎：综合临床指南

牙周炎是影响伴侣动物最常见的健康问题，高达80%的狗和70%的猫在两岁时会发展出某种程度的牙周疾病。这种进行性细菌感染会破坏牙齿支持结构，从可逆的牙龈炎发展到伴有永久性骨丢失的不可逆牙周炎。小型犬面临特别高的风险，与大型犬相比，发展成严重疾病的可能性高达五倍。除了口腔表现外，牙周炎还会导致系统性健康后果，包括心脏并发症、肾脏损伤和加速衰老过程的慢性炎症。本报告为兽医从业者提供了基于证据的方法，用于诊断、分期、治疗和预防犬猫牙周炎，强调了专业牙科护理和客户教育在管理这种普遍但可预防疾病中的关键重要性。

## 摘要

伴侣动物的牙周炎从牙菌斑积累发展到牙齿支持结构的不可逆破坏，影响大多数两岁以下的犬猫。由于牙齿拥挤和遗传因素，小型犬面临不成比例的高风险。这种疾病不仅限于口腔病理，还会导致系统性并发症，包括心脏损伤、肾功能损害和加速衰老过程的慢性炎症。

麻醉下的专业牙科清洁仍然是诊断和治疗的金标准，全口X光片对于准确分期至关重要。治疗成功取决于疾病阶段和主人对家庭护理方案的依从性。

| 疾病分期 | 预后 | 治疗重点 |
|---------------|-----------|-----------------|
| 第1阶段（牙龈炎） | 优秀 - 可逆 | 专业清洁 + 家庭护理 |
| 第2-3阶段（早期-中度） | 良好到谨慎 | 洁治、根面平整、抗菌剂 |
| 第4阶段（晚期） | 保留预后差 | 通常需要拔牙 |

通过每日刷牙、经VOHC批准的牙科饮食和定期专业清洁进行预防，提供了最有效的长期管理策略。早期干预和客户教育对于优化伴侣动物的治疗结果和维持系统性健康仍然至关重要。

## 疾病概述与流行病学

牙周病是一种由牙菌斑引起的炎症性疾病，影响牙周组织--围绕和支持牙齿的组织，包括牙槽骨、牙骨质、牙周韧带和牙龈[1]。疾病从可逆的牙龈炎（炎症仅限于牙龈）发展到涉及更深组织破坏和永久性骨丢失的不可逆牙周炎[1]。

牙周病是影响伴侣动物最常见的健康问题。在美国，20.5%的狗和24.2%的猫出现牙结石，而19.5%的狗和13.1%的猫患有牙龈炎[2]。高达70%的猫和80%的狗在2岁时会发展出某种程度的牙周病[1]。

小型犬面临不成比例的高风险，超小型品种（<6.5公斤）发展牙周病的可能性比巨型品种（>25公斤）高达5倍[3]。大多数5岁以上的狗有显著的牙周炎[4]。其他风险因素包括年龄增长、超重、糖尿病等免疫抑制状况、营养状况不良以及导致菌斑滞留表面的咬合不正[1]。

有一些证据表明，软质食物饮食可能与犬猫牙周病的发生频率和严重程度增加相关[2]。

### Sources

[1] Periodontal Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[2] The importance of feline oral health (Proceedings): https://www.dvm360.com/view/importance-feline-oral-health-proceedings
[3] Teeth troubles in tiny dogs: https://www.dvm360.com/view/teeth-troubles-in-tiny-dogs
[4] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings

## 发病机制与临床表现

现有内容全面涵盖了牙周病发病机制中涉及的细菌转变和炎症通路。在此基础上，牙周病原体产生的额外挥发性硫化合物显著导致口臭，而这些化合物也可能损害组织屏障完整性，促进内毒素渗透和系统性菌血症[4]。

牙周病的系统性影响超出了口腔表现。牙周袋中的细菌可进入血液循环，可能导致心脏组织损伤和心内膜炎，研究表明口腔菌血症与脑或心肌梗死之间存在联系[6]。当细菌损害肾小球膜时会出现肾脏并发症，影响肾功能，而肝脏受累可导致功能性肝变化[6]。

慢性牙周炎症导致"炎症性衰老"，这是一种与年龄相关疾病相关的低度全身性炎症状态[10]。这一过程涉及炎症标志物增加、免疫衰老和氧化损伤，可能加速全身病理变化[5]。炎症级联反应导致组织损伤后炎症消退缓慢，这在老年患者中尤其成问题[5]。

临床分期对于治疗规划仍然至关重要，四期系统有效指导治疗决策。然而，从业者应认识到，即使是幼年小型犬的第1阶段牙龈炎也可能迅速进展，一些约克夏梗和马耳他犬在九个月大时就需要拔牙[8]。这种疾病的隐匿性意味着猫可能在明显的口腔体征出现之前表现出行为上的细微变化，如梳理减少或社交互动减少[3]。

### Sources

[1] Periodontal Disease in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals

[2] Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics

[3] Focus on feline dental care and its effect on overall health: https://www.dvm360.com/view/focus-feline-dental-care-and-its-effect-overall-health-roundtable-discussion-sponsored-greenies

[4] Current best practices for diagnosis, treatment, and prevention of halitosis in cats: https://www.dvm360.com/view/current-best-practices-for-diagnosis-treatment-and-prevention-of-halitosis-in-cats/1000

[5] Dental Pain and Inflammation-Acute and Chronic: https://www.dvm360.com/view/dental-pain-and-inflammation-acute-and-chronic

[6] How periodontal disease can affect pets' organs: https://www.dvm360.com/view/how-periodontal-disease-can-affect-pets-organs

## 诊断方法

牙科X光摄影仍然是伴侣动物牙周炎诊断的最重要诊断工具[1]。美国兽医牙科学院（AVDC）建议每位牙科患者进行全口X光检查，以检测口腔检查中可能遗漏的病理变化[2]。

全身麻醉下的牙周探诊对于准确评估至关重要[3]。CP-15 UNC探针（带毫米刻度）适用于狗，而Williams探针（刻度在1、2、3，然后5、7、8、9和10毫米处）推荐用于猫[3]。正常龈沟深度在狗中为1-3毫米，在猫中为0.5-1毫米[4]。探诊应包括每颗牙齿周围至少六个点，以确保全面评估[3]。

临床附着水平比单独的探诊深度具有更大的诊断意义[4]。这一测量结合了袋深度和牙龈退缩，通过测量从釉牙骨质界到袋底的距离来确定[4]。锥形束计算机断层扫描和传统CT等先进成像模式为复杂牙周病变提供了优越的三维可视化[2]。

硫醇试条在视觉检查困难时（特别是在幼年动物中）提供了检测感染的宝贵诊断工具[5]。阳性结果表明需要专业牙科清洁的细菌感染，而阴性结果可以被视为预防成功的标志[5]。

### Sources
[1] CVC Highlights: Simple steps to proper periodontal probing: https://www.dvm360.com/view/cvc-highlights-simple-steps-proper-periodontal-probing
[2] Day one core competencies in veterinary dentistry: https://avmajournals.avma.org/view/journals/javma/261/12/javma.23.05.0242.xml
[3] Dental probes and explorers-musts for examination: https://www.dvm360.com/view/dental-probes-and-explorers-musts-examination
[4] The ABCs of veterinary dentistry: P is for periodontal pockets: https://www.dvm360.com/view/abcs-veterinary-dentistry-p-periodontal-pockets
[5] Strengthening oral health: A call to action for veterinary practices: https://www.dvm360.com/view/strengthening-oral-health-a-call-to-action-for-veterinary-practices

## 治疗策略与预防

全身麻醉下的专业牙科清洁是牙周治疗的基石[1]。治疗包括龈上和龈下洁治、根面平整、抛光和牙周探诊[2,3]。对于超过5毫米的牙周袋，开放翻瓣刮治术提供更好的可视化和对病变根表面的接触[3]。

手术干预包括牙龈增生的牙龈切除术、深袋的开放翻瓣手术以及使用骨移植材料的引导组织再生[2,6]。晚期病例可能需要牙周瓣手术，如根向复位瓣或侧向定位带蒂瓣[6]。

使用牙周药物（多西环素制剂）的抗菌治疗可直接放入4毫米或更深的牙周袋中[2]。全身性抗生素如克拉维酸适用于中重度牙周炎，通常在围手术期给予2-10天[2]。疼痛管理包括术前镇痛、区域神经阻滞和术后非甾体抗炎药[2]。

预防重点是每日家庭护理，包括使用批准的洁牙剂刷牙、有VOHC印章批准的牙科饮食、饮水添加剂和口腔漱口剂[2,7]。应每年安排或根据临床指征安排专业牙科清洁[7]。虽然目前没有针对牙周炎的特定疫苗，但整体预防护理和早期干预显著影响疾病进展[7]。

### Sources
[1] Journal of the American Veterinary Medical Association Prophylactic antibiotic use is common in dogs and cats presenting for procedures at veterinary referral dental practices: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.08.0524.xml
[2] DVM 360 An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings
[3] Merck Veterinary Manual Periodontal Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[4] DVM 360 Potential breakthrough in periodontal disease treatment gel: https://www.dvm360.com/view/potential-breakthrough-in-periodontal-disease-treatment-gel
[5] DVM 360 Stages of periodontal disease (Proceedings): https://www.dvm360.com/view/stages-periodontal-disease-proceedings
[6] DVM 360 Advanced dental procedures for pets: What's possible?: https://www.dvm360.com/view/advanced-dental-procedures-for-pets-what-s-possible
[7] DVM 360 Strengthening oral health: A call to action for veterinary practices: https://www.dvm360.com/view/strengthening-oral-health-a-call-to-action-for-veterinary-practices

## 鉴别诊断与预后

**鉴别诊断**

牙周炎必须与几种具有相似临床表现的口腔疾病进行鉴别。猫口腔炎是一个关键的鉴别诊断，其特征是口腔后部粘膜炎症，特别是在腭舌褶外侧[1]。区分的典型特征是猫口腔炎涉及超出牙龈的广泛粘膜炎症，而牙周炎主要影响牙齿周围的牙周组织。

犬的慢性溃疡性牙周口腔炎（CUPS）表现为口腔粘膜上与牙齿接触区域相对应的"接吻性溃疡"[3]。与牙周炎不同，CUPS主要涉及软组织的淋巴-浆细胞性炎症，而不是牙齿支持结构的破坏。其他鉴别诊断包括口腔肿瘤、天疱疮等自身免疫性疾病、嗜酸性肉芽肿复合物以及尿毒症等全身性疾病引起的继发性口腔炎[2,5]。

**预后**

牙周炎的预后因疾病阶段和治疗方法而异。在狗中，如果早期诊断，牙周病对适当治疗反应良好[8]。第1阶段（牙龈炎）预后良好，通过专业清洁和家庭护理可以完全逆转。第2-3阶段预后良好到谨慎，取决于附着丧失的严重程度和主人对家庭护理的依从性。

第4阶段牙周炎对牙齿保留的预后较差，当附着丧失超过50%时通常需要拔牙[8]。然而，狗能很好地适应牙齿缺失并维持良好的生活质量。猫牙龈口腔炎的预后更为谨慎，全口拔牙后60%达到临床治愈，20%显示显著改善，但约20%对治疗仍然无效[5]。

### Sources
[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[2] Stomatitis in dogs and cats (Proceedings): https://www.dvm360.com/view/stomatitis-dogs-and-cats-proceedings
[3] Dental Corner: Diagnosing and treating chronic ulcerative paradental stomatitis: https://www.dvm360.com/view/dental-corner-diagnosing-and-treating-chronic-ulcerative-paradental-stomatitis
[4] Dental Corner: Feline gingivostomatitis: How to relieve the oral discomfort: https://www.dvm360.com/view/dental-corner-feline-gingivostomatitis-how-relieve-oral-discomfort
[5] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings
