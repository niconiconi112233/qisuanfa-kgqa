# 非梗阻性猫特发性膀胱炎

非梗阻性猫特发性膀胱炎（FIC）是猫下尿路疾病最常见的原因，约占10岁以下猫病例的60-70%。由于病因不明且一年内复发率超过50%，这种无菌性炎症性疾病对兽医临床医生提出了重大的诊断和治疗挑战。

本综合报告将FIC视为一种需要系统性评估和多模式管理方法的复杂疾病。涵盖的关键领域包括：以特征性出血性炎症为表现的发作性临床表现、对准确识别至关重要的排除性诊断方法，以及强调环境改造与药物干预相结合的循证治疗方案。报告还讨论了通过多模式环境改造（MEMO）实施的关键预防策略，成功实施后可将复发率从39%降至11%。

## 疾病概述

非梗阻性猫特发性膀胱炎（FIC）被定义为一种病因未确定的疾病，其特征为血尿、排尿困难、尿频和影响膀胱的无菌性炎症过程[1]。FIC是猫下尿路疾病（FLUTD）最常见的原因，约占10岁以下猫病例的60-70%[2,3]。

该疾病影响约1.5%就诊于初级保健兽医的猫[3]。主要影响年轻至中年猫，发病高峰在2-6岁之间[2,3]。雄性和雌性猫均可同等受累，但去势雄猫和绝育雌猫比完整猫显示出更高的风险[3,4]。

FIC存在两种临床形式：非梗阻性和梗阻性。非梗阻性表现为典型的下尿路症状而无尿道阻塞，而梗阻性主要发生在雄猫中，由尿道栓子形成引起[1]。风险因素包括室内生活方式、纯干粮饮食、肥胖、活动减少、多猫家庭以及各种环境应激因素[3,4]。该疾病通常呈发作性模式，急性发作，通常在5-7天内自行缓解，但复发常见且不可预测[1,2]。

### Sources

[1] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0

[2] Feline idiopathic cystitis: https://www.dvm360.com/view/feline-idiopathic-cystitis

[3] Diagnosing and managing idiopathic cystitis in cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings

[4] Nonobstructive idiopathic feline lower urinary tract disease: https://www.dvm360.com/view/nonobstructive-idiopathic-feline-lower-urinary-tract-disease-how-approach-puzzling-disorder

## 常见病原体

非梗阻性猫特发性膀胱炎本质上是一种无菌性炎症性疾病。大多数病例与细菌病原体无关，患有FIC的年轻猫中细菌性尿路感染发生率低于3%[1]。然而，在10岁以上的猫中，细菌性UTI更为常见，占病例的12%[1]。

**病毒参与**
虽然在一些患有FIC的猫中已鉴定出病毒颗粒，但其作用仍不清楚。疱疹病毒和杯状病毒已被研究作为潜在触发因素[1,3]。最近的研究在患有iFLUTD的猫中发现了新型猫杯状病毒，但其致病意义未知[1]。潜伏性疱疹病毒或杯状病毒感染可能在个别猫中起作用，可能作为炎症触发因素[1,3]。

**隐匿生物体**  
支原体和脲原体已被研究作为难以常规培养的潜在"隐匿生物体"[1]。然而，最近的PCR研究未能从复发性FIC猫的尿液样本中鉴定出这些生物体[1,6]。这表明这些生物体在大多数病例中不起重要的致病作用。

**临床意义**
FIC的无菌性质将其与细菌性膀胱炎区分开来。多项寻找感染病因的研究一致未能在大多数患有此病的年轻猫中鉴定出细菌生物体[1,3]。发作性模式和病毒颗粒发现最初提示病毒病因，但尚未证实明确的病毒病因[1,3]。

### Sources

[1] DVM360 Diagnosing and managing idiopathic cystitis in cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[2] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[3] DVM360 Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[4] DVM360 Feline idiopathic cystitis: What it is and how to diagnose in patients: https://www.dvm360.com/view/feline-idiopathic-cystitis-what-it-is-and-how-to-diagnose-in-patients
[5] DVM360 Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0
[6] DVM360 Nonobstructive idiopathic feline lower urinary tract disease: https://www.dvm360.com/view/nonobstructive-idiopathic-feline-lower-urinary-tract-disease-how-approach-puzzling-disorder

## 临床症状和体征

非梗阻性猫特发性膀胱炎表现为特征性的下尿路症状群。最常见的临床表现是异位排尿（不当排尿），在高达93%的受影响猫中出现[1]。典型的排尿症状包括排尿困难、血尿、尿频和排尿费力，这些共同代表了该疾病的标志性症状[1][2]。

血尿存在于约95%的病例中，可能是间歇性的，在数天之间甚至在同一天内波动[3]。尿频和排尿费力分别发生在79%和70%的病例中[3]。这些症状源于膀胱炎症和感觉神经活动增加引起的神经源性炎症。

非典型表现包括行为变化和过度梳理模式。一些猫表现出双侧腹股沟脱毛伴自体损伤，可能代表膀胱炎症的牵涉痛[4]。受影响的猫可能在排尿尝试时发声，并表现出增加的恐惧、紧张或攻击性行为[4]。尾部腹部毛发修剪偶尔发生，作为内脏牵涉痛的表现。

临床过程通常呈发作性，急性发作。大多数发作无论治疗如何都会在5-7天内自行缓解，但一年内复发率超过50%[5]。一些猫表现为慢性持续性症状，从未完全缓解，而其他猫则经历频繁复发发作，发作间隔从数天到数年不等。

### Sources
[1] Nonobstructive idiopathic feline lower urinary tract disease: How to approach a puzzling disorder: https://www.dvm360.com/view/nonobstructive-idiopathic-feline-lower-urinary-tract-disease-how-approach-puzzling-disorder
[2] The frustrations of FLUTD (Proceedings): https://www.dvm360.com/view/frustrations-flutd-proceedings
[3] Diagnosing and managing idiopathic cystitis in cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[4] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0
[5] Managing idiopathic cystitis in cats for successful outcomes--parts 1 and 2 (Proceedings): https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings

## 诊断方法

非梗阻性猫特发性膀胱炎（FIC）的诊断需要使用病史、体格检查和排除其他原因的系统方法[1]。FIC本质上是一种排除性诊断，需要最低限度的检查，包括完整的环境和饮食史、彻底的体格检查和尿液分析[1]。

**初步评估**
诊断需要排除已知的下尿路症状原因，特别是尿石症、细菌性UTI、肿瘤和解剖异常[3]。最低限度的诊断检查包括尿液分析、尿培养和腹部X光片[6]。临床检查可能发现盆腔器官疼痛、膀胱壁增厚或在活动发作期间特征性的小膀胱[3]。

**实验室检查结果**
尿液分析发现包括"出血性炎症"，以红细胞为主，少量中性粒细胞[4]。血尿和蛋白尿通常波动，甚至在同一天内[3]。新鲜样本中通常没有结晶尿，其存在对非梗阻性FIC无诊断意义[4]。食用干粮的猫尿比重通常超过1.035[4]。

**影像学研究**
建议对所有有复发性症状的猫进行尿路影像学检查[3]。普通X光片可识别射线可透性≥2-3mm的结石，而超声检查比造影检查提供更少侵入性的评估[4]。双重对比膀胱造影可能显示局灶性或弥漫性膀胱壁增厚、造影剂渗透或充盈缺损[1]。

**高级诊断**
膀胱镜检查提供膀胱直接可视化，显示血管密度增加、水肿和黏膜下点状出血（肾小球样改变），这些是FIC的特征[3]。

### Sources
[1] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[2] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings
[3] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[4] Non-obstructive idiopathic/interstitial cystitis in cats: https://www.dvm360.com/view/non-obstructive-idiopathicinterstitial-cystitis-cats-thinking-outside-litter-box-proceedings
[5] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0

## 治疗选择

非梗阻性猫特发性膀胱炎治疗采用多模式方法，针对疼痛、炎症、饮食因素、环境应激因素和神经源性机制[1]。

**药物干预**构成急性管理的基石。包括丁丙诺啡（5-20 mcg/kg 口服 每日2-4次）在内的镇痛药通过舌下吸收提供有效疼痛缓解[2]。抗炎药物如美洛昔康可谨慎使用低剂量（0.025 mg/kg 每周3-4次）进行长期管理[4]。抗痉挛药如苯氧苄胺（2.5-10 mg/猫 口服 每日）有助于放松雄猫尿道平滑肌[9]。阿米替林（5-12.5 mg/猫 口服 每日）在严重复发性病例中显示疗效，长期使用时60%的猫显示临床症状缓解，尽管短期使用益处最小[1][3]。

**饮食管理**主要集中在增加饮水量以达到尿比重低于1.030。罐头食品饮食与干粮相比显著降低复发率，18只食用罐头食品的猫中有16只保持无症状，而28只食用干粮的猫中有17只无症状[9]。含有抗焦虑成分的处方泌尿治疗饮食在减少FIC发作方面显示出统计学显著性[6]。

**环境改造**通过MEMO（多模式环境改造）代表最重要的长期干预措施。基于"健康猫环境的五大支柱"，MEMO通过适当的猫砂盆管理、资源可用性和丰富活动来解决压力减少问题[6][7]。研究表明，80%的复发性FIC猫在成功实施MEMO后显示出临床显著改善[1]。

**辅助治疗**包括合成猫面部费洛蒙（Feliway）用于压力管理和糖胺聚糖补充，尽管对照研究显示后者疗效有限[7][9]。

### Sources
[1] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[2] Adjunctive analgesic use for acute and chronic pain: https://www.dvm360.com/view/adjunctive-analgesic-use-acute-and-chronic-pain-proceedings
[3] Urinary tract pitfalls: https://www.dvm360.com/view/urinary-tract-pitfalls-proceedings
[4] Osteoarthritis in cats: https://www.dvm360.com/view/osteoarthritis-cats-proceedings
[5] Osteoarthritis in cats: What we now know about recognition and treatment: https://www.dvm360.com/view/osteoarthritis-cats-what-we-now-know-about-recognition-and-treatment
[6] Feline interstitial cystitis: Its not about the bladder: https://www.dvm360.com/view/feline-interstitial-cystitis-it-s-not-about-bladder
[7] Nonobstructive idiopathic feline lower urinary tract disease: https://www.dvm360.com/view/nonobstructive-idiopathic-feline-lower-urinary-tract-disease-how-approach-puzzling-disorder
[8] Feline idiopathic cystitis: https://www.dvm360.com/view/feline-idiopathic-cystitis
[9] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[10] CVC Highlight: How to think outside the litter box: https://www.dvm360.com/view/cvc-highlight-how-think-outside-litter-box-managing-cats-with-nonobstructive-idiopathic-interstitial

## 预防措施

非梗阻性猫特发性膀胱炎的预防以多模式环境改造（MEMO）为中心，以减少压力和环境触发因素[1]。健康猫环境的五大支柱形成基础：提供足够的空间和垂直领域、单独获取食物和水资源、适当的猫砂盆管理、玩耍和捕食行为的机会以及积极的人猫互动[1]。

猫砂盆管理至关重要，需要每只猫一个猫砂盆外加一个额外的、每日清理、无香味的结团猫砂，并放置在安静、可到达的位置且有逃生路线[1][2]。应通过罐头食品饮食、多个新鲜水源以及针对特定猫的碗类型和水流偏好的最大化饮水量[1]。环境丰富包括抓挠柱、攀爬结构、藏身处、互动玩具和喂食谜题，以模拟自然狩猎行为[2][3]。

压力减少侧重于通过单独的资源获取和视觉屏障管理猫间冲突，保持可预测的日常，并最小化家庭压力因素[1][4]。饮食修改强调高水分饮食以降低尿比重至1.030以下，并逐步过渡以避免额外压力[3][6]。

体重管理预防肥胖，这是FIC复发的重要风险因素[1]。通过一周、一个月，然后每三到六个月的随访访问进行定期监测，允许治疗调整和持续支持[5]。研究表明，成功实施MEMO在第一年内使约80%的复发性FIC猫临床症状减少[2]。

### Sources
[1] Feline idiopathic cystitis: https://www.dvm360.com/view/feline-idiopathic-cystitis
[2] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[3] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[4] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings
[5] Pandora syndrome: Rethinking our approach to idiopathic cystitis in cats: https://www.dvm360.com/view/pandora-syndrome-rethinking-our-approach-idiopathic-cystitis-cats
[6] Management of refractory inflammatory feline lower urinary tract disease: https://www.dvm360.com/view/management-refractory-inflammatory-feline-lower-urinary-tract-disease-proceedings-0

## 鉴别诊断

FIC的诊断需要排除已知的下尿路症状原因以建立准确的鉴别诊断[1]。在10岁以下的猫中，尿石症占10-20%的病例，大多数为草酸钙或鸟粪石结石[1][3]。结构异常如脐尿管憩室或尿道狭窄约占病例的10%[1]。

细菌性尿路感染在年轻猫中不常见，占不到2%的病例[1][3]。然而，在10岁以上的猫中，超过一半将患有细菌性UTI，通常与肾脏疾病和尿比重未达最大浓缩相关[1]。行为障碍约占年轻猫病例的10%[1]。

膀胱或尿道肿瘤罕见，在10岁以下猫中占不到1%的病例[1][3]。包括双重对比膀胱造影和超声检查在内的先进影像学技术有助于在普通X光片正常时识别射线可透性结石和解剖缺陷[2]。膀胱镜检查提供膀胱黏膜的极佳可视化，特别是在雌猫中[2]。

关键鉴别特征包括年龄相关的患病率模式，年轻猫以特发性原因为主（60-70%），而老年猫以感染性原因为主[1][3]。尿液分析显示"出血性炎症"，以红细胞为主，少量中性粒细胞，提示FIC而非细菌感染[2]。完整的诊断检查包括尿液分析、尿培养、CBC、生化面板、X光片和超声检查，对于正确鉴别至关重要[3][4]。

### Sources
[1] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[2] Non-obstructive idiopathic/interstitial cystitis in cats: https://www.dvm360.com/view/non-obstructive-idiopathicinterstitial-cystitis-cats-thinking-outside-litter-box-proceedings
[3] Diagnosing and managing idiopathic cystitis in cats: https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[4] Working up FLUTD: https://www.dvm360.com/view/working-flutd-proceedings

## 预后

非梗阻性猫特发性膀胱炎猫的预后对于急性发作通常有利，但特征为高复发可能性[1]。大多数猫无论治疗如何都会在5-7天内经历临床症状自发缓解[1][2]。然而，长期前景涉及管理具有发作性恶化的慢性疾病。

复发率显著影响预后，根据观察强度影响40-65%的猫[1]。在六个月内，约50-65%的受影响猫将经历另一次发作[2][3]。复发模式不可预测，猫在发作之间保持正常状态从数天到数年不等[2]。

几个因素影响预后和复发风险。环境压力、多猫家庭、纯干粮饮食和室内生活方式增加复发可能性[1][3]。急性发作频率随着猫年龄增长而趋于下降，这使猫特发性膀胱炎与人间质性膀胱炎区别开来[1]。

生活质量考虑包括室内污染的可能性，这是猫被遗弃到收容所的主要原因[3]。猫还可能发展影响泌尿系统以外其他器官系统的合并症[6]。

长期管理成功率通过多模式环境改造（MEMO）显著提高，约80%的猫在成功实施后的第一年内显示出临床症状显著减少[6]。饮食修改，特别是过渡到增加饮水量的罐头食品，可将复发率从39%降至11%[1]。

### Sources

[1] Idiopathic cystitis: Recurrence rates can impact almost half of patients: https://www.dvm360.com/view/idiopathic-cystitis-recurrence-rates-can-impact-almost-half-patients
[2] Idiopathic cystitis (Proceedings): https://www.dvm360.com/view/idiopathic-cystitis-proceedings-0
[3] Diagnosing and managing idiopathic cystitis in cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-idiopathic-cystitis-cats-proceedings
[4] Feline lower urinary tract disease (Proceedings): https://www.dvm360.com/view/feline-lower-urinary-tract-disease-proceedings
[5] Evaluation of the effects of stress in cats with idiopathic cystitis: https://avmajournals.avma.org/view/journals/ajvr/67/4/ajvr.67.4.731.xml
[6] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
