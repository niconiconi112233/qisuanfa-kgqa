# 犬胆囊黏液囊肿：全面临床综述

胆囊黏液囊肿已成为影响犬的最重要肝外胆道疾病之一，从2000年前鲜有报道的病症转变为如今常见的临床挑战。这种黏稠、富含黏蛋白的胆汁进行性积聚会引发危及生命的并发症，包括胆囊破裂和胆汁性腹膜炎。该病主要影响老年纯种犬，特别是设得兰牧羊犬、可卡犬和小型雪纳瑞，并与内分泌疾病和高脂血症密切相关。本报告探讨了兽医从业人员在管理这种"神秘而致命的疾病"时必须掌握的病理生理学、诊断方法、治疗策略和预后因素，强调了早期识别和适当手术干预的关键重要性。

## 疾病概述

胆囊黏液囊肿（GBM）的特征是在异常扩张的胆囊内进行性积聚黏稠、富含黏蛋白的胆汁[1]。该病涉及囊性黏膜增生，胆囊上皮细胞过度分泌黏液，形成可能延伸至胆囊管、肝管和胆总管的胶状物质[1][2]。

2000年之前，犬胆囊黏液囊肿很少被报道，但它们已成为肝外胆道疾病的最常见原因之一[2][3]。发病率似乎在不断上升，过去20年中有超过100篇PubMed索引的文献记录了这种"神秘而致命的疾病"[4]。

GBM主要影响老年犬（中位年龄9-10岁），无性别偏好[1][2]。设得兰牧羊犬、可卡犬和小型雪纳瑞表现出增加的品种易感性[1][2]。在设得兰牧羊犬和其他受影响的品种中已发现ABCB4磷脂转运蛋白的基因突变，表明存在不完全外显率的显性遗传模式[2][5]。

病理生理学涉及黏蛋白过度分泌，胆囊内容物以形成凝胶的黏蛋白（Muc5b和Muc5ac）为主[1]。脱水后，这些黏蛋白转变为GBM中特征性的胶状橡胶样物质[1]。胆囊进行性扩张导致缺血、坏死和潜在的破裂，引起危及生命的胆汁性腹膜炎[1]。

### Sources

[1] Canine Gallbladder Mucocele - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele

[2] Managing gallbladder mucoceles (Proceedings) - DVM 360: https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings

[3] An update on gallbladder mucoceles in dogs - DVM 360: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

[4] Diagnosis and management of gallbladder mucocele formation in dogs - JAVMA: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.12.0789/javma.24.12.0789.xml

## 常见病原体

胆囊黏液囊肿主要是非感染性疾病，涉及黏液积聚而非原发性病原体引起的疾病。然而，继发性细菌感染可能使黏液囊肿复杂化，并显著影响临床表现和预后。

大约9%至43%的胆囊黏液囊肿患犬会发生细菌感染[1]。这些感染通常是继发性并发症，而不是黏液囊肿形成的主要原因。细菌群体通常是多微生物的，以革兰氏阴性生物为主[1]。

最常见的分离细菌包括大肠杆菌，其次是肠杆菌属、肠球菌属和梭菌属[1]。其他可能从感染胆囊内容物中培养的生物包括各种革兰氏阴性厌氧菌[1]。根据最近的兽医文献，继发性细菌感染可能包括肠球菌属、葡萄球菌属、大肠杆菌和铜绿假单胞菌[2][3]。在胆汁培养中已记录到假中间型葡萄球菌甚至耐甲氧西林菌株[2]。

这些细菌被认为通过胆道系统从肠道上行，尽管血源性传播也是可能的[1]。胆囊黏液囊肿内的黏液可形成生物膜微环境，作为感染储存库[3]。

继发性细菌感染显著改变临床过程，通常导致更严重的全身性疾病、发热，并在胆囊破裂时增加脓毒性腹膜炎的风险[1]。通过胆囊穿刺术或手术获得的胆汁样本进行细菌培养和药敏试验，对于适当的抗菌药物选择至关重要[2]。

与许多传染病不同，胆囊黏液囊肿没有病毒或其他特定的病原性原因。该病代表了一种机械性梗阻和黏液积聚过程，可能继发感染。

### Sources
[1] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs
[2] Outcome of elective cholecystectomy for the treatment of gallbladder disease in dogs: https://avmajournals.avma.org/view/journals/javma/252/8/javma.252.8.970.xml
[3] Canine Gallbladder Mucocele - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele

## 临床症状和体征

胆囊黏液囊肿呈现可变的临床谱，从无症状到急性危及生命的疾病[1]。临床疾病平均持续时间约5天，但有些犬表现出模糊的发作性症状，包括食欲不振、呕吐和腹痛，可持续数月[1]。

最常见的临床症状按频率递减依次为呕吐、腹部不适、厌食或食欲减退、黄疸、呼吸急促、心动过速、多尿/多饮、发热、腹泻和腹部膨隆[1]。约77%的患者出现临床症状，约四分之一保持无症状[5][8]。进展到胆囊破裂的犬通常表现为腹痛、黄疸、心动过速、呼吸急促和发热[1]。

**品种易感性和人口统计学特征**

胆囊黏液囊肿主要影响中位年龄10岁的老年犬，无性别偏好[1]。该病对小型纯种犬有强烈的易感性，设得兰牧羊犬、可卡犬和小型雪纳瑞的比例过高[1][5][6]。在一项研究中，66%的胆囊疾病设得兰牧羊犬确诊为黏液囊肿[5]。

**体格检查结果**

最常见的体格检查异常包括腹痛和黄疸[5]。其他发现可能包括发热、腹部膨隆、呼吸急促和心动过速[1][6]。值得注意的是，一些胆囊黏液囊肿破裂的犬尽管在腹腔内可见自由移动的凝固黏液囊肿，但临床上可能表现正常[1]。无黄疸性胆囊破裂很少被描述，表现为急性发作的厌食、嗜睡和呕吐，无黄疸[2]。

### Sources
[1] Canine Gallbladder Mucocele - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele
[2] Allen Press Anicteric Gallbladder Rupture with Elevated Bile Acids in Abdominal Effusion in a Dog with Cholecystitis: https://meridian.allenpress.com/jaaha/article-abstract/58/3/146/481931/Anicteric-Gallbladder-Rupture-with-Elevated-Bile?redirectedFrom=fulltext
[3] Managing gallbladder mucoceles (Proceedings): https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings
[4] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

## 诊断方法

胆囊黏液囊肿诊断主要依赖腹部超声检查，超声检查显示特征性超声特征。典型表现为扩大的胆囊内含有不移动、非重力依赖性的黏液，具有独特的星状或细条纹模式，类似于"猕猴桃"或"车轮"外观[1]。这一关键发现将黏液囊肿与简单的胆汁淤积区分开来，后者保持可移动性和重力依赖性[2]。

术前诊断测试包括全血细胞计数、血清生化分析、尿液分析和凝血面板[4]。实验室异常通常包括碱性磷酸酶（ALP）、丙氨酸氨基转移酶（ALT）、γ-谷氨酰转移酶（GGT）升高，约一半有症状的犬出现血清总胆红素升高[3]。全血细胞计数通常显示炎症性白细胞象，而生化面板可能显示甘油三酯和胆固醇增加[3]。

临床评估侧重于识别非特异性症状，包括呕吐、厌食、嗜睡和腹痛，体格检查可能揭示黄疸和发热[2]。超声表现可能随着黏液囊肿从早期到成熟阶段的进展而变化，产生不同的"胆汁模式"[3]。关键诊断原则是在保持患者侧卧位约10分钟后观察胆囊内容物，评估重力依赖性沉降，这将可移动的胆汁淤积与不移动的黏液囊肿物质区分开来[3]。

### Sources

[1] Hepatic ultrasonography: diffuse and focal diseases (Proceedings): https://www.dvm360.com/view/hepatic-ultrasonography-diffuse-and-focal-diseases-proceedings
[2] On guard for hepatobiliary diseases in dogs: https://www.dvm360.com/view/guard-hepatobiliary-diseases-dogs
[3] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml
[4] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

## 治疗选择

胆囊切除术代表胆囊黏液囊肿管理的金标准，择期手术死亡率约为5%，而有症状病例为17-23%[1]。术前稳定包括广谱抗生素（根据培养结果调整）、维生素K1治疗（0.5-1.5 mg/kg皮下注射，每12小时一次，持续24-48小时）和液体疗法[2]。手术技术应包括胆囊切除术而非胆囊造口术、胆道冲洗以去除胶状物质，以及常规肝活检和需氧/厌氧培养[4]。

围手术期护理需要密切监测，因为存在包括胰腺炎、胆汁性腹膜炎和肺部并发症在内的重大并发症，这些是死亡的主要原因[3]。对于早期黏液囊肿的无症状患者，可考虑药物治疗，使用熊去氧胆酸（15 mg/kg每日一次）、S-腺苷甲硫氨酸（20-40 mg/kg每日一次）和水飞蓟素等肝保护剂[2][6]。然而，药物治疗效果不一，报告的中位生存期为1,340天，而手术治疗为1,802天[3]。

术后并发症频繁发生，高达75%的犬显示持续性肝酶升高，需要持续评估胆道梗阻、细菌感染或并发肝病[3]。

### Sources
[1] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml
[2] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs
[3] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml
[4] Managing gallbladder mucoceles (Proceedings): https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings
[5] Understanding laparoscopy in veterinary surgery: https://www.dvm360.com/view/understanding-laparoscopy-in-veterinary-surgery
[6] Update on hepatoprotective therapies (Proceedings): https://www.dvm360.com/view/update-hepatoprotective-therapies-proceedings

## 预防措施

胆囊黏液囊肿形成的预防主要侧重于管理基础易感条件和实施早期检测策略。内分泌疾病的管理至关重要，因为患有肾上腺皮质功能亢进的犬发展成黏液囊肿的可能性是未受影响犬的29倍[2]。甲状腺功能减退和肾上腺皮质功能亢进的治疗应优先考虑，因为这些情况导致胆囊运动障碍和胆汁成分改变[1,3]。

饮食调整包括转向低脂饮食和停止高脂喂养方案，因为高脂血症是一个重要的风险因素[1,3]。应尽可能减少皮质类固醇给药，特别是在易感品种中[1,3]。

高风险品种的监测方案包括使用超声检查进行常规胆囊运动评估。运动研究的效用有助于在黏液囊肿成熟前识别胆囊运动障碍的犬，特别是易感品种的老年犬[1]。对于接受药物管理的早期黏液囊肿形成犬，建议每4-6周进行连续超声评估[3]。

早期检测策略涉及对易感品种（设得兰牧羊犬、小型雪纳瑞、可卡犬）的中年至老年犬进行常规腹部超声检查，特别是那些同时患有内分泌疾病或高脂血症的犬[1]。对于设得兰牧羊犬，由于潜在的品种特异性关联，可考虑使用吡虫啉以外的替代跳蚤和蜱虫预防药物[4]。

### Sources
[1] Canine Gallbladder Mucocele - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele
[2] Research Updates: Dogs with gallbladder mucoceles may be prone to common endocrine diseases: https://www.dvm360.com/view/research-updates-dogs-with-gallbladder-mucoceles-may-be-prone-common-endocrine-diseases
[3] Managing gallbladder mucoceles (Proceedings): https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings
[4] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml

## 鉴别诊断

胆囊黏液囊肿必须与几种临床表现重叠的疾病相鉴别。这些包括急性胆囊炎、急性胰腺炎、急性肝炎、钩端螺旋体病和肝外胆道梗阻[1]。

**急性胆囊炎**表现为腹痛、发热、呕吐和肝酶升高，与黏液囊肿相似。然而，胆囊炎通常在超声检查中显示胆囊壁增厚和炎症改变，而黏液囊肿则显示特征性的非重力依赖性条纹模式[2]。

**胰腺炎**可导致肝酶继发性升高，并可能表现为呕吐和腹痛。胰腺超声评估和犬胰腺脂肪酶免疫反应性测量有助于区分胰腺炎与原发性胆囊疾病[3]。

**急性肝炎**可能表现出类似的生化异常，包括ALT、ALP和胆红素升高。然而，肝炎通常缺乏黏液囊肿中特征性的胆囊超声变化，并且常有可识别的潜在原因，如毒素暴露或感染因子[1]。

**钩端螺旋体病**应考虑在肝酶急性升高的犬中，特别是当伴有发热和潜在接触史时。适当的血清学检测和PCR有助于确认这种感染原因[1]。

**肝外胆道梗阻**由胆石病或狭窄引起，可表现出与黏液囊肿相似的胆汁淤积酶模式。然而，影像学通常显示胆道扩张和梗阻病变，而不是特征性的胆囊黏液囊肿外观[2]。

关键区分因素是不移动、条纹状胆囊内容物的特征性超声表现，这些内容物不随重力改变位置[1][2]。

### Sources
[1] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml
[2] Canine Gallbladder Mucocele - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-gallbladder-mucocele
[3] An update on gallbladder mucoceles in dogs: https://www.dvm360.com/view/update-gallbladder-mucoceles-dogs

## 预后

胆囊黏液囊肿的预后在很大程度上取决于治疗方法和干预时机。接受无症状黏液囊肿择期胆囊切除术的犬预后良好，死亡率约为5%[1]。然而，需要紧急手术的有症状犬面临更高的风险，死亡率在17-23%之间[2]。

手术死亡率在术后即刻最高，肺部并发症是死亡的主要原因，包括急性肺血栓栓塞、急性肺损伤和吸入性肺炎[2]。与完整胆囊相比，胆囊破裂使死亡风险增加2.7倍[2]。

不良预后因素包括高龄、黄疸/高胆红素血症、肝酶升高、氮质血症、高乳酸血症、黏液囊肿成熟度高和并发肾上腺皮质功能亢进[2]。尽管存在这些风险，存活术后期的犬具有极好的长期预后，临床症状完全消失[1][7]。

药物治疗显示不同的结果，报告的中位生存期为1,340天，而手术病例为1,802天，但当药物治疗失败且需要紧急手术时，这一数字显著下降至203天[2]。如果犬能度过关键的术后期，成功胆囊切除术后的长期预后似乎极好[1]。

### Sources

[1] Managing gallbladder mucoceles (Proceedings): https://www.dvm360.com/view/managing-gallbladder-mucoceles-proceedings

[2] Diagnosis and management of gallbladder mucocele formation in dogs: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0789.xml

[7] Hyperbilirubinemia and recognizing gallbladder mucoceles (Proceedings): https://www.dvm360.com/view/hyperbilirubinemia-and-recognizing-gallbladder-mucoceles-proceedings
