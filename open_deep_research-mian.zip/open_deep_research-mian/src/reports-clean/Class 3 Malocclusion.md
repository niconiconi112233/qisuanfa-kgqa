# 伴侣动物III类错颌：兽医综合指南

III类错颌，以下颌前突或"地包天"为特征，是伴侣动物临床中一种重要的正畸疾病。虽然在许多短头颅品种中被视为正常，但这种颌骨排列紊乱在严重时可导致创伤性咬合、软组织损伤和功能障碍。本报告探讨了犬猫III类错颌的临床表现、诊断方法和治疗策略。主要主题包括阻断性正畸技术、牙冠缩短伴活髓治疗等手术干预，以及早期检测在预防并发症中的关键作用。分析强调了以证据为基础的管理方法，优先考虑患者的舒适度和功能，而非美容矫正。

## 疾病概述与流行病学

III类错颌，也称为下颌近中错位、下颌前突或地包天，是一种骨骼性错颌疾病，其特征是颌骨排列异常，下颌牙齿突出于上颌牙齿前方[1]。这种情况发生在下颌骨（下颌）相对于上颌骨（上颌）显得较长时，形成特征性的"下颌突出"外观，下颌切牙位于上颌切牙的吻侧[2]。

该疾病表现为牙弓之间的异常吻尾关系，其中下颌牙齿位于其正常咬合关系的前方[4]。III类错颌主要源于遗传，由遗传性牙面比例导致上下颌之间的大小比例失调[3]。

有趣的是，这种情况在许多短头颅品种中被视为正常，包括拳师犬、斗牛犬、波斯猫、波士顿梗犬和拉萨犬，在这些品种中下颌前突已被选择性培育为理想的品种特征[1][2]。在这些扁脸品种中，为短鼻子和"更方正"头部进行的选育无意中选择了下颌近中错位[2]。然而，即使在这些预期会出现地包天的品种中，也可能发生牙齿干扰和牙龈压迫，需要临床干预[4]。

虽然III类错颌的具体流行率数据有限，但该疾病在短头颅品种中特别常见，在这些品种中它代表了品种正常的解剖结构。病因主要是遗传性的，尽管颌骨生长过程中的发育变异或创伤可能会加重严重程度[3]。

### Sources

[1] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[2] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals
[3] Dentistry, the oral exam: practical anatomy and common pathology: https://www.dvm360.com/view/dentistry-oral-exam-practical-anatomy-and-common-pathology-proceedings
[4] Orthodontic solutions: What to do with that bite: https://www.dvm360.com/view/orthodontic-solutions-what-do-with-bite

## 临床表现与诊断

III类错颌（下颌近中错位）主要通过直接口腔检查和临床观察来诊断[1]。下颌相对于上颌处于近中（吻侧）位置，导致下颌牙齿突出于上颌牙齿前方[1][2]。虽然在许多短头颅品种中被视为正常，但当发生创伤性咬合时，它就具有临床意义[1]。

诊断评估从体格检查期间的视觉评估开始。执业医师应评估上颌切牙是否接触舌底或下颌犬齿，因为这可能导致显著的创伤和不适[1]。该疾病可能表现为各种临床表现，包括水平咬合（切牙边缘对边缘接触）或反向剪状咬合（下颌切牙在上颌切牙前方咬合）[2]。

在猫科患者中，正常的龈沟深度范围为0.5-1毫米，显著浅于犬科患者[4]。这种差异对于准确评估患有III类错颌的猫的牙周状况至关重要。

放射摄影在全面诊断中起着关键作用，特别是用于评估骨质丢失模式和根结构异常[3]。锥形束CT（CBCT）提供了解剖标志的增强可视化，在传统放射摄影解读可能具有挑战性的短头颅品种中尤其有价值[3]。

发病年龄通常在恒牙萌出时变得明显，最早可在6个月大时诊断。品种特异性表现最常见于短头颅品种，包括拳师犬、斗牛犬和波斯猫，在这些品种中该疾病代表正常的品种解剖结构，除非出现功能性并发症[1][2]。

### Sources
[1] Defining dental malocclusions in dogs - dvm360: https://www.dvm360.com/view/defining-dental-malocclusions-dogs
[2] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[3] Evaluation of the diagnostic yield of dental radiography and cone-beam CT: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.54.xml
[4] Feline dental problems (Proceedings): https://www.dvm360.com/view/feline-dental-proceedings

## 治疗方法与管理

III类错颌的治疗重点是舒适度、功能和预防创伤，而不是实现完美的美容效果[1]。治疗时机至关重要，早期干预可提供最佳结果[1]。

**阻断性正畸**
选择性拔除乳牙是III类错颌最常见的阻断性手术[1]。在早期（6-8周龄）进行时，这种技术消除了不良的牙齿锁结，允许无限制的颌骨运动，可能在生长期间实现自我矫正[1,3]。拔除哪些牙齿的决定取决于创伤的存在和颌骨生长需求[3]。

**保守管理**
许多III类错颌不需要治疗，除非它们导致创伤性咬合[4]。在短头颅品种中，III类错颌被视为正常，不需要干预[4]。如果不存在软组织创伤，监测可能是合适的，特别是当这种咬合模式是品种典型时[2]。

**手术干预**
对于导致创伤性咬合的恒牙，牙冠缩短伴活髓治疗可有效降低牙齿高度，同时保持牙髓活力[2,3,4]。这种手术消除了创伤，同时保留了牙齿功能，需要随访放射摄影进行监测[3,4]。拔除与错颌相关的上颌切牙可能为犬齿创造更宽的间隙，使其能够无创伤地咬合[4]。

**正畸移动**
正畸矫正需要多次麻醉事件和专业知识[4]。成功取决于患者的配合和主人对长期维护的承诺[2]。由于对治疗主要是遗传性疾病的伦理考虑，通常不推荐这种治疗[2,3]。

### Sources
[1] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth
[2] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[3] Pediatric dentistry: An overview of common problems you'll see in practice: https://www.dvm360.com/view/pediatric-dentistry-overview-common-problems-youll-see-practice
[4] Developmental Abnormalities of the Mouth and Dentition in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/developmental-abnormalities-of-the-mouth-and-dentition-in-small-animals

## 预防与预后

### 预防措施

**遗传咨询和育种策略：** 犬的III类错颌主要被认为是一种遗传性疾病，特别是骨骼性错颌遵循显性遗传模式[1]。负责任的育种实践需要识别受影响的动物并将其从育种计划中移除。育种者应评估种畜的口腔健康，避免配对已知颌骨长度差异的动物[2]。

**早期检测和干预：** 在6-8周龄时进行儿科牙科检查，可以早期识别乳牙的错颌。通过选择性拔除乳牙进行阻断性正畸，可以防止不良的牙齿锁结，并在关键发育期间允许无限制的颌骨生长[1]。

**环境预防：** 虽然III类错颌具有强烈的遗传成分，但避免发育中颌骨的创伤并在生长阶段保持适当的营养可能最小化继发性并发症。在生命第一年定期进行兽医牙科评估，确保及时识别和管理[1]。

### 预后与生活质量

**治疗结果：** 预后因严重程度和治疗方法而异。轻度III类错颌可能主要是美容性的，不需要干预[1]。然而，导致软组织创伤、牙齿与牙齿接触或功能障碍的病例需要及时治疗，以防止疼痛和继发性并发症[3]。

**生活质量考虑：** 大多数受影响的动物在治疗后适应良好，舒适度和功能得到改善。当正确执行时，牙冠截断伴活髓切断术或正畸矫正等手术干预通常提供良好的长期结果。如果不治疗，可能会发展进行性磨损模式、牙髓疾病和慢性疼痛[1]。

**长期并发症：** 未经治疗的III类错颌可导致异常牙齿磨损、创伤性牙髓炎、牙周疾病和早期牙齿脱落。定期监测确保早期发现需要额外干预的并发症[1][3]。

### Sources

[1] Normal occlusion or malocclusion: that is the question: https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[2] Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics
[3] Orthodontics defined: https://www.dvm360.com/view/orthodontics-defined
