# 猫科幼年牙龈炎

猫科幼年牙龈炎是一种具有挑战性的口腔炎症性疾病，影响处于关键牙齿发育期的幼猫。该病症以恒牙萌出周围严重的牙龈增生和炎症为特征，主要影响6-12月龄的猫。该疾病涉及病毒病原体、免疫功能障碍和口腔微生物群失调之间的复杂相互作用，形成持续性炎症循环，若不加以治疗可导致严重的牙周组织破坏。本兽医综合报告探讨了幼年牙龈炎的多因素性质，从其病毒和细菌病因到基于证据的治疗方案，为伴侣动物临床实践中有效管理此病症提供了重要的临床见解。

## 疾病概述

**定义**
猫科幼年牙龈炎是一种炎症性口腔疾病，特征为幼猫在恒牙萌出期间发生严重的牙龈增生和炎症（默克兽医手册，2024）。该病症涉及萌出牙齿周围明显的牙龈肿大，伴有剧烈的炎症变化，这些变化延伸至更深的牙周组织，导致牙龈萎缩、牙齿松动和牙槽骨丢失，并伴有牙周袋形成和根分叉暴露（默克兽医手册，2024）。

**流行病学背景**
该病症通常在6-12月龄的猫中表现出来，正值乳牙脱落和恒牙萌出时期（默克兽医手册，2024）。已发现特定的品种易感性，阿比西尼亚猫、缅因猫、波斯猫、暹罗猫和索马里猫的发病率较高（默克兽医手册，2024）。与成年猫口腔炎不同，幼年牙龈炎的炎症通常局限于牙齿周围的牙龈和粘膜组织，而不延伸至口腔后部，但当两岁以下猫存在明显的口腔后口咽部炎症时，两种疾病可能同时存在（默克兽医手册，2024）。

## 常见病原体

猫科幼年牙龈炎涉及复杂的病原体相互作用，破坏了正常的口腔微生物群平衡。多种病毒因子导致疾病的发生和发展[1]。猫杯状病毒（FCV）是最常被鉴定的病毒病原体，在某些研究中，高达100%的患病猫为慢性携带者[1]。猫疱疹病毒在口腔炎症性疾病的发展中也起着重要作用[1]。

逆转录病毒感染通过免疫抑制进一步损害口腔健康。猫免疫缺陷病毒（FIV）和猫白血病病毒（FeLV）常与严重的牙龈口腔炎相关，并可能使幼猫易患早发性牙周病[1]。这些病毒削弱局部免疫反应，允许机会性细菌过度生长。

细菌参与主要通过正常口腔微生物群失调而非特定致病菌种发生。该病症代表了对牙菌斑细菌和牙周韧带抗原的超免疫炎症反应[1]。当病毒感染或遗传倾向破坏免疫调节时，正常口腔细菌会引发过度炎症。

汉赛巴尔通体已被确定为与猫口腔炎相关的另一种潜在病原体，尽管支持这种关联的科学证据仍然有限[2]。病毒免疫抑制、遗传倾向和细菌抗原刺激之间的复杂相互作用创造了幼年牙龈炎特征性的自我维持炎症循环。

### Sources
[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[2] Gingivitis, stomatitis, and other oral lesions in cats (Proceedings): https://www.dvm360.com/view/gingivitis-stomatitis-and-other-oral-lesions-cats-proceedings

## 临床症状和体征

猫科幼年牙龈炎表现为特征性的牙龈增生和严重的炎症模式，这使其区别于其他口腔疾病。患病猫通常在萌出牙齿周围出现明显的牙龈肿大，当恒牙萌入口腔时伴有剧烈的炎症变化[1]。炎症延伸至更深的牙周组织，导致牙龈萎缩、牙齿松动和牙槽骨丢失，并伴有牙周袋形成和根分叉暴露[1]。

临床症状包括严重的口腔疼痛、口臭和口腔不适，可能导致猫在张口时发出声音[1]。与成年猫口腔炎不同，幼年牙龈炎的炎症通常局限于牙齿周围的牙龈和粘膜组织，而不延伸至口腔后部[1]。然而，如果两岁以下猫存在明显的口腔后口咽部炎症，两种疾病可能同时存在[1]。

已发现特定的品种易感性，阿比西尼亚猫、缅因猫、波斯猫、暹罗猫和索马里猫的发病率较高[1]。该病症通常在6-12月龄的猫中表现出来，正值乳牙脱落和恒牙萌出时期[1]。放射学评估经常显示受影响患者存在水平骨丢失，伴有根分叉受累和暴露[1]。

### Sources
[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals

## 诊断方法

猫科幼年牙龈炎的诊断主要依靠全面的临床检查结合支持性诊断测试。标志性的临床发现是口腔后部舌腭皱褶处或其外侧的严重粘膜炎症[1]。如果炎症仅局限于牙齿周围的牙龈，则牙龈炎或牙周炎而非幼年牙龈口腔炎是更可能的诊断。

由于严重的口腔疼痛妨碍充分的清醒评估，临床检查需要在麻醉下进行口腔评估[1]。兽医进行逐牙牙周探诊以测量龈沟深度，犬的正常探诊深度为1-3毫米，猫为0.5-1毫米[2]。

强烈建议对所有牙科患者进行口腔内牙科X线摄影，以全面评估疾病程度，避免不适当的治疗或忽视不明显的病理变化[2]。其他诊断测试可能包括杯状病毒和疱疹病毒的病毒分离、逆转录病毒检测以及评估肾衰竭等全身性疾病[1]。

应进行FeLV抗原和FIV抗体的血清学评估[3]。实验室检查结果可能显示白细胞增多、轻度至中度中性粒细胞增多伴左移、单核细胞增多、嗜酸性粒细胞增多、轻度淋巴细胞减少以及球蛋白增多伴白蛋白/球蛋白比例改变[3]。

在涉及单侧病变或增生性局灶性病变的非典型病例中，需要进行活检和组织学评估以排除口腔肿瘤或其他特定口腔疾病[1]。大多数活检样本显示淋巴细胞和浆细胞占优势，表明存在慢性炎症过程，但不能阐明主要病因。

### Sources
[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[2] Periodontal Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[3] Feline stomatitis: How to treat a diseae of unknown etiology: https://www.dvm360.com/view/feline-stomatitis-how-treat-diseae-unknown-etiology

## 治疗方案

猫科幼年牙龈炎需要综合的多模式方法，结合专业牙科护理、药物治疗和手术干预[1]。专业牙科清洁构成基础，包括使用超声洁牙机彻底清除龈上和龈下菌斑和牙石，随后进行抛光并用抗菌溶液冲洗[2]。

医学管理包括使用环孢素（5mg/kg/天）进行免疫调节治疗，已证明在自身免疫性口腔疾病中通过抑制T细胞活化和减少炎症反应有效[1]。皮质类固醇在70-80%的病例中提供有益效果，给药4-6个月并逐渐减量[2]。疼痛管理包括使用丁丙诺啡、布托啡诺和芬太尼贴剂等镇痛药以确保患者舒适[2]。

家庭护理策略强调每日刷牙和使用VOHC认可的产品，以控制专业治疗之间的菌斑积累[3]。对于严重病例，手术干预可能包括牙龈切除术以去除增生组织，这对疾病的增生形式特别有益[2][4]。

在药物治疗无效的难治性病例中，可考虑全口拔牙，约60%的患者可达到完全缓解[2]。这种多模式方法既解决了炎症成分，也解决了幼年牙龈炎特征性的潜在免疫功能障碍。

### Sources
[1] My favorite new drugs in veterinary dermatology: Parts 1 and 2 (Proceedings): https://www.dvm360.com/view/my-favorite-new-drugs-veterinary-dermatology-parts-1-and-2-proceedings
[2] Diseases of the feline oral cavity (Proceedings): https://www.dvm360.com/view/diseases-feline-oral-cavity-proceedings
[3] Fix the fixable: Treating periodontal and orthodontic disease: https://www.dvm360.com/view/fix-fixable-treating-periodontal-and-orthodontic-disease
[4] Management of the periodontal pocket: Part 1 (Proceedings): https://www.dvm360.com/view/management-periodontal-pocket-part-1-proceedings

## 预防措施

猫科幼年牙龈炎的预防需要从猫生命早期开始的多方面方法。每日刷牙是家庭护理的金标准，最好在猫年轻且口腔健康时开始[1]。如果每日刷牙有困难，每2-3天用纱布垫擦拭牙齿可提供显著益处[1]。

专业牙科清洁应从1岁开始，频率应根据个体需求而非固定时间表确定[2]。有些猫可能需要每6个月清洁一次，特别是那些早发性疾病患者[2]。定期兽医检查可以在严重病理发展前进行早期检测和干预。

营养支持在预防中起补充作用。某些特殊配方的干粮可对牙齿和牙龈提供有益按摩，帮助减少牙周病[4]。一些干粮和牙科零食有助于去除菌斑，但兽医指导对于适当产品选择仍然至关重要[1]。完整均衡的饮食确保适当的营养摄入，支持整体口腔健康[4]。

多猫家庭的环境管理包括减少可能加剧炎症状况的压力因素。系统疫苗接种和环境控制措施有助于预防可能加重口腔炎症的病毒感染的继发并发症[3]。早期干预策略集中在6-8月龄时识别幼年发病病例，此时可能首先出现牙龈肿胀和口臭[1]。

### Sources
[1] Dental Disorders of Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/dental-disorders-of-cats
[2] Diseases of the feline oral cavity (Proceedings): https://www.dvm360.com/view/diseases-feline-oral-cavity-proceedings
[3] Feline Respiratory Disease Complex - Respiratory System - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[4] Dog and Cat Foods - Management and Nutrition - Merck Veterinary Manual: https://www.merckvetmanual.com/management-and-nutrition/nutrition-small-animals/dog-and-cat-foods

## 鉴别诊断

猫科幼年牙龈炎必须与几种具有重叠临床体征的口腔炎症性疾病相鉴别。标志性的鉴别特征是发病年龄，幼年形式通常在6-8月龄时表现出来[1]。

**成年慢性牙龈口腔炎**是最重要的鉴别诊断。与幼年形式不同，成年牙龈口腔炎通常在7岁左右出现，特征为舌腭皱褶处或其外侧的严重口腔后部炎症[1]。成年牙龈口腔炎的标志性临床体征是口腔后部粘膜炎症，这在幼年病例中不太明显[1]。

**幼年发病牙周炎**通常影响缅因猫、暹罗猫和家养短毛猫幼猫，伴有大量菌斑和牙石沉积、附着丧失和骨丢失[2]。然而，牙周炎涉及超出牙龈的牙周结构破坏，这使其与简单的幼年牙龈炎区别开来。

**嗜酸性肉芽肿复合体（EGC）**病变通常出现在上唇、舌头和硬腭上，具有特征性的凹陷性溃疡，中心呈黄色[3]。EGC病变通常无痛且无瘙痒，与幼年牙龈炎的疼痛性炎症形成对比。

**淋巴浆细胞性牙龈炎/口腔炎**在某些纯种猫如阿比西尼亚猫和索马里猫中最早可在6个月时开始[3]。这些病例显示增生性、过度增生组织，具有"覆盆子红色、鹅卵石外观"，延伸超出牙龈边缘[3]。

**品种特异性考虑**至关重要，因为波斯猫表现出幼年早发性牙龈炎，牙龈边缘有红斑线，而阿比西尼亚猫和波斯猫可能发展为幼年增生性牙龈炎，增生组织覆盖牙齿[2]。

### Sources

[1] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals

[2] Diseases of the feline oral cavity (Proceedings): https://www.dvm360.com/view/diseases-feline-oral-cavity-proceedings

[3] Gingivitis, stomatitis, and other oral lesions in cats (Proceedings): https://www.dvm360.com/view/gingivitis-stomatitis-and-other-oral-lesions-cats-proceedings
