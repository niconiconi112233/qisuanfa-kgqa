# 犬猫甲沟炎：临床指南

甲沟炎是指围绕指甲的甲襞组织发炎，在小动物兽医临床实践中构成了一个重要的临床挑战。虽然作为原发性疾病相对少见，但甲沟炎常继发于伴侣动物的创伤、细菌感染或全身性疾病。本报告探讨了犬猫甲沟炎管理的病理生理学、诊断方法和基于证据的治疗策略。主要主题包括*假中间葡萄球菌*作为主要细菌病原体的作用、传染性和免疫介导性病因的鉴别诊断，以及解决潜在易感因素对成功长期管理的关键重要性。

## 摘要

犬猫甲沟炎是一种复杂疾病，需要全面了解细菌病理生理学、精确诊断技术和靶向治疗干预。*假中间葡萄球菌*作为主要细菌病原体占主导地位，*假单胞菌*、*大肠杆菌*和*马拉色菌*属的继发参与使治疗结果复杂化。临床表现从局部红斑和脓性分泌物到伴有甲营养不良的严重跛行不等。

| 管理组成部分 | 一线方法 | 持续时间/频率 |
|---------------------|--------------------|--------------------|
| 局部治疗 | 氯己定浸泡，稀释漂白剂 | 每日直至消退 |
| 全身性抗生素 | 头孢氨苄 20-30 mg/kg q12h | 最少21-42天 |
| 严重病例 | 头孢泊肟 5-10 mg/kg q24h | 6-8周 |

诊断成功取决于细胞学检查、细菌培养，以及在怀疑免疫介导原因时的组织病理学检查。预防侧重于通过适当修剪指甲和环境管理来减少创伤。对于细菌感染，使用适当的抗菌治疗预后仍然良好，但慢性病例可能导致永久性爪缺陷。早期干预解决过敏或内分泌疾病等潜在疾病对于防止复发和达到最佳临床结果至关重要。

## 疾病概述与流行病学

**定义**

甲沟炎定义为犬猫甲襞（围绕爪子的软组织）的炎症或感染[1]。这种情况代表了可能影响伴侣动物的更广泛爪部疾病谱系的一个组成部分。爪部单位由硬角质爪、下层甲床和包括甲襞在内的周围软组织组成[1]。

**解剖学考虑**

爪子对宠物具有多种基本功能，包括抓握、运动和防御[1]。患病的爪子使动物易受创伤、异常运动、疼痛、跛行和继发性皮炎影响[1]。甲襞和甲床之间的密切关系意味着甲沟炎可能进展并涉及爪部单位的更深结构。

**流行病学模式**

主要影响爪子和甲襞的疾病在犬猫中相对少见[2]。在评估爪部疾病时，单个爪子受累通常提示创伤、细菌感染或真菌感染为主要原因[1]。多个爪子受累更常见地表明全身性疾病，如免疫介导疾病、代谢障碍或甲营养不良[1][2]。

**易感因素**

甲沟炎最常继发于潜在疾病而非作为原发性疾病发生[1]。创伤是最常见的易感因素，特别是在犬中[1]。其他易感条件包括全身性疾病，如甲状腺功能减退、肾上腺皮质功能亢进、糖尿病、超敏反应和免疫介导疾病[1]。

### Sources

[1] Nail diseases (Proceedings): https://www.dvm360.com/view/nail-diseases-proceedings
[2] Nail disease (Proceedings): https://www.dvm360.com/view/nail-disease-proceedings

## 病因学与病理生理学

犬猫甲沟炎涉及细菌病原体、易感因素和局部组织破坏之间的复杂相互作用。犬皮肤感染中最常见的细菌病原体是*假中间葡萄球菌*，它产生β-内酰胺酶，通常定植于指间等温暖潮湿区域[1]。其他重要病原体包括作为继发入侵者的*假单胞菌*属、*大肠杆菌*和*奇异变形杆菌*[1]。在猫中，*多杀巴斯德菌*和β-溶血性链球菌常从皮肤感染中分离出来[1]。

病理生理学始于甲襞周围正常皮肤屏障的破坏。指间区域的温暖潮湿环境为细菌过度生长和定植创造了理想条件[2]。关键易感因素包括创伤、梳理不当、过度皮肤褶皱等解剖异常，以及过敏、内分泌疾病或免疫抑制疾病等潜在疾病[2]。

细菌对角质细胞的粘附代表了感染建立的关键第一步[2]。一旦定植发生，细菌毒素和炎症介质触发局部组织损伤和免疫反应。从表面定植到深部组织入侵的进展取决于宿主防御机制和伴随疾病，如常伴随深部脓皮病的蠕形螨病[2]。

继发性真菌感染，特别是*马拉色菌*属，常由于与表面葡萄球菌的共生关系而发生，创造了有利于两种生物的微环境变化[6]。这种并发感染模式使治疗复杂化，并导致甲沟炎病例中常见的慢性化。

### Sources
[1] Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[2] Pyoderma in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[3] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis

## 临床表现与诊断

犬猫甲沟炎表现为影响甲襞和爪部区域的特征性临床症状。典型体征包括甲床区域的红斑、肿胀和脓性分泌物[1]。该疾病通常表现为爪子周围疼痛、发炎的组织，可能伴有甲床受累和继发性甲营养不良[1]。

在猫中，甲沟炎可能表现为脚垫或爪襞周围干酪样化脓，特别是与落叶型天疱疮等自身免疫性疾病相关时[1]。犬可能因严重甲沟炎而表现出跛行，尤其是并发真菌性骨髓炎时[2]。

体格检查显示受影响爪子周围局部炎症、发热和压痛。可能存在脓疱，但常已破裂，留下结痂或干燥渗出物。从脓疱中突出的多根毛发有助于区分自身免疫相关甲沟炎与细菌性毛囊炎[1]。

诊断方法包括脓疱材料的细胞学检查，可能揭示伴有或不伴有细菌的中性粒细胞，具体取决于潜在原因。细菌培养和药敏测试对于识别传染源至关重要。在怀疑真菌感染的情况下，特别是伴有全身症状时，应考虑真菌培养和抗原检测[2]。活检样本的组织病理学检查可以区分甲沟炎的传染性、自身免疫性和肿瘤性原因。

### Sources

[1] Canine and feline pemphigus foliaceus: Improving your ... : https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome

[2] Blastomycosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/fungal-infections/blastomycosis-in-animals

## 治疗策略

犬猫甲沟炎的医学管理需要一种综合方法，既解决感染又解决潜在易感因素。**局部抗菌治疗是治疗的基石**，基于氯己定的溶液或稀释漂白剂爪子浸泡对于局部消毒至关重要[1]。含有抗菌剂与糖皮质激素和二甲基亚砜混合的局部组合可提供抗菌和抗炎效果[1]。

**全身性抗菌治疗对于更深部感染通常是必要的。** 选择最好由细菌培养和药敏测试指导，特别是考虑到慢性病例中多种抗生素疗程的历史[1]。**一线抗菌药物包括头孢氨苄（20-30 mg/kg PO q12h，持续21-42天）、头孢羟氨苄、阿莫西林-克拉维酸（13.75 mg/kg PO q12h）和甲氧苄啶-磺胺类药物**[3][5]。可能需要6-8周的较长治疗疗程才能解决[1]。

**二线抗菌药物如头孢泊肟（5-10 mg/kg PO q24h）和氟喹诺酮类药物应保留用于对一线药物无敏感性的病例**[3]。头孢维星（8 mg/kg SC q14d）提供14天的持续抗菌活性，可提高依从性[3][5]。

**在严重或难治性病例中可能需要手术干预**，特别是当存在显著组织增生或深沟形成时[1]。**局部和全身联合方法最有效**，治疗应持续直至临床和真菌学治愈均达到[2]。环境管理和解决过敏或结构异常等易感条件对于防止复发至关重要[1]。

### Sources
[1] Interdigital furunculosis: medical and surgical options: https://www.dvm360.com/view/interdigital-furunculosis-medical-and-surgical-options
[2] Dermatophytosis in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[3] Antibacterials for Integumentary Disease in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[4] Cephalosporins and Cephamycins Use in Animals - Pharmacology - Merck Veterinary Manual: https://www.merckvetmanual.com/pharmacology/antibacterial-agents/cephalosporins-and-cephamycins-use-in-animals
[5] Dosages of Antistaphylococcal Antimicrobials-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/dosages-of-antistaphylococcal-antimicrobials

## 预防与预后

### 预防

甲沟炎的预防护理侧重于减少创伤和适当的爪子管理[1]。定期修剪指甲可防止过度生长，并减少因钩住或分裂导致的创伤风险[2]。避免在柏油路、混凝土和砾石等粗糙表面上过度跑步有助于防止多个爪子受伤[2]。使用干净的指甲剪和适当卫生可防止在常规梳理过程中引入细菌病原体[2]。

高风险患者包括患有甲状腺功能减退、肾上腺皮质功能亢进、糖尿病或免疫介导疾病等潜在疾病的患者，这些疾病易导致继发性甲床感染[2]。环境管理包括保持清洁干燥的居住条件，并及时处理任何爪子损伤以防止继发性细菌并发症。通过环境消毒和隔离受影响动物直至真菌学治愈，可预防皮肤癣菌相关甲沟炎[4]。

### 预后

甲沟炎的预后根据潜在原因和严重程度差异很大。简单的创伤性损伤在适当治疗下通常愈合良好，尽管在最佳情况下用正常生长替换患病爪子需要数月时间[3]。

细菌感染通常对抗生素治疗反应良好，一旦正常爪子覆盖先前受影响区域，预期可解决[2]。慢性严重感染可能导致永久性缺陷性爪子生长[2]。皮肤癣菌相关甲沟炎在适当抗真菌治疗下预后良好，需要6-12周解决[4]。对称性狼疮样甲营养不良等免疫介导疾病需要长期免疫抑制治疗，改善和再生通常在3-4个月内注意到[2]。

### Sources

[1] Preventive Healthcare Guidelines: https://avmajournals.avma.org/downloadpdf/view/journals/javma/239/5/javma.239.5.625.pdf
[2] Nail diseases (Proceedings): https://www.dvm360.com/view/nail-diseases-proceedings
[3] Nail disease (Proceedings): https://www.dvm360.com/view/nail-disease-proceedings
[4] Dermatophytosis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
