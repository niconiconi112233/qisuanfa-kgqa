# 犬猫草酸钙结石

草酸钙结石是小动物临床中最具挑战性的泌尿系统疾病之一，其患病率从1981年占犬尿结石的5%和猫尿结石的1.5%，急剧上升至2013年分别达到42%和41%。这些晶体聚集物在整个泌尿道形成，根据解剖位置的不同产生不同的临床表现。本报告探讨了目前对草酸钙结石形成的认识，从涉及尿液过饱和的复杂病理生理学，到影响小型犬种以及喜马拉雅猫和波斯猫等特定猫种的品种易感性。分析涵盖了诊断影像学进展、包括输尿管支架置入在内的手术干预技术，以及管理这种复发性疾病所必需的循证预防方案。

## 疾病概述

草酸钙结石是由主要成分为一水草酸钙或二水草酸钙的晶体聚集物，在犬猫泌尿道内形成[1]。这些尿结石可表现为膀胱结石（cystoliths）、输尿管结石（ureteroliths）或肾结石（nephroliths），每个解剖位置都会带来不同的临床挑战[1]。**已有文献记载，超过98%的猫输尿管结石由草酸钙物质组成**[2]。

**草酸钙和鸟粪石是犬最常见的结石类型**[1]。近几十年来，患病率发生了显著变化。**1981年，草酸钙占犬尿结石的5%，占猫尿结石的1.5%**[5]。到2013年，草酸钙占犬尿结石的42%，占猫尿结石的41%[5]。在猫中，**2003年提交至明尼苏达尿结石中心的猫尿结石中，草酸钙是最常见的矿物质（47%）**[3]。

品种易感性已有充分记载。在犬中，许多小型品种常受影响，包括迷你雪纳瑞、吉娃娃、比熊犬、约克夏梗、西施犬和拉萨犬[1]。**猫的品种易感性包括喜马拉雅猫、波斯猫、布偶猫、哈瓦那棕猫和苏格兰折耳猫**[3]。**已认识到猫在形成草酸钙尿结石方面存在性别易感性，雄性更易患病**[1]。**猫在检测到草酸钙尿结石时的平均年龄约为8岁**[3]。

**高钙血症是草酸钙尿结石形成的易感因素，据报道在35%的患尿结石猫和约4%的患尿结石犬中存在**[4]。

### Sources

[1] Merck Veterinary Manual Urolithiasis in Dogs: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[2] Technical and clinical outcomes of ureteral stenting in cats: https://avmajournals.avma.org/view/journals/javma/244/5/javma.244.5.559.xml
[3] Feline calcium oxalate uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-feline-calcium-oxalate-uroliths
[4] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[5] Canine and feline urolith epidemiology: 1981-2013: https://www.dvm360.com/view/canine-and-feline-urolith-epidemiology-1981-2013

## 病理生理学和临床表现

草酸钙结石的形成是通过尿液过饱和和结晶的复杂过程发生的。高钙尿症是主要的病理生理因素，在犬猫中通常与血钙正常相关[1]。过饱和过程涉及多种危险因素，包括酸性尿（pH <6.25）、高草酸尿症和结晶抑制剂减少[2]。

当尿液中钙和草酸盐浓度超过溶解度极限时，结晶过程开始。与在碱性条件下沉淀的鸟粪石不同，草酸钙晶体在酸性尿中更容易形成[4]。这会导致晶体聚集，在数周至数月内进展为肉眼可见的结石形成[5]。

临床表现因结石位置而异。膀胱结石通常引起排尿困难、血尿和尿频，是两个物种中最常见的部位[6]。尿道结石可能引起类似体征，并可能伴有从包皮或阴部滴血[7]。上尿路受累表现不同--肾结石通常无症状，除非并发感染；而输尿管结石如果发生梗阻，可引起呕吐、嗜睡和胁腹疼痛[10]。

当结石引起尿道梗阻时，会出现紧急情况，特别是在雄性猫中。完全梗阻会在1-2天内导致毒素积聚，进展为抑郁、呕吐、脱水，并在72小时内可能致命的心律失常[8]。患有既往慢性肾病的猫，当输尿管结石损害已经边缘化的肾功能时，可能会发生尿毒症危象[5]。

### Sources
[1] Calcium Oxalate Nephrolithiasis in Dogs, Cats, and Humans: https://www.dvm360.com/view/calcium-oxalate-nephrolithiasis-in-dogs-cats-and-humans
[2] Feline calcium oxalate uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-feline-calcium-oxalate-uroliths
[4] Urolithiasis and the impact of nutritional management: https://www.dvm360.com/view/urolithiasis-and-the-impact-of-nutritional-management
[5] Urolithiasis in Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-cats
[6] Urolithiasis of the lower urinary tract (Proceedings): https://www.dvm360.com/view/urolithiasis-lower-urinary-tract-proceedings
[7] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[8] Urinary Stones (Uroliths, Calculi) in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/kidney-and-urinary-tract-disorders-of-cats/urinary-stones-uroliths-calculi-in-cats
[10] Overview of Urolithiasis in Small Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/overview-of-urolithiasis-in-small-animals

## 诊断和治疗

草酸钙尿结石具有高度放射性不透性，可通过放射线摄影在81%的猫中检测到，超声在77%中检测到，两种方法结合时检测率为90%[1]。平片X光检查是必要的，因为结石需要至少3mm才能被检测到[2]。草酸钙结石呈圆形至棘刺状，通常存在多个结石[6]。

超声检查显示肾积水、输尿管扩张，并有助于确定结石位置[1]。当梗阻位置不明确时，可能需要排泄性尿路造影或顺行性肾盂造影，但这些检查需要麻醉[1]。

实验室检查结果通常显示氮质血症（83%的猫），其中35%伴有高钙血症[1]。尿液分析可能显示血尿、脓尿，尿液pH通常呈中性至酸性[2,5]。

**治疗选择**

内科治疗包括立即进行液体利尿和使用甘露醇等利尿剂以促进结石排出[1]。可使用平滑肌松弛剂和镇痛药，但其疗效尚未得到证实[1]。草酸钙和二氧化硅尿结石无法通过内科方法溶解[9]。目前尚无草酸钙结石的内科溶解方案[10]。

当内科治疗失败时，需要手术干预。选择包括输尿管切开术、输尿管膀胱再植术或肾盂切开取石术，需要显微外科技术[1]。输尿管支架置入为梗阻性猫提供了更好的预后[1]。对于膀胱结石，微创技术如经皮膀胱切开取石术或膀胱镜下取石优于传统膀胱切开术[8]。

梗阻性患者的紧急管理需要在确定性干预之前通过液体疗法迅速稳定病情并纠正电解质失衡[1]。

### Sources

[1] Managing ureteral and renal calculi in cats (Proceedings): https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings
[2] Managing urolithiasis (Proceedings): https://www.dvm360.com/view/managing-urolithiasis-proceedings-0
[5] Clinical diagnosis of pyelonephritis often presumptive: https://www.dvm360.com/view/clinical-diagnosis-pyelonephritis-often-presumptive
[6] Tips for managing feline urolithiasis from a feline practitioner: https://www.dvm360.com/view/tips-for-managing-feline-urolithiasis-from-a-feline-practitioner
[8] Identifying and treating canine and feline urolithiasis: https://www.dvm360.com/view/identifying-and-treating-canine-and-feline-urolithiasis
[9] Nonsurgical urolith management (Proceedings): https://www.dvm360.com/view/nonsurgical-urolith-management-proceedings
[10] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs

## 预防和预后

**预防措施**

草酸钙结石在犬和猫中均预期会复发，因此预防方案至关重要[1]。预防的基石是增加饮水量，以达到犬尿液比重≤1.020，猫尿液比重≤1.030[1,2]。高水分饮食是首选，因为它们能促进致结石物质的稀释并增加排尿频率[2]。

饮食管理侧重于喂食旨在降低尿液过饱和的处方食品。对于犬，只有皇家宠物食品兽医饮食泌尿道SO（Royal Canin Veterinary Diet Urinary SO）适合长期草酸钙预防，而猫有多种治疗性饮食选择[1]。饮食应避免过量蛋白质、钙、草酸盐和维生素C补充，同时保持足够的磷水平[2]。

**医学预防方案**

柠檬酸钾（40-75 mg/kg，每12小时一次）可能对猫有益，通过碱化尿液和增加柠檬酸盐排泄[2]。维生素B6补充（2-4 mg/kg）是安全的，可能减少草酸盐排泄[2]。对于伴有高钙血症的猫，识别并纠正根本原因至关重要[1,3]。

**监测和预后**

定期监测包括尿液分析、血清生化分析和影像学检查，初期每2-4周一次[2]。尽管有预防措施，复发率仍然很高，高达50%的犬在3年内经历复发[1]。通过监测早期发现，可通过排尿性尿液压冲洗微创移除小结石[3]。风险因素消除的程度决定监测频率，具有多个持续风险因素的患者需要更频繁的评估[2]。

### Sources

[1] Dietary management of urolithiasis (Proceedings): https://www.dvm360.com/view/dietary-management-urolithiasis-proceedings
[2] Feline calcium oxalate uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-feline-calcium-oxalate-uroliths
[3] Urolithiasis in Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-cats
