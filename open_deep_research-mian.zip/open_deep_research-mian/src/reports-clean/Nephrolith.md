# 伴侣动物肾结石

肾结石，即肾结石的形成，代表了小动物临床中一项重要的临床挑战，影响着犬和猫。这种情况涉及在肾盂和肾实质内形成矿物质凝结物，其中草酸钙和鸟粪石是最常见的类型。虽然许多病例无症状且是偶然发现的，但有症状的动物可能表现为血尿、复发性尿路感染和潜在的肾脏并发症。本报告探讨了肾结石的全面兽医管理，涵盖流行病学模式、诊断方法、从药物溶解到先进外科手术的治疗方式，以及基于证据的预防策略，这些对于伴侣动物临床中实现最佳患者预后至关重要。

## 疾病概述与流行病学

肾结石，又称肾结石病，是指犬和猫肾盂和肾实质内矿物质凝结物的形成[1]。小动物的尿路结石最常发生在膀胱，但肾结石由于其位置和潜在并发症，构成了重要的临床挑战[1]。

最常见的肾结石类型包括鸟粪石（六水合磷酸镁铵）和草酸钙结石。历史上，鸟粪石尿路结石在两个物种中最为普遍，1981年占猫尿路结石的78%，尽管到2002年下降至约33%，但在2005年又回升至48.1%[4]。在犬中，1981-2005年间鸟粪石占尿路结石的43.5%，但从2004年开始成为第二常见类型[1]。

草酸钙肾结石表现出明显的人口统计学模式。雄性犬和猫，特别是去势雄性，风险更高[2]。年龄易感性因物种和结石类型而异：草酸钙影响老年犬（>5-8岁）和猫（10-15岁），而猫的鸟粪石肾结石主要发生在1-10岁之间[1][4]。

品种易感性已有充分记载。对于草酸钙结石，约克夏梗、博美犬、波斯猫和喜马拉雅猫表现出更高的易感性[2]。鸟粪石形成在迷你雪纳瑞犬、西施犬、比熊犬和外国短毛猫中更为常见[1][4]。

### Sources

[1] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[2] Calcium Oxalate Nephrolithiasis in Dogs, Cats, and Humans: https://www.dvm360.com/view/calcium-oxalate-nephrolithiasis-in-dogs-cats-and-humans
[4] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings

## 病因学与风险因素

犬和猫肾结石的形成涉及多种相互作用的因素，这些因素因结石类型而异。**鸟粪石**是猫中最常见的类型（47.1%），主要由碱性尿pH值和饮食因素引起，包括磷和镁摄入量增加[1]。在犬中，鸟粪石通常由产脲酶细菌（如葡萄球菌属和变形杆菌属）引起的尿路感染导致[2]。

**草酸钙结石**是犬中最常见的类型（47%），由酸性尿（pH < 6.25）、饮食钙摄入量增加、高钙血症和代谢性酸症发展而来[1]。这些状况导致钙从骨骼中释放并减少柠檬酸盐（一种重要的晶体抑制剂）[1]。小型犬品种包括迷你雪纳瑞犬、约克夏梗和西施犬表现出更高的易感性[2]。

**尿酸盐结石**主要影响*SLC2A9*转运蛋白基因发生突变的犬，特别是大麦町犬，或患有门体分流导致嘌呤代谢异常的犬[2]。**胱氨酸结石**发生在患有影响氨基酸重吸收的遗传性肾小管缺陷的犬中，在英国斗牛犬和獒犬中有品种易感性[2]。所有结石类型的共同风险因素包括年龄、性别、遗传、饮食成分以及改变尿液浓度和pH值的代谢异常[1][3]。

### Sources
[1] Urolithiasis and the impact of nutritional management: https://www.dvm360.com/view/urolithiasis-and-the-impact-of-nutritional-management
[2] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[3] Nutritional management of urolithiasis in dogs and cats: https://www.dvm360.com/view/nutritional-management-of-urolithiasis-in-dogs-and-cats

## 临床表现与诊断

许多患有肾结石的犬和猫没有症状，结石是在因其他疾病进行放射学检查时偶然发现的[1]。当只有一个肾脏受累时尤其如此[2]。然而，有症状的动物可能表现为血尿、复发性尿路感染（UTI）、呕吐以及腹部或腰部疼痛，尽管与人类相比疼痛并不常见[1]。患有输尿管结石的猫可能表现为急性或慢性肾衰竭，双侧输尿管梗阻或进行性肾损伤可导致尿毒症[1]。

体格检查可能揭示腰下区或腹部疼痛，但这通常不被识别[2]。除非结石非常大，否则触诊很少能识别出肾脏肿块。在急性肾损伤病例中，肿胀、疼痛的肾脏是标志性表现，一些动物可能表现出严重的放射状胁腹痛和腹部强直[3]。

**诊断方法**

实验室评估包括全血细胞计数、血清生化分析和尿液分析[2]。尿液分析可能显示血尿、结晶尿、脓尿和菌尿（如果同时存在UTI）[1]。等渗尿（尿比重1.007-1.015）在肾脏疾病中很常见[3]。晶体识别和尿液pH值有助于预测肾结石成分[1]。应通过膀胱穿刺术从所有患者获取样本进行尿液培养[1]。

**影像学方法**

放射致密性肾结石通常通过腹部X线摄影诊断[1]。超声检查可以确认结石的存在、大小和数量，但超声确认输尿管结石并非总是可能[1]。通过肾盂穿刺术进行的顺行肾盂造影有助于在标准影像学检查不足时识别梗阻原因[1][4]。肾盂镜检查已成功用于检测通过反复冲洗肾盂未能清除的小型肾结石[5]。在猫中，肾盂钙化必须与真正的肾结石相鉴别，这在诊断上可能具有挑战性[1]。

### Sources

[1] Feline nephroliths and ureteroliths (Proceedings): https://www.dvm360.com/view/feline-nephroliths-and-ureteroliths-proceedings
[2] Nephrolithiasis and ureterolithiasis in the canine and feline medical and surgical patient (Proceedings): https://www.dvm360.com/view/nephrolithiasis-and-ureterolithiasis-canine-and-feline-medical-and-surgical-patient-proceedings
[3] Acute uremia (Proceedings): https://www.dvm360.com/view/acute-uremia-proceedings
[4] Managing ureteral and renal calculi in cats (Proceedings): https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings
[5] Management of nephrolithiasis by pyelotomy and pyeloscopy in 13 dogs: https://avmajournals.avma.org/view/journals/javma/255/9/javma.255.9.1057.xml

## 医疗与外科管理

肾结石的治疗方法因结石成分、位置和临床表现而异。医疗溶解方案仅限于鸟粪石结石，使用溶石饮食（希尔氏s/d®）并在存在感染时结合适当的抗生素治疗[3]。溶解通常需要2-3个月（感染相关鸟粪石结石）和3-6周（无菌结石），每4周进行一次放射学监测[3]。

草酸钙肾结石占猫结石的40.6%，无法通过医疗溶解，需要手术干预[4]。传统肾切开术会导致肾小球滤过率下降10-20%，这在肾功能受损患者中可能具有临床意义[5]。微创技术提供了更优的替代方案，包括经皮肾镜取石术（PCNL），它利用球囊扩张而非手术刀切口，从而减少实质损伤[5]。

体外冲击波碎石术（ESWL）在猫中成功率有限，只有20%实现完全尿路结石清除[4]。猫草酸钙结石比犬结石更难破碎，且小的输尿管直径即使对细小碎片也易导致梗阻[7]。

对于输尿管梗阻，先进的干预措施包括输尿管支架置入、皮下输尿管旁路系统以及显微外科技术，如输尿管切开术或输尿管膀胱再植术[2]。紧急处理包括使用甘露醇（0.25-0.5 g/kg，20-30分钟内输注）进行液体利尿、平滑肌松弛剂如哌唑嗪（0.25-0.5 mg/猫，每12小时一次）以及对并发肾衰竭的支持性护理[7]。内镜肾镜取石术是用于需要专业技术的复杂病例的新兴技术[1]。

### Sources

[1] Journal of the American Veterinary Medical Association Endoscopic nephrolithotomy for the removal of complicated nephroliths in dogs and cats: 16 kidneys in 12 patients (2005-2017): https://avmajournals.avma.org/view/journals/javma/255/3/javma.255.3.352.xml
[2] Merck Veterinary Manual Obstructive Uropathy in Dogs and Cats: https://www.merckvetmanual.com/urinary-system/noninfectious-diseases-of-the-urinary-system-in-small-animals/obstructive-uropathy-in-dogs-and-cats
[3] DVM 360 Nephrolithiasis and ureterolithiasis in the canine and feline medical and surgical patient: https://www.dvm360.com/view/nephrolithiasis-and-ureterolithiasis-canine-and-feline-medical-and-surgical-patient-proceedings
[4] DVM 360 Feline nephroliths and ureteroliths: https://www.dvm360.com/view/feline-nephroliths-and-ureteroliths-proceedings
[5] DVM 360 Percutaneous nephrolithotomy for kidney stone removal: https://www.dvm360.com/view/percutaneous-nephrolithotomy-kidney-stone-removal
[6] DVM 360 Feline uroliths: https://www.dvm360.com/view/feline-uroliths-proceedings
[7] DVM 360 Managing ureteral and renal calculi in cats: https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings

## 预防策略

有效预防肾结石复发需要全面的、针对结石类型的综合方法，结合饮食管理、医疗方案和长期监测策略[1]。

**按结石类型划分的饮食管理**

鸟粪石预防的重点是维持尿液pH值低于6.8，并通过专用治疗性饮食减少镁、铵和磷的排泄。对于患有感染诱导鸟粪石结石的犬，一旦感染解决，通常不需要长期饮食管理，而应强调预防尿路感染[1]。

草酸钙预防更具挑战性，因为这些结石无法通过医疗溶解且经常复发。推荐的饮食策略包括限制蛋白质、避免酸化饮食、确保足够的钙摄入以及喂食高水分饮食，以维持犬的尿比重低于1.020，猫的尿比重低于1.025[2]。多种处方饮食专为草酸钙预防配制，首选罐装配方以增加饮水量[2]。

对于尿酸盐结石，使用蛋清或素食蛋白质来源的低嘌呤饮食可有效减少尿酸排泄，同时维持足够的蛋白质水平。猫尿酸盐结石的预防通常采用蛋白质限制、碱化的肾脏饮食[2][3]。

**医疗预防方案**

柠檬酸钾补充剂（40-75 mg/kg，每12小时一次）为草酸钙预防提供碱化作用，并可能减少钙排泄。噻嗪类利尿剂可减少尿钙排泄，但需要仔细监测电解质[6]。对于胱氨酸结石，2-巯基丙酰甘氨酸和将pH值碱化至7.5以上有助于预防复发[1]。

**监测与长期管理**

每3-6个月进行定期监测影像学检查，可以在结石足够小、可通过排尿性尿液压冲洗术非侵入性清除时早期发现复发[7]。这种方法有助于避免重复手术干预及相关并发症。一致的监测应包括尿液分析、血清生化分析和根据每位患者风险因素定制的适当影像学检查[6]。

### Sources

[1] Dietary management of urolithiasis (Proceedings): https://www.dvm360.com/view/dietary-management-urolithiasis-proceedings
[2] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings
[3] Nephrolithiasis and ureterolithiasis in the canine and feline: https://www.dvm360.com/view/nephrolithiasis-and-ureterolithiasis-canine-and-feline-medical-and-surgical-patient-proceedings
[4] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[5] Nutritional management of urolithiasis in dogs and cats: https://www.dvm360.com/view/nutritional-management-of-urolithiasis-in-dogs-and-cats
[6] Feline calcium oxalate uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-feline-calcium-oxalate-uroliths
[7] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs

## 鉴别诊断与预后

肾结石必须与几种临床表现重叠的尿路疾病相鉴别。主要鉴别诊断包括慢性肾病、肾盂肾炎、其他原因引起的输尿管梗阻和下尿路疾病[2]。鉴别特征包括草酸钙结石的放射学不透明性、输尿管梗阻的超声检查肾积水证据，以及无症状肾结石中缺乏全身性体征[2]。

肾盂钙化在影像学上可模拟真正的肾结石，需要使用超声或先进影像学技术进行仔细鉴别[4]。尿路感染可能与结石同时发生或继发于结石存在，因为肾结石作为细菌生长的核心[2]。临床鉴别依赖于尿液培养结果和对抗菌治疗的反应。

尿路结石还必须与其他血尿原因相鉴别，包括肿瘤、药物毒性和创伤[1]。体格检查结果、直肠触诊和全面的影像学评估有助于区分这些情况[3]。

预后因结石成分、位置和梗阻程度而异显著。草酸钙肾结石的预后为谨慎至一般，因为无法通过医疗溶解且复发率高[5]。手术并发症包括肾小球滤过率初始下降27-52%，在肾切开术后六周改善至下降22-34%[4]。完全输尿管梗阻需要立即干预以防止不可逆的肾损伤[5]。早期干预和适当的医疗管理显著改善预后，而延迟治疗通常导致永久性肾功能损害。

### Sources

[1] Red urine: Disorders you may have never considered: https://www.dvm360.com/view/red-urine-disorders-you-may-have-never-considered-proceedings-0/1000
[2] Managing feline nephroliths: https://www.dvm360.com/view/managing-feline-nephroliths-proceedings
[3] Nephrolithiasis and ureterolithiasis in the canine and feline: https://www.dvm360.com/view/nephrolithiasis-and-ureterolithiasis-canine-and-feline-medical-and-surgical-patient-proceedings
[4] Feline nephroliths and ureteroliths: https://www.dvm360.com/view/feline-nephroliths-and-ureteroliths-proceedings
[5] Managing ureteral and renal calculi in cats: https://www.dvm360.com/view/managing-ureteral-and-renal-calculi-cats-proceedings
