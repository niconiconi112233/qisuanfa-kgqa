# 宠物蟾蜍毒素暴露

蟾蜍毒素暴露在小动物兽医实践中代表着一种重要的紧急情况，尤其影响美国特定地理区域的犬和猫。这种中毒症发生在宠物接触有毒蟾蜍物种的防御性分泌物时，最显著的是*海蟾蜍*（*Rhinella marina*）和*科罗拉多河蟾蜍*（*Incilius alvarius*）。该状况可迅速从局部口腔刺激发展为危及生命的全身性并发症，包括严重的心律失常和神经系统症状。

本综合报告探讨了蟾蜍毒素暴露的临床表现、诊断挑战和治疗方案。关键主题包括有毒蟾蜍物种的识别及其地理分布、蟾蜍毒素和蟾蜍配基中毒的病理生理学、紧急去污程序以及重症监护管理策略。该报告还讨论了关键鉴别诊断和在流行地区对兽医从业者至关重要的预防措施，在这些地区季节性的蟾蜍活动对伴侣动物构成持续风险。

## 疾病概述

蟾蜍毒素暴露是一种急性中毒症，影响接触有毒蟾蜍物种防御性分泌物的犬和猫（默克兽医手册，2024年）。当伴侣动物用嘴咬、啃咬或以其他方式接触有毒蟾蜍时会发生这种情况，这些蟾蜍通过特化的腮腺和皮肤腺体释放刺激性毒素作为防御机制。

流行病学模式显示出明显的地理和季节性分布。在北美，临床上最重要的物种包括在佛罗里达州、夏威夷州和德克萨斯州建立种群的海蟾蜍（*Rhinella marina*）以及在美国西南部和墨西哥北部发现的科罗拉多河蟾蜍（*Inciliella alvarius*）（默克兽医手册，2024年）。接触最常发生在温暖的月份，特别是6月至9月之间，此时蟾蜍在黎明和黄昏时段最为活跃。

犬比猫更容易受到影响，因为它们的探索行为和在户外用嘴咬陌生物体的倾向。这种情况代表了一种需要立即干预的兽医紧急情况，因为从初次接触到危及生命的全身性症状的进展可能在几分钟到几小时内发生，具体取决于涉及的物种和暴露程度。

## 常见病原体

犬和猫的蟾蜍毒素暴露不是由传染性病原体引起的，而是由特定蟾蜍物种作为防御机制产生的有毒物质引起的。美国临床上最重要的两种有毒蟾蜍物种是海蟾蜍（*Rhinella marina*）和科罗拉多河蟾蜍（*Incilius alvarius*）[1]。

海蟾蜍（*Rhinella marina*），以前被称为*Bufo marinus*，是兽医实践中遇到的最有毒的物种。这种外来物种已在佛罗里达州、夏威夷州和德克萨斯州建立种群，在澳大利亚被称为甘蔗蟾蜍[1]。科罗拉多河蟾蜍（*Incilius alvarius*，以前称为*Bufo alvarius*）发现于美国西南部和墨西哥北部，是另一种具有潜在致命毒素水平的物种[1]。

所有蟾蜍都通过位于眼睛背侧和尾侧的大型腮腺以及遍布皮肤的小腺体产生有毒化合物[1]。毒素包含多种生物活性成分，包括蟾蜍配基（洋地黄样化合物）、蟾蜍毒素（钠通道阻滞剂）、多巴胺、儿茶酚胺、蟾蜍色胺和吲哚烷基胺[1][2]。蟾蜍配基对心血管系统产生洋地黄样作用，而蟾蜍毒素通过类似于局部麻醉剂的机制阻断神经中的钠通道[1][3]。

有毒分泌物是一种浓稠的乳白色、高度刺激性的物质，当蟾蜍受到攻击或干扰时，可以通过腺周肌肉的收缩迅速排出[1][2]。全球存在超过200种蟾蜍，其腮腺分泌物含有几种生物活性化合物，包括肾上腺素、去甲肾上腺素、多巴胺和血清素，这些物质容易被吸收[3]。

### Sources
[1] Toad Poisoning in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/toad-poisoning/toad-poisoning-in-dogs-and-cats
[2] "Natural" does not mean "safe" (Proceedings): https://www.dvm360.com/view/natural-does-not-mean-safe-proceedings
[3] 1941_1944.QXD - avmajournals.avma.org: https://avmajournals.avma.org/downloadpdf/view/journals/javma/216/12/javma.2000.216.1941.pdf

## 临床症状和体征

犬和猫的蟾蜍毒素暴露产生一系列特征性的临床表现，范围从轻微的局部刺激到危及生命的全身性毒性[1]。临床症状的严重程度和进展取决于多种因素，包括蟾蜍种类、暴露程度、患者健康状况和接触后经过的时间。

**局部和即时体征**
初始临床症状通常在接触后几分钟内出现，包括大量流涎，通常呈泡沫状，伴有剧烈的头部晃动和用爪子抓嘴[1][2]。由于毒素的直接刺激，口腔粘膜变得充血和鲜红[2]。动物经常表现出干呕并可能呕吐，特别是在严重病例中[1]。

**全身性心血管效应**
心脏表现是最严重的并发症之一，心动过速是犬最常见的异常，有时超过每分钟260次[2]。更严重的病例可能发展为室性早搏、交界性逸搏和房室传导阻滞[2]。这些心律失常可导致低血压，引起急性虚脱或长时间卧倒。

**神经系统表现**
中枢神经系统体征通常在第一小时内发展，包括震颤、癫痫发作、共济失调、定向障碍和步态亢进[1][2]。在严重病例中，动物可能进展至昏睡、昏迷或完全麻痹[1]。猫特别容易受到影响，可能表现出大声鸣叫、嚎叫，并迅速发展为麻痹体征[2]。

**呼吸和其他全身性体征**
其他表现包括呼吸急促、呼吸困难、肺水肿和发绀[1]。由于蟾蜍配基的洋地黄样作用，可能发生高钾血症，尽管这在人类中比在兽医患者中更一致地报道[2]。

### Sources
[1] Toad Poisoning in Dogs and Cats - Toxicology: https://www.merckvetmanual.com/toxicology/toad-poisoning/toad-poisoning-in-dogs-and-cats
[2] Successful treatment of Bufo marinus intoxication in a dog: https://www.dvm360.com/view/toxicology-case-successful-treatment-bufo-marinus-intoxication-dog

## 诊断方法

蟾蜍毒素暴露的诊断主要依靠临床表现评估结合支持性实验室检查结果[1]。临床评估侧重于识别特征性体征，包括接触后立即出现的大量流涎、剧烈的头部晃动、用爪子抓嘴和干呕[1]。诊断挑战的出现是因为与蟾蜍的接触在温暖或温和的天气中最常见，要求兽医在这些时期保持高度的临床怀疑[2]。

血清生化分析对于检测高钾血症至关重要，这是蟾蜍毒素中蟾蜍配基的洋地黄样作用导致的关键实验室检查结果[1][2]。由于蟾蜍毒素与地高辛测定之间存在交叉反应，血清地高辛浓度测量可能显示可检测水平[1][2]。然而，血清地高辛浓度有助于确认暴露，但不能可靠地表明中毒的严重程度[1][2]。

诊断过程面临重大挑战，因为没有特定的测试来确认蟾蜍毒素暴露[1]。蟾蜍毒素的多种成分可以迅速引起多灶性危及生命的临床状况，使得快速诊断对患者结果至关重要[3]。当没有特定的实验室确认时，兽医必须依靠环境史、季节性因素和特征性临床症状的快速发作[1][3]。

额外的实验室检查包括血清电解质、心脏生物标志物和心电图，有助于评估全身性影响并指导治疗决策[1]。对于严重受影响的动物，建议进行连续心电图监测，因为可能发展出各种心律失常[3]。

### Sources

[1] Merck Veterinary Manual Toad Poisoning in Dogs and Cats: https://www.merckvetmanual.com/toxicology/toad-poisoning/toad-poisoning-in-dogs-and-cats
[2] Merck Veterinary Manual Toad Poisoning Overview: https://www.merckvetmanual.com/toxicology/toad-poisoning/overview-of-toad-poisoning
[3] DVM360 Successful Treatment of Bufo marinus Intoxication: https://www.dvm360.com/view/toxicology-case-successful-treatment-bufo-marinus-intoxication-dog

## 治疗选择

蟾蜍毒素暴露的紧急治疗需要立即进行去污，随后进行积极的支持性护理[1]。应立即用大量水彻底冲洗患者的口腔以去除残留毒素[1]。仅仅用嘴接触过蟾蜍的动物不会从催吐中获益，催吐只应考虑用于临床症状轻微且已知已摄入蟾蜍组织的患者[1]。

活性炭（2-4克/公斤口服）能有效结合蟾蜍毒素和其他强心苷，但在出现神经系统体征或明显呕吐的动物中禁用[1][7]。当地高辛免疫Fab不可用时，对于持续的临床症状，可能在6-8小时后需要第二剂[7]。

癫痫发作的管理使用地西泮（0.5-1毫克/公斤静脉注射）、戊巴比妥（3-15毫克/公斤静脉注射）或丙泊酚（3-6毫克/公斤静脉注射）[1][7]。对于严重的神经系统体征，动物可能需要用戊巴比妥治疗以控制惊厥[6]。

心律失常需要特定的治疗方案：利多卡因（2-4毫克/公斤静脉注射，随后25-100微克/公斤/分钟持续输注）用于室性心律失常，普萘洛尔（0.02-0.06毫克/公斤静脉注射）或艾司洛尔用于室上性心动过速[1][7]。阿托品控制心动过缓，前提是没有高钾血症[7]。

重症监护包括连续心电图监测和在最初12小时内每2-4小时进行系列血清钾测量[1][7]。使用不含钙的溶液进行液体治疗支持心血管功能并增强毒素消除[7]。对于心脏异常持续存在且对标准治疗无反应的严重病例，羊源性地高辛免疫Fab（1-2瓶静脉注射）直接结合并灭活心脏活性甾醇[1][7]。

### Sources
[1] Toad Poisoning in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/toad-poisoning/toad-poisoning-in-dogs-and-cats
[2] Venomous varmints and other creepy-crawly creatures (Proceedings): https://www.dvm360.com/view/venomous-varmints-and-other-creepy-crawly-creatures-proceedings
[3] Successful treatment of Bufo marinus intoxication in a dog: https://www.dvm360.com/view/toxicology-case-successful-treatment-bufo-marinus-intoxication-dog

## 预防措施

预防犬和猫的蟾蜍毒素暴露主要依靠环境控制和主人教育。与有毒蟾蜍的接触在温暖或温和的天气中最常见，特别是在6月至9月之间[1]。主人应该了解北美最危险的物种包括在佛罗里达州、夏威夷州和德克萨斯州发现的海蟾蜍（*Rhinella marina*）和西南部地区的科罗拉多河蟾蜍（*Inciliella alvarius*）[1][3]。

环境管理包括在蟾蜍活动高峰期限制户外活动，特别是在蟾蜍最活跃的黎明和黄昏时段[1]。宠物主人应检查户外区域，特别是蟾蜍可能聚集的水源和遮蔽的藏身处[3]。清除积水和消除吸引昆虫的户外照明等财产改造可以减少家庭周围的蟾蜍数量。

主人教育对于高风险地区至关重要。宠物主人必须理解，通过大量水冲洗进行立即的口腔去污是最关键的急救措施[1][5]。应急计划应包括随时可用的兽医联系信息，并了解迅速的兽医干预显著改善预后。

行为训练以阻止宠物在户外探索或用嘴咬陌生物体提供额外保护[2]。在流行地区，在高风险期间进行监督的户外活动和牵绳散步代表实用的预防策略。

### Sources

[1] Toad Poisoning - Special Pet Topics: https://www.merckvetmanual.com/en-au/special-pet-topics/poisoning/toad-poisoning
[2] "Natural" does not mean "safe" (Proceedings): https://www.dvm360.com/view/natural-does-not-mean-safe-proceedings
[3] Flora and fauna: Hazardous biotoxins for pets (Proceedings): https://www.dvm360.com/view/flora-and-fauna-hazardous-biotoxins-pets-proceedings
[4] Successful treatment of Bufo marinus intoxication in a dog: https://www.dvm360.com/view/toxicology-case-successful-treatment-bufo-marinus-intoxication-dog
[5] Toad Poisoning in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/toad-poisoning/toad-poisoning-in-dogs-and-cats

## 鉴别诊断

蟾蜍毒素中毒症的临床表现可模仿许多其他疾病，使鉴别诊断对适当治疗至关重要。最重要的鉴别诊断包括其他引起类似神经系统和心血管表现的毒素[1]。

**毒理学鉴别诊断**包括中暑，它与蟾蜍中毒共有高热和神经系统体征[1]。金属dehyde中毒产生类似的肌肉震颤、感觉过敏和癫痫发作，但通常表现出更明显的胃肠道体征和代谢性酸中毒[1][4]。士的宁中毒导致伸肌强直和强直性癫痫发作，但动物对外部刺激保持反应，不像金属dehyde中毒中看到的持续惊厥[6]。有机磷和氨基甲酸酯杀虫剂产生毒蕈碱样体征，包括流涎过多和肌肉束颤，但通常表现为瞳孔缩小，而不是蟾蜍中毒症特征性的砖红色粘膜[5]。

**震颤性真菌毒素**（青霉震颤素A、罗克福菌素）引起类似的肌肉震颤和高热，但通常发生在摄入发霉材料之后[1][3]。甲基黄嘌呤中毒产生类似的过度活动、震颤和心律失常[1]。

**非毒理学鉴别诊断**包括原发性神经系统疾病、癫痫发作障碍和肝性脑病，这些疾病可表现为精神状态改变和癫痫发作，但缺乏蟾蜍中毒中特征性的电解质紊乱（钾和钙升高，磷、钠和氯降低）[1][2]。快速发作和户外暴露史有助于将蟾蜍中毒症与这些疾病区分开来。

### Sources

[1] Flora and fauna: Hazardous biotoxins for pets (Proceedings): https://www.dvm360.com/view/flora-and-fauna-hazardous-biotoxins-pets-proceedings

[2] Disorders of the Liver and Gallbladder in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats

[3] "Natural" does not mean "safe" (Proceedings): https://www.dvm360.com/view/natural-does-not-mean-safe-proceedings

[4] Merck Veterinary Manual Metaldehyde Poisoning in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/metaldehyde-poisoning/metaldehyde-poisoning-in-animals

[5] Merck Veterinary Manual Organophosphate Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/organophosphate-toxicosis-in-animals

[6] Merck Veterinary Manual Strychnine Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/strychnine-toxicosis/strychnine-toxicosis-in-animals
