# 宠物疾病：淋巴细胞增多症

淋巴细胞增多症的特征是淋巴细胞计数超过物种特异性参考范围，这代表了伴侣动物医学中一个重要的诊断挑战。这种情况可能由多种原因引起，从应激引起的生理反应到严重的潜在恶性肿瘤（如淋巴瘤）。理解反应性和肿瘤性淋巴细胞增多症之间的区别对兽医从业者至关重要，因为治疗方法差异巨大。本报告探讨了犬猫淋巴细胞增多症的致病机制、临床表现、诊断方法和治疗策略，为最佳患者护理和结果预测提供了循证指导。

## 疾病概述

**定义**：淋巴细胞增多症是指绝对淋巴细胞计数超过该物种和年龄动物参考上限（默克兽医手册）。在犬中，正常淋巴细胞计数通常为1,000-4,800个细胞/μL，而猫为1,500-7,000个细胞/μL（默克兽医手册）。绝对淋巴细胞计数是通过将白细胞总数乘以分类计数中观察到的淋巴细胞百分比计算得出的。

**流行病学背景**：淋巴细胞增多症发生在所有年龄段，但根据潜在病因表现出不同模式（默克兽医手册）。由兴奋或应激引起的生理性淋巴细胞增多症在幼年动物和猫中更常见，在处理过程中它们的淋巴细胞计数可能达到参考上限的两倍（默克兽医手册）。与慢性感染相关的病理性淋巴细胞增多症在中年动物中达到高峰，而肿瘤性原因主要影响7-8岁以上的老年患者（DVM360）。某些品种对淋巴增殖性疾病表现出易感性，尽管与人类研究相比，兽医医学中的综合流行病学数据仍然有限（默克兽医手册）。

## 常见病原体

伴侣动物的淋巴细胞增多症可由各种引起免疫缺陷或慢性炎症的病毒和细菌病原体引起。最重要的病毒原因包括猫的**猫白血病病毒(FeLV)**和**猫免疫缺陷病毒(FIV)** [1][2]。

**FeLV**是一种靶向淋巴细胞的逆转录病毒，导致深度免疫抑制，引起包括淋巴细胞增多症在内的各种血液学异常[1][2]。该病毒产生肿瘤性、免疫抑制性和骨髓抑制性疾病，不同亚型（FeLV-A、FeLV-B、FeLV-C和FeLV-T）引起不同的病理效应[2][3]。

**FIV**是另一种逆转录病毒，逐渐破坏CD4+ T辅助淋巴细胞，导致获得性免疫缺陷综合征[1][4]。该病毒靶向淋巴细胞并导致细胞介导免疫的进行性丧失，这可能表现为包括淋巴细胞增多症在内的淋巴细胞群体改变[1]。

**犬瘟病毒**感染并杀死犬体内的淋巴细胞，导致严重的联合免疫缺陷和相关淋巴样异常[1]。此外，犬猫的**细小病毒感染**引起急性白细胞减少，但在恢复期间可能出现反应性淋巴细胞增多症[1]。

其他可影响淋巴细胞群体的病毒因子包括**牛免疫缺陷样病毒**，该病毒已从持续性淋巴细胞增多症的牛中分离出来[1]。

### Sources

[1] Secondary Immunodeficiencies in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/secondary-immunodeficiencies-in-animals
[2] Feline Leukemia Virus Disease: https://www.merckvetmanual.com/infectious-diseases/feline-leukemia-virus/feline-leukemia-virus-disease
[3] FeLV/FIV (Proceedings): https://www.dvm360.com/view/felvfiv-proceedings
[4] FeLV and FIV: testing... diagnosing... preventing: https://www.dvm360.com/view/felv-and-fiv-testing-diagnosing-preventing-proceedings

## 临床症状和体征

现有章节内容提供了淋巴细胞增多症临床表现的全面概述。我将通过结合来源材料中额外的兽医特异性形态学细节和物种模式来扩展这一基础。

伴侣动物的淋巴细胞增多症很少表现出疾病特异性临床体征，因为症状通常反映潜在病因条件而非升高的淋巴细胞计数本身[1]。然而，某些模式有助于诊断鉴别。

**常见表现**通常包括淋巴结病（淋巴结肿大），根据病因可能是区域性或全身性的[1]。脾肿大常伴随淋巴细胞增多症，特别是在涉及全身感染或血液恶性肿瘤的病例中[1]。发热、嗜睡和食欲不振是非特异性但常见的发现[1]。

**形态学淋巴细胞变化**在血涂片上可观察到，提供重要诊断线索。反应性淋巴细胞具有增加的、明显嗜碱性的细胞质，可能有不规则或裂隙的细胞核[2]。这些细胞直径差异很大，但具有浓缩的染色质，与母细胞区分开来[2]。颗粒性淋巴细胞含有淡蓝灰色细胞质和几个小的粉色或嗜天青颗粒，可能代表自然杀伤细胞或T淋巴细胞[2]。如果检查发现原淋巴细胞和/或母细胞，淋巴细胞白血病就成为工作诊断[2]。

**品种易感性**存在于某些淋巴增殖性疾病中，尽管综合兽医数据仍然有限[1]。**犬猫之间的物种差异**包括正常淋巴细胞范围和兴奋反应的变化，猫在处理应激期间表现出明显的淋巴细胞增多症，可能达到参考上限的两倍[3]。

### Sources
[1] Leukogram Abnormalities in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[2] Three-minute peripheral blood film evaluation: The leukon: https://www.dvm360.com/view/three-minute-peripheral-blood-film-evaluation-leukon
[3] Clinical Hematology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology

## 诊断方法

伴侣动物淋巴细胞增多症的诊断需要采用多种诊断方式的综合方法[1]。初步评估从临床表现评估开始，兽医必须认识到淋巴细胞增多症通常与其他血液学异常一起出现，而非孤立存在。

实验室检测构成淋巴细胞增多症诊断的基石。全血细胞计数(CBC)与白细胞分类计数是必需的，提供应与物种特异性参考值对比解释的绝对淋巴细胞计数[2]。血涂片评估应伴随每次CBC，因为它揭示自动化分析仪无法检测的形态学变化，包括反应性淋巴细胞、颗粒性淋巴细胞和母细胞[4]。

流式细胞术已成为一种强大的诊断工具，特别用于表征淋巴增殖性疾病[1,5]。该技术分析细胞表面标记和物理特征，能够区分良性和恶性淋巴细胞群体。最新研究证明流式细胞术在猫淋巴瘤诊断中的有效性，与细胞学评估达到82%的一致性[1]。

对于需要明确淋巴瘤诊断的病例，抗原受体重排聚合酶链反应(PARR)检测可检测克隆性淋巴细胞群体[5,6]。PARR可在细胞学标本上进行，对淋巴瘤检测的敏感性为68-90%，尽管阴性结果不能排除恶性肿瘤[6,9]。

当怀疑淋巴增殖性疾病时，先进影像学可支持淋巴细胞增多症评估。腹部超声检查可揭示器官肿大、淋巴结病或肿块，这些需要进行细针穿刺进行细胞学检查[9]。

### Sources
[1] Flow cytometry and clonality evaluation are effective for characterizing feline lymphoma: https://www.dvm360.com/view/flow-cytometry-and-clonality-evaluation-are-effective-for-characterizing-feline-lymphoma
[2] Leukogram Abnormalities in Animals: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[3] Lymphoma in Dogs: https://www.merckvetmanual.com/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs
[4] Why a blood smear evaluation should be performed with every CBC: https://www.dvm360.com/view/why-a-blood-smear-evaluation-should-be-performed-with-every-cbc
[5] Applications of flow cytometry in companion animal medicine: https://www.dvm360.com/view/applications-of-flow-cytometry-in-companion-animal-medicine
[6] Feline lymphoma: diagnosis and treatment: https://www.dvm360.com/view/feline-lymphoma-diagnosis-and-treatment
[7] Cancer testing: beyond the biopsy (Proceedings): https://www.dvm360.com/view/cancer-testing-beyond-biopsy-proceedings
[8] Early detection of cancer requires persistent checks: https://www.dvm360.com/view/early-detection-cancer-requires-persistent-checks
[9] Gastrointestinal Neoplasia in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/neoplasia-of-the-gastrointestinal-tract-in-small-animals/gastrointestinal-neoplasia-in-dogs-and-cats

## 治疗选择

犬猫淋巴细胞增多症的治疗方法根据潜在病因差异很大(1)。对于**反应性淋巴细胞增多症**，治疗重点在于解决原发性炎症或感染性疾病，而非淋巴细胞增多症本身。糖皮质激素仍然是免疫抑制治疗的基石，通过减少炎症相关基因转录和下调细胞膜粘附蛋白，提供快速、非特异性的免疫系统抑制(1)。

**联合免疫抑制方案**通常比单一疗法更有效。硫唑嘌呤(2 mg/kg/天口服)是患有免疫介导性疾病犬的重要类固醇节约剂，尽管需要1-2周达到治疗水平(1)。环孢素以5-10 mg/kg分两次每日给药提供选择性T细胞抑制，血浆谷浓度目标为200 mg/ml以上(1)。在猫中，环孢素剂量差异显著，移植应用为每只猫2.5-5.0 mg每12小时一次(2)。

对于与淋巴瘤相关的**肿瘤性淋巴细胞增多症**，全身化疗方案是必需的。猫的低级别胃肠道淋巴瘤对泼尼松联合苯丁酸氮芥治疗反应良好(1)。高级别淋巴瘤需要积极的多药方案如CHOP，在犬中达到接近90%的反应率(1)。

**支持性护理措施**包括通过肠内喂养管为慢性病例提供营养支持，特别是胃肠道受累猫的钴胺素补充，以及定期全血细胞计数监测，根据患者反应和耐受性指导剂量调整(1)。

### Sources

[1] Immunosuppressive drugs: Beyond glucocorticoids: https://www.dvm360.com/view/immunosuppressive-drugs-beyond-glucocorticoids

[2] Immunosuppressive therapy in small animals (Proceedings): https://www.dvm360.com/view/immunosuppressive-therapy-small-animals-proceedings

## 预防措施

淋巴细胞增多症的预防主要集中于传染性病因的疫苗接种方案和实施环境控制以减少疾病传播。定期筛查对早期发现和干预至关重要[1]。

**疫苗接种仍然是预防**伴侣动物病毒性淋巴细胞增多症的基石。遵循AAHA和AAFP指南的核心疫苗提供对常见亲淋巴病毒的保护[2]。FeLV疫苗接种被推荐为幼猫的核心疫苗，2020年AAHA/AAFP指南建议对一岁以下的猫进行疫苗接种[3]。初始疫苗接种包括在8-9周龄开始间隔2-3周接种两剂，然后每年加强免疫[1][4]。

**环境控制措施**包括在兽医设施和多宠物家庭中保持适当的卫生规程。兽医标准预防措施汇编强调通过适当的个人防护设备和消毒程序减少人畜共患病原体传播[1]。隔离受感染动物可防止可能引起反应性淋巴细胞增多症的传染性病原体水平传播。疫苗接种前检测和所有猫的FeLV和FIV状态常规筛查有助于在将它们引入家庭前识别受感染动物[4][5]。

**定期健康监测**通过老年猫每半年一次检查和年度健康访视，使能够早期发现可能触发淋巴细胞增多症的潜在疾病[2]。预防护理指南建议常规血液学筛查，特别是七岁以上的猫，以在临床症状出现前识别具有临床意义的异常[2]。

### Sources
[1] A Perspective on Changes in Vaccine Protocols: https://www.dvm360.com/view/perspective-changes-vaccine-protocols
[2] To save cats: Why practices should maximize preventive care: https://www.dvm360.com/view/save-cats-why-practices-should-maximize-preventive-care
[3] Feline Leukemia Virus (FeLV) - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/disorders-affecting-multiple-body-systems-of-cats/feline-leukemia-virus-felv
[4] FeLV and FIV: testing...diagnosing...preventing (Proceedings): https://www.dvm360.com/view/felv-and-fiv-testingdiagnosingpreventing-proceedings
[5] Feline Leukemia Virus Disease: https://www.merckvetmanual.com/infectious-diseases/feline-leukemia-virus/feline-leukemia-virus-disease
