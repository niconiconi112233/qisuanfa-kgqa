# 伴侣动物瞬膜软骨外翻

瞬膜软骨外翻是一种影响犬猫第三眼睑的构象异常，特别常见于圣伯纳犬和大丹犬等大型犬种。当软骨成分之间的生长速率差异导致T形软骨发展为卷曲状畸形时，就会发生此病症，从而破坏正常泪膜分布并引起眼部刺激。与更常见的"樱桃眼"（涉及腺体脱垂）不同，软骨外翻特异性地影响结构性软骨框架本身。本综合报告探讨了这种品种特异性眼病的临床表现、诊断方法、手术治疗选择和长期预后，该病症需要及时手术干预以获得最佳效果。

## 疾病概述

瞬膜软骨外翻是一种影响犬猫第三眼睑（瞬膜）的构象异常[1]。第三眼睑包含T形透明软骨，用于强化其结构，软骨柱围绕眼球下内侧弯曲，横梁则加固游离边缘以适应角膜形状[1]。

当软骨的睑部和球部之间出现差异生长速率时，就会发生此病症，导致软骨发展为卷曲或弯曲构型[1]。由此产生的外翻破坏了正常的第三眼睑解剖结构和功能。

**品种易感性：** 某些大型犬种表现出更高的易感性，包括圣伯纳犬、大丹犬和纽芬兰犬[1]。该病症在巨型犬种中似乎更为普遍，但兽医文献中特定的患病率数据有限。

**年龄和物种：** 虽然年龄特异性数据尚未广泛记录，但该病症可影响各年龄段的犬。其发育性质表明，它可能在软骨成熟速率不同的生长期表现出来。

### Sources
[1] Image Quiz: Can you name that ophthalmologic condition?: https://www.dvm360.com/view/image-quiz-can-you-name-ophthalmologic-condition

## 临床表现与诊断

瞬膜软骨外翻表现为第三眼睑软骨的可见褶皱或卷曲，导致结膜充血和眼部分泌物增加[1]。该病症主要影响大型犬种，特别是圣伯纳犬、大丹犬和纽芬兰犬，是由于T形软骨的睑部和球部之间生长速率差异所致[1]。

该病症很容易与樱桃眼区分，后者涉及瞬膜腺体脱垂，表现为第三眼睑后的红色肿块[2][7]。与樱桃眼特有的红色、肿胀腺体外观不同，软骨外翻表现为软骨本身异常弯曲或卷曲，形成卷曲状畸形。樱桃眼表现为腺体本身的肥大、炎症和脱垂，常见于幼犬和某些品种，如比格犬、波士顿梗和斗牛犬[9]。

临床检查显示，由于软骨畸形，泪膜无法正常分散到角膜上[1]。诊断主要基于常规眼科检查期间的目视检查，应包括在良好光线下从2-3英尺外评估对称性、正常构型和明显病变[3]。

标准诊断测试如希林泪液测试、荧光素染色和眼压测量有助于评估继发并发症，但软骨外翻的诊断依赖于对畸形软骨结构的直接观察[3]。诊断不需要特定的影像学或实验室检查，因此是基于特征性外观和品种易感性的临床诊断。

### Sources

[1] Image Quiz: Can you name that ophthalmologic condition?: https://www.dvm360.com/view/image-quiz-can-you-name-ophthalmologic-condition
[2] Skills Laboratory: Prolapsed third eyelid gland replacement: https://www.dvm360.com/view/skills-laboratory-prolapsed-third-eyelid-gland-replacement
[3] Merck Veterinary Manual Physical Examination of the Eye in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals
[4] Merck Veterinary Manual Image:Prolapse, gland of third eyelid, dog: https://www.merckvetmanual.com/multimedia/image/prolapse-gland-of-third-eyelid-dog
[5] Merck Veterinary Manual Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals

## 治疗与管理

瞬膜软骨外翻的治疗需要手术矫正作为确定性方法[1]。保守的药物治疗通常对这种机械性畸形无效。

**手术技术**
主要治疗涉及切除外翻的软骨部分，同时保留瞬膜的功能[2]。该手术通常需要仔细解剖，仅切除卷曲或外翻的软骨段。一些兽医可能采用类似于治疗眼睑疾病的技术，使用精密手术器械重塑或切除有问题的软骨[2]。

**术后护理**
手术后，局部使用抗生素以预防继发性细菌感染[2]。可开具抗炎药物以减少术后肿胀和不适。定期监测对于评估愈合进展和检测潜在并发症至关重要。

**潜在并发症**
手术并发症可能包括软骨切除不完全导致复发、邻近结构损伤或继发感染[3]。在发生广泛组织损伤的严重病例中，可能需要更复杂的重建手术。

**预防**
由于该病症通常具有遗传成分，繁育计划应考虑对受影响动物进行筛查。早期识别和及时手术干预有助于预防继发性并发症，如持续性刺激引起的慢性结膜炎或角膜损伤。

### Sources
[1] Merck Veterinary Manual Disorders of the Eyelids in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-eyelids-in-dogs
[2] Merck Veterinary Manual The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[3] Merck Veterinary Manual Proptosis in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/proptosis-in-small-animals

## 预后与长期结果

瞬膜软骨外翻的预后因治疗方法和干预时机而异显著。及时进行手术矫正通常能获得极好的结果，复发率低[1]。大多数犬猫在适当的外翻软骨手术复位后，临床症状完全缓解。

长期成功取决于几个因素。在继发并发症发展前进行早期干预对获得最佳结果至关重要[1]。伴有第三眼睑腺体脱垂的病例可能需要更复杂的手术要求，但当同时处理两种病症时，通常仍能保持良好预后[2]。

采用适当技术时，手术矫正后复发不常见[2]。然而，手术矫正不完全或未能解决潜在构象因素可能导致再次外翻。单独保守治疗通常会导致临床症状持续和进行性角膜损伤。

不治疗该病症通常会导致慢性眼部刺激、角膜溃疡和继发性细菌感染[1]。这些并发症会显著影响长期眼部健康和舒适度。大多数动物在术后2-3周内恢复正常活动水平，通常在4-6周内完全愈合。具有复杂软骨畸形的大型犬可能需要额外的软骨切除术，但通过适当手术管理，总体预后仍然良好[2]。

### Sources
[1] Characterization and outcome following excision of masses in: https://avmajournals.avma.org/downloadpdf/view/journals/javma/245/7/javma.245.7.812.pdf
[2] VIN Surgical Management of Third Eyelid Problems in Dogs - WSAVA2007 - VIN: https://www.vin.com/apputil/content/defaultadv1.aspx?id=3860708&pid=11242
