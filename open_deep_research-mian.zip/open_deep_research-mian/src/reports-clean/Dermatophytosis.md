# 犬猫皮肤癣菌病：兽医综合指南

皮肤癣菌病，通常称为"癣"，尽管在所有皮肤疾病中占比不到4%，但在小动物诊疗中构成了显著的人畜共患病问题。这种浅表真菌感染影响犬猫的角化结构，其中犬小孢子菌是主要病原体。该疾病在健康动物中具有自限性，但通过直接接触和环境污染物对其他宠物和人类具有高度传染潜力。本报告探讨了从局限性脱毛到全身性感染的临床表现，包括伍德灯检查和真菌培养在内的诊断方法，结合全身性抗真菌药物与局部治疗的多模式治疗策略，以及在兽医实践中防止再感染和控制传播所必需的关键环境消毒方案。

## 疾病概述

皮肤癣菌病，通常称为"癣"，是伴侣动物皮肤、毛发，偶尔还有爪子的浅表真菌感染[1]。这种人畜共患病影响角化结构，在健康动物中被认为是自限性的，尽管它对其他宠物和人类构成显著的传染风险[2]。

犬猫中的主要致病因子包括犬小孢子菌、石膏样小孢子菌（现分类为石膏样纳米孢菌）和须毛癣菌[1,2]。犬小孢子菌是最常见的病原体，特别适应于猫和狗，并在动物宿主的环境中存活[1,3]。石膏样小孢子菌是生活在土壤中的亲土性生物，而须毛癣菌是亲动物性的，以小型啮齿动物为储存宿主[1,3]。

传播通过与受感染动物或含有孢子的污染物直接接触发生[2,7]。在孢子暴露充足、皮肤微创伤和潮湿的理想条件下，环境孢子可在6-8小时内萌发[2]。患病率相对较低，占所有皮肤疾病的不到4%，这与普遍看法相反[2]。风险因素包括年龄小、过度拥挤、生理压力和温暖环境[2,6]。

### Sources
[1] Dermatophyte and deep fungal infections (Proceedings): https://www.dvm360.com/view/dermatophyte-and-deep-fungal-infections-proceedings
[2] Dermatophytosis in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[3] How to perform and interpret dermatophyte cultures: https://www.dvm360.com/view/how-perform-and-interpret-dermatophyte-cultures
[4] Ringworm-diagnostics, treatment, and management strategies (Proceedings): https://www.dvm360.com/view/ringworm-diagnostics-treatment-and-management-strategies-proceedings
[5] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[6] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[7] Clinical Exposures: Canine dermatophyte infection: https://www.dvm360.com/view/clinical-exposures-canine-dermatophyte-infection

## 临床表现与诊断

皮肤癣菌病表现出多变的临床症状，包括脱毛、脱屑、结痂、红斑、丘疹、色素沉着和不同程度的瘙痒[1]。面部、耳朵、爪子和尾巴是最常见的受影响区域[3]。犬通常在受影响皮肤和正常皮肤之间表现出边界清晰的病变，而猫，特别是长毛品种，则发展为更广泛的感染[3]。

**伍德灯检查**
伍德灯（320-400纳米）对于识别被犬小孢子菌感染的毛发很有价值，这些毛发会发出明亮的苹果绿色荧光[1,3]。证据显示，91-100%的未治疗受感染动物有发光的毛发[1]。然而，并非所有皮肤癣菌种类都会发荧光，因此阴性结果不能排除感染[3]。

**直接显微镜检查**
在矿物油中对毛发和鳞屑进行直接检查可在超过85%的病例中确认感染[1]。受感染的毛发比正常毛发更粗，可能在毛干内显示真菌菌丝或在表面显示小分生孢子[1,3]。

**真菌培养和PCR**
使用皮肤癣菌测试培养基（DTM）进行的真菌培养仍然是物种鉴定的基础[1,3]。PCR检测提供快速结果，灵敏度>95%，特异性99%[3]。由于没有单一测试作为金标准，通常使用多种测试[1]。

**鉴别诊断**
鉴别诊断包括细菌感染、过敏性皮炎、寄生虫感染、如落叶型天疱疮等自身免疫性疾病，以及在面部病例中的猫疱疹病毒感染[2]。无论外观如何，伍德灯检查和真菌培养在所有面部皮炎病例中都是必需的[2]。

### Sources
[1] Dermatophytosis in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[2] CVC Highlight: Getting to the bottom of feline facial dermatitis: https://www.dvm360.com/view/cvc-highlight-getting-bottom-feline-facial-dermatitis/1000
[3] Dont let ringworm run rings around your veterinary patients: https://www.dvm360.com/view/don-t-let-ringworm-run-rings-around-your-veterinary-patients

## 治疗选择

有效的皮肤癣菌病管理需要结合全身性抗真菌治疗、局部治疗和环境消毒的多模式方法[1][2]。

**全身性抗真菌药物**构成治疗的基石。伊曲康唑是猫的首选一线治疗，剂量为5 mg/kg每日一次，采用一周用药一周停药的方案进行3-4个周期[2]。对于犬，推荐使用伊曲康唑5 mg/kg每日一次，直至真菌学治愈[2]。特比萘芬（30-40 mg/kg每日一次）为大型犬提供了经济有效的替代方案[2]。酮康唑可用于犬（5 mg/kg每日一次），但应避免用于猫，因为它会引起厌食[2][4]。

**局部治疗**是强制性的，因为它能消毒被毛并减少环境污染[2]。石灰硫磺药浴（1:16稀释）每周应用两次提供最有效的局部治疗，当与全身治疗结合时，约三周内达到临床缓解[2][7]。替代选择包括每周使用2-3次的咪康唑-氯己定洗发水（各2%），尽管这些比石灰硫磺效果较低[2][3]。

**环境消毒**防止来自存活孢子的再感染。通过彻底吸尘进行机械清除，然后使用对毛癣菌有效的浴室清洁剂进行表面消毒，可显著减少环境负担[2][5]。治疗持续时间在犬中通常为4-6周，在猫中可能需要3-4个治疗周期，持续直到真菌学治愈[2][4]。

### Sources
[1] A review of selected systemic antifungal drugs for use in dogs and cats: https://www.dvm360.com/view/review-selected-systemic-antifungal-drugs-use-dogs-and-cats
[2] Dermatophytosis in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[3] Prevention and treatment of dermatologic fungal disease in dogs and cats: https://www.dvm360.com/view/prevention-and-treatment-of-dermatologic-fungal-disease-in-dogs-and-cats
[4] Antifungals for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antifungals-for-integumentary-disease-in-animals
[5] Treatment of Canine and Feline Dermatophytosis: https://www.dvm360.com/view/treatment-of-canine-and-feline-dermatophytosis
[6] Time for topicals: A spot-on guide to treating dermatologic diseases: https://www.dvm360.com/view/time-for-topicals-a-spot-on-guide-to-treating-dermatologic-diseases
[7] Tackling feline ear disease, dermatophytosis: https://www.dvm360.com/view/tackling-feline-ear-disease-dermatophytosis

## 预防与预后

**预防措施**

目前没有可用于预防皮肤癣菌病的疫苗[1]。控制主要依靠环境管理和早期检测。隔离受感染动物对防止传播至关重要，因为无症状携带者可将感染传播给其他宠物和人类[1]。环境消毒需要积极清除受污染的毛发和碎屑，然后用1:10漂白剂溶液消毒，该溶液已被证明对孢子100%有效[2]。

在接收检查期间定期进行伍德灯筛查有助于早期识别病例，特别是在收容所等高风险环境中[2]。**需要局部治疗，因为它能消毒被毛**并最大限度地减少环境污染[1]。适当的卫生方案和早期识别可疑病变可降低传播风险。

**预后**

皮肤癣菌病在适当治疗下的预后通常极好[3]。大多数病例在使用全身性和局部治疗联合治疗时在3-6个月内解决[3]。**感染在适当治疗下需要6-12周才能解决**[1]。年轻、健康的动物通常比免疫功能不全的患者恢复得更快。

**在健康动物中，皮肤癣菌病通常是自限性疾病，在发展出适当的细胞介导免疫反应后会完全解决**[4]。在免疫功能正常的动物中，这通常需要100天[4]。治疗持续时间从14天到6个月不等，通过连续真菌培养监测，直到获得两个连续阴性结果[3]。在成功治疗和环境消毒后，复发并不常见。

### Sources
[1] Dermatophytosis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[2] Clinical Exposures: Canine dermatophyte infection: https://www.dvm360.com/view/clinical-exposures-canine-dermatophyte-infection
[3] Shelter Snapshot: Evidence-based answers to your dermatophytosis questions: https://www.dvm360.com/view/shelter-snapshot-evidence-based-answers-your-dermatophytosis-questions
[4] Guinea Pigs - Exotic and Laboratory Animals: https://www.merckvetmanual.com/exotic-and-laboratory-animals/rodents/guinea-pigs
