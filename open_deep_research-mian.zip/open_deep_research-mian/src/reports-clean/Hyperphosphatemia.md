# 伴侣动物的高磷血症

高磷血症是兽医实践中的一种重要代谢紊乱，当犬猫的血清磷浓度超过正常生理范围时发生。这种情况最常见于慢性肾脏病的继发，影响高达85%的晚期肾功能不全患者，但也可能由内分泌疾病、饮食因素和组织分解综合征引起。其临床意义不仅限于简单的电解质失衡，持续的高磷血症会促进心血管并发症、软组织矿化，并缩短患病动物的生存时间。本报告探讨了磷失调的病理生理机制、包括IRIS分期标准的诊断方法、结合饮食管理与磷结合剂的综合治疗策略，以及影响伴侣动物临床预后的因素。

## 病理生理学与病因

现有部分为理解伴侣动物高磷血症病理生理学提供了全面基础。在此框架基础上，该病症的复杂性超出了既定机制，包含了兽医实践中特有的其他致病因素。

维生素D中毒是一个重要原因，同时产生高钙血症和高磷血症[3]。与其他原因不同，维生素D毒性增加钙和磷的肠道吸收，形成独特的病理生理模式，动物表现为两种矿物质同时升高[6]。这是通过增强胃肠道吸收和增加肾脏对磷的重吸收实现的[3]。

甲状旁腺功能减退症，无论是原发性还是继发性，都通过肾脏无法抑制肾近端小管磷重吸收而导致高磷血症[5]。原发性甲状旁腺功能减退症通常由甲状旁腺切除术或甲状旁腺功能障碍引起，而假性甲状旁腺功能减退症则造成靶器官对甲状旁腺激素的抵抗[5]。

跨细胞磷转移在组织分解过程中导致高磷血症。肿瘤溶解综合征、横纹肌溶解和严重溶血将细胞内磷释放到细胞外液中，超过正常的肾脏排泄机制[4]。这些情况通常伴有其他电解质异常，包括高钾血症和高尿酸血症[5]。

钙磷乘积在超过60时具有临床意义，易导致软组织矿化和血管钙化[4][7]。这种病理生理关系是慢性高磷血症中常见心血管并发症的基础，特别是在伴有肾脏疾病的动物中。

### Sources

[1] Laboratory evaluation of kidney disease: https://www.dvm360.com/view/laboratory-evaluation-kidney-disease
[2] The role of phosphorus in feline chronic renal disease: https://www.dvm360.com/view/role-phosphorus-feline-chronic-renal-disease-proceedings
[3] Hyperphosphatemia : Practice Essentials, Background, ...: https://emedicine.medscape.com/article/241185-overview
[4] Potassium, phosphorus, and calcium treatment of severe abnormalities (Proceedings): https://www.dvm360.com/view/potassium-phosphorus-and-calcium-treatment-severe-abnormalities-proceedings
[5] Hyperphosphatemia - StatPearls - NCBI Bookshelf: https://www.ncbi.nlm.nih.gov/books/NBK551586/
[6] Diagnostic procedures (Proceedings): https://www.dvm360.com/view/diagnostic-proceedings-proceedings
[7] Therapeutic implications of recent findings in feline renal insufficiency: https://www.dvm360.com/view/therapeutic-implications-recent-findings-feline-renal-insufficiency-proceedings

## 诊断方法

高磷血症的诊断主要依靠血清生化分析，使用标准实验室技术测量磷浓度。IRIS分期指南建立了特定的诊断阈值：对于IRIS 2期、3期和4期慢性肾脏病的犬，高磷血症分别定义为超过4.5、5.0和6.0 mg/dL的值[1]。

由于肾脏排泄减少，高磷血症常见于急慢性肾脏病患者[3]。实验室评估应包括全血细胞计数、含电解质的全面生化分析和尿液分析，以评估浓缩能力并识别并发症，如尿路感染或结晶尿。

先进的诊断检测可能包括血浆成纤维细胞生长因子-23（FGF-23），这与慢性肾病犬的生存率相关，可能作为预后标志物[1]。甲状旁腺激素和离子化钙浓度有助于评估与高磷血症相关的继发性肾性甲状旁腺功能亢进[8]。

影像学研究支持诊断评估，但对高磷血症并不特异。腹部X线片可能显示肾结石或输尿管结石，而肾脏超声可以评估结构异常[3]。这些影像学模式有助于识别潜在原因和并发症，而不是直接诊断高磷血症本身。

早期检测依赖于常规生化筛查，因为临床症状通常在肾功能显著丧失后才出现。

### Sources

[1] A New Marker for Chronic Kidney Disease in Dogs?: https://www.dvm360.com/view/a-new-marker-for-chronic-kidney-disease-in-dogs
[2] Feeding pets with renal disease (Proceedings): https://www.dvm360.com/view/feeding-pets-with-renal-disease-proceedings
[3] Laboratory evaluation of kidney disease: https://www.dvm360.com/view/laboratory-evaluation-kidney-disease
[4] Hyperphosphatemia in Animals - Metabolic Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-phosphorus-metabolism/hyperphosphatemia-in-animals

## 治疗策略

全面的高磷血症管理需要结合饮食限制、磷结合剂、液体支持和仔细监测的多模式方法[1][2]。主要目标是维持血清磷浓度低于分期特定目标，以防止肾性继发性甲状旁腺功能亢进和组织矿化。

**饮食管理与磷结合剂**
限磷肾脏饮食是治疗的基石，为慢性肾病犬猫提供显著的生存益处[1][3]。当单独饮食限制不足时，肠道磷结合剂变得必不可少。铝基制剂（氢氧化铝、碳酸铝）仍然是20-30 mg/kg每8小时一次的高效一线选择[4]。钙基替代品包括碳酸钙和醋酸钙，但监测高钙血症至关重要[5]。较新的选择如碳酸镧（Fosrenol）和碳酸钙-壳聚糖组合（Epakitin）提供了额外的治疗选择[3][4]。

**液体疗法和支持性护理**
在晚期病例中，皮下液体给药变得至关重要，通常对平均体型的猫使用乳酸林格氏液，每日75-150毫升[1]。这有助于维持水合状态并支持毒素消除。同时管理包括用于尿毒症性胃炎的H2受体阻滞剂、用于低钾血症的钾补充剂，以及当碳酸氢盐水平降至15-16 mEq/L以下时的碱化剂[4][6]。

**监测方案**
一旦达到目标，治疗反应需要每3-4个月进行一次定期评估，在初始治疗阶段监测更频繁[3]。目标磷浓度根据IRIS分期而异：低于4.5 mg/dl（II期）、低于5.0 mg/dl（III期）和低于6.0 mg/dl（IV期）[6]。连续PTH测量提供了评估磷负担缓解的金标准[5]。

### Sources
[1] Chronic kidney disease in cats (Proceedings): https://www.dvm360.com/view/chronic-kidney-disease-cats-proceedings-1
[2] Staging and management of chronic kidney disease: https://www.dvm360.com/view/staging-and-management-chronic-kidney-disease-proceedings  
[3] 11 guidelines for conservatively treating chronic kidney: https://www.dvm360.com/view/11-guidelines-conservatively-treating-chronic-kidney-disease
[4] The technician's role in outpatient management of chronic: https://www.dvm360.com/view/technicians-role-outpatient-management-chronic-kidney-disease-proceedings
[5] The role of phosphorus in feline chronic renal disease: https://www.dvm360.com/view/role-phosphorus-feline-chronic-renal-disease-proceedings
[6] Updates in outpatient management of chronic kidney: https://www.dvm360.com/view/updates-outpatient-management-chronic-kidney-disease-proceedings

## 鉴别诊断与预后

### 鉴别诊断

高磷血症可能模拟其他几种代谢紊乱，需要仔细的诊断鉴别。最重要的鉴别诊断是慢性肾脏病，也表现为磷升高，但以同时存在氮质血症和肾小球滤过率降低为特征[1]。三发性甲状旁腺功能亢进表现为高钙血症和高磷血症，而原发性高磷血症通常显示正常钙水平[1]。

猫的甲状腺功能亢进症可能因骨转换增加而在约20%的病例中表现为高磷血症，但以T4水平升高和包括体重减轻和多食在内的特征性临床症状为鉴别点[2]。甲状旁腺功能减退症因肾脏磷重吸收增加而导致高磷血症，但以同时存在低钙血症和低PTH水平为鉴别特征[1]。

溶血样本可能因红细胞释放细胞内磷而错误地升高磷测量值，强调了正确样本处理的重要性[1]。血液浓缩和细胞内摄取减少也可能呈现类似的磷升高模式[1]。

### 预后

高磷血症的预后完全取决于潜在原因和治疗反应。在慢性肾脏病继发病例中，预后与IRIS分期相关，IV期患者的中位生存时间仅为97天，而II期患者为763天[3]。

早期识别和适当管理显著改善结果。当通过磷结合剂和饮食调整适当管理时，许多患者可以维持可接受的生活质量[3]。然而，持续的高磷血症可导致钙磷盐沉淀，导致骨骼外组织矿化，可能造成致命后果[1]。

### Sources
[1] Merck Veterinary Manual - Hyperphosphatemia in Animals: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-phosphorus-metabolism/hyperphosphatemia-in-animals
[2] Chronic kidney disease in cats (Proceedings): https://www.dvm360.com/view/chronic-kidney-disease-cats-proceedings-1
[3] Updates in feline chronic kidney disease: https://www.dvm360.com/view/updates-feline-chronic-kidney-disease-proceedings
