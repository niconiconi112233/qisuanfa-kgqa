# 伴侣动物淋巴细胞减少症

淋巴细胞减少症的特征是绝对淋巴细胞计数低于正常参考范围，是小动物兽医实践中最常见的白细胞疾病之一。这种血液学异常显著影响犬和猫的免疫功能，导致感染易感性增加和疫苗反应受损。该病症源于多种病因，从应激引起的淋巴细胞重新分布到直接破坏淋巴细胞的病毒感染。本报告探讨了淋巴细胞减少症的全面兽医诊疗方法，包括犬细小病毒和猫泛白细胞减少症等病毒病原体、流式细胞术和PCR检测等诊断方法、使用免疫抑制疗法的治疗方案，以及对于最佳患者结果至关重要的预防性疫苗接种策略。

## 疾病概述与常见病原体

淋巴细胞减少症定义为绝对淋巴细胞计数低于该物种的正常参考范围[1]。在犬中，正常淋巴细胞计数范围为0.4-2.9 × 10³/mcL，而在猫中为1.5-7.0 × 10³/mcL[2]。这种血液学异常是小动物实践中最常见的白细胞疾病之一[3]。

**疾病概述**

淋巴细胞减少症最常见的原因是循环糖皮质激素增加，无论是来自应激或疾病的内源性，还是来自治疗性给药的外源性[5]。这种应激性淋巴细胞减少症是通过淋巴细胞从循环重新分布到淋巴组织，而非实际细胞破坏发生的[4]。淋巴细胞减少症也可由病毒感染、骨髓抑制或免疫介导的破坏引起[5]。

**病毒病原体**

几种病毒感染在伴侣动物中引起显著的淋巴细胞减少症。犬细小病毒和猫泛白细胞减少症病毒直接靶向快速分裂的淋巴细胞，导致严重的免疫抑制[5]。猫白血病病毒(FeLV)和猫免疫缺陷病毒(FIV)通过免疫系统功能障碍和骨髓抑制引起慢性淋巴细胞减少症[6]。犬瘟病毒通过对淋巴组织的直接影响产生淋巴细胞减少症[5]。

**细菌和其他病原体**

犬埃立克体感染通常通过免疫介导机制和骨髓效应引起淋巴细胞减少症和血小板减少症[5]。其他立克次体生物和严重细菌感染可通过骨髓抑制或在 overwhelming 炎症反应中增加消耗来减少淋巴细胞计数[5]。

### Sources
[1] Hematology (Complete Blood Count) Reference Ranges: https://www.merckvetmanual.com/multimedia/table/hematology-complete-blood-count-reference-ranges
[2] Hematology Reference Ranges: https://www.merckvetmanual.com/reference-values-and-conversion-tables/reference-guides/hematology-reference-ranges
[3] Clinical Hematology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[4] Clinical Hematology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[5] Leukogram Abnormalities in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[6] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs

## 临床症状、体征和诊断方法

犬和猫的淋巴细胞减少症通常表现出与潜在疾病相关的微妙临床症状，而非低淋巴细胞计数的特异性症状。受影响的动物可能表现出感染易感性增加、伤口愈合延迟和疫苗反应差，这是由于免疫功能受损所致[1]。全身性体征包括嗜睡、虚弱和复发性细菌或病毒感染。

体格检查结果通常是非特异性的，反映了引起淋巴细胞减少症的原发疾病。尽管存在外周淋巴细胞减少症，但在某些淋巴瘤病例中可能反而出现全身性淋巴结肿大[2]。当骨髓浸润或全身性疾病是潜在原因时，可能存在肝脾肿大。

诊断评估集中在全血细胞计数(CBC)和手工分类计数上，以确认绝对淋巴细胞计数低于参考范围（犬通常<1,000个细胞/μL，猫<1,500个细胞/μL）。血涂片检查显示小淋巴细胞数量减少，并可能显示非典型或异常淋巴细胞[2]。

流式细胞术能够进行详细的淋巴细胞亚群分析，并可以识别特定的T细胞或B细胞缺陷[2][3]。这种先进技术测量包括大小、复杂性和表面标记表达在内的物理特征，以区分淋巴细胞群体。

有趣的是，患有发热和猫传染性腹膜炎的猫通常表现为淋巴细胞减少症，这与最近在弓形虫病和巴尔通体病中报告的淋巴细胞增多症形成对比[4]。在肾上腺皮质功能减退症病例中，由于皮质醇缺乏，可能会注意到应激白细胞象（包括淋巴细胞减少症和嗜酸性粒细胞减少症）的缺失[5]。

其他检测包括当怀疑原发性骨髓疾病时的骨髓抽吸或活检，以及可能抑制淋巴细胞产生或引起破坏的传染性病原体的PCR检测。

### Sources
[1] IMHA: Diagnosing and treating a complex disease: https://www.dvm360.com/view/imha-diagnosing-and-treating-complex-disease
[2] Lymphoma in Dogs - Circulatory System: https://www.merckvetmanual.com/en/circulatory-system/lymphoma-in-dogs/lymphoma-in-dogs
[3] Suspected primary bone marrow T-cell lymphoid neoplasia: https://avmajournals.avma.org/view/journals/javma/262/3/javma.23.07.0389.xml
[4] Managing and preventing feline febrile diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-febrile-diseases-proceedings
[5] Hypoadrenocorticism in the dog (Proceedings): https://www.dvm360.com/view/hypoadrenocorticism-dog-proceedings-0

## 治疗选择和预防措施

### 治疗选择

淋巴细胞减少症的治疗侧重于通过靶向药物干预解决潜在原因。糖皮质激素仍然是免疫介导性淋巴细胞减少症的主要免疫抑制疗法，由于生物利用度更高，在猫中优先使用泼尼松龙而非泼尼松(1)。泼尼松龙的抗炎剂量在犬和猫中为每天0.55-2.2 mg/kg，而免疫抑制剂量在猫中可扩展至每天4.4-8.8 mg/kg(4)。

替代性免疫抑制剂包括环孢素（目标谷浓度400-600 ng/ml）、硫唑嘌呤（在猫中禁用，因其可致致命性骨髓抑制），以及用于难治性病例的新型药物如霉酚酸酯和来氟米特(2)。对于继发于细小病毒感染的严重淋巴细胞减少症猫，支持性护理包括静脉输液疗法、止吐药如马罗匹坦（1 mg/kg皮下注射，每24小时一次）和广谱抗菌药物至关重要(5)。对于表现出营养不良迹象（包括被毛不良、肌肉萎缩或低白蛋白血症）的淋巴细胞减少症动物，应考虑营养支持(6)。应激性淋巴细胞减少症通常通过环境管理和减压方案得到解决。

### 预防措施  

预防中心在于针对引起淋巴细胞减少症的病毒病原体进行疫苗接种，包括猫白血病病毒、猫免疫缺陷病毒和犬细小病毒(7,8)。环境控制措施包括适当的卫生措施、隔离受感染动物以及对新到动物进行隔离检疫。定期监测全血细胞计数有助于早期发现淋巴细胞减少症的发展(4)。通过一致的常规、适当的居住环境和轻柔的处理来最小化应激，可减少应激引起的淋巴细胞重新分布。

### Sources

[1] Immunosuppressive therapy in small animals (Proceedings): https://www.dvm360.com/view/immunosuppressive-therapy-small-animals-proceedings-0
[2] Immunosuppressive drugs: Beyond glucocorticoids: https://www.dvm360.com/view/immunosuppressive-drugs-beyond-glucocorticoids  
[3] Erosive and ulcerative stomatitis in dogs and cats: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0573.xml
[4] Glucocorticoid use in cats: https://www.dvm360.com/view/glucocorticoid-use-cats
[5] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[6] Enteral feeding in dogs and cats: Indications, principles and techniques (Proceedings): https://www.dvm360.com/view/enteral-feeding-dogs-and-cats-indications-principles-and-techniques-proceedings
[7] Infectious diseases of the feline GI system (Proceedings): https://www.dvm360.com/view/infectious-diseases-feline-gi-system-proceedings
[8] Feline Panleukopenia - Digestive System: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia

## 鉴别诊断和预后

犬和猫淋巴细胞减少症的全面鉴别诊断需要区分几个关键病症。应激或皮质类固醇诱导的淋巴细胞减少症是最常见的原因，其特征为中性粒细胞增多、淋巴细胞减少、单核细胞增多和嗜酸性粒细胞减少[1][2]。这种模式源于内源性应激反应或外源性皮质类固醇给药，通常不伴有核左移或毒性变化[2]。

病毒感染构成另一个主要的鉴别诊断，各种病毒病原体通过直接破坏淋巴细胞引起暂时性淋巴细胞减少症[3]。猫泛白细胞减少症特别引起严重的淋巴细胞减少症和中性粒细胞减少，伴有发热、呕吐和脱水的特征性临床症状[4]。蛋白丢失性肠病可作为肠道蛋白质丢失的一部分产生淋巴细胞减少症，常伴有低白蛋白血症和体重减轻[5]。

必须考虑免疫缺陷疾病和造血肿瘤，特别是淋巴瘤，尤其是当淋巴细胞减少症持续存在或伴有其他临床异常时[3][6]。犬的胸腺瘤也可能作为其临床综合征的一部分表现为淋巴细胞减少症[6]。

预期临床结果因潜在病因而异很大。应激性淋巴细胞减少症通常通过消除潜在应激因素而解决，并具有极好的预后[1]。然而，与猫泛白细胞减少症等病毒疾病相关的淋巴细胞减少症预后不良，存活率仅为20-51%[4]。免疫缺陷综合征或晚期肿瘤性疾病具有谨慎到不良的预后，通常需要强化支持性护理和特定的治疗干预。

### Sources
[1] Corticosteroids in Animals: https://www.merckvetmanual.com/pharmacology/inflammation/corticosteroids-in-animals
[2] Inflammation, stress, or something else?: https://www.dvm360.com/view/inflammation-stress-or-something-else-
[3] Leukogram Abnormalities in Animals: https://www.merckvetmanual.com/circulatory-system/leukocyte-disorders/leukogram-abnormalities-in-animals
[4] Feline Panleukopenia: https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/feline-panleukopenia
[5] Protein-losing enteropathies: https://www.dvm360.com/view/protein-losing-enteropathies-proceedings-0
[6] Clinical features, treatment options, and outcome in dogs with thymoma: https://avmajournals.avma.org/view/journals/javma/243/10/javma.243.10.1448.xml
