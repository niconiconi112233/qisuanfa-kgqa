# 伴侣动物百合科植物中毒

百合科植物中毒是影响猫的最严重的兽医急症之一，即使是微量的真百合（*Lilium* 和 *Hemerocallis* 属）暴露也可能导致致命的急性肾损伤。这种情况独特地影响猫科动物，在其他伴侣动物中尚无毒性记录，因此环境意识对猫主人至关重要。最近的研究显示，急性肾损伤的发生率远高于之前认识到的，近一半的暴露猫会出现某种程度的肾功能损害。本综合报告探讨了百合诱导的肾毒性的病理生理学、临床表现模式、基于证据的治疗方案（包括新兴的门诊管理策略）以及关键的预防措施，这些措施可通过及时干预和主人教育来挽救猫的生命。

## 总结与临床意义

本报告揭示，百合中毒比历史上认识到的更为普遍，最近的研究显示，46.9%的暴露猫发展为急性肾损伤，而早期报告仅为9%。未鉴定的水溶性毒素影响植物的所有部分，在摄入后12-72小时内引起近端小管坏死。早期干预仍然是至关重要的，在6小时内治疗通过以2-3倍维持率进行积极的液体利尿可获得最佳结果。

| 治疗方法 | AKI发生率 | 存活率 | 主要优势 |
|-------------------|----------|---------------|---------------|
| 住院静脉输液 | 46.9% | 100% | 强化监测 |
| 门诊皮下输液 | 43.8% | 87.5% | 经济实惠的选择 |

可行的门诊方案的出现扩大了治疗的可及性，同时保持了良好的结果。通过完全清除环境中的有毒百合物种（*Lilium* 和 *Hemerocallis*）进行预防仍然是最有效的策略。兽医必须优先进行客户教育，让他们了解看似无害的花卉布置可能具有致命危险，并强调对猫来说不存在安全的暴露水平。

## 疾病概述与流行病学

百合科植物中毒，更准确地称为百合中毒，是指猫摄入 *Lilium* 和 *Hemerocallis* 属植物后发生的急性肾毒性[1]。该病症的特征是进行性急性肾损伤，如果不治疗可能导致致命的肾功能衰竭[2]。真百合具有高度肾毒性，可引起急性肾小管坏死，一些研究在复活节百合中毒中发现了并发胰腺炎和胰腺纤维化[2]。

猫对百合中毒具有独特的易感性，在其他伴侣动物中尚无毒性记录[3]。肾毒性百合的所有部分都有毒，包括花瓣、叶子、茎、花粉，甚至切花瓶中的水[6]。毒性成分尚未确定，但即使是轻微的暴露，如咬几片叶子或摄入花粉，也可能导致中毒，使所有猫的百合暴露都具有潜在的致命危险[4]。

从流行病学角度看，百合摄入是兽医毒物中心最常见的植物中毒咨询电话之一[6]。复活节百合（*Lilium longiflorum*）、虎百合（*L. tigrinum*）、星空百合、东方百合和萱草（*Hemerocallis* 属）是主要的肾毒性品种[6]。季节性模式与切花百合布置常见的节日相一致，特别是复活节和母亲节[4]。

预后关键取决于治疗时间，早期干预（6-12小时内）显著改善结果[5]。

### Sources

[1] CVC Highlight: Your toolbox for troublesome toxicoses in cats: https://www.dvm360.com/view/cvc-highlight-your-toolbox-troublesome-toxicoses-cats
[2] Toxicology Brief: The 10 most common toxicoses in cats: https://www.dvm360.com/view/toxicology-brief-10-most-common-toxicoses-cats
[3] Merck Veterinary Manual Houseplants and Ornamentals Toxic to Animals: https://www.merckvetmanual.com/toxicology/poisonous-plants/houseplants-and-ornamentals-toxic-to-animals
[4] Common hazards for cats (Proceedings): https://www.dvm360.com/view/common-hazards-cats-proceedings
[5] Outpatient treatment for lily toxicity in cats: https://www.dvm360.com/view/outpatient-treatment-for-lily-toxicity-in-cats
[6] Treating cats poisoned by lilies: https://www.dvm360.com/view/treating-cats-poisoned-by-lilies

## 有毒植物与病理生理学

**有毒百合物种**

Lilium 和 Hemerocallis 属对猫构成严重的肾毒性风险，即使是微量暴露也可能致命[1]。真百合（Lilium 属）包括复活节百合（L. longiflorum）、虎百合（L. tigrinum）、星空百合（L. orientalis）、亚洲杂交百合和森林百合[2]。萱草（Hemerocallis 属）同样有毒[2][3]。这些植物的所有部分都含有毒性成分，包括花粉、叶子、茎、花朵，甚至切花瓶中的水[2][5]。

**未知毒素与病理生理学**

百合诱导的猫急性肾损伤的机制仍不清楚，具体的肾毒性化合物尚未确定[1][3]。已知毒素是水溶性的，影响植物的所有部分[4]。初始临床症状包括摄入后数小时内呕吐，随后在24-72小时内迅速发展为少尿或无尿性肾功能衰竭[1][4]。

**肾脏病理生理学**

百合中毒引起近端小管坏死，导致急性肾损伤[1]。实验室变化在12小时内出现，显示血尿素氮和肌酐浓度升高[1]。在24小时内，尿分析显示等渗尿、大量管型、蛋白尿和糖尿[1][4]。病情发展为以肾小球滤过率降低为特征的急性肾功能衰竭，可能出现少尿或无尿[1]。如果没有及时干预，会发生不可逆的实质损伤，使早期识别和积极治疗变得至关重要[1][4]。

### Sources
[1] Common toxicities in cats (Proceedings): https://www.dvm360.com/view/common-toxicities-cats-proceedings
[2] Teach your veterinary clients: No lilies for kitties!: https://www.dvm360.com/view/teach-your-veterinary-clients-no-lilies-kitties
[3] Toxic plants (Proceedings): https://www.dvm360.com/view/toxic-plants-proceedings
[4] Toxicology of plants (Proceedings): https://www.dvm360.com/view/toxicology-plants-proceedings
[5] Treating cats poisoned by lilies: https://www.dvm360.com/view/treating-cats-poisoned-by-lilies

## 临床表现与诊断

### 最新研究发现
2025年的一项研究显示，急性肾损伤（AKI）的发生率远高于之前认识到的，住院猫中有46.9%，门诊猫中有43.8%在百合暴露后发展为AKI[1]。这与早期报告的仅9%的AKI发生率形成对比[1]。该研究应用了更新的国际肾脏兴趣协会（IRIS）分级指南，这可能检测到较轻度的肾损伤病例[1]。

### 更新的临床时间线
时间进展仍与既定模式一致。胃肠道症状，特别是呕吐，在摄入后2-12小时内发生[3]。急性肾功能衰竭通常在暴露后12-96小时显现，大多数病例在24-72小时内发展[3]。在摄入后6小时内进行早期干预提供最佳治疗结果[3]。

### 实验室和诊断更新
最新研究显示，血尿素氮和肌酐升高可能在摄入后12小时内检测到[1]。研究人群显示住院组和门诊组的基线肌酐中位数均为1.3 mg/dL[1]。大多数AKI猫发展为I级或II级严重程度，只有一只猫达到III级[1]。没有猫发展为IV级或更高级别的AKI，表明严重肾功能衰竭可能比之前认为的少见[1]。

### 治疗效果观察
有趣的是，胃净化率相对较低（住院组36.5%，门诊组12.5%进行催吐），但这与AKI发生率增加无关[1]。这一发现挑战了传统上对积极净化方案的强调，并表明支持性液体疗法可能是最关键的干预措施[1]。

### Sources
[1] Prevalence of acute kidney injury and outcome in cats treated as inpatients versus outpatients following lily exposure: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml
[2] Outpatient treatment for lily toxicity in cats: https://www.dvm360.com/view/outpatient-treatment-for-lily-toxicity-in-cats
[3] Treating cats poisoned by lilies: https://www.dvm360.com/view/treating-cats-poisoned-by-lilies

## 治疗方案与管理

百合中毒的治疗需要立即和积极的干预以预防急性肾损伤。如果暴露发生在6小时内，早期净化至关重要，包括催吐和活性炭给药[1]。主要治疗方法包括使用乳酸林格氏液以两倍维持率（2-3倍维持率）进行强化液体利尿，持续48-72小时，以增强毒素消除并预防肾小管损伤[1][2][3]。

静脉输液治疗仍然是金标准，如果在摄入后18小时内开始，可成功预防急性肾功能衰竭[2][5]。超过18小时的治疗通常由于严重肾功能衰竭而导致不良结果。应立即获取基线肾功能参数，并在12、24、36和48小时间隔监测[2][5]。

最新证据表明，对于某些猫，皮下输液的门诊管理可能是一个可行的替代方案[8]。一项对112只猫的研究显示，住院组（46.9%）和门诊组（43.8%）之间的AKI患病率无显著差异，尽管住院猫的存活率更高（100% vs 87.5%）[8]。

对于发展为无尿性肾功能衰竭的严重病例，可考虑血液透析或腹膜透析来管理氮质血症，同时允许肾小管在10-14天内再生[5][6]。从猫的毛发中完全清除百合花粉对于防止通过梳理继续暴露至关重要[1]。

### Sources

[1] Treating cats poisoned by lilies: https://www.dvm360.com/view/treating-cats-poisoned-by-lilies
[2] Toxicology of plants (Proceedings): https://www.dvm360.com/view/toxicology-plants-proceedings  
[3] CVC Highlight: Your toolbox for troublesome toxicoses in cats: https://www.dvm360.com/view/cvc-highlight-your-toolbox-troublesome-toxicoses-cats
[4] Don't eat that! Toxicities in cats (Proceedings): https://www.dvm360.com/view/dont-eat-toxicities-cats-proceedings
[5] Common hazards for cats (Proceedings): https://www.dvm360.com/view/common-hazards-cats-proceedings
[6] A practical review of common veterinary renal toxins: https://www.dvm360.com/view/practical-review-common-veterinary-renal-toxins
[7] Day Lily Toxicosis in Cats: A Retrospective Study of 40 Cases (1998-2002) - WSAVA2002 - VIN: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=11147&catId=29554&id=3846448
[8] Outpatient treatment for lily toxicity in cats: https://www.dvm360.com/view/outpatient-treatment-for-lily-toxicity-in-cats

## 预防与预后

**在百合中毒中预防至关重要，因为预后与治疗开始时间直接相关[1,5,6]。** 宠物主人必须了解真百合植物（Lilium 和 Hemerocallis 属）的所有部分对猫都具有高度毒性，需要从有猫科动物的家庭中完全清除[2,6]。这包括所有植物组成部分：花粉、叶子、茎，甚至切花瓶中的水[2]。

**一级预防涉及环境管理和客户教育。** 宠物毒物热线的"不要给猫咪百合"运动强调从家庭和花园中清除所有有毒百合物种，特别是复活节百合、虎百合、亚洲百合、星空百合、东方百合和萱草[2,6]。教育推广仍然至关重要，因为许多主人仍然不知道看似无害的花卉布置对猫可能是致命的[1]。

**预后因素很大程度上取决于时间[1,2,5]。** 在暴露后6小时内进行早期治疗提供最佳结果，尽管最新研究表明即使延迟就诊也有极好的存活率[1,5]。一项对112只猫的综合研究显示住院患者100%存活，门诊患者87.5%存活，表明各种治疗方式的预后良好[1,5]。

**就诊时急性肾损伤的程度显著影响长期结果[5]。** 最新数据显示，46.9%的住院猫出现某种程度的AKI，但60%的猫通过适当治疗显示肾功能稳定或改善[5]。长期监测仍然至关重要，因为即使初始反应良好的猫也可能发展为慢性肾病[2]。

### Sources
[1] Outpatient treatment for lily toxicity in cats: https://www.dvm360.com/view/outpatient-treatment-for-lily-toxicity-in-cats
[2] Treating cats poisoned by lilies: https://www.dvm360.com/view/treating-cats-poisoned-by-lilies
[3] Prevalence of acute kidney injury and outcome in cats treated as inpatients versus outpatients following lily exposure: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0355.xml
[4] The danger of household lilies: https://www.dvm360.com/view/the-danger-of-household-lilies
