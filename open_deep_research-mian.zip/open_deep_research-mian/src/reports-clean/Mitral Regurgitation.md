# 犬猫二尖瓣反流：综合临床指南

二尖瓣反流是伴侣动物中最常见的心血管疾病，影响约85%患有心脏病的犬，并在老年动物中发病率逐渐增加。该病症涉及收缩期血液从左心室反流至左心房，在犬中主要由黏液瘤性瓣膜变性引起，在猫中则继发于心肌病。

本报告为兽医从业者提供基于证据的指导，涵盖从早期检测到先进治疗选择的完整临床范围。涵盖的关键领域包括：骑士查理王小猎犬和小型犬的品种特异性风险模式、以匹莫苯丹治疗为特征的分阶段医疗管理方案、包括超声心动图和生物标志物在内的先进诊断方法、新兴的外科修复技术，以及影响各疾病阶段长期结果的预后指标。

## 疾病概述与病理生理学

二尖瓣反流（MR）是犬最常见的心脏病，约占犬心血管疾病的85%[1]。该病症涉及由于二尖瓣叶不完全闭合导致收缩期血液从左心室反流至左心房[2]。

该病主要影响老年犬，6岁后发病率增加，但在骑士查理王小猎犬中可能早在2-3岁就表现出来[1]。小型犬的发病率显著高于大型犬[2]。虽然在猫中较少见，但二尖瓣反流可继发于肥厚性心肌病，该病影响多达七分之一的猫[3]。

二尖瓣反流可分为原发性（黏液瘤性房室瓣变性）或继发性。原发性MR涉及退行性改变，其中二尖瓣的纤维层分解，导致瓣膜脱垂和瓣叶结节状增厚[2]。这种黏液瘤变性过程影响瓣叶和腱索，使其易于断裂[2]。

病理生理级联反应始于瓣膜功能不全，产生从心室到心房的湍流性收缩期血流，导致特征性心脏杂音和心房腔扩大[2]。当病情严重时，这会导致左心房压力和肺毛细血管压力超过20 mmHg，最终引起心源性肺水肿和充血性心力衰竭[2]。身体通过肾脏钠和水潴留进行代偿，增加血容量并实现显著的适应能力--犬可以对高达75%的血液反流回左心房的情况进行代偿[2]。

### Sources

[1] DVM 360 Mitral regurgitation (Proceedings): https://www.dvm360.com/view/mitral-regurgitation-proceedings
[2] Merck Veterinary Manual Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats
[3] Merck Veterinary Manual Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats

## 病因学与风险因素

犬猫二尖瓣反流主要由黏液瘤性房室瓣变性引起，约占犬所有心血管疾病的75%[1]。黏液瘤变性的确切原因尚不清楚，尽管在某些品种中已确定存在遗传易感性[1]。

**遗传和品种因素**
骑士查理王小猎犬表现为遗传性黏液瘤变性，该病比其他品种更频繁且在更年轻时发生[1][2]。在骑士查理王小猎犬和腊肠犬中，黏液瘤变性是一种遗传性状[2]。其他易感品种包括贵宾犬、约克夏梗和吉娃娃等小型犬[6]。

**年龄和体型模式**
二尖瓣反流与年龄和品种相关，老年小型犬的发病率显著更高[1]。该病影响约10%的5-8岁犬，20-25%的9-12岁犬，以及30-35%的13岁以上犬[2]。约30%的13岁犬临床上受影响，而尸检显示90%的13岁犬有瓣膜变性证据[6]。

**继发原因和感染性心内膜炎**
继发性二尖瓣反流可由扩张型心肌病引起，特别是在大型或巨型犬、牛磺酸缺乏的猫，或长期患有二尖瓣反流的动物中[2]。感染性心内膜炎是另一个原因，中年大型犬易感，雄性比雌性更常见[8]。最常分离的细菌包括链球菌、葡萄球菌、克雷伯氏菌属和大肠杆菌[8]。在猫中，二尖瓣反流不如犬常见[1]。

### Sources
[1] Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats
[2] Abnormalities of the Cardiovascular System in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[6] Acquired cardiac diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings
[7] A challenging case: Endocarditis in a Boston terrier: https://www.dvm360.com/view/challenging-case-endocarditis-boston-terrier
[8] Infectious Endocarditis in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats

## 临床表现与诊断

**临床表现**

二尖瓣反流表现出不同的临床表现，这些表现会经历各个阶段。早期体征包括运动不耐受和能量水平降低，特别是在年轻犬中[1]。标志性的体格检查发现是收缩期心脏杂音，在左心尖处最响亮，特征为全收缩期杂音，常常掩盖第二心音[1,8]。

杂音特征提供重要的诊断信息。杂音通常是全收缩期和平台形的，常向背侧和头侧传导[1,8]。随着疾病进展，可能出现其他异常心音，包括由增强的S3心音引起的奔马律[8]。

**先进诊断方法**

超声心动图仍然是确诊的金标准，显示增厚且不规则的瓣叶，回声正常至增强[1]。彩色多普勒超声心动图可以记录二尖瓣反流的存在，但彩色血流束的大小不应单独用于评估严重程度[1]。左心房大小作为评估反流严重程度的更可靠指标[1]。

胸部X光片评估心脏大小并识别肺部变化。左心房扩大是特征性发现，其大小与小型犬的反流严重程度直接相关[1]。

**心电图和生物标志物**

心电图提供节律评估，可以识别随左心房扩大而发展的心律失常，如房性早搏和心房颤动[1,9]。NT-proBNP作为有价值的生物标志物，水平升高（>1500pmol/L）预示发生充血性心力衰竭的风险增加[7]。

### Sources
[1] Merck Veterinary Manual Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats
[2] Diagnosis of Heart Disease in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals
[3] Electrocardiography (Proceedings): https://www.dvm360.com/view/electrocardiography-proceedings

## 治疗策略

二尖瓣反流的治疗方法根据疾病阶段和患者状况而有显著差异。对于B2期犬（无症状但心脏扩大），匹莫苯丹将充血性心力衰竭的发作时间延迟中位数15个月[1]。EPIC研究表明，接受匹莫苯丹的犬达到主要终点的风险比为0.64，与安慰剂相比[1]。

**分阶段医疗管理**

B1期犬通常不需要治疗。B2期犬在出现心脏扩大时受益于匹莫苯丹（0.4-0.6 mg/kg/天，分两次给药）[2]。C期和D期患者需要联合治疗，包括用于液体管理的呋塞米、ACE抑制剂（依那普利或贝那普利，0.25-0.5 mg/kg，每12-24小时）和匹莫苯丹[3]。螺内酯提供额外的醛固酮拮抗和抗纤维化作用[4]。

呋塞米仍然是主要的利尿剂，但难治性病例可能受益于改用托拉塞米或添加噻嗪类利尿剂[4]。对于轻度至中度充血性心力衰竭，推荐利尿剂治疗、ACE抑制剂、omega-3脂肪酸和限制钠饮食[6]。对于对常规治疗反应不佳的严重充血性心力衰竭犬，通常推荐低钠饮食[7]。

**手术选择**

在心肺分流下进行的二尖瓣修复手术在专业中心显示出约90%的成功率[4,5]。该手术涉及人工腱索置换和瓣环成形术技术[5]。最佳候选者是健康的中青年犬；12-13岁以上或有合并症的犬面临更高风险[4]。康复需要90天的活动限制，成功时长期预后良好[4]。

### Sources

[1] Pimobendan Delays Onset of Congestive Heart Failure in Dogs with Mitral Valve Disease and Cardiomegaly: https://www.dvm360.com/view/pimobendan-delays-onset-of-congestive-heart-failure-in-dogs-with-mitral-valve-disease-and-cardiomegaly

[2] Pimobendan: Understanding its cardiac effects in dogs with myocardial disease: https://www.dvm360.com/view/pimobendan-understanding-its-cardiac-effects-dogs-with-myocardial-disease

[3] Angiotensin-converting Enzyme Inhibitors for Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/angiotensin-converting-enzyme-inhibitors-for-use-in-animals

[4] Repair Surgery Among Latest Treatments for Mitral Valve Disease: https://www.dvm360.com/view/repair-surgery-among-latest-treatments-for-mitral-valve-disease

[5] Mitral valve repair under cardiopulmonary bypass in small breed dogs: https://avmajournals.avma.org/view/journals/javma/240/10/javma.240.10.1194.xml

[6] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings

[7] Heart Failure in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/heart-failure-in-dogs

## 鉴别诊断与预后

**鉴别诊断**

二尖瓣反流必须与几种具有重叠呼吸和心脏症状的心血管疾病进行鉴别。猫的肥厚性心肌病常引起呼吸困难和肺水肿，但特征是左心室壁增厚而非瓣膜变性[1]。犬的扩张型心肌病也表现为呼吸窘迫，但显示心腔扩大和收缩力降低而非瓣膜功能不全[2]。

鉴别因素包括超声心动图检查结果：二尖瓣反流显示增厚、不活动的瓣叶伴有反流，而心肌病显示特征性心肌改变[3]。退行性瓣膜病与先天性二尖瓣发育不良不同，后者发生在年轻动物中，表现为瓣膜结构畸形而非年龄相关性变性[4]。

**预后**

预后因疾病阶段和物种而异。许多轻度受影响的猫具有良好的长期结果，而处于充血性心力衰竭的猫中位生存期为3个月[1]。对于犬，只有约30%的二尖瓣反流患者会发展为心力衰竭[5]。

分期特异性预后包括：无症状犬可能多年保持稳定，而严重心力衰竭犬从诊断起生存期约6个月[2]。在B2期疾病中早期使用匹莫苯丹干预可将临床前期延长15个月[6]。有临床症状和严重二尖瓣发育不良的动物预后不良，但轻度受影响的动物可能数年保持无症状[4]。

### Sources
[1] Hypertrophic Cardiomyopathy in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Dilated Cardiomyopathy in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/dilated-cardiomyopathy-in-dogs-and-cats
[3] Acquired Heart and Blood Vessel Disorders in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/acquired-heart-and-blood-vessel-disorders-in-cats
[4] Mitral Valve Dysplasia in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/mitral-valve-dysplasia-in-animals
[5] Acquired Heart and Blood Vessel Disorders in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[6] Canine myxomatous mitral valve heart disease: When to medicate?: https://www.dvm360.com/view/canine-myxomatous-mitral-valve-heart-disease-when-medicate
