# 猫杯状病毒感染

猫杯状病毒（FCV）感染是家猫中最重大的病毒性呼吸道疾病之一，以其显著的遗传多样性和环境持久性影响着全球猫群。这种高度传染的病原体在兽医实践中构成了独特的挑战，因为它能在环境中存活数周，广泛的毒株变异限制了疫苗效力，并可能导致轻度上呼吸道疾病和严重的全身性表现。

本综合报告探讨了FCV的流行病学模式、从典型的口腔溃疡到危及生命的毒性全身性疾病等多种临床表现、包括分子检测局限性在内的当前诊断方法、以支持性护理为重点的循证治疗方案、疫苗接种策略及其固有挑战，以及影响临床实践中患者预后的因素。

## 摘要

猫杯状病毒感染在兽医实践中表现出显著的复杂性，超过100种遗传多样性毒株引起的疾病范围从伴有特征性口腔溃疡的轻度上呼吸道症状到死亡率高达33-60%的危及生命的毒性全身性疾病。该病毒显著的环境持久性（在室温下可存活数周）以及25%康复猫作为慢性携带者持续排毒，在多猫环境中造成了持续的传播挑战。

| 方面 | 主要发现 |
|--------|-------------|
| 诊断 | RT-PCR最敏感但实验室间结果不一致；仅凭临床症状不足以确诊 |
| 治疗 | 仅支持性护理 - 无特异性抗病毒药物；广谱抗生素用于继发感染 |
| 预防 | 疫苗接种可减轻严重程度，但由于毒株变异不能预防感染 |
| 预后 | 典型毒株预后良好（7-10天恢复）；毒性全身性形式预后极差 |

现有疫苗对流行毒株提供的交叉保护有限，强调了环境管理、应激减少和种群密度控制的至关重要性。兽医必须认识到，阳性诊断结果并不总是表明活动性疾病，而阴性结果也不能排除感染。未来的研究应专注于开发更广谱的疫苗和特异性抗病毒疗法，以应对猫医学中这一持续的挑战。

## 疾病概述与流行病学

猫杯状病毒（FCV）感染是一种高度传染性的病毒性呼吸道疾病，影响全球家猫。FCV是一种单链RNA、无包膜病毒，表现出显著的环境持久性，在室温下可存活数天至数周[1]。这种顽强的特性使其很容易通过污染物和直接接触传播。

该病毒表现出显著的遗传多样性，已鉴定出100多种不同毒株，在单一血清型内存在血清学交叉反应[2]。FCV感染在全球猫群中呈地方性流行，在收容所、猫舍和繁育设施等多猫环境中患病率特别高[2]。健康猫中的患病率高达24%，取决于使用的诊断方法[3]。

传播主要通过受感染猫的口咽分泌物直接接触发生，通过受污染表面传播的效率较低[2]。病毒靶向上呼吸道和口腔，引起典型症状包括结膜炎、鼻炎和特征性口腔溃疡[1]。

急性感染后，约25%的猫成为慢性携带者，从口咽部持续排毒数月至数年而无临床症状[4]。与猫疱疹病毒不同，FCV的排毒不受应激影响，在携带者猫中保持持续性[3]。

风险因素包括高密度饲养、应激、通风不良和并发的免疫抑制状况。幼猫和未接种疫苗的猫面临严重疾病表现增加的易感性。

### Sources

[1] Update on viral diseases in cats (Proceedings): https://www.dvm360.com/view/update-viral-diseases-cats-proceedings
[2] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings
[3] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[4] Feline viral skin diseases (Proceedings): https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings

## 常见病原体和临床表现

猫杯状病毒（FCV）是一种无包膜、单链RNA病毒，具有显著的突变率，导致广泛的抗原变异和毒力变化[1]。这种遗传不稳定性产生了许多在猫群中流行的抗原不同毒株，使FCV成为一种高度多样化的病原体。

**典型FCV毒株表现：**
大多数FCV感染表现为轻度、自限性上呼吸道疾病，类似于猫疱疹病毒感染。临床症状包括打喷嚏、鼻分泌物和结膜炎，但眼分泌物通常保持浆液性而非黏脓性[1]。FCV感染的一个区别特征是存在口腔溃疡，这很常见，有助于将其与其他呼吸道病原体区分开来[2]。FCV最常影响口腔和肺部的内壁，许多相关毒株引起不同程度的严重性[3]。一些毒株可能在8-12周龄的幼猫中产生短暂的"跛行综合征"，特征是发热、腿部跛行和关节疼痛，无口腔溃疡或肺炎[3]。

**毒性全身性疾病（VSD）毒株：**
2000年首次描述了一种毒性全身性形式，特征是高热、抑郁、厌食、皮下水肿（特别是头部和四肢）以及影响面部、耳廓和足部的严重溃疡性皮炎[1][2]。这种变异可导致多器官功能障碍，包括间质性肺炎以及肝、脾和胰腺坏死，即使在接种疫苗的成年猫中死亡率也达33-60%[4][5]。这些暴发主要发生在收容所或猫舍群体中，每次暴发涉及不同的病毒突变[2][5]。

### Sources
[1] Update on viral diseases in cats (Proceedings): https://www.dvm360.com/view/update-viral-diseases-cats-proceedings
[2] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings-0
[3] Feline Respiratory Disease Complex (Feline Viral Rhinotracheitis, Feline Calicivirus): https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[4] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals
[5] Virulent systemic feline calicivirus (Proceedings): https://www.dvm360.com/view/virulent-systemic-feline-calicivirus-proceedings

## 诊断方法

猫杯状病毒（FCV）感染的准确诊断需要结合临床评估和特定实验室检测的综合方法。临床表现评估侧重于特征性症状，包括口腔溃疡、上呼吸道症状和结膜炎，尽管仅凭临床症状区分FCV与其他呼吸道病原体仍然具有挑战性[1]。

**实验室检测方法**

RT-PCR代表了FCV检测最敏感和快速的诊断方法。这种分子技术可以从口咽、鼻和结膜拭子中扩增病毒RNA，在数小时内而非数天内提供结果[2]。然而，PCR敏感性在不同实验室间差异显著，取决于使用的具体方法，并且由于病毒遗传变异或运输过程中RNA降解，可能出现假阴性结果[1][3]。

使用细胞培养的病毒分离仍然是金标准，但需要1-2周才能获得结果。这种方法成功增殖活病毒用于鉴定，尽管FCV相对的环境稳定性使标本存活率问题比更脆弱的病毒少[1]。通过免疫荧光测定（IFA）进行抗原检测提供快速结果，但敏感性较低，使阳性结果具有确认性，而阴性结果不能排除感染[2]。

其他方法包括电子显微镜快速观察组织样本中的病毒颗粒，但这需要专门的设备和专业知识[4]。免疫组织化学可以使用病毒特异性抗体检测受感染组织内的病毒抗原[1]。

**诊断局限性和解释**

测试解释必须考虑FCV和其他呼吸道病原体都可以从无症状猫中分离出来，这降低了临床病例中的阳性预测值[1]。此外，猫可能同时携带多种病原体，使诊断复杂化。由于FCV毒株间的病毒遗传变异，可能出现假阴性PCR结果[2]。没有单一检测方法可以区分毒性全身性FCV与典型FCV毒株，需要从多只受影响猫中分离相同的病毒毒株来确认暴发情况[3]。

### Sources
[1] Viral diagnostics: What do the results mean? (Proceedings): https://www.dvm360.com/view/viral-diagnostics-what-do-results-mean-proceedings
[2] Molecular diagnostics: understanding assays for infectious diseases (Proceedings): https://www.dvm360.com/view/molecular-diagnostics-understanding-assays-infectious-diseases-proceedings
[3] Emerging respiratory infections (Proceedings): https://www.dvm360.com/view/emerging-respiratory-infections-proceedings-0
[4] Cowpox Virus Infections in Cats and Other Species: https://www.merckvetmanual.com/integumentary-system/pox-diseases/cowpox-virus-infections-in-cats-and-other-species

## 治疗选择和管理

FCV感染管理侧重于支持性护理和控制继发性细菌感染，因为该病毒没有特异性治疗方法[1]。广谱抗菌药物对继发性细菌感染有效，包括阿莫西林-克拉维酸、多西环素、阿奇霉素和氟喹诺酮类药物[2][3][4]。

对于FHV-1感染，口服L-赖氨酸250-500毫克，每日两次，可能干扰病毒蛋白质合成并减轻感染严重程度[5]。泛昔洛韦似乎比阿昔洛韦更安全，可按40-90毫克/千克口服，每8-12小时一次[2][5]。每日两次局部西多福韦有效治疗眼部FHV-1病变，比其他抗病毒药物刺激性小[2][5]。

人α干扰素每日口服30单位可能通过免疫调节帮助患有慢性病毒感染的猫[2][4]。鼻内减毒活疫苗可在慢性感染猫中提供治疗益处，对有反应的病例每年可给予多达三次[2][4]。

环境管理包括在用5%漂白剂溶液（稀释1:32）或过一硫酸钾消毒前彻底清洁，因为FCV抵抗许多常规消毒剂[6]。使用Feliway等产品减少应激和适当安置可以显著减轻暴发严重程度[2][5]。

护理包括维持水分、通过食欲刺激剂或必要时饲管提供营养支持，以及保持鼻腔/眼部分泌物清洁[4][7]。盐水雾化有助于去除顽固分泌物，而严重呼吸困难猫可能需要氧疗[4][7]。

### Sources
[1] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[2] WVC 2017: Managing Cats With Upper Respiratory Infection: https://www.dvm360.com/view/managing-cats-with-upper-respiratory-infection
[3] Viral respiratory pathogens (Proceedings): https://www.dvm360.com/view/viral-respiratory-pathogens-proceedings-0
[4] Feline viral upper respiratory infection: Why it persists (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[5] WVC 2017: Managing Cats with Upper Respiratory Infection - Viral Causes: https://www.dvm360.com/view/wvc-2017-managing-cats-with-upper-respiratory-infection--viral-causes
[6] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[7] Feline Respiratory Disease Complex - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 预防措施和疫苗接种

**疫苗接种方案**
猫杯状病毒的核心疫苗包括减毒活病毒（MLV）和灭活疫苗类型[1]。与灭活产品相比，MLV注射疫苗提供更快速的保护（5-7天）[2]。鼻内MLV和皮下制剂均可获得，通常与猫疱疹病毒和猫瘟热（FVRCP）联合使用[4][6]。疫苗接种应在6-9周龄开始，每3周加强一次，共三剂，然后每年重新接种[1]。

**疫苗效力和局限性**
由于广泛的病毒毒株变异，杯状病毒疫苗存在显著局限性。传统疫苗含有几十年前分离的单个毒株，对当前流行毒株提供的交叉保护有限[3][4]。存在许多耐药毒株，一些猫尽管接种疫苗仍易受感染[6][8]。疫苗减轻疾病严重程度和持续时间，但不能预防感染或携带者状态[4][6]。

**环境控制和消毒**
猫杯状病毒异常顽强，在干燥分泌物中可存活长达一个月[4][6][8]。有效消毒剂包括家用漂白剂（1:32稀释）、过一硫酸钾（Trifectant®）和加速过氧化氢[4][7]。季铵化合物对这种无包膜病毒无效[4][7]。在暴发期间，严格的环境去污染至关重要[3][7]。病毒可在环境中长时间存活，使彻底的卫生方案至关重要[6]。

**多猫管理**
在多猫环境中，隔离临床受影响的猫是强制性的[4][6][8]。通过适当安置、最小化处理和环境丰富化减少应激有助于预防病毒再激活[4][8]。种群密度控制是最重要的预防策略，因为过度拥挤增加传播风险并损害免疫功能[4][8][6]。

### Sources
[1] Merck Veterinary Manual Vaccination of Exotic Mammals: https://www.merckvetmanual.com/exotic-and-laboratory-animals/vaccination-of-exotic-mammals/vaccination-of-exotic-mammals
[2] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[3] DVM 360 Virulent systemic feline calicivirus: https://www.dvm360.com/view/virulent-systemic-feline-calicivirus-proceedings
[4] DVM 360 Feline infectious respiratory disease: https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[5] American Journal of Veterinary Research Long-term immunity in cats: https://avmajournals.avma.org/view/journals/ajvr/60/5/ajvr.1999.60.05.652.xml
[6] DVM 360 Shelter Snapshot Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-in-animal-shelters
[7] DVM 360 Controlling disease transmission in animal shelters for technicians: https://www.dvm360.com/view/controlling-disease-transmission-animal-shelters-technicians-proceedings
[8] DVM 360 Why do we have respiratory disease in our shelter cats: https://www.dvm360.com/view/why-do-we-have-respiratory-disease-our-shelter-cats-and-what-can-we-do-control-it-proceedings

## 鉴别诊断和预后

### 鉴别诊断

猫杯状病毒感染必须与几种症状重叠的呼吸道病原体区分开来[1]。主要鉴别诊断是猫疱疹病毒-1（FHV-1），它往往更显著地影响结膜和鼻腔通道，而FCV通常影响口腔黏膜和下呼吸道[1]。然而，由于表现相似，临床鉴别通常是不可能的[1][3]。

其他重要鉴别包括猫衣原体，其特征是产生严重结膜炎伴较轻呼吸道症状，以及支气管败血波氏杆菌，它更常引起咳嗽[2]。支原体物种可能引起严重结膜水肿和较轻的鼻炎[1]。继发性细菌感染经常使病毒性呼吸道疾病复杂化[1]。

诊断依赖于口咽、鼻或结膜样本的PCR检测，尽管检测并不总是确认活动性疾病[2]。FHV-1诊断特别具有挑战性，因为病毒间歇性排毒[1]。

### 预后

典型FCV感染的预后通常良好，死亡率保持较低[1]。大多数猫在7-10天内自发康复，尽管轻度病例症状可能持续5-10天，严重病例可达6周[1][3]。

不良预后指标包括非常年轻或非常年老，幼猫和老年猫预后较差[3]。短头品种面临慢性疾病发展的更高风险[1]。毒性全身性FCV毒株预后极差，尽管有支持性护理，死亡率仍接近50%[2]。

### Sources

[1] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[3] Feline Respiratory Disease Complex (Feline Viral Rhinotracheitis, Feline Calicivirus): https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
