# 伴侣动物的鸟粪石结石

鸟粪石结石是兽医临床中影响犬猫的最重要泌尿系统疾病之一。这些由六水磷酸镁铵组成的尿石在不同物种间表现出明显不同的病理生理学特征--犬主要为感染诱导性形成，而猫则为无菌性形成。本报告探讨了鸟粪石尿石症的综合临床处理方法，包括显示犬雌性易感和品种特异性风险的流行病学模式、葡萄球菌属和变形杆菌属等细菌病原体、利用影像学和尿液分析的诊断方案、使用特殊饮食和抗生素的药物溶解策略，以及管理三年内高达50%复发率所必需的预防方案。

## 摘要

鸟粪石结石表现出明显的物种特异性特征，这些特征从根本上塑造了临床管理方法。在犬中，超过95%的病例涉及产脲酶细菌感染，需要联合抗生素和饮食治疗，而猫主要发展为无菌性结石，仅通过酸化溶解饮食即可管理。成功治疗取决于通过碱性尿液pH检测的早期识别、适当的影像学确认以及物种特异性治疗方案。

| 方面 | 犬 | 猫 |
|--------|------|------|
| **主要原因** | 细菌感染 (>95%) | 无菌性/饮食性 (大多数) |
| **性别易感性** | 雌性 (85%) | 无易感性 |
| **治疗持续时间** | 平均1-2个月 | 通常2-4周 |
| **关键管理** | 抗生素 + 饮食 | 仅饮食 |

适当治疗的良好预后被显著的复发潜力所抵消，特别是在猫中，无菌性鸟粪石尿石尽管采取了预防措施仍可能复发。长期成功需要主人遵守高水分预防饮食、每2-3个月进行定期监测，并在碱性尿液表明治疗失败或感染复发时及时干预。

## 疾病概述与流行病学

鸟粪石结石是主要由六水磷酸镁铵（MgNH₄PO₄-6H₂O）组成的尿石[1]。这些结石是犬和猫中最常见的尿石类型之一，但由于商业饮食配方和治疗干预的变化，其患病率随时间波动[2]。

**流行病学数据**

在犬中，2003年明尼苏达尿石中心分析的28,629例尿石中，鸟粪石结石占41%，使其与草酸钙结石同样常见[2]。然而，患病率随时间发生变化，到2004年鸟粪石成为犬中第二常见的尿石类型[1]。

在猫中，1981-2005年间鸟粪石患病率发生显著变化。1981年最初占猫尿石的78%，到2000年代初下降至约33%，然后到2005年再次上升至48.1%[5]。

**风险因素与人口统计学**

犬鸟粪石结石表现出强烈的雌性易感性（85%雌性 vs 15%雄性），平均年龄为6岁[2]。品种易感性包括混种犬（25%）、迷你雪纳瑞（12%）、西施犬（9%）、比熊犬（7%）、可卡犬（5%）和拉萨犬（4%）[2]。

在猫中，大多数鸟粪石结石是无菌性的，无性别易感性，影响1-10岁的动物[5]。易感品种包括外国短毛猫、布偶猫、夏特尔猫、东方短毛猫和喜马拉雅猫[7]。

### Sources

[1] Merck Veterinary Manual Urolithiasis in Dogs: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[2] DVM 360 Improving management of urolithiasis: canine struvite uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-canine-struvite-uroliths
[3] DVM 360 Diagnosing and treating canine struvite uroliths: https://www.dvm360.com/view/diagnosing-and-treating-canine-struvite-uroliths
[4] DVM 360 Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings
[5] DVM 360 Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[6] DVM 360 Canine uroliths (Proceedings): https://www.dvm360.com/view/canine-uroliths-proceedings

## 病理生理学与常见病原体

鸟粪石结石的形成涉及细菌病原体、尿液化学和宿主因素之间的复杂相互作用，这些因素在犬和猫之间差异显著[1]。病理生理学核心是尿液中的磷酸镁铵（MAP）过饱和，当矿物成分大量排泄并在特定条件下沉淀时发生[1]。

在犬中，超过95%的鸟粪石尿石由产脲酶细菌的尿路感染引起[1,2]。最常见的病原体包括葡萄球菌属和变形杆菌属，较少涉及克雷伯菌属、棒状杆菌属、肠球菌属和支原体[2,6]。这些细菌产生脲酶，将尿素水解为氨，随后形成铵离子，减少氢浓度并增加尿液pH值[2,3,4]。

这种细菌诱导的碱性环境（pH通常>7.0）显著降低鸟粪石溶解度并促进快速晶体形成[2,4]。碱化还增加磷酸根离子和碳酸根离子的可用性，促进磷酸钙和碳酸钙磷酸盐与鸟粪石矿物一起沉淀[2]。

相比之下，猫主要发展为与细菌感染无关的无菌性鸟粪石尿石[1,6]。猫无菌性鸟粪石形成与饮食因素有关，特别是镁和磷摄入增加，结合碱性尿液pH和低尿量[8]。其病理生理学与感染诱导性结石根本不同，涉及饮食矿物过饱和而非细菌脲酶活性[1,8]。

### Sources
[1] Stones vs. crystals: Management and prevention ...: https://www.dvm360.com/view/stones-vs-crystals-management-and-prevention-proceedings
[2] Improving management of urolithiasis: canine struvite uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-canine-struvite-uroliths
[3] Advanced interpretation of the urine dipstick (Proceedings): https://www.dvm360.com/view/advanced-interpretation-urine-dipstick-proceedings
[4] The value of a urinalysis (Proceedings): https://www.dvm360.com/view/value-urinalysis-proceedings
[5] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis
[6] Stones vs. crystals: Management and prevention (Proceedings): https://www.dvm360.com/view/stones-vs-crystals-management-and-prevention-proceedings/1000
[7] Urolithiasis and the impact of nutritional management: https://www.dvm360.com/view/urolithiasis-and-the-impact-of-nutritional-management
[8] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings

## 临床表现与诊断方法

鸟粪石结石的临床表现因其在泌尿道内的位置而异[1]。大多数鸟粪石结石发生在膀胱，引起典型的下泌尿道症状，包括排尿困难、血尿、尿频和不当排尿[2][6]。患有非常小结石的猫可能无症状，但较大的结石可能干扰排尿或刺激尿道内壁[1]。

体格检查结果通常有限，因为猫中的大多数膀胱结石无法通过腹部触诊检测到[7]。然而，兽医偶尔可能通过腹部触诊检测到结石，或在膀胱检查时听到可闻的嘎吱声[3]。直肠检查可识别盆腔尿道中的结石[9]。

诊断影像学检查对确认至关重要。X线平片可检测小至3毫米的结石，但超声检查更优越，假阴性率仅为6%，而X线片为27%[1][3]。鸟粪石结石通常不透射线，在平片上易于观察[6][9]。

尿液分析提供重要的诊断信息。患有感染诱导性鸟粪石结石的犬的尿液pH通常呈碱性（>7.0），这是由于产脲酶细菌的存在[3][5]。鸟粪石晶体呈现为棱角状、棱柱状结构，在碱性尿液中更容易形成[6][7]。菌尿、脓尿和碱性尿的存在表明存在活动性尿路感染[2]。

当可获得结石时，确诊需要定量结石分析[6]。通过膀胱穿刺的尿液培养对于识别产脲酶细菌（特别是葡萄球菌属和变形杆菌属）至关重要[2][3]。

### Sources

[1] Merck Veterinary Manual Urinary Stones (Uroliths, Calculi) in Cats: https://www.merckvetmanual.com/cat-owners/kidney-and-urinary-tract-disorders-of-cats/urinary-stones-uroliths-calculi-in-cats

[2] DVM 360 Improving management of urolithiasis: canine struvite uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-canine-struvite-uroliths

[3] DVM 360 Diagnosing and treating canine struvite uroliths: https://www.dvm360.com/view/diagnosing-and-treating-canine-struvite-uroliths

[4] Journal of the American Veterinary Medical Association Efficacy of two commercially available, low-magnesium, urine-acidifying dry foods for the dissolution of struvite uroliths in cats: https://avmajournals.avma.org/view/journals/javma/243/8/javma.243.8.1147.xml

[5] Merck Veterinary Manual Urinalysis - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/urinalysis

[6] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis

[7] Improving management of urolithiasis: diagnostic caveats: https://www.dvm360.com/view/improving-management-urolithiasis-diagnostic-caveats

[8] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings

[9] Overview of Urolithiasis in Small Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/overview-of-urolithiasis-in-small-animals

## 治疗选择与管理

鸟粪石结石的治疗在犬和猫之间差异显著。在猫中，使用具有酸化作用且鸟粪石前体含量低的处方鸟粪石溶解饮食可有效溶解无菌性鸟粪石尿石[1]。完全溶解通常在饮食治疗2-4周后发生，但需要每两周通过X线和尿液分析进行监测[1]。

对于犬，药物溶解需要同时进行抗微生物治疗和鸟粪石溶解饮食[1]。完全溶解平均需要1-2个月，但根据结石大小可能需要更长时间[1]。这种联合方法解决了犬中常见的感染诱导性鸟粪石形成，抗生素治疗在整个溶解过程中持续进行，因为细菌仍隐藏在结石层内[6]。

鸟粪石溶解饮食减少蛋白质、磷和镁，同时促进酸化（尿液pH<6.3）和利尿[1]。在治疗期间应仅喂食这些饮食以确保疗效，不允许其他食物或零食[6]。高钠含量刺激口渴和代偿性多尿，以进一步降低尿液浓度[7]。

当药物溶解失败或存在禁忌症时，手术干预仍是必要的。膀胱切开术提供明确的结石清除，而经皮膀胱取石术等微创技术具有降低复发率和缩短住院时间等优势[1]。排尿性尿液压冲洗可有效去除小结石（雌性<5mm，雄性<1mm），无需特殊设备[1]。

治疗监测包括定期尿液pH评估和影像学随访[6]。使用pH试纸进行家庭监测有助于早期发现治疗失败，因为碱性尿液表明抗生素耐药性或尿路感染复发[6]。长期饮食管理侧重于高水分饮食和预防碱性尿液，而不是在成功治疗后继续溶解方案[1]。

### Sources

[1] Dietary management of urolithiasis (Proceedings): https://www.dvm360.com/view/dietary-management-urolithiasis-proceedings
[2] Feline uroliths (Proceedings): https://www.dvm360.com/view/feline-uroliths-proceedings
[3] Crystals, stones, and diets (Proceedings): https://www.dvm360.com/view/crystals-stones-and-diets-proceedings
[4] Canine uroliths (Proceedings): https://www.dvm360.com/view/canine-uroliths-proceedings
[5] Canine urolithiasis overview and update (Proceedings): https://www.dvm360.com/view/canine-urolithiasis-overview-and-update-proceedings
[6] Urolithiasis in Dogs - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-dogs
[7] Improving management of urolithiasis: canine struvite uroliths: https://www.dvm360.com/view/improving-management-urolithiasis-canine-struvite-uroliths

## 预防、鉴别诊断与预后

**预防措施**

预防鸟粪石结石复发需要全面的饮食管理和监测方案。有鸟粪石结石病史的猫应尽可能维持高水分、鸟粪石预防性饮食，因为无菌性鸟粪石尿石可能复发[1]。关键预防策略包括喂食罐头或高水分饮食以增加尿量并降低矿物浓度、维持适当的尿液pH（6.0-6.3）以及减少饮食中的镁和磷[2]。通过尿液分析和定期X线监测（每2-3个月）进行定期监测，能够在结石需要手术干预之前早期检测复发[3]。

**鉴别诊断**

鸟粪石结石的主要鉴别诊断包括草酸钙和尿酸盐尿石。草酸钙结石不透射线但无法药物溶解，通常在酸性尿液中形成，常见于中老年猫[1][4]。鉴别因素包括尿液pH（鸟粪石在碱性尿>6.7中形成，而草酸钙在任何pH下均可形成）、晶体形态和对溶解治疗的反应[4]。尿酸盐结石较少见，但应考虑，特别是在调查潜在肝功能障碍时[4]。

**预后与复发**

鸟粪石尿石症的预后在适当治疗下通常良好。溶解通常在饮食治疗2-4周内发生[1]。然而，复发率显著，无菌性鸟粪石尿石在猫中尽管采取了预防措施仍可能复发[1]。在犬中，据报道三年内复发率高达50%，强调了长期管理的重要性[3]。长期结果取决于主人对饮食建议的遵守和定期监测方案。

### Sources

[1] Urolithiasis in Cats - Urinary System: https://www.merckvetmanual.com/urinary-system/urolithiasis-in-small-animals/urolithiasis-in-cats

[2] Dietary management of urolithiasis (Proceedings): https://www.dvm360.com/view/dietary-management-urolithiasis-proceedings

[3] Stalking stones: An overview of canine and feline urolithiasis: https://www.dvm360.com/view/stalking-stones-overview-canine-and-feline-urolithiasis

[4] Stones vs. crystals: Management and prevention (Proceedings): https://www.dvm360.com/view/stones-vs-crystals-management-and-prevention-proceedings
