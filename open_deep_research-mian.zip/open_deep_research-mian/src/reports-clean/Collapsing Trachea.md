# 伴侣动物气管塌陷

气管塌陷是一种进行性退行性呼吸系统疾病，显著影响患病犬的健康和生活质量。这种结构性气道疾病的特点是气管软骨环弱化和动态性梗阻，主要影响小型犬种，需要全面了解以进行有效的临床管理。

本报告探讨了气管塌陷的多方面性质，从其基础病理生理学和特征性临床表现到当前的诊断方法和治疗策略。分析涵盖了该疾病的流行病学模式、继发性并发症（包括机会性细菌感染），以及兽医从业者可用的医疗和手术干预措施范围。此外，报告还讨论了关键的预防措施、鉴别诊断考量因素以及影响患者长期结果和生活质量管理的预后因素。

## 疾病概述

气管塌陷是一种进行性、退行性疾病，影响犬的气管软骨和背侧气管膜[1]。该疾病由于C形气管软骨环弱化和背侧纵向韧带冗余而发展，导致呼吸期间动态性气道梗阻[2]。

其病理生理学涉及通过冗余的气管膜、弱化的软骨环或两者共同导致气道管腔受损[1]。研究表明，硫酸软骨素和钙含量减少，以及软骨细胞减少，导致气管环背腹侧扁平化[3]。该疾病是动态的，颈段气管塌陷在吸气期间由于气道负压而发生，而胸内段塌陷则在呼气期间发生[1]。

气管塌陷主要影响中老年小型犬[4]。约克夏梗是标志性品种，但该疾病常见于博美犬、吉娃娃犬、马尔济斯犬以及迷你和玩具贵宾犬[1,7]。临床症状通常在犬达到中年时显现，并可能随时间推移逐渐加重[1]。最常见的受影响解剖位置是胸廓入口处，此处软骨最薄[1]。

### Sources
[1] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings
[2] Surgery STAT: Tracheal collapse: rings or stents?: https://www.dvm360.com/view/surgery-stat-tracheal-collapse-rings-or-stents
[3] Tracheal collapse frustrating; minimally invasive tehniques promising: https://www.dvm360.com/view/tracheal-collapse-frustrating-minimally-invasive-tehniques-promising
[4] Managing laryngeal and tracheal problems (Proceedings): https://www.dvm360.com/view/managing-laryngeal-and-tracheal-problems-proceedings
[5] Managing upper airway disease (Proceedings): https://www.dvm360.com/view/managing-upper-airway-disease-proceedings
[6] Breed-specific canine respiratory diseases: https://www.dvm360.com/view/breed-specific-canine-respiratory-diseases

## 常见病原体

虽然气管塌陷主要是一种涉及气管软骨环弱化的结构性疾病，但继发性细菌感染常常使疾病复杂化，并显著导致临床恶化[1]。这些机会性感染在基础气管病理损害呼吸道防御机制时发生。

正常呼吸道含有共栖生物，包括多杀性巴氏杆菌、支气管败血波氏杆菌、链球菌、葡萄球菌、假单胞菌和大肠杆菌等，不引起临床症状[1]。然而，在患有气管塌陷的犬中，当黏液纤毛清除功能受损且气道刺激为细菌增殖创造有利条件时，这些细菌成为机会性病原体。

与气管塌陷继发性感染相关的常见细菌分离株包括支气管败血波氏杆菌、多杀性巴氏杆菌、克雷伯氏菌属、链球菌属和大肠杆菌[3]。这些革兰氏阴性需氧菌常从患病犬的呼吸道分泌物中培养出来。支气管败血波氏杆菌特别重要，因为它既可作为原发性病原体，也可作为继发性入侵者，诱导纤毛停滞，进一步损害呼吸道防御机制[5,7]。

继发性细菌感染显著增加疾病管理的复杂性[1]。受损的气管结构创造了一个环境，使这些通常共栖的细菌能够建立感染，导致黏液产生增加、气道炎症和临床症状恶化。当怀疑有继发性细菌感染时，可能需要进行支气管镜检查以收集样本进行细胞学检查和培养[1]。

### Sources
[1] Overview of Respiratory Diseases of Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/overview-of-respiratory-diseases-of-dogs-and-cats
[2] Tonsillitis in Dogs and Cats - Respiratory System: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/tonsillitis-in-dogs-and-cats
[3] Pulmonary parenchymal disease (Proceedings): https://www.dvm360.com/view/pulmonary-parenchymal-disease-proceedings
[4] Rational antibiotic choices for bacterial pneumonia in dogs: https://www.dvm360.com/view/rational-antibiotic-choices-bacterial-pneumonia-dogs-proceedings
[5] Lower respiratory infections in dogs (Proceedings): https://www.dvm360.com/view/lower-respiratory-infections-dogs-proceedings
[6] Canine infectious respiratory disease complex: https://www.dvm360.com/view/canine-infectious-respiratory-disease-complex-management-and-prevention-canine-populations-proceedin
[7] Managing puppies with pneumonia (Proceedings): https://www.dvm360.com/view/managing-puppies-with-pneumonia-proceedings

## 临床症状和体征

气管塌陷的特征性临床表现是阵发性发作的 distinctive "goose-honk"（鹅鸣样）咳嗽[1]。这种剧烈的干咳通常由兴奋、运动或压力诱发，可能伴有终末性干呕或作呕，导致主人有时误以为是呕吐[2,6]。

患病犬通常表现出运动不耐受和呼吸窘迫模式，这些症状随塌陷位置而变化[2]。颈段气管塌陷产生吸气性喘鸣和吸气困难，而胸内段塌陷导致慢性咳嗽，伴有明显的呼气末期"啪嗒声"[2]。在严重病例中，犬可能出现呼吸困难、发绀甚至昏厥[5,6]。

该疾病主要影响小型犬，特别是约克夏梗、博美犬和玩具贵宾犬，通常在3至6岁之间显现[2,6]。体格检查常显示气管触诊时容易诱发咳嗽，气管可能感觉比正常更软，并可触及气管膜[2,5]。当大气道塌陷在一起时，可能听到听觉性"咔嗒声"，最常见于咳嗽发作结束时[7]。

患病犬在咳嗽发作间歇期通常健康，尽管它们可能随时间推移表现出症状逐渐加重[2,5]。临床表现常呈波动性病程，由环境因素或并存状况引发周期性加重。

### Sources

[1] Radiography underestimates the severity of ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0150/ajvr.25.04.0150.pdf
[2] Managing upper airway disease (Proceedings): https://www.dvm360.com/view/managing-upper-airway-disease-proceedings
[3] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/248/5/javma.248.5.489.xml
[4] Exercise intolerance in retrievers: https://www.dvm360.com/view/exercise-intolerance-retrievers
[5] Managing laryngeal and tracheal problems (Proceedings): https://www.dvm360.com/view/managing-laryngeal-and-tracheal-problems-proceedings
[6] Respiratory disasters and how we managed them-Part 2: https://www.dvm360.com/view/respiratory-disasters-and-how-we-managed-them-part-2-proceedings
[7] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings

## 诊断方法

气管塌陷的诊断依赖于多种互补方法来评估静态解剖结构和动态气道功能。临床检查包括仔细触诊颈段气管，可能揭示背腹侧扁平化，并可能引发严重咳嗽发作[2]。体格检查期间的气管压迫通常在受影响患者中诱发阵发性咳嗽[3]。

放射学评估构成诊断成像的基础。未麻醉患者的侧位胸部X线片通常对气管塌陷具有诊断意义[4]。然而，由于该疾病的动态性质，普通X线片可能不够充分[2]。吸气和呼气位视图或屈曲和伸展颈部位置可以显示呼吸不同阶段气管直径的变化[4]。

透视检查通过确认清醒患者呼吸期间气管直径的动态变化提供更优的评估[2,3]。这种方法对于检测静态X线片上可能不明显的塌陷特别有价值[5]。

支气管镜检查代表气管塌陷诊断和分级的金标准[3,4]。该技术允许直接观察动态气道塌陷并评估背侧膜松弛度、气管环形状和管腔受压程度[4]。该程序使用标准化分级系统：I级（管腔减少25%）、II级（减少50%）、III级（减少75%）和IV级（接近完全闭塞）[1,4]。支气管镜检查还使收集细菌培养和细胞学评估的样本成为可能[4]。

### Sources

[1] Radiography underestimates the severity of: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0150/ajvr.25.04.0150.pdf
[2] Medical management of canine upper airway diseases: https://www.dvm360.com/view/medical-management-of-canine-upper-airway-diseases
[3] Managing the coughing dog (Proceedings): https://www.dvm360.com/view/managing-coughing-dog-proceedings
[4] Surgery of the respiratory system (Proceedings): https://www.dvm360.com/view/surgery-respiratory-system-proceedings
[5] Fluoroscopic and radiographic evaluation of tracheal collapse: https://avmajournals.avma.org/view/journals/javma/230/12/javma.230.12.1870.xml

## 治疗选择

医疗管理是犬气管塌陷治疗的基石。抗炎剂量的皮质类固醇（每日泼尼松0.5 mg/kg）有效减轻气管炎症、黏膜水肿和支气管痉挛[1][3]。镇咳药如氢可酮（每6小时0.22 mg/kg）、布托啡诺或复方药物如地芬诺酯与阿托品提供症状缓解[1][2][5]。支气管扩张剂包括茶碱和特布他林可能改善下气道气流[2]。

体重管理和镇静剂如乙酰丙嗪有助于减轻呼吸压力。大多数轻度至中度塌陷的犬单独医疗管理反应良好[1][4]。

对于药物治疗无效的严重病例，需要手术干预。自扩张镍钛合金支架提供传统管外假体环置入的微创替代方案[2][4]。气管支架置入可在透视引导下快速进行，适合高风险患者[4][8]。对于没有并发主支气管塌陷的犬，报告有70-90%的改善成功率[4]。

然而，支架并发症包括断裂（约42%病例发生）、过度肉芽组织形成和细菌性气管炎[7]。管外假体环对颈段气管塌陷仍然有效，但存在喉麻痹和气管坏死的风险[8]。两种手术方法都是姑息性而非治愈性的，需要持续的医疗管理[4]。

### Sources
[1] Upper airway disease (Proceedings): https://www.dvm360.com/view/upper-airway-disease-proceedings
[2] Tracheal collapse frustrating; minimally invasive tehniques promising: https://www.dvm360.com/view/tracheal-collapse-frustrating-minimally-invasive-tehniques-promising
[3] Managing the coughing dog (Proceedings): https://www.dvm360.com/view/managing-coughing-dog-proceedings
[4] Tracheal collapse: old disease; newer treatment options (Proceedings): https://www.dvm360.com/view/tracheal-collapse-old-disease-newer-treatment-options-proceedings
[5] Medical management of canine upper airway diseases: https://www.dvm360.com/view/medical-management-of-canine-upper-airway-diseases
[7] Self-expanding nitinol stents for the treatment of tracheal collapse in dogs: 12 cases (2001-2004): https://avmajournals.avma.org/view/journals/javma/232/2/javma.232.2.228.xml
[8] Interventional radiology in veterinary medicine: https://www.dvm360.com/view/interventional-radiology-veterinary-medicine-now-and-future-proceedings

## 预防措施

体重管理对预防气管塌陷进展至关重要。肥胖犬在50%气管塌陷时经历16倍增加的气道阻力[1]。气管塌陷的治疗通过减重显著改善[1]。为有效管理体重，绝育/去势后应减少30%的能量摄入以维持最佳体重[4]。大多数室内猫只需要其静息能量需求（平均体型猫约200千卡/天），许多需要更少以维持正常体重[4]。

环境改变包括使用胸背带代替项圈以减少气管压力[7]。生活方式改变如"体重控制、胸背带vs项圈"是标准治疗方法[7]。运动限制、减少兴奋和压力是必要的预防措施[6]。

管理并存状况可防止疾病加重。受气管塌陷影响的相同品种常发展为房室瓣疾病，心房增大可能加重塌陷症状[7]。细菌感染可能引发或加重气管塌陷，当存在脓性炎症的细胞学证据时需要及时抗菌治疗[7]。环境压力包括温度极端和湿度变化增加疾病易感性[6]。

### Sources
[1] Obesity: the skinny on fat (Proceedings): https://www.dvm360.com/view/obesity-skinny-fat-proceedings
[4] Feeding cats and feline obesity (Proceedings): https://www.dvm360.com/view/feeding-cats-and-feline-obesity-proceedings
[6] Merck Veterinary Manual Tracheal Collapse in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/lung-and-airway-disorders-of-dogs/tracheal-collapse-in-dogs
[7] DVM 360 Tracheal collapse: A common cause of chronic cough (Proceedings): https://www.dvm360.com/view/tracheal-collapse-common-cause-chronic-cough-proceedings

## 鉴别诊断

气管塌陷必须与几种导致犬慢性咳嗽的疾病进行鉴别。最重要的鉴别诊断包括慢性支气管炎、感染性气管支气管炎、喉功能障碍和心脏病[1]。

**慢性支气管炎**常与气管塌陷并存并具有相似的临床表现。许多患有气管塌陷的犬由于细菌疾病或过敏状况而并发慢性支气管炎，潜在炎症和小气道阻力增加加剧气管塌陷[1]。两种疾病通常影响老年小型犬并表现为慢性咳嗽，没有支气管镜检查难以区分[2]。

**感染性气管支气管炎**表现为类似的干咳和终末性干呕，但通常具有急性发作并有近期暴露史。咳嗽通常伴有肿大、红色的扁桃体和增加的咽部分泌物，与气管塌陷的慢性性质不同[1]。

**喉麻痹**产生吸气性喘鸣和运动不耐受，主要影响大型犬。高达30%的气管塌陷犬可能并发喉麻痹，需要在轻度麻醉下仔细评估杓状软骨运动[1,4]。

**心脏病**需要仔细鉴别，因为许多患有气管塌陷的小型犬也并发二尖瓣疾病。心力衰竭产生柔软、湿性咳嗽，X线片显示肺水肿模式，而气管塌陷引起响亮、鹅鸣样咳嗽，肺部正常或支气管周围模式[1,6]。左心房增大可压迫左主支气管，引起与心力衰竭无关的咳嗽[6,8]。

### Sources

[1] Managing laryngeal and tracheal problems (Proceedings): https://www.dvm360.com/view/managing-laryngeal-and-tracheal-problems-proceedings
[2] Canine chronic bronchitis and pulmonary fibrosis ...: https://www.dvm360.com/view/canine-chronic-bronchitis-and-pulmonary-fibrosis-proceedings
[3] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings
[4] Breed-specific canine respiratory diseases: https://www.dvm360.com/view/breed-specific-canine-respiratory-diseases
[5] Managing the coughing dog (Proceedings): https://www.dvm360.com/view/managing-coughing-dog-proceedings
[6] When to take this cough to heart: https://www.dvm360.com/view/when-to-take-this-cough-to-heart
[7] Cough...Heart disease or lung disease? (Proceedings): https://www.dvm360.com/view/coughheart-disease-or-lung-disease-proceedings
[8] Back to basics: clinical cardiovascular exam and diagnostic ...: https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings

## 预后

患有气管塌陷的犬的预后因疾病严重程度、并存状况和治疗反应而显著不同[1][2]。I-II级塌陷的犬通常单独医疗管理具有更好的长期结果，而III-IV级塌陷的犬面临更谨慎的预后[2]。

术后，大多数犬在咳嗽和呼吸困难方面经历显著改善，活动水平提高，气管支气管炎发作减少[2]。然而，患有严重塌陷（III-IV级）、慢性肺病和肺心病的手术患者尽管进行干预仍可能有持续性临床症状[2]。

几个因素影响长期管理成功。并存状况如喉麻痹、慢性阻塞性肺病和心脏病显著影响结果[3]。患有难治性肺水肿或进行性右心衰竭的犬预后更具挑战性[6]。

生活质量考虑至关重要，因为气管塌陷无法治愈[3]。目标成为缓解临床症状而非治愈。大多数犬通过适当的医疗管理可以维持可接受的生活质量，尽管主人必须理解可能持续存在轻度咳嗽[2][3]。

长期成功取决于主人对生活方式改变、体重管理和药物治疗方案的依从性。需要频繁介入性操作或因并发心脏病出现并发症的犬通常生存时间较短[6]。

### Sources
[1] Radiography underestimates the severity of tracheal collapse: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0150/ajvr.25.04.0150.pdf
[2] Surgery of the respiratory system (Proceedings): https://www.dvm360.com/view/surgery-respiratory-system-proceedings
[3] Tracheal collapse (Proceedings): https://www.dvm360.com/view/tracheal-collapse-proceedings
[4] Fluoroscopic and radiographic evaluation of tracheal collapse: https://avmajournals.avma.org/view/journals/javma/230/12/javma.230.12.1870.xml
[5] Specialists' approach to tracheal collapse: https://avmajournals.avma.org/view/journals/javma/261/1/javma.22.03.0108.xml
[6] Keys to managing end-stage heart failure: https://www.dvm360.com/view/keys-managing-end-stage-heart-failure
