# 伴侣动物退行性关节疾病：综合临床回顾

退行性关节疾病（DJD）是兽医临床中影响犬猫的最普遍且最具影响力的慢性疾病之一。高达40%的年轻成年犬和超过90%的老年猫表现出骨关节炎证据，这种进行性疾病通过疼痛、活动能力下降和行为改变显著损害生活质量。与许多传染性疾病不同，DJD的隐匿性发作和物种特异性表现常导致诊断延迟和管理不当。本报告综合了当前兽医知识在八个关键领域：疾病流行病学、病理生理机制、临床表现、诊断方法、循证治疗策略、预防措施、鉴别诊断和预后因素。理解这些相互关联的方面使兽医能够实施早期干预策略和多模式管理方法，从而显著改善受影响患者的长期预后。

## 疾病概述与流行病学

退行性关节疾病（DJD），也称为骨关节炎，是一种进行性疾病，特征是动关节中关节软骨的退化、关节积液和关节周围骨赘形成[1]。该疾病是犬猫最常见的慢性疼痛性疾病之一，对生活质量有显著影响。

**患病率与年龄分布**
DJD的患病率随年龄变化显著。在犬中，8个月至4岁的动物中高达40%显示骨关节炎的放射学证据，尽管临床症状通常在5-13岁之间出现[1]。约20%的成年犬患有一个或多个关节的骨关节炎[2]。该疾病在猫中严重未被识别，约60%的所有猫和超过90%的12岁以上猫显示退行性关节变化[1]。

**风险因素**
关键风险因素包括肥胖，研究表明超重犬的DJD发生率和严重程度增加[1]。遗传易感性起着关键作用，特别是品种特异性构象异常，如某些品种的髋关节发育不良[1]。早期绝育（小于5个月龄）可能增加犬的髋关节骨关节炎风险[4]。环境因素如发育期间的受控运动和营养管理显著影响疾病进展[1]。

### Sources
[1] Osteoarthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats
[2] Management of osteoarthritis in sporting dogs (Proceedings): https://www.dvm360.com/view/management-osteoarthritis-sporting-dogs-proceedings
[3] Osteoarthritis in cats (Proceedings): https://www.dvm360.com/view/osteoarthritis-cats-proceedings-0
[4] Preventing osteoarthritis: What are the facts? (Proceedings): https://www.dvm360.com/view/preventing-osteoarthritis-what-are-facts-proceedings

I'll synthesize the existing section content with the provided source material to enhance the pathophysiology and clinical presentation section.

## 病理生理学与临床表现

退行性关节疾病涉及复杂的病理生理机制，始于关节软骨退化和进行性软骨细胞坏死[1]。由蛋白聚糖、1型胶原和80%水组成的软骨基质经历向分解代谢的稳态转变[2]。最初，软骨细胞蛋白聚糖产生减少导致基质中硫酸软骨素和水的流失， resulting in less elastic cartilage with reduced shock absorption [2].

这种降解释放炎症介质，包括白细胞介素-1β、IL-6、肿瘤坏死因子-α和前列腺素E2，这些介质刺激基质金属蛋白酶（MMPs）[1][3]。这些酶进一步分解软骨基质和胶原，形成炎症和破坏的自我维持循环[1][3]。伴有丰富神经支配的新生血管形成的发炎滑膜成为关键疼痛发生器，连同暴露的软骨下骨和发炎的关节囊[7]。

临床表现在不同物种间差异显著。犬通常表现为跛行、起身缓慢、上下楼梯困难，以及跳跃或玩耍受限[7]。然而，双侧疾病时跛行可能不太明显，因为犬可以在肢体间重新分配体重[8]。体格检查发现包括关节和关节周围肿胀、肌肉萎缩、摩擦音和活动范围受限[8]。

猫由于其代偿能力和双侧受累而表现出明显不同的临床模式[7][8]。猫患者很少显示明显跛行，而是表现为梳理减少导致受影响区域毛发打结、不愿跳到高处、因难以进入猫砂盆而排泄不当，以及包括易怒或退缩在内的行为改变[7][8]。许多主人将这些迹象误认为是正常衰老，使早期识别具有挑战性[7]。当猫无法到达高处食物位置时可能发生体重减轻，有些因难以采取排泄姿势而发展为便秘[7]。

放射学证据显示，12岁以上猫中90%受DJD影响，其中肘关节最常显示严重病变[9]。两个物种在检查时都可能显示关节增厚、肌肉萎缩和摩擦音，但由于猫具有优越的代偿机制，这些发现在猫中不太一致[7][8]。

### Sources

[1] Managing arthritic dogs and cats (Proceedings): https://www.dvm360.com/view/managing-arthritic-dogs-and-cats-proceedings-0
[2] A closer look at canine osteoarthritis: https://www.dvm360.com/view/closer-look-canine-osteoarthritis
[3] Medical management of osteoarthritis in dogs (Proceedings): https://www.dvm360.com/view/medical-management-osteoarthritis-dogs-proceedings
[4] Osteoarthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats
[5] DJD calls for TLC: Identify and relieve cats pain and disability: https://www.dvm360.com/view/djd-calls-tlc-identify-and-relieve-cats-pain-and-disability
[6] Sports medicine for cats (Proceedings): https://www.dvm360.com/view/sports-medicine-cats-proceedings-0
[7] Degenerative joint disease in cats (Proceedings): https://www.dvm360.com/view/degenerative-joint-disease-cats-proceedings
[8] Joint disease in cats: Assume the worst and treat for the best: https://www.dvm360.com/view/joint-disease-cats-assume-worst-and-treat-best
[9] Osteoarthritis in cats (Proceedings): https://www.dvm360.com/view/osteoarthritis-cats-proceedings-0

## 诊断方法与鉴别诊断

DJD的诊断评估需要多模式方法，结合临床检查与先进成像技术[1]。体格检查可能显示关节积液、关节周围增厚、活动范围减少和摩擦音，但由于猫的体型和性情，这些发现通常很微妙[3]。在家中，患有关节炎的猫会限制活动以避免疼痛运动，可能对儿童或其他宠物显得"脾气暴躁"，并在肩部和大腿处显示肌肉流失[5]。

放射学检查仍然是主要的诊断成像方式，显示特征性变化，包括不规则的关节表面边缘和软骨下硬化[1]。然而，骨关节炎的放射学发现与临床功能并不总是良好相关，因为22%的猫显示放射学证据，而只有33%有相应临床症状[4]。X光片显示关节内液体增加、软组织肿胀、骨赘生长、软骨下骨硬化和增厚，有时显示关节间隙变窄[6]。

先进成像包括计算机断层扫描（CT）和磁共振成像（MRI）可能是确诊所必需的，特别是当放射学变化微妙时[3]。关节镜检查提供关节内结构的直接可视化，并允许在关节操作期间进行动态评估[4]。

### 鉴别诊断

关键鉴别诊断包括感染性关节炎、免疫介导性多关节病和肿瘤[3]。脓毒性关节炎表现为发热、精神不振和关节肿胀[6]。免疫介导性疾病如猫进行性多关节炎和系统性红斑狼疮可能表现为类似的关节炎症，但通常同时影响多个关节[6]。

### Sources

[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/241/9/javma.241.9.1155.xml
[2] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/256/9/javma.256.9.977.xml
[3] Osteoarthritis in cats: Still a mass of unknowns: https://www.dvm360.com/view/osteoarthritis-cats-still-mass-unknowns
[4] Sports medicine for cats (Proceedings): https://www.dvm360.com/view/sports-medicine-cats-proceedings-0
[5] Treating feline arthritis with spectrum of care: https://www.dvm360.com/view/treating-feline-arthritis-with-spectrum-of-care
[6] Joint Disorders in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/bone-joint-and-muscle-disorders-of-cats/joint-disorders-in-cats

## 治疗选择

NSAIDs代表犬猫退行性关节疾病的一线治疗[1]。对于临床症状轻微的犬（COAST 2期），在尝试停药前可能需要≥1个月的NSAID治疗，而临床症状中度至严重的犬（COAST 3-4期）可能需要持续的长期治疗[1]。

在猫中，美洛昔康（0.02 mg/kg口服每日）和罗贝考昔（2 mg/kg口服或1 mg/kg皮下每日）已建立长期使用的安全性资料，即使在患有稳定IRIS 1-2期慢性肾病的猫中也是如此[1]。治疗应遵循既定指南，谨慎减量并监测[6]。

抗神经生长因子单克隆抗体提供了有希望的替代选择。Bedinvetmab（0.5 mg/kg皮下每月）使中度至重度临床症状的犬受益，而frunevetmab（1-2.8 mg/kg皮下每月）为患有骨关节炎的猫提供有价值的治疗[1]。这些药物针对神经源性炎症和周围敏化，补充NSAID治疗。

其他镇痛药物包括加巴喷丁（犬10-20 mg/kg口服每8-12小时；猫10 mg/kg口服每12小时）、金刚烷胺（3-5 mg/kg口服每12-24小时）和普瑞巴林[1]。体重优化仍然至关重要，即使是适度的体重减轻也能显著改善超重犬的功能[1,2]。

多模式康复治疗包括手动治疗、治疗性运动、水疗（当水位达到髋部水平时减少髋关节负荷60%）、低水平激光治疗和针灸[3,5]。猫的环境改造包括抬高的食碗、易于进入的猫砂盆以及通往首选休息区域的坡道或台阶[6]。

### Sources

[1] Osteoarthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats
[2] Load and grow: https://www.dvm360.com/view/load-and-grow
[3] Rehabilitation and canine osteoarthritis: a multimodal approach: https://www.dvm360.com/view/rehabilitation-and-canine-osteoarthritis-a-multimodal-approach
[4] Approaches to the physical rehabilitation of dogs and cats with chronic neurologic and musculoskeletal disorders: https://www.dvm360.com/view/approaches-physical-rehabilitation-dogs-and-cats-with-chronic-neurologic-and-musculoskeletal-disorde
[5] A brief overview of rehabilitation modalities: https://www.dvm360.com/view/a-brief-overview-of-rehabilitation-modalities
[6] DJD calls for TLC: Identify and relieve cats pain and disability: https://www.dvm360.com/view/djd-calls-tlc-identify-and-relieve-cats-pain-and-disability

## 预防与长期预后

现有部分提供了退行性关节疾病预防策略和预后因素的全面覆盖。来自Managing osteoarthritis in dogs (Proceedings)和Rehabilitation and canine osteoarthritis: a multimodal approach来源的资料强化了几个关键点，同时提供了额外的临床背景。

体重管理仍然是预防的基石，维持最佳体况评分（4.5/9）可能将高风险犬的骨关节炎发展减少高达70%[1]。资料证实，间歇性体力活动优于持续运动，避免可能加剧关节损伤的过度使用损伤[6]。定期受控运动计划，包括水疗和步行等治疗活动，有助于维持关节活动度和肌肉力量[2][4]。

早期干预策略应包括环境改造，如提供坡道和防滑表面[3]。犬骨关节炎分期工具（COAST）有助于标准化早期检测，在显著结构变化发生前的0-2期进行干预最为有益[5]。含有omega-3脂肪酸的关节补充剂在早期疾病管理中显示出希望[1][10]。

长期预后很大程度上取决于早期识别和干预时机。资料强调骨关节炎进展缓慢且逐渐发作，使早期诊断具有挑战性但至关重要[1][6]。使用多模式方法积极诊断和管理的犬可以多年维持良好生活质量，而表现为晚期疾病的患者面临更具挑战性的管理[4][5]。当干预在中度至重度阶段进行时，治疗成功率显著降低，因为不可逆的结构性关节变化已经发生[5]。通过结合药物、体重控制、运动和康复的适当多模式管理，许多患者在活动能力和疼痛控制方面经历显著改善，尽管这仍然是一种进行性、终身疾病，需要持续监测和治疗调整[6][4]。

### Sources
[1] A breakthrough joint supplement for dogs and cats: https://www.dvm360.com/view/a-breakthrough-joint-supplement-for-dogs-and-cats
[2] Nonpharmacologic management of canine osteoarthritis: https://www.dvm360.com/view/nonpharmacologic-management-of-canine-osteoarthritis-part-1
[3] Make a patient-specific plan for canine osteoarthritis: https://www.dvm360.com/view/make-a-patient-specific-plan-for-canine-osteoarthritis
[4] Rehabilitation and canine osteoarthritis: a multimodal approach: https://www.dvm360.com/view/rehabilitation-and-canine-osteoarthritis-a-multimodal-approach
[5] Study suggests canine elbow osteoarthritis patients may be referred late: https://www.dvm360.com/view/study-suggests-canine-elbow-osteoarthritis-patients-may-be-referred-late-reducing-successful-treatment
[6] Managing osteoarthritis in dogs (Proceedings): https://www.dvm360.com/view/managing-osteoarthritis-dogs-proceedings
[7] Tools for addressing osteoarthritis pain: https://www.dvm360.com/view/tools-for-addressing-osteoarthritis-pain
[8] Canine OsteoArthritis Staging Tool Now Available: https://www.dvm360.com/view/new-standardized-approach-to-diagnosing-and-monitoring-canine-oa
[9] Osteoarthritis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/musculoskeletal-system/osteoarthritis-in-dogs-and-cats/osteoarthritis-in-dogs-and-cats
[10] A mulitmodal approach to treating canine osteoarthritis beyond NSAIDs: https://www.dvm360.com/view/mulitmodal-approach-treating-canine-osteoarthritis-beyond-nsaids-sponsored-nestl-purina
