# 伴侣动物的窦性心动过速

窦性心动过速是兽医实践中最常遇到的心律失常之一，影响所有年龄段的犬和猫。这种特征为心率超过物种特异性正常范围但维持正常电传导的疾病，既是对压力的生理反应，也是潜在疾病过程的病理指标。

本综合报告探讨了伴侣动物窦性心动过速的多面性，探索了从检查室压力到严重心脏和全身疾病的多种病因。分析涵盖了使用心电图和辅助测试的诊断方法，包括β受体阻滞剂和钙通道阻滞剂的治疗干预，以及严重依赖潜在原因的预后考虑。理解这种疾病的复杂性对于有效的临床管理和最佳的患者结局至关重要。

## 疾病概述

**窦性心动过速**被定义为一种规律性窦性心律，其心率快于正常但通常适合动物所处的情况[1]。在犬中，正常静息心率范围为70-120次/分钟，而猫通常表现为120-140次/分钟[2]。窦性心动过速代表一种生理反应，其中窦房结以升高的速率放电，同时维持正常的电传导通路。

这种情况在犬和猫中都很常见，作为一种代偿机制。在受压力的猫中，在检查室静息时心率可达240次/分钟[3]。健康的犬在睡眠期间心率可低至十几次，而在最大运动期间可达≥250次/分钟[3]。

**从流行病学角度看**，窦性心动过速在兽医实践中经常遇到，作为对各种生理和病理状况的继发反应。它通常发生在经历压力、运动、甲状腺功能亢进、发热、疼痛、血容量不足、心脏压塞或心力衰竭的动物中[3]。当发生充血性心力衰竭时，交感神经张力增加通常导致窦性心律失常消失和心率增加[4]。这种情况也可能发生在使用增加窦房结放电速率的药物时，如儿茶酚胺[3]。

### Sources
[1] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[2] Resting Heart Rates: https://www.merckvetmanual.com/multimedia/table/resting-heart-rates
[3] Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[4] Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats

## 常见原因和病理生理学

犬和猫的窦性心动过速由多种生理和病理原因引起，这些原因增加了交感神经系统活动或降低了副交感神经张力。压力是最常见的生理原因，检查室压力经常使猫的心率升高至180-220次/分钟，使犬的心率超过正常范围[1]。

疼痛和发热是重要的病理触发因素，它们刺激交感神经放电，导致窦房结不适当的加速。由脱水、失血或休克引起的血容量不足会产生代偿性心动过速，因为心血管系统试图维持足够的心输出量[2]。

内分泌疾病通常通过对心脏组织的代谢效应引起窦性心动过速。甲状腺功能亢进在猫中尤为重要，过量的甲状腺激素直接刺激心肌细胞并增加代谢需求。如果不治疗，这种情况可导致继发性心肌病[3]。

心脏疾病本身经常通过多种机制引发窦性心动过速。心力衰竭触发代偿性交感神经激活，因为身体试图在心功能降低的情况下维持灌注。猫的肥厚型心肌病通常表现为不适当的窦性心率，这是由于心室充盈改变和交感神经张力增加所致[1,4]。

药物相关原因包括儿茶酚胺、茶碱和特布他林等支气管扩张剂，以及β受体阻滞剂的停用。这些药物直接刺激肾上腺素能受体或改变自主神经平衡[2,7]。病理生理学涉及正常窦房结调节的破坏，其中去甲肾上腺素与β-1受体结合增加，使放电速率超过生理需求[6]。

### Sources
[1] Merck Veterinary Manual Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[2] Merck Veterinary Manual Heart Disease: Conduction Abnormalities in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[3] DVM 360 Feline cardiovascular diseases: https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[4] DVM 360 MVC 2018: Advances in Feline Heart Disease Diagnosis: https://www.dvm360.com/view/mvc-2018-advances-in-feline-heart-disease-diagnosis
[5] Merck Veterinary Manual Diagnosis of Heart Disease in Animals: https://www.merckvetmanual.com/circulatory-system/heart-disease-and-heart-failure/diagnosis-of-heart-disease
[6] Merck Veterinary Manual The Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/the-cardiovascular-system-in-animals
[7] Merck Veterinary Manual Antiarrhythmics for Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/antiarrhythmics-for-use-in-animals

## 临床症状和诊断方法

犬和猫的窦性心动过速表现为心率超过正常范围：犬>160次/分钟，猫>200次/分钟。临床症状通常反映潜在原因而非心动过速本身。动物可能表现出运动不耐、虚弱、呼吸急促，或在严重情况下出现晕厥[1]。

体格检查在听诊时发现心率快速。脉搏触诊确认心率升高，但脉搏质量可能根据潜在病因而有所不同。伴随发现可能包括发热、脱水迹象或疼痛证据[2]。

心电图是窦性心动过速的确定性诊断工具。心电图发现显示规律心律，每个QRS复合波前有正常P波形态，维持正常P-R间期。心率持续超过物种特异性正常限制[3]。在一个记录的病例中，一只混种犬表现为200次/分钟的窦性心动过速[4]。

额外的诊断测试应集中于识别潜在原因。全血细胞计数、血清生化面板和动脉血压测量有助于检测全身状况。超声心动图评估心脏结构和功能，排除原发性心脏病。胸部X光片可能显示肺部异常或心脏扩大[1][2]。

在猫中，心电图可以识别包括心动过速在内的心律失常，而超声心动图提供了对心腔大小和心脏功能的极好评估[3]。

### Sources

[1] Diagnosis of Heart Disease in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/diagnosis-of-heart-disease/diagnosis-of-heart-disease-in-animals

[2] 7-year-old 35.0-kg neutered male mixed-breed: https://avmajournals.avma.org/downloadpdf/view/journals/javma/aop/javma.25.04.0240/javma.25.04.0240.pdf

[3] Diagnosis of Cardiovascular Disease in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/diagnosis-of-cardiovascular-disease-in-cats

[4] ECG of the Month in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/260/14/javma.21.04.0183.xml

## 治疗选择和管理

犬和猫窦性心动过速的治疗侧重于解决潜在原因，同时在必要时提供症状管理。β肾上腺素能受体拮抗剂作为不适当窦性心动过速的一线治疗，阿替洛尔是兽医实践中最常用的药物[1]。犬的剂量为0.2-1 mg/kg口服每12小时一次，而猫接受1-2.5 mg/kg口服每12小时一次[1]。

当单独使用β受体阻滞剂不足时，可考虑使用III类抗心律失常药如索他洛尔。索他洛尔结合了钾通道阻滞和β阻滞特性，使其在1-2.5 mg/kg口服每12小时一次的剂量下对室上性和室性心动过速均有效[1]。

钙通道阻滞剂如地尔硫卓可能有益，特别是在患有肥厚型心肌病的猫中，窦性心动过速导致动态流出道梗阻[2]。地尔硫卓有效减缓房室传导和窦性心率[2]。

紧急管理需要立即处理潜在的病理生理学[3]。在血容量不足性休克中，窦性心动过速通常由灌注不足引起，需要液体复苏和疼痛控制[3]。非药物方法应解决环境压力源、温度控制，并确保充分水合，同时治疗可能引发心动过速的疼痛或焦虑[4]。

### Sources
[1] Antiarrhythmics for Use in Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-cardiovascular-system/antiarrhythmics-for-use-in-animals
[2] Antiarrhythmic therapy (Proceedings): https://www.dvm360.com/view/antiarrhythmic-therapy-proceedings
[3] Initial Triage and Resuscitation of Small Animal Emergency Patients: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/evaluation-and-initial-treatment-of-small-animal-emergency-patients/initial-triage-and-resuscitation-of-small-animal-emergency-patients
[4] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20

## 鉴别诊断和预后

### 鉴别诊断

窦性心动过速的关键鉴别诊断包括室上性心动过速（SVT）、心房颤动和心房扑动[1]。SVT通常表现为突发突止，窄QRS复合波，犬中心率为200-350次/分钟[2]。与窦性心动过速的逐渐心率变化不同，SVT在没有先前心率增加的情况下显示突然加速[1]。

心房颤动表现为不规则不规律心律，无P波和波动基线，通常超过160次/分钟[2]。心房扑动显示"锯齿状"基线模式，心房速率超过400次/分钟[2]。

鉴别特征包括P波形态和心率特征。窦性心动过速维持正常P波构型，心率逐渐变化，而异位心律显示改变或缺失的P波，突发突止[1][2]。

### 预后

预后完全取决于潜在病因[2]。由压力、运动或疼痛引起的生理性窦性心动过速通常在原因纠正后解决，预后极佳[2]。

由心力衰竭、甲状腺功能亢进或全身疾病引起的继发性窦性心动过速需要治疗原发性疾病[2]。超过180次/分钟的慢性心动过速可能导致心动过速性心肌病，但这种情况在心率控制后迅速逆转[7]。

否则健康的动物中的病理性窦性心动过速需要进一步的心脏评估，因为预后与潜在结构性心脏病的严重程度相关[2]。

### Sources

[1] Reading ECGs in veterinary patients: an introduction - dvm360: https://www.dvm360.com/view/reading-ecgs-in-veterinary-patients-an-introduction
[2] Heart Disease: Conduction Abnormalities in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/heart-disease-conduction-abnormalities-in-dogs-and-cats/heart-disease-conduction-abnormalities-in-dogs-and-cats
[7] Get with the beat! Analysis and treatment of cardiac arrhythmias: https://www.dvm360.com/view/get-with-beat-analysis-and-treatment-cardiac-arrhythmias-proceedings
