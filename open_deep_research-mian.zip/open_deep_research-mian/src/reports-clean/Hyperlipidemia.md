# 犬猫高脂血症

高脂血症是伴侣动物中一种重要的代谢性疾病，特征为血液中甘油三酯、胆固醇或两者浓度升高。这种疾病在犬和猫中的表现不同，雪纳瑞犬和比格犬存在品种易感性，并可导致严重并发症，包括胰腺炎、眼部疾病和神经系统疾病。该疾病可能是原发性（家族性/特发性）或继发于潜在疾病，如糖尿病、甲状腺功能减退或肾上腺皮质功能亢进。本报告探讨了小动物临床实践中高脂血症的病理生理学、临床表现、诊断方法和循证治疗策略。重点关注的领域包括严重高甘油三酯血症与胰腺炎风险之间的关键关系、物种特异性的临床表现，以及饮食管理作为一线治疗的作用。

## 疾病概述与病理生理学

高脂血症定义为血液中甘油三酯（高甘油三酯血症）、胆固醇（高胆固醇血症）或两者浓度增加[1]。犬猫的正常脂质代谢涉及复杂过程，其中脂质作为脂蛋白（乳糜微粒、VLDL、LDL和HDL）运输，通过特定细胞受体将脂质递送至适当组织[2]。

该疾病可以是生理性（餐后）或病理性，病理性高脂血症由原发性（遗传性/特发性）原因引起或继发于潜在疾病[2]。原发性高脂血症最常见于迷你雪纳瑞犬和比格犬[3]。虽然无性别偏好，但大多数患病犬为中年和老年[3]。猫的家族性高脂血症与脂蛋白脂肪酶缺乏相关[2]。

继发性高脂血症通常由糖尿病、胰腺炎、甲状腺功能减退或肾上腺皮质功能亢进引起，原因是脂蛋白脂肪酶活性受损[2]。脂蛋白脂肪酶由肝素、胰岛素和甲状腺激素增强，对于从血液中清除VLDL和乳糜微粒脂肪酸是必需的[2]。当此系统失效时，严重的高乳糜微粒血症可导致胰腺血管闭塞，导致缺血和继发性胰腺炎[2]。

### Sources
[1] Merck Veterinary Manual Feline Hepatic Lipidosis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
[2] DVM 360 Hyperlipidemia in dogs and cats: https://www.dvm360.com/view/hyperlipidemia-dogs-and-cats
[3] Hyperlipidemic states in the dog and cat (Proceedings): https://www.dvm360.com/view/hyperlipidemic-states-dog-and-cat-proceedings

## 临床表现与并发症

犬猫高脂血症在物种间的临床表现明显不同。在犬中，主要临床症状包括胃肠道紊乱，如呕吐、腹泻、腹痛和厌食[1]。犬还可能表现出神经系统并发症，包括癫痫发作，以及特征性的眼部表现[1]。

眼部并发症尤为重要，包括视网膜脂血症（可见富含脂质的视网膜血管）、脂性房水（前房中的乳白色混浊）、角膜脂质沉积（脂质性角膜病变）和角膜弓状病变[1,2]。这些眼部体征可作为高脂血症的早期指标，可能在常规眼科检查中被发现[2]。

在猫中，临床表现明显不同。猫高脂血症通常表现为皮肤黄瘤--由富含脂质的巨噬细胞积聚引起的无痛性隆起皮肤病变[1]。猫还可能发展周围神经病变，常见表现包括霍纳综合征、胫神经麻痹和桡神经麻痹[1]。

严重高乳糜微粒血症（>1,000 mg/dL）在两个物种中的关键并发症是由于乳糜微粒体积大导致的血管闭塞[1]。当胰腺血管发生闭塞时，随后的缺血会形成一个危险循环，导致继发性胰腺炎--这是高脂血症最严重的并发症之一[1,3]。这种关系使高脂血症既是胰腺炎的危险因素，也是其后果，严重高甘油三酯血症（≥500 mg/dL）被认为是重要的胰腺炎危险因素[3]。

### Sources
[1] Hyperlipidemia in dogs and cats: https://www.dvm360.com/view/hyperlipidemia-dogs-and-cats
[2] Ocular manifestations of systemic disease--when the eye is not the primary disease (Proceedings): https://www.dvm360.com/view/ocular-manifestations-systemic-disease-when-eye-not-primary-disease-proceedings
[3] Pancreatitis in Dogs and Cats - Digestive System: https://www.merckvetmanual.com/digestive-system/the-exocrine-pancreas/pancreatitis-in-dogs-and-cats

## 诊断方法与检测

高脂血症诊断需要系统方法，从适当的样本收集和视觉评估开始。血液样本应在禁食12小时后采集，以区分病理性与餐后高脂血症[1]。血清的肉眼检查显示，当甘油三酯浓度超过300-400 mg/dL时，出现明显的脂血症，由于高浓度的乳糜微粒和VLDL而呈乳白色[2]。

乳糜微粒测试通过将脂血症血清冷藏12-14小时来区分脂质异常[2]。乳糜微粒形成奶油状表层，而VLDL保持悬浮，形成混浊的下层。两层都表明乳糜微粒和VLDL过量[2]。

实验室检测包括空腹甘油三酯和胆固醇浓度，参考范围因实验室方法而异[2]。甘油三酯水平>500 mg/dL的犬需要立即管理，因为有胰腺炎风险[1]。高脂血症可能干扰比色法测定，因此应提交配对样本--一份用于脂质分析，一份清除乳糜微粒用于常规生物化学[2]。

继发性原因评估包括全血细胞计数、综合生化谱、低剂量地塞米松抑制试验、甲状腺功能测试（T4和TSH）以及血清胰腺脂肪酶免疫反应性[2]。甲状腺功能减退是犬中最常见的继发性原因[3]，而糖尿病、肾上腺皮质功能亢进和蛋白丢失性肾病是其他重要的鉴别诊断[4]。

### Sources
[1] Hyperlipidemic states in the dog and cat (Proceedings): https://www.dvm360.com/view/hyperlipidemic-states-dog-and-cat-proceedings
[2] Hyperlipidemia in dogs and cats: https://www.dvm360.com/view/hyperlipidemia-dogs-and-cats
[3] The posterior segment--the hidden world of the eye (Proceedings): https://www.dvm360.com/view/posterior-segment-hidden-world-eye-proceedings
[4] Monitor serum concentrations of triglyceride or cholesterol for hyperlipidemia: https://www.dvm360.com/view/monitor-serum-concentrations-triglyceride-or-cholesterol-hyperlipidemia

## 治疗与管理策略

犬猫高脂血症的治疗需要多模式方法，针对饮食管理、药物干预和潜在疾病治疗。治疗的第一线是减少膳食脂肪[1]。商业处方饮食在限制主人补充脂肪的情况下，已被证明在将过高的血清甘油三酯降至正常范围内持续有效[1]。

空腹血清甘油三酯浓度大于500 mg/dL的犬被认为有发展胰腺炎的风险，需要立即进行降脂管理[2]。饮食治疗的目标是维持血清甘油三酯浓度低于500 mg/dL[2]。高甘油三酯血症患者，特别是那些空腹甘油三酯浓度超过1000 mg/dL的患者，应以现实的治疗目标进行治疗，即持续维持水平在500-1000 mg/dL之间[1]。

Omega-3脂肪酸补充显示出潜在的降脂作用[3]。鱼油是omega-3多不饱和脂肪的重要来源，已被认识到其降低血清脂质（特别是甘油三酯）的能力[1]。当饮食管理证明不足时，药物制剂可能有益。吉非贝齐在犬中以10 mg/kg口服每日两次给药，已产生不同程度的血清甘油三酯浓度降低，并作为饮食治疗的有用辅助药物[2]。对于猫，推荐的吉非贝齐剂量为7.5-10 mg/kg口服每日两次[1]。

饮食干预后每6-8周定期监测血清脂质浓度是必要的[2]。治疗成功需要解决潜在疾病，如糖尿病、甲状腺功能减退和肾上腺皮质功能亢进，这些疾病通常导致继发性高脂血症[2][3]。高胆固醇血症对低脂饮食管理和消胆胺治疗（持续病例中1-2克每12小时一次）显示出改善的反应[2]。

### Sources
[1] Hyperlipidemic states in the dog and cat (Proceedings): https://www.dvm360.com/view/hyperlipidemic-states-dog-and-cat-proceedings
[2] Monitor serum concentrations of triglyceride or cholesterol for hyperlipidemia: https://www.dvm360.com/view/monitor-serum-concentrations-triglyceride-or-cholesterol-hyperlipidemia
[3] Hyperlipidemia in dogs and cats: https://www.dvm360.com/view/hyperlipidemia-dogs-and-cats

## 鉴别诊断与预后

### 鉴别诊断

犬猫高脂血症的关键鉴别诊断包括区分原发性（家族性）和继发性形式[1]。继发性高脂血症最常见与糖尿病、甲状腺功能减退、肾上腺皮质功能亢进和蛋白丢失性肾病相关[3]。原发性高脂血症最常见于迷你雪纳瑞犬和比格犬，特征为家族性高乳糜微粒血症[1]。

鉴别特征包括临床表现和潜在疾病标志物。继发性形式通常在治疗潜在疾病后消退，而原发性形式需要直接的脂质管理[3]。在猫中，家族性高脂血症表现为皮肤黄瘤和周围神经病变，与犬中占主导的胃肠道体征不同[2]。

### 预后因素

原发性和继发性高脂血症的预后差异显著。对于原发性高脂血症，甘油三酯水平>1000 mg/dL表明胰腺炎风险增加，需要立即治疗[3]。通过饮食管理将空腹甘油三酯维持在500-1000 mg/dL之间的犬预后良好[1]。

继发性高脂血症的预后取决于潜在疾病成功管理[2]。与甲状腺功能减退相关的高胆固醇血症通常在甲状腺激素替代治疗后消退，而糖尿病性高脂血症需要持续的胰岛素治疗和饮食管理[4]。

### 预期结果

通过适当治疗，75-80%的严重高脂血症猫在提供包括营养支持在内的定制重症监护时可以存活[7]。饮食反应性原发性高脂血症的犬可以实现长期控制，尽管有些需要辅助吉非贝齐治疗[1]。未经治疗的严重高甘油三酯血症由于胰腺炎并发症而具有显著的死亡风险。

### Sources

[1] Hyperlipidemic states in the dog and cat (Proceedings): https://www.dvm360.com/view/hyperlipidemic-states-dog-and-cat-proceedings

[2] Hyperlipidemia in dogs and cats: https://www.dvm360.com/view/hyperlipidemia-dogs-and-cats

[3] Monitor serum concentrations of triglyceride or cholesterol for hyperlipidemia: https://www.dvm360.com/view/monitor-serum-concentrations-triglyceride-or-cholesterol-hyperlipidemia

[4] Understanding and diagnosing canine hypothyroidism: https://www.dvm360.com/view/understanding-and-diagnosing-canine-hypothyroidism

[7] Feline Hepatic Lipidosis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
