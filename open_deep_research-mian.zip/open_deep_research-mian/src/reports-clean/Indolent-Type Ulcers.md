# 伴侣动物的惰性溃疡

惰性溃疡，也称为自发性慢性角膜上皮缺损（SCCED），是兽医实践中最常见的眼部疾病之一。这些无法愈合的浅表角膜溃疡主要影响中年犬，其特征是上皮基底膜附着机制缺陷，阻碍了正常的伤口愈合。本报告探讨了这些疑难病例的临床表现、诊断方法和治疗方式。关键主题包括有助于诊断的特征性荧光素染色模式，从简单清创到金刚砂角膜切除术的各种手术干预，以及根据治疗选择和患者因素而定的良好但可变的预后。

## 摘要

惰性溃疡在小动物眼科领域构成重大挑战，需要专业的诊断识别和针对性的治疗干预。特征性的"光晕"荧光素染色模式结合松散的上皮边缘，能够实现明确诊断，并与感染性或创伤性溃疡相鉴别。治疗成功率因方法而异，简单清创的愈合率为50%，而浅层角膜切除术提供100%的成功率。

| 治疗方法 | 成功率 | 愈合时间 | 是否需要麻醉 |
|---------|--------|----------|------------|
| 简单清创 | 50% | 2-3周 | 局部麻醉 |
| 网格角膜切开术 | 80% | 2-3周 | 局部麻醉 |
| 金刚砂磨削 | >80% | <2周 | 全身麻醉 |
| 浅层角膜切除术 | 100% | 2-3周 | 全身麻醉 |

尽管总体预后良好，但50%的复发率需要持续监测和客户教育。早期识别和适当的手术干预可最大限度地减少并发症，同时保持患病动物的视力和舒适度。

## 疾病概述

自发性慢性角膜上皮缺损（SCCED），通常称为惰性溃疡，是一种特殊类型的浅表角膜溃疡，无法通过正常的伤口愈合过程愈合[1]。这些溃疡的特征是上皮基底膜存在潜在异常，以及角膜上皮与下方基质之间粘附复合物的形成[1]。

SCCED主要影响中老年犬，通常年龄超过6岁，没有明显的性别倾向[1]。虽然最初在拳师犬中描述，但这些溃疡可发生在所有品种中，尽管拳师犬仍占较高比例[1]。该疾病几乎仅见于犬，在猫和马中仅有少数报道[2]。大多数病例是自发发生的，没有已知创伤，但有些可能发生在轻微角膜损伤之后[2]。

SCCED的高患病率使其成为兽医实践中最常见的眼部溃疡之一[1]。这些溃疡通常是慢性的、浅表的、非感染性的，并伴有不同程度的疼痛[3]。一个独特的特征是溃疡周围存在松散的上皮边缘，这 creates a characteristic fluorescein staining pattern with a dull halo around the brighter central stain [1].

### Sources

[1] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[2] Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[3] Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings

## 病理生理学和临床表现

惰性溃疡，也称为自发性慢性角膜上皮缺损（SCCED），是由上皮基底膜附着机制故障引起的[1]。病理生理学涉及角膜上皮与其基底膜之间粘附复合物的缺乏或缺失，阻碍了正常的再上皮化[6]。在浅层角膜基质中形成由胶原纤维和无定形材料组成的异常无细胞区， creating a barrier to reformation of corneal adhesion complexes [6].

典型的临床表现包括浅表角膜溃疡在正常的3-5天时间框架内无法愈合，通常持续超过14天[6]。特征性表现是溃疡区域周围有一圈松散、附着不良的上皮唇或卷边[1][3]。荧光素染色显示出独特的"光晕"模式，染料渗入未附着的上皮边缘下，在溃疡中心较亮的绿色染色周围形成暗绿色光晕[6]。

临床症状包括眼睑痉挛、畏光和流泪，表明眼部疼痛[6]。许多病例（58-64%）表现出浅表角膜新生血管，大多数病变发生在角膜轴旁或旁轴区域[6]。这些溃疡通常影响任何性别的中年犬，历史上拳师犬占比较高，但在大多数品种中都有记载[6]。

### Sources
[1] Merck Veterinary Manual The Cornea in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[2] Merck Veterinary Manual Image:Indolent corneal ulcer, dog: https://www.merckvetmanual.com/multimedia/image/indolent-corneal-ulcer-dog
[3] A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers

Looking at the provided source material, I can see it contains information about oral inflammatory diseases in small animals but does not contain specific information about indolent-type corneal ulcers, which are ophthalmic conditions. The existing section content already provides comprehensive information about diagnostic approaches and differential diagnosis for indolent-type ulcers, including fluorescein staining, Rose Bengal staining, clinical examination techniques, and critical differentials.

Since the source material is not relevant to the section topic of "indolent-type ulcers" (which are corneal/eye conditions), I cannot use it to enhance or modify the existing section content. The current section already covers:

- Fluorescein staining as the primary diagnostic tool
- Rose Bengal stain for enhanced sensitivity
- Clinical examination features (loose epithelial edges)
- Key differential diagnoses (infected ulcers, KCS, conformational issues)
- Timeline for investigation (7-10 days)

## 诊断方法和鉴别诊断

现有内容保持不变，因为提供的资料讨论的是口腔炎症性疾病而非角膜溃疡，因此不能用于编写或增强本节关于惰性角膜溃疡的内容。

### Sources
No relevant sources available for this section topic from the provided material.

## 治疗选择

惰性角膜溃疡的初始治疗涉及使用无菌棉签进行积极的上皮清创，以去除所有未附着的上皮[1]。清创后，执业兽医可以在几种手术干预措施之间选择。单独使用棉签清创可在30-40%的病例中实现愈合[3]。

使用皮下针头进行网格角膜切开术在前部基质中创建线性划痕或穿刺标记。该技术成功率约为80%，可在局部麻醉下进行[2]。金刚砂浅层角膜切除术使用3.5mm金刚石尖端电动磨头抛光前部基质，提供卓越的上皮清创[1]。研究表明，金刚砂角膜切除术比网格角膜切开术愈合更快，并发症发生率低[1]。

术后护理包括每日三次局部使用吗啡滴眼液（1%）进行疼痛管理和预防性广谱抗生素。伊丽莎白圈可防止愈合期间的自伤[1]。可能需要多次手术，对于顽固性病例有时需要第二次或第三次治疗[6]。浅层角膜切除术提供100%的成功率，但需要全身麻醉和手术显微镜[2]。

辅助治疗包括局部四环素类似物，与安慰剂治疗相比，可显著缩短愈合时间[5]。绷带式接触镜可提供角膜保护和增强舒适度。手术干预后通常需要2-3周才能完成上皮化[6]。

### Sources
[1] A challenging case: A dog with nonhealing corneal ulcers - dvm360: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[2] Spontaneous Chronic Corneal Epithelial Defects in Dogs: https://meridian.allenpress.com/jaaha/article/41/3/158/175943/Spontaneous-Chronic-Corneal-Epithelial-Defects-in
[3] Non-healing corneal ulcers - dvm360: https://www.dvm360.com/view/non-healing-corneal-ulcers
[4] The Cornea in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[5] In vivo effects of adjunctive tetracycline treatment on refractory corneal ulcers: https://avmajournals.avma.org/view/journals/javma/237/4/javma.237.4.378.xml
[6] Understanding canine ocular ulcers: https://www.dvm360.com/view/understanding-canine-ocular-ulcers

## 预后

惰性角膜溃疡在适当治疗下通常预后良好。通过适当的清创和手术干预，通常在两周内愈合[1][2]。成功率因治疗方法而异，简单清创的愈合率约为50%，而网格角膜切开术将成功率提高到约80%[4][5]。金刚砂角膜切除术比传统角膜切开术显示更快的愈合时间，浅层角膜切除术始终达到100%的成功率[2][4]。

然而，复发很常见，约50%的患者在同一眼或对侧眼出现溃疡[2]。默克兽医手册展示了成功的治疗结果，显示病例中仍有轻度角膜纤维化和浅表色素沉着，但视力得以保留[1]。可能需要多次治疗，因为有些病例需要在7-14天的间隔内重复清创程序[5]。

发病年龄影响治疗难度，年轻犬通常需要更积极的管理。环境因素如海拔和紫外线暴露在某些情况下可能影响疾病进展[6]。应向主人咨询疾病的慢性性质和可能需要多次手术的情况，但通过适当的兽医护理，大多数病例能够实现令人满意的愈合，并保持视力和舒适度。

### Sources
[1] Merck Veterinary Manual The Cornea in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-cornea-in-animals
[2] DVM 360 A challenging case: A dog with nonhealing corneal ulcers: https://www.dvm360.com/view/challenging-case-dog-with-nonhealing-corneal-ulcers
[3] DVM 360 Corneal disease (Proceedings): https://www.dvm360.com/view/corneal-disease-proceedings
[4] DVM 360 Canine keratitis: Ulcers to KCS (Proceedings): https://www.dvm360.com/view/canine-keratitis-ulcers-kcs-proceedings
[5] Canine corneal diseases: Treatment for transparency greater than the federal stimulus (Proceedings): https://www.dvm360.com/view/canine-corneal-diseases-treatment-transparency-greater-federal-stimulus-proceedings
