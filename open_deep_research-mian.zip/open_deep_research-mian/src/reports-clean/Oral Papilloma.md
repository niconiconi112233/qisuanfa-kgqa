# 伴侣动物口腔乳头状瘤

口腔乳头状瘤病是小动物兽医实践中常见的病毒性疾病，其特征是在犬和猫的口腔内出现良性的菜花状生长物。该病由种特异性乳头瘤病毒引起，主要影响免疫系统尚未发育成熟的幼年动物，但在老年宠物中出现可能预示着潜在的免疫缺陷。

本报告通过全面分析其病毒病因学、独特的临床表现以及包括组织病理学和PCR检测在内的诊断方法，探讨了口腔乳头状瘤的临床意义。治疗策略从手术切除到新兴的药物治疗（如阿奇霉素治疗），而该病特有的自限性特征影响着管理决策。了解鉴别诊断，特别是将乳头状瘤与鳞状细胞癌区分开来，对于伴侣动物实践中的准确诊断和适当治疗干预至关重要。

## 摘要

口腔乳头状瘤病在小动物实践中是一种可管理但具有临床重要性的疾病。该病的双重性质--在幼犬中主要呈自限性，但在老年动物中可能提示免疫缺陷--需要仔细的临床评估。诊断方法已从单纯的视觉检查发展到包括PCR测试和免疫组织化学以进行确诊。

治疗策略显示出显著的多样性，从传统的手术切除到创新的药物治疗，如每日10 mg/kg的阿奇霉素，可在2-3周内使病变消退。由于缺乏特定的预防性疫苗，准确的鉴别诊断变得尤为重要，特别是在老年患者中区分乳头状瘤与鳞状细胞癌。

| 方面 | 幼犬 | 老年犬 |
|--------|------------|------------|
| 预后 | 优良，自限性 | 需要免疫缺陷评估 |
| 治疗 | 通常观察 | 更积极的干预 |
| 意义 | 良性病毒感染 | 潜在的潜在疾病 |

临床医生应优先考虑早期识别、适当的诊断检查以及根据患者年龄和免疫状态定制的治疗方法，以优化临床结果。

## 疾病概述与流行病学

口腔乳头状瘤病是一种良性病毒性疾病，其特征是在犬和猫的口腔内发展出指状或丝状突起[1]。这些乳头状瘤病变表面呈菜花状生长物，主要影响口腔黏膜、黏膜皮肤交界处和嘴唇周围的皮肤[1]。

病原体是犬乳头瘤病毒，这是一种种特异性DNA病毒[1]。口腔乳头状瘤表现出明显的流行病学模式，在幼犬和青少年犬中最常见，发病突然，生长和扩散迅速[1]。幼年动物由于免疫系统尚未成熟似乎特别容易感染。

在出现多个乳头状瘤的成年老年犬中，应怀疑存在潜在的免疫缺陷，因为这可能表明患有淋巴瘤等疾病[1]。该病没有特定的品种易感性，但影响所有品种的犬。

传播通过动物之间的直接接触发生，病毒通过口腔黏膜的微小破损进入。潜伏期各不相同，但病变通常在易感的幼年动物中突然出现并伴有特征性的快速进展。

有趣的是，口腔乳头状瘤病通常是自限性的，随着动物免疫系统产生有效反应，病变通常在数周至数月内自行消退[1]。这种自行解决的特点是该病的一个显著特征。

### Sources
[1] Oral Papillomas in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs

## 诊断方法

口腔乳头状瘤的诊断主要依靠临床检查和在需要时进行组织病理学确认。视觉检查仍然是诊断的基石，揭示这些病毒病变特有的菜花状外观和质地[1]。独特的形态学结合幼犬的典型患者人口统计学特征，通常提供足够的诊断确定性。

当需要确诊时，组织活检通过组织病理学检查提供明确诊断[1]。显微镜评估显示特征性的组织结构变化，包括乳头瘤病毒感染典型的上皮增生和角化模式[2]。然而，在常规组织学检查中可能难以识别病毒包涵体。

对于需要病毒确认的病例，聚合酶链反应（PCR）测试为乳头瘤病毒检测提供了高灵敏度和特异性[1]。这种分子诊断技术可以在新鲜组织样本和福尔马林固定、石蜡包埋的标本上进行，使其适用于常规诊断使用。

免疫组织化学代表另一种诊断选择，当病毒包涵体在标准组织学染色中不明显时特别有用[2]。该技术可以识别感染组织内的病毒抗原，确认病变的病毒病因学。

### Sources
[1] Oral Papillomas in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
[2] Feline viral skin diseases (Proceedings): https://www.dvm360.com/view/feline-viral-skin-diseases-proceedings

## 治疗选择

口腔乳头状瘤的治疗根据严重程度和患者因素而有所不同[1]。手术切除仍然是最常见的方法，涉及在全麻下完全切除单个病变。冷冻疗法提供了一种非侵入性替代方案，使用液氮冷冻并破坏乳头状瘤组织。

药物治疗在兽医实践中显示出希望。阿奇霉素治疗已在犬乳头状瘤病例中证明有效，以10 mg/kg口服每24小时一次的治疗方案可在2-3周内使病变消退[2]。干扰素治疗，包括全身性和口服形式，提供免疫调节益处。低剂量口服干扰素（每日或隔日1,000-3,000 IU）代表了一种新兴的治疗选择[1]。

手术减瘤可以使用激光、电外科或射频外科技术进行[2]。锐利切除为外生性病变提供了另一种手术方法。在严重病例中，当犬无法正常吞咽或呼吸时，应考虑使用商业性或自体疫苗[2]。

支持性护理侧重于预防继发性细菌感染和保持口腔卫生。定期监测确保早期发现潜在的恶性转化，这在老年患者或免疫功能低下的动物中尤为重要[1]。

治疗选择取决于病变特征、患者年龄、免疫状态和主人偏好。在具有挑战性的病例中，可以结合多种方式以获得最佳结果。

### Sources
[1] Infectious skin disease in cats, more than you realized (Proceedings): https://www.dvm360.com/view/infectious-skin-disease-cats-more-you-realized-proceedings
[2] Merck Veterinary Manual Oral Papillomas in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs

## 预防、鉴别诊断和预后

**预防和疫苗接种：** 目前，犬口腔乳头状瘤尚无特定疫苗[1]。该病的自限性使得预防工作主要集中在一般卫生实践上。然而，在严重病例中，当犬因广泛病变而无法正常吞咽或呼吸时，应考虑使用商业性或自体疫苗[1]。针对个体犬的预防产品如核心疫苗广泛可用，尽管这些产品并不专门针对乳头瘤病毒感染[2]。

**鉴别诊断：** 口腔乳头状瘤的主要鉴别诊断是鳞状细胞癌，特别是当病变为单个或发生在成年老年动物中时[1,3]。其他疣状病变是鳞状上皮的良性外生性增生，临床上与病毒引起的乳头状瘤无法区分，但通常生长缓慢且为单个[1]。在猫中，鉴别诊断包括其他口腔肿瘤，如纤维肉瘤和各种良性肿瘤[3]。还必须排除恶性黑色素瘤，特别是在患有色素性口腔肿块的犬中[4]。

**预后：** 口腔乳头状瘤由于其自限性通常具有优良的预后。乳头状瘤可能在数周至数月内不经治疗而自行消退[1]。然而，在患有多个乳头状瘤的成年老年犬中，应怀疑存在潜在的免疫缺陷，如淋巴瘤，这可能影响预后[1]。自限性特征使得任何治疗的评估变得困难，尽管对于严重病例存在各种治疗选择[1]。

### Sources

[1] Oral Papillomas in Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-papillomas-in-dogs
[2] Risk reduction and management strategies to prevent transmission of infectious disease: https://avmajournals.avma.org/view/journals/javma/249/6/javma.249.6.612.xml
[3] Oral Tumors in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[4] Managing canine oral tumors: https://www.dvm360.com/view/managing-canine-oral-tumors
