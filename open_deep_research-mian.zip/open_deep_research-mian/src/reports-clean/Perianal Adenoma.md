# 伴侣动物肛周腺瘤：临床管理与预后

肛周腺瘤是兽医学中最具激素依赖性的肿瘤之一，主要发生于未去势雄性犬，由睾酮刺激特殊的肝样腺体所致。本综合报告探讨了这些良性肿瘤的临床意义，这些肿瘤主要影响老年未去势雄性犬，并显示出对单纯去势手术的显著反应性。分析涵盖了诊断方法（包括独特的细胞学发现）、从激素管理到手术干预的治疗策略，以及与适当治疗相关的良好预后。主要发现包括该肿瘤独特的肝样细胞形态、与肛囊腺癌的鉴别诊断挑战，以及对雄激素撤除治疗的显著治疗反应，使该疾病成为理解激素依赖性兽医肿瘤学的重要模型。

## 疾病概述与流行病学

肛周腺瘤，又称肝样腺瘤或环肛腺瘤，是起源于犬肛门周围特殊皮脂腺的良性肿瘤[1]。这些肿瘤由肝样细胞发展而来，肝样细胞是存在于肛周区域的雄激素敏感性腺体细胞。

肛周腺瘤主要发生于老年未去势雄性犬，去势可显著降低肿瘤发生率[1]。强烈的雄性倾向归因于这些腺体的雄激素依赖性。大多数患病犬为中老年，通常超过8岁。

虽然文献中专门针对肛周腺瘤的综合流行病学数据有限，但这些肿瘤占犬肛周肿块的很大比例。混种犬常受影响，尽管一些肛周肿瘤研究报告了品种易感性[1]。由于激素依赖性，该疾病在雌性犬和去势雄性犬中基本不存在。

与占所有皮肤肿瘤2%和肛周肿瘤17%且性别分布均等的肛囊腺癌不同[6]，肛周腺瘤显示出强烈的未去势雄性偏向和良性行为，使早期识别和适当管理对获得最佳预后至关重要。

### Sources
[1] Perianal Tumors in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perianal-tumors-in-animals
[6] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs

## 病因学与病理生理学

肛周腺瘤是起源于肝样腺体（环肛腺）的良性肿瘤，肝样腺体是犬科动物特有的改良皮脂腺[1]。这些特殊腺体分布于犬的肛周区域、会阴部、尾部背侧基部及其他区域[2]。

肛周腺瘤的发展受雄激素（特别是睾酮）的强烈影响[1][2][4]。这解释了为什么这些肿瘤主要发生在未去势雄性犬中（占病例的90%），尽管它们也可能在去势雄性犬（20%）、未绝育雌性犬（9%）和绝育雌性犬（19%）中发生[2]。睾酮依赖性如此显著，以至于单纯去势通常可导致肿瘤消退[4]。

发病机制涉及激素刺激肝样腺体增生，进而发展为腺瘤样转化。这些细胞在形态上类似于肝细胞，特征是丰富的颗粒状细胞质和显著的核仁[2]。尽管存在一定的细胞多形性，这些肿瘤通常分化良好且恶性潜力相对较低。

未去势雄性犬的相关疾病包括睾丸肿瘤、前列腺增生和会阴疝，反映了持续雄激素暴露的更广泛影响[3][4]。肝样腺体对激素影响的反应性使肛周腺瘤成为兽医学中激素依赖性肿瘤的极好例子。

### Sources
[1] Merck Veterinary Manual Perianal Tumors in Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perianal-tumors-in-animals
[2] DVM 360 Clinical Exposures: Canine circumanal gland adenoma: The cytologic clues: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[3] MSD Veterinary Manual Disorders of the Rectum and Anus in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-rectum-and-anus-in-dogs
[4] DVM 360 Oral and perianal tumors (Proceedings): https://www.dvm360.com/view/oral-and-perianal-tumors-proceedings

## 临床表现与诊断

细针穿刺细胞学是肛周腺瘤的主要诊断工具。细胞学检查显示独特的圆形至多边形上皮细胞，聚集成团块，具有丰富的细颗粒状、双嗜性细胞质[1]。细胞含有圆形至卵圆形核，呈网状染色质和显著核仁，形态上类似于肝细胞[1]。

较小的储备型细胞具有较深的细胞质和较高的核质比，存在于团块边缘[1]。尽管存在轻度的细胞大小和核大小不等，这些肿瘤显示出均匀的细胞形态，恶性标准有限[1]。独特的颗粒状细胞质有助于将肛周腺瘤与其他肛周肿瘤（包括肛囊腺癌）区分开来[1]。

组织病理学评估确认细胞学诊断，并用于区分良性腺瘤和恶性变体。对手术边缘进行组织或血管侵犯的检查对于环肛腺癌的确定性诊断是必要的[1]。

主要鉴别诊断是肛囊腺癌，其在细胞学上表现为成团的立方形细胞，细胞边界不清，细胞质极少[2]。与肛周腺瘤不同，肛囊腺癌缺乏特征性的颗粒状细胞质和凝聚性团块模式[2]。

### Sources

[1] Clinical Exposures: Canine circumanal gland adenoma: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[2] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma

## 治疗策略与管理

手术切除仍然是肛周腺瘤的确定性治疗方法，完全切除通常可提供治愈性结果[1]。然而，在未去势雄性犬中，单纯去势可能有效导致肿瘤消退，因为这些肿瘤具有高度激素依赖性[1]。腺瘤对睾酮和其他雄激素的依赖性使得不进行手术切除的去势成为某些病例的一线治疗选择。

对于未去势雄性犬，通常推荐同时进行去势和肿瘤切除以获得最佳结果并降低未来肿瘤发展的可能性[1]。这种联合方法既解决了现有肿瘤，又解决了驱动肿瘤形成的基础激素刺激。

医疗管理选择包括激素治疗，适用于手术禁忌的病例。使用己烯雌酚的雌激素治疗已被采用，尽管这存在骨髓抑制风险并需要仔细监测[1]。对于直径小于1-2厘米的局灶性肿瘤，可考虑冷冻手术，但由于可能损伤括约肌，应避免在肛门附近使用[1]。

术后护理侧重于预防并发症和监测复发。新的肿瘤可能从附近增生的环肛腺发展，造成复发的假象[1]。对于不适合进一步手术的复发病例，辅助放射治疗提供两年内69%的完全肿瘤控制机会[1]。

### Sources

[1] Clinical Exposures: Canine circumanal gland adenoma: The cytologic clues: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues

## 鉴别诊断与并发症

区分肛周腺瘤与其他肛周肿块需要仔细的细胞学和临床评估。主要鉴别诊断是肛囊腺癌，尽管解剖位置相似，但其表现特征明显不同[7]。肛囊腺癌在细胞学上表现出较少凝聚的细胞团块，具有少量嗜碱性细胞质和不明显的细胞边界，与肛周腺瘤特征性的颗粒状、双嗜性细胞质和凝聚性细胞排列形成鲜明对比[7]。

其他重要的鉴别诊断包括浆细胞瘤、鳞状细胞癌、基底细胞肿瘤和皮肤附属器肿瘤[6][7]。肛周腺瘤细胞独特的肝样外观，具有丰富的类似肝细胞的颗粒状细胞质，有助于将其与其他肿瘤类型区分开来[7][9]。

关键区分因素包括解剖起源（肛周腺瘤起源于环肛腺，而肛囊腺癌起源于肛囊内的顶泌腺）、细胞学外观和生物学行为[7][8]。肛周腺瘤是睾酮依赖性的且通常为良性，而肛囊腺癌具有高度侵袭性并具有显著的转移潜力，常表现为高钙血症和腰下淋巴结肿大[8][10]。

肛周腺瘤的并发症通常很少。主要关注点涉及罕见情况下可能的恶性转化，尽管这种情况很少发生[6]。完全手术切除通常可预防复发，尽管新的肿瘤可能从附近增生的环肛腺发展，造成复发的假象[7]。

### Sources
[1] Cytology of lumps and bumps (Proceedings): https://www.dvm360.com/view/cytology-lumps-and-bumps-proceedings-0
[2] Clinical Exposures: Canine circumanal gland adenoma: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues
[3] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[4] Can you use cytology to predict tumor behavior (Proceedings): https://www.dvm360.com/view/can-you-use-cytology-predict-tumor-behavior-proceedings
[5] Identifying and treating anal sac adenocarcinoma in dogs: https://www.dvm360.com/view/identifying-and-treating-anal-sac-adenocarcinoma-dogs

## 预后与长期结果

当实施适当治疗时，犬肛周腺瘤的预后通常良好。单纯去势通常导致显著的肿瘤消退，许多腺瘤在手术后数月内完全消失[4]。对于患有肛周腺瘤的未去势雄性犬，去势消除了驱动肿瘤生长的睾酮刺激，导致良好的长期结果。

手术切除结合去势提供了良好的局部控制。当获得完全手术边缘时，复发率相对较低。一项研究报告，根据手术技术的不同，约22.9%至31.5%的病例出现肿瘤复发[1,5]。然而，大多数复发可以通过额外的手术干预或辅助治疗成功管理。

复发检测的中位时间范围为25至960天，中位数为343天[3]。生活质量考虑因素通常是有利的，因为这些良性肿瘤在适当管理时很少引起显著的长期发病率。1年、2年和3年生存率分别为95%、72%和66%，均表现优异[1]。

影响结果的预后因素包括就诊时肿瘤大小、手术切除的完全性和去势状态。早期干预和完全手术切除提供最佳的长期预后。与恶性肛周肿瘤不同，肛周腺瘤在适当治疗时对总生存率影响最小。

### Sources

[1] Treatment, prognosis, and outcome of dogs treated for rectal: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.10.0666.xml
[2] Complications associated with modified closed anal: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0155/javma.25.03.0155.pdf
[3] Oral and perianal tumors (Proceedings): https://www.dvm360.com/view/oral-and-perianal-tumors-proceedings
[4] Long-term outcomes associated with a modified versus: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0239.xml
