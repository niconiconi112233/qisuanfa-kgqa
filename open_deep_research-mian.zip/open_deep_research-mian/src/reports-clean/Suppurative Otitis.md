# 伴侣动物的化脓性耳炎

化脓性耳炎是兽医临床中最具挑战性的炎症性耳部疾病之一，其特征为脓性分泌物和细菌感染，可进展为严重的神经系统并发症。本综合报告探讨了犬猫化脓性耳炎的多因素性质，涵盖了从细胞学评估到先进成像技术的基本诊断方法。分析探讨了主要细菌病原体，包括假中间型葡萄球菌和铜绿假单胞菌，同时详细说明了结合局部抗菌药物与全身治疗的循证治疗方案。文章还检查了关键的临床表现、鉴别诊断标准和预防策略，以及影响恢复结果的预后因素和潜在并发症，如永久性听力损失或前庭功能障碍。

## 疾病概述

化脓性耳炎定义为耳道的炎症性疾病，特征为含有中性粒细胞和致病菌的脓性渗出物（默克兽医手册）。该疾病与红斑-蜡样耳炎的区别在于存在大量浓稠的脓性分泌物而非蜡样物质，代表了对细菌感染更严重的炎症反应（DVM360）。

从流行病学角度看，化脓性耳炎影响犬和猫，但在具有解剖学易感因素的犬中更为常见，如垂耳或狭窄耳道（默克兽医手册）。该疾病通常作为潜在原发性病因的继发并发症发展，最常见的是过敏性皮炎，这占犬外耳炎病例的大多数（AVMA期刊）。品种特异性模式包括具有结构性耳部异常的犬易感性增加，而骑士查理王小猎犬可能出现原发性分泌性中耳炎的独特表现，特征性临床症状包括谨慎的颈部姿势（默克兽医手册）。

该疾病代表着一个重要的临床挑战，因其倾向于慢性化并可能进展为中耳炎和内耳炎，这可能导致永久性神经系统并发症，包括面神经麻痹和前庭功能障碍（默克兽医手册）。

## 常见病原体

犬猫化脓性耳炎涉及几种关键的细菌和真菌生物，它们在疾病过程中充当持续因素。细菌感染主导急性表现，而酵母感染经常使慢性病例复杂化[1]。

**葡萄球菌属**代表急性化脓性耳炎中最常见的细菌病原体，其中*中间型葡萄球菌*（现为*假中间型葡萄球菌*）是主要分离株[1]。这些革兰氏阳性球菌通常少量存在于健康耳道中，但当环境变化促进过度生长时变得具有致病性[1]。

**铜绿假单胞菌**在慢性化脓性耳炎病例中成为主要关注点[3]。这种革兰氏阴性杆菌产生特征性的绿色粘稠分泌物，并引起耳道上皮的严重溃疡[3]。研究表明，93.4%的*铜绿假单胞菌*分离株对环丙沙星和马波沙星保持敏感，而只有71%对恩诺沙星有反应[3]。

**变形杆菌属**也导致慢性感染，特别是*奇异变形杆菌*，在细胞学上呈现杆状生物[1,6]。这些细菌以及*大肠杆菌*通常从患病耳道中培养出来，但在健康耳道中很少发现[1]。

**厚皮马拉色菌**是主要的酵母病原体，在特应性皮炎犬中尤其普遍[1]。虽然少量可能正常，但显著增殖表明需要抗真菌治疗的病理性感染[1,6]。马拉色菌发酵产物表现出严重的炎症特性，有助于疾病的持续存在[1]。

### Sources
[1] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
[2] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[3] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[4] Diagnosing and managing otitis externa in the real world (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-otitis-externa-real-world-proceedings
[5] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[6] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

## 临床症状和体征

犬猫化脓性耳炎表现为特征性的脓性分泌物，伴有明显的临床表现。标志性症状是大量浓稠的脓性渗出物，这与红斑-蜡样外耳炎中见到的蜡样分泌物明显不同[1]。这种脓性物质通常具有特别刺鼻的气味，特别是当涉及铜绿假单胞菌等革兰氏阴性杆菌时[1]。

疼痛指标很明显，包括摇头、抓耳和耳部操作时疼痛[1]。受影响的动物在耳部疼痛时可能表现出头部倾斜，但这不同于内耳受累时看到的真正神经性头部倾斜[2]。目视检查显示耳道发红、糜烂、溃疡和肿胀[1]。

当化脓性耳炎进展累及中耳或内耳时，会出现神经系统体征。这些包括面神经麻痹导致无法眨眼、霍纳综合征（眼球内陷、上睑下垂、瞳孔缩小）和干性角膜结膜炎[2]。内耳受累产生周围前庭体征，包括同侧头部倾斜、快速相远离患侧的自发性水平或旋转性眼球震颤，以及平衡问题[2,4]。

品种特异性模式包括垂耳或狭窄耳道犬的更高易感性[1]。骑士查理王小猎犬可能出现原发性分泌性中耳炎的独特表现，包括谨慎的颈部姿势和自发性发声[2]。

### Sources
[1] Merck Veterinary Manual Otitis Externa in Animals: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Merck Veterinary Manual Otitis Media and Interna in Animals: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[3] Merck Veterinary Manual Ear Infections and Otitis Externa in Dogs: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/ear-infections-and-otitis-externa-in-dogs
[4] DVM 360 Otitis media and interna: Look for neurological signs: https://www.dvm360.com/view/otitis-media-and-interna-look-neurological-signs

## 诊断方法

**耳镜检查是诊断犬猫化脓性耳炎的基础**[1]。这需要适当的技术以有效可视化耳道和鼓膜。应向背侧和外侧牵拉耳廓以拉直L形耳道，允许通过垂直和水平耳道交界处的背侧褶皱[1]。视频耳镜提供比手持仪器更优越的放大和细节，使操作更安全并可视化更好[4]。

**必须对每个有耳炎临床症状的患畜进行细胞学评估**[1,2]。在应用任何清洁剂之前，使用棉签从水平耳道交界处采集样本[4]。改良瑞氏染色（Diff-Quik）提供快速、实用的结果，用于识别细菌、酵母和炎症细胞[1,4]。中性粒细胞吞噬细菌的存在证实了致病性感染而非定植[1]。

**当细胞学显示混合感染、化脓性炎症或怀疑中耳炎时，需要进行细菌培养和药敏试验**[2]。从水平耳道进行的培养为全身治疗提供指导，尽管局部浓度超过全身最低抑菌浓度[4]。

**CT或MRI的先进成像优于传统X线摄影，用于检测中耳炎**[6]。这些模态显示液体积聚、鼓泡壁变化和软组织受累，这些可能在X线上不可见[6]。

**鼓膜切开术允许直接取样和治疗中耳感染**[6]。这需要使用带套囊的气管内插管的全身麻醉，以防止冲洗期间误吸[6]。

### Sources
[1] Merck Veterinary Manual Otitis Externa in Animals: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] DVM 360 Ear we go again: https://www.dvm360.com/view/ear-we-go-again:-improve-your-otitis-diagnostics
[3] DVM 360 Diagnostic otology: https://www.dvm360.com/view/diagnostic-otology-proceedings
[4] DVM 360 Stopping the otitis snowball: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[5] Merck Veterinary Manual Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[6] Merck Veterinary Manual Otitis Media and Interna: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

## 治疗选择

化脓性耳炎治疗需要多方面的方法，结合局部抗菌药物、全身治疗和潜在炎症的管理[1][2]。局部抗菌剂被认为是治疗的基石，因为它们达到的浓度是最小抑菌浓度的1000倍，通常可以克服细菌耐药机制[2]。对于大多数犬，应每天两次应用5-10滴局部药物，体积根据患畜大小调整[2]。

当耳道增生、糜烂或存在中耳炎时，需要全身性抗生素[3]。氟喹诺酮类药物是革兰氏阴性感染的首选，基于优越的疗效数据，马波沙星（4-5.5 mg/kg每日）和环丙沙星（30 mg/kg每日）是一线选择[3]。对于假单胞菌感染，应使用Tris-EDTA预处理增强局部治疗，这会破坏细菌细胞膜并增加抗生素渗透性[2]。

抗炎治疗对于减轻疼痛、肿胀和耳道狭窄至关重要[4]。全身性泼尼松龙以1-2 mg/kg每日使用2-4周，可以显著改善耳道通畅性，使医疗管理比手术干预更成功[4]。局部皮质类固醇应使用有效减轻炎症的最弱效制剂[4]。

耳道冲洗方案至关重要，特别是对于碎屑积聚的慢性病例[4]。当怀疑中耳炎或可视化受损时，可能需要在全身麻醉下进行深度耳道冲洗[4]。

### Sources
[1] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[3] Otitis externa - a quick guide to management (Proceedings): https://www.dvm360.com/view/otitis-externa-quick-guide-management-proceedings
[4] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

## 预防措施

预防化脓性耳炎需要多方面的方法，针对原发性病因、易感因素和环境管理[1]。最关键的预防策略涉及识别和管理潜在的过敏性疾病，特别是特应性皮炎和食物过敏，这些是犬外耳炎的主要原因[3]。

定期耳道清洁构成预防护理的基础。使用适当的溶解耳垢溶液的家庭清洁方案有助于去除过敏原、碎屑并减少微生物过度生长[5]。应教导客户使用温和清洁剂（如胶束溶液）或用温水球管抽吸的正确清洁技术[5]。清洁频率应根据宠物的易感因素和反应进行个体化。

易感因素管理包括控制游泳引起的过度潮湿，避免过度拔毛或使用棉签引起的医源性创伤[1][4]。虽然耳毛可能导致耳炎，但常规拔毛可能引起炎症，只应在必要时进行[6]。

环境控制措施专注于减少过敏原和维持适当的湿度水平。对于特应性患者，通过空气过滤和定期清洁最小化对已识别环境过敏原的暴露可以减少耳炎发作[3]。

含有乙酸、硼酸或氯己定的消毒溶液可在高风险患者中预防性使用，尽管效果各不相同[5]。定期兽医监测，包括耳镜检查和细胞学，可以在进展到化脓性阶段之前进行早期检测和干预[1]。

### Sources
[1] Otitis: the keys to diagnosing this multifactorial inflammatory disease: https://www.dvm360.com/view/otitis-the-keys-to-diagnosing-this-multifactorial-inflammatory-disease
[2] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[3] Straight-up sewer ear: How to improve your outcome in otitis externa cases: https://www.dvm360.com/view/straight-sewer-ear-how-improve-your-outcome-otitis-externa-cases
[4] Diagnosing and managing otitis externa in the real world: https://www.dvm360.com/view/diagnosing-and-managing-otitis-externa-real-world-proceedings
[5] Approach to otitis, client education leads to success: https://www.dvm360.com/view/approach-otitis-client-education-leads-success-proceedings
[6] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause

现有内容已经提供了化脓性耳炎鉴别诊断的全面概述。基于原始材料，我可以通过添加细胞学检查作为关键诊断工具的信息并强化一些区分特征来增强本节。以下是更新后的部分：

## 鉴别诊断

区分化脓性耳炎与其他耳部疾病需要仔细评估临床表现和诊断结果。红斑-蜡样耳炎通常表现为发红的耳道和过多的蜡样产生，没有脓性分泌物[1]。细胞学上缺乏中性粒细胞炎症有助于将其与化脓性形式区分开来。

异物性耳炎表现为急性发作，单侧发病，耳镜检查可见异物。与化脓性耳炎不同，异物引起机械刺激而非感染性炎症[1]。

肿瘤性疾病，包括蜡样腺腺瘤和腺癌，表现为耳道内的坚实肿块。先进成像显示特征性的占位性病变，可能涉及骨骼，这与化脓性耳炎中看到的弥漫性炎症变化形成对比[2]。

炎性息肉表现为从鼓泡或鼻咽延伸的光滑、粉红色、带蒂的肿块[3]。这些良性生长物常见于年轻猫，可能引起并发上呼吸道体征，这与典型的化脓性耳炎不同。组织病理学检查证实了息肉的非肿瘤性质[3]。

关键诊断标准包括细胞学检查显示化脓性病例中存在细菌生物和中性粒细胞[4]。使用改良瑞氏染色的细胞学可快速识别致病细菌、酵母和炎症细胞[4]。耳镜可视化脓性分泌物和识别特定病原体的培养结果进一步证实化脓性耳炎。当仅靠临床检查不足时，先进成像有助于区分炎症性、肿瘤性和异物性原因。

### Sources
[1] Managing recurrent otitis externa in dogs: what have we learned?: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/243/6/javma.243.6.775.xml
[3] Inflammatory Polyps in Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/tumors-of-the-ear-in-small-animals/inflammatory-polyps-in-cats
[4] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause

## 预后

化脓性耳炎的预后因治疗反应、疾病慢性化和影响恢复时间线的潜在因素而有显著差异[1]。早期干预为感染和临床症状的完全解决提供最有利的结果[2]。

急性耳炎病例通常在适当治疗的一到三周内成功响应。然而，慢性化脓性耳炎带来更大挑战，治疗时间延长到四周至三个月或更长[1]。在需要全身性皮质类固醇、全身麻醉、成像和积极治疗的困难病例中，成本和副作用风险显著增加。

几种并发症可能影响长期预后。神经功能缺陷包括霍纳综合征、头部倾斜和面神经麻痹可能在感染解决后永久存在[2]。具有预先存在神经体征的猫出现永久性并发症的几率显著更高 - 霍纳综合征为2.6倍，头部倾斜为3.3倍，面神经麻痹为5.6倍，与没有这些状况的猫相比[3]。

听力损失代表一个严重的潜在并发症，通过感染损伤或氨基糖苷类等某些药物的医源性原因发生[4]。一些患者可能发展成永久性耳聋，需要终身适应。

当尽管积极治疗医疗管理失败时，需要全耳道切除术加鼓泡骨切除术[1]。幸运的是，通过适当的早期诊断和治疗方法，很少需要这种手术干预。

长期管理成功关键取决于识别和控制原发性潜在原因，如过敏性皮炎、食物反应或内分泌疾病[1]。如果不解决这些易感因素，无论初始治疗成功如何，复发发作仍可能发生。

### Sources
[1] Treatment of Pseudomonas otitis in the dog: https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[2] Otitis Media and Interna in Animals: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[3] Comparison of complications and outcome following unilateral: https://avmajournals.avma.org/view/journals/javma/255/7/javma.255.7.828.xml
[4] Stopping the otitis snowball: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
