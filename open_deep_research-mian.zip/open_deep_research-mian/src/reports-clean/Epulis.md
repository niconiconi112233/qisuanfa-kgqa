# 宠物疾病：齿龈瘤

齿龈瘤是小动物兽医临床中最常见的口腔生长物之一，主要影响犬类，偶尔见于猫类。这些良性牙龈肿块，现在更精确地归类为外周牙源性纤维瘤和犬棘状成釉细胞瘤，需要及时识别和适当的外科治疗以预防并发症并确保最佳的患者预后。本综合报告探讨了伴侣动物齿龈瘤的临床表现、诊断方法、治疗方案和预后考虑因素。重点内容包括这些增殖性病变的非传染性病因、组织病理学诊断的关键作用、基于肿瘤类型的手术切除技术，以及良性变体完全切除后的良好预后。

## 疾病概述

齿龈瘤是一个临床描述性术语，指任何局部牙龈增生，而非特定的组织病理学诊断[1]。在兽医牙科领域，这一术语已发生显著演变，传统分类已被基于组织来源和生物学行为的更精确命名法所取代。

**定义**
历史上，齿龈瘤分为三种类型：纤维性齿龈瘤、骨化性齿龈瘤和棘状齿龈瘤[2]。然而，当代兽医病理学现在将这些视为不同的实体。纤维性和骨化性齿龈瘤现在被归类为外周牙源性纤维瘤（POF），这是起源于牙周韧带结构的良性肿瘤[2]。棘状齿龈瘤已被重新分类为犬棘状成釉细胞瘤，反映了其更具侵袭性的生物学行为[1]。

**流行病学背景**
外周牙源性纤维瘤是犬类最常见的良性口腔肿瘤，占良性口腔肿瘤的77.8%[2]。这些病变主要影响6岁以上的犬，通常是单发的，但也可能出现多发病变[2]。猫很少发生POF，但发生时，多发病变比犬类更常见[2]。最近瑞士的研究证实POF占所有口腔肿瘤的63%，强调了它们在小动物临床中的重要性[3]。总体而言，口腔肿瘤的发病率为4.59/1000例患者，诊断时的中位年龄为9.66岁[4]。

犬棘状成釉细胞瘤倾向于发生在下颌骨前部，但可能出现在口腔的任何部位，当前文献中未报告特定的品种易感性[1]。

### Sources
[1] AVMA 2017: Managing Oral Tumors in Dogs: https://www.dvm360.com/view/avma-2017-managing-oral-tumors-in-dogs
[2] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[3] A retrospective analysis of oral tumors in dogs in Switzerland: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.06.0414.xml
[4] Understanding canine oral neoplasia - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.xml

## 常见病原体

齿龈瘤是一种非传染性疾病，起源于反应性增生而非病原体参与[1]。与犬猫的许多口腔炎症性疾病不同，齿龈瘤不是由病毒或细菌病原体引起的[1]。相反，这些牙龈肿块是由牙周韧带组织对慢性刺激或机械创伤的反应性增生而发展形成的[1][4]。

最常见的类型是外周牙源性纤维瘤（以前称为纤维性或骨化性齿龈瘤），起源于牙周韧带细胞和牙龈上皮，而非传染性病原体[1][5]。同样，更具侵袭性的犬棘状成釉细胞瘤（以前的棘状齿龈瘤）起源于牙板细胞，没有微生物病因[1]。

这种非病原性病因将齿龈瘤与影响伴侣动物的传染性口腔疾病（如病毒性乳头状瘤、细菌性牙龈炎或真菌性口炎）区分开来。虽然如果齿龈瘤发生溃疡或创伤可能会发生继发性细菌污染，但这些肿块的形成主要不依赖于传染性生物体[2]。理解这一区别在临床上很重要，因为治疗重点是手术切除而非抗菌治疗[1][4]。

### Sources

[1] Oral Tumors in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals

[2] Dental and oral examination: A visual atlas of dental and oral pathology (Proceedings): https://www.dvm360.com/view/dental-and-oral-examination-visual-atlas-dental-and-oral-pathology-proceedings

[3] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses

[4] Oral pathology and anatomic abnormalities (Proceedings): https://www.dvm360.com/view/oral-pathology-and-anatomic-abnormalities-proceedings

[5] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs

## 临床症状和体征

现有章节内容已经提供了关于齿龈瘤临床表现的全面概述。根据原始资料，我可以用关于品种模式和诊断考虑因素的额外具体细节来增强本节内容。

齿龈瘤通常表现为局部牙龈肿胀，通常最初无痛，这使得早期检测具有挑战性[1]。最常见的临床体征是可见的牙龈肿块，通常表现为起源于牙龈线附近的平滑、粉色、带蒂的生长物[1][2]。这些肿块范围可从相对小的结节到可能完全覆盖几个牙齿表面的大生长物[3]。

相关症状通常包括口臭（口臭）、进食困难和口腔出血[1][4]。宠物可能表现出不愿进食或吞咽困难，特别是当肿块干扰正常咀嚼机制时[1][5]。流涎过多（过度流口水）和带血唾液经常被观察到，特别是当齿龈瘤在进食过程中发生溃疡或创伤时[4][5]。

随着齿龈瘤增大，它们可能导致面部肿胀或不对称，主人可能注意到受影响区域的牙齿移位或松动[1]。肿块通常触感坚实，可能有更宽的附着基底，特别是在骨化性齿龈瘤中[1][2]。在猫中，齿龈瘤很少见，但出现时，往往是多发性的而非单发性的[4]。

犬棘状成釉细胞瘤（棘状齿龈瘤的当前术语）表现为红色、隆起的增生性牙龈肿块，可导致牙齿移位和骨侵袭[6][7]。这些病变可能在活检采集后快速生长，通常影响下颌骨前部[8]。

重要的是，许多宠物会掩盖与口腔肿块相关的疼痛，使得没有彻底口腔检查的诊断具有挑战性[1]。晚期病例可能出现继发性并发症，如牙齿脱落或难以维持正常口腔卫生，导致口臭加重和潜在的继发性细菌感染。

### Sources

[1] Oral pathology and anatomic abnormalities (Proceedings): https://www.dvm360.com/view/oral-pathology-and-anatomic-abnormalities-proceedings
[2] Oral neoplasia and surgery (Proceedings): https://www.dvm360.com/view/oral-neoplasia-and-surgery-proceedings
[3] Disorders of the Mouth in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-mouth-in-cats
[4] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[5] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[6] Canine acanthomatous ameloblastoma: https://www.merckvetmanual.com/multimedia/image/canine-acanthomatous-ameloblastoma
[7] Canine acanthomatous ameloblastoma, radiograph: https://www.merckvetmanual.com/multimedia/image/canine-acanthomatous-ameloblastoma-radiograph
[8] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses

考虑到现有章节内容和新的原始资料，我将综合这些信息，用额外的临床见解来增强诊断方法部分。

## 诊断方法

诊断齿龈瘤需要系统的方法，结合临床检查与先进的影像学和组织病理学评估。视诊和触诊构成初步评估，使兽医能够评估肿块特征、大小和位置[1]。然而，由于口腔肿块不易脱落，应避开细针抽吸，而采用组织活检进行明确诊断[4]。

组织活检仍然是齿龈瘤诊断的金标准。深部切开活检是必要的，因为由于覆盖的上皮增生，浅表取样可能错过诊断性组织[2]。对于外周牙源性纤维瘤（以前的齿龈瘤），完全手术切除通常需要拔除相关牙齿和刮除牙槽窝以去除剩余的牙周韧带[1,7]。

在进行麻醉和活检之前，兽医应拍摄口腔肿块照片并使用牙周探针记录测量结果[7]。牙科X线摄影在评估齿龈瘤方面起着关键作用，特别是骨化性变体，其在软组织阴影中显示明显的钙化[1]。然而，传统X线片只有在30-50%的骨破坏发生时才能检测到骨受累[6]。

CT或MRI的先进成像提供了对肿瘤范围和骨受累的优越评估，对手术规划至关重要[6]。这些成像方式对于评估侵袭性变体（如犬棘状成釉细胞瘤）特别有价值，这些变体经常侵犯周围组织和骨骼[1,7]。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings-0
[3] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses
[4] Oral tumors: Know the extent of disease prior to surgery: https://www.dvm360.com/view/oral-tumors-know-extent-disease-prior-surgery
[5] How to approach pet dental care year-round: https://www.dvm360.com/view/how-to-approach-pet-dental-care-year-round
[6] Finding and treating oral melanoma, squamous cell carcinoma, and fibrosarcoma in dogs: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[7] AVMA 2017: Managing Oral Tumors in Dogs: https://www.dvm360.com/view/avma-2017-managing-oral-tumors-in-dogs

## 治疗选择

手术切除是齿龈瘤的主要治疗方法，方法因齿龈瘤类型而异[1]。对于良性外周牙源性纤维瘤（以前称为纤维性或骨化性齿龈瘤），完全手术切除通常需要保守切除牙龈肿块、拔除受影响的牙齿以及刮除牙槽窝以去除剩余的牙周韧带[3]。

犬棘状成釉细胞瘤由于其局部侵袭性需要更积极的手术干预。广泛切除，包括1厘米正常软组织和骨骼边缘，对于实现治愈和预防复发至关重要[3]。对于恶性口腔肿瘤，目标是至少有2厘米干净边缘的广泛切除[2]。

当手术切除不完全或不可行时，放射治疗作为重要的辅助治疗。放射治疗可用于不可切除病例的主要治疗或术后控制显微镜下疾病[7]。特别对于棘状成釉细胞瘤，放射治疗已显示出优异的结果，80%的犬在三年时无肿瘤进展存活，85%在一年时无肿瘤[4]。

术后护理包括使用阿片类药物和非甾体抗炎药进行疼痛管理，以及氯己定口腔漱口。手术后6-8小时应提供软食，并在约两周的愈合期间维持[3]。

### Sources
[1] Understanding canine oral neoplasia: intrinsic rather than ...: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.09.0594.pdf
[2] Geriatric veterinary dentistry: how old is too old to make it ...: https://www.dvm360.com/view/geriatric-veterinary-dentistry-how-old-too-old-make-it-right
[3] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[4] Oral tumors: Know the extent of disease prior to surgery: https://www.dvm360.com/view/oral-tumors-know-extent-disease-prior-surgery
[5] Finding and treating oral melanoma, squamous cell ...: https://www.dvm360.com/view/finding-and-treating-oral-melanoma-squamous-cell-carcinoma-and-fibrosarcoma-dogs
[6] Oral neoplasia and surgery (Proceedings): https://www.dvm360.com/view/oral-neoplasia-and-surgery-proceedings
[7] Dispelling the myths of veterinary cancer and its treatment ...: https://www.dvm360.com/view/dispelling-myths-veterinary-cancer-and-its-treatment-proceedings
[8] Palliative radiation therapy for solid tumors in dogs: 103 cases ...: https://avmajournals.avma.org/view/journals/javma/248/1/javma.248.1.72.xml
[9] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses

## 预防措施

定期口腔检查是伴侣动物齿龈瘤预防的基石[1]。兽医团队应将常规口腔评估纳入每次健康检查，利用检测革兰氏阴性细菌产生的硫醇的诊断测试来识别早期牙周病[2]。这种主动方法能够在牙龈异常进展为更显著的肿块之前进行早期检测。

日常家庭护理显著降低了齿龈瘤发展的风险。宠物主人应实施一致的口腔卫生实践，包括刷牙、使用VOHC批准的牙科擦拭物和饮水添加剂[2]。每年两次的专业牙科清洁使兽医能够在牙龈变化成为临床显著肿块之前识别并处理它们。

早期干预对于最佳结果至关重要。兽医应在活检前拍摄任何口腔肿块的照片，并在检测到肿块时及时获取组织样本[3]。对于外周牙源性纤维瘤，保守切除活检结合拔除相关牙齿和刮除牙周韧带可预防复发[1]。在幼犬和幼猫就诊期间的定期监测有助于识别可能导致口腔肿块发展的先天性异常[4]。

品种特异性意识被证明是有价值的，因为某些品种表现出牙龈增生和口腔肿块的易感性[2][10]。最重要的原则是，牙龈疾病不会在干净的牙齿周围发展[6]。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] How to approach pet dental care year-round: https://www.dvm360.com/view/how-to-approach-pet-dental-care-year-round
[3] The diagnostic approach to oral masses: https://www.dvm360.com/view/the-diagnostic-approach-to-oral-masses
[4] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth
[5] MSD Veterinary Manual Dental Disorders of Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/dental-disorders-of-dogs
[6] The ABCs of veterinary dentistry: "G" is for gingiva: https://www.dvm360.com/view/abcs-veterinary-dentistry-g-gingiva

## 鉴别诊断

将齿龈瘤与其他口腔肿块区分需要系统评估临床和组织病理学特征[1]。主要的恶性鉴别诊断包括**恶性黑色素瘤**、**鳞状细胞癌**和**纤维肉瘤**--犬类最常见的三种口腔恶性肿瘤[1]。

**恶性黑色素瘤**表现为色素性或无色素性、溃疡性肿块，通常影响牙龈，具有快速转移潜力和>2cm肿瘤的不良预后[1]。**鳞状细胞癌**表现为不规则、花椰菜样肿块，具有高度侵袭性和显著的骨受累，是猫最常见的口腔恶性肿瘤[1,2]。**纤维肉瘤**通常表现为坚实、扁平、多叶状肿块，具有深部组织附着，但转移潜力低于黑色素瘤[1]。

**良性鉴别诊断**包括继发于牙周病的**牙龈增生**，与齿龈瘤的区别在于其炎症病因和对牙周治疗的反应[2,4]。**其他良性肿块**如成釉细胞瘤、浆细胞瘤和颗粒细胞瘤需要组织病理学区分[1]。

**传染性病因**包括猫的**嗜酸性肉芽肿**和局部刺激引起的**化脓性肉芽肿**必须被考虑[4]。**牙科疾病相关肿胀**由慢性牙槽骨炎引起，可能模拟肿瘤，但通常与特定牙齿病理相关[4]。

明确诊断需要**组织病理学检查**，因为仅凭临床外观不能可靠区分这些疾病[1,2]。先进成像可能揭示有助于鉴别诊断的特征性骨受累模式。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] Feline oral squamous cell carcinoma: An overview: https://www.dvm360.com/view/feline-oral-squamous-cell-carcinoma-overview
[3] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings-0
[4] Oral pathology and anatomic abnormalities (Proceedings): https://www.dvm360.com/view/oral-pathology-and-anatomic-abnormalities-proceedings

## 预后

齿龈瘤的预后因肿瘤类型和手术管理方法而有显著差异。外周牙源性纤维瘤（纤维性和骨化性齿龈瘤）在完全切除时预后良好，完全手术切除通常可治愈[1]。这些良性病变在采用包括拔牙和牙周韧带刮除的保守切除治疗时复发率最低。

棘状齿龈瘤（棘状成釉细胞瘤）尽管是良性的，但预后更为谨慎。虽然这些肿瘤不转移，但它们表现出局部侵袭性行为和显著的骨侵袭[2]。广泛手术切除，包括1厘米健康骨边缘，对于治愈和预防复发至关重要。放射治疗已显示出有希望的结果，研究报告在接受4周内12次治疗的犬中，80%在三年时无肿瘤进展存活[3]。

不完全的手术边缘是影响复发率的主要因素。位置和肿瘤大小也影响预后，较大的病变对治疗的反应较差[3]。生活质量考虑包括激进手术后可能的功能和外观变化，尽管犬通常能很好地适应口腔手术。

长期监测要求包括术后2周、2个月、6个月、12个月、18个月和24个月的定期复查，随后进行年度评估[1]。早期检测复发可改善治疗结果并维持患者生活质量。

### Sources

[1] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals
[2] Oral tumors: Know the extent of disease prior to surgery: https://www.dvm360.com/view/oral-tumors-know-extent-disease-prior-surgery
[3] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings-0
