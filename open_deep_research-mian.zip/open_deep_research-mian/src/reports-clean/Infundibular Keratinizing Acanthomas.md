# 伴侣动物的漏斗部角质化棘皮瘤

漏斗部角质化棘皮瘤（IKAs）是兽医皮肤科实践中影响犬猫的最常见良性毛囊肿瘤之一。这些独特的角质化上皮性肿瘤起源于毛囊漏斗部，为临床医生带来了独特的诊断和治疗挑战。本综合报告探讨了IKAs的临床特征、诊断方法和治疗策略，特别关注在挪威猎麋犬、拉萨犬、比利时牧羊犬和古代英国牧羊犬中观察到的品种特异性易感性。该分析涵盖了从初步临床识别到长期预后的基本方面，为兽医专业人员提供了管理这种良性但可能存在问题疾病的单发病灶和泛发形式的循证指导。

## 疾病概述

漏斗部角质化棘皮瘤（IKAs）是起源于犬猫毛囊漏斗部的良性表皮肿瘤。这些肿瘤的特征是充满角蛋白的囊性结构，内衬复层鳞状上皮，代表了伴侣动物中最常见的毛囊肿瘤之一[1]。

IKAs也被称为皮内角质化上皮瘤或角质棘皮瘤，它们很可能起源于毛囊而非毛囊间表皮[3]。这些良性肿瘤可在身体任何部位发生，在中年犬中，背部、尾部和四肢是最常见的部位[3][4]。

挪威猎麋犬、比利时牧羊犬、拉萨犬和古代英国牧羊犬最易发生这些肿瘤，其中挪威猎麋犬和拉萨犬有发生泛发性病变的风险[3][4]。最具特征性的表现是带有中央角质化孔的丘疹或结节，该孔可能突出于表皮表面，呈现角状外观；然而，许多这些肿瘤从不与表皮连续，可能仅表现为角质化囊肿[3]。

虽然关于小动物兽医学中IKAs的发病率、年龄分布模式和解剖部位偏好的具体流行病学数据在现有文献中仍然有限，但这些肿瘤被认为是皮肤科实践中重要的鉴别诊断。

### Sources
[1] Age- and breed-matched retrospective cohort study: https://avmajournals.avma.org/view/journals/javma/257/5/javma.257.5.507.xml
[2] Merck Veterinary Manual Diagnosis of Skin Diseases in Small Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/diagnosis-of-skin-diseases-in-small-animals
[3] Merck Veterinary Manual Epidermal and Hair Follicle Tumors in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[4] MSD Veterinary Manual Tumors of the Skin in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 常见病原体

漏斗部角质化棘皮瘤（IKAs）是良性肿瘤，没有已知的病毒或细菌病因学[1]。这些肿瘤很可能起源于毛囊结构而非传染性病原体[1]。与其他一些毛囊肿瘤不同，IKAs与乳头瘤病毒感染或细菌病原体无关[1][2]。

IKAs的病因学在很大程度上仍未明确，这使其区别于病毒引起的乳头状瘤和其他传染性毛囊疾病[1]。虽然肿瘤发展的确切机制尚不清楚，但这些病变似乎代表了毛囊上皮的良性增殖性生长，没有微生物参与[1][2]。

这种非传染性特征在将IKAs与其他可能具有传染性病因的毛囊肿瘤（如病毒性乳头状瘤或细菌性毛囊炎相关的增殖性病变）进行鉴别时很重要[2]。缺乏病原体参与意味着抗菌治疗不适用于IKA治疗，并且该疾病不会在动物之间传染[1]。

### Sources

[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 临床症状和体征

漏斗部角质化棘皮瘤表现为独特的良性生长物，其特征是角质化外观。这些肿瘤通常表现为从皮肤表面突出的坚硬、分层肿块，由于其角质化特性，常类似小角[1]。在某些情况下，上皮瘤可能仅表现为角质化囊肿而非突起性病变。

肿瘤可在身体任何部位发生，但最常见于背部、尾部和腿部[1]。中年犬主要受影响，某些品种显示易感性增加，特别是挪威猎麋犬、比利时牧羊犬、拉萨犬和古代英国牧羊犬[1]。

挪威猎麋犬和拉萨犬特别易患广泛性、泛发形式的疾病[1][2]。最具特征性的表现是带有中央角质化孔的丘疹或结节，该孔可能突出于表皮表面，呈现角状外观[2]。然而，许多肿瘤从不与表皮连续，可能仅表现为角质化囊肿。

当犬发现肿瘤有刺激性时，可能会出现临床并发症，导致通过抓挠、摩擦或试图咬掉它们而造成自体创伤[1]。这种行为反应可导致继发性皮肤创伤、溃疡和潜在的细菌感染，这可能使临床表现复杂化并需要额外的治疗干预。

### Sources

[1] Tumors of the Skin in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 诊断方法

漏斗部角质化棘皮瘤的诊断主要依靠组织病理学检查，因为仅凭临床表现不能明确地将这些良性肿瘤与其他角质化上皮性病变区分开来[1]。细针抽吸细胞学检查可提供初步指导，但由于这些病变的角质化性质而存在局限性。

**临床评估**：这些肿瘤通常表现为丘疹至结节性病变，具有特征性的中央角质化核心或角状突起[2]。存在可能含有突出角蛋白的中央孔高度提示但非特异性的。临床检查应评估病变分布，因为挪威猎麋犬和拉萨犬可能发展为需要全身评估的泛发形式。

**组织病理学检查**：明确诊断需要组织活检，显示具有角质化分化的良性上皮增殖的特征性表现[1]。组织学模式显示内陷的上皮形成起源于毛囊的充满角蛋白的囊肿或角状结构。这种检查将IKAs与鳞状细胞癌和其他角质化病变区分开来。

**细胞学评估**：细针抽吸通常由于广泛的角质化而产生有限的诊断信息[3]。当获得细胞材料时，它主要由成熟的角质化细胞和角蛋白碎片组成，需要组织学确认以进行准确诊断。

**影像学考虑**：常规影像学检查通常不适用于浅表病变。然而，在怀疑深部组织受累或计划大病变手术切除的情况下，超声检查可能有助于定义组织边界和手术切缘。

### Sources

[1] Intracutaneous Cornifying Epitheliomas: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals
[2] Tumors of the Skin in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[3] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗选择

**手术切除仍然是犬猫漏斗部角质化棘皮瘤的主要治疗方法**[1]。完全手术切除具有治愈性，兽医通常在肿瘤周围切除足够的边缘以确保完全切除[2]。然而，犬倾向于随时间发展额外的肿瘤，使长期监测变得必要[1]。

**对于具有多个病变的泛发性疾病**，口服维甲类药物如异维A酸或依曲替酯可能提供治疗益处[1]。这些药物有助于控制疾病的过度角化性质，并可能减少新肿瘤的形成[2]。

**替代治疗方式包括冷冻疗法、激光切除和使用卡介苗（BCG）疗法进行局部免疫调节**[1]。这些方法对于具有多个病变或不适合广泛手术的犬可能特别有用。

**术后护理考虑**侧重于防止自体创伤和继发性细菌感染。如果病变没有溃疡、感染或引起自体创伤，治疗可能是可选的[2]。然而，当犬试图抓挠、摩擦或咬病变时，干预变得必要，导致继发性并发症。

**强烈挤压或操作这些病变是禁忌的**，因为它可能导致肿瘤壁破裂，将角蛋白释放到周围组织中，并引发严重的化脓性肉芽肿性炎症[1]。

### Sources

[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

[2] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 预防措施

当前的兽医文献为漏斗部角质化棘皮瘤（IKA）提供的循证预防策略有限。然而，基于肿瘤特征和品种易感性，几种方法显示出前景。

**遗传咨询和繁殖管理**
挪威猎麋犬和拉萨犬显示出发生泛发性IKA的最高风险[1]。对于患有泛发性疾病的动物，口服维甲类药物（如异维A酸或依曲替酯）可能具有治疗益处[2]。遗传咨询应侧重于这些易感品种，特别是当多个家庭成员受影响时。繁殖计划应考虑将患有泛发性疾病的动物从繁殖种群中移除，以减少遗传传播风险。

**早期检测方案**
定期皮肤科检查对于易感品种至关重要，特别是挪威猎麋犬、比利时牧羊犬、拉萨犬和古代英国牧羊犬[1]。主人应监测带有中央角质化孔的特征性丘疹或结节，特别是在背部、尾部和四肢上[2]。早期识别可防止肿瘤壁破裂和继发性化脓性肉芽肿性炎症的并发症。

**泛发形式的管理**
治疗是可选的，前提是已建立明确诊断，并且没有自体创伤、溃疡或继发性感染[2]。减少自体创伤的环境改变，以及定期监测溃疡或破裂，有助于防止当角蛋白释放到周围组织中时发生的炎症性并发症。

### Sources
[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 鉴别诊断

几种良性和恶性皮肤肿瘤可能模拟漏斗部角质化棘皮瘤，需要仔细的组织病理学检查以明确诊断。

**分化良好的鳞状细胞癌**代表最具挑战性的鉴别诊断。与IKAs不同，鳞状细胞癌显示侵袭性生长模式、细胞非典型性，并且可能与表皮连续[1]。然而，两种肿瘤都可呈现角质化和角质化物质，使肉眼外观不足以进行区分。

**毛上皮瘤**是充满浓缩、黄色、颗粒状物质的毛囊肿瘤，外观可能与IKAs相似[1]。关键区别特征是毛上皮瘤涉及整个毛囊结构，而IKAs特异地起源于漏斗部。

**毛母质瘤**提供了另一个重要的鉴别诊断，特别是其良性形式，表现为具有砂砾样内容的囊性肿块[1]。这些肿瘤起源于毛球基质细胞，可能从基质囊肿发展而来，不同于IKAs的漏斗部起源。

**基底细胞肿瘤**（毛胚细胞瘤）有时可能与IKAs混淆，特别是当它们表现为囊性变异时[2]。然而，基底细胞肿瘤通常显示嗜碱性细胞增殖，而非IKAs特征性的角质化上皮模式。

其他毛囊囊肿包括漏斗部毛囊囊肿和混合囊肿也可能需要根据其特定的角质化模式和细胞形态进行区分[2]。

### Sources
[1] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

## 预后

患有漏斗部角质化棘皮瘤的犬的预后通常极好，因为这些是良性肿瘤，没有恶性潜力[1]。完全手术切除具有治愈性，没有转移或恶性转化的风险[1]。然而，该疾病具有明显的随时间复发和发展新病变的倾向。

发生一个漏斗部角质化棘皮瘤的犬在其一生中易患在其他部位发生额外的肿瘤[1][2]。这种复发模式在某些品种中特别常见，挪威猎麋犬和拉萨犬发生具有多个病变的泛发形式疾病的风险最高[1]。

对于这些良性病变，如果没有自体创伤、溃疡或继发性细菌感染，治疗是可选的[1][2]。当进行手术切除时，如果切除不完全，一年内复发很常见[2]。对于患有广泛性疾病的犬，口服维甲类药物如异维A酸或依曲替酯可能在管理多个病变方面提供治疗益处[1]。

长期预后主要取决于疾病程度和犬发展新病变的倾向，而非任何危及生命的并发症。主要的预后问题涉及外观美观、病变溃疡时继发感染的潜力，以及需要持续监测和可能对新肿瘤发展进行重复治疗。

### Sources
[1] Epidermal and Hair Follicle Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/epidermal-and-hair-follicle-tumors-in-animals

[2] Tumors of the Skin in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
