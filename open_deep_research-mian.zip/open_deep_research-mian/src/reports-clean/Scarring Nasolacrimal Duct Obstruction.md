# 伴侣动物瘢痕性鼻泪管阻塞

瘢痕性鼻泪管阻塞是兽医实践中一种重要的眼科疾病，导致犬猫出现慢性泪溢和继发性并发症。这种泪液引流通道的永久性阻塞由多种原因引起，包括慢性泪囊炎、异物、创伤以及猫疱疹病毒等传染性病原体。该疾病通过可预测的炎症级联反应进展，导致纤维性瘢痕形成，从而损害泪液从眼睛到鼻腔的正常流动。本综合报告探讨了瘢痕性鼻泪管阻塞的多方面问题，涵盖了从基础琼斯测试到先进CT成像的诊断方法，从药物冲洗到复杂手术重建的治疗选择，以及影响患病伴侣动物临床结果的预后因素。

## 疾病概述与流行病学

瘢痕性鼻泪管阻塞是一种慢性疾病，特征是泪液从眼睛到鼻腔的引流通道发生永久性阻塞。鼻泪系统包括泪腺、内眦附近的两个泪点、在骨性泪窝内泪囊处汇合的泪小管，以及终止于鼻孔的鼻泪管[1]。

**泪囊炎**（泪囊的炎症）通常通过炎性碎片、异物或压迫管道的肿块导致阻塞。这种情况导致泪溢、对治疗无效的继发性结膜炎，偶尔在犬中形成引流瘘管[1]。**几种情况可导致鼻泪管阻塞**，包括泪点闭锁、感染、异物材料阻塞、先前感染（特别是猫的疱疹病毒）引起的瘢痕、创伤，以及肿瘤或骨骼畸形引起的压迫[6]。

鼻泪管可能因鼻腔或鼻旁疾病而发生改变，这些改变已在计算机断层扫描研究中得到证实[1]。**解剖学考虑**显示，泪液由腺体产生，并通过鼻泪管排入鼻腔[1]。

在猫中，慢性猫疱疹病毒1型感染可使结膜和泪管开口形成瘢痕[1]。该疾病影响各年龄段的犬和猫，尽管在当前兽医文献中特定品种的易感性仍然有限。短头颅品种可能表现出不同的解剖学特征，这可能影响鼻泪系统功能[1]。

### Sources

[1] Computed tomographic findings of nasal and paranasal: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.05.0330.xml

[6] Lacrimal disease can make you cry: What to do?: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings-0

## 病因学与病理生理学

瘢痕性鼻泪管阻塞通过多种致病机制发展，损害正常泪液引流。泪囊炎是最常见的原因，由炎性碎片阻塞鼻泪囊和近端管道引起[1]。这种炎症过程引发一系列组织损伤和随后的瘢痕形成，永久性缩小或阻塞引流通道。

滞留在鼻泪系统内的异物引发慢性炎症反应，导致肉芽组织形成和最终瘢痕[2]。鼻泪装置的创伤性损伤造成直接组织损伤和随后的愈合反应，通常导致永久性狭窄或完全阻塞[4]。

传染性病原体，特别是细菌病原体，引发泪囊和导管组织内的慢性炎症[3]。炎症过程损伤脆弱的上皮内衬和周围组织，促进纤维化和瘢痕形成。外部压迫鼻泪管的肿块可导致压迫性组织坏死和瘢痕，即使在肿块移除后也是如此[1]。

病理生理进展遵循可预测的模式：初始组织损伤导致炎症、炎性碎片积聚、组织坏死，最终形成纤维瘢痕，永久性损害导管通畅性[2]。慢性病例可能形成引流瘘管作为替代引流通路，表明正常鼻泪系统严重瘢痕化[1]。

### Sources

[1] Nasolacrimal and Lacrimal Apparatus in Animals - Eye: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] Disorders of the Nasal Cavity and Tear Ducts in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-nasal-cavity-and-tear-ducts-in-cats
[3] Disorders of the Nasal Cavity and Tear Ducts in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs
[4] Lacrimal disease can make you cry: What to do?: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings-0

## 临床表现与诊断

瘢痕性鼻泪管阻塞通常以持续性泪溢（流泪过多）为主要临床症状。患病动物表现为泪液持续溢出，常伴有内眦处黏脓性分泌物[1]。在慢性病例中，常发展为对常规治疗无效的继发性结膜炎，鼻泪点下方可能可见轻度至中度肿胀[1]。

该疾病偶尔可能发展为泪囊炎（泪囊炎症），导致下眼睑内侧疼痛性肿胀，有时在犬的下眼睑内侧或下方形成引流瘘管[1]。患有此病的猫可能表现为慢性泪液溢出，特别是在波斯猫和喜马拉雅猫品种中[1]。

诊断评估从琼斯测试开始，将荧光素染色剂应用于角膜表面，检查鼻孔是否存在染色剂，以指示导管通畅性[1]。确定性诊断程序涉及鼻泪管冲洗和灌洗，可揭示阻塞和黏脓性分泌物从泪点反流[1]。

先进成像技术在复杂病例中起着关键作用。计算机断层扫描（CT）提供骨骼结构的良好可视化，可以识别慢性阻塞的部位和原因[2]。当冲洗不能治愈时，可能需要进行对比泪囊鼻腔造影术，以确定慢性阻塞的部位、原因和预后[1]。现代CT技术允许使用薄切片进行详细评估，提供比传统X射线更优越的诊断信息[2]。

### Sources
[1] Nasolacrimal and Lacrimal Apparatus in Animals - Eye Diseases: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] Advanced imaging in exotics (Proceedings): https://www.dvm360.com/view/advanced-imaging-exotics-proceedings

## 治疗选择

瘢痕性鼻泪管阻塞的治疗取决于阻塞的严重程度和位置。初始管理包括使用无菌盐水进行鼻泪管冲洗以重新建立导管通畅性[1]。当冲洗证明不足时，可同时给予全身性抗菌药物和抗炎药物以及局部抗菌溶液[1]。

对于持续性阻塞，使用聚乙烯或硅胶管，或2-0单丝尼龙缝线进行临时导管插入，有助于在愈合期间保持通畅性[1]。先进的支架置入程序由加州大学戴维斯分校开创，涉及多学科团队使用内窥镜、CT和透视检查来识别和绕过阻塞，临时支架放置两个月以允许适当愈合[2]。

当鼻泪装置遭受不可逆损伤时，需要手术重建。结膜鼻腔造口术或结膜口腔造口术程序创建新的引流通道，将泪液排入鼻腔、鼻窦或口腔[1][3]。这些重建手术描述了开放和闭合两种手术技术[3]。当常规药物治疗无法恢复正常泪液引流时，这些手术干预提供了替代方案。

### Sources

[1] Merck Veterinary Manual Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals

[2] DVM 360 Dry-eyed at last: Nasolacrimal stenting procedure corrects a cat's tear duct obstruction: https://www.dvm360.com/view/dry-eyed-last-nasolacrimal-stenting-procedure-corrects-cats-tear-duct-obstruction

[3] DVM 360 Lacrimal disease can make you cry: What to do?: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings-0

## 鉴别诊断与预后

### 鉴别诊断

在犬和猫中，几种情况必须与瘢痕性鼻泪管阻塞相鉴别。**先天性鼻泪管闭锁**表现出类似的泪溢症状，但从出生时就存在，通常涉及哈斯纳瓣闭锁或先天性泪囊膨出[1]。在幼驹和年轻骆驼科动物中，鼻泪管鼻腔（远端）端闭锁很常见，通常通过鼻孔底部的可压缩肿胀来指示[1]。

**原发性获得性鼻泪管阻塞（PANDO）**代表无潜在瘢痕的特发性阻塞，在老年动物中更常见[3]。**肿瘤原因**包括鼻腔肿瘤可模拟瘢痕性阻塞，通常表现为进行性单侧症状和对比成像中广泛的鼻甲破坏[7]。**炎症性疾病**如泪囊炎显示细菌或异物阻塞，伴有从泪点反流的黏脓性分泌物[1]。

**继发性原因**包括放射性碘诱导的阻塞（通常是双侧）、慢性感染性泪囊炎伴继发性瘢痕，以及创伤相关的狭窄[3]。**功能性阻塞**由上呼吸道感染或黏膜肿胀引起，应通过鼻泪管冲洗程序与永久性瘢痕相鉴别[1][2]。

### 预后

瘢痕性鼻泪管阻塞的预后在很大程度上取决于慢性程度、严重程度和潜在原因。**早期病例**可能对鼻泪管冲洗和使用聚乙烯或硅胶管进行导管插入以在愈合期间保持通畅性反应良好[1]。**中度病例**通常需要手术干预，如结膜鼻腔造口术或结膜口腔造口术，以创建新的引流通道进入鼻腔、鼻窦或口腔[1][2]。

**严重慢性病例**伴有不可逆的鼻泪装置损伤，预后谨慎，需要永久性手术引流解决方案[1]。成功率因瘢痕的位置和严重程度而异。早期干预通常改善结果，而长期阻塞伴有广泛纤维化的完全解决预后较差。

### Sources

[1] Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] Disorders of the Nasal Cavity and Tear Ducts in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-nasal-cavity-and-tear-ducts-in-cats
[3] Bilateral Nasolacrimal Duct Obstruction after Adjuvant Radioactive Iodine: https://webeye.ophth.uiowa.edu/eyeforum/cases/148-nasolacrimal-obstruct-post-i131.htm
[7] Canine and feline nasal tumors: https://www.dvm360.com/view/canine-and-feline-nasal-tumors
