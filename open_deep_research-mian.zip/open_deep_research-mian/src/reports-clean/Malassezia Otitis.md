# 犬猫马拉色菌性耳炎

马拉色菌性耳炎是小动物兽医临床中最常见的耳部疾病之一，由健康耳道中天然存在的亲脂性酵母菌过度生长引起。当基础疾病破坏耳部正常微环境时，这种机会性病原体从无害的共生菌转变为致病因子。该疾病特别影响某些品种，如寻回犬、梗犬和巴吉度犬，通常继发于过敏性疾病、解剖因素或内分泌疾病。本报告探讨了马拉色菌性耳炎的综合兽医处理方法，涵盖从耳镜检查到细胞学评估的诊断策略，结合局部抗真菌药与全身治疗的循证治疗方案，以及专注于基础病因管理以获得最佳长期效果的关键预防措施。

## 疾病概述

马拉色菌性耳炎是由马拉色菌属的亲脂性酵母菌（主要是犬猫中的厚皮马拉色菌）过度生长引起的耳道炎症性疾病[1]。该疾病是小动物就诊兽医的最常见原因之一[1]。

马拉色菌作为共生菌存在于犬猫健康的皮肤和黏膜表面，在正常耳道中数量较少[1][2]。该生物体既是正常栖息者又是机会性病原体，当耳道环境变化促进过度生长时就会引发问题[2]。

马拉色菌性耳炎没有公认的性别分布，但幼年动物可能更常受影响[1]。品种易感性与皮肤过敏相关，特别是影响寻回犬和梗犬[1]。某些品种如巴吉度犬在皮肤上保持遗传上更高数量的马拉色菌，使其易受感染[2]。

该疾病总是继发于另一种破坏耳道正常微环境的基础疾病[2]。原发性原因包括过敏、寄生虫、自身免疫性疾病、内分泌疾病以及垂耳或狭窄耳道等解剖因素[1]。从共生状态到致病状态的转变发生在屏障功能受损时，导致炎症反应和临床疾病表现。

### Sources

[1] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

[2] The latest in diagnosis and management of Malassezia: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis/1000

## 发病机制与临床表现

马拉色菌性耳炎代表一个复杂的病理过程，其中正常的酵母菌定植转变为致病的过度生长[1]。*厚皮马拉色菌*是犬耳中的主要菌种，通常以少量存在于健康耳道微生物组中。然而，耳道微环境的破坏会触发病理性增殖[6]。

**易感因素**
改变耳道环境的主要病因包括过敏性疾病（特应性皮炎、食物超敏反应）、解剖因素（垂耳、狭窄耳道）、内分泌疾病（甲状腺功能减退）和过度潮湿[1]。这些情况损害耳部的自然防御机制，为酵母菌过度生长创造有利条件[4]。

**致病机制**
从共生菌到病原体的转变涉及多种因素。马拉色菌产生有助于毒力的磷脂酶，在全身性感染中观察到更高活性[7]。该生物体通过脂肪酶代谢表面脂肪酸，产生炎症性类花生酸并改变皮肤pH值，进一步损害屏障功能[7]。

**临床表现**
受影响的动物通常表现为中度瘙痒、炎症和特征性的蜡质渗出物形成[6]。临床症状包括摇头、恶臭、红斑和棕色蜡状分泌物[1]。该疾病常见于垂耳品种，可能单侧或双侧表现[5]。由于表面生物体之间的共生关系，葡萄球菌属的并发细菌感染经常发生[7]。

### Sources
[1] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Diagnostic otology (Proceedings): https://www.dvm360.com/view/diagnostic-otology-proceedings
[3] Practical approach to diagnosing and managing ear disease in the dog (Proceedings): https://www.dvm360.com/view/practical-approach-diagnosing-and-managing-ear-disease-dog-proceedings
[4] Malassezia otitis (Proceedings): https://www.dvm360.com/view/malassezia-otitis-proceedings/1000
[5] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis
[6] Allergy in Dogs and Cats - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/allergy-in-dogs-and-cats

## 诊断方法

## 诊断方法

马拉色菌性耳炎的全面诊断需要系统检查，结合耳镜评估、细胞学分析以及在复杂病例需要时的先进技术[1]。

**耳镜检查**
应尽可能对所有皮肤病患进行耳镜评估[1]。视频耳镜比手持设备提供更佳的放大和可视化效果，特别是对于疑难病例[2]。检查应评估耳道狭窄、红斑、糜烂、腺体增生、渗出物特征和肿块。鼓膜评估至关重要，但常因碎屑遮挡而需要清洁才能充分观察[1]。

**细胞学评估**
水平耳道渗出物的细胞学评估提供即时诊断信息，应在每个耳部病例中进行[1][2]。样本用棉签采集，滚涂在玻片上，用Diff-Quick或改良瑞氏染色染色。无需热固定[1]。正常耳道可能含有少量共生生物体，但需要识别和量化马拉色菌的过度生长[1][2]。

**先进诊断**
培养很少用于外耳炎，但强烈建议用于疑似中耳炎病例[1]。当增生组织妨碍鼓膜观察或神经学症状伴随耳炎时，可能需要放射学或先进影像学（CT/MRI）[1]。对于阻塞性肿块或慢性无反应病例应进行活检[2]。

### Sources

[1] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Diagnosing and managing ear disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-ear-disease-proceedings

## 治疗策略

马拉色菌性耳炎的循证治疗需要综合方法，同时针对感染和基础病因[1]。成功的管理通常结合局部抗真菌治疗与适当的耳部清洁方案，并在需要时使用全身药物。

**局部抗真菌治疗**
马拉色菌性耳炎最有效的局部抗真菌药物包括咪康唑、克霉唑和磺胺嘧啶银[2]。针对马拉色菌，推荐使用地塞米松磷酸钠与1%咪康唑按1:1比例的组合[3]。治疗持续时间通常为两周，通过细胞学复查评估反应[2]。

**耳部清洁方案**
在应用抗真菌药物前进行彻底的耳部清洁至关重要，因为它可去除渗出物并改变环境pH值以抑制酵母菌过度生长[2]。某些耳部清洁剂具有内在抗真菌特性，如乙酸和硼酸溶液，据报道对穿孔鼓膜使用安全[3]。

**全身治疗**
当单独局部治疗不足或怀疑中耳炎时，应使用全身性抗真菌药物[1][2]。酮康唑5-10 mg/kg每日一次和伊曲康唑5 mg/kg每日一次是高效选择[1][2]。氟康唑（2.5-10 mg/kg每日一次）和特比萘芬（30 mg/kg每日一次）作为替代药物[2]。治疗应在临床缓解后继续14天，最短持续21天[1]。

**管理基础病因**
成功的长期管理需要识别和控制易感条件，特别是过敏性疾病如特应性皮炎和食物超敏反应[2][6]。不解决这些基础因素，复发性感染很常见。

### Sources
[1] A review of selected systemic antifungal drugs for use in dogs and cats: https://www.dvm360.com/view/review-selected-systemic-antifungal-drugs-use-dogs-and-cats
[2] Update on treatment of Malassezia dermatitis (Proceedings): https://www.dvm360.com/view/update-treatment-malassezia-dermatitis-proceedings
[3] Otitis externa - a quick guide to management (Proceedings): https://www.dvm360.com/view/otitis-externa-quick-guide-management-proceedings
[4] Malassezia otitis (Proceedings): https://www.dvm360.com/view/malassezia-otitis-proceedings

## 预防与预后

### 预防措施

现有内容全面涵盖了预防策略，重点是管理基础易感因素和适当的耳部维护。使用适当清洁剂定期清洁耳道至关重要，特别是对于易感品种[3]。对主人进行正确清洁技术教育可提高依从性和治疗成功率。

环境管理仍然是关键，包括保持耳道干燥和通风良好[3]。修剪耳道开口周围的毛发可改善通风，但应避免常规拔毛，除非必要以防止炎症反应[3]。

**疫苗接种考虑：** 与许多其他传染病不同，目前没有专门用于预防马拉色菌性耳炎的疫苗。该酵母菌是共生生物体，疾病发展主要取决于宿主因素而非病原体暴露[2][7]。预防重点在于管理易感条件如过敏性皮炎，这可能受益于环境过敏原控制措施，如通过适当湿度控制（40-50%）和用热水定期清洗床上用品来减少屋尘螨[5]。

### 预后因素

当识别并适当管理原发性病因时，马拉色菌性耳炎的预后通常良好[1][3]。治疗持续时间差异显著 - 急性病例通常在2-4周内缓解，而慢性病例可能需要数月治疗[3]。

关键预后因素包括及时进行适当的抗真菌治疗、耳道变化严重程度、并发中耳炎的存在，以及最重要的是识别和控制基础疾病[1][2]。通过适当的基础疾病管理和适当的维护护理，病例复发率显著降低[9]。

长期成功很大程度上取决于主人的依从性和通过细胞学复查进行定期兽医监测以评估治疗反应[1]。在管理得当和主人依从性良好的情况下，复发可以有效最小化。

### Sources
[1] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] The latest in diagnosis and management of Malassezia dermatitis: https://www.dvm360.com/view/the-latest-in-diagnosis-and-management-of-malassezia-dermatitis
[3] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[4] Managing the itchy pet (Proceedings): https://www.dvm360.com/view/managing-itchy-pet-proceedings
[5] Atopy therapy: minimizing drugs (or at least the immunosuppressive ones) (Proceedings): https://www.dvm360.com/view/atopy-therapy-minimizing-drugs-or-least-immunosuppressive-ones-proceedings-0
[6] Identifying, managing feline acne, non-parasitic otitis and allergic dermatitis: https://www.dvm360.com/view/identifying-managing-feline-acne-non-parasitic-otitis-and-allergic-dermatitis
[7] Feline dermatology (Proceedings): https://www.dvm360.com/view/feline-dermatology-proceedings
[8] Diagnostic otology (Proceedings): https://www.dvm360.com/view/diagnostic-otology-proceedings
[9] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
