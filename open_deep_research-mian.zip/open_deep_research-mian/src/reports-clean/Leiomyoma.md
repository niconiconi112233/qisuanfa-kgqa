# 伴侣动物平滑肌瘤：临床指南

平滑肌瘤是兽医从业者主要在中老年犬猫中遇到的良性平滑肌肿瘤。这些非恶性肿瘤最常影响胃肠道和子宫，呈现出独特的诊断和治疗挑战。虽然许多病例无症状且是偶然发现的，但一些患者会出现显著的临床症状，包括慢性呕吐、胃肠道梗阻或副肿瘤综合征如低血糖。本报告探讨了小动物临床实践中平滑肌瘤的临床表现模式、诊断方法、手术治疗选择和预后因素，为从业者提供管理这些良性但可能产生重要影响的肿瘤的循证指导。

## 疾病概述

平滑肌瘤是可发生于犬猫多种器官的良性平滑肌肿瘤，最常影响子宫、胃肠道和其他含有平滑肌的结构[1][3]。这些非恶性肿瘤源于平滑肌细胞的增殖，其特征是细胞分化良好且无侵袭性[4]。

伴侣动物平滑肌瘤的流行病学数据显示特定模式。这些肿瘤通常影响中老年动物，犬常在6-12岁之间发病[3]。然而，胃平滑肌瘤特别倾向于发生在老年犬中，通常在10-15岁之间[3]。雌性动物，特别是未绝育雌性，由于激素影响表现出更高的易感性，尤其是子宫平滑肌瘤[4]。子宫平滑肌瘤通常被认为是非侵袭性、非转移性和缓慢生长的，子宫切除术几乎总是可以治愈[4]。

在猫中，平滑肌瘤的发生频率低于犬，但遵循相似的年龄和性别模式。这些肿瘤通常生长缓慢且保持局部化，使其区别于其恶性对应物平滑肌肉瘤[3]。平滑肌瘤的良性性质使其在得到正确诊断和管理时通常预后良好。

### Sources
[1] A retrospective analysis of oral tumors in dogs in Switzerland: https://avmajournals.avma.org/view/journals/javma/263/1/javma.24.06.0414.xml
[2] A literature review on the welfare implications of gonadectomy: https://avmajournals.avma.org/view/journals/javma/250/10/javma.250.10.1155.xml
[3] Gastrointestinal Neoplasia in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/neoplasia-of-the-gastrointestinal-tract-in-small-animals/gastrointestinal-neoplasia-in-dogs-and-cats
[4] Is removal of the uterus necessary?: https://avmajournals.avma.org/view/journals/javma/239/11/javma.239.11.1409.xml

## 常见病原体

平滑肌瘤是非感染性肿瘤，无病毒或细菌病因。这些良性平滑肌肿瘤源于平滑肌细胞的自发增殖，而非病原体[1][2]。

与传染性疾病不同，平滑肌瘤通过非感染机制发展。它们被描述为起源于胃肠道的自发性良性平滑肌肿瘤[3][4]。肿瘤表现为界限清晰的圆形至卵圆形肿块，通常有包膜且呈膨胀性生长，通常不伴有覆盖黏膜的溃疡[5]。

重要的是将平滑肌瘤与可能引起相似临床表现的感染性疾病区分开来。虽然感染性胃肠疾病由特定病原体如细菌、病毒或寄生虫引起，但平滑肌瘤是平滑肌组织异常细胞生长和增殖的结果[6]。

### Sources

[1] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/247/11/javma.247.11.1237.xml
[2] Paraneoplastic syndromes in dogs and cats: https://www.dvm360.com/view/paraneoplastic-syndromes-in-dogs-and-cats
[3] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[4] Gastric neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastric-neoplasms-dogs-and-cats-proceedings
[5] A challenging case: Esophageal leiomyoma in a dog: https://www.dvm360.com/view/challenging-case-esophageal-leiomyoma-dog
[6] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

## 临床症状和体征

犬猫平滑肌瘤的临床表现因解剖位置和肿瘤大小而有显著差异。**胃平滑肌瘤通常无症状**，许多病例是在常规检查或死后评估中偶然发现的[4]。当出现临床症状时，它们通常是由机械效应或并发症引起的。

**胃肠道平滑肌瘤**最常表现为慢性呕吐，特别是当位于胃或近端小肠时[1]。体重下降和厌食是常见的伴随症状。大肠位置可能导致腹泻、血便、里急后重或带状粪便[1][3]。盲肠或回结肠区域有肿瘤的犬可能表现出小肠和大肠腹泻的混合特征[1][3]。

**副肿瘤性低血糖**是与胃平滑肌瘤和平滑肌肉瘤相关的重要非典型表现[1][5][6]。受影响的动物可能因肿瘤分泌胰岛素样生长因子而表现出震颤、癫痫、虚弱或虚脱。多尿和多饮也被记录为平滑肌肿瘤的副肿瘤综合征[5]。

**位置特异性模式**包括食管平滑肌瘤引起吞咽困难、反流和因吸入导致的呼吸道症状[6]。较小的肿瘤（<2 cm）通常临床上无症状，而较大的肿块则产生机械性梗阻症状[6]。

### Sources
[1] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[2] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings
[3] Ultrasonography of the gastrointestinal tract: a myriad of disease (Proceedings): https://www.dvm360.com/view/ultrasonography-gastrointestinal-tract-myriad-disease-proceedings
[4] Gastric neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastric-neoplasms-dogs-and-cats-proceedings
[5] A challenging case: Esophageal leiomyoma in a dog: https://www.dvm360.com/view/challenging-case-esophageal-leiomyoma-dog

## 诊断方法

小动物平滑肌瘤的诊断依赖于结合临床检查、先进成像和确定性组织病理学分析的综合多模式方法[1]。临床检查通常可触及腹部肿块或肠梗阻体征，尽管许多病例表现为非特异性症状[2]。

诊断成像在特征描述中起着关键作用。普通X线片可能显示肿块效应或胃壁增厚，而造影检查显示充盈缺损和黏膜不规则[3]。腹部超声显示局灶性壁增厚、正常分层消失和蠕动不良，但正常外观不能排除肿瘤[1]。CT成像提供肿瘤大小、位置和侵袭性的优越可视化，特定的对比增强模式有助于区分平滑肌瘤与其他肿块[1]。

内窥镜检查显示黏膜下肿瘤，覆盖黏膜光滑且管腔狭窄[4]。然而，对于疑似平滑肌瘤，内窥镜活检是禁忌的，因为会增加手术并发症[4]。相反，超声引导下细针抽吸或全层手术活检提供足够的组织样本[1]。

确定性诊断需要组织病理学检查，显示成熟平滑肌细胞的有序增殖，具有交织的良性梭形细胞束[4]。免疫组织化学染色有助于区分平滑肌瘤和平滑肌肉瘤，平滑肌瘤显示较低的有丝分裂指数且无包膜侵袭或坏死[2]。α平滑肌肌动蛋白阳性确认平滑肌起源，而Kit (CD117)阴性则区别于胃肠道间质瘤[2]。

### Sources
[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[2] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings
[3] Gastrointestinal Neoplasia in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/neoplasia-of-the-gastrointestinal-tract-in-small-animals/gastrointestinal-neoplasia-in-dogs-and-cats
[4] A challenging case: Esophageal leiomyoma in a dog: https://www.dvm360.com/view/challenging-case-esophageal-leiomyoma-dog

## 治疗选择

手术切除是伴侣动物平滑肌瘤的主要治疗方法，具体方法因解剖位置而异。对于食管平滑肌瘤，摘除术是首选技术，涉及黏膜外剥离以保留黏膜层，同时从肌壁中切除肿瘤[1]。这种方法避免了食管切除和吻合术相关的并发症。

围手术期管理包括使用阿片类药物、非甾体抗炎药和局部神经阻滞的多模式镇痛，以及手术期间的预防性抗生素[1]。对于食管手术，术后护理包括禁食12小时，然后喂食软食七天，以减少食管刺激[1]。

术后考虑因素取决于位置和切除范围。当发生黏膜穿透或进行广泛切除时，可能需要放置胃造口管[1]。通常建议术后限制活动4周。应仔细关闭肌层间隙和外膜，以防止术后并发症如憩室形成[1]。

对于所有位置通常建议广泛的手术切缘，特别是对于可通过浆膜或黏膜方法进行完全摘除的胃肠道平滑肌瘤[2]。腹腔镜方法越来越常用，与传统开放手术相比，发病率更低且恢复时间更快[3]。对于子宫平滑肌瘤，卵巢子宫切除术是首选治疗方法[4]。

### Sources

[1] A challenging case: Esophageal leiomyoma in a dog: https://www.dvm360.com/view/challenging-case-esophageal-leiomyoma-dog
[2] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings
[3] Understanding laparoscopy in veterinary surgery: https://www.dvm360.com/view/understanding-laparoscopy-in-veterinary-surgery
[4] Vaginal cytology as a diagnostic tool (Proceedings): https://www.dvm360.com/view/vaginal-cytology-diagnostic-tool-proceedings

## 预防措施

传统的预防策略不适用于伴侣动物的平滑肌瘤，因为这些是源于平滑肌细胞的自发性肿瘤，没有可控制的已识别感染性、遗传性或环境原因[1]。与传染性疾病或某些遗传性疾病不同，平滑肌瘤通过不可预测的细胞转化过程发展，无法通过疫苗接种、饮食调整或环境管理来预防[2][3]。

胃肠道平滑肌瘤缺乏已知的风险因素意味着不存在特定的预防方案[1]。这些良性平滑肌肿瘤在中老年犬猫中零星发生，没有已证实的品种易感性或可预防的触发因素[2][3]。

然而，通过常规兽医检查进行早期检测是管理平滑肌瘤病例最有价值的方法。定期体格检查，特别是中老年宠物的腹部触诊，可以在肿块出现症状之前识别它们[1][2]。对老年动物的慢性胃肠道体征（如呕吐、腹泻或体重减轻）进行及时诊断检查，可以更早地识别和治疗胃肠道肿瘤，包括平滑肌瘤[1][3]。

使用诊断成像进行常规健康筛查可能检测到无症状肿块，使得在发生梗阻等并发症之前进行手术干预[2]。当获得完全切缘时，平滑肌瘤的早期手术切除通常预后极佳[1][3]。

### Sources

[1] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[2] Gastric neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastric-neoplasms-dogs-and-cats-proceedings
[3] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings

## 鉴别诊断

在诊断伴侣动物平滑肌瘤时，由于临床表现和成像特征重叠，必须考虑几个关键的鉴别诊断[1]。

**主要肿瘤性鉴别诊断：** 平滑肌肉瘤是最关键的鉴别诊断，因为两者都源于平滑肌，但预后差异显著[1][2]。胃肠道间质瘤（GIST）与平滑肌肿瘤具有组织学相似性，但通过c-kit (CD117)染色阳性来区分[1][3]。GIST通常发生在盲肠和大肠，而平滑肌瘤更常影响胃和小肠[1][3]。

**其他恶性肿瘤：** 必须排除腺癌，特别是在胃肠道位置，它通常表现出相似的临床症状[1][3]。淋巴瘤可以模拟平滑肌瘤，特别是当表现为局灶性肿块而非弥漫性浸润时[1][3]。其他考虑因素包括纤维肉瘤、鳞状细胞癌和浆细胞瘤[2][3]。

**鉴别特征：** 关键诊断因素包括肿瘤位置、大小和成像特征[5]。平滑肌瘤通常是界限清晰的壁内肿块，覆盖黏膜完整[2][5]。先进成像（CT/MRI）有助于区分局部侵袭模式[2]。组织学上，与平滑肌肉瘤相比，平滑肌瘤有丝分裂象较少且无包膜侵袭[2][4]。

**非肿瘤性疾病：** 应考虑肉芽肿性炎症、胃溃疡和良性息肉[5]。这些疾病在超声检查中可能表现出相似的壁增厚和正常分层消失[5]。

### Sources

[1] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
[2] A challenging case: Esophageal leiomyoma in a dog: https://www.dvm360.com/view/challenging-case-esophageal-leiomyoma-dog
[3] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings
[4] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[5] Gastric tumors--does ultrasonography help (Proceedings): https://www.dvm360.com/view/gastric-tumors-does-ultrasonography-help-proceedings

## 预后

患有平滑肌瘤的犬猫在完全手术切除后通常预后极佳[1]。平滑肌瘤是非转移性的，手术切除可以完全解决疾病[2]。

胃或肠道平滑肌瘤患者在无转移性疾病证据的情况下进行完全肿瘤切除时可以获得良好预后[3]。关键预后因素是在初次切除尝试时获得干净的手术切缘。

生活质量考虑通常是有利的，因为平滑肌瘤是不转移的良性肿瘤。一旦完全切除，当获得足够切缘时复发并不常见。特别是对于胃肠道平滑肌瘤，在成功手术干预后临床症状通常完全缓解[4]。

与恶性平滑肌肿瘤的对比是显著的--虽然平滑肌肉瘤在手术切除后的中位生存时间为7.8个月，但平滑肌瘤在正确管理时具有更有利的长期预后[5]。在肿瘤增大影响周围结构之前进行早期手术干预可优化受影响动物的结果和生活质量。

肠外髓外浆细胞瘤在手术切除提供干净切缘且无转移性疾病证据的情况下通常预后良好[6]。

### Sources

[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

[2] What Is Your Diagnosis? in: Journal of the American ...: https://avmajournals.avma.org/view/journals/javma/259/S1/javma.20.04.0178.xml

[3] Gastric neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastric-neoplasms-dogs-and-cats-proceedings

[4] Intestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/intestinal-neoplasms-dogs-and-cats-proceedings

[5] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings

[6] Gastrointestinal neoplasms in dogs and cats (Proceedings): https://www.dvm360.com/view/gastrointestinal-neoplasms-dogs-and-cats-proceedings
