# 犬猫桡骨骨干骨折

桡骨骨干骨折在小动物临床实践中构成一项重大的骨科挑战，尤其影响玩具犬和迷你犬品种，因其骨骼结构脆弱。这些桡骨骨干中段骨折约占所有犬类骨折的18%，通常由创伤引起，包括跌倒、机动车事故以及猫的高楼综合征。本报告探讨了桡骨骨干骨折的综合管理，涵盖流行病学模式、诊断方法以及从外部固定到锁定加压钢板和微创手术等先进手术技术的治疗选择，同时解决小型品种患者带来的独特挑战以及影响长期预后的潜在并发症。

## 摘要

桡骨骨干骨折呈现复杂的管理挑战，需要根据患者因素和骨折特征采取个体化治疗方法。现有证据表明，玩具犬和迷你犬品种由于生物力学因素面临特别高的风险，即使是轻微创伤也可能导致骨折。手术固定已成为首选治疗方法，骨板作为金标准，外骨骼固定提供出色的替代方案，尤其适用于猫的骨不连病例。

关键治疗考虑因素包括：

| 因素 | 考虑事项 | 结果 |
|--------|---------------|---------|
| 患者体型 | 玩具品种需要专用植入物 | 并发症风险更高 |
| 固定方法 | 骨板 vs. ESF vs. 组合方式 | 骨板仍是金标准 |
| 手术入路 | MIPO 保留软组织生物学特性 | 改善愈合潜力 |

成功取决于适当的植入物选择、精确的手术技术和谨慎的患者选择。尽管通过适当管理预后通常良好，但包括骨不连和植入物失败在内的并发症仍然是值得关注的问题，尤其在体型较小的患者中。未来研究应专注于优化玩具品种的固定技术，并开发品种特异性治疗方案，以减少并发症并改善结果。

## 疾病概述与流行病学

桡骨骨干骨折是犬猫桡骨骨干（中部）的断裂[1]。桡骨是前臂（前臂）的两块骨头之一，与尺骨一起从肘部延伸到腕部。骨干骨折发生在骨的中央部分，不同于干骺端或骨骺骨折[1]。

桡骨和尺骨同时骨折是犬的常见损伤，约占该物种所有骨折的18%[2]。在小型或玩具品种犬中，发病率显著更高，归因于生物力学因素，如桡骨远端失效载荷低[2]。这些骨折通常由重大创伤引起，包括机动车事故、跌倒以及猫的高楼综合征[1]。

玩具犬和小型犬因其脆弱的骨骼结构和相对于骨强度的较高活动量而表现出易感性增加[1]。即使是轻微创伤，如小跳跃或跌倒，也可能在这些品种中引起骨折[2]。年轻、生长中的动物尤其易感，因为它们的骨骼矿化程度较低，在压力下更容易骨折。

年龄分布各不相同，幼年动物经历的骨折通常与活跃玩耍或探索期间的创伤有关。成年动物通常因更高能量的创伤事件而遭受这些骨折。

### Sources
[1] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings
[2] Open reduction and cranial bone plate fixation of fractures: https://avmajournals.avma.org/downloadpdf/view/journals/javma/250/12/javma.250.12.1419.pdf

## 鉴别诊断

桡骨骨干骨折必须与其他几种表现为急性前肢跛行和疼痛的疾病相鉴别[1]。尺骨骨折常与桡骨骨折同时发生，但也可能表现为具有相似临床表现的孤立性损伤。体格检查应仔细评估两块骨头以识别并发损伤。

软组织损伤，包括严重的肌肉拉伤或韧带损伤，可能模拟骨折表现，但缺乏桡骨骨干骨折特有的骨擦音和骨骼不稳定[1]。关节脱位，特别是在肘部或腕部，可能表现出相似的跛行模式，但显示不同的放射学发现和可触及的关节不稳定，而非骨干中段的骨破坏。

继发于骨肿瘤或代谢性骨病的病理性骨折应予以考虑，尤其对于老年患者或有轻微创伤史的患者[2]。骨肉瘤常见于犬的桡骨远端，可能表现为通过弱化骨的病理性骨折。

发育性疾病如幼年快速生长的大型犬的全骨炎可引起急性跛行和骨痛，但通常周期性影响多块骨头，并显示特征性的髓内放射学密度，而非离散的骨折线[2]。由生长障碍引起的肢体成角畸形可能导致慢性跛行，但缺乏创伤性桡骨骨干骨折典型的急性发作和放射学骨折模式。

### Sources

[1] Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats

[2] Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/developmental-osteopathies-in-dogs-and-cats

## 治疗方案与手术技术

桡骨骨干骨折的治疗需要仔细考虑骨折构型、患者因素和手术专业知识。使用夹板或石膏的外部固定适用于有不完全骨折的幼犬，但由于固定不充分，对于完全性骨干骨折是禁忌的[1]。

手术固定方法包括骨板、外骨骼固定（ESF）和髓内（IM）针[2]。骨板仍然是骨干骨折的金标准，锁定加压钢板（LCP）在骨质疏松骨和干骺端区域提供优越的抗拔出阻力[3]。板-针组合通过在植入物之间分散机械负荷，为粉碎性骨折提供增强的稳定性[3]。

外骨骼固定显示出高成功率，特别是线性ESF系统用于治疗猫的骨不连病例[4]。改良的加强型自由形态ESF技术已证明对猫科患者的四肢骨折有效[5]。

对玩具品种和猫的特殊考虑包括在迷你犬和玩具犬品种中使用颅侧骨板固定桡骨-尺骨骨折，这提供了优异的结果[6]。这些较小的患者由于骨量有限，通常需要专门的植入物尺寸和谨慎的手术计划。

微创钢板骨接合术（MIPO）已获得普及，利用小切口进行植入物放置，同时保留软组织生物学特性[3]。当与锁定钢板结合使用时，该技术特别有益，因为它维持骨折血肿并减少手术创伤，同时实现稳定固定。

### Sources

[1] Merck Veterinary Manual Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[2] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[3] Changes in fracture treatment which help practitioners: https://www.dvm360.com/view/changes-fracture-treatment-which-help-practitioners-proceedings
[4] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[5] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[6] Open reduction and cranial bone plate fixation of fractures: https://avmajournals.avma.org/view/journals/javma/250/12/javma.250.12.1419.xml

## 并发症与预后

根据现有资料，伴侣动物的桡骨骨干骨折可能出现几种显著影响恢复结果的并发症。最常见的并发症包括植入物失败、畸形愈合、延迟愈合和骨不连[1]。在迷你犬和玩具犬品种中，桡骨骨干骨折由于骨尺寸小和相对较差的骨质量而特别具有挑战性[1]。

当固定装置选择或应用不当时，会发生植入物失败，导致螺钉松动、钢板断裂或结构失效[7]。畸形愈合的特征是在不正确的解剖对位下愈合，可导致外翻、内翻或旋转畸形，影响肢体功能，并可能促进骨关节炎的发展[7]。

影响恢复的预后因素包括患者年龄、骨折复杂性、适当的植入物选择和手术技术。年轻、健康的动物进行适当固定通常具有良好的恢复预后[5]。然而，粉碎性骨折需要更强的固定，因为它们不能像简单骨折那样有效地与骨分担负荷[7]。

预期愈合时间取决于多种因素，但适当的手术技术、合适的植入物选择以及遵守术后限制对于成功结果至关重要[7]。当骨折得到适当管理时，长期预后通常良好，尽管一些病例可能出现需要额外手术干预的并发症[5]。

### Sources
[1] Open reduction and cranial bone plate fixation of fractures involving the distal aspect of the radius and ulna in miniature- and toy-breed dogs: 102 cases (2008-2015): https://avmajournals.avma.org/view/journals/javma/250/12/javma.250.12.1419.xml
[2] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[3] Surgery STAT: Tailor your bone fracture repair technique: https://www.dvm360.com/view/surgery-stat-tailor-your-bone-fracture-repair-technique
