# 伴侣动物慢性结膜炎概述

慢性结膜炎是兽医临床中最常见的眼部疾病之一，影响犬和猫，但其根本病因和管理方法截然不同。这种持续超过2-3周的结膜炎症性疾病，对兽医提出了独特的诊断和治疗挑战。

本报告全面探讨了伴侣动物慢性结膜炎的概况，研究了主要的病毒病原体（如猫疱疹病毒1型，80%的感染猫会建立潜伏感染）、细菌病原体（包括猫衣原体和支原体属）以及短头颅犬品种易感性的关键作用。分析涵盖了利用PCR检测和细胞学检查的循证诊断方案、以西多福韦等抗病毒药物为特色的多模式治疗策略，以及管理这种通过原发性病原体感染影响几乎所有猫的复发性疾病的现实预后。

## 疾病概述与临床表现

慢性结膜炎定义为持续超过2-3周的结膜炎症，其特征是影响眼睑、球结膜和/或第三眼睑结膜的持续性炎症变化[2]。在伴侣动物中，慢性结膜炎占眼部疾病表现的很大比例，研究表明59.3%的猫显示眼部异常，其中眼表变化最为常见，占51.9%[1]。

犬和猫的流行病学模式差异显著。在犬中，慢性结膜炎通常继发于潜在疾病，如过敏、干眼或解剖异常[6][7]。短头颅品种和眼眶暴露较大的犬由于其解剖结构易感性，更容易发生角膜和结膜疾病[4]。此外，结膜表面口腔细菌的流行率达到33%，在短头颅犬中发病率显著更高[5]。相比之下，几乎所有猫结膜炎病例都是由原发性病原体感染引起的，最显著的是猫疱疹病毒1型（FHV-1）[2][3]。

临床症状包括结膜充血、化学性结膜炎、眼部分泌物（从浆液性到黏液脓性不等）、眼睑痉挛和流泪[2][3][6]。在猫中，与其他病原体（如猫衣原体）相比，FHV-1感染表现为更严重的结膜充血和分泌物，而猫衣原体通常引起更严重的化学性结膜炎[2]。慢性病例可能发展为结膜滤泡、角膜受累（包括溃疡），在严重情况下形成睑球粘连（结膜粘连）[2][3]。原发性细菌性结膜感染在家养动物中很少见，除非在特定情况下，如牛的莫拉氏菌角膜结膜炎[6]。

### Sources
[1] Ophthalmic abnormalities in cats study: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0187/javma.25.03.0187.pdf
[2] Feline conjunctivitis overview: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[3] Feline keratitis and conjunctivitis: https://www.dvm360.com/view/feline-keratitis-and-conjunctivitis-proceedings
[4] Mastering corneal ulcers (part 1): https://www.dvm360.com/view/mastering-corneal-ulcers-part-1-
[5] Oral bacteria may affect conjunctival microorganisms: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.23.11.0260.xml
[6] Just Ask the Expert conjunctival infections: https://www.dvm360.com/view/just-ask-expert-how-do-you-treat-conjunctival-infections
[7] The red eye diagnostics and treatment: https://www.dvm360.com/view/red-eye-diagnostics-and-treatment-proceedings

## 常见病原体与传染性病因

猫和犬的慢性结膜炎涉及多种传染性病原体，这些病原体可延续炎症并建立持续性感染。

**病毒病原体：** 猫疱疹病毒1型（FHV-1）是猫的主要病毒性病因，流行病学研究显示全球暴露率高达95%[3]。原发性感染后，80%的猫在三叉神经节建立潜伏感染，约40%经历复发性感染[3][4]。犬疱疹病毒1型（CHV-1）主要影响新生犬作为新生儿疾病，但可引起成年犬的结膜炎和角膜水肿[7]。这些病毒造成初始上皮损伤，使动物易患继发性细菌感染。

**细菌病原体：** 猫衣原体在猫中引起显著的慢性结膜炎，特别是在多猫环境中，其临床特征为严重的化学性结膜炎[1][4]。猫支原体引起猫的角膜炎和结膜炎，而猫口支原体代表另一种常见物种[1]。犬支原体作为新型呼吸道病原体影响犬[2]。葡萄球菌属和链球菌属通常在两种动物中引起继发性细菌感染[2]。

**病理生理学：** 病毒病原体通常通过损伤结膜上皮引发疾病[2]。FHV-1建立永久性潜伏感染，应激诱导的再激活导致复发性疾病[3]。支原体和衣原体等细菌具有延长的排毒期，有助于疾病慢性化[2]。原发性病毒损伤和继发性细菌定植的结合，创造了慢性结膜炎特有的持续性炎症循环。

### Sources
[1] Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases
[2] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-in-animal-shelters
[3] Feline corneal diseases: herpesvirus and more: https://www.dvm360.com/view/feline-corneal-diseases-herpesvirus-and-more-proceedings
[4] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[7] Canine Herpesvirus Infection - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/canine-herpesvirus-infection/canine-herpesvirus-infection

## 诊断方法与鉴别诊断

慢性结膜炎的诊断依赖于系统的临床评估结合实验室检测[1][2]。全面的方法从标准眼科检测开始，包括希尔默泪液试验（在任何局部干预前首先进行）、荧光素染色和眼内压测量[1][3]。应系统地进行威胁反应视力测试以及对称性、瞳孔光反射和眼睑反射评估[3]。

结膜细胞学检查提供快速诊断信息，应在局部麻醉后使用细胞刷技术获取[1][6]。可在麻醉滴注后进行培养和药敏试验，最常需要需氧培养[1]。为获得最佳结果，实验室提交表格应注明样本位置和所需药敏测试[1]。

先进的影像技术包括使用10-20 MHz探头的眼部超声，当混浊妨碍直接观察时允许检查，并可指导细针穿刺程序[3][4]。当怀疑眼眶疾病时，可利用计算机断层扫描（CT）或磁共振成像（MRI）进行球后评估[4]。

PCR检测是猫常见结膜病原体（包括FHV-1、猫衣原体和支原体属）的首选诊断方法，尽管可能出现假阳性和假阴性[9]。许多实验室提供全面的猫呼吸道面板，可同时筛查多种生物体[9]。

### Sources
[1] Ocular diagnostics (Proceedings): https://www.dvm360.com/view/ocular-diagnostics-proceedings
[2] The red eye: diagnostics and treatment (Proceedings): https://www.dvm360.com/view/red-eye-diagnostics-and-treatment-proceedings
[3] Ocular diagnostic testing: what, when, how? (Proceedings): https://www.dvm360.com/view/ocular-diagnostic-testing-what-when-how-proceedings
[4] An eye on canine orbital disease: Causes, diagnostics, and treatment: https://www.dvm360.com/view/eye-canine-orbital-disease-causes-diagnostics-and-treatment
[6] Merck Veterinary Manual Cytology - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[9] DVM 360 Mastering feline conjunctivitis cases: https://www.dvm360.com/view/mastering-feline-conjunctivitis-cases

## 治疗选择

猫慢性结膜炎需要针对传染性病因和支持性护理的多模式治疗方法。主要病原体猫疱疹病毒（FHV-1）无法消除，但可通过抗病毒治疗有效控制[1]。

**抗病毒干预**是治疗的基石。局部使用0.5%西多福韦溶液对FHV-1显示出强效，每日两次给药，减少临床症状和病毒排毒，同时比替代药物毒性更低[1]。全身性使用泛昔洛韦90 mg/kg每日两次提供良好的口服抗病毒覆盖[1]。传统局部药物包括1%三氟胸苷、0.1%碘苷和3%阿糖腺苷，在症状消退后需要每日5-6次应用，持续10-14天[1]。

**细菌管理**通过局部使用1%四环素软膏每日3-4次或口服多西环素10 mg/kg每日一次持续三周来处理继发性感染[1]。

**支持性护理**包括频繁使用含有透明质酸的高质量人工泪液制剂，因为FHV-1减少结膜杯状细胞导致泪膜质量障碍[1]。减压至关重要，因为糖皮质激素和应激情况可触发病毒再激活[1]。

治疗选择应考虑疾病严重程度、主人依从性和经济限制。在轻度病例中，单独支持性护理可能更可取，以避免治疗相关的应激[1]。

### Sources
[1] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-

## 预防措施与预后

慢性结膜炎的预防主要依靠疫苗接种和环境管理策略。对于猫衣原体感染，有疫苗可用但提供不完全保护，减轻疾病严重程度而非预防感染[2]。在疾病流行的猫舍中可考虑使用猫衣原体疫苗[2]。

环境卫生实践对预防传播至关重要。由于衣原体生物体在环境中存活能力差，动物之间的直接接触是主要传播途径[2]。常规卫生措施包括接触感染动物后洗手，有助于减少人畜共患传播风险[2]。

减压代表关键的预防措施，特别是对于疱疹病毒相关结膜炎。主人应了解潜伏感染的猫很可能复发，应尽量减少环境应激因素[4]。

慢性结膜炎的预后因病因和宿主因素而有显著差异。对于衣原体感染，当给予足够时间的适当抗生素治疗时，治疗通常有效[2]。建议使用多西环素（10 mg/kg/天）治疗至少4周，有些病例需要长达6周[2]。

然而，尽管经过治疗，临床症状可能持续数周，复发并不少见[2]。未经治疗的猫可能在感染后携带衣原体生物体数月，作为传播的储存宿主[2]。通过适当治疗，预后通常良好，尽管慢性病例可能需要延长治疗方案。

### Sources

[2] Chlamydial Conjunctivitis in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals

[4] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
