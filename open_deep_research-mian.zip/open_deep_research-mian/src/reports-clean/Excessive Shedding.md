# 伴侣动物过度脱毛

过度脱毛是兽医实践中常见的皮肤科问题，需要将病理性脱毛与正常的生理更新过程区分开来。虽然狗的每平方英寸皮肤上自然约有15,000根毛发，而猫有60,000-120,000根，但当过度脱毛导致可见的秃斑或秃块而非常规毛发更替时，就具有临床意义。

本综合报告探讨了过度脱毛的多因素性质，涵盖包括细菌性脓皮病和皮肤癣菌在内的传染性病原体、从品种特异性模式到炎症性与非炎症性原因的临床表现，以及利用皮肤刮片、毛发镜检和内分泌学检测的诊断方法。治疗策略包括药物干预和管理方案，而预防措施则侧重于寄生虫控制和营养优化，以维持伴侣动物的最佳被毛健康。

## 疾病概述

现有章节内容为理解伴侣动物过度脱毛提供了全面基础。我将结合额外的参考资料来增强流行病学背景。

**定义**

过度脱毛是指健康伴侣动物正常生理更新过程之外的毛发脱落[1]。狗的每平方英寸皮肤上约有15,000根毛发，而猫拥有60,000-120,000根毛发，所有毛发都以镶嵌模式循环经历发育阶段[1]。正常脱毛代表自然的毛发更替，不伴随秃斑或对称性脱发[4,5]。当过度脱毛导致明显的被毛脱落和秃斑时，就变为病理性[4,5]。

正常与过度脱毛的临床区别需要评估毛发脱落是否造成可见的秃斑，还是仅仅代表自然毛发更替的一个阶段[2]。异常脱毛通常表明存在潜在的细菌性脓皮病或其他传染性原因[4]。如果导致明显的被毛脱落和秃斑，脱毛可能是异常的，可能由细菌感染引起[6]。

**流行病学背景**

脱毛模式主要受光照周期和外部温度变化的影响，户外宠物通常在春季和秋季过渡期间脱毛最多[1]。然而，室内伴侣动物由于恒定的温度和光照条件，经历近乎持续的脱毛[1]。在恒定人工照明（特别是石英卤素灯或荧光灯）下饲养的动物可能因光照周期紊乱而表现出过度脱毛[2]。

年龄显著影响脱毛模式，动物通常在怀孕、哺乳期或严重疾病或发热后几周内正常脱毛[2]。猫在呼吸道感染后常出现明显脱毛[2]。毛发生长周期包括生长期（生长）、退行期（过渡）和休止期（静止），外部因素影响这些阶段[3]。

### Sources

[1] DVM 360 Not another shedding question: https://www.dvm360.com/view/not-another-shedding-question
[2] DVM 360 Acquired alopecias mimicking endocrine skin disease: https://www.dvm360.com/view/acquired-alopecias-mimicking-endocrine-skin-disease-parts-1-and-2-proceedings
[3] Merck Veterinary Manual The Integumentary System in Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/the-integumentary-system-in-animals
[4] Merck Veterinary Manual Hair Loss (Alopecia) in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/hair-loss-alopecia-in-dogs
[5] Merck Veterinary Manual Hair Loss (Alopecia) in Cats: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/hair-loss-alopecia-in-cats
[6] Merck Veterinary Manual Shedding: https://www.merckvetmanual.com/multimedia/table/shedding

## 常见病原体

伴侣动物的过度脱毛可由各种传染性和寄生虫性病原体引起，这些病原体直接损伤毛囊或诱导导致脱发的炎症反应[1]。

**细菌性原因**
细菌性脓皮病主要由葡萄球菌属引起，是狗和猫异常脱毛的常见原因[1]。细菌感染破坏毛囊并干扰正常毛发生长周期，导致明显的毛发脱落和秃斑区域[1]。细菌性毛囊炎与猫的瘙痒性粟粒状皮炎相关，尽管其发生不如犬类常见[2]。

**真菌病原体**
皮肤癣菌是过度脱毛的重要真菌性原因，特别是在猫中，皮肤癣菌病在某些地理区域更为普遍[2]。这些生物直接侵入并破坏毛干和毛囊，导致脱发，可能伴有鳞屑、结痂和炎症变化[3]。马拉色酵母菌也可能作为继发并发症导致脱毛，加剧瘙痒和脱发[2]。

**寄生虫性病原体**
蠕形螨引起蠕形螨病，直接影响毛囊并导致显著脱发[1]。各种体外寄生虫包括猫疥螨（Notoedres cati）、耳痒螨（Otodectes cynotis）和姬螯螨属（Cheyletiella）可诱导超敏反应和自伤性创伤，导致过度脱毛[2]。这些寄生虫引发炎症反应，损害毛囊完整性和正常毛发生长模式。

### Sources
[1] Dermatological Problems in Animals: https://www.merckvetmanual.com/en-au/integumentary-system/integumentary-system-introduction/alopecia-in-animals
[2] Itchy cat: Don't want that! (Proceedings): https://www.dvm360.com/view/itchy-cat-dont-want-proceedings

## 临床症状和体征

狗和猫的过度脱毛根据潜在病因表现出不同的临床表现。**典型表现**包括弥漫性脱发、斑片状秃斑和环境中的毛发积聚增加[1]。炎症性原因通常伴有瘙痒、红斑、鳞屑和涉及葡萄球菌和马拉色菌属的继发性皮肤感染[2]。

**品种特异性模式**在犬特应性皮炎中值得注意，易感品种包括金毛寻回犬、拉布拉多寻回犬、西部高地白梗和波士顿梗[2]。这些品种通常表现为影响足部、面部、耳朵、屈曲面、腋窝和腹部的脱发[2]。**猫科表现**差异显著，表现为粟粒状皮炎、自伤性脱发或头颈部瘙痒[1]。

**区分炎症性与非炎症性原因**需要仔细检查。炎症性脱发通常表现为瘙痒导致自伤性创伤，导致脱发、红斑、鳞屑、抓痕和色素沉着[3]。非炎症性原因如内分泌疾病，表现为对称性脱发模式，除非发生继发感染，否则无瘙痒[3]。

**相关的皮肤变化**包括苔藓化、毛囊角栓和并发的细菌或酵母菌过度生长，这些通常会加剧临床症状[2][3]。

### Sources

[1] Atopic Dermatitis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals

[2] Canine Atopic Dermatitis - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis

[3] Dermatological Problems in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

## 诊断方法

诊断伴侣动物过度脱毛需要系统的方法，从全面的临床表现评估开始。兽医应评估脱发的模式和分布，检查脱毛是全身性还是局部性、季节性还是持续性[1]。体格检查应评估皮肤状况、被毛质量以及任何伴随的皮肤变化，如红斑、鳞屑或色素沉着。

**实验室诊断构成评估的基石**。皮肤刮片仍然是检测体外寄生虫的关键，特别是蠕形螨属，需要深部刮片和皮肤压迫来识别毛囊内的螨虫[2]。毛发镜检（显微镜下毛发检查）可揭示结构异常、真菌元素和附着在毛干上的寄生虫卵[2]。**显微镜下可能看到真菌孢子，在检查皮肤癣菌感染时，受感染的毛发通常比正常毛发更粗**[1]。

使用胶带印片或棉拭子采样等技术对皮肤样本进行细胞学检查，可以识别细菌过度生长、马拉色菌生物和炎症细胞[3]。使用皮肤癣菌试验培养基（DTM）或专用培养基进行真菌培养仍然是皮肤癣菌鉴定的金标准，PCR检测可快速确认真菌DNA的存在[1]。

**对于内分泌相关的脱发，血液检查变得至关重要**。全血细胞计数、血清生化谱和特定激素检测，包括甲状腺功能测试（总T4、游离T4、TSH）和肾上腺功能评估，有助于识别潜在的代谢原因[8]。当评估导致被毛变化的肾上腺或甲状腺异常时，影像学研究如超声检查可能是必要的。

### Sources
[1] Merck Veterinary Manual Dermatophytosis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[2] DVM 360 Simple diagnostic tools in veterinary dermatology: https://www.dvm360.com/view/simple-diagnostic-tools-veterinary-dermatology-proceedings
[3] Merck Veterinary Manual Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗选择

现有内容为治疗方法提供了全面基础。在此框架基础上，成功管理过度脱毛需要识别和处理并发的细菌和酵母菌感染，这些感染日益被认为是伴侣动物瘙痒和脱发的常见原因[1]。

在开始治疗前应进行皮肤细胞学诊断，以识别继发性微生物感染[1]。全面的寄生虫控制仍然至关重要，因为体外寄生虫感染可能加剧脱毛模式并使治疗反应复杂化[1]。

对于内分泌相关的过度脱发，当确诊甲状腺功能减退或其他内分泌疾病时，可能需要激素替代疗法[2]。必需脂肪酸补充剂对鳞屑性疾病可提供显著益处，并可能有助于恢复正常被毛质量[3]。Omega-3脂肪酸已显示出抗炎特性，可能支持整体皮肤健康，尽管剂量应仔细监测[3]。

褪黑素疗法对某些形式的脱发显示出前景，特别是在毛囊敏感性可能改变的情况下[4]。治疗通常涉及每8-12小时口服3-6毫克，在8-12周后评估反应[4]。

定期梳理管理和使用保湿香波进行适当沐浴可以帮助去除松散毛发并支持皮肤屏障功能[1]。治疗成功需要在调查过敏性病因之前解决任何潜在的传染性原因，因为并发感染通常导致过度脱毛模式[1]。

### Sources
[1] Dermatological Problems in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals
[2] Overview of endocrine skin diseases: https://www.dvm360.com/view/overview-endocrine-skin-diseases-proceedings
[3] Exploring the role of omega-3 supplementation in cats and dogs: https://www.dvm360.com/view/exploring-the-role-of-omega-3-supplementation-in-cats-and-dogs
[4] Focal, non-inflammatory alopecia: A diagnostic, treatment challenge: https://www.dvm360.com/view/focal-non-inflammatory-alopecia-diagnostic-treatment-challenge

## 预防措施

有效预防过度脱毛侧重于全面的寄生虫控制、最佳营养和定期梳理实践。全年广谱寄生虫预防至关重要，因为寄生虫感染可显著导致被毛质量差和脱毛增加[1]。伴侣动物寄生虫委员会推荐每月使用心丝虫预防药物，同时控制蛔虫和钩虫，幼犬和幼猫在2-3周龄时进行初次驱虫，之后每两周治疗一次直到8-9周龄[2]。

环境控制措施包括定期清理粪便和使用季铵盐或含氯消毒剂进行环境消毒，以防止再感染循环[3]。由于粪便中的寄生虫会造成高度污染的环境，增加再感染概率，适当的卫生对于维持健康的被毛状况至关重要[4]。

营养优化在减少过度脱毛方面发挥着重要作用。必需脂肪酸补充剂，特别是平衡的omega-3和omega-6脂肪酸，有助于维持健康的皮肤和被毛[5]。高质量、高消化率的饮食和适当的蛋白质来源支持最佳被毛健康，同时避免可能导致皮肤炎症和随后脱发的食物过敏原。

使用适当的香波进行定期梳理可以防止加剧脱发的继发并发症。对于脂溢性疾病，含有硫和水杨酸的抗菌脂溢香波有助于正常化角质形成细胞更新[6]。跳蚤控制至关重要，因为绦虫感染通过吞食跳蚤发生，使全面的体外寄生虫预防成为脱发管理的重要组成部分[7]。改良环孢素可能对管理过敏性脱发原因有益，犬剂量为5 mg/kg，猫为7 mg/kg，尽管最大效果可能需要长达30天[8]。

### Sources
[1] Deworming: Next steps in disease prevention: https://www.dvm360.com/view/deworming-next-steps-disease-prevention
[2] Deworming: Next steps in disease prevention: https://www.dvm360.com/view/deworming-next-steps-disease-prevention
[3] Problems associated with intestinal parasites in cats: https://www.dvm360.com/view/problems-associated-with-intestinal-parasites-cats
[4] Just how common are canine and feline intestinal parasites?: https://www.dvm360.com/view/just-how-common-are-canine-and-feline-intestinal-parasites
[5] Topical and systemic therapy for seborrheic disorders: https://www.dvm360.com/view/topical-and-systemic-therapy-seborrheic-disorders-parts-1-and-2-proceedings
[6] Topical and systemic therapy for seborrheic disorders: https://www.dvm360.com/view/topical-and-systemic-therapy-seborrheic-disorders-parts-1-and-2-proceedings
[7] Combatting unseen parasites: A closer look at tapeworms and whipworms: https://www.dvm360.com/view/combatting-unseen-parasites-a-closer-look-at-tapeworms-and-whipworms
[8] Dermatological Problems in Animals - Integumentary System: https://www.merckvetmanual.com/en-au/integumentary-system/integumentary-system-introduction/alopecia-in-animals

## 鉴别诊断

过度脱毛需要与具有重叠临床表现的多种疾病进行仔细鉴别。**内分泌疾病**代表最重要的鉴别诊断，特别是甲状腺功能减退和肾上腺皮质功能亢进(1)。患有内分泌疾病的犬通常表现为背部躯干或尾部的对称性脱发、非瘙痒性皮肤（除非继发感染），并可能表现出嗜睡或体重增加等代谢变化(1)。

**过敏性皮炎**包括特应性皮炎和食物过敏必须与病理性脱发区分开来(2)。这些情况通常以瘙痒为主要主诉，与内分泌相关的脱发不同，后者通常无瘙痒(1,3)。跳蚤过敏性皮炎是猫对称性脱发最常见的原因(3)。

**脂溢症**和细菌/酵母菌感染可导致过度脱发，必须通过细胞学检查排除(3)。**正常季节性脱毛**与病理性脱发的区别在于其可预测的时间、缺乏继发性皮肤变化以及无潜在全身性体征(3)。

**关键鉴别因素**包括：瘙痒存在与否（过敏性与内分泌性）、脱发模式（对称性与局灶性）、发病年龄（老年动物更可能为内分泌性）以及多尿、多饮或行为变化等并发全身性体征(1,3)。

### Sources
[1] Common endocrine dermatopathies in dogs - dvm360: https://www.dvm360.com/view/common-endocrine-dermatopathies-dogs
[2] Alopecia in a Boxer in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/262/12/javma.24.04.0286.xml
[3] Dermatological Problems in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals

## 预后

过度脱发的预后完全取决于潜在原因[1]。当由正常生理过程或季节性变化引起时，不需要医疗干预，病情会自然解决。然而，病理性原因需要特定的治疗方法。

对于传染性原因如皮肤癣菌病，预后通常良好。健康动物的大多数感染是自限性的，无需治疗即可解决[4]。通过适当的全身和局部治疗，通常在6-12周内解决，大多数情况下可实现真菌学治愈[4][5]。患有并发疾病或免疫抑制的动物可能经历更长的恢复时间。

导致过度脱发的细菌性脓皮病和酵母菌过度生长通常对抗微生物治疗反应良好。每24-48小时使用氯己定/咪康唑香波进行局部治疗，结合必要时全身性抗真菌药物，通常在2-3周内产生积极结果[2]。

内分泌原因如甲状腺功能减退和肾上腺皮质功能亢进通过适当的激素替代或治疗通常具有良好的长期预后[2]。然而，在成功治疗潜在内分泌疾病后，毛发再生可能需要数月时间。

包括特应性皮炎和食物过敏在内的过敏性原因需要持续管理而非治愈。通过适当识别过敏原和实施适当的治疗，临床症状可以得到良好控制，尽管通常需要终身管理[2]。

### Sources
[1] Dermatitis and Dermatologic Problems in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/dermatitis-and-dermatologic-problems-in-dogs
[2] Dermatological Problems in Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals
[3] Not another shedding question: https://www.dvm360.com/view/not-another-shedding-question
[4] Dermatophytosis in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[5] Treatment of Canine and Feline Dermatophytosis: https://www.dvm360.com/view/treatment-of-canine-and-feline-dermatophytosis
