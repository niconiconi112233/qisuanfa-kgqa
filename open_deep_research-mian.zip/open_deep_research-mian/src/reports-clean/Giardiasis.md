# 犬猫贾第鞭毛虫病：综合兽医指南

贾第鞭毛虫病是全球范围内影响伴侣动物的最普遍寄生虫感染之一，在某些群体中感染率高达39%。这种由*十二指肠贾第鞭毛虫*（*Giardia duodenalis*）引起的原虫疾病，因其多变的临床表现和间歇性包囊排出模式，对兽医从业者构成了重大的诊断和治疗挑战。幼年动物和处于拥挤环境中的动物面临特别高的感染风险，一些收容所群体的感染率接近100%。本综合指南探讨了该病原体的遗传多样性、物种特异性聚集群、从传统漂浮技术到现代抗原检测的诊断方法、以芬苯达唑作为一线疗法的当前治疗方案，以及在兽医实践中预防再感染的关键环境控制措施。

## 疾病概述

贾第鞭毛虫病是由肠道贾第鞭毛虫（也称为*蓝氏贾第鞭毛虫*或*十二指肠贾第鞭毛虫*）引起的一种原虫感染，主要影响犬和猫的小肠[1]。这种双形态寄生虫以附着于肠上皮细胞的鞭毛滋养体形式存在，以及以促进传播的环境抗性包囊形式存在[1]。

贾第鞭毛虫种是全球范围内最常见的伴侣动物肠道寄生虫之一。患病率因所研究群体和使用的诊断方法而有显著差异[1][2]。全球范围内的研究发现，宠物和收容所的犬猫感染率在1%-39%之间，腹泻动物的感染率更高（10-20%）[1][2][3]。在一项对有症状动物的大型调查中，使用ELISA抗原检测，15.6%的犬和10.3%的猫检测结果为阳性[3]。

年龄易感性很明显，幼年动物的感染率高于成年动物[1][2]。在幼年动物和那些拥挤条件下（如犬舍、猫舍、收容所和宠物店）共同饲养的动物中患病率最高，感染率可接近100%[2][5]。导致感染的环境因素包括受污染的水源、拥挤的居住条件和不良的卫生状况[1][2]。贾第鞭毛虫包囊在凉爽潮湿的环境中能存活数月，使消毒工作变得具有挑战性[1][2]。

### Sources
[1] Giardia infection in dogs and cats (Proceedings): https://www.dvm360.com/view/giardia-infection-dogs-and-cats-proceedings
[2] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[3] Giardiasis and coccidiosis (Proceedings): https://www.dvm360.com/view/giardiasis-and-coccidiosis-proceedings
[4] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[5] Canine and feline cryptosporidiosis and giardiasis (Proceedings): https://www.dvm360.com/view/canine-and-feline-cryptosporidiosis-and-giardiasis-proceedings/1000

## 常见病原体

贾第鞭毛虫病由*十二指肠贾第鞭毛虫*（也称为*蓝氏贾第鞭毛虫*或*肠道贾第鞭毛虫*）引起，这是一种鞭毛状原虫寄生虫[1]。根据分子特征，该生物被细分为八个遗传聚集群（A-H），具有特定的宿主关联性[2]。

犬主要感染聚集群C和D，这些代表了在犬群中最常见的宿主适应性基因型[1][2]。在全球调查的犬中，这些聚集群占10-30%，一些研究者认为它们是独立的物种（*犬贾第鞭毛虫*，*G. canis*）[3][4]。猫主要携带聚集群F，该群对猫科动物表现出相似的宿主特异性[1][2]。在一般猫群中，该聚集群的患病率为1-10%，但在猫舍饲养的动物中可达50%[4][5]。

在美国，宿主适应性聚集群（犬的C/D，猫的F）尚未在人类中被发现，表明其人畜共患潜力有限[2]。这些基因型在家养宠物群体中最为普遍，并可能在高密度居住环境中胜过其他聚集群[1][6]。

聚集群A和B被认为具有人畜共患潜力，因为它们主要感染人类，但偶尔也会出现在犬和猫中[1][2]。聚集群A可进一步细分，其中亚聚集群AI有时见于宠物，而AII则更常与人类感染相关[1][7]。一些研究在犬和猫中发现了低患病率的聚集群A和B，表明存在潜在的但不常见的跨物种传播[2][7]。

### Sources

[1] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[2] Canine and feline cryptosporidiosis and giardiasis (Proceedings): https://www.dvm360.com/view/canine-and-feline-cryptosporidiosis-and-giardiasis-proceedings
[3] Feline infectious diarrhea update (Proceedings): https://www.dvm360.com/view/feline-infectious-diarrhea-update-proceedings
[4] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[5] An update on feline infectious diarrhea (Proceedings): https://www.dvm360.com/view/update-feline-infectious-diarrhea-proceedings
[6] Gastrointestinal protozoa (Proceedings): https://www.dvm360.com/view/gastrointestinal-protozoa-proceedings
[7] Management and prevention of feline infectious gastrointestinal diseases (Proceedings): https://www.dvm360.com/view/management-and-prevention-feline-infectious-gastrointestinal-diseases-proceedings

## 临床症状和体征

犬猫贾第鞭毛虫病的临床表现多样，从无症状感染到严重的吸收不良性腹泻。最具特征性的表现包括慢性小肠腹泻，其特点是量大、恶臭、颜色浅，常被描述为"牛粪"状并伴有脂肪泻[1]。腹泻可能是急性或慢性、间歇性或持续性，并可能伴有体重减轻，尽管食欲正常或增加[1]。

典型的小肠腹泻特征包括液体至半成形粪便，排便频率中度增加，每次排便的粪便量正常或增加[2]。大多数受影响的动物保持精神活泼、警觉、无发热，并维持正常食欲，但严重病例可能出现脱水、嗜睡和厌食[2]。呕吐偶尔伴随腹泻，一些患者以慢性呕吐为主要表现[2]。

猫可能出现黏液性腹泻，并且特别容易出现大肠症状，包括血便、过量粪便黏液和里急后重[1]。此外，猫表现出更好的结肠水分保存能力，可能掩盖明显的腹泻，尽管存在显著的吸收不良和体重减轻[3]。幼年动物（幼犬和幼猫）更容易出现临床症状和严重疾病，特别是当与其他胃肠道寄生虫或免疫抑制性疾病并发时[1][2]。临床表现可能在一些患者中自限，而另一些则发展为持续性、耐药性感染，需要多次治疗干预。

### Sources
[1] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[2] Giardia infection in dogs and cats (Proceedings): https://www.dvm360.com/view/giardia-infection-dogs-and-cats-proceedings
[3] Merck Veterinary Manual Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals

## 诊断方法

由于间歇性包囊排出模式和不同的诊断敏感性，伴侣动物贾第鞭毛虫病的准确诊断依赖于多种检测方法[1]。临床表现的评估应考虑到大多数*贾第鞭毛虫*感染是无症状的，腹泻是存在时的主要临床症状[1]。

**粪便漂浮法**
硫酸锌离心漂浮法（比重1.18）仍然是包囊检测的首选显微镜技术[1]。该方法需要在1500 rpm下离心3-5分钟，并在10分钟内进行检查以防止包囊塌陷[2]。标准氯化钠漂浮溶液可能会使包囊变形，应避免使用[1]。由于包囊排出是间歇性的，在3-5个连续天内进行三次粪便检查可达到95%的诊断效率，而单次检查仅为70-75%[2]。

**ELISA抗原检测**
商业抗原检测，包括IDEXX SNAP贾第鞭毛虫检测，可检测分裂滋养体产生的贾第鞭毛虫特异性抗原[2]。这些检测避免了与间歇性包囊排出相关的问题，据报道比单独使用硫酸锌漂浮法多检测出30%的病例[6]。硫酸锌漂浮法与抗原检测的结合构成了诊断的金标准[2]。

**免疫荧光测定**
使用荧光素标记抗体的直接免疫荧光抗体染色（IFAT）可快速识别包囊，但需要荧光显微镜[1]。该方法被认为具有高灵敏度和特异性，在可用时是贾第鞭毛虫诊断的金标准[4]。

**PCR检测**
分子方法具有高灵敏度，但由于成本考虑很少常规使用[1]。PCR可以在其他方法失败的情况下检测DNA，尽管阳性结果仅确认感染存在，而非临床疾病病因[8]。

### Sources
[1] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[2] Diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diarrhea-dogs-and-cats-proceedings
[3] Giardia and Tritrichomonas foetus: an update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings-0
[4] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[5] Diagnosing common infectious diseases - What do all those new tests, titers, PCRs, and blue dots really mean? Part 2: cats (Proceedings): https://www.dvm360.com/view/diagnosing-common-infectious-diseases-what-do-all-those-new-tests-titers-pcrs-and-blue-dots-really-m
[6] Acute and chronic diarrhea in dogs and cats: Giardiasis, Clostridium perfringens Enterotoxicosis, Tritrichomonas foetus, and Cryptosporidiosis (Proceedings): https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich
[7] Giardia, cryptosporidia, tritrichomonas (Proceedings): https://www.dvm360.com/view/giardia-cryptosporidia-tritrichomonas-proceedings
[8] An update on three important protozoan parasitic infections in cats: cryptosporidiosis, giardiasis, and tritrichomoniasis: https://www.dvm360.com/view/update-three-important-protozoan-parasitic-infections-cats-cryptosporidiosis-giardiasis-and-tritrich

## 治疗方案

目前犬猫贾第鞭毛虫病的治疗方法包括药理学和非药理学干预。芬苯达唑被认为是首选治疗方法，剂量为50 mg/kg，每日一次，连用3-5天，在犬中显示出95-100%的疗效，在猫中效果中等[1]。这种苯并咪唑衍生物对怀孕动物安全，无 reported 不良反应。

甲硝唑仍然是常用的替代药物，剂量为25 mg/kg，每日两次，连用5-7天，尽管它在犬中仅显示67%的疗效，并有神经系统副作用的风险[1][3]。每日总剂量不应超过65 mg/kg，以最小化毒性风险[4]。对于耐药病例或怀疑同时存在细菌过度生长的情况，可考虑联合使用芬苯达唑和甲硝唑[2]。

非药理学方法起着重要的支持作用。环境消毒至关重要，包括及时清除粪便、蒸汽清洁和使用季铵盐消毒[1]。用香波给感染动物洗澡可以去除毛发上的包囊，防止再感染。高纤维饮食可能通过使滋养体附着更困难来支持肠道健康，而益生菌可以帮助恢复被抗菌疗法破坏的正常肠道菌群[2]。

### Sources
[1] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[2] Integrative approach to treating Giardia lamblia infections: https://www.dvm360.com/view/integrative-approach-to-treating-giardia-lamblia-infections
[3] Giardia, cryptosporidia, tritrichomonas (Proceedings): https://www.dvm360.com/view/giardia-cryptosporidia-tritrichomonas-proceedings
[4] Diarrhea in dogs and cats (Proceedings): https://www.dvm360.com/view/diarrhea-dogs-and-cats-proceedings

## 预防措施

环境控制是兽医环境中贾第鞭毛虫预防的基石。*贾第鞭毛虫*包囊在粪便排出时即具有感染性，并在凉爽潮湿的环境中存活数月[1]。每日清除粪便对于限制环境污染和减少感染压力至关重要。包囊对干燥敏感，因此清洁后区域应彻底干燥[1]。

对于受感染的动物，立即隔离腹泻宠物或确诊的携带者可防止传播给其他易感宿主[1]。受感染的犬和猫应使用葡萄糖酸氯己定香波洗澡，以去除毛发上的包囊[1]。定期使用季铵盐化合物、蒸汽或沸水清洗和干燥毯子、寝具和食具可有效灭活包囊[1]。

消毒方案需要在冲洗污染表面之前保持5-20分钟的接触时间。在受感染动物最后出现后，草地至少会保持一个月的污染状态，因为这些区域的消毒是不可能的[1]。

水源管理至关重要，因为水媒传播很常见。清洁水源必须防止粪便污染[1]。

贾第鞭毛虫疫苗（GiardiaVax™）以前可用于犬和猫，但现已停产[6][7]。一些兽医报告说，在将疫苗接种作为耐药感染的免疫治疗时，治疗效果不一[7]。

### Sources
[1] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
[6] Giardia infection in dogs and cats (Proceedings): https://www.dvm360.com/view/giardia-infection-dogs-and-cats-proceedings
[7] Management and prevention of feline infectious gastrointestinal diseases (Proceedings): https://www.dvm360.com/view/management-and-prevention-feline-infectious-gastrointestinal-diseases-proceedings

## 鉴别诊断

贾第鞭毛虫病必须与犬猫慢性腹泻的众多原因进行区分。外分泌胰腺功能不全（EPI）是一个关键的鉴别诊断，通过血清胰蛋白酶样免疫反应性（TLI）检测诊断，与其他吸收不良疾病相比，EPI中的浓度极低[1,2]。EPI通常表现为尽管多食但体重减轻和与消化不良相关的腹泻。

炎症性肠病（IBD）代表了另一个主要的鉴别诊断，特别是淋巴细胞性浆细胞性肠炎。IBD通常显示更严重的组织学变化，包括绒毛萎缩和慢性炎症浸润，而贾第鞭毛虫病可能引起最小的组织学改变[1,4]。两种疾病都可能表现为慢性小肠腹泻和体重减轻。

需要考虑的其他寄生虫感染包括幼猫的*胎儿三毛滴虫*（*Tritrichomonas foetus*），它引起水样至黏液性腹泻，通过PCR或特殊培养方法诊断[4]。*隐孢子虫*和球虫也表现相似，但通过不同的诊断技术识别。

小肠细菌过度生长（SIBO）或抗生素反应性腹泻可能模仿贾第鞭毛虫病，特别是在年轻的德国牧羊犬中。这些情况通常显示血清叶酸和钴胺素浓度改变，并对抗生素治疗有反应[1,4]。

饮食敏感性和食物反应性腹泻影响30-50%患有慢性胃肠道症状的犬猫。与贾第鞭毛虫病不同，这些情况在2-3周内对排除性饮食或水解蛋白饮食有反应[4,6]。

### Sources

[1] Diagnostic approach to chronic diarrhea in dogs and cats: https://www.dvm360.com/view/diagnostic-approach-chronic-diarrhea-dogs-and-cats-proceedings
[2] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[3] Disorders of the Stomach and Intestines in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-stomach-and-intestines-in-cats
[4] Tips to treat persistent cases of chronic diarrhea in pets: https://www.dvm360.com/view/tips-treat-persistent-cases-chronic-diarrhea-pets-sponsored-nestle-purina
[5] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[6] Feline diarrhea: Let the diagnostic clues flow: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow

## 预后

犬猫贾第鞭毛虫病经过适当治疗后预后极佳，大多数动物完全康复。临床症状通常在治疗开始期间或之后不久消退，受影响的动物通常在21-70天内变得无症状(1)。研究表明治疗成功率很高，一项研究显示88%的未治疗猫在2年内腹泻消失(2)。

年龄和免疫状态显著影响预后。幼年动物通常对治疗反应良好，但可能经历更严重的初始症状。免疫抑制动物或患有并发胃肠道疾病的动物面临持续感染风险增加和恢复时间延长(6)。

**持续性包囊排出者的管理带来了持续的挑战**。尽管临床症状改善，动物可能继续排出包囊，需要仔细监测。5天内三次硫酸锌检查阴性被认为足以排除活动性感染(4)。然而，一些动物成为慢性携带者，间歇性排出包囊持续数月至数年而无临床症状(2)。

**治疗失败或再感染可能发生**，需要延长疗程或替代药物。环境污染，特别是在犬舍或多宠物家庭中，增加了再感染风险。治疗后给动物洗澡和彻底的环境消毒有助于防止复发(1)。

在其他健康的动物中并发症很少见。大多数感染是自限性的，严重的全身影响不常见。成功治疗后通常不会出现长期后遗症，尽管一些动物在急性阶段可能经历暂时性体重减轻或身体状况不佳。

在适当管理的病例中存活率接近100%，因为贾第鞭毛虫病很少导致健康的伴侣动物死亡。

### Sources
[1] Giardia and Tritrichomonas foetus: an update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings-0
[2] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich
[3] Giardia infection in dogs and cats (Proceedings): https://www.dvm360.com/view/giardia-infection-dogs-and-cats-proceedings
[4] Management and prevention of feline infectious gastrointestinal diseases (Proceedings): https://www.dvm360.com/view/management-and-prevention-feline-infectious-gastrointestinal-diseases-proceedings
[5] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t
[6] Giardiasis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/giardiasis-giardia/giardiasis-in-animals
