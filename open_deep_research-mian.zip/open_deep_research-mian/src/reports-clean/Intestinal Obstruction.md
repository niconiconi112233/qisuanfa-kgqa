# 犬猫肠梗阻

肠梗阻是伴侣动物医学中最关键的手术急症之一，需要立即识别和干预以防止危及生命的并发症。本综合报告探讨了犬猫胃肠道梗阻的病理生理学、临床表现和管理，从常见的异物摄入到复杂的肠套叠。分析涵盖了基本的诊断方法，包括放射学解读和超声检查结果，从保守治疗到手术干预的循证治疗方案，以及影响患者预后的预后因素。如果管理得当，存活率超过90%，了解肠梗阻诊断和治疗的细微差别对于管理急性腹部急症的兽医从业者至关重要。

## 摘要

犬猫肠梗阻是一种复杂的急症，需要系统评估和及时干预。幼年动物和大型犬对异物梗阻表现出更高的易感性，而线性异物预后特别严重，87.5%需要手术干预，而离散异物则较低。

成功的治疗取决于通过特征性临床症状的早期识别，包括喷射性呕吐、腹痛和放射学显示的肠道扩张证据。在精心选择的病例中，保守治疗成功率为47%，而手术干预在猫中取得了91%的两周存活率，在即使需要再次手术的狗中存活率也达到83%。

| 因素 | 预后较好 | 预后较差 |
|--------|------------------|-----------------|
| **异物类型** | 离散、非线性物体 | 线性异物 |
| **患者状态** | ASA <3，血流动力学稳定 | ASA ≥3，不稳定表现 |
| **持续时间** | 早期就诊 | 长时间梗阻 |
| **管理方式** | 及时干预 | 延迟治疗 |

通过环境控制和主人教育进行预防仍然是首要任务，特别是对于重复犯病和高风险品种。通过适当的围手术期管理和早期肠内喂养方案，大多数患者都能获得优秀的长期生活质量，强调了在伴侣动物实践中及时识别和循证治疗方法的重要性。

## 疾病概述

肠梗阻是胃肠道的一种阻塞，干扰食物和液体的通过，可能导致危及生命的后果[1]。这种情况是犬猫最常见的手术急症之一，通常导致顽固性呕吐并需要立即干预[1]。

根据位置，梗阻可分为三大类：腔外（肠腔外）、壁内（肠壁内）或腔内（肠腔内）[1]。最常见的腔外原因是肠套叠，即胃肠道的一段被相邻的一段包裹，通常发生在回盲结肠交界处[1]。壁内梗阻由浸润性疾病引起，如肿瘤、真菌感染或肉芽肿，而腔内梗阻通常继发于异物摄入[1]。

无论病因如何，未解决的梗阻会导致近端胃肠道液体和气体扩张[1]。病理生理学涉及静脉回流受损而动脉血流维持，导致充血、缺氧和潜在的坏死[1]。如果不及时纠正，这可能导致细菌移位、内毒素血症和低血容量性休克[1]。

幼猫和大型犬易患异物性梗阻，而肠套叠最常见于幼犬[1]。机械性原因包括异物、肿瘤、狭窄和粘连，而功能性原因涉及严重炎症或代谢紊乱[6]。

### Sources

[1] Gastrointestinal Obstruction in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[6] Gastrointestinal motility disorders (Proceedings): https://www.dvm360.com/view/gastrointestinal-motility-disorders-proceedings

## 临床症状和体征

犬猫肠梗阻的临床表现各不相同，取决于梗阻的持续时间、程度和位置[1]。最常见的体征是呕吐，但在远端小肠梗阻时较少见[1]。幼猫和年轻的大型犬比老年动物更可能因异物梗阻而就诊[1]。

**主要临床症状**

呕吐和厌食是肠梗阻的标志性体征[1]。患者还可能出现腹泻、体重减轻、嗜睡和败血症性休克体征，但这些较为少见[1]。体格检查可能显示腹痛或可触及的肠道肿块[1]。

**位置特异性变化**

近端小肠梗阻通常引起中度至重度呕吐，而中远端空肠和回肠梗阻可能呕吐较少[2]。在胃潴留疾病中，呕吐通常具有独特的"喷射性"特征，描述为强力喷射，从口中呈水流状喷出而不是形成堆状[2]。

**物种特异性模式**

猫需要仔细进行口腔检查，因为线性异物可能锚定在舌根[1]。如果存在，必须立即切断，切勿拉动。肠套叠最常见于幼犬，通常引起腹痛、呕吐和腹泻，可能带血或不带血[1]。低血容量性休克和腹痛的体征通常伴随肠嵌顿病例出现[1]。

### Sources

[1] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals

[2] Gastrointestinal motility disorders (Proceedings): https://www.dvm360.com/view/gastrointestinal-motility-disorders-proceedings

## 诊断方法

诊断肠梗阻需要系统的方法，结合临床表现评估、实验室评估和先进的影像学技术[1]。体格检查应专注于腹部触诊，以检测扩张的肠袢、肿块或穿孔体征[1]。

实验室检查结果为梗阻提供支持性证据。常见变化包括白细胞增多伴左移、低氯血症和代谢性碱中毒，无论梗阻位置如何[1]。明显的白细胞增多或白细胞减少伴退行性左移可能表明穿孔和继发性细菌性腹膜炎[1]。

放射学成像仍然是诊断的基础。普通X光片可以识别不透射线的异物，并显示肠梗阻伴肠袢扩张，内含液体和/或气体[1]。使用钡剂的造影检查对检测可透射线的异物和肠套叠有价值，但如果怀疑穿孔，应使用水溶性碘剂[1]。

超声检查对检测肠道异物、含液体的扩张肠袢以及肠套叠的"靶环"样特征性表现（同心圆高回声和低回声环）非常有效[1]。高频探头（>7.5 MHz）优化了肠壁层的可视化[2]。患者禁食通过减少气体和食糜来提高图像质量[2]。

### Sources
[1] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[2] Ultrasonography of the gastrointestinal tract: https://www.dvm360.com/view/ultrasonography-gastrointestinal-tract-myriad-disease-proceedings

## 治疗选择

肠梗阻的治疗需要立即进行医疗稳定，然后在大多数情况下进行手术干预。医疗稳定侧重于使用平衡电解质溶液进行积极的液体复苏，以纠正脱水和电解质失衡[1]。患有胃肠道异物性梗阻的狗受益于更长的术前液体复苏，以优化心血管稳定性[2]。

对于血流动力学稳定患者的离散异物病例，可以考虑保守治疗[2]。保守治疗包括液体疗法、胃肠道支持和疼痛管理，并通过系列影像学监测异物通过情况[2]。在一项研究中，医疗管理在47%的病例中成功，对于胃和小肠异物且无进行性扩张证据的病例成功率更高[2]。

手术治疗包括近端梗阻的胃切开术、远端异物的肠切开术，或无活力肠段的肠切除吻合术[1][3]。肠切开术应在梗阻部位附近的健康组织上进行[3]。对于线性异物，必须首先释放近端锚定点，然后在移除前轻柔地将物质挤向更健康的肠段[4]。使用单丝可吸收材料的简单间断缝合提供最佳闭合[1][2]。

术后护理包括持续的液体治疗、多模式疼痛管理和止吐治疗[3]。预防性抗生素适用于肠道手术[2][5]。12小时内早期肠内喂养促进肠道愈合和蠕动[4]。术后48-96小时之间的超声检查允许早期发现肠裂开[6]。

### Sources
[1] Intestinal surgery (part 1) (Proceedings): https://www.dvm360.com/view/intestinal-surgery-part-1-proceedings
[2] Clinical features and outcomes of dogs with attempted medical management for discrete gastrointestinal foreign material: 68 cases (2018-2023): https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml
[3] Resolving a small-bowel obstruction: https://www.dvm360.com/view/resolving-a-small-bowel-obstruction
[4] Surgery pearls: Removing linear foreign bodies in dogs: https://www.dvm360.com/view/surgery-pearls-removing-linear-foreign-bodies-in-dogs
[5] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[6] Evaluation of early and systematic ultrasound examination to diagnose intestinal dehiscence following intestinal surgery in dogs: https://avmajournals.avma.org/view/journals/javma/263/1/javma.23.10.0599.xml

## 预防措施

肠梗阻的预防侧重于全面的饮食管理、环境控制和针对性的主人教育策略[1][2]。饮食预防通过适当的营养和喂养实践构成梗阻预防的基石。高纤维饮食有助于促进正常的胃肠道蠕动并预防便秘相关梗阻，同时确保充足的水分摄入可防止粪便嵌塞[2][4]。

环境控制措施对于最大限度地减少异物摄入风险至关重要。宠物主人应妥善保管可能造成梗阻危险的家居物品，包括塑料制品、骨头、玩具和线状材料如绳子或纱线[1][2][3]。幼犬和幼猫对异物梗阻表现出更高的易感性，在其探索阶段需要加强警惕[2][6]。在玩耍和用餐期间定期监督可减少接触潜在危险物品的机会[3]。

特定的行为管理策略包括通过益智喂食器和狩猎玩具为猫提供适当的狩猎和喂养丰富化[10]。这些鼓励自然觅食行为，同时减少因无聊而摄入不适当物品的情况[10]。对于狗，通过幼犬防护环境进行适当的板条箱训练可防止接触可能引起肠梗阻的绳子、绳索和难以消化的材料[3]。

主人教育是预防的关键组成部分，特别是关于品种特异性风险和重复犯病管理[2][6]。对于有既往梗阻发作史的动物，实施严格的环境管理协议变得至关重要。这包括消除接触先前摄入的材料，并建立具有适当分量的规律喂养程序[4]。定期兽医监测有助于识别复发早期迹象，在完全梗阻发展前实现及时干预[6]。

### Sources

[1] Surgery STAT: Surgical management of gastrointestinal foreign bodies: https://www.dvm360.com/view/surgery-stat-surgical-management-gastrointestinal-foreign-bodies
[2] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[3] Canine housetraining, Part 2: Managing developmental issues with puppy crating: https://www.dvm360.com/view/canine-housetraining-part-2-managing-developmental-issues-with-puppy-crating
[4] Constipation and Obstipation in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/constipation-and-obstipation-in-small-animals
[6] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[10] Feeding cats with different nutritional needs-a dilemma in multicat households (Proceedings): https://www.dvm360.com/view/feeding-cats-with-different-nutritional-needs-dilemma-multicat-households-proceedings

## 鉴别诊断

肠梗阻的临床表现可能与几种其他引起急性腹部症状的疾病非常相似，需要仔细鉴别以确保适当治疗[1]。**功能性肠梗阻**是一个关键的鉴别诊断，特别是在患有细小病毒感染的狗中，严重的肠道炎症导致运动减退而无机械性梗阻[1,4]。与真正的梗阻不同，功能性肠梗阻通常对支持治疗有反应，而不是手术干预。

**胃肠炎**通常表现为呕吐，可能引起类似梗阻的急性发作症状[2]。然而，胃肠炎患者在X光片上通常保持正常的肠道气体模式，缺乏真正梗阻特征性的梗阻点近端进行性扩张[1]。

**胰腺炎**可通过严重腹痛和呕吐模拟梗阻，但诊断影像学显示胰腺炎症而非肠道扩张[4]。血清胰腺脂肪酶免疫反应性（cPLI/fPLI）有助于区分胰腺炎和梗阻[9]。

**胃扩张和扭转（胃胀气）**表现相似，伴有急性呕吐和腹部扩张，但特别影响胃部[2,6]。放射学检查结果显示特征性的胃位置而非小肠扩张模式。

关键的鉴别特征包括放射学显示梗阻部位近端肠袢液体和气体扩张、异物在系列影像学中不移动，以及造影检查中特定的梗阻模式[1]。这些发现结合尽管支持治疗但临床恶化的情况，有助于区分真正的机械性梗阻与可能通过医疗管理解决的功能性疾病。

### Sources
[1] Gastrointestinal Obstruction in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[2] Disorders of the Stomach and Intestines in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[3] Acute Intestinal Obstructions in Large Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/acute-intestinal-obstructions-in-large-animals/acute-intestinal-obstructions-in-large-animals
[4] Diagnosis and management of GI motility disorders: https://www.dvm360.com/view/diagnosis-and-management-of-gi-motility-disorders
[5] Gastrointestinal motility disorders (Proceedings): https://www.dvm360.com/view/gastrointestinal-motility-disorders-proceedings
[6] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[7] Diagnostic approach to diarrhea (Proceedings): https://www.dvm360.com/view/diagnostic-approach-diarrhea-proceedings
[8] Acute and chronic vomiting in dogs and cats (Proceedings): https://www.dvm360.com/view/acute-and-chronic-vomiting-dogs-and-cats-proceedings
[9] What Is Your Diagnosis? in: Journal of the American Veterinary Medical Association Volume 241 Issue 3 (): https://avmajournals.avma.org/view/journals/javma/241/3/javma.241.3.319.xml

## 预后

肠梗阻的预后根据几个关键因素而有显著差异。早期干预和就诊时的患者稳定性是结果的主要决定因素[1]。

**存活率和结果**
接受胃肠道异物手术的猫两周存活率优秀，为91%[1]。因并发症需要第二次手术的狗保持83%的存活率[4]。这些良好的结果很大程度上取决于及时的手术干预和适当的围手术期管理。

**关键预后因素**
就诊时的患者稳定性显著影响预后。ASA状态≥3的狗面临更高的并发症风险，特别是胃肠道手术后的裂开[5]。梗阻持续时间与组织活力和手术复杂性直接相关。长时间梗阻增加肠缺血、穿孔和败血症性腹膜炎的风险[1][8]。

**线性异物与非线性异物**
线性异物预后明显较差，87.5%需要手术，而非线性物体的手术率较低[2]。线性物体引起部分梗阻并可能撕裂肠壁，导致腹膜炎[1]。线性异物病例的医疗管理成功率明显较低。

**生活质量考虑**
大多数出院的患者在适当处理和管理根本原因后，都能获得优秀的长期生活质量。

### Sources
[1] Practical imaging of the gastrointestinal tract: https://www.dvm360.com/view/practical-imaging-gastrointestinal-tract-proceedings
[2] Clinical features and outcomes of dogs with attempted medical management: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml
[3] Diseases Associated with Colic in Horses: https://www.merckvetmanual.com/digestive-system/colic-in-horses/diseases-associated-with-colic-in-horses-by-anatomic-location
[4] Early detection of small intestinal strangulating obstruction: https://www.dvm360.com/view/early-detection-small-intestinal-strangulating-obstruction-proceedings
