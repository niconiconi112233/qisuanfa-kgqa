# 伴侣动物支原体感染

支原体感染在小动物临床实践中构成了重大的诊断和治疗挑战，既包括影响犬猫的呼吸道病原体，也包括血营养性物种。这些缺乏细胞壁的细菌引起多样的临床表现，从上呼吸道疾病和结膜炎到严重的溶血性贫血以及包括多发性关节炎和神经系统体征在内的全身性并发症。本报告探讨了伴侣动物支原体感染的流行病学、临床表现、诊断方法和治疗策略。涵盖的关键领域包括区分呼吸道支原体（如*猫支原体*和*犬支原体*）与血营养性物种，鉴于其挑剔的性质和共生存在所带来的准确诊断挑战，以及强调多西环素作为一线治疗并针对难治性病例提供适当替代方案循证治疗方案。

## 摘要

伴侣动物支原体感染提出了复杂的诊断和治疗挑战，需要系统性的临床方法。*猫支原体*成为猫的主要呼吸道病原体（占病例的60%），而*犬支原体*主导犬类感染（占病例的66%），两者在临床表现和解剖靶点方面与血营养性物种存在显著差异。

诊断主要依赖PCR检测，因为培养困难，对于下呼吸道感染，支气管肺泡灌洗液相比鼻拭子提供更优质的样本。鉴于这些生物在健康动物中的共生性质，临床解释仍然具有挑战性。

| 方面 | 呼吸道支原体 | 血营养性支原体 |
|--------|------------------------|----------------------|
| 主要靶点 | 上/下呼吸道、眼睛 | 红细胞 |
| 关键临床症状 | 结膜炎、鼻炎、咳嗽 | 溶血性贫血、虚弱 |
| 诊断样本 | BAL液、结膜拭子 | 血涂片、PCR |
| 治疗持续时间 | 7-14天 | 2-6周 |

治疗以多西环素（5 mg/kg，每12小时一次，持续7-10天）为中心作为一线疗法，氟喹诺酮类和大环内酯类作为替代方案。通过减少过度拥挤和压力管理进行环境控制对于预防至关重要，特别是在收容所环境中。

未来的重点应集中在开发快速诊断工具，并为区分临床样本中致病性与共生性支原体存在制定更明确的指南。

## 疾病概述

支原体感染是影响伴侣动物的细菌性疾病，由支原体属中缺乏细胞壁的微生物引起[1]。这些挑剔的细菌主要引起犬猫的呼吸道感染，尽管它们也可能导致全身性疾病，如血营养性支原体病（猫传染性贫血）[2]。

临床上最重要的物种包括犬的*犬支原体*和猫的*猫支原体*，其中*犬支原体*是犬呼吸道疾病检测组中最常见的病原体（占病例的66%），*猫支原体*占猫病例的60%[1]。这些生物是正常呼吸道菌群的一部分，但在某些条件下会变得致病[3]。此外，支原体感染可能引发某些猫的哮喘反应[4][5]。

传播通过直接接触、呼吸道飞沫和污染物发生。对于血营养性物种，跳蚤充当媒介，适当的跳蚤控制对于预防至关重要[6]。风险因素包括免疫功能受损、并发感染（如猫白血病病毒或猫免疫缺陷病毒）、压力、过度拥挤和通风不良。幼年动物、老年宠物和收容所环境中的动物由于免疫系统不成熟和接触机会增加而面临更高风险。

### Sources
[1] A retrospective analysis of canine, feline, and equine respiratory polymerase chain reaction panels: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.11.0755/javma.24.11.0755.pdf
[2] Hemotropic Mycoplasma Infections in Animals: https://www.merckvetmanual.com/circulatory-system/blood-parasites/hemotropic-mycoplasma-infections-in-animals
[3] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-animal-shelters
[4] Feline asthma (Proceedings): https://www.dvm360.com/view/feline-asthma-proceedings
[5] Managing allergic asthma in cats (Proceedings): https://www.dvm360.com/view/managing-allergic-asthma-cats-proceedings
[6] Flea-associated illnesses in cats: https://www.dvm360.com/view/flea-associated-illnesses-cats

## 常见病原体

现有内容全面涵盖了血营养性支原体，但支原体感染还包括引起呼吸道和眼部疾病的非血营养性物种。*猫支原体*是猫的重要呼吸道病原体，与血支原体有很大不同[6]。

*猫支原体*是猫呼吸道疾病复合体的关键组成部分，引起严重的结膜水肿和较轻度的鼻炎[6]。与血营养性支原体不同，*猫支原体*感染眼睛和上呼吸道通道，而不是红细胞[6]。这种生物特征性地产生严重的结膜水肿并伴有相关炎症，受感染的猫可能偶尔打喷嚏[6]。随着疾病进展，发热可能伴随从浆液性泪液分泌物到粘脓性结膜炎、淋巴细胞浸润和上皮增生的进展而发展[6]。

*猫支原体*在吉姆萨染色的结膜涂片中表现为细胞外球状体，通常见于结膜上皮细胞表面[6]。该生物对四环素类和氟喹诺酮类有反应，这些药物对*猫衣原体*和*猫支原体*都最有效[6]。这代表了与血支原体的明确治疗区别，后者主要需要多西环素治疗来管理溶血性贫血。

感染*猫支原体*的恢复期猫可能经历临床复发，类似于血营养性物种中观察到的携带者状态[6]。然而，临床表现和受影响的解剖部位将呼吸道支原体与其血营养性对应物区分开来，强调了支原体属在伴侣动物中多样的致病潜力。

### Sources

[1] Hemotropic Mycoplasma Infections in Animals: https://www.merckvetmanual.com/circulatory-system/blood-parasites/hemotropic-mycoplasma-infections-in-animals

[2] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml

[3] Interpretation of anemias- by the numbers and by the cells: https://www.dvm360.com/view/interpretation-anemias-numbers-and-cells-proceedings

[4] Recognizing infectious organisms in the blood film: https://www.dvm360.com/view/recognizing-infectious-organisms-blood-film-proceedings

[5] Infectious hemoylytic anemias: Look for an underlying cause: https://www.dvm360.com/view/infectious-hemoylytic-anemias-look-underlying-cause

[6] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex

## 临床症状和体征

猫和犬的支原体感染表现出影响多个身体系统的多样临床表现。上呼吸道体征通常包括急性发热、打喷嚏、鼻分泌物和眼分泌物[1]。在猫科动物中，结膜炎和角膜溃疡可能作为上呼吸道综合征的一部分发展[1]。

下呼吸道受累可表现为咳嗽、喘息和呼吸窘迫，类似于感染某些支原体物种的猫中的"哮喘样"体征[2]。一些患者可能进展为需要立即干预的明显呼吸困难。

呼吸道外表现在支原体感染中尤为重要。多发性关节炎代表主要的临床表现，受影响的动物表现出发热、感觉过敏、行走困难、关节积液和关节疼痛[2]。这些生物对关节组织表现出嗜性，引起化脓性炎症反应，如果不治疗可能变成慢性。

神经系统受累虽然不太常见，但可通过全身播散发生。临床体征可能包括癫痫发作、中枢前庭体征、头部顶撞以及背痛或轻瘫[3][4]。这些表现通常表明更严重的全身性感染，需要积极的治疗干预。

临床表现通常在物种间有所不同，猫最初经常表现出更细微的体征。许多病例表现为非特异性体征，包括厌食、嗜睡和体重减轻，在没有适当诊断测试的情况下使早期诊断具有挑战性[1]。

### Sources
[1] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-animal-shelters
[2] Feline infectious diseases-a collection of interesting cases (Proceedings): https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings
[3] Canine influenza and the current outbreak: 10 takeaways: https://www.dvm360.com/view/canine-influenza-and-current-outbreak-ten-takeaways
[4] Meningitis, Encephalitis, and Encephalomyelitis in Animals: https://www.merckvetmanual.com/nervous-system/meningitis-encephalitis-and-encephalomyelitis/meningitis-encephalitis-and-encephalomyelitis-in-animals

## 诊断方法

准确诊断犬猫支原体感染需要结合临床评估、专业样本采集和先进实验室技术的综合方法。

临床表现评估形成诊断的基础。临床医生应评估呼吸道体征，包括慢性咳嗽、鼻分泌物和呼吸困难，同时进行完整的病史和体格检查[1]。支原体物种的挑剔性质使诊断复杂化，因为生物需要快速运输并且在宿主外部存活不良[2]。

样本采集技术对于成功检测至关重要。支气管肺泡灌洗（BAL）代表下呼吸道感染的最佳方法，与鼻拭子相比提供更优越的产率[1,4]。对于上呼吸道疾病，鼻冲洗标本比简单拭子提供更好的诊断潜力。BAL液的细菌培养和药敏测试有助于指导抗菌治疗，特别是在难治性病例中[1]。

PCR检测协议彻底改变了支原体诊断。与传统培养方法相比，分子分析提供了显著改善的敏感性和周转时间[2]。猫支原体的物种特异性PCR分析和属级PCR筛选测试在许多兽医实验室中可用，提供具有优异特异性的快速病原体鉴定[2]。

培养挑战仍然是支原体诊断的重大障碍。这些生物需要特殊培养基和长达一周的孵育时间[2]。缓慢生长的性质需要特定的实验室要求，因为常规培养方案可能无法检测这些病原体。传统显微镜鉴定在急性感染猫中的敏感性低于50%[3]。

结果解释需要仔细考虑共生存在。支原体物种在正常猫的口咽部和鼻腔中很容易检测到，使临床意义评估复杂化[2]。然而，从通常无菌部位（如下呼吸道）分离，特别是纯培养，支持致病性参与。

### Sources
[1] Merck Veterinary Manual Pneumonia in Dogs and Cats: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/pneumonia-in-dogs-and-cats
[2] DVM 360 Mycoplasmas in feline medicine: https://www.dvm360.com/view/mycoplasmas-feline-medicine-proceedings
[3] Merck Veterinary Manual Hemotropic Mycoplasma Infections: https://www.merckvetmanual.com/circulatory-system/blood-parasites/hemotropic-mycoplasma-infections-in-animals
[4] Merck Veterinary Manual Diagnostic Techniques for Respiratory Disease: https://www.merckvetmanual.com/respiratory-system/respiratory-system-introduction/diagnostic-techniques-for-respiratory-disease-in-animals

## 治疗选择

**伴侣动物支原体感染的一线抗菌治疗以多西环素为中心**[2]。推荐剂量为5 mg/kg口服，每12小时一次，或10 mg/kg口服，每24小时一次，给药7至10天[2]。多西环素对常见呼吸道病原体提供广谱活性，猫耐受性良好[2]。

**当一线治疗有禁忌时，替代抗生素包括大环内酯类和氟喹诺酮类**[2,3]。当支原体物种不被高度怀疑时，可以考虑阿莫西林（22 mg/kg口服，每12小时一次）[2]。对于血营养性支原体，普拉多沙星和马波沙星已证明对*猫血支原体*有效[9,10]。

**呼吸道感染的治疗持续时间通常为7-14天**，治疗持续至少一周直到临床症状消退[2,5]。在肺炎病例中，无论疾病严重程度如何，最初建议使用肠外抗生素，出院后改为口服抗生素[5]。对于慢性感染，治疗持续时间可能延长至四至六周，取决于临床反应[5]。

**支持性护理措施包括维持水合状态、为厌食患者提供辅助喂养以及在需要时进行氧气补充**[6]。对于与血营养性支原体相关的严重溶血性贫血，可能需要输血和糖皮质激素来管理免疫介导的红细胞破坏[9]。

**监测治疗反应包括在开始治疗后10-14天内进行临床重新评估**[5]。如果呼吸道感染在48小时内没有改善，应考虑改用不同的抗菌药物类别[2]。建议对肺炎病例进行随访X光检查以评估治疗反应[5]。

### Sources
[1] AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.04.0133/ajvr.25.04.0133.pdf
[2] What are the best practices for antibiotic use in feline upper respiratory tract disease?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-feline-upper-respiratory-tract-disease
[3] Antimicrobial Use in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-eye/antimicrobial-use-in-animals
[4] What are the best practices for antibiotic use in canine infectious respiratory disease complex?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-canine-infectious-respiratory-disease-complex
[5] What are the best practices for antibiotic use in pneumonia, bronchitis and pyothorax?: https://www.dvm360.com/view/what-are-best-practices-antibiotic-use-pneumonia-bronchitis-and-pyothorax
[6] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[7] Quinolones, Including Fluoroquinolones, Use in Animals: https://www.merckvetmanual.com/pharmacology/antibacterial-agents/quinolones-including-fluoroquinolones-use-in-animals
[8] Mycoplasmas in feline medicine: https://www.dvm360.com/view/mycoplasmas-feline-medicine-proceedings
[9] Hemotropic Mycoplasma Infections in Animals: https://www.merckvetmanual.com/circulatory-system/blood-parasites/hemotropic-mycoplasma-infections-in-animals
[10] Use of pradofloxacin to treat experimentally induced Mycoplasma hemofelis infection in cats: https://avmajournals.avma.org/view/journals/ajvr/70/1/ajvr.70.1.105.xml

## 预防措施和鉴别诊断

### 预防措施

环境控制对于管理多猫环境中的支原体感染至关重要。在收容所和猫舍中，减少过度拥挤显著降低传播风险，因为拥挤增加接触率并损害空气质量[1]。关键控制措施包括在可能的情况下进行"点清洁"而不是完全清洁笼舍、大幅增加笼舍尺寸以及提供躲避处以减少压力[4]。由于压力激活疱疹病毒脱落并易患继发感染，尽量减少不必要的处理和笼舍移动至关重要[7]。

消毒方案应针对所涉及的特定病原体。虽然支原体物种通常对常规消毒剂敏感，但猫杯状病毒（一种常见的共同病原体）需要1:32稀释的漂白剂溶液或过一硫酸钾[4]。定期清洁必须先于消毒，因为有机碎屑会使所有消毒剂失效。

### 鉴别诊断

支原体呼吸道感染的关键鉴别包括病毒性上呼吸道病原体、猫衣原体和支气管败血波氏杆菌[6,7]。猫疱疹病毒-1通常引起更严重的结膜和鼻部体征，而猫杯状病毒常产生口腔溃疡[6]。猫衣原体特征性地产生慢性结膜炎，伴有最小的鼻部体征[8]。支气管败血波氏杆菌可能引起咳嗽，并可能影响上呼吸道和下呼吸道[7]。猫支原体经常发生在合并感染中，特别是与杯状病毒，使临床鉴别复杂化[1,6]。PCR组可以帮助同时识别多种病原体，尽管阳性结果并不总是表明活跃的疾病原因[1]。

### Sources

[1] Mycoplasmas in feline medicine (Proceedings): https://www.dvm360.com/view/mycoplasmas-feline-medicine-proceedings
[2] Feline Respiratory Disease Complex - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[3] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
[4] Shelter Snapshot: Infectious respiratory disease in animal shelters: https://www.dvm360.com/view/shelter-snapshot-infectious-respiratory-disease-in-animal-shelters
