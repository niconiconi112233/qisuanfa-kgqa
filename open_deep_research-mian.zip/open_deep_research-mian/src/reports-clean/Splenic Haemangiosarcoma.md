# 伴侣动物脾血管肉瘤

脾血管肉瘤是小动物临床中最具破坏性的恶性肿瘤之一，主要影响大型品种犬，中位年龄为10岁。这种高度侵袭性的血管内皮肿瘤占所有脾脏肿块的45-65%，病程隐匿，通常在发生灾难性破裂之前都未被检测到。该疾病的临床意义在于其双重性质：涉及肿瘤破裂导致低血容量性休克的急性急诊表现，以及挑战早期诊断的隐匿性慢性表现。尽管手术和化疗干预取得了进展，预后仍然很差，不到10%的患者能存活超过一年，这使得该疾病成为兽医急诊医学和肿瘤学的重要关注点。

## 疾病概述

脾血管肉瘤是一种高度恶性的血管内皮肿瘤，约占所有犬类肿瘤的2%[1]。这种侵袭性癌症起源于血管内壁的内皮细胞，并通过血行转移表现出快速的转移潜力[1]。

该疾病主要影响老年犬，诊断时的平均年龄为10岁[1]。大型和巨型品种犬明显高发，德国牧羊犬、金毛寻回犬和拉布拉多寻回犬表现出明显的品种易感性[2][3]。考虑到强烈的品种关联，怀疑存在遗传成分，但确切病因仍不清楚[1]。

脾血管肉瘤遵循"双三分之二规则"，即三分之二的脾脏肿块是恶性的，而这些恶性肿瘤中三分之二是血管肉瘤，占犬类所有脾脏肿块的45-65%[2]。然而，出现肿瘤破裂和血腹的犬类具有更高的恶性肿瘤发生率，80%的非创伤性血腹病例是肿瘤性的，其中88%是血管肉瘤[2]。

该肿瘤的生物学特征是早期局部浸润和远处转移，常见影响大网膜、肝脏和肺部[1]。约50%的犬在诊断时已有肉眼可见的转移性疾病[2]。尽管采用了积极的治疗方法，1年生存率仍低于10%，突显了与这种恶性肿瘤相关的不良预后[2]。

### Sources
[1] Canine and feline hemangiosarcoma-recent advance (Proceedings): https://www.dvm360.com/view/canine-and-feline-hemangiosarcoma-recent-advance-proceedings
[2] Essential information for veterinarians about hemangiosarcoma: https://www.dvm360.com/view/essential-information-for-veterinarians-about-hemangiosarcoma
[3] Association between previous splenectomy and gastric...: https://avmajournals.avma.org/view/journals/javma/242/10/javma.242.10.1381.xml

## 常见病原体

脾血管肉瘤不是由传染性病原体引起的，而是代表一种具有多因素病因的肿瘤性疾病。与细菌或病毒疾病不同，血管肉瘤起源于血管内皮细胞的恶性转化，没有特定的微生物参与[1]。

确切病因仍不完全清楚，但几个因素可能促进肿瘤发展。遗传易感性似乎很重要，已在犬血管肉瘤中证实p53和PTEN肿瘤抑制基因的突变，可能在疾病进展中发挥作用[2]。这些分子改变表明是遗传易感因素而非传染性原因。

环境暴露已被研究作为潜在的风险因素，尽管尚未确定明确的因果关系。莫里斯动物基金会金毛寻回犬终生研究继续检查环境化学暴露及其与犬类癌症发展的联系[3]。

紫外线辐射在皮肤血管肉瘤的发展中起明确作用，尽管这一机制不适用于脾脏形式。脾脏变异型缺乏导致皮肤血管肉瘤发病机制的直接太阳辐射暴露。

现有证据表明，脾血管肉瘤可能是由遗传易感性、年龄相关的细胞变化以及潜在环境因素之间的复杂相互作用引起的，而不是需要针对病原体治疗方法传染性疾病过程。

### Sources
[1] Long-term complications of splenectomy in dogs with ...: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.05.0307/javma.25.05.0307.pdf
[2] Canine and feline hemangiosarcoma-recent advance ...: https://www.dvm360.com/view/canine-and-feline-hemangiosarcoma-recent-advance-proceedings
[3] Morris Animal Foundation Golden Retriever Lifetime Study ...: https://www.dvm360.com/view/morris-animal-foundation-golden-retriever-lifetime-study-commemorates-10-years

## 临床症状和体征

脾血管肉瘤表现出高度可变的临床表现，从急性危及生命的虚脱到隐匿的慢性体征[1]。犬可能表现出非特异性症状，包括食欲减退、嗜睡或胃肠道不适，使早期诊断具有挑战性[1]。

**急性表现**是戏剧性的，构成兽医急症。犬在急性虚脱后出现低血容量性休克，常伴有苍白黏膜、虚弱和出血性休克体征[1][2]。这些急诊病例通常涉及脾脏肿块破裂导致血腹[1][2]。临床症状可迅速进展为急性呼吸窘迫，表现为不停喘气、呼吸急促和呼吸困难[3]。

**慢性表现**更为隐匿，特征是间歇性虚弱、慢性嗜睡和运动不耐[1][2]。一些患者因进行性脾脏肿大或缓慢血液积聚而显示腹部膨胀[1][2]。胃肠道体征可能包括间歇性呕吐或腹泻[1]。

**品种特异性模式**显示德国牧羊犬、金毛寻回犬和拉布拉多寻回犬易感[1][2]。然而，任何犬种都可能发生这种恶性肿瘤[1]。

**偶然发现**发生在常规检查或为无关疾病进行影像学检查时发现脾脏肿块，许多犬在就诊时没有临床症状[1]。**体格检查**可能发现脾肿大、苍白黏膜、脉搏质量弱、毛细血管再充盈缓慢以及心动过速或呼吸急促[1][2]。

### Sources
[1] Essential information for veterinarians about hemangiosarcoma: https://www.dvm360.com/view/essential-information-for-veterinarians-about-hemangiosarcoma
[2] Update on canine hemangiosarcoma (Proceedings): https://www.dvm360.com/view/update-canine-hemangiosarcoma-proceedings
[3] Lethargy, hyporexia, and acute respiratory distress in a 3-year: https://avmajournals.avma.org/view/journals/javma/262/12/javma.24.07.0472.xml

## 诊断方法

脾血管肉瘤的诊断需要系统方法，结合临床评估、实验室检查和高级影像学检查[1]。实验室检查结果通常包括再生性贫血、血小板减少和全血细胞计数（CBC）中的裂红细胞，反映肿瘤相关出血和凝血病引起的微血管病变变化[1][3]。约半数患者存在凝血异常，需要评估凝血酶原时间或颊黏膜出血时间[1]。

影像学检查对诊断和分期至关重要。三视图胸部X光片可检测肺转移，诊断时50%的病例存在肺转移[1][3]。腹部超声检查仍然是优越的影像学技术，即使在X光细节模糊时也能评估肿块结构和检测腹腔积液[3][4]。超声检查不能明确区分良性和恶性病变，强调"双三分之二规则"，即只有45-65%的脾脏肿块是血管肉瘤[1]。

虽然超声心动图可以检测心脏受累，但其常规用于筛查右心房肿块存在争议[1]。细针抽吸细胞学检查的诊断价值有限（约25%），并且对囊性肿块有出血风险[1][3]。明确诊断需要手术切除后的组织病理学检查，因为没有无创检查能可靠地区分血管肉瘤与血肿或血管瘤等良性病变。

### Sources

[1] Essential information for veterinarians about hemangiosarcoma: https://www.dvm360.com/view/essential-information-for-veterinarians-about-hemangiosarcoma

[2] Canine and feline hemangiosarcoma-recent advance: https://www.dvm360.com/view/canine-and-feline-hemangiosarcoma-recent-advance-proceedings

[3] Update on canine hemangiosarcoma: https://www.dvm360.com/view/update-canine-hemangiosarcoma-proceedings

[4] Three-minute peripheral blood film evaluation: https://www.dvm360.com/view/three-minute-peripheral-blood-film-evaluation-erythron-and-thrombon

## 治疗选择

脾血管肉瘤治疗需要多模式方法，结合手术、化疗和支持性护理[2]。**手术脾切除术**是主要干预措施，通过切除出血肿块和防止危及生命的出血提供即时稳定[2]。然而，单独手术效果不佳，中位生存时间仅为1-3个月[2]。

**辅助化疗**显著改善生存结果。基于阿霉素的方案仍然是金标准，包括单药阿霉素、阿霉素联合环磷酰胺（AC方案）以及阿霉素联合环磷酰胺和长春新碱（VAC方案）[2]。这些方案将脾切除术后中位生存时间延长至约5-8个月[3][4]。各种基于阿霉素的方案显示出相似的效果，生存时间范围为140-202天[2]。

**支持性护理**对处理出血发作和贫血至关重要。对于出现急性出血和严重贫血的犬，可能需要输血[4]。液体治疗有助于在围手术期维持心血管稳定性。

**新兴疗法**显示出改善结果的前景。使用低剂量口服环磷酰胺和吡罗昔康的节律性化疗显示出令人鼓舞的结果，中位生存时间为178天[2][5]。免疫治疗方法，包括L-MTP-PE联合化疗，与单独化疗相比实现了273天的改善生存时间[2]。使用受体酪氨酸激酶抑制剂的靶向疗法正在研究用于常规化疗后的维持治疗[4]。

### Sources
[1] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/256/10/javma.256.10.1101.xml
[2] Canine and feline hemangiosarcoma-recent advance: https://www.dvm360.com/view/canine-and-feline-hemangiosarcoma-recent-advance-proceedings
[3] Osteosarcoma and hemangiosarcoma: The ugly sarcomas: https://www.dvm360.com/view/osteosarcoma-and-hemangiosarcoma-ugly-sarcomas-proceedings
[4] Update on canine hemangiosarcoma (Proceedings): https://www.dvm360.com/view/update-canine-hemangiosarcoma-proceedings
[5] Multimodality care in veterinary oncology (Proceedings): https://www.dvm360.com/view/multimodality-care-veterinary-oncology-proceedings

## 预防措施

脾血管肉瘤的一级预防由于其很大程度上自发性的性质而仍然具有挑战性。然而，可以实施几种风险缓解策略，特别是对于高风险品种，包括德国牧羊犬、金毛寻回犬、拉布拉多寻回犬、爱尔兰猎狼犬和维兹拉犬[1]。

早期检测筛查代表了最有希望的预防方法。在常规健康检查期间定期进行腹部超声检查可以在破裂发生前识别脾脏肿块，可能允许在患者更稳定时进行手术干预[2]。先进的筛查技术，包括液体活检测试，已显示出在高风险人群中早期癌症检测的前景，一些研究证明检测血管肉瘤和其他侵袭性癌症的敏感性为85.4%[5]。

对于皮肤血管肉瘤形式，紫外线保护措施至关重要。在高峰时段限制阳光照射并为户外犬提供遮荫可以减少光化性血管肉瘤风险，特别是对于毛发稀疏或色素浅的品种[1]。

补充方法包括支持性补充剂。云南白药，一种含有三七的中药配方，可能有助于管理出血发作并显示出体外抗肿瘤作用[3]。I'm-Yunity蘑菇提取物（多糖肽）在小规模研究中显示出适度的生存益处，平均生存时间约为199天，而未经治疗的犬为[3]。

虽然这些预防措施不能消除血管肉瘤风险，但它们可能促进早期检测或为受影响患者提供支持性益处。在实施任何补充方案之前，兽医咨询是必不可少的。

### Sources
[1] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[2] Essential information for veterinarians about hemangiosarcoma: https://www.dvm360.com/view/essential-information-for-veterinarians-about-hemangiosarcoma
[3] Integrating herbal support in canine hemangiosarcoma management: https://www.dvm360.com/view/integrating-herbal-support-in-canine-hemangiosarcoma-management
[4] The canine cancer conundrum: Insights into screening and detection: https://www.dvm360.com/view/the-canine-cancer-conundrum-insights-into-screening-and-detection
[5] Clinical validation study for pioneering early cancer detection test for dogs is published: https://www.dvm360.com/view/clinical-validation-study-for-pioneering-early-cancer-detection-test-for-dogs-is-published

## 鉴别诊断

区分脾血管肉瘤与其他脾脏肿块需要通过影像学和组织病理学进行系统评估，因为单独的临床表现不足以做出明确诊断[1]。

**良性脾脏肿块**
"双三分之二规则"表明约三分之一的脾脏肿块是良性的[2]。常见的良性鉴别诊断包括血肿、结节性增生、脓肿和血管瘤[2]。血管瘤表现为良性血管肿瘤，可压缩，呈红色至黑色外观，但与血管肉瘤不同，它们保持局部化而无转移潜力[4]。

**恶性脾脏肿瘤**
在恶性脾脏肿块中，血管肉瘤占45-65%的病例[2]。其他原发性脾脏恶性肿瘤包括肥大细胞瘤（猫占42%）、淋巴瘤和组织细胞肉瘤[1]。其他鉴别诊断包括平滑肌肉瘤、恶性纤维组织细胞瘤和骨肉瘤[3]。

**鉴别因素**
超声外观不能可靠地区分良性和恶性病变[2]。出现非创伤性血腹的犬类显示更高的恶性肿瘤发生率（80%），其中88%是血管肉瘤[2]。偶然发现的脾脏肿块（"偶然瘤"）显示较低的恶性肿瘤发生率，约为30%[2]。

明确诊断需要手术切除后的组织病理学检查[2,3]。细胞学检测恶性脾脏病变的诊断准确性有限（73%），由于肿瘤易脆性，细针抽吸存在出血风险[1,3]。

### Sources
[1] Prevalence of malignancy and factors affecting outcome: https://avmajournals.avma.org/view/journals/javma/261/11/javma.23.05.0258.xml
[2] Essential information for veterinarians about hemangiosarcoma: https://www.dvm360.com/view/essential-information-for-veterinarians-about-hemangiosarcoma
[3] Update on canine hemangiosarcoma: https://www.dvm360.com/view/update-canine-hemangiosarcoma-proceedings
[4] Tumors of the Skin in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs

## 预后

脾血管肉瘤预后严重，在各种治疗方式中生存结果 consistently 不佳。单独手术仅产生1-3个月的中位生存时间（MST）[1][2]。即使在脾切除术后进行基于阿霉素的化疗，最有效的治疗方法，MST也仅延长至约4-6个月（140-202天）[1][2]。

临床分期显著影响预后。I期疾病（肿瘤局限于脾脏）的犬显示出更长的生存时间，一些研究报告I期MST为345天，而III期为68-93天[2]。然而，无论治疗如何，不到10%的犬能存活超过一年[2]。

心脏受累代表特别差的预后指标。患有心脏血管肉瘤的犬生存时间极短，MST仅为0.07个月[3]。右心房肿块手术切除后进行化疗可将生存时间延长至约175天，而单独手术为42天[2]。

肿瘤破裂状态影响结果，当手术治疗时，未破裂的肿瘤通常与更好的预后相关。同时患有心脏和脾脏受累的犬面临最差的结果，通常在转移性疾病进展之前死于急性出血[2]。

### Sources

[1] Canine and feline hemangiosarcoma-recent advance: https://www.dvm360.com/view/canine-and-feline-hemangiosarcoma-recent-advance-proceedings

[2] Update on canine hemangiosarcoma: https://www.dvm360.com/view/update-canine-hemangiosarcoma-proceedings

[3] Pericardial effusion: causes and clinical outcomes in dogs: https://www.dvm360.com/view/pericardial-effusion-causes-and-clinical-outcomes-dogs-proceedings
