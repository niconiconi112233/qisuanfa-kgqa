# 伴侣动物硬膜外血肿

硬膜外血肿是兽医实践中一种危急的神经系统急症，指创伤性损伤后血液在颅骨或椎管与硬脑膜之间积聚。这种占位性病变对神经结构造成危及生命的压迫，需要立即识别和干预。在犬和猫中，硬膜外血肿最常见于机动车事故，可通过增加颅内压和继发性脑损伤导致快速的神经功能恶化。本报告探讨了兽医从业者管理这一挑战性疾病所需的病理生理学、临床表现、诊断方法和治疗策略，强调了早期手术干预和强化术后护理在决定患者预后方面的重要性。

## 疾病概述

**定义**

硬膜外血肿定义为血液在颅骨与覆盖脊髓或大脑的最外层膜（硬脑膜）之间积聚[1]。这种情况是一种占位性病变，可通过压迫神经结构导致显著的神经功能损害。

**解剖学考虑**

硬膜外间隙位于椎管或颅骨与硬脑膜之间。此间隙的血液积聚通常由创伤事件中的血管破裂引起，形成压迫脊髓或脑组织的占位性病变[1]。机动车事故是犬胸部创伤的最常见原因，气胸是最常见的创伤相关胸腔间隙疾病，在所有胸部创伤的犬和猫中发生率高达47%[2]。

**流行病学背景**

伴侣动物的硬膜外血肿主要与犬和猫的创伤性脑损伤相关。这些病变可能从血管破裂引起的占位性病变到更复杂的损伤，包括硬膜下血肿和脑实质内出血[1]。在一组骨折犬的病例中，基于放射学证据的创伤性血胸发生率为8.7%[3]。这种情况最常见于钝性创伤、机动车事故或影响头部或脊柱的穿透性损伤之后。

**年龄和风险因素**

硬膜外血肿的创伤性原因可影响任何年龄的动物，但由于活动量增加和创伤暴露风险较高，幼年动物可能面临更高风险[1]。神经系统急症在小动物临床中很常见，除创伤外，感染、肿瘤和炎症过程也是重要原因[4]。

### Sources
[1] Traumatic brain injury: keys to success (Proceedings): https://www.dvm360.com/view/traumatic-brain-injury-keys-success-proceedings
[2] Managing thoracic trauma (Proceedings): https://www.dvm360.com/view/managing-thoracic-trauma-proceedings-0
[3] Emergency approach to thoracic trauma (Proceedings): https://www.dvm360.com/view/emergency-approach-thoracic-trauma-proceedings
[4] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings

## 病因学和病理生理学

犬和猫的硬膜外血肿由创伤引起，导致颅骨与硬脑膜之间出血。机动车事故是犬胸部和颅脑创伤的最常见原因[1]。创伤引起的原发性脑损伤涉及多种力量，包括施加于颅骨的加速、减速和扭转力，这些可能导致血管破裂引起的占位性病变，包括硬膜外血肿、硬膜下血肿和脑实质内出血[2]。

病理生理机制涉及脑膜血管或静脉窦破裂，形成占位性病变。凝血病可能禁忌某些手术，并增加干预期间的出血风险[3]。血管破裂常见于硬膜外脊柱病变，因为创伤性损伤导致动脉和静脉出血进入硬膜外间隙[4]。积聚的血块压迫脑组织，导致颅内压升高和随后的继发性脑损伤。

继发性脑损伤是最关键的病理生理问题，涉及原发性损伤部位局部和远端的进行性神经元损伤。全身氧输送减少变得至关重要，因为氧输送取决于心输出量和动脉氧含量[2]。血肿的占位效应损害脑血流，如果颅内压超过脑灌注压阈值，可能导致脑缺血和进一步的神经元损伤[4]。低温可能使创伤病例复杂化，因为核心体温低于94°F会损害体温调节并减少热量产生[5]。

### Sources

[1] Managing thoracic trauma (Proceedings): https://www.dvm360.com/view/managing-thoracic-trauma-proceedings-0

[2] Traumatic brain injury: keys to success (Proceedings): https://www.dvm360.com/view/traumatic-brain-injury-keys-success-proceedings

[3] Local and regional anesthetic techniques (Proceedings): https://www.dvm360.com/view/local-and-regional-anesthetic-techniques-proceedings

[4] Neurological emergencies (Proceedings): https://www.dvm360.com/view/neurological-emergencies-proceedings-0

[5] Cold critters: Understanding hypothermia: https://www.dvm360.com/view/cold-critters-understanding-hypothermia

## 临床表现和诊断方法

犬和猫的硬膜外血肿表现为急性发作的神经系统体征，根据解剖位置而异[1]。临床症状包括精神状态改变、头倾斜、共济失调、肢体轻瘫或瘫痪，以及脊髓反射减弱或消失。神经系统检查常显示不对称性缺陷，如果大脑受累，可出现同侧运动功能障碍和对侧感觉变化[4]。

诊断影像学对确诊至关重要。MRI是金标准，在T1加权像上显示特征性高信号，在T2加权序列上根据血肿年龄显示混合信号[1][2]。CT成像显示高密度病变伴占位效应和潜在的中线移位[3]。先进影像学有助于将硬膜外血肿与其他占位性病变区分，并可检测身体深部的结构变化，包括血肿[3]。

实验室检查通常显示正常结果，除非存在潜在的凝血病[4]。脑脊液分析可能显示蛋白质和红细胞增加（如果进行），但在颅内压升高时禁忌[4]。

鉴别诊断包括脑肿瘤、脓肿、其他颅内出血，以及脊柱病例的急性椎间盘疾病[2]。鉴别因素包括急性发作、无发热（与脓肿区分），以及特征性影像学发现显示具有占位效应的血液产物，而非肿瘤浸润性病变的表现。

### Sources

[1] Subdural Hematoma of the Brainstem in a Dog: Magnetic...: https://meridian.allenpress.com/jaaha/article/41/6/400/176063/Subdural-Hematoma-of-the-Brainstem-in-a-Dog
[2] Medical management of spinal epidural empyema in five dogs: https://avmajournals.avma.org/downloadpdf/view/journals/javma/249/10/javma.249.10.1180.pdf
[3] Merck Veterinary Manual Computed Tomography in Animals - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/computed-tomography-in-animals
[4] Merck Veterinary Manual The Neurologic Evaluation of Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/the-neurologic-evaluation-of-dogs

## 治疗策略和预后

硬膜外血肿由于其危及生命的性质需要紧急手术干预[1]。相关疾病硬膜下积脓被认为是外科急症，因为颅内压升高和随后的脑干压迫很常见[1]。

医疗管理侧重于通过控制通气和适当的麻醉方案降低颅内压[4]。应避免使用氯胺酮和Telazol，因为它们会增加ICP，而将PaCO2维持在正常低值有助于抵消吸入麻醉药的血管扩张作用[4]。在急性腔隙出血病例中，可通过抽吸从体腔中回收血液[2]。

手术干预通常包括开颅术以清除血肿和控制出血源。术后护理需要密切监测神经系统状态、维持平均动脉压高于60 mmHg，以及将血糖控制在80-120 mg/dL之间[2]。体温调节和液体平衡管理是恢复的关键组成部分[2]。

长期神经预后取决于治疗前压迫的严重程度和持续时间[5]。经根治性手术干预后使用钛网颅骨成形术的病例已显示成功的24个月随访期，临床状态正常[3]。预后通常谨慎至不良，生存率很大程度上取决于快速识别和立即手术减压。

### Sources
[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/245/2/javma.245.2.175.xml
[2] Monitoring the Critically Ill Small Animal Using The Rule of 20: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/monitoring-the-critically-ill-small-animal/monitoring-the-critically-ill-small-animal-using-the-rule-of-20
[3] Use of a titanium mesh for cranioplasty following radical: https://avmajournals.avma.org/view/journals/javma/231/11/javma.231.11.1692.xml
[4] Anesthesia for neurologic disease and procedures: https://www.dvm360.com/view/anesthesia-neurologic-disease-and-procedures-proceedings
[5] Long-term neurologic outcome of hemilaminectomy and disk: https://avmajournals.avma.org/view/journals/javma/241/12/javma.241.12.1617.xml
