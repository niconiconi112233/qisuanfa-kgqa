# 犬猫爪脱落：兽医指南

爪脱落是小动物临床实践中的一项重大临床挑战，通过从传染性病原体到自身免疫性疾病的多种病因影响犬和猫。这本综合性兽医指南探讨了爪脱落的多方面性质，从细菌和真菌病原体（如假中间型葡萄球菌和皮肤癣菌）到品种特异性疾病（如德国牧羊犬的对称性狼疮性爪营养不良）。报告详细介绍了基本的诊断方法，包括细胞学、培养技术和放射学评估，同时概述了基于证据的治疗方案，涵盖抗菌治疗、手术干预和支持性护理。了解创伤性损伤、自身免疫性疾病和肿瘤过程之间的复杂鉴别诊断，使兽医能够提供针对性的治疗干预并实施有效的预防策略，以获得最佳的患者预后。

## 疾病概述

**定义**
爪脱落，或称甲脱落，是指犬猫的一个或多个爪从爪床上完全脱落或脱落的状况（默克兽医手册，2024年）。此病症包括多种爪部异常，包括甲裂（爪分裂）、甲周炎（爪褶炎症）以及可能导致爪完全脱落的进行性爪营养不良（dvm360，2024年）。

**流行病学背景**
爪脱落影响犬和猫，其患病率因潜在病因而异。细菌感染是最常见的原因，假中间型葡萄球菌是犬病例中的主要病原体（默克兽医手册，2024年）。对称性狼疮性爪营养不良（SLO）表现出明显的品种易感性，尤其影响3-8岁的德国牧羊犬、罗威纳犬和戈登塞特犬（dvm360，2024年）。该病症通常开始时仅涉及单个爪，但经常在数周至数月内进展至多个趾，中年犬对自身免疫性变体表现出更高的易感性（dvm360，2024年）。创伤性损伤仍然是总体上最常见的原因，而传染性病因更常见于继发性并发症而非原发性疾病过程（dvm360，2024年）。

## 常见病原体

犬猫的爪脱落可由影响爪床和周围组织的各种传染性病原体引起。了解这些病原体对于正确的诊断和治疗至关重要。

**细菌病原体**
犬爪感染中的主要细菌病原体是假中间型葡萄球菌[1]。其他细菌种类包括凝固酶阴性葡萄球菌、链球菌、微球菌属和不动杆菌属[1]。革兰氏阴性菌如大肠杆菌、奇异变形杆菌和假单胞菌属也可能作为继发性病原体参与[1]。这些感染通常继发于创伤或潜在疾病，而非爪脱落的主要原因[2]。

**真菌生物**
影响爪的皮肤癣菌感染虽不常见但具有临床意义[3]。最重要的种类包括犬小孢子菌、须毛癣菌和石膏样小孢子菌（原石膏样小孢子菌）[3]。这些病原体可影响皮肤和毛发，较少影响爪[3]。马拉色菌可导致爪呈棕红色变色并伴有蜡样渗出物[2]。包括芽生菌病、隐球菌病和孢子丝菌病在内的全身性真菌感染也可能影响爪床并引起全身性疾病[2,4]。

**寄生虫病因**
蠕形螨不直接影响爪，但通过持续性炎症和感染引起继发性变化[2]。与爪异常相关的其他寄生虫包括利什曼原虫和钩虫，可能需要特定的实验室检测来确认[2]。

### Sources
[1] Pyoderma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[2] Nail diseases (Proceedings) - dvm360: https://www.dvm360.com/view/nail-diseases-proceedings
[3] Dermatophytosis in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/dermatophytosis/dermatophytosis-in-dogs-and-cats
[4] Fungal Infections in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/disorders-affecting-multiple-body-systems-of-cats/fungal-infections-in-cats

## 临床症状和体征

犬猫爪脱落根据潜在病因表现出多样的临床表现。最常见的表现是**甲脱落**（爪完全脱落），可能从单个爪开始，但常进展至多个趾[1]。**甲裂**（爪分裂或断裂）常伴随此病症，爪显得干燥、变形和脆弱[2]。

**甲周炎**（爪褶炎症）表现为爪床周围肿胀、红斑和可能的脓性渗出物[1]。疼痛和跛行模式差异显著--受影响的动物可能表现出轻度不适到严重跛行，特别是在发生继发性细菌感染时[1][3]。

**品种特异性表现**在对称性狼疮性爪营养不良（SLO）中值得注意，德国牧羊犬、罗威纳犬和戈登塞特犬易患此病[2]。SLO通常影响中年犬（3-8岁），表现为多个爪进行性爪异常[2]。

**症状进展**常遵循特征性模式：初始单个爪受累，在数周至数月内进展至多个爪[2]。爪可能显得短、变色、变形、柔软和易碎，与爪床附着不良[1]。该病症可能伴有真菌感染中的棕红色变色或创伤的继发性并发症[1]。

### Sources
[1] Nail diseases (Proceedings): https://www.dvm360.com/view/nail-diseases-proceedings
[2] A pivotal pedicure: Understanding SLO: https://www.dvm360.com/view/pivotal-pedicure-understanding-slo
[3] Pain Management in Small Animals with Lameness: https://www.merckvetmanual.com/musculoskeletal-system/lameness-in-small-animals/pain-management-in-small-animals-with-lameness

## 诊断方法

临床检查是犬猫爪脱落诊断的基础。目视检查应评估爪受累程度、出血、肿胀和继发性细菌感染的存在[1]。体格检查必须评估所有受累及相邻的爪，以确定病情是局灶性还是全身性。

**细胞学检查**为炎症和感染过程提供快速的初步评估。受影响组织的细针抽吸或印片涂片可显示细菌生物、炎症细胞和组织碎片[2]。细胞学有助于区分感染性和非感染性原因，并指导进一步的诊断检测决策。

**细菌和真菌培养**对于鉴定特定病原体和确定抗菌药物敏感性模式仍然必不可少[1]。应在开始抗菌治疗前使用无菌技术采集新鲜组织样本或渗出物。在适当培养基中正确运输样本可确保最佳生物体回收。

**PCR检测**为病原体检测提供了更高的敏感性和特异性，特别是对于苛养生物或先前接受过抗菌治疗的病例[1]。当常规培养失败时，分子检测可以鉴定皮肤癣菌DNA、细菌病原体和其他传染性病原体。

**放射学检查**在怀疑骨骼受累时变得必要[3]。数字放射摄影可显示影响第三指骨的骨髓炎、骨折或异物穿透。可能需要多个视图来全面评估趾骨结构。

**通过活检进行组织病理学检查**在怀疑肿瘤过程时提供明确的组织特征描述[2]。组织样本应包括受影响的爪床和相邻正常组织，以确定结构变化和细胞特征。

### Sources
[1] Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[2] Merck Veterinary Manual - Cytology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[3] Merck Veterinary Manual - Radiography: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/radiography-of-animals

## 治疗选择

爪脱落的治疗需要多模式方法，包括药物干预、手术程序和支持性护理[1]。

**药物干预**：一线抗生素包括头孢氨苄（20-30 mg/kg 口服 每12小时一次）、阿莫西林-克拉维酸（13.75 mg/kg 口服 每12小时一次）或甲氧苄啶-磺胺嘧啶（15-30 mg/kg 口服 每12小时一次），疗程21-42天，在临床缓解后继续治疗5-7天[2]。对于真菌感染，可能需要使用伊曲康唑或特比萘芬等抗真菌药物。使用皮质类固醇或环孢素的免疫抑制疗法保留用于影响爪床的自身免疫性疾病。

**手术方法**：对于严重受损的爪，可能需要完全拔甲（爪切除术），需要切除第三指骨同时保留远端伸肌突起以维持正常趾功能[3]。部分P3切除术保留了深指屈肌腱插入点，防止腕关节背屈并维持正常步态[5]。对于严重的深部趾部脓毒症病例，当保守治疗失败时，手术选择包括关节固定术或截肢术[5]。

**护理和包扎**：适当的伤口管理包括使用氯己定或碘伏进行初步清洁，然后使用弹性绷带和胶带进行保护性包扎[4]。对于需要特殊护理的爪垫损伤，使用非粘附性初级绷带、厚实吸收性次级层和三级胶带可提供最佳愈合条件[6]。绷带应定期更换并监测感染或循环受损迹象。

治疗持续时间随感染严重程度而异，深度感染需要在临床缓解后继续7-21天[2]。

### Sources
[1] Merck Veterinary Manual - Antibacterials for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/antibacterials-for-integumentary-disease-in-animals
[2] DVM 360 - Managing superficial pyoderma with light therapy: https://www.dvm360.com/view/managing-superficial-pyoderma-with-light-therapy
[3] DVM 360 - ACVC 2019: Feline onychectomy: What we know and what we dont: https://www.dvm360.com/view/acvc-2019-feline-onychectomy-what-we-know-and-what-we-don-t
[4] DVM 360 - A declawing controversy: Stepping into the ring: https://www.dvm360.com/view/declawing-controversy-stepping-ring
[5] Merck Veterinary Manual - Lameness Originating in the Hoof in Cattle: https://www.merckvetmanual.com/musculoskeletal-system/lameness-in-cattle/lameness-originating-in-the-hoof-in-cattle
[6] DVM 360 - Paw tissues unique; injuries need special care, attention: https://www.dvm360.com/view/paw-tissues-unique-injuries-need-special-care-attention

## 预防措施

伴侣动物爪脱落的预防侧重于解决根本原因并实施适当的爪护理实践[1][2]。定期修剪爪对于维持最佳爪健康和防止可能导致爪脱落的创伤性损伤至关重要[4]。AAHA疫苗接种指南强调，预防性医疗是维持犬类健康、长寿和生活质量的基石[2][3]。

环境管理在预防中起着至关重要的作用。主人应为猫提供适当的抓挠表面，并确保将创伤风险降至最低的安全环境[2]。对于可能因过度抓挠和继发性爪损伤而导致过敏状况的动物，应尽可能实施全面的过敏原避免策略[6][7]。

解决潜在医疗状况对于预防爪脱落至关重要。患有异位性皮炎的犬和猫需要多模式管理，包括局部抗菌治疗、适当的沐浴方案以及识别继发性细菌或酵母感染等诱发因素[7][9]。甲状腺功能减退和肾上腺皮质功能亢进等内分泌疾病应得到适当诊断和治疗，因为这些问题会影响爪健康[7]。

常规寄生虫控制有助于预防可能导致过度抓挠和继发性爪创伤的瘙痒性疾病[7]。此外，保持适当的营养支持整体皮肤健康和爪完整性。

### Sources

[1] A review of medically unnecessary surgeries in dogs and cats: https://avmajournals.avma.org/view/journals/javma/248/2/javma.248.2.162.xml
[2] 2022 AAHA Canine Vaccination Guidelines (2024 Update): https://meridian.allenpress.com/jaaha/article/60/6/1/503802/2022-AAHA-Canine-Vaccination-Guidelines-2024
[3] 2022 AAHA Canine Vaccination Guidelines: https://meridian.allenpress.com/jaaha/article/58/5/213/485754/2022-AAHA-Canine-Vaccination-Guidelines
[4] How to introduce avian and exotic patients to your practice: https://www.dvm360.com/view/how-introduce-avian-and-exotic-patients-your-practice-proceedings
[5] Feline Chronic Pain: https://www.dvm360.com/view/feline-chronic-pain
[6] Atopic Dermatitis in Animals: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[7] Dermatological Problems in Animals: https://www.merckvetmanual.com/integumentary-system/integumentary-system-introduction/dermatological-problems-in-animals
[8] Canine Atopic Dermatitis: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis
[9] Update on pathogenesis, diagnosis, and treatment of atopic dermatitis in dogs: https://avmajournals.avma.org/view/journals/javma/254/11/javma.254.11.1291.xml

## 鉴别诊断

爪脱落因与多种病症的临床体征重叠而带来诊断挑战。创伤性损伤是最常见的鉴别诊断，其特征是不对称受累和特定事件史[1]。细菌感染通常表现为脓性渗出物和疼痛，可通过显示变性中性粒细胞和细菌的细胞学检查加以区分[2]。

对称性狼疮性爪营养不良（SLO）是一种关键的自身免疫性鉴别诊断，对称性影响多个爪，爪干燥、变形，可能自发脱落[3]。SLO主要影响德国牧羊犬、罗威纳犬和戈登塞特犬，表现为进行性爪营养不良而无系统性受累[3]。

落叶型天疱疮可引起爪床病变，特别是在猫中，爪褶周围明显化脓的"干酪样甲周炎"具有特征性[2]。与单纯爪脱落不同，落叶型天疱疮通常涉及其他身体部位，包括面部、耳朵和爪垫[4]。

鳞状细胞癌等肿瘤性疾病通常影响单个趾，而免疫介导性血管炎表现为紫癜和界限清晰的溃疡，同时影响耳廓、尾部和爪垫[4]。皮肤癣菌病和深部真菌感染需要真菌培养进行明确鉴别。

区分因素包括分布模式（对称性vs不对称性）、并发皮肤病变、品种易感性和经验性抗菌治疗的反应。组织病理学检查对于自身免疫性疾病的明确诊断仍然必不可少。

### Sources

[1] DVM 360 Pemphigus foliaceus: an overview: https://www.dvm360.com/view/pemphigus-foliaceus-an-overview
[2] DVM 360 Canine and feline pemphigus foliaceus: Improving your chances of a successful outcome: https://www.dvm360.com/view/canine-and-feline-pemphigus-foliaceus-improving-your-chances-successful-outcome
[3] DVM 360 A pivotal pedicure: Understanding SLO: https://www.dvm360.com/view/pivotal-pedicure-understanding-slo
[4] Merck Veterinary Manual Miscellaneous Diseases of the Pinna in Dogs and Cats - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/diseases-of-the-pinna/miscellaneous-diseases-of-the-pinna-in-dogs-and-cats
