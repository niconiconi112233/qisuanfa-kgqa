# 猫病毒性鼻气管炎：综合兽医指南

猫病毒性鼻气管炎（FVR）是影响全球猫的最重要呼吸道疾病之一，在猫群中的暴露率超过95%，近乎普遍。该病由猫疱疹病毒1型（FHV-1）引起，对幼年、未接种疫苗的猫以及收容所等高密度环境中的猫构成特殊风险。本报告系统性地探讨了FVR的临床表现、诊断方法和治疗策略。涵盖的关键领域包括有助于诊断的特征性树枝状角膜溃疡、在临床试验中显示出前景的新型抗病毒治疗，以及疫苗接种方案在疾病预防中的关键作用。了解FVR的终身携带状态和应激诱导的再激活模式对于有效的猫长期健康管理至关重要。

## 疾病概述与流行病学

猫病毒性鼻气管炎（FVR）是由猫疱疹病毒1型（FHV-1）引起的一种急性上呼吸道感染[1]。这种病毒性疾病是猫急性上呼吸道感染的最常见原因，占猫呼吸道疾病复合体中的大多数病例[1]。

FHV-1是一种大型有包膜的DNA病毒，已从全球临床患病猫中分离出来，通过血清中和试验证实了不同国家的病毒株相同[2]。该病毒呈全球分布，影响家猫和外来猫科动物[3,5]。专家认为全球超过95%的猫曾暴露于FHV-1，表明在猫群中近乎普遍暴露[1,5]。

该病主要影响幼年未接种疫苗的猫，最严重的感染通常发生在母体抗体消退后的幼猫（约9周龄）[4]。成年猫可能被感染，但如果之前接种过疫苗，通常临床表现轻微。收容所的猫由于居住环境密集和种群密度高而特别危险[1]。

传播通过气溶胶飞沫和受污染的物体（污染物）进行，可由处理人员传播给易感猫[1]。与其他呼吸道病原体相比，该病毒在环境中的存活时间相对较短[4]。感染猫在康复后可能携带并间歇性排毒数月，压力可能触发病毒再激活和继发疾病[1,3]。

### Sources
[1] Clinical trial underway for feline herpesvirus treatment in shelter cats: https://www.dvm360.com/view/clinical-trial-underway-for-feline-herpesvirus-treatment-in-shelter-cats
[2] Virologic and Immunologic Aspects of Feline Viral: https://avmajournals.avma.org/view/journals/javma/158/6/javma.1971.158.06.922.xml
[3] Feline Respiratory Disease Complex - Merck Veterinary Manual: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[4] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[5] Vaccination of Exotic Mammals - Merck Veterinary Manual: https://www.merckvetmanual.com/exotic-and-laboratory-animals/vaccination-of-exotic-mammals/vaccination-of-exotic-mammals

## 临床表现与诊断

猫病毒性鼻气管炎表现出独特的临床模式，有助于诊断。受感染猫通常会出现发热、厌食、从浆液性发展为黏液脓性的鼻分泌物、打喷嚏和眼部分泌物[1]。实验感染后的临床症状包括打喷嚏、眼鼻分泌物、下颌下淋巴结肿大和咳嗽[1]。

**典型临床症状**
最严重的感染发生在母体抗体消退后（约9周龄）的幼猫和幼年未接种疫苗的猫中[1]。FHV-1通常与角膜溃疡和角膜炎相关，树枝状溃疡被认为是该感染的特征性病变[3]。许多猫表现出流涎过多，可能发展为溃疡性和间质性角膜炎、角膜腐肉形成和前葡萄膜炎[1]。严重的咽炎可能是某些感染猫的唯一临床症状[3]。

**非典型表现**
FHV-1已成为疱疹性溃疡性皮炎的原因，表现为持续的面部和鼻部病变，可能类似于嗜酸性肉芽肿[3]。此外，该病毒还与慢性口炎、面部皮炎和内源性葡萄膜炎相关[5]。

**诊断方法**
诊断依赖于使用口咽、鼻和结膜拭子进行病毒分离，但由于FHV-1很脆弱，样本处理需谨慎[3]。PCR技术提供快速、敏感的检测，在已接种疫苗的猫或复发期间可能特别有用[3]。然而，解释需要结合临床背景，因为约25%的健康猫中可检测到FHV-1 DNA[5]。荧光抗体检测和直接观察树枝状角膜溃疡支持诊断，但由于疫苗干扰，不推荐血清学检测[3]。

### Sources
[1] Acute feline upper respiratory infection (Proceedings): https://www.dvm360.com/view/acute-feline-upper-respiratory-infection-proceedings
[3] Feline herpesvirus and calicivirus infections: What's new? (Proceedings): https://www.dvm360.com/view/feline-herpesvirus-and-calicivirus-infections-whats-new-proceedings
[5] Managing and preventing feline respiratory diseases (Proceedings): https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings

## 治疗方法与预防

现有内容全面涵盖了猫病毒性鼻气管炎的治疗选择和预防策略，有效综合了多个来源。当前章节已提供有关药物和非药物干预、支持性护理方法以及预防方案（包括疫苗接种计划和环境管理）的详细信息。

**支持性护理和氧疗**
对于经历严重呼吸困难的猫，可能需要在氧舱中进行氧疗[1]。液体疗法可用于纠正脱水，对于严重受影响的猫，需要通过注射器喂食或喂食管（鼻食管、鼻胃或食管造口）进行辅助喂食[1]。**广谱抗菌药物**对继发性细菌感染至关重要，有效选择包括头孢菌素、甲氧苄啶-磺胺、氟喹诺酮类、四环素和氯霉素[1]。

**高级治疗考虑**
**雾化疗法**或生理盐水滴鼻液有助于清除呼吸道顽固分泌物[1]。含有硫酸麻黄碱（0.25%溶液，每鼻孔两滴，每日两次）的血管收缩剂滴鼻液联合抗生素有助于减少鼻分泌物量[1]。对于FHV-1感染引起的角膜并发症，应每4小时涂抹含有**碘苷**、**三氟胸苷**或**阿糖腺苷**的局部抗病毒药膏[1]。

**疫苗接种方案更新**
改良活病毒FVR-FCV疫苗可用于鼻内和胃肠外给药[1]。对于9周龄以上的猫，接种包括间隔3周的两剂，而幼猫需要每3-4周接种一次，直到至少12周龄[1]。成年猫应每1-3年接种单剂加强疫苗[1]。

### Sources
[1] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Merck Veterinary Manual Feline Respiratory Disease Complex (Pet Owners): https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[3] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings

## 鉴别诊断与预后

**鉴别诊断**

猫病毒性鼻气管炎必须与其他引起相似临床症状的呼吸道病原体进行鉴别[1]。猫杯状病毒（FCV）是主要的鉴别诊断，通常表现为口腔溃疡，而非FHV-1特征性的结膜和鼻部受累[1,3]。然而，由于两种病原体可能引起相似的呼吸道症状，临床鉴别可能困难[1]。

猫衣原体通常产生严重结膜炎，鼻分泌物最少，与FHV-1显著的鼻部受累形成对比[1,3]。支气管败血波氏杆菌感染更可能引起咳嗽并可能导致肺炎，这与典型的FHV-1表现不同[3]。支原体属通常引起严重结膜水肿，与FHV-1相比鼻炎较不明显[1]。

**预后**

猫病毒性鼻气管炎的预后通常良好，死亡率通常较低[1]。大多数受感染猫在10-20天内自发康复，尽管轻度病例症状可能持续5-10天，严重病例可达6周[1]。一般来说，该病是自限性的，死亡非常罕见[1]。

幼猫和老年猫最容易患严重疾病，而短头品种面临慢性并发症的更高风险[1]。继发性细菌感染可能使康复复杂化，FHV-1可能导致长期鼻甲损伤，使猫易患慢性鼻炎[1]。所有感染猫都成为潜伏携带者，在压力期间可能再激活[1]。

### Sources
[1] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Feline Respiratory Disease Complex (Cat Owners): https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[3] Managing and preventing feline respiratory diseases: https://www.dvm360.com/view/managing-and-preventing-feline-respiratory-diseases-proceedings
