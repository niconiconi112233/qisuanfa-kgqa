# 复杂性冠根折

复杂性冠根折是伴侣动物中最严重的牙科创伤形式之一，其折裂线贯穿牙冠和牙根结构并直接暴露牙髓。这些疼痛的病症需要立即的兽医诊治，因为暴露的牙髓组织不可避免地会受到细菌污染，导致感染、脓肿形成以及潜在的牙齿脱落。

本报告探讨了这些复杂折裂背后的病理生理学，从初始创伤机制到疼痛通路激活和感染进展。包括牙科X光摄影和锥形束计算机断层扫描在内的先进诊断方法，对于正确的骨折分类和治疗计划至关重要。基于证据的治疗方法从成功率高达94%的根管治疗，到活髓治疗和牙冠修复。了解预防策略和鉴别诊断标准，使兽医能够为这些具有挑战性的病例提供最佳护理。

## 病理生理学与临床表现

复杂性冠根折代表严重的牙科创伤，其折裂线贯穿牙冠和牙根结构并直接暴露牙髓[1]。理解其潜在的病理生理学对于犬猫这些疼痛病症的适当临床管理至关重要。

**解剖学基础与折裂机制**

牙髓由结缔组织、神经、血管和成牙本质细胞组成，包含在牙髓腔和根管内[1]。在复杂性冠根折中，折裂线穿透保护性的牙釉质和牙本质层，直接将这个活组织暴露于口腔环境[1]。

这些折裂通常由外部创伤引起，如机动车事故或激烈玩耍，或由犬咬合不适当的硬物引起，包括真骨头、尼龙玩具、岩石或笼子栏杆[1]。裂齿产生的巨大咬合力，当被咬物体比牙齿结构本身更硬时，会导致牙齿折裂[1]。

**疼痛通路与临床表现**

复杂性折裂中的直接牙髓暴露通过急性阶段激活A-δ伤害感受器而引发剧烈疼痛[1]。随着牙髓坏死，这些伤害感受器也会坏死，但C型伤害感受器保持完整，传递钝痛和酸痛[1]。这种病理生理学解释了为什么许多牙折裂患者最初可能不会表现出明显的疼痛临床症状，因为它们的食欲通常保持不变[1]。

**感染进展与并发症**

当牙髓直接暴露于口腔环境时，细菌污染是不可避免的，导致牙髓炎并最终牙髓坏死[1]。随着感染向根尖方向进展，可导致根尖周疾病，包括骨炎、肉芽肿形成或脓肿发展[1]。这些并发症可能表现为面部肿胀、引流窦道（口腔瘘）或牙齿松动[6]。

感染通路通过根尖三角区延伸，在此处牙髓通过多个小孔而非单个开口与周围组织相连[1]。犬猫的这一解剖特征促进了感染向牙周韧带、根尖骨和血管系统的扩散。

### Sources
[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[6] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals

## 诊断方法

复杂性冠根折的全面诊断需要在全身麻醉下进行系统评估并结合先进的影像学技术[1]。诊断过程从全面的口腔检查开始，包括牙周探诊，应评估犬的正常龈沟深度为0-3毫米，猫为0.5-1毫米[1]。

牙科X光摄影是骨折评估的基石，要求拍摄全口口内影像，所有牙根尖周围有3毫米的可视化范围[1]。X光解读侧重于识别牙源性病变（LEO征象），包括根尖周透射区、增宽的牙周间隙和根管异常[1]。即使是非复杂性折裂在X光上也可能显示牙髓疾病，这强调了无论是否可见牙髓暴露，影像学检查都是至关重要的[7]。

锥形束计算机断层扫描（CBCT）与传统的牙科X光摄影相比，在评估异常萌出模式、根管形态和复杂折裂构型方面提供了更高的诊断效能[4]。评估标准包括使用美国兽医牙科学院系统进行折裂分类，该系统区分复杂性（牙髓暴露）和非复杂性（牙髓完整）冠根折[8,9]。

牙髓活力评估涉及用牙科器械仔细探查以确认牙髓暴露，这在猫犬齿中尤为重要，因为其牙髓腔几乎延伸至牙冠尖端[7]。临床检查应评估牙齿松动度、变色和相关软组织变化，因为面部肿胀常伴随复杂性上颌骨折裂[3]。

### Sources
[1] Day one core competencies in veterinary dentistry: https://avmajournals.avma.org/view/journals/javma/261/12/javma.23.05.0242.xml
[2] Evaluation of the diagnostic yield of dental radiography: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[3] The ABCs of veterinary dentistry: https://www.dvm360.com/view/the-abcs-of-veterinary-dentistry-when-waiting-is-wishful-thinking
[4] Dental Corner: Dental fracture treatment options: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[5] Examining new classifications of tooth fractures: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures
[6] Tooth fracture: Should you ever just wait and see: https://www.dvm360.com/view/tooth-fracture-should-you-ever-just-wait-and-see-proceedings

## 治疗选择

复杂性冠根折需要及时的治疗干预以保留牙齿功能并预防并发症。主要的治疗方式包括根管治疗（RCT）、活髓治疗（VPT）、拔牙和牙冠修复[1,2]。

**根管治疗**
RCT是治疗伴有牙髓暴露的复杂性冠根折的金标准。该程序涉及完全去除牙髓组织、根管系统的抗菌准备以及使用X光可检测的材料进行填充[3]。近期研究显示了极佳的结果，根管治疗在犬中的长期成功率达到94%[2]。该程序允许保留牙齿结构和功能，同时消除感染和相关疼痛。

**牙冠修复**
在牙髓治疗后，牙冠修复为结构受损的牙齿提供额外保护。与陶瓷替代品相比，金属冠提供了卓越的耐用性，在工作犬中，19个牙冠中有17个在32个月的随访中保持完整和功能[1]。修复过程包括牙冠预备、取模和使用树脂粘固剂进行粘接就位。

**活髓治疗**
VPT是年轻动物急性损伤的替代治疗选择。该程序涉及去除病变的冠部牙髓同时保留活组织，随后放置矿物三氧化物凝聚体和复合修复体[1]。如果在损伤后48小时内进行，成功率可达80%，但超出此时间范围后效果会显著下降[4]。

**拔牙**
当由于广泛的牙周疾病、经济限制或治疗失败而无法进行牙髓治疗时，手术拔牙仍然是适应症[2]。

### Sources
[1] Dental Corner: Dental fracture treatment options in dogs and cats: https://www.dvm360.com/view/dental-corner-dental-fracture-treatment-options-dogs-and-cats
[2] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[3] Endodontic Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
[4] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.xml

## 预防与鉴别诊断

### 预防策略

预防复杂性冠根折涉及减少创伤暴露[1]。建议避免硬质咀嚼物体有助于预防牙齿折裂[2]。有分离焦虑的动物在关在笼子里时经常折裂牙齿，因此适当的行为管理至关重要[2]。在牙齿挺出前去除足够的颊骨并在牙科手术中使用锋利的器械可预防医源性折裂[1]。

上颌和下颌犬齿通常最容易折裂，其次是切牙和上颌第四前臼齿[3]。折裂的犬齿和切牙通常由剧烈玩耍或事故的创伤引起，而前臼齿和臼齿则由咬合创伤引起[2]。提供转诊行为学专家的选择并谨慎选择关押方式有助于减少牙科折裂[2]。

### 鉴别诊断

必须将复杂性冠根折与其他影响牙冠和牙根结构的牙科疾病区分开来[4]。单纯的牙周病表现为无牙齿结构损伤，而复杂性折裂则显示牙髓暴露，牙冠中心有红色或黑色斑点[5]。非复杂性折裂涉及牙釉质或牙本质而无牙髓暴露[4]。

牙齿变色可能表明牙髓疾病而非折裂，87-92%的内源性染色牙齿是无活力的[5]。拔牙期间的根折与复杂性冠根折不同，因为它们影响牙龈线以下的残留牙根碎片[1]。X光评估有助于区分折裂模式和影响治疗决策的并发牙周病[3]。

### Sources

[1] Six common pitfalls in veterinary dentistryand how to avoid them: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them
[2] Feeling the bite of the economic downturn?: https://www.dvm360.com/view/feeling-bite-economic-downturn
[3] F is for fractured teeth: https://www.dvm360.com/view/f-is-for-fractured-teeth
[4] Examining new classifications of tooth fractures - dvm360: https://www.dvm360.com/view/examining-new-classifications-tooth-fractures
[5] Endodontic Disease in Small Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/endodontic-disease-in-small-animals
