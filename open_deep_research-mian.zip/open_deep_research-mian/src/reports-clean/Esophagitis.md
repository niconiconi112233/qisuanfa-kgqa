# 伴侣动物食管炎

食管炎在兽医实践中代表一种重要但常常诊断不足的疾病，通过多种机制影响犬和猫，包括胃食管反流、异物创伤和药物引起的损伤。这种食管黏膜的炎症状况可从轻度刺激发展为严重并发症，包括狭窄形成和吸入性肺炎。本报告探讨了从麻醉相关的酸反流到猫体内多西环素引起的化学烧伤的复杂病因学，同时探讨了导致诊断不足的诊断挑战。治疗策略包括酸抑制方案、狭窄的球囊扩张技术，以及针对高风险操作和药物给药实践的预防措施。

## 疾病概述

食管炎被定义为食管黏膜的炎症，可从轻度刺激到严重溃疡和糜烂不等[1]。这种情况在伴侣动物医学中代表一个重要的临床问题，影响犬和猫，尽管在犬中可能更常见地被识别[1]。

流行病学背景显示，食管炎可能比兽医从业者通常认识到的更为常见[1,2]。急性食管炎的报告患病率在临床文献中似乎较低，但这可能代表了低估，因为与该疾病相关的临床症状和放射学发现具有隐匿性[1]。许多病例可能未被诊断，因为食管炎在没有内镜检查的情况下很难被发现[2]。

与猫相比，犬因食管疾病（包括食管炎）就诊更为频繁[1]。然而，猫科动物患者可能因该物种临床症状被忽视而导致诊断不足[1]。猫特别容易发生药物性食管炎，尤其是由多西环素和克林霉素等药物引起[1,2]。年轻至中年患者最容易摄入腐蚀性物质，从而导致食管炎[3]。

短头颅品种犬的消化道病变（包括食管炎）患病率增加，高达97%的短头颅犬存在食管、胃或十二指肠异常[4,5]。中国沙皮犬易患先天性食管裂孔疝，这可导致反流性食管炎[6]。

### Sources
[1] Diseases of the esophagus (Proceedings): https://www.dvm360.com/view/diseases-esophagus-proceedings
[2] Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats
[3] Disorders of the esophagus (Proceedings): https://www.dvm360.com/view/disorders-esophagus-proceedings
[4] Vocal fold granuloma associated with brachycephalic airway syndrome: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0825.xml
[5] Postoperative regurgitation and respiratory complications in brachycephalic dogs: https://avmajournals.avma.org/view/journals/javma/256/8/javma.256.8.899.xml
[6] Regurgitation, dysphagia, and esophageal dysmotility (Proceedings): https://www.dvm360.com/view/regurgitation-dysphagia-and-esophageal-dysmotility-proceedings

## 病因学和病理生理学

伴侣动物的食管炎由多种病因因素引起，这些因素通过独特的病理生理机制导致黏膜炎症[1]。最常见的原因是胃食管反流（GER），特别是在全身麻醉期间，当下食管括约肌松弛时，胃酸、胃蛋白酶和胆汁接触脆弱的食管黏膜[2,3]。与胃不同，食管缺乏保护性黏液-碳酸氢盐屏障和前列腺素防御，使其易受酸-肽性损伤[2]。

异物代表另一个重要原因，尤其是在小型犬中，骨头、玩具和尖锐物体通过压迫性坏死、撕裂或穿孔造成机械性创伤[2,4]。药物性食管炎在服用多西环素或克林霉素片剂而没有充分饮水的猫中经常发生，导致食管长时间接触和化学损伤[1,4]。

病理生理学涉及一个破坏性循环，其中初始黏膜损害损害食管运动和下食管括约肌功能[2]。这种功能障碍持续胃食管反流，形成加剧炎症的正反馈循环。严重的食管炎超出黏膜范围延伸至肌层，通过壁内纤维化愈合导致环形狭窄和狭窄形成[4]。其他原因包括持续性呕吐、腐蚀性物质摄入、过热食物引起的热损伤，以及罕见的感染因子如腐霉属[4,6]。

从急性炎症到慢性并发症的进展取决于损伤的深度和持续时间，深部环形损伤最可能导致需要治疗干预的功能性显著狭窄。

### Sources

[1] Disorders of the Esophagus in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-esophagus-in-cats

[2] Diagnosing and treating esophageal diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-esophageal-diseases-dogs-and-cats-proceedings

[3] Esophageal foreign bodies, esophagitis and strictures (Proceedings): https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings

[4] Esophagitis and esophageal stricture (Proceedings): https://www.dvm360.com/view/esophagitis-and-esophageal-stricture-proceedings

[5] Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats

[6] Esophageal disease (Proceedings): https://www.dvm360.com/view/esophageal-disease-proceedings

## 临床症状和体征

**典型临床症状**

食管炎的主要临床症状是反流，必须与呕吐区分开来[1]。与呕吐不同，反流是一个被动过程，没有前驱症状如舔唇、焦虑或干呕[2]。临床症状通常在麻醉操作或黏膜损伤后1-3天出现[3]。

其他体征包括吞咽困难（伴随头颈伸展的吞咽困难）、吞咽疼痛（疼痛性吞咽）、过度流涎、干呕和反复吞咽尝试[3]。在轻度病例中，体征可能轻微或不存在，非特异性嗜睡、厌食和模糊不适可能先于反流出现[3]。

**体格检查发现**

体格检查可能显示身体状况不佳，如果存在吸入性肺炎则可能出现发热[2]。在继发于食管炎的巨食症患者中，左侧腹侧颈部区域可能发生动态扩张[2]。肺部爆裂音表明吸入性肺炎，这是一种严重并发症[2]。发现口咽刺激与食管炎并存提示腐蚀性物质摄入[3]。

**非典型表现**

食管炎在并发症发生之前可能在临床上无症状[4]。当继发于慢性呕吐时，表现可能令人困惑，因为呕吐和反流同时发生[2]。一些动物可能因无法保留食物而食欲旺盛[2]。

### Sources

[1] Esophageal disease (Proceedings): https://www.dvm360.com/view/esophageal-disease-proceedings
[2] Esophagitis and esophageal stricture (Proceedings): https://www.dvm360.com/view/esophagitis-and-esophageal-stricture-proceedings
[3] Esophageal foreign bodies, esophagitis and strictures (Proceedings): https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings
[4] Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats

## 治疗策略和管理

小动物食管炎的有效管理需要多方面方法，包括酸抑制、黏膜保护、运动增强和营养支持[1][2][3]。主要治疗目标是消除胃酸暴露以促进食管黏膜愈合，同时解决根本原因。

**酸抑制治疗**
质子泵抑制剂（PPIs）代表食管炎治疗的金标准。奥美拉唑（1.0 mg/kg PO q24h）提供比组胺-2受体拮抗剂更优越的胃酸抑制[1][3]。对于麻醉相关的胃食管反流预防，应在麻醉诱导前18-24小时和4小时再次给予奥美拉唑[2]。替代性H2受体拮抗剂包括法莫替丁（0.5 mg/kg PO q12h）或雷尼替丁（1-2 mg/kg PO q12h），尽管这些药物不如PPIs有效[3]。

**促动力和黏膜保护剂**
甲氧氯普胺（0.2-0.4 mg/kg PO q8h）通过增加下食管括约肌压力增强胃排空并减少胃食管反流[2][3]。硫糖铝混悬液（0.5-1.0 g PO TID）通过选择性结合受损食管组织提供黏膜屏障保护，尽管其在非酸性食管环境中的功效可能有限[3]。

**手术干预和球囊扩张**
食管狭窄需要机械干预，球囊导管扩张代表首选治疗方式[5][6]。通常需要进行间隔2-3天的多次扩张程序，当由经验丰富的从业者执行时，成功率超过80%[3]。应尽可能避免食管手术，因为愈合特性差且并发症发生率高[3]。

**营养管理和饲管支持**
饮食调整包括频繁少量喂食柔软、易消化的食物。需要长期营养支持的严重病例受益于食管造口管置入[4]。与胃造口管相比，这些管允许给予混合饮食和药物，同时最小化麻醉时间和并发症[4]。

### Sources
[1] Gastric ulcers: a pain in the gut! (Proceedings): https://www.dvm360.com/view/gastric-ulcers-pain-gut-proceedings
[2] Gastrointestinal motility disorders caused by esophageal disease: https://www.dvm360.com/view/gastrointestinal-motility-disorders-caused-by-esophageal-disease
[3] Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats
[4] Surgery STAT: Don't forget nutrition! Placing esophagostomy tubes in cats: https://www.dvm360.com/view/surgery-stat-dont-forget-nutrition-placing-esophagostomy-tubes-cats
[5] Esophageal Strictures in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophageal-strictures-in-small-animals
[6] Esophageal strictures in cats and dogs: Signs, causes and treatment: https://www.dvm360.com/view/esophageal-strictures-cats-and-dogs-signs-causes-and-treatment

## 预防和预后

**预防措施**

食管炎的预防中心在于避免易感风险因素和实施适当的麻醉方案。全身麻醉期间的胃食管反流代表最重要的可预防的食管狭窄原因，占犬和猫病例的65%[1]。术前给予质子泵抑制剂（麻醉前18-24小时和4小时给予奥美拉唑）可减轻反流严重程度[2]。

适当的药物给药技术至关重要，特别是在猫中。多西环素和克林霉素片剂应始终跟随饮水给药，以防止食管滞留和随后的化学损伤[1][3]。环境管理包括限制接触腐蚀性物质并为已知食管疾病患者维持适当的喂养实践。

**预后和预期结果**

食管炎的预后因严重程度和根本原因而有显著差异[4]。轻度食管炎可能不需要治疗并自行消退。然而，严重食管炎存在严重并发症风险，包括食管坏死、穿孔和狭窄形成[1]。

食管狭窄的发展代表一个主要的预后关注点，在12-24%的中度至重度异物性食管炎病例中发生[1]。球囊扩张治疗在70-88%的狭窄患者中取得良好结果，尽管通常需要多次程序[6]。球囊操作的中位次数范围为2-4次，一些患者需要多达10次或更多次扩张[1]。

吸入性肺炎仍然是食管疾病患者发病率和死亡率的主要原因[4]。早期识别和积极治疗基础食管疾病和相关并发症显著影响整体预后。

### Sources
[1] DVM 360 Esophagitis and esophageal stricture (Proceedings): https://www.dvm360.com/view/esophagitis-and-esophageal-stricture-proceedings
[2] DVM 360 Recognizing and treating esophageal disorders in dogs and cats: https://www.dvm360.com/view/recognizing-and-treating-esophageal-disorders-dogs-and-cats
[3] Merck Veterinary Manual Esophagitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-esophagus-in-small-animals/esophagitis-in-small-animals
[4] Merck Veterinary Manual Disorders of the Esophagus in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-esophagus-in-dogs
[5] DVM 360 Diagnosing and treating esophageal diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-esophageal-diseases-dogs-and-cats-proceedings
[6] DVM 360 Esophageal foreign bodies, esophagitis and strictures (Proceedings): https://www.dvm360.com/view/esophageal-foreign-bodies-esophagitis-and-strictures-proceedings
