# 犬猫难产：综合临床指南

难产，定义为分娩困难或无法通过产道排出胎儿，是一种重要的生殖系统急症，影响约5%的犬猫妊娠，在某些短头颅品种中发生率接近100%。本综合指南探讨了涉及母体子宫无力、解剖异常和胎儿胎位异常的多因素病因，这些因素会损害正常分娩。报告涵盖了利用临床评估和影像学技术的基本诊断方法、基于证据的治疗方案（包括更新的催产素给药指南）、剖腹产的手术指征，以及优化小动物临床实践中母体和新生儿结局的预防性繁殖管理策略。

## 疾病概述与流行病学

难产被定义为分娩困难或无法在没有帮助的情况下通过产道排出胎儿[1]。母犬或母猫难产的总发生率约为妊娠的5%，但在某些品种中可能接近100%，特别是软骨发育不全和短头颅类型[2]。

易感因素分为母体和胎儿原因。品种易感性显著影响难产风险，斗牛犬、哈巴狗、波士顿梗、吉娃娃、波斯猫和暹罗猫风险较高[2]。小型犬通常表现出更高的易感性[3]。

难产可分为原发性或继发性。原发性子宫无力是由于子宫无法对胎儿信号做出反应，原因包括刺激不足、大胎数或过大胎儿导致的过度拉伸、遗传易感性或年龄相关变化[2]。继发性子宫无力是由于产道阻塞导致的子宫肌层耗竭所致[2]。

其他易感因素包括既往骨折导致的骨盆道狭窄、未成熟、先天性畸形、初产动物的心理压力，以及胎儿原因如胎位异常或胎儿发育异常[2]。

### Sources

[1] Clinical Investigation of Canine Reproduction Disorders: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/clinical-investigation-of-canine-reproduction-disorders
[2] Dystocia in Small Animals - Reproductive System: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/dystocia-in-small-animals
[3] Eclampsia in Small Animals - Metabolic Disorders: https://www.merckvetmanual.com/metabolic-disorders/disorders-of-calcium-metabolism/eclampsia-in-small-animals

## 病因学与病理生理学

伴侣动物难产是由损害正常分娩的母体和胎儿因素之间复杂相互作用引起的[1]。理解这些潜在机制对于最佳临床管理至关重要。

**母体原因**

子宫无力是难产最常见的母体原因，约占所有病例的60%[1][2]。原发性子宫无力是指子宫肌层从分娩开始时无法产生足够收缩，通常是由于胎儿信号不足、大胎数导致的过度拉伸或内在肌层功能障碍[2]。继发性子宫无力在初始正常收缩停止后发展，通常是由于阻塞性难产导致的肌层耗竭[2]。

解剖异常显著促成阻塞性难产。既往骨折、先天性畸形或品种特异性结构问题导致的骨盆道异常创造了胎儿通过的机械屏障[2]。阴道狭窄和软组织异常进一步损害产道[3]。

全身因素包括低钙血症、低血糖和母体疾病，可通过影响细胞收缩机制诱发子宫功能障碍[1][4]。

**胎儿原因**

胎儿胎位异常和胎势异常约占难产病例的15%[4]。常见表现包括后肢屈曲的臀先露、头部侧偏和横向胎位[2]。胎儿过大，特别是在单胎妊娠中，造成与母体骨盆的大小不匹配[3][4]。

先天性胎儿异常如脑积水、全身水肿和骨骼畸形可机械性阻碍分娩[2]。胎儿死亡通过消除正常定位反射并允许异常胎位发展而增加难产风险[1]。

### Sources
[1] Diagnosing and managing canine dystocia: https://www.dvm360.com/view/diagnosing-and-managing-canine-dystocia-proceedings
[2] Dystocia in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/dystocia-in-small-animals
[3] Dystocia: Medical and surgical management: https://www.dvm360.com/view/dystocia-medical-and-surgical-management-proceedings
[4] Problems of pregnancy and parturition: https://www.dvm360.com/view/problems-pregnancy-and-parturition-proceedings

## 临床识别与诊断方法

难产诊断依赖于识别特定临床症状和使用适当的诊断技术[1]。临床症状包括收缩无力或缺失、新生儿之间间隔延长（幼犬之间超过4小时）、强烈收缩超过30分钟而未排出胎儿，以及24小时内未能从第一产程进展到第二产程[1][2]。其他指标包括异常阴道分泌物，特别是分娩前出现深绿色或有异味的分泌物，这可能表示胎盘分离[2]。

体格检查应包括使用无菌技术进行阴道指检以检测阻塞并确定胎儿胎位[2]。腹部触诊可估计胎儿数量并评估子宫收缩[2]。

**诊断影像学对于全面评估至关重要。** 三视图腹部X线片（侧位和腹背位）是准确计数剩余胎儿和筛查阻塞所必需的[1]。X线片能正确确定93%的犬妊娠中的胎儿数量，而单独超声检查的准确率仅为36%[1]。然而，超声在评估胎儿生存能力和窘迫方面更优越[1][3]。正常胎儿心率在犬中应超过180次/分钟，总体为200-250次/分钟[1][2]。心率低于150-180次/分钟表示胎儿窘迫，需要紧急干预[1][3]。

实验室评估应包括全血细胞计数、血清生化和钙水平，以识别促成因素[3]。

### Sources
[1] Managing dystocia with surgery: https://www.dvm360.com/view/managing-dystocia-with-surgery
[2] Dystocia in Small Animals - Reproductive System: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/dystocia-in-small-animals
[3] Diagnosing and managing canine dystocia (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-canine-dystocia-proceedings

## 治疗策略

难产治疗需要系统方法，结合药物治疗、手动技术和有指征时的手术干预。治疗选择取决于识别根本原因、评估母体和胎儿状态以及排除阻塞性疾病[1]。

### 药物治疗
对于原发性子宫无力，催产素给药是药物治疗的基石。现有证据支持比历史上推荐的更低剂量：每20-30分钟肌肉注射0.25-5单位，如果无效则不超过三剂[1]。基于体重的剂量范围从5公斤以下犬0.25单位到30公斤以上犬3-5单位[4]。较高剂量可能导致子宫强直并损害胎盘血流[4]。

葡萄糖酸钙（10%）以0.5-1.5 mL/kg皮下给药可增强子宫收缩强度，并在催产素前10分钟给药时发挥协同作用[1]。即使血钙正常的母犬也可能从钙补充中受益[2]。

### 手术干预
剖腹产的指征包括阻塞性难产、药物治疗失败、胎儿窘迫（心率<180次/分钟）或剩余胎儿超过两个[1][8]。术前准备包括液体复苏和电解质异常纠正[6]。手术技术涉及腹中线入路，小心处理子宫以防止血管撕脱[6]。

### 新生儿护理
分娩后即刻护理包括清理气道、彻底擦干和脐带结扎。多沙普仑（1-5毫克皮下注射）可刺激受损新生儿的呼吸[8]。早期葡萄糖补充可预防低温-低血糖综合征[8]。

### Sources
[1] Merck Veterinary Manual Dystocia in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/dystocia-in-small-animals
[2] Merck Veterinary Manual Labor and Delivery: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/labor-and-delivery-in-dogs-and-cats
[3] Managing dystocia with surgery: https://www.dvm360.com/view/managing-dystocia-with-surgery
[4] Use lower doses of oxytocin for dystocia: https://www.dvm360.com/view/practical-matters-use-lower-doses-oxytocin-dystocia
[5] Letters on dystocia management: https://www.dvm360.com/view/letters-few-clarifications-dystocia-management
[6] Cesarean section techniques: https://www.dvm360.com/view/cesarean-section-dogs-indications-techniques
[7] Medical and surgical management: https://www.dvm360.com/view/dystocia-medical-and-surgical-management-proceedings
[8] WSAVA proceedings on dystocia: https://www.vin.com/apputil/content/defaultadv1.aspx?id=4516345&pid=11310

## 预防与鉴别诊断

现有章节内容提供了难产预防措施和鉴别诊断的全面概述。根据原始资料，我可以通过额外具体的繁殖管理和诊断考虑信息来增强这部分内容。

### 增强的预防措施

难产预防以繁殖前评估和负责任繁殖实践为中心。繁殖能力检查应包括阴道指检以识别可能干扰交配和分娩的前庭阴道狭窄[1]。在前庭阴道连接处发现的狭窄是先天性异常，需要繁殖前修复或计划剖腹产[1]。

繁殖前筛查至关重要，特别是犬的*犬布鲁氏菌*[1]。母犬应在每个繁殖周期前进行筛查，而种公犬需要年度检测以维持无布鲁氏菌病的繁殖环境[1]。

繁殖前适当的营养和身体状况优化可提高受孕率和分娩结局[1]。繁殖者应避免不必要的钙补充，这会诱发子痫[1]。核心疫苗应是最新的，但不建议在繁殖前立即重新接种，除非疫苗接种状态不足[1]。

### 增强的鉴别诊断

几种情况可能模拟难产表现。主要鉴别包括正常延长分娩与真正难产，这需要仔细评估胎儿心率和子宫收缩[2]。正常胎儿心率范围为200-250次/分钟，低于200表示窘迫[2]。

必须通过影像学区分子宫无力和阻塞性难产[2]。完全性原发性子宫无力表现为尽管足月妊娠但未能启动分娩，而部分性子宫无力涉及在排出一些新生儿后停止[2]。

其他需要鉴别的生殖系统急症包括阴道脱垂、子宫扭转和阴道狭窄。这些情况可能表现出相似的努责行为，但需要不同的管理方法，并可通过指检和影像学研究进行区分。

### Sources
[1] Merck Veterinary Manual: Breeding Management of Dogs and Cats: https://www.merckvetmanual.com/management-and-nutrition/management-of-reproduction-dogs-and-cats/breeding-management-of-dogs-and-cats
[2] Merck Veterinary Manual: Dystocia in Small Animals: https://www.merckvetmanual.com/reproductive-system/reproductive-diseases-of-the-female-small-animal/dystocia-in-small-animals
