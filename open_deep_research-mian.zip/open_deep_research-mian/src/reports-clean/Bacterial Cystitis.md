# 伴侣动物的细菌性膀胱炎

细菌性膀胱炎是影响犬类的最常见传染病，患病率为14%，而在猫中则显著少见。这种尿路感染通过特征性下泌尿道体征引起严重不适，包括频繁排尿、疼痛和血尿。该病主要由上行性细菌感染引起，其中大肠杆菌（*Escherichia coli*）占所有病例的近一半。了解细菌性膀胱炎对兽医从业者至关重要，因为正确的诊断和治疗方法已随着当前指南的强调而显著发展，这些指南提倡更短的抗生素疗程和抗菌药物管理。本报告探讨了细菌性膀胱炎的基本方面，从病原体识别和临床表现到现代诊断方法和循证治疗方案，这些方案优化了患者治疗效果，同时应对日益增长的抗菌素耐药性问题。

## 疾病概述

细菌性膀胱炎被定义为尿路细菌感染，其特征是膀胱黏膜炎症和下泌尿道疾病的临床症状[1]。这种疾病是犬类最常见的传染病，影响14%的犬类，而在猫中则显著少见[4]。

流行病学模式显示出明显的物种差异。在猫中，细菌性尿路感染（UTI）在幼年动物中不常见，由于其复杂的尿路防御系统，仅有1%至3%的猫在一生中会患病[3]。然而，在老年猫中，特别是患有糖尿病、慢性肾病或甲状腺功能亢进等并发疾病的猫，发病率显著增加[4]。

几个风险因素使动物易患细菌性膀胱炎。在猫中，代谢疾病、年龄增长和雌性是重要风险因素[3]。犬在宿主防御机制受损、解剖异常或全身性免疫抑制时表现出更高的易感性[1]。导尿和排尿不完全等环境因素也增加了感染风险[1]。

当正常的皮肤和胃肠道菌群上行至尿路并克服通常阻止细菌定植的自然防御机制时，通常会导致该病发生[4]。了解这些流行病学模式对适当的诊断和管理策略至关重要。

### Sources

[1] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings
[2] Subclinical bacteriuria is nonprogressive but persistent in ...: https://avmajournals.avma.org/view/journals/javma/262/12/javma.24.07.0439.xml
[3] Diagnosing and treating urinary tract infection in cats: https://www.dvm360.com/view/lecture-link-diagnosing-and-treating-urinary-tract-infection-cats
[4] Pharmacotherapeutics in Bacterial Urinary Tract Infections ...: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals

## 常见病原体

犬和猫的细菌性膀胱炎由特定的尿路病原体引起，这些病原体具有不同的流行模式和特征。**大肠杆菌（*Escherichia coli*）**是主要病原体，约占犬尿路感染的45%，占两个物种所有细菌分离株的一半以上[1][2]。这种革兰氏阴性杆菌通过专门的黏附因子表现出特殊的毒力，增强了其对尿路上皮的黏附[8]。

**葡萄球菌属（*Staphylococcus* species）**是第二大常见细菌原因，约占犬UTI的10%[2]。这些革兰氏阳性球菌，特别是假中间葡萄球菌（*Staphylococcus pseudintermedius*），通常产生β-内酰胺酶和脲酶，导致尿液pH值升高[8]。**变形杆菌属（*Proteus* species）**也约占感染的10%，其特征是强效脲酶产生[1][2]。

其他重要病原体包括犬中的**克雷伯氏菌属（*Klebsiella*）（约10%）、肠球菌属（*Enterococcus*）（约5%）和链球菌属（*Streptococcus*）（约5%）**[2]。在猫中，病原体谱略有不同，以大肠杆菌、肠球菌、凝固酶阴性葡萄球菌和变形杆菌最为常见[3]。

最近的研究表明，25%的培养阳性标本含有多种细菌，特别是在复发性感染中[1]。新兴关注点包括解尿素棒状杆菌（*Corynebacterium urealyticum*），这是一种生长缓慢、分解尿素的微生物，会形成结晶性结痂，使根除变得困难[3]。

### Sources
[1] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings
[2] Therapeutic caveats: Difficult urinary tract infections: https://www.dvm360.com/view/therapeutic-caveats-difficult-urinary-tract-infections
[3] Resistant urinary tract infections (Proceedings): https://www.dvm360.com/view/resistant-urinary-tract-infections-proceedings
[8] Managing routine and difficult urinary tract infections in dogs (Proceedings): https://www.dvm360.com/view/managing-routine-and-difficult-urinary-tract-infections-dogs-proceedings

## 临床症状和体征

细菌性膀胱炎表现出特征性的下泌尿道体征，在犬和猫中表现一致。主要临床表现包括尿频（pollakiuria）、排尿困难（dysuria）、排尿费力（stranguria）、血尿（hematuria）、不当排尿（periuria）和尿失禁[1][2]。

这些体征是由膀胱壁炎症引起的，代表了尿路对细菌侵害的有限反应模式[2]。炎症级联反应导致组织损伤并刺激痛觉纤维，导致受影响动物出现特征性不适和排尿模式改变。

**物种特异性模式**

犬和猫表现出相似的临床表现，尽管存在一些显著差异。雌性犬由于尿道较短且距离肛门较近而风险增加[1]。在猫中，细菌性UTI在幼年动物（<10岁）中不常见，不到2%的患有下泌尿道体征的幼年猫被确诊为细菌感染[2][4]。然而，老年猫（≥10岁）的UTI率显著更高，特别是患有甲状腺功能亢进、糖尿病或慢性肾病等并发疾病的猫[2][4]。

一些患有菌尿的动物可能没有表现出临床症状，这种情况称为亚临床菌尿[1][3]。这种无症状表现在猫中更常见，通常不需要治疗，除非存在特定的风险因素[2]。

### Sources
[1] Bacterial Cystitis in Small Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals
[2] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals
[3] Overview of Infectious Diseases of the Urinary System in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/overview-of-infectious-diseases-of-the-urinary-system-in-small-animals
[4] Problem urinary tract infections (Proceedings): https://www.dvm360.com/view/problem-urinary-tract-infections-proceedings

## 诊断方法

细菌性膀胱炎的诊断需要在出现下泌尿道体征的患者中确认菌尿[1]。全面的诊断方法包括临床评估、实验室检查以及必要时进行的影像学检查。

**临床评估**
通过详细病史记录临床症状及其频率对细菌性膀胱炎的分类至关重要[1]。体格检查应包括直接观察排尿和评估外生殖器形态，特别是在复发性感染病例中[8]。

**实验室检查**
尿液分析和尿沉渣检查代表最低诊断要求[1]。尿液样本应理想地通过膀胱穿刺术收集以最小化污染[1]。显微镜检查发现菌尿可预测阳性培养结果，仅有3.4%的无活性沉渣产生阳性培养[1]。尿液试纸的白细胞部分在小动物中不准确，不应使用[1]。

定量尿培养仍是诊断的金标准[1]。膀胱穿刺样本的细菌生长≥1,000 CFUs/mL表示具有临床相关性的菌尿[1]。虽然培养是所有病例的理想选择，但特别推荐用于复发性感染、有下泌尿道体征的猫以及经验性治疗失败时[1,8]。

**影像学检查**
影像学检查适用于复发性病例以评估潜在原因[8]。超声检查优于放射检查，在检测尿石方面假阴性率分别为6%和27%[8]。膀胱镜检查是评估复发性感染的最终诊断步骤，当其他方法无法明确时使用[8]。

### Sources
[1] Bacterial Cystitis in Small Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals
[8] Updates in management of urinary tract infections in small animal medicine: https://www.dvm360.com/view/updates-in-management-of-urinary-tract-infections-in-small-animal-medicine

## 治疗选择

当前兽医指南强调对犬和猫的散发性细菌性膀胱炎采用**短疗程抗菌药物治疗**。对于无并发症病例，推荐**3-5天的治疗时间**，这代表了从传统较长疗程的重大转变[1]。在大多数地区，阿莫西林和甲氧苄啶-磺胺类药物作为合理的经验性一线选择。

**抗生素选择**应优先考虑能在尿液中达到高浓度的药物。尽管体外耐药性结果，阿莫西林由于在尿液中达到极高浓度，对散发性膀胱炎仍然有效[1][3]。**氟喹诺酮类和第三代头孢菌素等关键抗菌药物应保留**用于培养和药敏确认的病例[1]。

**复发性细菌性膀胱炎**需要4-6周的治疗时间，**怀疑肾脏或前列腺感染时推荐6-8周**[5]。治疗应基于尿培养结果，通过治疗开始后3-5天的随访培养进行监测[4][5]。

**支持性护理措施**包括解决潜在的易感因素，如解剖异常、免疫抑制或并发疾病。对于耐药感染，替代方案包括氨基糖苷类、氯霉素或呋喃妥因，但这些需要密切监测不良反应[4]。

**随访评估**包括治疗完成后5-7天的治疗后尿培养，以确认微生物学治愈[1]。然而，如果在散发性病例中经验性治疗后临床症状消失，则不需要进行随访检测。

### Sources
[1] Bacterial Cystitis in Small Animals - Urinary System: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals
[2] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals
[3] Resistant urinary tract infections (Proceedings): https://www.dvm360.com/view/resistant-urinary-tract-infections-proceedings
[4] Diagnosing and managing recurrent urinary tract infections (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-recurrent-urinary-tract-infections-proceedings

## 预防措施

犬和猫细菌性膀胱炎的预防侧重于识别和管理损害宿主防御机制的易感因素[1]。患有复发性细菌性膀胱炎的患者需要彻底的诊断评估，以评估复发原因和再感染风险因素，包括解剖异常、代谢疾病和免疫抑制状况[1]。

关键的预防策略包括纠正尿失禁、通过外阴成形术解决凹陷外阴等解剖缺陷，以及管理糖尿病或肾上腺皮质功能亢进等基础疾病[1][4]。环境管理起着关键作用，特别是保持适当的猫砂盒卫生和减少多宠物家庭中的压力[2]。

对于猫，通过多模式环境改造（MEMO）减轻压力已被证明能有效减少下泌尿道体征[7]。这包括实施健康猫环境的五大支柱：提供充足的资源、安全空间、可预测的日常、积极的人猫互动以及尊重猫的感官需求[7]。多个猫砂盒（每只猫一个加一个额外），每日清理、无香型猫砂以及远离压力源的战略性放置至关重要[8]。

饮食调整是预防的基石，高水分含量是主要管理策略[3][6]。虽然蔓越莓提取物通过抑制细菌对尿路上皮的黏附在预防再感染方面显示出前景，但益生菌、D-甘露糖和口服糖胺聚糖的证据仍然有限[1][4]。脉冲抗生素治疗由于潜在的耐药性发展仍然存在争议。

### Sources
[1] Bacterial Cystitis in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals
[2] Managing recurrent UTIs in pets: https://www.dvm360.com/view/managing-recurrent-utis-pets
[3] Management of refractory inflammatory feline lower urinary tract disease (Proceedings): https://www.dvm360.com/view/management-refractory-inflammatory-feline-lower-urinary-tract-disease-proceedings-1
[4] How to manage recurrent urinary tract infections: https://www.dvm360.com/view/how-to-manage-recurrent-urinary-tract-infections
[5] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[6] Management of refractory inflammatory feline lower urinary tract disease (Proceedings): https://www.dvm360.com/view/management-refractory-inflammatory-feline-lower-urinary-tract-disease-proceedings-0
[7] Feline idiopathic cystitis: https://www.dvm360.com/view/feline-idiopathic-cystitis
[8] Feline elimination disorders (Proceedings): https://www.dvm360.com/view/feline-elimination-disorders-proceedings

## 鉴别诊断

细菌性膀胱炎必须与几种具有重叠临床症状的疾病进行鉴别。在10岁以下的猫中，特发性膀胱炎占下泌尿道体征的60-70%，而细菌性UTI发生在不到2%的病例中[1]。然而，10岁以上的猫细菌感染率显著高于50%[1]。

关键鉴别因素包括年龄、临床表现和诊断结果。猫特发性膀胱炎通常影响主要食用干粮的年轻到中年室内猫，体征通常在7天内自行缓解[2]。诊断需要排除细菌性UTI、尿石症、肿瘤和解剖异常[2]。

尿石症表现出相似的刺激性排尿体征，但可通过影像学研究识别。平片X光可检测≥2-3毫米的致密结石，而超声检查具有更高的敏感性，假阴性率仅为6%，而X光片为27%[3]。细菌培养仍是金标准，膀胱穿刺样本≥1,000 CFUs/mL表示具有临床相关性的菌尿[1]。

肿瘤和解剖异常需要先进的影像学或膀胱镜检查才能明确诊断。尿沉渣检查中发现菌尿强烈预测阳性培养结果[1]。临床表现模式、年龄人口统计学和系统性诊断评估有助于将细菌性膀胱炎与这些重叠疾病区分开来。

### Sources
[1] Bacterial Cystitis in Small Animals: https://www.merckvetmanual.com/urinary-system/infectious-diseases-of-the-urinary-system-in-small-animals/bacterial-cystitis-in-small-animals
[2] Managing idiopathic cystitis in cats for successful outcomes: https://www.dvm360.com/view/managing-idiopathic-cystitis-cats-successful-outcomes-parts-1-and-2-proceedings
[3] Diagnosing and managing recurrent urinary tract infections: https://www.dvm360.com/view/diagnosing-and-managing-recurrent-urinary-tract-infections-proceedings

## 预后

犬和猫的细菌性膀胱炎对于无并发症病例预后良好，大多数动物对适当的抗菌治疗反应迅速[1]。散发性细菌性膀胱炎与对治疗快速反应的临床症状相关，并且不易复发[1]。该病是由于宿主防御机制的暂时性破坏，在开始适当治疗后几天内即可解决[1]。

然而，对于复杂病例，预后变得更加谨慎。与宿主免疫系统缺陷相关的复杂UTI通常对抗生素治疗无反应或在停药后复发，构成治疗挑战[2]。复杂UTI最重要的治疗是纠正潜在的宿主防御缺陷，如果无法识别或纠正易感因素，复发和再感染很常见[2]。

大约25%在一生中患过UTI的宠物会发生复发性细菌性膀胱炎[3]。对于复发性感染病例，预后取决于潜在原因--再感染通常比复发感染具有更好的结果。当前建议对散发性病例和大多数复发性病例均采用短疗程治疗（3-5天），这已被证明与较长疗程同样有效，同时减少了抗菌素耐药性问题[1]。

影响恢复的预后因素包括潜在易感条件的存在、客户对治疗的依从性以及涉及的特定细菌病原体。大多数患有简单无并发症UTI的犬完全康复，并继续过着正常、健康的生活[3]。

### Sources

[1] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/pharmacotherapeutics-in-bacterial-urinary-tract-infections-in-animals

[2] Managing complicated urinary tract infections (Proceedings): https://www.dvm360.com/view/managing-complicated-urinary-tract-infections-proceedings

[3] Managing recurrent UTIs in pets: https://www.dvm360.com/view/managing-recurrent-utis-pets
