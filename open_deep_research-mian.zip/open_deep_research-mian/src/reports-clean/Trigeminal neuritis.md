# 伴侣动物的三叉神经炎

三叉神经炎是小动物临床中一种重要的神经系统急症，其特征为突发性双侧下颌瘫痪，导致患犬和患猫无法闭合口腔。这种特发性炎症性疾病影响第五对脑神经，造成独特的"下颌下垂"综合征，严重影响动物的进食和饮水能力。虽然确切病因尚不清楚，但该疾病涉及三叉神经运动支的非化脓性炎症和脱髓鞘。本报告探讨了三叉神经炎的临床表现、诊断挑战和管理策略，强调了在适当的支持性护理下良好的预后，以及这种自限性周围神经疾病典型的3-4周恢复时间。

## 疾病概述

三叉神经炎是影响犬猫第五对脑神经（三叉神经）的一种特发性炎症性疾病[1]。三叉神经是一条大型复杂神经，包含运动和感觉两种成分，为咀嚼肌（颞肌、咬肌、内侧翼肌、外侧翼肌、前二腹肌和下颌舌骨肌）提供运动神经支配，并为头部大部分区域提供感觉神经支配，包括面部、眼睑、耳廓、角膜、口腔和鼻粘膜[1]。

特发性三叉神经病变在犬中常见，但在猫中不常见[2]。该病的特征是急性发作的弛缓性下颌瘫痪，患病动物无法闭合口腔，进食和饮水困难[2]。病因尚不清楚，但组织病理学检查显示三叉神经运动支存在双侧非化脓性炎症和脱髓鞘[2]。

虽然金毛寻回犬可能易患眼外肌炎，但现有的兽医文献并未提供关于三叉神经炎特定品种发病率的详细流行病学数据[3]。大多数患病动物在支持性护理下会在3-4周内自行康复[2]。

### Sources
[1] DVM 360 Cranial nerve disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-dogs-and-cats-proceedings
[2] Merck Veterinary Manual Inflammatory Disorders of the Peripheral Nerves and Neuromuscular Junction in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/inflammatory-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals
[3] DVM 360 Cranial nerve disorders in dogs (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings

## 病理生理学和临床表现

三叉神经炎涉及三叉神经运动支的双侧非化脓性炎症和脱髓鞘，尽管确切的病理生理机制仍不清楚[1][2]。急性炎症过程破坏神经传导，导致运动功能障碍，而通常不影响感觉功能[1]。

典型的临床症状是突发性弛缓性下颌瘫痪，形成特征性的"下颌下垂"综合征，患病动物无法闭合口腔[1][2]。这种双侧运动缺陷阻碍了正常的食物摄取，并导致从口角过度流涎[2]。由于无法正确抓取和处理食物，动物在进食和饮水方面遇到严重困难[1][2]。

虽然运动缺陷在临床表现中占主导地位，但一些患者可能出现非典型症状，包括三叉神经分布区域的部分面部感觉丧失[3]。霍纳综合征偶尔会伴随三叉神经炎出现，尽管这是一种较少见的表现形式[2][3]。

急性发作的性质将三叉神经炎与渐进性神经系统疾病区分开来。临床症状通常在数天内而非数周内达到最严重程度[3]。尽管运动表现显著，但患病动物保持正常的精神状态、食欲和痛觉感知，这有助于将这种周围神经疾病与中枢神经系统疾病区分开来[2]。

运动障碍的双侧性质对于产生特征性的下颌下垂至关重要，因为单侧三叉神经功能障碍通常不会导致这种严重的临床表现[3]。

### Sources

[1] Merck Veterinary Manual Inflammatory Disorders: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/inflammatory-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals

[2] Merck Veterinary Manual Dog Disorders: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-dogs

[3] DVM 360 Cranial nerve disorders in dogs: https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings

## 诊断方法和鉴别诊断

三叉神经炎的诊断主要依靠全面的神经系统检查，结合系统地排除其他疾病。神经系统检查有助于确定脑神经功能障碍是源于中枢神经系统还是周围神经系统[1]。

体格检查显示双侧下颌瘫痪，无法闭合口腔，食物摄取困难，以及三叉神经分布区域的感觉丧失程度不一[2]。运动功能评估包括通过张开下颌评估咀嚼肌张力以及测试舌头力量[1]。完整的神经系统检查应排除其他脑神经缺陷和脑干体征，这些体征提示中枢神经系统受累[3]。

先进的诊断成像技术中，MRI比CT更适合检测中枢神经系统病变[2]。电诊断检查包括肌电图和神经传导研究，可以客观评估三叉神经功能[1]。脑脊液分析可用于检测中枢神经系统或神经根的炎症性疾病[1]。

主要的鉴别诊断包括狂犬病、肿瘤（神经鞘瘤、脑肿瘤）、创伤、咀嚼肌肌炎和下颌脱位[2][4]。咀嚼肌肌炎在急性期表现为肌肉肿胀和疼痛，在慢性期发展为明显萎缩和牙关紧闭[1]。神经鞘瘤最初引起单侧无力和疼痛，最终导致受影响侧的肌肉萎缩[4]。应根据疫苗接种史考虑狂犬病的可能性，而创伤则需要评估颅骨X光片以检查骨折[2]。

### Sources
[1] Cranial nerve disorders in dogs (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings
[2] Cranial nerve disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-dogs-and-cats-proceedings
[3] Skills Laboratory, Part 2: Interpreting the results of a neurologic examination: https://www.dvm360.com/view/skills-laboratory-part-2-interpreting-results-neurologic-examination
[4] Disorders of the Peripheral Nerves and Neuromuscular Junction in Dogs: https://www.merckvetmanual.com/en-au/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-dogs

## 治疗、预防和预后

### 治疗选择
三叉神经炎没有特异性治疗方法，该疾病对皮质类固醇无反应[1]。治疗重点在于支持性护理，以维持营养和水分，同时神经自行恢复[2]。由于患病动物无法正确闭合口腔，进食和饮水方面的帮助至关重要[2]。病因不明，没有特异性治疗方法[3]。

### 喂养管理
营养支持需要喂食糊状食物或流质饮食，动物可以舔食[2]。对于严重病例，可能需要放置饲管，包括咽造口术、食管造口术或PEG管[2][4]。对于厌食≥3天或自愿热量摄入不足的动物，建议使用肠内饲管[4]。可能还需要液体疗法以防止脱水[2]。液体和营养支持可能是必要的[3]。

### 预防
对于特发性三叉神经炎，没有已知的预防措施，因为病因仍然不明[2][3]。没有疫苗或环境控制措施可用于预防这种疾病。

### 预后
预后通常良好，因为三叉神经炎通常是自限性的[1][2]。恢复通常在3-4周内自发发生[1][2][3]，大多数动物在3周内开始改善，并在1-9周内完全康复[1][2]。平均恢复时间约为3周[2]。大多数患病动物完全康复，没有长期神经功能缺损。

### Sources
[1] Merck Veterinary Manual: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/inflammatory-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals  
[2] Cranial nerve disorders (Proceedings) - dvm360: https://www.dvm360.com/view/cranial-nerve-disorders-proceedings  
[3] Disorders of the Peripheral Nerves and Neuromuscular Junction in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/brain-spinal-cord-and-nerve-disorders-of-dogs/disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-dogs
[4] Enteral feeding in dogs and cats - dvm360: https://www.dvm360.com/view/enteral-feeding-dogs-and-cats-indications-principles-and-techniques-proceedings
