# 犬猫特应性皮炎

特应性皮炎是影响伴侣动物最常见的过敏性皮肤病之一，犬的过敏相关保险索赔为16例，而猫仅为6例。这种具有遗传倾向、IgE介导的炎症性疾病导致慢性瘙痒，显著影响宠物及其主人的生活质量。该疾病在不同物种中表现不同，犬通常在耳廓和前爪表现出特征性病变模式，而猫则表现为粟粒性皮炎和自发性脱毛。

本综述全面探讨了特应性皮炎的病理生理学、品种易感性和年龄相关模式。报告涵盖了现代诊断方法，包括Favrot标准，探讨了从速效JAK抑制剂到长期免疫治疗的当前治疗方式，并讨论了为准确诊断必须系统排除的关键鉴别诊断。

## 疾病概述与流行病学

特应性皮炎(AD)是一种具有遗传倾向的炎症性和瘙痒性过敏性皮肤病，具有特征性临床表现[1]。它最常与环境过敏原（如花粉、环境螨虫、霉菌、食物过敏原以及马拉色菌和葡萄球菌生物体）的IgE抗体相关[1]。特应性表型的特征是慢性瘙痒、典型的病变分布、家族病史和品种易感性[1]。

患有AD的动物在遗传上易通过吸入或皮肤吸收对环境中的过敏原产生致敏作用[1][3]。过敏原是蛋白质，当通过皮肤、呼吸道或胃肠道吸入或吸收时，会引发过敏原特异性IgE的产生[1]。这些过敏原特异性IgE分子附着在组织肥大细胞或嗜碱性粒细胞上[1]。

发病机制涉及IgE介导的I型超敏反应和T细胞介导的反应[3]。当致敏细胞再次接触特定过敏原时，肥大细胞脱颗粒导致炎症介质（包括组胺、白三烯和其他血管活性物质）的释放[1]。

犬AD是一种常见的皮肤疾病，估计全球约影响10-15%的犬[3][5]。多个品种表现出对犬AD的易感性，包括中国沙皮犬、金毛寻回犬、拉布拉多寻回犬、大麦町犬、拳师犬和各种梗类犬[1]。发病年龄通常在6个月至3岁之间，无性别偏好[1]。最近的保险数据显示，犬平均有16例过敏相关索赔，而猫为6例[6]。

猫特应性皮炎与犬AD有许多相似之处，但表现不同，包括粟粒性皮炎、自发性脱毛、嗜酸性肉芽肿复合物以及头颈部瘙痒[1]。

### Sources

[1] Atopic Dermatitis in Animals - Integumentary System: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[2] Canine allergic dermatitis: Pathogenesis, clinical signs, and diagnosis: https://www.dvm360.com/view/canine-allergic-dermatitis-pathogenesis-clinical-signs-and-diagnosis
[3] Canine atopic dermatitis: a roadmap to individualized, multimodal treatment: https://www.dvm360.com/view/canine-atopic-dermatitis-a-roadmap-to-individualized-multimodal-treatment
[4] Fecal bacterial microbiota diversity characterized for dogs with: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.24.09.0274/ajvr.24.09.0274.pdf
[5] Update on pathogenesis, diagnosis, and treatment of atopic: https://avmajournals.avma.org/view/journals/javma/254/11/javma.254.11.1291.xml
[6] The prevalence of allergy-related claims: https://www.dvm360.com/view/the-prevalence-of-allergy-related-claims

## 诊断方法

**临床评估与病史采集**

特应性皮炎的诊断主要依靠临床标准、病史和排除其他瘙痒性疾病，而非明确的实验室检测[1]。系统的诊断方法至关重要，首先需要对达到准确诊断所需的系统过程进行全面的客户教育[2]。

**犬诊断的Favrot标准**

前瞻性研究已将Favrot标准确立为犬特应性皮炎的标准化诊断指南[2]。这些标准包括受影响的耳廓（非耳廓边缘）、受影响的前爪、3岁以下发病、慢性或复发性酵母感染、对皮质类固醇有反应的瘙痒、主要室内生活方式、未受影响的背腰部区域以及发病时无皮肤病变的瘙痒[2]。报告的敏感性和特异性分别为85%和79%[2]。

**最低皮肤科数据库**

标准诊断工作流程需要完成最低皮肤科数据库，包括皮肤刮片、真菌培养和细胞学检查[3]。这种系统方法确保在确认特应性皮炎之前排除寄生虫性、感染性和其他过敏性疾病。

**过敏检测方案**

皮内过敏检测仍是金标准诊断测试，需要镇静和剃毛[4]。血清过敏检测（RAST或ELISA）通过简单的血液采集提供便利，但可能产生假阳性结果[4]。两种检测都识别用于免疫疗法配方的特定过敏原，但需要与临床病史和季节性相关联[2]。检测仅在临床诊断确立后进行，主要用于免疫疗法规划而非诊断确认。

### Sources
[1] Atopic Dermatitis in Animals: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[2] Canine Atopic Dermatitis: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis
[3] Feline Atopic Dermatitis: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/feline-atopic-dermatitis
[4] Atopic dermatitis in cats and dogs (Proceedings): https://www.dvm360.com/view/atopic-dermatitis-cats-and-dogs-proceedings

## 治疗策略与管理

全面的特应性皮炎管理需要结合药物和非药物干预的定制化多模式方法[1]。主要目标是通过终身疾病管理而非治愈来改善患者和主人的生活质量[2]。

**药物治疗选择**

速效疗法包括奥拉替尼（JAK-1抑制剂），在24小时内提供瘙痒控制，28天治疗成功率为66%[1]。Lokivetmab是一种单克隆抗IL-31抗体，提供每月皮下注射，有效率为73-88%，不良反应最小[1]。对于猫，奥拉替尼以0.4-2 mg/kg每12-24小时一次的剂量显示出良好前景，尽管标签外使用需要监测[9]。

环孢素对两种动物的长期管理仍然有效，需要4-6周才能产生治疗效果。犬的初始剂量为5 mg/kg每日一次，而猫特应性皮炎需要7 mg/kg每日一次持续30天[2]。糖皮质激素提供快速缓解，但由于潜在的不良反应，仅用于急性发作。

**免疫疗法和环境管理**

过敏原特异性免疫疗法代表长期治疗的金标准，反应率为60-70%，达到最大效果需要长达12个月[6]。成功取决于准确的过敏原识别和适当的方案调整。

通过定期洗澡（每周至每两周）、用于继发性感染的抗菌洗发水以及避免过敏原的环境管理增强治疗效果[1]。识别和控制诱发因素，包括继发性感染、食物过敏原和季节性暴露，对于最佳管理至关重要[7]。

### Sources
[1] Think like a dermatologist: untangling itch: https://www.dvm360.com/view/think-like-a-dermatologist-untangling-itch
[2] Immunomodulators for Integumentary Disease in Animals: https://www.merckvetmanual.com/pharmacology/systemic-pharmacotherapeutics-of-the-integumentary-system/immunomodulators-for-integumentary-disease-in-animals
[3] Atopic Dermatitis in Animals - Integumentary System: https://www.merckvetmanual.com/en-au/integumentary-system/atopic-dermatitis/atopic-dermatitis-in-animals
[4] Oclacitinib 10 years later: lessons learned and directions for: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.22.12.0570.xml
[5] Dermatology advancements: An overview of the latest treatment options: https://www.dvm360.com/view/dermatology-advancements-an-overview-of-the-latest-treatment-options
[6] Allergy specific immunotherapy: how to maximize the results: https://www.dvm360.com/view/allergy-specific-immunotherapy-how-maximize-results-proceedings
[7] Canine Atopic Dermatitis - Integumentary System: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis
[8] Update on canine atopy: Diagnosis and management: https://www.dvm360.com/view/update-canine-atopy-diagnosis-and-management-proceedings
[9] Update on pathogenesis, diagnosis, and treatment of atopic: https://avmajournals.avma.org/view/journals/javma/254/11/javma.254.11.1291.xml

## 鉴别诊断与预后

### 主要鉴别诊断

准确诊断特应性皮炎需要系统排除许多具有重叠临床表现的瘙痒性疾病[1]。主要鉴别诊断包括**体外寄生虫**（跳蚤、疥螨、蠕形螨、 cheyletiellosis），必须通过皮肤刮片和跳蚤控制评估来排除[1]。**食物过敏**表现出类似的瘙痒模式，但缺乏季节性变化，可能影响在特应性皮炎中通常不受影响的背部区域[2]。

**继发性感染**（葡萄球菌和马拉色菌物种）通常使特应性皮炎复杂化，并可能掩盖潜在的过敏性疾病[1]。**跳蚤过敏性皮炎**尤其重要，因为过敏是叠加的--控制跳蚤暴露可能会将总过敏原负担降低到瘙痒阈值以下[2]。

### 区分临床特征

Favrot标准提供诊断指导，当八项标准中满足五项时，敏感性为85%：受影响的耳廓、前爪、3岁以下发病、慢性酵母感染、对皮质类固醇有反应的瘙痒、室内生活方式、未受影响的背腰部区域以及初始无病变的瘙痒[1]。

### 预后和预期结果

特应性皮炎无法治愈，但在大多数情况下可以成功管理以改善生活质量[1]。**过敏原特异性免疫疗法**提供最佳的长期预后，成功率约为66%，尽管需要6-12个月才能显著改善[2]。现代靶向疗法如奥拉替尼和lokivetmab在急性管理中可在24-72小时内提供快速缓解[1]。大多数患者需要终身多模式治疗，预后很大程度上取决于主人的依从性和早期干预以防止继发性并发症。

### Sources
[1] Canine Atopic Dermatitis - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/atopic-dermatitis/canine-atopic-dermatitis
[2] Allergies: Atopic Dermatitis in Dogs and Cats - Veterinary Partner - VIN: https://veterinarypartner.vin.com/default.aspx?pid=19239&id=4951475
