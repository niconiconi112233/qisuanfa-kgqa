# 伴侣动物毛滴虫病：综合兽医指南

毛滴虫病是兽医实践中影响猫的一种重要寄生虫病，由鞭毛原生动物胎儿三毛滴虫引起。这种传染性病原体导致慢性大肠性腹泻和结肠炎，特别是在猫舍和收容所等高密度环境中饲养的幼猫中。由于该生物体的挑剔特性和有限的治疗选择，该疾病呈现出独特的诊断和治疗挑战。本报告探讨了病原体特征、临床表现、诊断方法、治疗方案和预防策略，这些对于小动物实践中的有效管理至关重要。了解毛滴虫病对于管理慢性腹泻病例的兽医至关重要，因为这种情况通常需要专门的检测，并仔细权衡治疗风险与收益。

## 疾病概述

伴侣动物的毛滴虫病是一种主要影响猫的原生动物感染，由胎儿三毛滴虫引起。这种厌氧原生动物寄生虫是传染性大肠性腹泻和慢性结肠炎的重要病因[1]。胎儿三毛滴虫是一种鞭毛生物，长10-25微米，有3-5根鞭毛和一个波动膜[2]。

自从在猫中发现以来，该疾病在小动物兽医实践中日益受到重视。胎儿三毛滴虫的流行率因饲养条件而有显著差异--约30%的赛猫受到感染，而在流浪猫或室内猫中流行率非常低[1][3]。高种群密度环境如猫舍和收容所是感染的主要风险因素[1][4]。

大多数宠物狗和猫群体中的总体流行率通常为1%至5%，但在腹泻动物中增加到10-20%[5]。群居动物的感染率可能达到更高水平，一项研究发现来自89个猫舍的117只猫中有31%被感染[5]。

与引起生殖系统疾病的牛型胎儿三毛滴虫不同，猫株专门以滋养体形式定植于回肠末端、盲肠和结肠。该生物体不形成包囊，使传播通过滋养体形式在宿主间直接发生[4]。一岁以下的幼猫最常受影响，感染通常在3个月至13岁之间出现[1][3]。

### Sources

[1] Giardia, cryptosporidia, tritrichomonas (Proceedings): https://www.dvm360.com/view/giardia-cryptosporidia-tritrichomonas-proceedings

[2] Giardia and Tritrichomonas foetus: An update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings

[3] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t

[4] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings

[5] An update on three important protozoan parasitic infections in cats: cryptosporidiosis, giardiasis, and tritrichomoniasis: https://www.dvm360.com/view/update-three-important-protozoan-parasitic-infections-cats-cryptosporidiosis-giardiasis-and-tritrich

## 常见病原体

引起猫毛滴虫病的主要病原体是**胎儿三毛滴虫**，一种鞭毛原生动物寄生虫[1]。这种生物体呈梨形和多形性，长10-25微米，具有三根前鞭毛和一根延伸超出波动膜的长后鞭毛[1][2]。

胎儿三毛滴虫是一种厌氧原生动物，具有独特的形态特征，可将其与相似生物体区分开来[2]。与贾第虫不同，胎儿三毛滴虫表现出快速、抽搐的"吉特巴"运动，而不是贾第鞭毛虫特征性的"落叶"运动[2]。该生物体缺乏包囊阶段，仅以活动的滋养体形式存在，通过粪口途径在宿主间直接传播[2][3]。

最近的分子研究证实，**胎儿三毛滴虫，而不是人五毛滴虫，是猫毛滴虫腹泻的病原体**[4]。所有毛滴虫都具有三至五根前鞭毛、一个波动膜和附着在波动膜边缘的后鞭毛[5]。一个关键识别特征是贯穿毛滴虫全长并向后突出的轴柱[5]。

该寄生虫寄居在受感染猫的盲肠、结肠和回肠远端[3]。它以滋养体形式在这些区域定植，并持续在粪便中排出，使其在潮湿环境中可存活长达三天[3][6]。虽然胎儿三毛滴虫也可在生殖系统感染牛，但猫株似乎特别适应猫的胃肠道[1]。

### Sources
[1] Giardia and Tritrichomonas infections: https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[2] Feline infectious diarrhea update: https://www.dvm360.com/view/feline-infectious-diarrhea-update-proceedings
[3] An update on feline infectious diarrhea: https://www.dvm360.com/view/update-feline-infectious-diarrhea-proceedings
[4] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t
[5] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich

## 临床症状和体征

猫毛滴虫病表现为特征性的大肠性腹泻模式。主要的临床表现为慢性、时好时坏的大肠性腹泻，通常呈半成形或"牛粪"状稠度，并具有明显的恶臭[1]。这种腹泻有时含有新鲜血液或粘液，将其与小肠疾病区分开来[2]。

**胃肠道表现**
腹泻的特点是间歇性，有改善期后复发。受感染的猫可能会经历排便困难（里急后重）和排便频率增加而每次排便量减少，这是大肠受累的典型表现[3]。胎儿三毛滴虫引起轻度至重度的淋巴浆细胞性和中性粒细胞性结肠炎，导致这些特征性的大肠症状[4]。

**全身性体征**
严重受感染的幼猫可能出现严重的肛门刺激，伴有粪便滴漏或大便失禁，有些病例发展为直肠脱垂[2]。尽管有这些胃肠道体征，受感染的猫通常保持健康状态并维持良好的身体状况，这有助于将毛滴虫病与其他衰弱性疾病区分开来[2]。腹泻对抗生素治疗通常有短暂改善[4]。

**品种特异性模式**
在猫舍和收容所等高密度环境中的幼猫显示出最高的流行率[2]。胎儿三毛滴虫感染在拥挤猫舍和收容所中密集饲养的幼猫中流行率最高，在一项研究中，来自89个猫舍的117只猫中有31%被确认感染[4]。与其他寄生虫（特别是贾第虫和隐孢子虫）的合并感染通常加剧临床症状，应在诊断工作中予以考虑[3]。

### Sources
[1] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[2] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-0
[3] Acute and chronic diarrhea in dogs and cats: https://www.dvm360.com/view/acute-and-chronic-diarrhea-dogs-and-cats-giardiasis-clostridium-perfringens-enterotoxicosis-tritrich
[4] Giardia and Tritrichomonas foetus: An update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings

## 诊断方法

诊断伴侣动物的毛滴虫病需要结合临床评估和专业实验室技术的系统方法。诊断的挑战在于胎儿三毛滴虫的挑剔特性和新鲜标本采集的需求[1]。

直接粪便检查仍然是初步筛查方法。将腹泻粪便的新鲜湿涂片与盐水混合，在200-400X放大倍数下进行显微镜检查，可以识别活动的胎儿三毛滴虫滋养体[2]。这些生物体表现出特征性的快速、抽搐的"吉特巴"运动，将其与贾第虫的"落叶"运动区分开来[2]。然而，直接显微镜检查的敏感性有限，在临床研究中仅能检测出14%的自然感染猫[1]。

使用InPouch TF等专业系统的粪便培养提供了更高的诊断准确性[3]。培养需要米粒大小的量（0.05g）新鲜粪便接种到原生动物培养基中，在37°C下孵育48小时或在室温下孵育长达12天[2]。这种方法比直接显微镜检查具有更高的敏感性，同时保持生物体的活性[3]。

PCR检测是最准确的诊断方法，具有卓越的敏感性和特异性[2]。这种分子技术需要180-220毫克保存在异丙醇中的粪便，检测限为每200毫克样品10个毛滴虫[2]。PCR仍然是确诊的金标准，对于确认感染持续或治疗失败特别有价值。

### Sources
[1] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[2] Giardia and Tritrichomonas foetus: An update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings
[3] Use of a commercially available culture system for diagnosis of: https://avmajournals.avma.org/view/journals/javma/222/10/javma.2003.222.1376.xml

## 治疗选择

**药物干预**

罗硝唑仍然是治疗猫胎儿三毛滴虫感染最有效的硝基咪唑类抗菌药物[1][2]。以30 mg/kg口服每日一次或两次，持续10-14天，罗硝唑比其他药物显示出更好的疗效，但具有显著的神经毒性风险，包括嗜睡、食欲下降、共济失调、颤抖、躁动和癫痫发作[1][2][4]。这些神经系统副作用通常在治疗开始后3-9天出现，停药后通常是可逆的，但恢复可能需要1-4周[2][4]。狭窄的安全范围需要在治疗期间仔细监测[2]。

甲硝唑和替硝唑代表替代的硝基咪唑选择，但疗效有限[1]。研究表明，甲硝唑以25 mg/kg BID给药可使研究猫的粪便样本呈阴性，而替硝唑在体外浓度≥10 μg/mL时可杀死胎儿三毛滴虫[1]。然而，这些替代品在完全消除生物体方面通常不如罗硝唑有效[1]。

**非药物管理**

环境控制措施对于预防再感染至关重要[2]。受感染的猫应在治疗期间隔离，并频繁更换和消毒猫砂盆[2]。减少饲养密度可最大程度减少与压力相关的并发症，而同时发生的寄生虫感染，特别是贾第虫和隐孢子虫，需要同时识别和治疗[2]。

**治疗考虑因素**

治疗效果仍然有限，罗硝唑在约60%的病例中成功[1]。许多猫在未经治疗的情况下在两年内腹泻自发缓解，尽管它们可能在多年内保持PCR阳性[1][4]。考虑到潜在的药物毒性和疾病的自然缓解，治疗决定需要仔细评估个体患者情况和主人期望[1]。

### Sources
[1] Update on Feline Trichomonosis: To Treat or Not to Treat?: https://www.dvm360.com/view/update-on-feline-trichomonosis-to-treat-or-not-to-treat
[2] Giardia and Tritrichomonas infections (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[3] Giardia and Tritrichomonas foetus: an update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings-0
[4] Giardia and Tritrichomonas foetus: An update (Proceedings): https://www.dvm360.com/view/giardia-and-tritrichomonas-foetus-update-proceedings

## 预防措施和鉴别诊断

### 环境控制和隔离

环境消毒对于在多猫家庭和猫舍中预防毛滴虫病传播至关重要。在彻底清除所有粪便物质后，蒸汽清洁可有效从受污染表面消除胎儿三毛滴虫滋养体[1]。季铵化合物在按制造商推荐浓度使用时提供有效的化学消毒[2]。

环境的完全干燥至关重要，因为毛滴虫病生物体不能在干燥条件下存活。受感染的猫应在治疗期间隔离，以防止再感染[3]。猫砂盆需要频繁更换和消毒，以最大限度地减少治疗期间的自身感染。胎儿三毛滴虫在潮湿环境中可存活长达三天，但在干燥条件下迅速死亡[2]。

### 高风险环境管理

减少过度拥挤是收容所环境中最重要的控制措施[2]。该生物体缺乏包囊阶段，使其环境持久性与其他原生动物相比有限。罗硝唑治疗需要在延长治疗期间仔细监测神经系统副作用[4]。

### 鉴别诊断

几种肠道病原体表现出与毛滴虫病重叠的临床症状。贾第虫感染产生类似的大肠性腹泻，但在直接粪便检查中表现出特征性的"落叶"运动，而不是毛滴虫的抽搐运动[5]。

产气荚膜梭菌肠毒素中毒引起慢性间歇性腹泻，但需要肠毒素检测进行确诊[1]。隐孢子虫病表现为水样腹泻，需要专门的免疫荧光检测进行识别[3]。贾第虫合并感染在患有毛滴虫病的猫中很常见，需要使用多种诊断方式进行全面的寄生虫评估[3]。

### Sources
[1] Diagnosing cases of acute or intermittent diarrhea: https://www.dvm360.com/view/diagnosing-cases-acute-or-intermittent-diarrhea-giardiasis-clostridium-perfringens-enterotoxicosis-t
[2] Feline infectious diarrhea update (Proceedings): https://www.dvm360.com/view/feline-infectious-diarrhea-update-proceedings
[3] Giardia and Tritrichomonas infections: https://www.dvm360.com/view/giardia-and-tritrichomonas-infections-proceedings
[4] A new treatment for feline Tritrichomonas foetus infection: https://www.dvm360.com/view/cvc-highlights-new-treatment-feline-tritrichomonas-foetus-infection
[5] Giardia, cryptosporidia, tritrichomonas: https://www.dvm360.com/view/giardia-cryptosporidia-tritrichomonas-proceedings
[6] An update on three important protozoan parasitic infections: https://www.dvm360.com/view/update-three-important-protozoan-parasitic-infections-cats-cryptosporidiosis-giardiasis-and-tritrich
