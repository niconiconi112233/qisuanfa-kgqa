# 伴侣动物中的纤维瘤

纤维瘤是一种影响犬猫的重要良性结缔组织肿瘤，在兽医实践中需要准确的诊断和适当的治疗。这些真皮成纤维细胞的离散性增生主要发生在老年犬中，特别是杜宾犬、拳师犬和金毛寻回犬，表现为隆起的、通常无毛的结节，具有两种不同的变体：坚硬的硬纤维瘤和柔软的软纤维瘤。虽然纤维瘤本质上是良性的，但可能与恶性纤维肉瘤相混淆，因此正确的鉴别诊断至关重要。本报告探讨了纤维瘤管理的综合临床方法，涵盖从体格检查到组织病理学的诊断方法、考虑边缘的手术治疗选择、包括脂肪瘤和软组织肉瘤在内的鉴别诊断，以及完全切除后的长期预后。

## 疾病概述与分类

现有内容为伴侣动物纤维瘤分类提供了全面的基础。根据额外的资料来源，我可以将这些信息与最新的流行病学发现相结合，以增强概述，同时保持既定结构。

最近研究的流行病学数据证实了纤维瘤的患病模式，纤维肉瘤约占猫口腔肿瘤的10-20%[2]，而良性成纤维细胞肿瘤占结缔组织肿瘤的很大一部分[3]。在瑞士犬类癌症登记处对1955-2008年间121,693只犬的分析中，纤维瘤/纤维肉瘤占所有肿瘤的3.4%，通常发生在软组织和皮肤中[4]。

外周牙源性纤维瘤代表一个独特的亚群，是犬猫最常见的良性口腔肿瘤。最新的瑞士数据显示，这些肿瘤占犬良性口腔肿瘤的77.8%，占猫所有口腔肿瘤的8.2%[1][3]。这种特定形式表明解剖部位分类在纤维瘤诊断和预后中的重要性。

现有内容中概述的年龄和品种易感性与当前文献保持一致。头部和四肢仍然是主要的解剖部位，硬纤维瘤和软纤维瘤之间的区别提供了重要的临床特征[1]。

当代证据强化了完全切除的建议，特别是考虑到可能与低级别纤维肉瘤的诊断混淆，这些肿瘤表现出恶性浸润行为，尤其是发生在口鼻部时[1]。

### Sources
[1] Connective Tissue Tumors in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[2] Feline oral tumors (Proceedings): https://www.dvm360.com/view/feline-oral-tumors-proceedings
[3] A retrospective study of oral tumors in cats in Switzerland: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.05.0161/ajvr.25.05.0161.xml
[4] Findings from the Swiss Canine Cancer Registry, 1955-2008: https://www.dvm360.com/view/findings-from-the-swiss-canine-cancer-registry-1955-2008

## 临床表现与诊断方法

纤维瘤的临床表现根据肿瘤位置和类型而有显著差异。皮肤纤维瘤通常表现为离散的、隆起的、通常无毛的结节，起源于真皮或皮下组织[1]。这些病变触诊时感觉坚硬而有弹性（硬纤维瘤）或柔软而有波动感（软纤维瘤）[1]。

外周牙源性纤维瘤（POF）表现为坚实的牙龈肿块，最常见影响6岁以上的犬[2]。这些牙周韧带肿瘤通常是单发的，但也可能出现多发病变[2]。一些POF在牙科X光片上可看到矿化，表现为软组织阴影内的明显不透明区[2]。

体格检查显示真皮或牙龈结节，可能是无蒂至隆起状，表面呈乳头状。胶原痣通常发生在近端和远端四肢、头部、颈部和易受创伤的区域[1]。存在两种不同的形式：不涉及附属器的毛囊间/皮下变体，以及包含扩大、畸形毛囊和腺体的形式[1]。

诊断成像包括对口腔病变进行牙科X光检查，以识别骨化中心和骨受累情况。CT或MRI的先进成像为较大肿块提供手术计划细节[1]。最终诊断需要活检或切除后的组织病理学检查[1][2]。对于易于脱落的病变，细针抽吸的细胞学诊断可能是可行的[2]。

### Sources

[1] Connective Tissue Tumors in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals

[2] Oral Tumors in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals

## 治疗选择与手术管理

**手术切除是犬猫纤维瘤的金标准治疗方法。**完全手术切除包括以足够的边缘切除肿瘤，以最小化复发风险[1]。边缘应足够宽以确保完全切除肿瘤，建议对切除边缘进行组织病理学检查以确认边缘清晰[1]。大多数肿瘤的目标是1-2厘米边缘的手术切除，但如果不可行，手术减瘤仍可改善生活质量[2]。

**对于良性纤维瘤，如果病变小且无问题，治疗可能是可选的。**然而，当纤维瘤外观改变、生长过大或干扰动物的舒适度或功能时，建议手术切除[1,3]。变得溃疡或引起继发性炎症的纤维瘤应予以切除以防止并发症[1]。

**坚硬（硬纤维瘤）和柔软（软纤维瘤）两种变体都对手术切除反应良好。**完全切除通常对良性纤维瘤具有治愈性，尽管一些动物可能随时间倾向于发展出额外的肿瘤[1,3]。对于恶性纤维肉瘤，广泛的手术切除并去除周围组织是必要的，因为这些肿瘤具有局部侵袭性[3]。

**术后护理包括疼痛控制、限制活动监测并发症。**从麻醉中恢复后可提供饮水，术后6-8小时提供软食[3]。伊丽莎白圈可防止手术部位的自体创伤[3]。

### Sources
[1] Merck Veterinary Manual Tumors of the Skin in Dogs: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
[2] AVMA 2017: Managing Oral Tumors in Dogs: https://www.dvm360.com/view/avma-2017-managing-oral-tumors-in-dogs
[3] Merck Veterinary Manual Oral Tumors in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-mouth-in-small-animals/oral-tumors-in-small-animals

## 鉴别诊断与相关疾病

将纤维瘤与其他皮肤肿块区分需要系统评估临床表现和病理特征。主要的鉴别诊断包括其他良性间质肿瘤、恶性肉瘤和反应性病变[1]。

**良性肿瘤鉴别**包括脂肪瘤，表现为柔软、可自由移动的皮下肿块，抽吸时感觉油腻，与纤维瘤的坚实、细胞性质形成对比[2]。组织细胞瘤表现为幼犬的粉红色圆形肿块，可能自行消退，与纤维瘤的持续性特征相区别[1]。胶原痣表现为隆起的真皮结节，但缺乏真正纤维瘤特征的细胞增殖[3]。

**恶性肿瘤鉴别**需要仔细区分。纤维肉瘤是侵袭性间质肿瘤，具有明显的细胞多形性、多核细胞和粗染色质模式，与良性纤维瘤的均一外观形成对比[2]。软组织肉瘤表现为局部侵袭性肿块，具有长、纤细胞质突起的梭形细胞，与纤维瘤更圆润的细胞形态不同[8]。巨细胞肿瘤含有特征性的大型多核细胞，具有10-50个细胞核，这在纤维瘤中不存在[1]。

**反应性病变**包括局灶性纤维增生，这是继发于慢性刺激发展而来，显示类似的纤维组织增生但伴有炎症浸润。纤维瘤病表现为良好分化的成纤维细胞的侵袭性增殖，伴有散在的淋巴样结节，在没有组织学检查的情况下难以与浸润性纤维肉瘤区分[2]。

细胞学评估有助于区分这些疾病，因为纤维瘤通常产生少量均一的梭形细胞，具有淡嗜碱性胞质和圆形细胞核，而恶性病变显示细胞增多、多形性和有丝分裂活性增加[2]。

### Sources
[1] Just under the surface: Cytology of the skin (Proceedings): https://www.dvm360.com/view/just-under-surface-cytology-skin-proceedings
[2] Connective Tissue Tumors in Animals: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[3] Tumors of the Skin in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[8] Cytology for 3 common dermatological tumors: https://www.dvm360.com/view/cytology-for-3-common-dermatological-tumors

## 预防、预后与长期管理

**预防**
目前，由于犬猫纤维瘤的良性性质和不明确的病因学，尚无特定的预防措施[1]。纤维瘤是真皮成纤维细胞的离散性增生，主要发生在老年犬中，特别是杜宾犬、拳师犬和金毛寻回犬[3]。这些良性肿瘤表现为起源于真皮或皮下脂肪的隆起、通常无毛的结节，具有两种主要变体：坚硬而有弹性（硬纤维瘤）或柔软而有波动感（软纤维瘤）[3][4]。

**预后与临床结果**
纤维瘤在完全手术切除后的预后极好。这些病变是良性的，不会扩散到身体其他部位[1][3]。当达到足够的手术边缘时，完全手术切除通常具有治愈性且复发率低[3][4]。对于未溃疡且不影响正常活动的良性纤维瘤，尤其是在老年动物中，治疗可能是可选的[1][4]。

**长期管理与监测**
术后监测应包括手术边缘的组织病理学检查。"广泛"或"干净"的边缘表明肿瘤细胞远离切除组织的边缘，使复发不太可能[1][4]。建议定期随访检查以监测手术部位，但完全切除后复发并不常见。对于外观改变或生长过大的纤维瘤，建议完全手术切除[3][4]。

### Sources
[1] Tumors of the Skin in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/skin-disorders-of-cats/tumors-of-the-skin-in-cats
[2] Connective Tissue Tumors in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/tumors-of-the-skin-and-soft-tissues/connective-tissue-tumors-in-animals
[3] Tumors of the Skin in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/skin-disorders-of-dogs/tumors-of-the-skin-in-dogs
