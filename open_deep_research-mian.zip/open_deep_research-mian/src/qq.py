import os
import time
import json
import traceback
from datetime import datetime
from zai import ZhipuAiClient

# ========== 配置 ==========
API_KEY = "106350c189a5410cd95897207e4eafa2.Giu1p55HaVP6RCGu"  # 建议用环境变量读取
MODEL_NAME = "glm-4.5"
INPUT_DIR = "/Users/yangjianxin/Downloads/open_deep_research-mian/src/reports-0806"
OUTPUT_DIR = "/Users/yangjianxin/Downloads/open_deep_research-mian/src/reports-out"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 日志文件
ERROR_LOG = os.path.join(OUTPUT_DIR, "translation_errors.jsonl")
FAILED_LIST = os.path.join(OUTPUT_DIR, "failed_files.txt")

# ========== 初始化客户端 ==========
client = ZhipuAiClient(api_key=API_KEY)

def log_error(filename: str, stage: str, err: Exception, extra: dict = None):
    """将错误以 JSONL 记录下来，并把失败文件名写入列表。"""
    record = {
        "time": datetime.now().isoformat(),
        "file": filename,
        "stage": stage,
        "error_type": type(err).__name__,
        "error_msg": str(err),
        "traceback": traceback.format_exc(),
        "extra": extra or {},
    }
    with open(ERROR_LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
    with open(FAILED_LIST, "a", encoding="utf-8") as f:
        f.write(filename + "\n")

def build_prompt(text: str) -> str:
    return f"""
你是专业的中英双语兽医医学翻译，请将以下宠物医疗知识文档翻译成中文：
- 保留正文中的参考文献引用标记（如 [1]、[2]）原样不变；
- 文末的“Sources”部分不要翻译，保持原文格式；
- 保留原有 Markdown 标题与结构。
- 不要输出除翻译任务外任何其他无用的信息。

以下是需要翻译的文档内容：
{text}
""".strip()

def translate_file_stream(md_path: str, output_path: str, retries: int = 3, base_delay: float = 2.0):
    """流式翻译 + 实时打印 + 边下边写；带重试与错误记录。"""
    with open(md_path, "r", encoding="utf-8") as f:
        original_text = f.read()

    prompt = build_prompt(original_text)
    attempt = 0
    while True:
        attempt += 1
        partial_written = False
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=[{"role": "user", "content": prompt}],
                thinking={"type": "disabled"},
                stream=True,              # 开启流式
                max_tokens=8192,
                temperature=0.7
            )

            total_chars = 0
            # 以追加方式写，若中途异常，已写入内容仍保留
            with open(output_path, "w", encoding="utf-8") as out_f:
                for chunk in response:
                    try:
                        # 某些异常/心跳包可能无 choices 或无 delta
                        delta = getattr(chunk.choices[0], "delta", None) if chunk and chunk.choices else None
                        content_piece = getattr(delta, "content", None) if delta else None
                    except Exception as iter_err:
                        # 记录但继续尝试下一片
                        log_error(os.path.basename(md_path), "stream_iter", iter_err)
                        continue

                    if content_piece:
                        print(content_piece, end="", flush=True)
                        out_f.write(content_piece)
                        total_chars += len(content_piece)
                        partial_written = True

            print("\n✅ 翻译完成:", os.path.basename(md_path))

            # 判空：如果拿到的内容长度过短，视为失败（可能是限流或返回空）
            if total_chars < 5:
                raise RuntimeError(f"empty_or_too_short_output chars={total_chars}")

            return  # 成功即返回

        except KeyboardInterrupt:
            # 用户中断：仍保留已写内容，并记录
            print("\n⏹️ 用户中断:", os.path.basename(md_path))
            log_error(os.path.basename(md_path), "keyboard_interrupt", KeyboardInterrupt(), {"partial_written": partial_written})
            raise
        except Exception as e:
            # 记录错误
            log_error(os.path.basename(md_path), "api_call_or_stream", e, {
                "attempt": attempt,
                "partial_written": partial_written
            })

            if attempt >= retries:
                print(f"❌ 最终失败（已重试 {retries} 次）: {os.path.basename(md_path)} -> {e}")
                # 若没有任何内容写入，确保输出文件不存在空壳
                try:
                    if (not partial_written) and os.path.exists(output_path):
                        os.remove(output_path)
                except Exception:
                    pass
                return
            else:
                delay = base_delay * (2 ** (attempt - 1))
                print(f"⚠️ 出错重试第 {attempt}/{retries} 次，等待 {delay:.1f}s：{os.path.basename(md_path)} -> {e}")
                time.sleep(delay)

# ========== 遍历文件夹并翻译 ==========
def main():
    for filename in os.listdir(INPUT_DIR):
        if not filename.lower().endswith(".md"):
            continue
        input_path = os.path.join(INPUT_DIR, filename)
        output_path = os.path.join(OUTPUT_DIR, filename)

        print(f"\n—— 处理文件：{filename} ——")
        try:
            translate_file_stream(input_path, output_path, retries=3, base_delay=2.0)
        except Exception as e:
            # 兜底：单文件不可预期异常
            print(f"❌ 未捕获的异常 {filename}: {e}")
            log_error(filename, "uncaught_main", e)

if __name__ == "__main__":
    main()