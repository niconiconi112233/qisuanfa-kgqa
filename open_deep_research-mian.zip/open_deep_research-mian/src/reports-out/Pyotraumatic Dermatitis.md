# 伴侣动物的脓皮创伤性皮炎

脓皮创伤性皮炎，通常被称为"热点"，是伴侣动物中最快速发展的细菌性皮肤感染之一，能够在数小时内从初始刺激发展为广泛性病变。这种急性湿性皮炎给受影响的宠物带来显著不适，需要立即的兽医干预以防止扩散和继发并发症。本综合报告探讨了犬猫脓皮创伤性皮炎的临床表现、潜在病理生理学和基于证据的管理策略。主要主题包括假中间型葡萄球菌的主导作用、使用细胞学和细菌培养的诊断方法、涉及局部抗菌药物和全身治疗的急性治疗方案，以及针对潜在过敏状况和环境触发因素的关键预防策略。

## 疾病概述

脓皮创伤性皮炎，也称为急性湿性皮炎或"热点"，是一种局部的、快速发展的细菌性皮肤感染，其特征是由自体创伤引起的湿润、红斑和剧烈瘙痒的病变[1]。这种情况代表了一种浅表性脓皮病，是继发于潜在诱因发生的，这些诱因创造了温暖、潮湿的环境，有利于细菌过度生长[1]。

该疾病通常影响所有年龄段的犬，但没有特定的品种、年龄或性别倾向，尽管病例研究表明2至8岁的犬可能经常受到影响[2]。当存在易感因素时，脓皮创伤性皮炎可以迅速发展，通常在数小时内发生[1]。

**皮肤上的温暖、潮湿区域**，如唇褶、面部褶皱、颈褶、腋窝区域、背侧或跖侧趾间区域、阴门褶皱和尾褶，通常比其他皮肤区域有更高的细菌数量，感染风险增加[1]。当通常干燥、沙漠般的皮肤环境变得更加潮湿时，该疾病通常会发展，允许常驻和短暂细菌在受影响区域过度定植[1]。

不太常见的皮肤表现可能包括作为犬食物过敏继发体征的脓皮创伤性皮炎[3]。

### Sources

[1] Pyoderma in Dogs and Cats - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats

[2] Photobiomodulation with fluorescent light energy as a sole treatment of pyotraumatic dermatitis (hot spot): a case series in: Journal of the American Veterinary Medical Association - Ahead of print: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.12.0820/javma.24.12.0820.xml

[3] Cutaneous Food Allergy in Animals - Integumentary System - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/food-allergy/cutaneous-food-allergy-in-animals

## 病因学和发病机制

脓皮创伤性皮炎的特征是由自体创伤和细菌过度生长引发的复杂病理生理级联反应。犬脓皮创伤性皮炎的主要细菌病原体是**假中间型葡萄球菌**，它在大多数犬细菌性皮肤感染中代表主要微生物[1]。这种凝固酶阳性葡萄球菌产生β-内酰胺酶，使其固有地抵抗某些抗菌药物，包括青霉素、氨苄西林和阿莫西林[1]。

发病机制始于引发瘙痒的初始触发因素，导致剧烈的抓挠、舔舐或咀嚼行为。常见的潜在触发因素包括过敏状况，如异位性皮炎、食物过敏和跳蚤过敏性皮炎[1]。自体创伤破坏了正常的皮肤屏障功能，创造了有利于细菌粘附和增殖的温暖、潮湿条件[1]。

**皮肤上的温暖、潮湿区域**，包括面部褶皱、颈褶、腋窝区域和背侧趾间区域，表现出更高的细菌数量和增加的感染风险[1]。受损的屏障功能允许常驻菌群过度生长，并从共生行为转变为致病行为。在异位性动物中，细菌对角质形成细胞的粘附增加，屏障脂质功能缺陷促进葡萄球菌定植和增殖[6]。

一旦建立，细菌群体进行群体感应，从增殖转向毒素产生，这进一步损害屏障功能并延续炎症循环[6]。这创造了一个自我延续的过程，其中细菌感染维持炎症和瘙痒，导致持续的自体创伤和病变扩展。

### Sources

[1] Merck Veterinary Manual Pyoderma in Dogs and Cats: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[2] Diagnosing and treating canine bacterial pyodermas: https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings
[3] The CSI approach to pruritic pets–secondary dermatology testing: https://www.dvm360.com/view/csi-approach-pruritic-pets-secondary-dermatology-testing-proceedings

## 临床表现和诊断

脓皮创伤性皮炎表现为特征性的急性病变，包括脱毛、结痂和糜烂，并有超急性发作史[3][4]。病变通常表现为温暖、潮湿的区域，可能伴有疼痛，并常常伴有恶臭渗出物[1]。

体格检查显示界限清晰的脱发区域，伴有红斑和渗出性表面。病变通常发生在容易保留水分的区域，如唇褶、面部褶皱、颈褶和腋窝区域[1]。金毛寻回犬和圣伯纳犬可能表现出一种独特的颊部变异，这代表深部毛囊炎而非表面脓皮病[3][4]。

**诊断方法**

诊断主要基于临床表现和急性发作史[3][4]。皮肤细胞学是最有价值的诊断工具之一，允许识别炎症细胞和细菌[1]。应在轻轻清洁后从受影响区域收集印片。

必须进行深层皮肤刮片以排除蠕形螨病，而皮肤真菌培养有助于排除真菌感染[1]。对于无反应病例或怀疑耐甲氧西林生物体时，建议进行细菌培养和药敏试验[1]。

**关键鉴别诊断**

重要的鉴别诊断包括浅表性细菌性毛囊炎，其表现为丘疹和表皮领圈而非急性糜烂性病变[3][4]。还应考虑皮肤真菌病、蠕形螨病和接触性皮炎[1]。与脓皮创伤性毛囊炎不同，表面脓皮创伤性皮炎缺乏毛囊受累，表现为更表浅的糜烂。

### Sources
[1] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[2] Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[3] Diagnosing and treating canine bacterial pyodermas (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-canine-bacterial-pyodermas-proceedings

## 治疗方法

成功的脓皮创伤性皮炎治疗需要立即的急性管理，随后是全面的长期护理。初始管理始于彻底修剪受影响区域周围的毛发，并使用稀释的氯己定溶液（0.05%）或生理盐水冲洗进行温和清洁[7][8]。修剪应延伸到可见病变之外，以确保完整的伤口评估并防止进一步污染。

局部治疗形成治疗基石。抗菌敷料，特别是含银产品，在炎症和修复阶段提供持续的抗菌活性[7][9]。水胶体或水泡沫敷料可能有益于维持适当的水分平衡，但必须注意防止周围健康组织的浸渍[7]。

全身药物包括用于感染病变的广谱抗生素和谨慎使用皮质类固醇治疗严重炎症[1]。疼痛管理至关重要，因为这些病变可能相当不适。必须持续实施伊丽莎白圈或保护性包扎，以防止持续的自体创伤[1][7]。

解决根本原因确保长期成功并防止复发。常见触发因素包括跳蚤过敏、异位性皮炎和食物敏感性，需要同时治疗[1]。使用适当压力（7-8 psi）和大量抗菌溶液进行适当的伤口灌洗有助于去除碎屑并减少细菌负荷[8]。治疗成功取决于将立即的伤口护理与对易感因素的综合管理相结合。

### Sources

[1] DVM 360 Diagnosing and treating bacterial pyoderma in dogs (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-bacterial-pyoderma-dogs-proceedings
[7] Merck Veterinary Manual Wound Bandages and Dressings for Small Animals - Emergency Medicine and Critical Care - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/wound-bandages-and-dressings-for-small-animals
[8] Merck Veterinary Manual Initial Wound Management in Small Animals - Emergency Medicine and Critical Care - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/initial-wound-management-in-small-animals
[9] Merck Veterinary Manual Topical Agents in Wound Management in Small Animals - Emergency Medicine and Critical Care - Merck Veterinary Manual: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/wound-management-in-small-animals/topical-agents-in-wound-management-in-small-animals

## 预防和预后

脓皮创伤性皮炎的预防集中在控制潜在状况和识别触发因素[1]。最重要的预防措施是维持严格的跳蚤控制，因为跳蚤过敏性皮炎是主要的潜在原因[2,4]。定期使用有效的跳蚤预防药物和环境控制可以显著降低复发风险，因为跳蚤过敏引起的严重瘙痒可能导致大量脱发和热点[4]。

全面的过敏管理对预防至关重要。患有异位性皮炎的犬应在进入过敏季节前控制好过敏[1]。环境控制措施包括维持适当的美容护理习惯，特别是确保长毛、厚毛犬彻底干燥，以防止皮肤上水分滞留[1]。

管理潜在的医疗状况，如甲状腺功能减退症或肾上腺皮质功能亢进症，对预防复发至关重要[1,2]。定期的兽医监测和对内分泌疾病的适当治疗可以降低继发细菌感染的易感性。

当得到适当管理时，脓皮创伤性皮炎的预后通常极好[2]。大多数病例通过适当治疗迅速缓解，通常在开始治疗后24-48小时内显示改善。在适当的伤口护理和全身治疗下，完全愈合通常在7-10天内发生。

关键的预后因素包括早期干预和识别潜在触发因素[1,2]。识别并控制根本原因的病例具有最佳的长期预后。然而，如果易感因素仍未解决，复发很常见[1]。患有季节性异位性皮炎的犬可能经历季节性复发，除非最小化过敏原暴露。

### Sources
[1] Common skin conditions in pets: https://www.dvm360.com/view/common-skin-conditions-in-pets
[2] Pyoderma in Dogs and Cats - Integumentary System: https://www.merckvetmanual.com/integumentary-system/pyoderma/pyoderma-in-dogs-and-cats
[3] Photobiomodulation with fluorescent light energy as a sole treatment option for pyotraumatic dermatitis: https://avmajournals.avma.org/view/journals/javma/263/7/javma.24.12.0820.xml
[4] Fleas: They are happiest at home: https://www.dvm360.com/view/fleas-they-are-happiest-home