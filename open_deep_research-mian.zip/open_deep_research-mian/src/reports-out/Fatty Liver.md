# 猫脂肪肝：一种危重的兽医急症

猫脂肪肝是影响伴侣猫的最常见且可能致命的肝脏疾病，需要立即识别和积极干预。这种代谢综合征发生在脂肪动员超过肝脏处理能力时，导致肝细胞内危险的甘油三酯积累。该病主要影响因压力或潜在疾病而长期厌食的超重中年猫。本报告探讨了成功治疗所必需的病理生理学、临床表现和循证管理策略。重点关注领域包括原发性和继发性形式的鉴别诊断、通过饲管管理进行的关键营养支持方案，以及影响75-88%生存率的预后因素，这些生存率可通过及时、全面的治疗实现。

## 疾病概述

猫脂肪肝（FHL）是猫最常见的获得性且可能致命的肝脏疾病，代表一种多因素综合征[1]。该病的特征是肝细胞内甘油三酯积累，数量超过正常肝脏脂肪含量（低于5%），可能使肝脏重量增加一倍或两倍[2]。

当外周脂肪动员超过肝脏重新分配或利用脂肪进行β-氧化的能力时，该综合征就会发展，导致肝细胞胞质因甘油三酯储存而显著扩张[1]。在过度肥胖的猫中，通常由引起厌食或食物剥夺的原发疾病过程为脂肪肝的发生奠定基础。

**流行病学背景**

脂肪肝影响所有年龄段的猫，中位年龄约为7岁，大多数病例发生在4-15岁之间[2][6]。肥胖的母猫风险最大，尽管似乎没有明显的品种偏好，家养短毛猫常受影响[2][6]。除了母猫与肥胖相关的风险外，该病没有特定的性别倾向。

肥胖是主要风险因素，因为过度肥胖的猫具有增加的外周脂肪储存，在食物摄入减少期间可以迅速动员[2]。环境压力如强制减重、搬家、新引入宠物或寄养可能触发易感动物的综合征[1]。

### Sources
[1] Feline Hepatic Lipidosis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/feline-hepatic-lipidosis
[2] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[6] Hepatic lipidosis: Winning strategies (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-winning-strategies-proceedings

## 常见病原体

猫的脂肪肝根据潜在病因分为原发性或继发性。原发性脂肪肝发生在没有可识别的基础疾病过程的情况下，通常由其他方面健康的猫长期厌食、压力或突然饮食变化触发[1]。

继发性脂肪肝是引起厌食和代谢功能障碍的基础疾病过程的结果[1]。最相关的疾病包括炎症性肠病、胆管肝炎和胰腺炎——这些疾病通常同时发生，被称为"猫三联炎综合征"[2]。

胆管肝炎经常导致继发性脂肪肝的发展。中性粒细胞性胆管肝炎通常涉及细菌病原体，包括大肠杆菌、肠杆菌属、葡萄球菌属、溶血性链球菌属、拟杆菌属和梭菌属[1]。这些肠道细菌通过胆总管上行，由猫的胰腺和胆管之间的解剖连接促进[5]。

胰腺炎常与脂肪肝同时发生[2]。研究表明，83%的慢性胆道疾病猫同时患有炎症性肠病，50%同时患有胰腺炎[1]。这种三联关系表明涉及胰腺和胆管汇合的共同解剖通路的共享病理生理机制[5]。

其他可触发继发性脂肪肝的全身性疾病包括肿瘤（特别是淋巴瘤）、糖尿病、甲状腺功能亢进、肾病和心血管疾病[1]。这些疾病促进厌食和代谢压力，当肝脏的分散机制不堪重负时，导致过度的外周脂肪分解和肝内甘油三酯积累[3]。

### Sources

[1] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[2] Managing pancreatitis in cats (Proceedings): https://www.dvm360.com/view/managing-pancreatitis-cats-proceedings
[3] Hepatic lipidosis (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-proceedings
[4] Diagnosing and managing feline pancreatitis (Sponsored by IDEXX Laboratories): https://www.dvm360.com/view/diagnosing-and-managing-feline-pancreatitis-sponsored-idexx-laboratories
[5] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings

## 临床症状和体征

猫脂肪肝呈现多种临床表现，从微妙的早期迹象到严重的全身性疾病。最显著的临床特征包括超过体重25%的显著体重减轻，可能包括脱水不足[1]。猫通常表现出不同程度的嗜睡、呕吐和流涎，约70%的病例中可见黄疸[2]。

厌食是一个标志性症状，通常在就诊前持续1-2周或更长时间[2]。受影响的猫可能显示肝肿大，可触及肝缘，虚弱伴特征性颈部腹屈（特别是在严重低钾血症存在时），以及苍白[1]。其他体征包括胃轻瘫、因电解质失衡引起的肠梗阻，以及尽管外周脂肪消耗但仍保留网膜和镰状脂肪[1]。

肝性脑病虽然在猫中不如狗常见，可能表现为流涎、迟钝和共济失调[1]。由于肠肝胆汁酸循环中断导致的维生素K不足可能出现出血倾向[1]。大多数受影响的猫是中年猫，没有特定的品种偏好，但历史上肥胖猫似乎易患[2]。

临床表现常包括非特异性体征，如食欲下降、间歇性呕吐或腹泻、被毛不良和多尿/多饮[3]。体格检查可能显示肌肉消耗、皮脂溢和脱水[3]。患有严重电解质紊乱的猫可能表现出极度虚弱、应激耐受性有限以及在处理过程中呼吸窘迫[1]。

### Sources
[1] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies
[2] Feline Hepatic Lipidosis - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
[3] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings

## 诊断方法

诊断猫脂肪肝需要结合临床评估、实验室评估和影像学技术的系统方法。诊断通常通过临床表现、生化特征和超声检查结果建立，而非侵入性程序。

**临床表现评估**
体格检查显示关键发现，包括黄疸、肝肿大和超过体重25%的显著体重减轻[2]。受影响的猫常表现为嗜睡、呕吐，以及尽管外周消耗但仍保留网膜脂肪。肥胖猫厌食的临床病史强烈提示脂肪肝[3]。

**实验室检查结果**
生化特征显示特征性模式，碱性磷酸酶（ALP）显著升高，丙氨酸氨基转移酶（ALT）轻度至中度升高，以及高胆红素血症[1][2]。重要的是，γ-谷氨酰转移酶（GGT）浓度保持正常或仅轻微增加，这区别于胆管炎（GGT通常超过ALP升高）[1][2]。全血细胞计数显示非再生性贫血和异形红细胞症。

**影像学技术**
腹部超声检查具有诊断价值，显示与镰状脂肪和脾脏相比均质高回声肝实质，以及主观肝肿大[2]。这种高回声反映肝细胞内脂肪积累。

**细胞学用于确诊**
在给予维生素K后，细针肝穿刺抽吸细胞学提供确诊，显示>80%的肝细胞存在显著的脂质空泡扩张[2]。肝活检对诊断非必需，但如果基础并发疾病需要组织病理学评估，则可能需要。

### Sources
[1] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings
[2] Feline Hepatic Lipidosis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
[3] Clinical approach to icterus in the cat (Proceedings): https://www.dvm360.com/view/clinical-approach-icterus-cat-proceedings

## 治疗选择

猫脂肪肝的治疗需要积极的营养支持和全面的支持性护理。治疗的基石是通过饲管给予肠内营养，因为强制喂食和食欲刺激剂单独使用不足以满足热量需求[1]。

**营养支持**

初始喂养应从鼻食管管开始以便立即实施， later transitioning to larger-bore esophagostomy or gastrostomy tubes for long-term management [1]. 喂养方案第一天从休息能量需求的25-33%开始，在2-3天内逐渐增加到全量需求[1]。饮食应富含蛋白质（30-40%）、脂肪适中（50%）和低碳水化合物（20%），以满足猫的营养需求[1]。

**液体和电解质管理**

使用平衡电解质溶液进行积极的液体治疗至关重要，避免使用含乳酸或高葡萄糖的液体，这些可能加重肝功能障碍[1][4]。密切监测钾、磷和镁水平至关重要，因为在营养重新引入期间可能发生再喂养综合征[1][2]。低钾血症尤其重要，因为它代表一个负面的预后指标[1]。

**其他治疗**

使用甲氧氯普胺作为持续速率输注（1-2 mg/kg/天）的止吐治疗可有效控制呕吐[1]。维生素补充包括皮下注射维生素K1治疗凝血病、B族复合维生素治疗缺乏症，以及钴胺素治疗已证实的缺乏症[1][7]。支持性补充剂如L-肉碱（250-500 mg/天）、牛磺酸（250-500 mg/天）和S-腺苷甲硫氨酸可能有助于肝脏恢复[7]。

### Sources
[1] Hepatic lipidosis maximizing a successful outcome: https://www.dvm360.com/view/hepatic-lipidosis-maximizing-successful-outcome-proceedings
[2] Feeding tube management and complications: https://www.dvm360.com/view/feeding-tube-management-and-complications-proceedings
[3] Nutritional management of pancreatitis and concurrent: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.11.0641.xml
[4] Feline liver disease: https://www.dvm360.com/view/feline-liver-disease-proceedings
[5] ACVC 2017: Critical Care Nutrition: https://www.dvm360.com/view/critical-care-nutrition
[6] Incorporating enteral nutrition into your practice: https://www.dvm360.com/view/incorporating-enteral-nutrition-your-practice
[7] Hepatic lipidosis: Winning strategies: https://www.dvm360.com/view/hepatic-lipidosis-winning-strategies-proceedings

## 预防措施

体重管理对预防猫脂肪肝至关重要，因为肥胖是一个主要风险因素[1]。最成功的减重计划包括热量限制和运动，治疗性减重饮食提供足够的蛋白质水平，同时保持适当的营养平衡。进行减重的肥胖猫需要仔细监测，以防止在减重过程中发生脂肪肝[1]。

环境压力减轻在预防中起着关键作用。压力事件如使用不可接受的食物替代品强制减重、搬家、新引入宠物、家庭成员丧失、寄养或意外禁闭可能触发导致脂肪肝综合征的厌食[2]。最小化这些压力源并提供稳定的环境有助于防止引发脂肪肝的一系列事件。

适当的饮食过渡是必要的预防措施。在7-10天内逐渐改变饮食可防止可能导致长期厌食的拒食[1]。当需要饮食调整时，确保适口性和维持足够的卡路里摄入可防止与饥饿相关的代谢紊乱。

厌食猫的早期干预方案是预防的基础。任何经历超过2-3天厌食的猫需要通过饲管立即提供营养支持，而不是依赖食欲刺激剂[2]。监测高风险猫包括定期体重评估和在食欲下降时及时干预，特别是代表最高风险群体的超重中年至老年猫。

### Sources

[1] Merck Veterinary Manual Nutrition in Disease Management in Small Animals: https://www.merckvetmanual.com/management-and-nutrition/nutrition-small-animals/nutrition-in-disease-management-in-small-animals

[2] Merck Veterinary Manual Feline Hepatic Lipidosis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis

## 鉴别诊断

猫脂肪肝的鉴别诊断需要仔细区分其他肝脏疾病和引起厌食和黄疸的全身性疾病[1]。最重要的鉴别包括其他原发性肝脏疾病和厌食的继发原因。

**原发性肝脏鉴别**包括胆管炎/胆管肝炎，其呈现类似的黄疸，但通常显示相对于ALP更高的GGT升高，这与脂肪肝不同（脂肪肝中GGT正常或仅轻微升高）[1]。肝肿瘤，特别是淋巴瘤，必须通过细胞学检查或活检排除[2]。炎症性肝病在细胞学上可能显示混合性炎症浸润，与脂肪肝中主要的脂质空泡形成对比[2]。

**区分原发性和继发性脂肪肝**对预后和治疗至关重要。继发性脂肪肝伴有基础疾病，如糖尿病、胰腺炎、炎症性肠病或引起厌食的全身性疾病[3]。这些疾病需要同时管理，可能预后较差，伴有胰腺炎的猫恢复率为20%，而单纯原发性脂肪肝的恢复率>50%[3]。

**引起厌食的全身性疾病**包括肾病、呼吸系统疾病和内分泌疾病，这些疾病可触发继发性脂肪肝[4]。非常高的ALP伴正常GGT的生化模式，结合适当的临床特征和肝脏高回声的超声检查结果，有助于将特发性脂肪肝与这些疾病区分开[1]。

### Sources
[1] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings
[2] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[3] Hepatic lipidosis: Winning strategies (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-winning-strategies-proceedings
[4] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies

## 预后

当及时实施积极治疗时，猫脂肪肝有极好的预后[2]。通过全面的营养支持和定制的重症监护，严重受影响的猫可达到75-80%的生存率，而仅靠营养支持的生存率仅为50%[2]。最近研究报告生存率在60-88%之间，一些资料称早期干预时恢复率为80-88%[4,6]。

早期诊断和立即营养干预显著改善结果[4]。反应良好的猫通常在治疗开始后7-10天内胆红素浓度下降50%[4,6]。预后不良的猫通常在第一周内死亡，使这一初始期成为监测的关键时期[4,6]。

几个预后因素影响恢复。就诊时较高的中位钾水平和血细胞比容，以及较年轻的年龄，与生存率呈正相关[4]。长期低钾血症显著增加死亡风险[2]。与单纯脂肪肝猫相比，并发胰腺炎显著恶化预后[3,4]。并发疾病的存在通常对生存率产生负面影响[3]。

必要的监测参数包括每日评估电解质（特别是钾和磷）、PCV/TP、血糖，以及在关键的重新喂养期间仔细观察并发症[4,6]。猫通常需要饲管喂养3-8周，预期完全恢复且无残留肝功能障碍[4,6]。除非诱发原因仍未解决，否则复发不太可能。

### Sources
[1] Survival analysis to evaluate associations - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/252/6/javma.252.6.710.xml
[2] Feline Hepatic Lipidosis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
[3] Hepatic lipidosis (Proceedings): https://www.dvm360.com/view/hepatic-lipidosis-proceedings
[4] Hepatic lipidosis maximizing a successful outcome: https://www.dvm360.com/view/hepatic-lipidosis-maximizing-successful-outcome-proceedings
[5] Retrospective evaluation of enteral nutrition supplementation: https://avmajournals.avma.org/view/journals/javma/aop/javma.24.07.0494/javma.24.07.0494.xml
[6] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings