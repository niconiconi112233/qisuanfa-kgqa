# 伴侣动物出血性胃肠炎

出血性胃肠炎，现在更准确地称为急性出血性腹泻综合征（AHDS），是小动物临床中最关键的胃肠道急症之一。该病主要影响犬，特别是幼龄动物和玩具品种犬，表现为特征性的大量血性腹泻和严重血液浓缩，可迅速发展为低血容量性休克。

对于兽医从业人员来说，理解AHDS至关重要，因为早期识别和及时治疗显著影响患者预后，当开始适当治疗时死亡率低于10%。本报告探讨了涉及产气荚膜梭菌和病毒病原体的复杂病因学、区分AHDS与其他出血性疾病的独特临床表现、强调液体治疗的循证治疗方案，以及包括细小病毒性肠炎和凝血病在内的关键鉴别诊断。

## 摘要

AHDS是一种具有多因素病因的复杂综合征，其中产气荚膜梭菌和病毒病原体导致肠道通透性增加和特征性液体流失。该病表现出明显的品种易感性，特别是影响约克夏梗和迷你贵宾犬等玩具品种，幼龄犬风险最高。

诊断主要依靠临床表现结合特征性血液浓缩（PCV >60%），尽管存在出血性损失，这使AHDS与其他血性腹泻原因区分开来。治疗成功取决于积极的静脉液体治疗，抗菌药物仅保留用于显示全身性受累的严重病例。最近的证据对在无并发症病例中常规使用抗生素提出了质疑。

| 关键鉴别诊断 | 鉴别特征 |
|--------------|----------|
| 细小病毒 | 中性粒细胞减少症 vs. 血液浓缩 |
| 胰腺炎 | 酶升高，不同疼痛模式 |
| 凝血病 | 凝血参数异常 |

早期干预可实现良好预后，死亡率低于10%，强调了在急诊实践方案中及时识别和适当液体复苏的关键重要性。

## 疾病概述和流行病学

所提供的来源材料不包含关于猫出血性胃肠炎（HGE）的信息，现有章节内容已根据《默克兽医手册》提供了全面概述。当前内容准确定义急性出血性腹泻综合征（AHDS）为首选的现代术语，并提供详细的流行病学信息[1]。

现有章节正确指出，AHDS主要发生于犬，中位年龄为5岁的幼龄犬最易受影响[1]。小型和玩具品种犬表现出明显的易感性，包括约克夏梗、迷你品犬、迷你雪纳瑞、迷你贵宾犬和马尔济斯犬[1]。这代表了兽医应认识的重要品种特异性流行病学模式。

病理生理学描述准确解释了导致液体、蛋白质和血液流失到肠腔的肠道通透性增加机制[1]。急性黏膜出血性坏死和中性粒细胞炎症的组织学发现主要影响大肠而非胃，支持从出血性胃肠炎更名为AHDS[1]。

该病被正确识别为非传染性疾病，这对客户教育和管理决策很重要[1]。病因尚不明确，可能与产气荚膜梭菌感染或超敏反应有关，反映了当前兽医界对该综合征的理解。

### Sources

[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs

## 病因学和病理生理学

出血性胃肠炎的病因和发病机制仍不完全清楚，现已确定了多种致病因子和疾病机制。**产气荚膜梭菌**是最受牵连的病原体，特别是*netF*毒素[1]。然而，由于*产气荚膜梭菌*可从超过80%的正常犬中分离出来，发病机制仍然复杂[2]。

继发性细菌增殖常见，肠道产气荚膜梭菌在各种触发因素后经常增殖，包括抗生素暴露、饮食改变、pH值改变、免疫抑制或并发病毒感染[2]。**病毒病原体**也有显著贡献，犬细小病毒导致肠隐窝上皮细胞破坏、淋巴细胞耗竭和中性粒细胞减少症[4]。已鉴定出犬肠道冠状病毒的强毒株引起类似细小病毒感染的严重疾病，包括出血性腹泻、白细胞减少症和高死亡率[1][3]。

主要病理生理机制涉及**肠道通透性增加**，导致液体、血浆蛋白和红细胞泄漏到肠腔[1][5]。这导致特征性血液浓缩和出血性腹泻。该病主要影响大肠，急性肠黏膜出血性坏死和中性粒细胞炎症是主要组织学病变[1]。犬细小病毒特异性靶向小肠隐窝上皮细胞、淋巴造血组织和骨髓的快速分裂细胞[2]。

### Sources
[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[2] Canine Parvovirus Infection (Parvoviral Enteritis in Dogs): https://www.merckvetmanual.com/digestive-system/infectious-diseases-of-the-gastrointestinal-tract-in-small-animals/canine-parvovirus-infection-parvoviral-enteritis-in-dogs
[3] Update on viral enteritis (Proceedings): https://www.dvm360.com/view/update-viral-enteritis-proceedings
[4] Managing patients with parvoviral enteritis (Proceedings): https://www.dvm360.com/view/managing-patients-with-parvoviral-enteritis-proceedings
[5] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs

## 临床表现和诊断

犬的急性出血性腹泻综合征（AHDS）表现为**急性发作的大量出血性腹泻**，常被描述为类似覆盆子果酱，特别影响幼龄犬和小型至玩具品种犬[1]。**呕吐、厌食、嗜睡和腹痛**是常见的并发症状，呕吐通常先于血性腹泻出现[1]。明显的液体流失可在临床上可识别的脱水发生前导致低血容量性休克[1]。

诊断主要依靠**品种特征和急性发作的临床症状伴血液浓缩**（PCV通常>60%）和正常或轻度降低的总血浆蛋白浓度[1]。尽管存在明显的胃肠道出血，这些**PCV/总固体结果始终存在**，表明严重容量不足伴大量蛋白质损失超过红细胞损失[1]。

**大肠腹泻特征**有助于区分AHDS与其他疾病，包括频繁去猫砂盆、里急后重和血性黏液便[2]。在猫中，腹泻通常是混合性肠道的，具有小肠和大肠特征[2]。**腹部超声**可评估肠壁厚度并排除其他原因，因为AHDS的异常应仅限于弥漫性肠梗阻和充满液体的肠袢[1][3]。

**鉴别诊断包括细菌性、病毒性（细小病毒、冠状病毒）和寄生虫性胃肠炎；继发性胃肠道受累的全身性疾病（肾上腺皮质功能减退症）；凝血病；严重胃肠道溃疡；肿瘤；胰腺炎和胃肠道穿孔**[1]。

### Sources
[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs
[2] Feline diarrhea: Let the diagnostic clues flow: https://www.dvm360.com/view/feline-diarrhea-let-the-diagnostic-clues-flow
[3] GI hemorrhage (Proceedings): https://www.dvm360.com/view/gi-hemorrhage-proceedings

## 治疗方案和管理

**及时的静脉液体治疗是出血性胃肠炎治疗的基石**[1]。晶体液给药速率应基于患者的灌注状态、脱水程度和持续损失。有明显低蛋白血症或休克的犬可能受益于合成或天然胶体治疗，包括储存或新鲜冷冻血浆[1]。

**不建议对轻中度病例常规使用抗菌药物治疗**。最近的证据表明，在无菌性HGE犬中，阿莫西林/克拉维酸治疗不影响死亡率、住院时间或临床症状严重程度[1]。然而，对于有全身性疾病临床症状、严重中性粒细胞增多症（>25 × 10⁹/L）、中性粒细胞减少症或退行性核左移的严重病例，应使用胃肠外抗菌药物。推荐方案包括氨苄西林20-40 mg/kg静脉注射每6-8小时一次，对于脓毒症患者使用恩诺沙星5-20 mg/kg静脉注射每24小时一次以覆盖革兰氏阴性菌[1]。

**支持性护理措施包括根据血清水平补充电解质**，如氯化钾（20-40 mEq/L），以及为低血糖患者补充葡萄糖（2.5-5%）。止吐治疗和饮食管理遵循急性胃肠炎的标准方案[1]。

**关键监测参数包括红细胞压积（通常>60%）、总血浆蛋白、血糖和电解质水平**。灌注参数、心率和血压的连续评估指导液体治疗调整[1]。

### Sources
[1] Merck Veterinary Manual Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs

## 预防、预后和鉴别诊断

**预防措施**
出血性胃肠炎缺乏特定的预防方案，因为它不被认为是传染性疾病[1]。初级预防侧重于避免潜在触发因素，包括饮食不当、压力，并确保充分的疫苗接种状态。幼龄犬和玩具品种犬（约克夏梗、迷你品犬、马尔济斯犬）面临更高风险[1]。

**预后**
经过适当治疗预后良好，住院犬的死亡率低于10%[1]。及时的静脉液体治疗至关重要，因为未治疗病例具有高死亡风险。严重并发症可包括明显低蛋白血症、DIC、脓毒症和低血容量性休克[1]。

**关键鉴别诊断**
关键鉴别诊断包括犬细小病毒性肠炎，其表现为类似的出血性腹泻，但通常显示中性粒细胞减少症而非AHDS中特征性的血液浓缩[1]。必须考虑急性胰腺炎，特别是在猫中，它经常作为"三体炎"的一部分与胆管炎和炎症性肠病同时发生。来自杀鼠剂中毒、血小板减少症或其他出血性疾病的凝血病需要通过凝血测试评估[1]。其他考虑包括全身性疾病如肾上腺皮质功能减退症、严重胃肠道溃疡、肿瘤和任何病因的胃肠道穿孔[1]。

### Sources
[1] Acute Hemorrhagic Diarrhea Syndrome in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/acute-hemorrhagic-diarrhea-syndrome-in-dogs