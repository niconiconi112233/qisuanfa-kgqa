# 伴侣动物血小板增多症

血小板增多症定义为血小板计数高于正常参考范围，是犬和猫中一项重要的血液学发现，需要仔细的临床评估。这种情况主要表现为继发于潜在炎症过程、肿瘤形成或组织损伤的反应性血小板增多症，而非原发性骨髓疾病。了解血小板增多症的病理生理学、诊断方法和治疗策略对兽医从业者至关重要，因为该病症的临床意义主要取决于识别和治疗根本原因，同时在严重病例中监测潜在的血栓并发症。

## 疾病概述

**定义**

血小板增多症定义为血小板计数高于该物种的正常参考范围（默克兽医手册，2024）。在犬中，正常血小板计数范围为200,000-500,000个细胞/μL，而猫的正常范围较高，为300,000-800,000个细胞/μL（默克兽医手册，2024）。当犬的血小板计数超过600,000-700,000个细胞/μL，猫的血小板计数超过800,000-1,000,000个细胞/μL时，通常诊断为血小板增多症（DVM360，2024）。

该病症分为两大类：原发性（特发性）血小板增多症和继发性（反应性）血小板增多症。原发性血小板增多症源于影响巨核细胞增殖的克隆性骨髓疾病，而继发性血小板增多症则是对潜在疾病（如炎症、组织损伤或慢性疾病）的生理反应（DVM360，2024）。

**流行病学背景**

在伴侣动物中，继发性血小板增多症远比原发性血小板增多症常见，反应性形式占兽医实践中遇到的绝大多数病例（DVM360，2024）。与人类患者相比，包括特发性血小板增多症在内的原发性血小板增多症在犬和猫中极为罕见（默克兽医手册，2024）。

该病症影响犬和猫，反应性形式没有明显的品种或年龄倾向，但根本原因可能显示人口统计学模式。术后血小板增多症，特别是脾切除术后，是兽医医学中有充分记录的现象（JAVMA，2020）。患病率因研究人群和实践环境中的潜在疾病状况而有显著差异。

## 常见病原体

犬和猫的血小板增多症很少由原发性感染病原体引起。与血小板减少症不同，后者通常由各种感染后的免疫介导破坏引起，血小板增多症通常代表对潜在疾病的反应性过程，而非直接由病原体诱导的血小板过度产生[1]。

伴侣动物的大多数血小板增多症病例是继发性（反应性）的，而非感染性起源。血小板计数升高通常作为对炎症、组织损伤或慢性疾病状态的生理反应而发展[2]。直接刺激巨核细胞增殖和血小板产生的原发性感染原因在兽医医学中极为罕见。

然而，某些立克次体感染可能在恢复期间接导致血小板增多症。犬埃立克体、血小板无形体和吞噬细胞无形体感染通常在急性感染期间引起血小板减少症[3]。在恢复期或慢性阶段，当骨髓补偿先前的血小板破坏时，可能偶尔发展为反应性血小板增多症。

细菌感染很少通过全身性炎症反应引发反应性血小板增多症，这是间接效应而非病原体直接侵入骨髓[4]。缺乏特定的病毒或细菌病原体作为主要原因，这使得血小板增多症与犬和猫的其他血液学疾病有所区别。

### Sources
[1] Transfusion support of the bleeding patient: Part II (Proceedings): https://www.dvm360.com/view/transfusion-support-bleeding-patient-part-ii-proceedings
[2] Platelets in Animals: https://www.merckvetmanual.com/circulatory-system/hematopoietic-system-introduction/platelets-in-animals
[3] Ehrlichiosis, Anaplasmosis, and Related Infections in Animals: https://www.merckvetmanual.com/generalized-conditions/rickettsial-diseases/ehrlichiosis-anaplasmosis-and-related-infections-in-animals
[4] Overcoming the diagnostic and therapeutic challenges of canine immune-mediated thrombocytopenia: https://www.dvm360.com/view/overcoming-diagnostic-and-therapeutic-challenges-canine-immune-mediated-thrombocytopenia

## 临床症状和体征

现有部分全面涵盖了血小板增多症的临床表现。根据可用的来源材料，我可以通过对亚临床表现和物种特异性表现的额外见解来增强内容。

**无症状表现**

许多患有血小板增多症的犬尽管血小板计数显著升高，但仍完全无症状[5]。这种亚临床表现在反应性血小板增多症中特别常见，其中潜在疾病可能是主要的临床关注点，而非升高的血小板计数本身。

**非特异性临床体征**

当出现临床表现时，它们通常是非特异性的，并且与潜在病因相关，而非直接由血小板增多症引起[5]。犬可能表现出嗜睡、虚弱、厌食或与导致反应性血小板增多症的原发疾病过程相关的体征。

**血栓风险评估**

严重血小板增多症的主要临床关注点是因活性血小板数量增加而导致过度凝血[5]。然而，自发性血栓事件在犬中很少见，通常仅在血小板计数超过1,000,000/μL并结合其他风险因素（如脱水）时发生[5]。大多数反应性血小板增多症病例不会达到这些临界阈值。

**矛盾性出血**

有趣的是，一些患有反应性血小板增多症的犬可能因伴随的血小板功能障碍而经历出血倾向，尽管血小板数量升高[5]。这种矛盾性出血模式可能使临床评估和鉴别诊断复杂化。

犬和猫血小板增多症的临床表现高度可变，许多病例在出现并发症或通过常规诊断测试发现潜在疾病之前保持亚临床状态。

### Sources
[1] Excessive Immune Function in Animals: https://www.merckvetmanual.com/immune-system/immunologic-diseases/excessive-immune-function-in-animals
[2] Overcoming the diagnostic and therapeutic challenges of canine immune-mediated thrombocytopenia: https://www.dvm360.com/view/overcoming-diagnostic-and-therapeutic-challenges-canine-immune-mediated-thrombocytopenia
[3] Arterial Thromboembolism in Dogs and Cats - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/various-cardiovascular-diseases-in-dogs-and-cats/arterial-thromboembolism-in-dogs-and-cats
[4] Postoperative thrombocytosis and thromboelastographic evidence of hypercoagulability in dogs undergoing splenectomy for splenic masses in: Journal of the American Veterinary Medical Association Volume 256 Issue 1 (): https://avmajournals.avma.org/view/journals/javma/256/1/javma.256.1.85.xml
[5] Increased number of platelets call for review of thrombocytosis: https://www.dvm360.com/view/increased-number-platelets-call-review-thrombocytosis
[6] Immune-mediated thrombocytopenia--pathophysiology and diagnosis (Proceedings): https://www.dvm360.com/view/immune-mediated-thrombocytopenia-pathophysiology-and-diagnosis-proceedings
[7] Platelet Disorders in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/platelet-disorders-in-animals
[8] Immune-mediated thrombocytopenia and immune-mediated arthritis (Proceedings): https://www.dvm360.com/view/immune-mediated-thrombocytopenia-and-immune-mediated-arthritis-proceedings
[9] Managing immune-mediated thrombocytopenia and immune-mediated arthritis (Proceedings): https://www.dvm360.com/view/managing-immune-mediated-thrombocytopenia-and-immune-mediated-arthritis-proceedings

## 诊断方法

全血细胞计数（CBC）是识别伴侣动物血小板增多症的主要诊断工具[2]。CBC提供必要的血小板计数测量，正常犬血小板计数范围为200,000-500,000个细胞/μL，猫计数范围为300,000-800,000个细胞/μL[1]。当血小板计数超过这些参考范围时，诊断为血小板增多症，通常犬超过600,000-700,000个细胞/μL，猫超过800,000-1,000,000个细胞/μL[2]。

临床表现评估侧重于识别可能导致继发性血小板增多症的潜在疾病[2]。兽医通过体格检查和病史采集评估炎症、肿瘤形成或慢性疾病的体征。血涂片检查允许对血小板进行形态学评估，并检测可能错误升高自动化计数的聚集现象[1]。血小板聚集在猫中特别常见，可能导致机器生成的计数错误地偏低[1]。

额外的实验室检测包括炎症标志物，如C反应蛋白，以识别潜在的炎症过程[3]。在疑似原发性血小板增多症的病例中，可能需要进行骨髓检查，尽管这种情况在兽医患者中很少见[6]。包括放射学和超声在内的影像学检查有助于识别导致反应性血小板增多症的潜在肿瘤或炎症性疾病[3]。

这些诊断方法共同实现了原发性和继发性血小板增多症的区分，同时识别需要治疗的潜在病因。

### Sources
[1] Merck Veterinary Manual Platelets in Animals: https://www.merckvetmanual.com/circulatory-system/hematopoietic-system-introduction/platelets-in-animals
[2] DVM 360 Increased number of platelets: https://www.dvm360.com/view/increased-number-platelets-call-review-thrombocytosis
[3] Merck Veterinary Manual Clinical Hematology: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/clinical-hematology
[4] Skills Laboratory Bone Marrow Samples: https://www.dvm360.com/view/skills-laboratory-how-collect-diagnostic-bone-marrow-samples

## 治疗选择

伴侣动物血小板增多症的治疗主要针对根本原因，而非升高的血小板计数本身[1]。原发性血小板增多症需要特定管理以预防血栓并发症。羟基脲（15-30 mg/kg口服每日一次）是特发性血小板增多症的一线细胞减少治疗，有助于减少血小板产生[1]。

继发性血小板增多症治疗侧重于管理诱发性疾病。当炎性疾病引发反应性血小板增多症时，皮质类固醇的抗炎治疗可能有益[1]。对于免疫介导性疾病，包括泼尼松（1-2 mg/kg口服每日两次）在内的免疫抑制方案可能有助于控制基础疾病和继发性血小板升高[4]。

当血栓风险升高时，可考虑使用阿司匹林（犬0.5-10 mg/kg口服每日一次；猫81 mg口服每72小时一次）或氯吡格雷（犬1.1-3 mg/kg口服每日一次；猫18.75 mg口服每日一次）进行抗血小板治疗[2][3]。对于有多种高凝状态的患者，使用普通肝素或低分子量肝素（达肝素犬100-175 U/kg皮下每8小时一次；猫75 U/kg皮下每6小时一次）的抗凝治疗提供血栓预防[2][3]。

支持性护理包括监测血栓事件和保持充分水合以防止血液粘度增加[1]。定期监测全血细胞计数对于评估治疗反应和相应调整治疗至关重要。

### Sources
[1] Pathological Thrombosis in Animals - Circulatory System - Merck Veterinary Manual: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/pathological-thrombosis-in-animals
[2] Antithrombotic Drugs-Merck Veterinary Manual: https://www.merckvetmanual.com/multimedia/table/antithrombotic-drugs
[3] Updates in anticoagulant therapy (Proceedings): https://www.dvm360.com/view/updates-anticoagulant-therapy-proceedings
[4] Transfusion support of the bleeding patient: Part II: https://www.dvm360.com/view/transfusion-support-bleeding-patient-part-ii-proceedings



## 鉴别诊断

犬和猫的血小板增多症必须与其他血小板疾病和导致血小板计数升高的疾病相区分。反应性血小板增多症是最常见的形式，继发于脾切除术、兴奋、运动、骨折、高循环糖皮质激素水平、失血后事件、骨髓纤维化和缺铁性贫血[1]。

原发性血小板增多症代表更严重的疾病，表现为特发性血小板增多症或与其他骨髓增殖性疾病相关，包括真性红细胞增多症、慢性髓系白血病和骨髓纤维化[1]。患有特发性血小板增多症的犬可能经历出血或凝血问题，临床表现包括脾肿大、腹部膨胀或便血，尽管有些无症状[1]。

关键区分因素包括血小板计数幅度和相关临床发现。除非血小板计数超过1,000,000/μL并结合其他风险因素（如脱水），否则反应性血小板增多症很少引起并发症[1]。相比之下，当出现极高的血小板计数而没有可识别的反应性原因时，应怀疑原发性血小板增多症[6]。

免疫介导性血小板减少症（IMTP）需要仔细区分，因为它表现为血小板计数降低而非升高[4]。IMTP通常显示血小板计数低于50,000/μL，而血小板增多症则表现为计数升高[4]。临床出血表现也有所不同，IMTP引起点状出血和粘膜出血，而血小板增多症在极高计数时可能引起血栓并发症[4]。

对于有临床出血体征、凝血筛查试验正常、血小板计数充足和颊粘膜出血时间延长的动物，应考虑冯·维勒布兰德病[3]。这是血小板数量正常情况下异常出血的最常见原因，将其与血小板增多症和血小板减少症区分开来[3]。

### Sources

[1] Increased number of platelets call for review of thrombocytosis: https://www.dvm360.com/view/increased-number-platelets-call-review-thrombocytosis

[2] Platelet Disorders in Animals - Circulatory System: https://www.merckvetmanual.com/circulatory-system/hemostatic-disorders/platelet-disorders-in-animals

[3] Three-minute peripheral blood film evaluation: The erythron and thrombon: https://www.dvm360.com/view/three-minute-peripheral-blood-film-evaluation-erythron-and-thrombon

[4] Anemias and thrombocytopenias (Proceedings): https://www.dvm360.com/view/anemias-and-thrombocytopenias-proceedings