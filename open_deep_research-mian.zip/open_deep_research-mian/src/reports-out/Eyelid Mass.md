# 了解犬猫眼睑肿块

眼睑肿块是小动物临床中最常见的眼科疾病之一，在犬和猫之间具有显著不同的临床意义。虽然约75-85%的犬眼睑肿块是良性睑板腺腺瘤和乳头状瘤，对单纯切除反应良好，但猫眼睑肿块主要为恶性，其中以鳞状细胞癌最为常见。这种明显的物种差异从根本上改变了诊断和治疗方法。

本报告探讨了最常见的眼睑肿瘤类型及其特征表现，包括细针抽吸和组织病理学在内的基本诊断方法，从手术切除技术到冷冻疗法的全面治疗选择，以及关键的预防策略，重点关注紫外线暴露风险和品种易感性，这些因素影响长期预后和管理决策。

## 常见类型及临床特征

犬和猫最常见的眼睑肿块在物种间差异显著，具有独特的特征表现和生物学行为[1]。

**犬 - 最常见类型：**
睑板腺腺瘤是犬中最常见的眼睑肿瘤，占所有眼睑肿块的28.7%至60%[2][3]。这些良性肿块通常表现为棕色、增生性或菜花状生长物，涉及眼睑边缘和睑板腺[2][3]。它们在老年犬中最常见，且通常生长缓慢[2]。

鳞状乳头状瘤是第二常见类型，约占犬眼睑肿块的25%[3]。这些在结构上更具乳头状特征，可能起源于病毒[3]。

黑色素细胞瘤也约占病例的25%，魏玛猎犬和维兹拉犬似乎过度代表[3]。在犬中，眼睑黑色素瘤表现为良性，对切除或冷冻手术反应良好[3]。

其他不太常见的类型包括组织细胞瘤（在幼犬中表现为粉红色圆形肿块，可能自行消退）、纤维瘤、脂肪瘤、肥大细胞瘤、基底细胞瘤和鳞状细胞瘤，总共仅占病例的10%或更少[3]。

**猫 - 主要为恶性：**
与犬不同，大多数猫眼睑肿瘤是恶性的[3][8]。鳞状细胞癌是猫中最常报告的眼睑肿瘤[8]。其他恶性类型包括基底细胞癌、肥大细胞瘤、纤维瘤/纤维肉瘤、血管肉瘤、黑色素瘤、淋巴肉瘤和腺瘤[3]。

约75%-85%的犬眼睑肿块是良性的，而猫眼睑肿块由于其恶性潜力需要更积极的评估[3][4]。

### Sources
[1] Ophthalmic anatomy and diagnostics (Proceedings): https://www.dvm360.com/view/ophthalmic-anatomy-and-diagnostics-proceedings
[2] Skills Laboratory: Cryosurgery for eyelid masses: https://www.dvm360.com/view/skills-laboratory-cryosurgery-eyelid-masses
[3] Ocular neoplasia and treatment (Proceedings): https://www.dvm360.com/view/ocular-neoplasia-and-treatment-proceedings
[4] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings
[8] Use of a subdermal plexus flap to reconstruct an upper eyelid: https://avmajournals.avma.org/view/journals/javma/250/2/javma.250.2.211.xml

## 诊断方法与技术

眼睑肿块的临床检查始于详细的病史采集和系统的视觉评估。临床医生应评估对称性、肿块特征（大小、位置、颜色、硬度）以及是否存在分泌物或炎症等相关体征[1]。通过威胁反应进行视力测试和眼睑功能的基本神经评估应在检查早期进行[1]。

**细针抽吸和活检考虑因素**

细针抽吸（FNA）是一种低成本、快速的诊断方法，用于识别肿瘤类别，但不能确定组织学分级[1]。对于猫眼睑肿块，在清醒患者中进行FNA可能特别具有挑战性，通常需要镇静或麻醉以获得足够的样本[2]。然而，FNA可以有效区分炎症性和肿瘤性病变，当观察到典型细胞特征时可能提供推定诊断[3]。对于具有挑战性的解剖位置，使用超声引导可以提高诊断准确性并减少并发症[3]。

**组织病理学检查的重要性**

组织病理学仍然是眼睑肿块明确诊断的金标准[1]。对于大多数肿块，推荐进行深部切口活检，因为由于覆盖的炎症，浅表样本可能不具有诊断性[4]。大多数眼睑肿瘤需要活检以进行明确诊断和治疗计划[2]。适当的组织采样需要通过摄影或详细绘图记录肿瘤的位置和大小，以促进治疗计划[1]。切口活检对于管理客户对治疗结果和预后的期望特别有价值[5]。

**分期和高级诊断**

完整分期包括体格检查和淋巴结触诊、最低数据库（CBC、生化谱、尿液分析）和影像学研究[4]。对于侵袭性肿块，可能需要进行高级断面成像如CT或MRI，以确定范围并规划治疗方法[4]。对于疑似恶性肿块，应进行胸部X光检查和淋巴结细胞学评估以评估转移[4]。

### Sources
[1] Diagnosing and Treating Cancer in Companion Animals: https://www.dvm360.com/view/diagnosing-and-treating-cancer-in-companion-animals
[2] MSD Veterinary Manual Cancers and Tumors of the Eye in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/cancers-and-tumors-of-the-eye-in-dogs
[3] DVM 360 Practical Matters: Use caution when performing fine-needle aspiration biopsy of ventral neck masses in dogs: https://www.dvm360.com/view/practical-matters-use-caution-when-performing-fine-needle aspiration-biopsy-ventral-neck-masses-dogs
[4] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[5] DVM 360 In defense of the incisional biopsy in veterinary oncology cases: https://www.dvm360.com/view/defense-incisional-biopsy-veterinary-oncology-cases

## 治疗选择和手术技术

眼睑肿块的治疗取决于肿瘤大小、位置和疑似恶性程度。对于小于眼睑长度25%的肿块，单纯楔形切除可提供优异结果[1]。V形楔形的长度应是其基底宽度的两倍，以达到最佳美容效果[1]。使用双层闭合进行精确边缘对合至关重要，结膜使用可吸收缝线，皮肤使用不可吸收缝线，并在眼睑边缘使用8字形缝合模式[1]。

对于需要组织重建的较大肿块，先进技术包括H成形术和旋转皮瓣，但必须确保足够的血液供应以保证皮瓣存活[2]。替代治疗方式包括激光消融和冷冻疗法[2,6]。CO2激光消融可以从睑结膜表面进行，对边缘破坏最小，美容效果极佳[3]。冷冻疗法使用-196°C的液氮进行两次冻融循环，有效破坏组织同时保持眼睑边缘完整性[6]。冷冻治疗后可能出现暂时性肿胀和脱色素[6]。

术后护理需要局部和全身抗生素、疼痛管理和伊丽莎白圈保护[2]。复发率因技术而异：手术切除平均28个月复发，激光治疗18个月，冷冻疗法7个月[2]。完整的组织病理学评估至关重要，特别是在猫中，眼睑肿块经常是恶性的[4]。

### Sources

[1] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery
[2] Surgical techniques for the eyelid (Proceedings): https://www.dvm360.com/view/surgical-techniques-eyelid-proceedings
[3] Eyelid disease and surgery (Proceedings): https://www.dvm360.com/view/eyelid-disease-and-surgery-proceedings
[4] Ocular Neoplasia in Dogs - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/neoplasia-of-the-eye-and-associated-structures/ocular-neoplasia-in-dogs
[5] Managing common eyelid diseases (Proceedings): https://www.dvm360.com/view/managing-common-eyelid-diseases-proceedings
[6] Skills Laboratory: Cryosurgery for eyelid masses: https://www.dvm360.com/view/skills-laboratory-cryosurgery-eyelid-masses

## 预防、预后和管理

紫外线暴露是猫眼睑肿块的重要风险因素，特别是影响耳廓、耳前区域和眼睑的浅表性血管肉瘤[1]。色素沉着的浅色猫风险较高，慢性紫外线暴露可诱发这些肿瘤。建议对易感动物使用紫外线防护面罩以减少紫外线辐射暴露。

某些品种表现出对特定眼睑疾病的易感性。拳师犬、波士顿梗犬和拉布拉多猎犬显示肥大细胞瘤风险较高，而沙皮犬、松狮犬和寻血猎犬易患上睑内翻，需要手术矫正[5]。在犬中，睑板腺腺瘤和腺癌约占眼睑肿块的60%，大多数犬眼睑肿瘤（95%）是良性的[2][3]。

预后因肿瘤类型而异显著。猫皮肤肥大细胞瘤通常仅通过手术切除就有极好的预后，治愈率接近90%[1]。犬眼睑腺癌具有局部侵袭性但很少转移，手术切除通常有效且复发不常见[2]。对于良性肿块，当肿瘤涉及小于25-30%的眼睑长度时，单纯楔形切除可提供优异结果[4][6]。

治疗方式显示相似的治愈率但不同的复发模式。所有技术的复发率大致相同，但复发时间冷冻疗法最短（7个月），激光中等（18个月），手术切除最长（28个月）[6]。长期监测方案应包括对先前治疗的恶性肿瘤每6个月定期重新评估。对于复杂的重建手术、放射治疗计划或当肿瘤超过一般实践中可实现的手术边缘时，应转诊给兽医眼科医生。

### Sources
[1] Feline head and neck tumors (Proceedings): https://www.dvm360.com/view/feline-head-and-neck-tumors-proceedings
[2] MSD Veterinary Manual Ocular Neoplasia in Dogs: https://www.merckvetmanual.com/eye-diseases-and-disorders/neoplasia-of-the-eye-and-associated-structures/ocular-neoplasia-in-dogs
[3] MSD Veterinary Manual Cancers and Tumors of the Eye in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/cancers-and-tumors-of-the-eye-in-dogs
[4] DVM 360 Skills Laboratory: Cryosurgery for eyelid masses: https://www.dvm360.com/view/skills-laboratory-cryosurgery-eyelid-masses
[5] Help with challenges in eyelid surgery: https://www.dvm360.com/view/help-with-challenges-in-eyelid-surgery
[6] Surgical techniques for the eyelid (Proceedings): https://www.dvm360.com/view/surgical-techniques-eyelid-proceedings