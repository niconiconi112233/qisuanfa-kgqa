# 伴侣动物的胃扩张扭转综合征

胃扩张扭转综合征（GDV）是兽医医学中最危急的急症之一，主要影响大型和巨型犬种，即使经过治疗，死亡率仍高达45%。这种危及生命的综合征涉及胃部扩大和旋转，导致心血管和呼吸系统受损的级联反应，需要立即干预。在美国，每年约有60,000只犬受到此病影响，大丹犬的终生风险高达42.4%。本报告探讨了GDV的全面兽医管理，从急诊识别和稳定到手术矫正和预防策略，为管理这种时间敏感的兽医急症提供了必要的临床知识。

## 疾病概述

胃扩张扭转综合征（GDV）是一种危及生命的急症，其中胃部扩大并沿其肠系膜轴旋转[1]。也被称为"胃胀气"，GDV涉及由气体或液体积聚引起的胃扩张和扭转，即胃部围绕远端食道顺时针旋转90°至360°[1]。

GDV主要影响大型和巨型犬种，即使经过治疗，死亡率也在20-45%之间[1][2]。在美国，每年约有60,000只犬受到此病影响[1]。大丹犬的终生风险最高，为42.4%，其次是其他易感品种，包括德国牧羊犬、爱尔兰雪达犬、标准贵宾犬、圣伯纳犬和魏玛犬[1][2][3]。

风险随年龄增长而显著增加——对于大型犬种，5岁后风险每年增加20%，对于巨型犬种，3岁后每年增加20%[3]。雄性犬的发病率略高于雌性犬[3]。其他风险因素包括深而窄的胸廓结构、瘦体型、有一级亲属患有GDV病史、紧张或恐惧的气质以及某些饮食因素[1][2][3]。虽然主要影响犬类，但GDV很少发生在猫和其他物种中[2]。

### Sources
[1] Successful stabilization of the patient with gastric dilatation-volvulus: https://www.dvm360.com/view/successful-stabilization-patient-with-gastric-dilatation-volvulus-proceedings
[2] Gastric dilatation-volvulus: The twisted truth: https://www.dvm360.com/view/gastric-dilatation-volvulus-the-twisted-truth
[3] Risk Factors for Canine Bloat: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=11165&meta=Generic&id=3848657

## 临床症状和病理生理学

现有内容全面概述了犬胃扩张扭转综合征的临床表现和病理生理学。额外的资料来源允许增强关于非典型表现和潜在机制的细节。

患有GDV的犬可能表现出不同程度的症状严重性。早期病例可能显示细微迹象，包括不安和轻度腹部增大，而典型表现包括无效干呕、进行性腹部膨胀和流涎三联征[4]。具有急性躁动和无效干呕的典型大型深胸犬表现仍然最常见，尽管GDV可发生在非典型品种甚至猫中，在这些情况下呼吸窘迫通常比胃肠道症状更突出[4,7]。

随着胃扩张的进展，心血管损害迅速发展。犬最初表现为代偿性低血容量休克，特征为心动过速和正常脉搏，但可迅速进展为失代偿状态，伴有严重低血压、心动过缓和心血管衰竭[1,6]。临床表现的严重程度与预后直接相关，侧卧犬的死亡率显著高于能够行走的患犬[6]。

病理生理级联反应涉及多器官系统功能障碍。胃旋转通过压迫后腔静脉和门静脉导致静脉回流机械性阻塞，导致血液在内脏循环中淤积[6]。同时，扩张的胃机械性限制膈肌运动，损害肺顺应性并导致呼吸功能障碍[6]。这种心血管和呼吸功能障碍的组合，加上潜在的胃壁坏死和细菌移位，创造了这种危及生命的状况。

### Sources
[1] Gastric dilatation volvulus syndrome (Proceedings): https://www.dvm360.com/view/gastric-dilatation-volvulus-syndrome-proceedings
[2] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[3] Gastric dilatation-volvulus: Controlling the crisis: https://www.dvm360.com/view/gastric-dilatation-volvulus-controlling-crisis
[4] Emergency stabilization of gastric dilatation and volvulus: https://www.dvm360.com/view/emergency-stabilization-gastric-dilatation-and-volvulus-proceedings
[5] Gastric dilatation-volvulus: The twisted truth: https://www.dvm360.com/view/gastric-dilatation-volvulus-the-twisted-truth
[6] Gastric dilatation-volvulus: Controlling the crisis: https://www.dvm360.com/view/gastric-dilatation-volvulus-controlling-crisis
[7] Feline Gastric Dilatation-Volvulus: https://www.dvm360.com/view/feline-gastric-dilatationvolvulus

## 诊断方法和治疗

胃扩张和扭转的诊断主要依靠临床表现和放射学确认[1]。典型三联征包括无效干呕、腹部膨胀和低血容量休克迹象[1]。体格检查显示鼓音腹部，可能伴有脾肿大[1]。

**影像学检查**对确诊至关重要。右侧位X光片是首选，显示特征性"双气泡"外观，幽门向背侧移位，胃底和幽门窦之间分隔[1][3]。胃壁内气体提示坏死，而游离腹腔气体表明穿孔[3]。

**实验室评估**应包括血细胞比容、总固体、血糖、静脉血气和乳酸浓度[2]。血浆乳酸>6-7 mmol/L与胃坏死和不良预后相关[1][4]。连续乳酸测量比单次值更有价值[2]。

**急诊稳定**从放置大口径静脉导管和休克速率晶体液治疗（最初90 mL/kg/小时）开始[1][4]。通过经口胃管或经皮胃穿刺进行胃减压可立即缓解症状[1][2]。

**手术干预**包括胃复位、评估需要切除的坏死组织、必要时脾切除术和胃固定术以防止复发[1][5]。存在多种胃固定技术，当正确执行时复发率<5%[5]。

**术后护理**包括持续心脏监测、液体治疗、镇痛药和胃保护剂。室性心律失常通常在术后24-48小时发展，可能需要利多卡因治疗[1][5]。

### Sources
[1] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[2] Emergency stabilization of gastric dilatation and volvulus: https://www.dvm360.com/view/emergency-stabilization-gastric-dilatation-and-volvulus-proceedings
[3] Gastric dilatation volvulus syndrome: https://www.dvm360.com/view/gastric-dilatation-volvulus-syndrome-proceedings
[4] Successful stabilization of the patient with gastric dilatation-volvulus: https://www.dvm360.com/view/successful-stabilization-patient-with-gastric-dilatation-volvulus-proceedings
[5] Gastric dilatation-volvulus: The twisted truth: https://www.dvm360.com/view/gastric-dilatation-volvulus-the-twisted-truth

## 预防和预后

**预防措施**

预防性胃固定术仍然是预防胃扩张扭转的最有效方法，在胃壁和腹壁之间形成永久性粘连，防止未来胃部旋转[1]。此手术可在常规绝育手术期间使用微创技术如腹腔镜辅助胃固定术进行[2,3]。胃固定术后，伴有或不伴有扭转的胃扩张复发率在6-10%之间[6]。

饮食管理包括喂食多次小餐而不是一顿大餐，限制餐前餐后运动，减少用餐时的压力，避免使用升高食盆[1,2]。高风险品种的主人应接受关于GDV迹象的教育，并避免繁殖有一级亲属患有GDV的犬[1]。

**预后和生存率**

GDV手术矫正后的总体生存率在70-80%之间，治疗动物的死亡率为20-45%[1,3]。然而，根据多种因素，死亡率可能在10-90%之间显著变化[2]。

关键预后指标包括血浆乳酸浓度，当乳酸<6.0 mmol/L时生存率为99%，而>6.0 mmol/L时为58%[1]。临床症状持续时间超过六小时、需要脾切除术和部分胃切除术、住院期间低血压以及存在腹膜炎或败血症与死亡率增加相关[1,3]。预防性胃固定术显示出显著的生存益处，在罗威纳犬中死亡率降低2.2倍，在大丹犬中降低29.6倍[1]。

### Sources

[1] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[2] Gastric dilatation-volvulus: Controlling the crisis: https://www.dvm360.com/view/gastric-dilatation-volvulus-controlling-crisis
[3] Successful stabilization of the patient with gastric dilatation-volvulus: https://www.dvm360.com/view/successful-stabilization-patient-with-gastric-dilatation-volvulus-proceedings
[4] Surgery STAT: Prevent gastric dilatation volvulus with laparoscopic assisted gastropexy: https://www.dvm360.com/view/surgery-stat-prevent-gastric-dilatation-volvulus-with-laparoscopic-assisted-gastropexy
[5] Gastric dilatation-volvulus: The twisted truth: https://www.dvm360.com/view/gastric-dilatation-volvulus-the-twisted-truth
[6] Association of mesenteric volvulus in police working dogs: https://avmajournals.avma.org/view/journals/javma/262/6/javma.23.11.0620.xml