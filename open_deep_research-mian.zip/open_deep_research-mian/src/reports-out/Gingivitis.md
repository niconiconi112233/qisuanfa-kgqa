# 犬猫牙龈炎：综合兽医指南

牙龈炎是小动物临床中最常见但可预防的疾病之一，在2-3岁龄时影响高达80%的犬和70%的猫。作为牙周病的可逆前兆，早期识别和干预可防止其发展为不可逆的附着丧失和全身并发症。本报告探讨了以革兰氏阴性厌氧菌为主的细菌病因学，从口臭到牙龈出血的临床表现，以及包括牙周探诊和先进实验室技术在内的循证诊断方法。治疗策略强调专业牙科预防与兽医口腔健康委员会批准的家庭护理产品相结合，只要客户依从性良好并遵循定期监测方案，预后极佳。

## 疾病概述与流行病学

牙龈炎是由牙菌斑在牙齿表面积聚引起的牙龈（牙龈组织）炎症[1]。它代表牙周病的初始、可逆阶段，发生在附着丧失出现之前[1]。与牙周炎不同，牙龈炎仅影响牙龈组织，不涉及更深层的牙周结构，如牙周韧带、牙骨质或牙槽骨[1]。

伴侣动物中牙龈炎患病率极高。来自美国兽医诊所超过46,000只犬猫的最新调查数据显示，犬的牙结石患病率为20.5%，猫为24.2%，牙龈炎影响19.5%的犬和13.1%的猫[3]。其他研究报告称，到2-3岁时，高达70%的猫和80%的犬会发展为某种形式的牙周病[4]。

小型犬特别易感，玩具品种患牙周病的可能性比巨型品种高5倍[4]。短头颅品种，包括斗牛犬、哈巴狗和波斯猫，因牙齿拥挤而促进疾病早期发作[4,5]。在猫中，波斯猫、缅因猫、缅甸猫和暹罗猫表现出对早发性或严重牙周病的品种易感性[6]。风险因素包括高龄、猫体重增加、糖尿病或肾上腺皮质功能亢进引起的免疫抑制、营养不良以及创造菌斑滞留表面的咬合不正[1,4]。

### Sources
[1] Periodontal Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[3] Banfield releases new data on periodontal disease; top breeds identified: https://www.dvm360.com/view/banfield-releases-new-data-periodontal-disease-top-breeds-identified
[4] Strengthening oral health: A call to action for veterinary practices: https://www.dvm360.com/view/strengthening-oral-health-a-call-to-action-for-veterinary-practices
[5] Dentistry A to Z: G is for genetics: https://www.dvm360.com/view/g-is-for-genetics
[6] Diseases of the feline oral cavity (Proceedings): https://www.dvm360.com/view/diseases-feline-oral-cavity-proceedings

## 病因学与临床表现

犬猫牙龈炎主要由牙菌斑在牙齿表面积聚引起，刺激宿主产生炎症反应[1]。口腔支持多样化的细菌微生物群，初始定植以革兰氏阳性需氧菌为主，包括葡萄球菌属和链球菌属[1]。随着菌斑成熟和氧气耗尽，细菌种群转向更具致病性的革兰氏阴性厌氧菌，如牙龈卟啉单胞菌、唾液卟啉单胞菌、脆弱拟杆菌和中间普雷沃菌[1]。

病理生理学始于牙齿表面获得性薄膜形成，随后在24小时内形成细菌生物膜[3]。菌斑向牙龈下扩展，细菌产物与细胞降解化合物共同作用对牙周软组织造成破坏，导致牙龈炎[3]。这代表牙周病的可逆阶段，炎症仅限于牙龈组织，无附着丧失[1]。

临床表现包括口臭、红肿且探诊时易出血的牙龈，以及菌斑和牙结石积聚[1,3]。急性牙龈炎表现为明显的牙龈肿胀和出血，而慢性牙龈炎则表现为持续性牙结石沉积，口臭是主人主要投诉的问题[3]。到2-3岁时，该疾病影响高达70%的猫和80%的犬[1,2]。某些纯种猫，包括波斯猫、缅因猫和暹罗猫，表现出对严重早发性疾病的易感性增加[3]。如不干预，牙龈炎可进展为牙周炎，导致不可逆的附着丧失和骨破坏。

### Sources
[1] Periodontal Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[2] Oral Inflammatory and Ulcerative Disease in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-mouth-in-small-animals/oral-inflammatory-and-ulcerative-disease-in-small-animals
[3] Diseases of the feline oral cavity (Proceedings): https://www.dvm360.com/view/diseases-feline-oral-cavity-proceedings

## 诊断方法与鉴别诊断

现有章节内容全面涵盖了牙周病的诊断技术。然而，兽医微生物学和实验室测试的最新进展可提高诊断准确性和临床决策能力。

**增强型实验室诊断**

兽医临床微生物学实验室为常规牙周病之外的复杂口腔感染提供关键支持[1]。当需要进行细菌培养时，从牙周袋正确采集标本需要特别注意，避免正常口腔微生物群的污染[1]。抗菌药物敏感性测试应仅对具有既定解释标准的临床相关分离株进行[1]。

**先进细胞学评估**

细胞学通过细针抽吸或印片涂片可为口腔病变提供有价值的诊断信息[2]。该技术有助于区分炎症性疾病与肿瘤形成，特别是在评估异常牙龈肿块或慢性增殖性病变时[2]。观察到的细胞特征可指导是否需要进行组织活检以明确诊断。

**实验室质量与解释**

临床化学组可能支持影响口腔健康的全身性疾病诊断[3]。专业外部实验室提供先进的测试能力，其质量控制程序可提高诊断准确性[3]。结果必须结合临床表现和患者病史进行解释，以确保适当的治疗决策[1]。

将先进实验室诊断与传统牙周评估相结合，为兽医提供了全面工具，用于准确诊断和靶向治疗犬猫的复杂口腔疾病。

### Sources
[1] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: recommendations from the American College of Veterinary Microbiologists: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[2] Cytology - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology
[3] Laboratory Tests Routinely Performed in Veterinary Medicine - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/laboratory-tests-routinely-performed-in-veterinary-medicine

## 治疗策略与预防

全面的牙龈炎治疗强调专业牙科预防与有效的家庭护理方案相结合。兽医口腔健康委员会（VOHC）是评估牙科家庭护理产品的黄金标准，仅接受通过严格科学试验证明菌斑或牙结石积聚减少至少20%的产品[4]。目前，32种犬用产品和12种猫用产品已获得VOHC认可，为兽医提供了循证建议[7]。

预防性护理必须在宠物生命早期开始。每日刷牙仍然是控制菌斑的黄金标准，但不到5%的宠物主人保持足够的刷牙频率[7]。替代方法包括含有菌斑控制剂的牙科湿巾、含有氯化锌和柠檬酸钠的水添加剂，以及具有机械研磨特性的治疗性牙科饮食[7]。利用蜡质或亲水性聚合物的牙科封闭剂可形成屏障，防止细菌粘附于牙齿表面[7]。

专业干预遵循全面的口腔预防、评估和治疗（COPAT）方案。优质的牙科护理需要以预防为重点的方法，而非在疾病已经进展后的反应性治疗[6]。《默克兽医手册》强调，良好的牙科护理可减少菌斑发展，并防止进展到需要拔牙的严重牙周病[1]。疫苗接种在牙龈炎预防中不起作用，而牙周病疫苗因缺乏长期疗效已被停用[2,4]。

环境管理包括避免可能造成牙齿骨折的硬质咀嚼玩具，同时推广VOHC认可的产品[7]。

### Sources
[1] Routine Health Care of Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/routine-care-and-breeding-of-cats/routine-health-care-of-cats
[2] Noncore vaccines: which ones and how often? Part 1: https://www.dvm360.com/view/noncore-vaccines-which-ones-and-how-often-part-1-dogs-proceedings
[3] Pet periodontal support, plus inventory management software and more: https://www.dvm360.com/view/dvm360-product-report-pet-periodontal-support-plus-inventory-management-software-and-more
[4] Pfizer discontinues production of veterinary periodontal disease vaccine for dogs: https://www.dvm360.com/view/pfizer-discontinues-production-veterinary-periodontal-disease-vaccine-dogs
[5] The ABCs of veterinary dentistry: Q is for quality, not quantity: https://www.dvm360.com/view/abcs-veterinary-dentistry-q-quality-not-quantity
[6] The ABCs of veterinary dentistry: "L" is for "Looks like we're too late": https://www.dvm360.com/view/abcs-veterinary-dentistry-l-looks-were-too-late
[7] The ultimate guide to veterinary dental home care: https://www.dvm360.com/view/ultimate-guide-veterinary-dental-home-care

## 预后与长期管理

牙龈炎如能早期诊断并适当治疗，预后极佳[1]。作为一种仅限于牙龈软组织的可逆炎症性疾病，通过专业牙科清洁结合持续的家庭护理可实现完全缓解[2]。关键预后因素是客户对每日菌斑控制措施的依从性，这可防止进展为不可逆的牙周炎。

相比之下，牙周炎的预后根据严重程度从谨慎到不良不等[2]。2期牙周病（高达25%附着丧失）可能对局部抗生素和严格的家庭护理反应良好。然而，3期和4期牙周炎是进行性和不可逆的，当附着丧失超过50%时通常需要拔牙[3]。

全身并发症显著影响预后。影响3岁龄80%犬和70%猫的牙周病可导致菌血症，可能对心脏、肝脏、肾脏和肺部产生影响[4]。患有并发牙周病的糖尿病猫面临特殊挑战，因为炎症会损害血糖控制[2]。

长期管理要求轻度疾病每6个月复查一次，严重病例每3个月复查一次[2]。强调每日刷牙、VOHC认可的牙科咀嚼玩具和早期专业干预的预防优先方法可显著改善结果[5]。客户教育关于品种特异性易感性和年龄相关考虑至关重要，特别是对于较早发病的小型犬和短头颅动物[6]。没有持续的家庭护理，宠物通常需要每年在麻醉下进行专业清洁。

### Sources
[1] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings
[2] Dental concerns and care through the life stages of pets: https://www.dvm360.com/view/dental-concerns-and-care-through-life-stages-pets-sponsored-greenies
[3] The importance of feline oral health (Proceedings): https://www.dvm360.com/view/importance-feline-oral-health-proceedings
[4] Dentistry A to Z: "I" is for innovation: https://www.dvm360.com/view/dentistry-a-to-z-i-is-for-innovation
[5] The ABCs of veterinary dentistry: "L" is for "Looks like we're too late": https://www.dvm360.com/view/abcs-veterinary-dentistry-l-looks-were-too-late
[6] Strengthening oral health: A call to action for veterinary practices: https://www.dvm360.com/view/strengthening-oral-health-a-call-to-action-for-veterinary-practices