# 伴侣动物的老年性白内障

老年性白内障是影响老年犬猫的一种重要的年龄相关性眼部疾病，其特征是进行性晶状体混浊，可严重影响视力和生活质量。与老年宠物中常见的良性核性硬化不同，真正的老年性白内障会导致功能性视力障碍，需要仔细进行临床鉴别。本报告探讨了伴侣动物老年性白内障的病理生理学、临床表现和诊断方法。重点领域包括核性硬化与真正白内障的区别、现代手术干预（包括超声乳化联合人工晶状体植入术），以及解决受影响宠物的医疗治疗和生活质量问题的综合管理策略。

## 疾病概述与流行病学

老年性白内障是伴侣动物正常衰老过程中发生的年龄相关性晶状体混浊。该病症指发生在老年宠物中的任何晶状体混浊，无论大小，都必须与核性硬化相区别，后者是一种良性的衰老变化[1]。

核性硬化在犬猫7岁左右开始显现，会导致光线散射，但不会显著损害视力[1]。真正的老年性白内障可能源于糖尿病或年龄因素，并可能进展为视力障碍[2]。

**流行病学模式：**
在犬类混种品种中，白内障的发生率为1.6%[1]。犬的白内障发生率远高于猫，猫很少发生原发性白内障[1]。当猫确实发生白内障时，它们通常继发于持续性葡萄膜炎，而非年龄相关性变化[1]。

年龄相关性白内障可能发展为"非常晚期的晶状体硬化可能进展为老年性白内障和视力障碍"[2]。其病理生理学涉及通过维持透明度的改变生化过程破坏正常晶状体代谢[2]。高分子量蛋白（类蛋白）增加，低分子量蛋白（类晶体）减少，同时伴有代谢泵功能障碍和离子浓度改变[2]。

风险因素包括高龄、糖尿病（尤其在犬中）和品种易感性，遗传性白内障在纯种犬中比年龄相关性老年性白内障更为常见[1]。

### Sources

[1] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis

[2] Disease and surgery of the lens (Proceedings): https://www.dvm360.com/view/disease-and-surgery-lens-proceedings

## 临床表现与诊断

**临床症状和体征**
犬猫的老年性白内障通常表现为进行性视力障碍，从强光下的轻微视觉困难到晚期病例的完全失明[1]。主人通常报告宠物撞到家具、不愿上下楼梯或在不熟悉环境中行走、以及不愿跳跃或玩耍。患有白内障的犬通常至少8-10岁，如果它们没有明显的视力缺陷，则更可能是核性硬化而非白内障[1]。

**发展阶段**
白内障的发展经历不同阶段：初期（晶状体受累少于10-15%，对视力影响最小）、未成熟期（不完全混浊，视力受影响）、成熟期（晶状体完全混浊，视力严重受损）和过熟期（晶状体蛋白泄漏可能导致继发性并发症）[1]。过熟期的特征是降解酶释放、晶状体囊收缩和前房加深[1]。

**诊断方法**
全面的眼科检查包括裂隙灯生物显微镜检查，以评估晶状体混浊的位置和密度[2,3]。应在暗室中使用托吡卡胺进行瞳孔散大后进行后照法评估[1,4]。当存在核性硬化而无白内障时，完整的眼底反射仍然可见[1]。

**鉴别诊断**
核性硬化呈现均匀的珍珠状混浊，带有灰蓝色调，而白内障则像大小和混浊程度不一的白色碎冰块[1]。核性硬化双眼受累程度相同，而白内障可能是单侧或双侧的[1]。

### Sources
[1] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[2] A new age of veterinary ophthalmology in: Journal of the American Veterinary Medical Association: https://avmajournals.avma.org/view/journals/javma/262/S2/javma.262.s2.s4.xml
[3] Ultrasound biomicroscopy in dogs suggests postoperative ocular hypertension following cataract surgery and to explore the relationship between intraocular pressure and CC UBM measurements: https://avmajournals.avma.org/view/journals/javma/262/S2/javma.24.05.0309.xml
[4] Physical Examination of the Eye in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals

## 治疗与管理

### 手术干预

**超声乳化术**是犬猫白内障手术的金标准，利用超声波能量通过2.7-3毫米的小切口粉碎晶状体[1]。现代机器可以精细调节超声波功率，以实现安全、高效的摘除并减少热损伤[1]。**双手操作技术**如"超声乳化劈核术"通过将力量导向对侧器械来减少手术时间和悬韧带压力[1]。

**人工晶状体（IOL）植入**在晶状体摘除后进行，犬的标准度为41-42D，猫为52-53D[4][6]。可折叠IOL是首选，因为它们可以通过小切口注入而无需扩大切口[6]。

### 术前评估与术后护理

全面评估包括**视网膜电图（ERG）**、眼部超声和前房角镜检查，以评估视网膜功能和青光眼风险[4][6]。术前控制**晶状体诱导性葡萄膜炎（LIU）**至关重要，需使用局部皮质类固醇和非甾体抗炎药[2][6]。

术后并发症包括**眼压升高**（24小时内）、青光眼（<10%风险）和视网膜脱离[6]。长期抗炎治疗有助于预防并发症[8]。

### 非手术治疗

对于未接受手术的患者，**积极的LIU治疗**对于预防继发性青光眼仍然至关重要[2][8]。局部类固醇或非甾体抗炎药可控制晶状体蛋白泄漏引起的炎症[8]。**N-乙酰肌肽滴眼液**等药物治疗效果有限，在8周内对未成熟白内障仅改善5%[7]。

### Sources

[1] Selected lens diseases and cataract treatment (Proceedings): https://www.dvm360.com/view/selected-lens-diseases-and-cataract-treatment-proceedings
[2] Cataracts: How to uncover the imposter lenticular sclerosis: https://www.dvm360.com/view/cataracts-how-uncover-imposter-lenticular-sclerosis
[3] Disease and surgery of the lens (Proceedings): https://www.dvm360.com/view/disease-and-surgery-lens-proceedings
[4] Update on cataract surgery (Proceedings): https://www.dvm360.com/view/update-cataract-surgery-proceedings
[5] Managing diseases of the lens-clarification of a cloudy type (Proceedings): https://www.dvm360.com/view/managing-diseases-lens-clarification-cloudy-type-proceedings
[6] Cataract surgery in veterinary medicine today (Proceedings): https://www.dvm360.com/view/cataract-surgery-veterinary-medicine-today-proceedings
[7] Lens disorders: Diagnosis and treatment (Proceedings): https://www.dvm360.com/view/lens-disorders-diagnosis-and-treatment-proceedings-0
[8] Lens disorders: Diagnosis and treatment (Proceedings): https://www.dvm360.com/view/lens-disorders-diagnosis-and-treatment-proceedings

## 预防与预后

**预防措施**

老年性白内障无法预防，因为它们是衰老的自然后果[1]。然而，定期眼科检查对于早期发现至关重要，应在每次年度就诊时检查眼睛，以检测晶状体混浊的早期变化，特别是老年宠物[1]。

通过适当的营养、体重管理和控制并发疾病来维持最佳整体健康，可能有助于延缓年龄相关性变化的进展[1][2]。环境调整对视力受损的宠物变得至关重要 - 食物和水碗以及栖息地位置应保持不变，以帮助导航[1]。含有抗氧化剂包的优质老年粮可能通过减少自由基损伤提供额外支持，自由基在白内障发展中起重要作用[2][3]。

**监测方案**

对于有风险的老年患者，系统性筛查方案应包括全面的眼科评估。在12岁以上的犬中，41%表现出某种程度的视力障碍，到16岁时增加到68%[1]。定期监测允许早期干预和生活质量调整。

**预后与生活质量**

老年性白内障的预后因进展速度和患者适应能力而异。如果发病是渐进的，通常能成功适应视力下降[1]。然而，突发性白内障没有足够的时间进行适应，可能严重影响生活质量。

不经治疗，预期会出现进行性视力下降。通过超声乳化联合人工晶状体植入术进行手术干预，在最初1-2年内的成功率为90-95%[6][7]。生活质量的考虑包括宠物安全导航的能力、维持正常进食行为以及表现出舒适的社交互动。当环境调整无法为失明或视力受损的宠物提供足够的安全感时，生活质量会受到严重损害[1]。

### Sources

[1] Diagnosing and managing common age-related problems in older dogs and cats: https://www.dvm360.com/view/diagnosing-and-managing-common-age-related-problems-older-dogs-and-cats-proceedings
[2] Why pets age and how can influence the process: https://www.dvm360.com/view/why-pets-age-and-how-can-influence-process-proceedings
[3] Why dogs and cats age and how we can influence the process: https://www.dvm360.com/view/why-dogs-and-cats-age-and-how-we-can-influence-process-proceedings
[4] Introducing Iams Senior Plus Formulas: https://www.dvm360.com/view/introducing-iams-senior-plus-formulas
[5] Cataract surgery in veterinary medicine today: https://www.dvm360.com/view/cataract-surgery-veterinary-medicine-today-proceedings
[6] The Lens in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/the-lens-in-animals
[7] Update on cataract surgery: https://www.dvm360.com/view/update-cataract-surgery-proceedings