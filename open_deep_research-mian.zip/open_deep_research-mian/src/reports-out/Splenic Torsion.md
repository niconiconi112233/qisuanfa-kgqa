# 伴侣动物脾扭转

脾扭转是兽医医学中的一种危急重症，主要通过脾脏围绕其血管蒂的旋转影响大型和巨型犬。这种危及生命的状况需要立即识别和手术干预，以防止血管损伤和脾坏死的致命并发症。该疾病可表现为原发性脾扭转或继发于胃扩张-扭转症，每种情况都需要不同的诊断和治疗方法。本报告探讨了脾扭转的综合临床管理，涵盖紧急稳定方案、诊断影像技术、手术脾切除术以及影响小动物临床实践中患者结果的预后因素。

## 疾病概述

脾扭转是一种危及生命的疾病，涉及脾脏围绕其血管蒂的旋转，导致血管损伤和潜在的脾坏死[1]。这种情况主要影响大型和巨型犬，脾脏因血管淤滞和最终血栓形成而肿大[1]。

病理生理学核心是脾血管蒂的旋转，这会阻断静脉回流，同时最初保留动脉血流[1]。这导致进行性脾肿大、充血和潜在的组织坏死。脾扭转可作为原发性疾病发生，或继发于胃扩张-扭转症（GDV），在GDV中，由于解剖连接，脾脏跟随胃的旋转[2]。在GDV病例中，根据扭转程度，脾脏的位置可能从左腹背侧到右腹头侧不等[2]。

从流行病学角度看，脾扭转对大型和巨型品种有明显的品种易感性[1]。最近的研究表明，性别分布相对均衡，雄性在小品种犬病例中约占49%[3]。原发性脾扭转病例表现出与GDV相关的继发性形式不同的临床表现[1]。原发性脾扭转可表现为急性和慢性两种形式，慢性表现由于模糊且有时间歇性的临床症状而特别难以诊断[4]。

### Sources

[1] Primary splenic torsion in dogs: 102 cases (1992–2014): https://avmajournals.avma.org/view/journals/javma/248/6/javma.248.6.661.xml
[2] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[3] Splenomegaly in small‐breed dogs: 45 cases(2005–2011): https://avmajournals.avma.org/view/journals/javma/250/10/javma.250.10.1148.xml
[4] Chronic primary splenic torsion with peritoneal adhesions in a dog: https://meridian.allenpress.com/jaaha/article-abstract/36/5/390/175455/Chronic-primary-splenic-torsion-with-peritoneal?redirectedFrom=fulltext

## 临床症状和体征

犬脾扭转的临床表现包括急性腹痛、呕吐、厌食和嗜睡[1]。该疾病通常表现为急性腹膜炎症状，患病动物表现出突然发作的腹部不适和痛苦。体格检查显示触诊时腹痛，并可能触及坚硬的腹部肿块[2]。

脾扭转犬可表现出两种不同的临床模式。急性发作的犬通常表现出明显的腹痛和虚脱[3]。相比之下，慢性脾扭转的犬可能表现出模糊的临床症状，包括厌食、嗜睡、间歇性呕吐、腹胀，可能还有多尿和多饮[3]。一些犬在急性发作前可能表现出慢性间歇性症状，包括抑郁、厌食和与腹部不适一致的体征[4]。

体格检查发现包括心动过速、黏膜发黏和毛细血管再充盈时间延长，表明脱水。腹部触诊通常显示不适，并可能识别出腹部肿大、坚硬的肿块，对应于扭转的脾脏。由于腹痛，犬可能表现出僵硬步态和异常姿势。

实验室异常通常包括脱水导致的红细胞压积和血红蛋白浓度升高、中性粒细胞增多的白细胞增多，以及呕吐和液体流失导致的电解质紊乱，包括低钾血症和低氯血症[4]。在慢性表现的犬中，尿液分析可能注意到血红蛋白尿[3]。

影像学检查对诊断至关重要。腹部X光片可能显示脾脏向前移位和正常脾脏结构丧失。超声检查结合彩色多普勒血流可检测到受影响脾脏的血流缺失，这是扭转的特征性表现[2]。

### Sources
[1] Specific surgical emergencies (Proceedings): https://www.dvm360.com/view/specific-surgical-emergencies-proceedings
[2] A retained testis and spermatic cord torsion in a boxer: https://www.dvm360.com/view/clinical-exposures-retained-testis-and-spermatic-cord-torsion-boxer
[3] Surgery of the spleen (Proceedings): https://www.dvm360.com/view/surgery-spleen-proceedings
[4] A challenging case: Acute-on-chronic vomiting in a German shepherd: https://www.dvm360.com/view/challenging-case-acute-chronic-vomiting-german-shepherd

## 手术管理和并发症

在脾扭转病例中，手术干预前的紧急稳定至关重要。应立即开始使用晶体液（30-45 ml/kg推注）进行积极液体复苏，并考虑使用高渗盐水或羟乙基淀粉以提供更持久的血管内支持[1]。患者需要血流动力学稳定并持续监测血压，在尝试手术矫正前保持平均动脉压充足[2]。

完全脾切除术是脾扭转的确定性治疗方法[1]。手术方法包括确认左胰腺肢的位置，然后使用大直径缝线（#1聚二氧六环酮）结扎整个脾血管蒂，再切除扭转的脾脏[1]。脾脏切除后，缓慢解开血管蒂并检查出血，根据需要应用额外的结扎线或高能量密封装置[1。

建议在脾切除术期间进行预防性胃固定术，约三分之二的犬接受这种同期手术[3]。带环、切口或肋周胃固定术技术可预防未来的胃扩张-扭转症。

常见的围手术期并发症包括室性心律失常和贫血[3]。术中出血和延迟性出血是重大问题，需要在腹部闭合前仔细确认止血[1]。具有统计学意义的死亡风险因素包括脓毒性腹膜炎、术中出血和术后呼吸窘迫[3]。

由于与脾切除术相关的神秘性心律失常，需要在24小时护理设施中进行2-3天的术后监测[1]。适当的稳定方案可显著改善结果，当适当的稳定措施先于手术时，存活率超过90%[4]。

### Sources
[1] Let's undo the twist: diagnosing and treating splenic torsion in dogs: https://www.dvm360.com/view/let-s-undo-the-twist-diagnosing-and-treating-splenic-torsion-in-dogs
[2] Initial Triage and Resuscitation of Small Animal Emergency Patients: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/evaluation-and-initial-treatment-of-small-animal-emergency-patients/initial-triage-and-resuscitation-of-small-animal-emergency-patients
[3] Primary Splenic Torsion in Dogs: https://avmajournals.avma.org/view/journals/javma/248/6/javma.248.6.661.xml
[4] Gastric dilatation-volvulus: It doesnt have to make your stomach turn: https://www.dvm360.com/view/gastric-dilatation-volvulus-it-doesn-t-have-make-your-stomach-turn

## 鉴别诊断和预后

### 鉴别诊断

脾扭转必须与几种引起急性腹膜炎的疾病进行鉴别。胃扩张-扭转症（GDV）是最关键的鉴别诊断，因为**脾脏滞留常伴随GDV**，两种情况都可能表现出相似的休克模式和腹胀[1]。GDV通常显示特征性的放射学分区，呈"反向C"征，而脾扭转则显示脾肿大并可能位置异常[1]。

**脾脏肿块，特别是血管肉瘤，表现出相似的临床症状，包括心律失常和虚脱**[3]。然而，多普勒评估的超声检查可以通过显示**扭转的脾蒂和脾血管血流缺失**来区分扭转[3]。其他鉴别诊断包括脾血肿，其可能通过腹腔积血模拟肿瘤表现[8]。**脾梗死**也表现为急性腹痛，但在影像学上缺乏特征性的扭转蒂[2]。

### 预后

**接受原发性脾扭转脾切除术的犬预后良好**[6]。研究报告手术矫正后的总存活率为70-80%，**大多数犬能够存活至出院**[6]。

**负面预后指标包括脓毒性腹膜炎、术中出血和术后呼吸窘迫**[6]。临床症状持续时间也影响结果——慢性表现的预后可能比急性病例更差[3]。**延迟性出血是相对常见的术后并发症**，需要仔细的止血技术[8]。

脾切除术后，犬保持良好的生活质量，长期并发症极少[6]。

### Sources

[1] Gastric Dilation and Volvulus in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastric-dilation-and-volvulus-in-small-animals
[2] Splenic Infarction: Symptoms, Causes & Treatment: https://my.clevelandclinic.org/health/diseases/splenic-infarction
[3] Let's undo the twist: diagnosing and treating splenic torsion in dogs: https://www.dvm360.com/view/let-s-undo-the-twist-diagnosing-and-treating-splenic-torsion-in-dogs
[4] Spherocytosis as an indicator of fragmentation injury in dogs: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.03.0148.xml
[5] Long-term complications of splenectomy in dogs with: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.05.0307/javma.25.05.0307.pdf
[6] Surgery of the spleen (Proceedings): https://www.dvm360.com/view/surgery-spleen-proceedings