# 伴侣动物慢性胃炎

慢性胃炎是兽医临床实践中最常见的胃肠道疾病之一，影响各年龄段的犬和猫，临床严重程度各不相同。这种胃黏膜持续性炎症性疾病对兽医从业者提出了重大的诊断和治疗挑战，需要对其多因素病因和多样化的临床表现有全面的理解。

本报告探讨了慢性胃炎背后的复杂病理生理学，从幽门螺杆菌定植到药物引起的黏膜损伤。它探讨了从初始临床评估到先进内窥镜评估的诊断过程，同时详细介绍了基于证据的治疗方案，从饮食管理到免疫抑制治疗。分析包括关键的鉴别诊断和预后考虑因素，这些因素直接影响小动物临床实践中的临床决策和客户沟通。

## 摘要

伴侣动物的慢性胃炎是一种复杂的、多因素的疾病，需要系统性的诊断和治疗方法。该病主要影响中年动物，间歇性呕吐是其标志性临床症状，尽管幽门螺杆菌在某些群体中的定植率接近100%，但并非所有感染都会出现临床症状。

诊断成功很大程度上依赖于内窥镜评估和组织病理学确认，因为常规实验室检查和体格检查通常结果无异常。治疗方案采用分层方法，从低过敏性饮食和胃保护剂开始，对难治性病例进展到免疫抑制治疗。

| 治疗反应类别 | 成功率 | 典型时间线 |
|---|---|---|
| 食物反应性肠病 | 50-65% | 14天 |
| 抗生素反应性病例 | 15-35% | 2-4周 |
| 免疫抑制剂反应性 | 10-25% | 4-8周 |

预后因潜在病因而有显著差异，食物反应性病例显示良好结果，而肿瘤性鉴别诊断则预后谨慎。通过对慢性呕吐模式的系统评估进行早期识别，结合适当的诊断影像学和靶向治疗试验，对于小动物临床实践中的最佳患者结果和有效的客户管理仍然至关重要。

## 疾病概述与流行病学

慢性胃炎是犬和猫中常见的诊断疾病，表现为慢性胃肠道疾病[1]。该病的特征是胃黏膜持续炎症，持续数周至数月，这与急性胃炎发作不同。

慢性胃炎影响各年龄段的犬和猫，但中年动物更常受影响[2]。在猫中，纯种个体可能易患慢性胃炎[3]。该病在伴侣动物中没有明显的性别偏好。

慢性胃炎的患病率因潜在病因而有显著差异。幽门螺杆菌相关性胃炎在两个物种中都显示出极高的患病率，调查显示在某些犬和猫群体中感染率接近100%[2][3]。然而，并非所有感染动物都会发展成临床胃炎，这表明疾病发展需要额外的易感因素。

慢性胃炎的风险因素包括饮食不当、压力、并发炎症性肠病和传染性病原体。环境因素如犬舍或收容所饲养可能增加接触传染性病因的风险。该病通常作为更广泛的胃肠道疾病综合征的一部分发生，特别是在猫中，慢性胃炎可能与炎症性肝病和胰腺炎相关，形成所谓的三联炎综合征[3]。

### Sources

[1] Comparison of clinical, endoscopic, and histologic features: https://avmajournals.avma.org/view/journals/javma/256/8/javma.256.8.906.xml

[2] Helicobacter gastritis in dogs and cats (Proceedings): https://www.dvm360.com/view/helicobacter-gastritis-dogs-and-cats-proceedings  

[3] Disorders of the Stomach and Intestines in Cats: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-stomach-and-intestines-in-cats

## 病因与病理生理学

犬和猫的慢性胃炎涉及多种病理生理机制，导致胃黏膜持续性炎症。涉及的主要传染性病原体是**幽门螺杆菌属**，特别是类似幽门螺杆菌的生物体，它们定植于胃黏膜并引发炎症反应[1]。这些细菌产生脲酶，产生氨损伤上皮细胞并破坏保护性黏液层。

然而，最近的研究表明，一些犬可能由于对幽门螺杆菌属的耐受性丧失而发展成胃炎，而不是这些生物体的内在致病特性[2]。寄生虫病因包括猫的**泡翼线虫属**和**三尖奥杜安线虫**，它们引起直接黏膜刺激和慢性炎症[1]。

非传染性病因同样重要，包括**饮食因素**如食物过敏、饮食不当以及增加胃酸分泌的辛辣或高脂肪食物。**药物性胃炎**通常由非甾体抗炎药(NSAIDs)引起，这些药物抑制环氧化酶-1并减少保护性前列腺素的产生[3]。这导致黏液分泌减少、碳酸氢盐产生减少和黏膜血流受损。

**全身性疾病**包括慢性肾病、肝病和肾上腺皮质功能减退症可通过代谢紊乱引起继发性胃炎[3]。病理生理学涉及胃黏膜屏障的破坏，允许酸反扩散，并通过肥大细胞脱颗粒和组胺释放持续炎症，形成一个黏膜损伤的自我持续循环。

### Sources
[1] Malabsorption Syndromes in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/malabsorption-syndromes-in-small-animals
[2] Comparison of clinical, endoscopic, and histologic features: https://avmajournals.avma.org/view/journals/javma/256/8/javma.256.8.906.xml
[3] Diagnosis and management of GI motility disorders: https://www.dvm360.com/view/diagnosis-and-management-of-gi-motility-disorders

## 临床表现与诊断

慢性胃炎通常以间歇性呕吐为主要临床症状[1]。呕吐发作通常含有食物或胆汁，与进食没有特定的时间关系，发作模式可能是周期性的[1]。进食后8-10小时以上呕吐未消化或部分消化的食物提示胃动力障碍，这通常伴随慢性胃炎发生[1]。全身性疾病、体重减轻和胃肠道溃疡在单纯慢性胃炎中很少发生[2]。

体格检查结果通常无异常，但彻底的腹部触诊对于检测任何肿块或增厚的肠段至关重要[3]。犬偶尔可能采取"祈祷"姿势以缓解前腹部不适[2]。

诊断评估从全面的实验室检查开始，包括CBC、生化谱、尿液分析和粪便检查，以排除全身性疾病[1]。对于猫，甲状腺激素检测和心丝虫抗体检测被认为是常规基线评估[1]。这些检查有助于排除可能导致慢性呕吐的疾病，如肾上腺皮质功能减退症、肝病和肾衰竭[1]。

高级影像学在诊断中起着关键作用。腹部超声可以检测胃壁增厚、肿块和其他异常[1]。内窥镜检查被认为是最可靠的诊断工具，允许直接胃检查和活检采集，同时在诊断胃糜烂和慢性胃炎方面比钡餐检查可靠得多[1]。胃活检的组织学评估对于明确诊断仍然必不可少，显示特征性炎症浸润[2]。

### Sources
[1] Diagnostic strategy for vomiting in dogs and cats: https://www.dvm360.com/view/diagnostic-strategy-vomiting-dogs-and-cats-proceedings
[2] Gastritis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-in-small-animals/gastritis-in-small-animals

## 治疗策略

慢性胃炎的治疗根据严重程度和患者表现采用序贯方法。质子泵抑制剂(PPIs)代表胃保护的一线治疗，奥美拉唑(0.5-1.5 mg/kg，口服，每12小时一次)或泮托拉唑(1 mg/kg，静脉注射，每12小时一次)提供比H2受体拮抗剂更优的酸抑制[1]。

饮食管理是治疗的基石。使用新蛋白质来源或水解蛋白质的低过敏性饮食应在其他干预前试用3-4周[2]。临床症状轻微的动物通常对支持性护理和专门喂食高消化率饮食有反应[2]。

对于组织学确认的中度至重度病例，免疫抑制治疗变得必要。泼尼松龙对猫和小型犬以2 mg/kg每日剂量开始，或对大型犬以40-50 mg/m²剂量开始，然后逐渐减量至最低有效剂量[2]。对于难治性病例，可能需要额外的免疫抑制剂如硫唑嘌呤(犬：每24-48小时2 mg/kg)或苯丁酸氮芥(猫：每48-72小时2 mg)[2]。

特定类型的胃炎需要靶向方法。幽门螺杆菌相关性胃炎可能对阿莫西林、甲硝唑和次水杨酸铋的三联疗法有反应[3]。慢性肥厚性胃病通常需要通过幽门成形术进行手术矫正[2]。

应通过临床改善和适时的内窥镜复查来监测治疗反应。

### Sources
[1] ACVIM consensus statement on GI protectants: https://www.dvm360.com/view/acvim-consensus-statement-gi-protectants-what-you-need-know
[2] Gastritis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-in-small-animals/gastritis-in-small-animals
[3] Helicobacter gastritis in dogs and cats: https://www.dvm360.com/view/helicobacter-gastritis-dogs-and-cats-proceedings

## 鉴别诊断与预后

慢性胃炎的鉴别诊断包括几种临床表现重叠的疾病。**炎症性肠病(IBD)是主要的鉴别诊断**，共享慢性呕吐、体重减轻和间歇性食欲改变等症状[1]。IBD呈现三种主要模式：主要呕吐、主要腹泻或混合症状。鉴别特征包括IBD对免疫抑制治疗更一致的应答及其临床症状的周期性模式[1]。

**胃肠道肿瘤，特别是淋巴瘤和腺癌**，必须在中年至老年动物中考虑[2]。在猫中，淋巴瘤是最常见的胃肠道肿瘤，而在犬中，腺癌主要发生在胃和大肠[2]。关键鉴别因素包括可触及腹部肿块的存在、尽管治疗但仍进行性体重减轻以及超声检查显示壁增厚或正常分层丧失的证据。

**异物梗阻**可引起类似的慢性呕吐模式。年轻、大型品种犬特别容易摄入不适当的物体[3]。放射影像学和内窥镜检查有助于区分异物和炎症性疾病。

**慢性肠病**类别包括食物反应性肠病(病例的50-65%)、抗生素反应性肠病(15-35%)和免疫抑制剂反应性肠病(10-25%)[4]。对特定治疗的反应有助于区分这些疾病。

慢性胃炎的预后因潜在原因而有显著差异。食物反应性疾病通常在14天内显示改善，长期预后良好至优秀[4]。IBD病例通常对皮质类固醇反应良好，一个月内临床反应率高达90%，尽管11%在三个月内复发[4]。肿瘤性疾病预后谨慎至不良，小肠腺癌的中位生存时间为4-18个月，高级别淋巴瘤在大多数情况下为2-3个月[2]。

### Sources
[1] Managing IBD in dogs and cats (Proceedings): https://www.dvm360.com/view/managing-ibd-dogs-and-cats-proceedings
[2] Gastrointestinal Neoplasia in Dogs and Cats: https://www.merckvetmanual.com/digestive-system/neoplasia-of-the-gastrointestinal-tract-in-small-animals/gastrointestinal-neoplasia-in-dogs-and-cats
[3] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[4] Decoding chronic enteropathy in canine patients: https://www.dvm360.com/view/decoding-chronic-enteropathy-in-canine-patients