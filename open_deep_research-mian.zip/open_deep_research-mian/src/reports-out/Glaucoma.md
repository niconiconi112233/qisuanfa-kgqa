# 伴侣动物青光眼：一种关键的眼科急症

青光眼是兽医实践中最紧急的眼科急症之一，其特征是眼内压升高，导致犬猫不可逆的视力丧失和严重疼痛。本综合报告探讨了青光眼的多方面性质，从涉及房水动力学紊乱的潜在病理生理学到包括眼压测量和前房角镜检查在内的关键诊断技术。分析涵盖了使用渗透性利尿剂和碳酸酐酶抑制剂的紧急医疗干预，从睫状体光凝术到挽救性手术的手术选择，以及区分青光眼与前葡萄膜炎和其他红眼病症的复杂鉴别诊断。特别强调品种特异性易感性、对侧眼的预防性管理策略，以及尽管积极治疗但大多数青光眼最终会丧失视力的严峻现实，突显了早期识别和立即干预的重要性。

## 疾病概述

犬猫青光眼被定义为一组以眼内压（IOP）升高和进行性视神经及视网膜退化为特征的疾病 [1]。其发病机制涉及视网膜神经节细胞功能丧失、视神经轴突破坏和视力丧失，而升高的IOP现在被认为是风险因素而非主要原因 [2]。

正常的房水动力学需要产生和排出之间的平衡。房水由睫状体的无色素上皮细胞通过主动转运、被动扩散和超滤作用产生 [2]。碳酸酐酶催化基本反应 H2O + CO2 ←→ HCO3- + H+，其中碳酸氢盐和钠被主动转运到后房，水随之渗透性进入 [1]。

在犬猫中，房水主要通过常规途径经虹膜角膜角和小梁网排出，较小体积通过非常规的葡萄膜巩膜途径排出（犬为15%，猫为3%）[1][2]。青光眼通常是由于房水排出减少而非产生过多所致 [1]。正常IOP范围在犬为15-25 mmHg，在猫可达30 mmHg，压力超过25-30 mmHg被认为值得关注 [2][4]。

某些品种表现出增加的易感性，包括可卡犬、巴吉度猎犬、松狮犬、西伯利亚哈士奇和沙皮犬，雌性更常受影响，大多数病例发生在中年犬（5-7岁）[1][3]。

### Sources

[1] Update on glaucoma in dogs (Proceedings): https://www.dvm360.com/view/update-glaucoma-dogs-proceedings
[2] Glaucoma (Proceedings): https://www.dvm360.com/view/glaucoma-proceedings
[3] An overview of canine glaucoma: https://www.dvm360.com/view/an-overview-of-canine-glaucoma
[4] Glaucoma: The 5 o'clock emergency (Proceedings): https://www.dvm360.com/view/glaucoma-5-oclock-emergency-proceedings

## 常见病原体

猫犬青光眼通常继发于引起葡萄膜炎的传染性病原体，导致虹膜粘连形成和房水排出受损等并发症。几种关键病原体可引发这种炎症级联反应。

**病毒病原体**
在猫中，最重要的病毒原因包括猫传染性腹膜炎（FIP）、猫白血病病毒（FeLV）和猫免疫缺陷病毒（FIV）[1]。FIP通常表现为双侧肉芽肿性前葡萄膜炎，可进展为继发性青光眼 [2]。FeLV感染可能与影响葡萄膜的淋巴肉瘤有关，导致严重的虹膜增厚和继发性青光眼 [2]。FIV感染常表现为前葡萄膜炎和扁平部炎，可能易导致青光眼并发症 [2]。

**细菌病原体**
汉塞巴尔通体是猫中由葡萄膜炎引起的继发性青光眼的重要细菌原因 [1]。其他细菌病原体包括支原体、埃里希体属和各种立克次体生物 [1]。在犬中，细菌原因包括犬布鲁氏菌、伯氏疏螺旋体和钩端螺旋体属 [3]。

**其他传染性病原体**
真菌病原体如芽生菌病、组织胞浆菌病和隐球菌病可引起严重葡萄膜炎导致青光眼 [1]。原生动物感染，特别是由刚地弓形虫引起的弓形体病，是猫葡萄膜炎的常见原因，可能进展为继发性青光眼 [1]。在继发于全身性疾病的葡萄膜炎猫中，多达50%发生继发性青光眼 [2]。

### Sources
[1] A challenging case: Uveitis and secondary glaucoma in a cat: https://www.dvm360.com/view/challenging-case-uveitis-and-secondary-glaucoma-cat
[2] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[3] Current approaches to uveitis in the dog and cat (Proceedings): https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings

## 临床症状和体征

### 急性与慢性表现

青光眼明显表现为急性或慢性疾病，尽管大多数急性病例是叠加在慢性疾病上而非单一事件 [1]。急性青光眼是真正的急症，动物表现出严重不适，包括眼睑痉挛、第三眼睑抬高和触诊眼部周围时发声 [2]。这些患者通常显示强烈的巩膜和结膜充血伴有弥漫性角膜水肿 [2]。

慢性青光眼患者在家中通常显得舒适，主人报告仅出现微妙的行为变化，如嗜睡增加和更多时间睡眠 [2]。早期体征常被忽视，包括反应迟钝或轻度散大的瞳孔、轻度球结膜静脉充血和早期眼球增大 [1]。

### 典型眼部体征

经典体征包括散大、固定或反应迟钝的瞳孔；球结膜静脉充血；巩膜外层血管充血；和角膜水肿 [1]。随着压力持续升高，出现继发性眼球增大（牛眼）、晶状体移位和后弹力层破裂（角膜条纹）[1]。急性病例的眼内压通常超过40-60 mmHg [2]。

### 品种特异性模式

某些品种表现出原发性闭角型青光眼易感性，包括美国可卡犬、巴吉度猎犬、松狮犬、中国沙皮犬、萨摩耶犬和西伯利亚哈士奇 [2]。比格犬和挪威猎鹿犬通常因ADAMTS10突变而发展为原发性开角型青光眼 [2]。

### 物种差异

在猫中，青光眼主要继发于前葡萄膜炎和肿瘤，原发性青光眼罕见，暹罗猫除外 [1]。猫对治疗反应不同，由于葡萄膜巩膜排出途径有限，对前列腺素类似物反应不佳 [3]。在猫中，疼痛通常表现为行为改变而非痉挛性眨眼 [4]。

### Sources

[1] Merck Veterinary Manual Glaucoma in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/glaucoma-in-animals
[2] DVM 360 Update on glaucoma in dogs: https://www.dvm360.com/view/update-glaucoma-dogs-proceedings
[3] DVM 360 Latanoprost limitations in cats with glaucoma: https://www.dvm360.com/view/latanoprost-limitations-in-cats-with-glaucoma
[4] Merck Veterinary Manual Glaucoma in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/glaucoma-in-cats

## 诊断方法

犬猫青光眼的准确诊断依赖于使用多种诊断方式的综合评估。**眼压测量是主要的诊断工具**，压平式和回弹式眼压计在兽医实践中广泛使用 [1]。Tonopen是一种压平式眼压计，基于角膜压扁估计眼内压，而较新的回弹式眼压计如TonoVet通过角膜接触后探针回弹测量压力 [3]。正常眼内压在犬为15-25 mm Hg，在猫约为19.7 ± 5.6 mm Hg [2]。

**先进成像技术**提供关键的解剖学评估。前房角镜检查使用专用镜片使虹膜角膜角可视化，有助于分类青光眼类型并确定易感品种的风险 [2,5]。高频超声生物显微镜（50-100 MHz）允许详细检查前房角和睫状裂，提供有价值的预后信息 [2]。最近的研究证明超声生物显微镜在评估术后并发症和角特征方面的效用 [6,7,9]。

**检眼镜检查仍然必不可少**，用于检测与青光眼损伤相关的视盘变化、视网膜损伤和杯状凹陷 [2]。电生理技术，包括图形视网膜电图和视觉诱发电位，可在可见变化出现前检测早期视网膜神经节细胞损伤 [2]。

**临床检查**必须评估瞳孔反应、角膜透明度、巩膜外层血管充血和眼球大小，以区分急性和慢性表现 [1,2]。

### Sources
[1] Acute Glaucoma in Small Animals - Emergency Medicine: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/acute-glaucoma-in-small-animals
[2] Glaucoma in Animals - Eye Diseases and Disorders: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/glaucoma-in-animals
[3] Update on glaucoma in dogs (Proceedings): https://www.dvm360.com/view/update-glaucoma-dogs-proceedings
[4] Tips for simplifying ophthalmic exam in general practice: https://www.dvm360.com/view/tips-for-simplifying-ophthalmic-exam-in-general-practice
[5] An overview of canine glaucoma: https://www.dvm360.com/view/an-overview-of-canine-glaucoma
[6] Bleb characteristics assessed by ultrasound biomicroscopy: https://avmajournals.avma.org/view/journals/ajvr/85/5/ajvr.24.01.0013.xml

## 治疗选择

青光眼的紧急医疗管理侧重于使用渗透性利尿剂如甘露醇（1-2 g/kg IV，20-30分钟内）或口服甘油（1-2 g/kg）快速降低眼内压（IOP），这些药物在30-60分钟内使玻璃体和房水脱水 [1][2]。碳酸酐酶抑制剂（多佐胺、布林佐胺局部使用；醋甲唑胺2-5 mg/kg PO BID）减少房水产生，对犬猫均有效 [1][3]。前列腺素类似物，特别是拉坦前列素，通过增加葡萄膜巩膜排出对犬青光眼最有效，但在猫中效果较差 [1][3]。

慢性药物治疗将局部碳酸酐酶抑制剂与前列腺素类似物联合使用，每日两次给药。β-受体阻滞剂如噻吗洛尔在犬猫中的效果相对较人类差 [1][3]。

有视力眼睛的手术干预包括内窥镜睫状体光凝术，在直视下靶向睫状体色素组织，以及通过管道系统促进房水排出的前房角植入物 [1]。使用外部标志物的经巩膜睫状体光凝术显示约50%的IOP控制成功率 [4]。对于失明、疼痛眼睛的挽救性手术包括眼球摘除术（最常见）、使用一氧化二氮的睫状体冷冻治疗、使用庆大霉素的化学性睫状体消融（尽管与增加肿瘤风险相关），以及带巩膜内假体植入的眼内容剜除术 [1][3]。建议咨询兽医眼科医生进行手术规划。

### Sources
[1] Your treatment options for glaucoma in small animals: https://www.dvm360.com/view/your-treatment-options-glaucoma-small-animals-0
[2] Glaucoma: The 5 o'clock emergency (Proceedings): https://www.dvm360.com/view/glaucoma-5-oclock-emergency-proceedings
[3] Treatment of Glaucoma in Animals - Pharmacology: https://www.merckvetmanual.com/en-au/pharmacology/systemic-pharmacotherapeutics-of-the-eye/treatment-of-glaucoma-in-animals
[4] Glaucoma (Proceedings): https://www.dvm360.com/view/glaucoma-proceedings

## 预防措施

犬青光眼的预防措施集中在高风险对侧眼的预防性治疗和品种特异性筛查计划。在单侧原发性青光眼犬中，对侧眼患病的可能性极高，通常在8个月内 [1]。因此建议对未受影响的眼睛进行预防性治疗，这是保护视力的关键干预措施。

前房角镜检查在识别高风险眼睛中起基础作用，特别是在易患前房角发育不全的品种中，如美国和英国可卡犬、平毛寻回犬、拉布拉多寻回犬、金毛寻回犬、巴吉度猎犬和萨摩耶犬 [1]。这种专业检查使兽医能够在临床症状出现前评估虹膜角膜角并确定青光眼风险。

品种筛查计划应纳入对易感品种的定期前房角镜评估，以早期识别梳状韧带的发育异常 [2]。客户教育策略必须强调原发性青光眼的遗传性质以及高风险动物定期眼科检查的重要性 [1]。应告知主人青光眼症状的紧急性以及在出现角膜水肿、巩膜外层充血或瞳孔异常等症状时需要立即兽医就诊。

预防性治疗涉及在症状显现前预防疾病发生的预防性治疗 [2]。对于猫患者，尽管是纯室内生活方式，定期预防性兽医就诊仍然必不可少 [3]。

### Sources
[1] An overview of canine glaucoma: https://www.dvm360.com/view/an-overview-of-canine-glaucoma
[2] Prophylaxis and Prophylactic Health Treatments: https://www.verywellhealth.com/what-is-the-meaning-of-prophylactic-3157145
[3] 6 ways to pitch preventive care to cat owners: https://www.dvm360.com/view/6-ways-pitch-preventive-care-cat-owners

## 鉴别诊断

青光眼必须与几种表现出相似眼部体征的疾病区分开来，特别是那些引起"红眼"外观的疾病 [1][2]。关键鉴别因素包括特定的临床发现和眼压测量结果。

**前葡萄膜炎**表现为低眼内压（通常<10 mm Hg）、瞳孔缩小和房水闪辉，与青光眼的高压（>25 mm Hg）和瞳孔散大形成对比 [4][5]。葡萄膜炎中发炎的眼睛通常比正常眼睛压力低，而在青光眼中受影响眼睛显示较高压力 [1]。

**晶状体脱位**可引起继发性青光眼，使鉴别具有挑战性 [3]。前房角镜检查和仔细的晶状体位置评估至关重要，因为用于青光眼的前列腺素类似物可能使前脱位的晶状体卡住并加重压力 [5]。

**眼外伤**可能表现出与青光眼相似的巩膜外层血管充血和角膜水肿，但病史和检查通常揭示明显的损伤体征 [1][6]。外伤也可通过血-房水屏障破坏引起继发性青光眼。

**结膜炎**显示浅表血管充血，没有青光眼特征的深部巩膜外层充血 [1]。眼内压保持正常，患者缺乏急性青光眼中见到的瞳孔散大和角膜水肿 [5]。

关键诊断特征包括眼压读数（双眼差异>10 mm Hg提示青光眼）、瞳孔大小（青光眼散大与葡萄膜炎缩小）以及发炎眼睛和正常眼睛之间的压力关系 [7]。品种易感性也很重要，因为某些品种如可卡犬和巴吉度猎犬患原发性青光眼的风险更高 [1][5]。

### Sources

[1] Merck Veterinary Manual - Glaucoma in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/glaucoma-in-animals
[2] DVM 360 - Current approaches to uveitis in the dog and cat: https://www.dvm360.com/view/current-approaches-uveitis-dog-and-cat-proceedings
[3] DVM 360 - An overview of canine glaucoma: https://www.dvm360.com/view/an-overview-of-canine-glaucoma
[4] Merck Veterinary Manual - Anterior Uveitis in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/anterior-uveitis-in-small-animals
[5] Merck Veterinary Manual - Acute Glaucoma in Small Animals: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/ophthalmic-emergencies-in-small-animals/acute-glaucoma-in-small-animals
[6] DVM 360 - The bleeding eye: https://www.dvm360.com/view/bleeding-eye-proceedings
[7] DVM 360 - 6 eye errors you're probably overlooking: https://www.dvm360.com/view/6-eye-errors-you-re-probably-overlooking

## 预后

犬猫青光眼的预后在急性和慢性病例间差异显著，视力保存率直接与干预的时间和积极性相关 [1][2]。在急性青光眼发作中，如果立即开始早期积极治疗可以保存视力，但大多数急性原发性青光眼犬尽管治疗通常在24-48小时内失明 [1]。不幸的是，一旦青光眼发展为伴有牛眼和视神经萎缩的慢性疾病，视力预后极差 [1]。

大多数青光眼眼睛尽管积极进行药物和手术治疗，最终都会丧失视力 [1]。然而，药物和手术选择的持续进步正在扩展治疗工具，并允许视力保存时间越来越长 [1]。原发性青光眼通常最初表现为单侧过程，但大多数高风险犬将在诊断后一年内发展为对侧眼青光眼 [2]。在正常眼压眼中开始预防性抗青光眼和抗炎治疗已被证明可将青光眼发作延迟中位数324天 [2]。

品种特异性因素显著影响预后，某些易感品种如可卡犬、沙皮犬和巴吉度猎犬长期视力结果较差 [1]。即使在视力丧失后，生活质量考虑仍然重要，因为青光眼仍然是一种疼痛性疾病，需要持续管理以保持患者舒适 [2]。不幸的是，青光眼没有有效的"治愈"方法，使其成为一种需要终身管理的疾病 [2]。

### Sources

[1] Glaucoma: The 5 o'clock emergency (Proceedings): https://www.dvm360.com/view/glaucoma-5-oclock-emergency-proceedings
[2] Your treatment options for glaucoma in small animals: https://www.dvm360.com/view/your-treatment-options-glaucoma-small-animals-0