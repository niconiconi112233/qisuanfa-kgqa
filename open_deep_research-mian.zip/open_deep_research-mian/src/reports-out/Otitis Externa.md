# 犬猫外耳炎：临床管理与治疗方法

外耳炎是小动物兽医实践中最常见的疾病之一，影响所有犬只的3.5%，并占兽医诊所就诊量的10-20%。本综合报告探讨了外耳道炎症的多方面性质，从其多样化的感染原因（包括假中间型葡萄球菌、铜绿假单胞菌和厚皮马拉色菌），到有效管理所需的复杂诊断方法。分析涵盖了从局部抗菌药物到全外耳道切除术等手术干预的循证治疗方案，同时阐述了过敏性皮炎和品种特异性解剖学考虑等潜在易感因素在急性和慢性病例中的关键作用。

## 摘要

本报告表明，成功管理外耳炎需要采取系统方法，解决原发性原因、继发感染和持续因素。该疾病的复杂性在其多样的病原谱中显而易见，其中铜绿假单胞菌等细菌感染在慢性病例中呈现特别的治疗挑战，而厚皮马拉色菌则经常使炎症过程复杂化。诊断成功取决于正确的耳镜检查结合细胞学评估，而先进影像学检查则保留给涉及疑似中耳炎的复杂病例。

急性和慢性病例的治疗结果差异显著。虽然急性病例通常在适当治疗1-3周内痊愈，但慢性外耳炎可能需要4周至3个月的治疗。预后很大程度上受主人依从性和潜在疾病（如异位性皮炎）成功管理的影响。专注于正确耳部卫生、环境控制和易感因素管理的预防策略对于长期成功至关重要。

| 因素 | 急性外耳炎 | 慢性外耳炎 |
|--------|---------------------|------------------------|
| 治疗持续时间 | 1-3周 | 4周至3+个月 |
| 主要病原体 | 葡萄球菌、马拉色菌 | 假单胞菌、混合感染 |
| 预后 | 适当治疗后预后极佳 | 谨慎，需要长期管理 |
| 并发症 | 及时治疗则最小 | 可能需要手术干预 |

早期干预和专科转诊显著改善结果，与仅由初级医疗管理相比，获得委员会认证的皮肤科医生实现了更高的缓解率和更低的复发率。

## 疾病概述

外耳炎定义为鼓膜外侧外耳道的炎症，可伴有或不伴有耳廓受累[1]。这种情况是小动物（尤其是犬）就诊兽医的最常见原因之一，影响所有犬只的3.5%，就诊兽医诊所的犬中有10-20%患有耳部疾病[1][7]。

该疾病可表现为急性或慢性，可为单侧或双侧[1]。幼年动物可能更常受影响，最高发病率发生在5-8岁之间[7]。长耳犬占主导地位，特别是可卡犬、寻回犬和德国牧羊犬[7]。

品种易感性反映了与皮肤疾病相关的因素，特别是寻回犬和梗犬的过敏症[1]。拉布拉多寻回犬、沙皮犬和各种梗犬品种显示出更高的易感性[6][9]。外耳炎没有公认的性别倾向性[1]。

猫外耳炎比犬类疾病少见[7]。该疾病范围可从轻微、自限性发作到需要广泛医疗或手术干预的严重慢性病例。

### Sources

[1] Otitis Externa in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[6] Food allergies in the dog and cat (Proceedings): https://www.dvm360.com/view/food-allergies-dog-and-cat-proceedings  
[7] Otitis externa/media (Proceedings): https://www.dvm360.com/view/otitis-externamedia-proceedings
[9] Update on canine atopy: Diagnosis and management: https://www.dvm360.com/view/update-canine-atopy-diagnosis-and-management-proceedings

## 常见病原体

外耳炎涉及多种传染性病原体，这些病原体导致外耳道的炎症过程。常见分离的主要细菌病原体包括假中间型葡萄球菌，它是犬中最常见的革兰氏阳性细菌病因[2]。革兰氏阴性细菌，特别是铜绿假单胞菌，是重要病原体，尤其在慢性病例中，并且通常与更严重、难治性感染相关[4][6]。

其他重要细菌病因包括奇异变形杆菌和大肠杆菌，这些细菌常从受影响的耳部培养出[6]。肠球菌属也是外耳炎病例中的常规细菌分离株[5]。

酵母菌感染主要由厚皮马拉色菌引起，在外耳炎发作期间经常大量繁殖[2][6]。这种共生生物在耳部微环境改变时变为致病性，通常促成炎症反应。

寄生虫病因包括耳痒螨（耳螨），这在猫中特别常见，但也影响犬[7][8]。蠕形螨属偶尔会引起犬猫外耳道内的局部增殖，这是唯一受影响的身体部位[6][7]。

这些病原体的相对临床重要性差异很大。革兰氏阴性杆菌的细菌感染，特别是假单胞菌，通常与更具挑战性的治疗结果相关，并可能表明存在潜在的易感因素[4][6]。

### Sources

[1] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] A powerful tool for addressing inflammation early in dogs with otitis externa: https://www.dvm360.com/view/a-powerful-tool-for-addressing-inflammation-early-in-dogs-with-otitis-externa
[3] FDA approves Mometamax Single: https://www.dvm360.com/view/fda-approves-mometamax-single
[4] Collaboration with the clinical microbiology laboratory optimizes diagnosis: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml
[5] Otitis Externa in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[6] Mange in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/integumentary-system/mange/mange-in-dogs-and-cats
[7] Itchy cat: Don't want that! (Proceedings): https://www.dvm360.com/view/itchy-cat-dont-want-proceedings

## 临床症状和体征

外耳炎的临床体征可包括摇头、耳部操作时疼痛、恶臭、渗出物、红斑、糜烂、溃疡、肿胀或耵聍腺增生的任何组合[1]。根据病因或疾病持续时间，耳道可能疼痛或瘙痒，体征可能突然或长期存在[1]。

**典型临床表现**

最常见的体征包括摇头、异味、皮肤发红、肿胀、抓挠耳朵、分泌物增多和鳞状皮肤[1,2]。深色分泌物通常表明存在酵母菌感染或耳螨，但也可能发生在细菌或混合感染中[1]。患者经常表现出因抓挠造成的自伤证据，耳廓变形或摇头模式表明长期耳部不适[1,2]。

红斑耵聍性耳炎的特征是红斑和耵聍性分泌物，最常与马拉色菌相关[3]。在猫中，耳螨的典型临床体征包括发病年龄小，伴有典型的黑褐色耵聍性分泌物，通常为双侧[4]。

**疼痛和行为反应**

患有外耳炎的动物经常在耳部操作时表现出疼痛，并可能因耳部不适而将头偏向一侧[1]。极度疼痛的病例可能需要镇静或全身性糖皮质激素治疗，然后才能进行适当的耳镜评估[1]。

**品种特异性模式**

外耳炎的品种易感性反映了皮肤疾病的易感性，如寻回犬和梗犬的过敏症[1]。虽然没有公认的性别分布，但幼年动物可能更常受影响[1]。

### Sources

[1] Merck Veterinary Manual Otitis Externa in Animals: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] DVM360 Stopping the otitis snowball: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause
[3] AVMA Journals Managing recurrent otitis externa in dogs: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[4] DVM360 The crusted cat: https://www.dvm360.com/view/crusted-cat-scraping-away-confusion

## 诊断方法

外耳炎的诊断需要结合临床检查、样本收集和适当检测方法的系统方法[1]。诊断基础包括耳镜检查、细胞学评估以及必要时进行培养[2]。

**耳镜检查**
应对所有表现为耳部疾病的患者进行耳镜评估[2]。该检查评估垂直和水平耳道的狭窄、红斑、糜烂、腺体增生、渗出物和肿块[2]。视频耳镜与手持式耳镜相比提供更佳的放大和可视化效果，特别适用于具有挑战性的病例[5]。

**细胞学评估**  
细胞学是最有价值的诊断工具，因其简单性、实用性和快速结果[1,5]。样本应在引入清洁剂或治疗前从水平耳道收集[5]。改良瑞氏染色（Diff-Quik）在临床上适用于识别细菌、酵母菌和炎症细胞[1,5]。正常耳朵含有薄的蜡状耵聍和角质化鳞状上皮细胞，而异常发现包括中性粒细胞数量增加、细菌（球菌表明葡萄球菌或链球菌；杆菌提示假单胞菌）和酵母菌生物[5,7]。

**先进影像学检查**
当怀疑中耳炎或在复杂病例中，需要进行先进影像学检查[2]。CT和MRI在检测中耳受累方面比常规X光片具有更高的敏感性，可显示液体积聚、骨骼改变和软组织变化[2]。

### Sources

[1] Merck Veterinary Manual Cytology - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

[2] Merck Veterinary Manual Otitis Media and Interna in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals

[3] Merck Veterinary Manual Otitis Externa in Animals - Ear Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals

[4] DVM 360 Feline otitis (Proceedings): https://www.dvm360.com/view/feline-otitis-proceedings

[5] DVM 360 Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause

[6] Managing recurrent otitis externa in dogs - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml

[7] Diagnosing and managing ear disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-ear-disease-proceedings

## 治疗选择

**手术干预**
当保守药物治疗失败时，对于严重的慢性外耳炎，手术选择变得必要。全外耳道切除术加侧壁鼓室骨切除术（TECA-BO）适用于伴有耳道增生、狭窄和钙化的终末期疾病[2][3]。该手术涉及从耳廓到鼓室泡完全切除耳道，为难治性病例提供确定性治疗[2]。

对于没有显著增生或狭窄的较轻微病例，可考虑侧耳道切除术，以改善水平耳道的引流和通气[3]。然而，该手术在慢性病例中成功率有限，通常需要转为TECA-BO[2][3]。

**并发症和结果**
TECA-BO带来显著风险，包括面神经麻痹（10-30%的病例）、出血、前庭功能障碍和慢性瘘管形成（3-15%的病例）[2]。尽管存在这些风险，该手术提供了极佳的生活质量改善，消除了慢性疼痛和对持续医疗管理的需求[2]。大多数患有终末期耳炎的犬在术前已有明显的听力损失，使得术后耳聋问题较小[3]。

**先进影像学和规划**
计算机断层扫描或磁共振成像通过识别软骨钙化和骨骼变化来确定手术候选资格，这些变化表明医疗预后不良[5]。这些影像学模式指导适当的治疗选择和手术规划以获得最佳结果[5]。

### Sources
[1] Ear canal ablation, more than palliation (Proceedings): https://www.dvm360.com/view/ear-canal-ablation-more-palliation-proceedings
[2] Canine ear canal surgery considerations: https://www.dvm360.com/view/canine-ear-canal-surgery-considerations
[3] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer

## 预防措施

小动物外耳炎的预防侧重于解决易感因素和实施适当的耳部卫生方案[1]。耳道应保持干燥和通风良好，建议经常游泳的犬使用局部收敛剂[1]。洗澡时应防止水进入耳道，以减少浸渍，这会损害皮肤屏障功能并易导致机会性感染[1][3]。

定期耳部清洁至关重要，主人需要接受适当的技术教育[1][2]。一些兽医建议每周进行耳部清洁，以鼓励宠物主人定期检查宠物的耳朵[2]。修剪耳廓凹面和外耳道周围的毛发可改善通风并减少湿度[1][3]。然而，不建议常规拔毛，因为它可能引起炎症反应，增加细菌和酵母菌定植的易感性[2]。

管理潜在的原发性原因对预防至关重要[1]。这包括控制过敏性状况如异位性皮炎和食物超敏反应，这些是主要的易感因素[1]。内分泌疾病如甲状腺功能减退和肾上腺皮质功能亢进应被识别并适当管理[1]。定期兽医监测允许早期发现复发性疾病并调整预防方案[1]。

### Sources
[1] Otitis Externa in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-externa/otitis-externa-in-animals
[2] Stop getting burned by ear infections: https://www.dvm360.com/view/stop-getting-burned-ear-infections
[3] Ear Infections and Otitis Externa in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/ear-infections-and-otitis-externa-in-dogs

## 鉴别诊断

几种疾病可能模拟犬猫的外耳炎，需要仔细临床鉴别。中耳炎在耳道深处表现，耳镜检查可能显示鼓膜完整，但临床症状常与外耳疾病重叠[1]。内耳炎通常表现为神经系统体征，包括头倾斜、眼球震颤和共济失调，这些在单纯外耳炎病例中不存在。

没有继发细菌感染的耳痒螨（耳螨）产生特征性的深色咖啡渣样碎屑，但缺乏细菌性外耳炎典型的脓性分泌物。显微镜检查显示活的螨虫和卵，将其与细菌原因区分开来。

耳道异物引起突然发作的摇头和疼痛，通常为单侧，耳镜检查可见阻塞。与感染性外耳炎不同，异物病例通常突然发作，没有逐渐进展。

肿瘤性疾病包括耵聍腺腺瘤、鳞状细胞癌或炎性息肉表现为耳道内可见肿块。这些病变通常为单侧，可导致部分耳道阻塞并伴有相关分泌物。

影响耳朵的自身免疫性疾病如落叶性天疱疮或红斑狼疮表现为特征性水疱、糜烂或结痂病变，延伸到耳道外并累及耳廓和耳周皮肤，这与典型外耳炎局限于耳道的炎症不同。

原发性分泌性中耳炎（胶耳），特别是在骑士查理王小猎犬中，导致持续性传导性耳聋，没有外耳炎典型的疼痛性分泌物[2]。

### Sources

[1] Managing recurrent otitis externa in dogs: https://avmajournals.avma.org/view/journals/javma/261/S1/javma.23.01.0002.xml
[2] Deafness in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/deafness/deafness-in-animals

## 预后

外耳炎的预后在急性和慢性病例之间差异显著，多种因素影响长期结果[1]。急性外耳炎通常在识别并管理原发性原因后，在1-3周内对适当治疗反应良好[1]。相比之下，慢性病例呈现更具挑战性的预后，通常需要至少4周的治疗时间，并可能延长至3个月或更长时间[1]。

主人依从性在决定预后方面起着关键作用，因为无反应性或慢性复发性外耳炎是宠物主人向不同兽医寻求多种意见的常见原因[2]。潜在原因显著影响预后，涉及异位性皮炎或食物不良反应等过敏性状况的病例需要终身管理[1]。成功结果取决于在治疗继发感染的同时控制原发性因素。

复发性外耳炎尤其具有挑战性，局部治疗仅对个体发作提供短期成功，常导致炎症反复循环[1]。早期转诊专科医生提供更好的结果，由获得委员会认证的皮肤科医生治疗的犬与仅由初级医疗管理的犬相比，显示出更低的复发率和更好的增生性病变缓解率[3]。并发症可能很严重，当药物治疗失败时，一些病例最终需要全外耳道切除术和鼓室骨切除术，尽管通过积极的早期干预很少需要这样做[1]。

### Sources

[1] Treatment of Pseudomonas otitis in the dog (Sponsored by Pfizer): https://www.dvm360.com/view/treatment-pseudomonas-otitis-dog-sponsored-pfizer
[2] Veterinary Medicine Essentials: Otitis: https://www.dvm360.com/view/veterinary-medicine-essentials-otitis
[3] Stopping the otitis snowball: identifying the infection and cause: https://www.dvm360.com/view/stopping-the-otitis-snowball-identifying-the-infection-and-cause