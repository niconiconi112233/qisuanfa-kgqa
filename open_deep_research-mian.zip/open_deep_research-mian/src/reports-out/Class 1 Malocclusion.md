# 伴侣动物中的一类错颌畸形

一类错颌畸形代表了犬猫中最常见的牙齿排列紊乱，其特征为正常的颌骨关系但个别牙齿位置异常。与涉及颌骨长度差异的骨骼性错颌畸形不同，一类病例保持正常的上颌-下颌对齐，而特定牙齿偏离理想位置。本综合报告探讨了一类错颌畸形在小动物临床中的临床意义、诊断方法和治疗策略。分析涵盖了品种特异性易感性，从设得兰牧羊犬的矛状犬齿到长头品种的基底狭窄情况，同时探讨了通过球疗的保守治疗和先进的正畸干预措施。理解这些情况对兽医从业者至关重要，因为早期识别和适当治疗可防止进展为包括牙周病和组织创伤在内的严重并发症。

## 疾病概述

一类错颌畸形，也称为中性颌，是犬猫的一种牙齿状况，特征为颌骨长度正常但一个或多个牙齿位置异常[1]。这种情况代表了最常见的错颌畸形类型，其中上颌和下颌关系保持正常，但个别牙齿在牙弓内排列不齐[1][2]。

一类错颌畸形在大多数情况下被认为是非遗传性的，尽管存在某些品种易感性[2][4]。颌骨长度错颌畸形被认为是遗传性的，而一类错颌畸形通常被认为是非遗传性的，但设得兰牧羊犬和波斯猫的近中位上颌犬齿等例外情况除外[4]。例子包括设得兰牧羊犬常见的矛状犬齿（近中位上颌犬齿），以及长头品种和标准贵宾犬中常见的基底狭窄下颌犬齿[2]。

这种疾病可表现为多种形式，包括前部交叉颌、后部交叉颌和水平咬合[1]。患病率数据在不同兽医研究中差异显著，单独针对一类错颌畸形的具体数据有限[3]。然而，错颌畸形在小动物临床中经常遇到，特别是在常规牙齿检查期间。早期识别至关重要，因为许多病例出现功能性并发症，如果不治疗可能进展为更严重的牙齿疾病[1][2]。

### Sources

[1] Defining dental malocclusions in dogs - dvm360: https://www.dvm360.com/view/defining-dental-malocclusions-dogs
[2] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings
[3] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion
[4] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth

## 病因学和病理生理学

一类错颌畸形特征为正常的颌骨关系但个别牙齿位置异常，源于多种遗传和发育因素。最常见的病因因素是遗传成分，在特定品种如设得兰牧羊犬和标准贵宾犬中尤为明显，这些品种的矛状效应和基底狭窄错颌畸形表现出品种易感性[1]。与主要为遗传性的骨骼性错颌畸形（二至四类）不同，一类错颌畸形通常被认为是非遗传性的牙齿异常，尽管不能完全排除遗传影响[2]。

病理生理学涉及发育阶段正常牙齿萌出通路的破坏。当恒牙遵循错误的萌出轨迹时，它们无法对乳牙根部施加适当压力，阻碍正常的根部吸收和脱落[3]。这导致持续性乳牙与错位恒牙并存，导致拥挤和异常咬合关系。牙齿发育过程中的环境因素，包括未萌出牙齿的创伤和上方乳牙引起的感染，可导致釉质低钙化和随后的结构异常[1]。

影响釉质形成的发育异常，特别是由犬瘟热等发热性疾病引起的，损害牙齿结构完整性[1]。一类错颌畸形可由局部原因引起，包括唇、颊或舌压力，囊性或肿瘤性形成，以及系统性或内分泌疾病[4]。当恒牙异常萌出时发生乳牙滞留，阻止正常脱落机制并导致包括拥挤引起的牙周病在内的继发并发症[4]。

短头品种面临口腔空间受限的额外挑战，导致前臼齿和臼齿因拥挤而旋转，常伴有歪颌模式和颅面不对称[2]。许多小品种的软骨发育不全基因影响软骨发育，导致中面部结构发育不全，促成错颌畸形模式[3]。

### Sources
[1] Dental Disorders of Dogs - Dog Owners: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/dental-disorders-of-dogs
[2] Oral diagnosis: Hard tissue valuation (Proceedings): https://www.dvm360.com/view/oral-diagnosis-hard-tissue-valuation-proceedings
[3] Ethical orthodontics (Proceedings): https://www.dvm360.com/view/ethical-orthodontics-proceedings
[4] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings

## 临床表现和诊断

一类错颌畸形表现为颌骨对齐正常但个别牙齿位置异常[1]。临床检查显示尽管上颌-下颌关系正常，但牙齿位置异常，这将其与骨骼性错颌畸形区分开来[2]。常见表现包括矛状犬齿、前部交叉颌、后部交叉颌和水平咬合构型[2]。

口腔检查应系统评估咬合，评估中线匹配、切牙重叠、犬齿交错、前臼齿咬合和裂齿重叠[1]。清醒检查提供初步评估，而麻醉评估允许全面的牙周探查和详细的牙齿定位分析[1]。正常牙周探诊深度在犬为1-3毫米，在猫为0.5-1毫米[1]。

诊断影像学检查对完整评估至关重要。口腔内牙科放射学提供根部定位、牙周附着和牙槽骨结构的详细评估[1]。包括锥形束计算机断层扫描（CBCT）在内的先进影像学可用于需要详细三维可视化的复杂病例[3]。

鉴别诊断包括其他错颌畸形分类、滞留乳牙和发育性牙齿异常[2]。鉴别因素集中在颌骨关系评估上——一类保持正常骨骼对齐，而二类和三类分别涉及下颌远中错颌或近中错颌[2]。短头品种显示更高的错颌畸形患病率，需要品种特异性评估方案[4]。

### Sources
[1] Merck Veterinary Manual Periodontal Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[2] Defining dental malocclusions in dogs - dvm360: https://www.dvm360.com/view/defining-dental-malocclusions-dogs
[3] American Journal of Veterinary Research Evaluation of the diagnostic yield of dental radiography and cone-beam computed tomography: https://avmajournals.avma.org/view/journals/ajvr/79/1/ajvr.79.1.62.xml
[4] Initial screening for dental abnormalities identified by analysis: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/85/9/ajvr.24.03.0085.pdf

## 治疗选择

一类错颌畸形的保守管理策略包括球疗和阻断性正畸，旨在发育期间引导正确的牙齿排列。球疗涉及鼓励幼犬每天三次携带适当大小的球15分钟，这会对舌侧移位的下颌犬齿施加倾斜平面力[1]。这种优雅的治疗选择不需要麻醉，在适当年龄应用时可纠正许多错颌畸形。

正畸装置代表更复杂的治疗方法。倾斜平面可以直接用丙烯酸树脂制作，或创建为固定在上颌犬齿上的实验室铸造装置[2]。这些装置通过施加的力被动移动牙齿，通常在两到四周内实现矫正。先进的正畸治疗利用托槽和弹性链为更复杂的错位创造可控的倾斜力。

手术干预包括使用矿物三氧化物凝聚体的活髓牙冠切除术，在犬中显示出80%的成功率[3]。对于引起组织创伤或功能损害的严重病例，可能需要拔除受影响的牙齿，特别是当正畸矫正不可行时。治疗决策需要仔细考虑患者年龄、错颌畸形严重程度和潜在并发症。

干预时机至关重要——在年幼动物中早期识别和治疗比成年动物延迟干预产生更好的结果[4]。

### Sources
[1] Canine orthodontics: Providing healthy occlusions: https://www.dvm360.com/view/dental-corner-canine-orthodontics-providing-healthy-occlusions
[2] Malocclusion with severe tissue destruction in a dog: https://www.dvm360.com/view/malocclusion-with-severe-tissue-destruction-dog
[3] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.pdf
[4] The ABCs of veterinary dentistry: M is for malposition and malocclusion: https://www.dvm360.com/view/abcs-veterinary-dentistry-m-malposition-and-malocclusion

## 预防和预后

一类错颌畸形的预防主要集中在选择性繁殖实践和早期干预策略上。加拿大兽医医学协会反对导致身体形态和功能有害变化的选择性繁殖[1]。对于一类错颌畸形，繁殖建议包括避免交配已知有正畸异常的动物，因为许多错颌畸形具有遗传成分[2]。

早期干预对最佳结果至关重要。通过早期检测和治疗预防重大问题符合动物的最佳利益[3]。应在幼年动物中考虑阻断性正畸，特别是当乳牙滞留时，因为没有两颗牙齿可以同时占据同一个牙槽[3]。乳牙维持正确的咬合，而恒牙在错颌畸形中发育，因此及时拔除至关重要。

治疗成功在很大程度上取决于早期识别和适当干预[1]。当牙齿错位引起创伤时，应通过正畸、牙髓病学、拔牙或偶尔的牙齿成形术进行干预[1]。对患者来说，最少侵入性治疗应始终是首要考虑[1]。

一类错颌畸形的预后因严重程度和干预时机而异显著。生长阶段的早期治疗提供最佳结果，当适当实施时，正畸治疗可预防或缓解错颌畸形[3]。一旦达到骨骼成熟，治疗选择变得更加有限。长期成功需要持续监测和可能的后续治疗。创造健康的口腔，而非完美的咬合，应成为主要目标[3]。

### Sources

[1] Malocclusion and tooth-on-tooth trauma: https://www.dvm360.com/view/malocclusion-and-tooth-tooth-trauma
[2] Oral diagnosis: Hard tissue valuation (Proceedings): https://www.dvm360.com/view/oral-diagnosis-hard-tissue-valuation-proceedings
[3] Identifying problems early in a puppy or kitten mouth: https://www.dvm360.com/view/identifying-problems-early-puppy-or-kitten-mouth