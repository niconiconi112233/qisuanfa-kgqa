# 小动物兽医实践中的会阴疝

会阴疝是小动物兽医实践中的一种重要外科疾病，主要影响8岁以上的未绝育雄性犬。这种情况涉及骨盆膈肌的减弱，使腹部和盆腔器官疝入会阴区域。该报告探讨了涉及激素影响和前列腺疾病的多因素病因学，需要系统性临床检查和影像学诊断的挑战，以及具有高复发率的复杂外科管理。涉及膀胱后屈和肠绞窄的紧急情况需要立即干预。了解品种易感性、通过早期绝育的预防措施以及预后因素对于在这种具有挑战性的疾病中获得最佳患者结果至关重要。

## 疾病概述与流行病学

会阴疝被定义为腹部或盆腔器官通过 weakened 或有缺陷的骨盆膈异常突出，发生在肛门外侧 [1][4]。这些疝与其他类型的区别在于，移位的器官通常不被包含在腹膜囊内 [4]。

解剖学基础涉及骨盆膈的提肛肌和尾骨肌的失效或减弱 [4]。提肛肌是一块薄扇形肌肉，与筋膜层一起形成骨盆膈，泌尿生殖道和消化道通过它向外开口 [1][4]。

会阴疝最常见于8岁以上的未绝育雄性犬，尽管也可能发生在较年轻的动物中 [1][2][4]。这种情况主要影响雄性，雌性很少受到影响 [4]。已报告多个品种易感性，包括威尔士柯基犬、波士顿梗、拳师犬、柯利犬、凯尔皮犬、腊肠犬、迷你贵宾犬、古代英国牧羊犬和北京犬 [4]。

尚未确定特定原因，但可能涉及多种致病因素 [1][2][4]。激素失衡病因学得到以下证据支持：一些受影响的犬同时患有睾丸肿瘤、前列腺肿大或男性化囊肿子宫扩大 [1][2][4]。未绝育雄性中较高的发病率表明激素影响可能起主要作用 [4]。绝育降低了会阴疝的风险 [3]。

### Sources

[1] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings
[2] Diaphragmatic, inguinal, & perinial hernia repair (Proceedings): https://www.dvm360.com/view/diaphragmatic-inguinal-perinial-hernia-repair-proceedings
[3] Do we need a paradigm shift in canine neutering?: https://www.dvm360.com/view/do-we-need-a-paradigm-shift-in-canine-neutering-
[4] Perineal Hernia in Dogs - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perineal-hernia-in-dogs

Looking at the provided sources, I need to synthesize the existing section content with the new source material to enhance the "Etiology and Clinical Presentation" section. The existing content is comprehensive, and I'll integrate additional information from the sources while maintaining the section structure.

## 病因学和临床表现

会阴疝是由于提肛肌和尾骨肌失效导致，使盆腔和腹部内脏疝入会阴 [1]。这种情况主要影响中老年未绝育雄性犬，激素影响在发病机制中起主要作用 [1]。

**激素和前列腺因素**
归因于性激素失衡的前列腺增生被强烈认为是致病因素 [1]。雌激素和雄激素都促进会阴疝的发展，同时伴有前列腺疾病的情况很常见 [1,3]。一些受影响的犬表现出睾丸肿瘤、前列腺肿大或子宫异常，支持激素病因学理论 [3]。

**临床表现**
主要临床表现包括会阴肿胀，通常无痛，可能是单侧或双侧的 [1]。受影响的犬通常表现出便秘、顽固性便秘、里急后重和排便困难，这是由于直肠偏向疝囊所致 [1,4]。泌尿生殖系统症状包括排尿困难和排尿疼痛，特别是在膀胱受累时 [1,4]。

**紧急情况**
当发生膀胱后屈时，会阴疝成为紧急情况，导致尿路梗阻 [1]。在这些情况下，会阴肿胀可能坚硬且难以复位，需要立即干预，如膀胱穿刺或导尿 [1]。绞窄的肠环也可能造成紧急情况，伴有肠梗阻症状 [1]。

### Sources

[1] Perineal Hernia in Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perineal-hernia-in-dogs
[2] A Review of the Surgical Management of Perineal Hernias in Dogs: https://meridian.allenpress.com/jaaha/article/54/4/179/184150/A-Review-of-the-Surgical-Management-of-Perineal
[3] Dogs neutered prior to perineal herniorrhaphy or that develop postoperative fecal incontinence are at an increased risk for perineal hernia recurrence: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.07.0487.xml
[4] Disorders of the Rectum and Anus in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-rectum-and-anus-in-dogs

## 诊断方法和鉴别诊断

会阴疝的诊断方法需要从直肠指检开始的系统性临床检查。这揭示了骨盆膈单侧或双侧减弱的关键发现，直肠壁偏向疝侧（单侧病例）或直肠扩张（双侧病例）[1]。

影像学在全面诊断中起着关键作用。腹部X线片可能显示直肠粪便扩张，由于膀胱疝导致会阴区软组织密度增加，或疝内充满气体的肠环 [1]。会阴超声可以确定前列腺、膀胱或肠环是否存在于疝囊内 [1]。

关键鉴别诊断包括前列腺旁囊肿，这些囊肿源于胚胎残留物并充满液体，对邻近器官造成类似的压迫症状 [2]。这些囊肿可以通过超声检查区分，超声显示具有高回声外缘和低回声或无回声内容的结构 [2]。前列腺脓肿代表另一个重要的鉴别诊断，通常由慢性细菌性前列腺炎发展而来，特征是前列腺实质内含有脓性、化脓性渗出物的囊袋 [2]。

肛门囊肿瘤，特别是腺癌，也必须考虑，因为它可能表现为肛门周围肿胀和里急后重 [3]。这些肿瘤具有侵袭性，常转移至腰下淋巴结，并在25-50%的病例中引起副肿瘤性高钙血症 [3]。

其他鉴别诊断包括肛门周围肿瘤，如肝样腺瘤，这些肿瘤通常发生在老年未绝育雄性犬中，具有特征性的细胞学特征 [4]。临床鉴别依赖于疝的可复性特征与肿瘤性肿块的坚实、不可复性特征。

### Sources
[1] Perineal Hernia in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perineal-hernia-in-dogs
[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[3] Clinical Rounds: Anal sac adenocarcinoma: https://www.dvm360.com/view/clinical-rounds-anal-sac-adenocarcinoma
[4] Clinical Exposures: Canine circumanal gland adenoma: The cytologic clues: https://www.dvm360.com/view/clinical-exposures-canine-circumanal-gland-adenoma-cytologic-clues

## 治疗选择和外科管理

会阴疝的治疗在大多数情况下需要外科干预，医疗稳定化处理任何并发问题。初始管理侧重于解除存在的尿道梗阻，并通过粪便软化剂和灌肠解决便秘问题 [1][2]。

外科修复通常采用闭孔内肌移位技术，该技术将闭孔肌从坐骨上提起，并将其内侧缝合到肛门括约肌，外侧缝合到坐骨结节韧带 [3]。这种方法通过避免肛门括约肌畸形和更好地处理大型腹侧疝，克服了标准修复的缺点 [3]。替代技术包括阔筋膜移植，可能提供与传统方法相当的结果 [1]。

对于伴有肠绞窄的紧急情况，立即外科干预可防止组织坏死 [2]。在尿路梗阻病例中导尿失败时，可能需要进行膀胱穿刺和疝复位 [4]。

在疝修复期间强烈建议同时进行绝育手术，因为在手术矫正前已绝育的犬复发可能性高4.4倍 [5]。术后护理包括6-8周的严格活动限制、疼痛管理以及监测感染、血清肿形成或复发等并发症 [2]。由于高复发率（10-46%）和潜在并发症，预后仍然谨慎 [4]。

### Sources

[1] Treatment of canine perineal hernia with a fascia lata graft: https://avmajournals.avma.org/view/journals/javma/262/5/javma.23.11.0650.xml
[2] Jejunal strangulation and incarceration associated with: https://avmajournals.avma.org/view/journals/javma/260/1/javma.20.11.0627.xml
[3] Anorectal disease: Tumors best treated by complete surgical excision: https://www.dvm360.com/view/anorectal-disease-tumors-best-treated-complete-surgical-excision
[4] Perineal Hernia in Dogs - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perineal-hernia-in-dogs
[5] Dogs neutered prior to perineal herniorrhaphy or that develop: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.07.0487.xml

## 预防和预后

**预防措施**
早期绝育代表会阴疝最有效的预防策略 [1]。在疝修复期间同时进行绝育手术被强烈推荐以降低复发风险 [1]。易感条件的管理包括解决慢性便秘、前列腺肿大和导致骨盆膈减弱的睾丸疾病 [2]。激素影响起主要作用，未绝育雄性中较高的发病率支持了绝育的重要性 [1]。

**预后和预期结果**
由于高复发率和潜在并发症，预后通常谨慎 [1]。复发率根据外科技术和同时进行的手术在10-46%之间 [1]。替代来源报告复发率在2-40%的病例之间 [2]。大多数会阴疝不是紧急情况，除非并发膀胱后屈或肠绞窄 [2]。

**预后因素和长期管理**
关键预后因素包括采用的外科技术、同时进行的绝育手术和患者年龄 [1][2]。双侧疝需要分阶段手术方法，间隔4-6周，以最小化对外部肛门括约肌的压力 [2]。术后并发症包括大便失禁、伤口感染和影响长期结果的神经损伤 [2]。术后应维持低残留饮食，以防止排便时过度用力 [2]。

### Sources
[1] Merck Veterinary Manual Perineal Hernia in Dogs: https://www.merckvetmanual.com/digestive-system/diseases-of-the-rectum-and-anus/perineal-hernia-in-dogs
[2] Herniorrhaphy (Proceedings): https://www.dvm360.com/view/herniorrhaphy-proceedings