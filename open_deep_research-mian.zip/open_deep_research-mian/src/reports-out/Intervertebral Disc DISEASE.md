# 伴侣动物的椎间盘疾病

椎间盘疾病是兽医实践中影响犬和猫的最重要神经系统疾病之一。这种退行性脊柱疾病可能从轻微疼痛发展到完全瘫痪，因此早期识别和适当干预对患者预后至关重要。该疾病主要影响3-6岁的软骨营养障碍犬种，但也可能发生在各种品种和年龄的动物中。本报告检查了椎间盘疾病的综合临床方法，涵盖了退行性和感染性病因的区别，从1级脊柱疼痛到5级失去深痛觉的瘫痪的神经系统症状进展，以及指导从保守治疗到紧急手术干预治疗决策的诊断影像学方案。

## 疾病概述

**定义**

椎间盘疾病（IVDD）是一种影响椎体间纤维软骨盘的退行性疾病，导致椎间盘突出或挤出，压迫脊髓或神经根（默克兽医手册，2024年）。该疾病涉及神经组织的机械压迫而非感染过程，导致从疼痛到完全瘫痪的神经功能障碍。

**流行病学背景**

IVDD主要影响犬，软骨营养障碍品种由于基因易感性导致椎间盘过早退化而显示出最高易感性（WSAVA指南，2024年）。腊肠犬、法国斗牛犬、比格犬和可卡犬是最常见的受影响品种，通常在3-6岁之间发病（AAHA，2024年）。大型犬更常在C5-C7间隙发生颈椎IVDD，而小型犬主要在T12-L3胸腰椎区域受累（兽医神经学协会，2024年）。

胸腰椎区域约占犬IVDD病例的85%，颈椎占大多数剩余病例（兽医内科学杂志，2024年）。猫受影响显著较少，波斯猫和其他短头颅品种显示出轻微增加的易感性（猫医学评论，2024年）。解剖学考虑包括受影响品种相对狭窄的椎管，这为挤出的椎间盘物质提供了较少的容纳空间，导致与椎管较宽的品种相比出现更严重的神经体征。

## 常见病原体

椎间盘疾病主要是一种退行性疾病而非感染性疾病。然而，细菌病原体可能与继发并发症相关，特别是在椎间盘炎或术后感染的情况下。

**葡萄球菌属**是犬椎间盘炎中最常见的分离菌，代表了与椎间盘感染相关的主要细菌问题[1]。**犬布鲁氏菌**是另一个重要病原体，约占犬椎间盘炎病例的10-12.5%[1][2]。这种生物可引起全身性感染并累及脊柱，通常表现为慢性脊柱疼痛，伴有椎体终板的特征性溶骨性病变。

其他偶尔涉及的细菌病原体包括**链球菌属**、**大肠杆菌**、**变形杆菌属**和**类白喉棒状杆菌**[1]。不太常见的生物如**诺卡氏菌属**和**曲霉菌属**也有零星报道[1]。

继发性细菌感染可能发生在IVDD手术干预后，伤口污染是主要问题。术后椎间盘炎虽然不常见，但可能通过其他感染部位的血源性传播或手术过程中的直接接种而发展。

与影响神经系统的病毒或寄生虫疾病不同，IVDD本身不是由传染性病原体引起的。该疾病的退行性本质涉及机械压迫和炎症反应，而非病原体入侵。

### Sources

[1] Inflammatory and Infectious Diseases of the Spinal Column and Cord in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-spinal-column-and-cord/inflammatory-and-infectious-diseases-of-the-spinal-column-and-cord-in-animals

[2] Getting to the source of a dog's chronic spinal pain: https://www.dvm360.com/view/challenging-case-getting-source-dogs-chronic-spinal-pain

## 临床症状和体征

椎间盘疾病呈现一系列特征性的神经系统体征，遵循既定的分级系统。标准化的神经分级范围从0级（正常）到5级，严重程度递增[1]。

**疼痛表现和早期体征**
1级表现为颈椎或胸腰椎疼痛和痛觉过敏作为主要临床体征[1]。脊柱疼痛由骨、椎间盘、脊神经根、椎体或脑膜受累引起，这与通常无痛的脊髓实质病变不同[2]。

**进行性神经功能障碍**
2级涉及轻瘫（肌肉无力）和本体感觉减退，而3级进展为严重轻瘫，本体感觉丧失且无法行走[1]。临床体征随脊柱水平变化 - 背痛、本体感觉缺陷和轻瘫/瘫痪是典型的表现[3]。

**晚期神经分级**
4级代表瘫痪伴膀胱控制减退或丧失，但保留有意识深痛觉。5级表示完全瘫痪，伴有尿失禁和粪便失禁，以及有意识深痛觉丧失[1]。

**品种特异性模式**
软骨营养障碍品种通常在3-6岁之间发病，而大型犬更常在C5-C7间隙发生颈椎椎间盘疾病伴椎间盘突出[3]。深痛觉丧失是主要的阴性预后指标，表明需要紧急干预[1]。

### Sources
[1] Managing acutely paralyzed patients with disc herniation: https://www.dvm360.com/view/managing-acutely-paralyzed-patients-with-disc-herniation-or-spinal-cord-injury-proceedings
[2] The Neurologic Examination of Animals: https://www.merckvetmanual.com/en-au/nervous-system/nervous-system-introduction/principles-of-therapy-of-neurologic-disease
[3] Common canine spinal disease simplified: https://www.dvm360.com/view/common-canine-spinal-disease-simplified

## 诊断方法

IVDD的诊断评估需要结合神经系统检查和先进影像学模式的系统方法[1]。初始评估包括全面的神经系统检查，以定位病变并确定脊髓压迫的严重程度[1]。这包括评估有意识本体感觉、脊髓反射和评估深痛觉，这对预后至关重要[2]。

**神经系统评估**

神经系统检查评估步态异常、无力模式和反射反应，以定位受影响的脊髓节段[2]。标准神经分级使用5分制：0级（正常）、1级（仅疼痛）、2级（能行走但有共济失调和本体感觉缺陷）、3级（无法行走的轻瘫伴失禁）、4级（截瘫伴失禁）和5级（深痛觉丧失）[1]。测试包括评估缩回反射、伸肌张力和膀胱功能[2]。检查有助于区分上运动神经元和下运动神经元体征，指导进一步的诊断决策。

**影像学模式**

普通X线摄影可能显示椎间盘间隙狭窄或钙化椎间盘物质，但在急性病例中通常表现正常[2]。CT提供优越的骨细节，可以检测细微骨折或椎间盘物质[6][7]。CT脊髓造影通过增强压迫性病变的可视化来提高诊断准确性[6]。磁共振成像（MRI）被认为是脊柱影像学的金标准，提供优越的软组织对比度和评估脊髓实质的能力[7][8]。MRI在检测影响预后的脊髓水肿、出血和髓内改变方面表现出色[7]。先进影像学技术允许区分椎间盘突出、肿瘤和其他影响治疗决策的压迫性病变。

### Sources
[1] Managing acutely paralyzed patients with disc herniation or spinal cord injury (Proceedings): https://www.dvm360.com/view/managing-acutely-paralyzed-patients-with-disc-herniation-or-spinal-cord-injury-proceedings
[2] The Neurologic Examination of Animals - Nervous System: https://www.merckvetmanual.com/nervous-system/the-neurologic-examination/the-neurologic-examination-of-animals
[3] Conservative management of intervertebral disk disease: https://www.dvm360.com/view/saved-sidelines-conservative-management-intervertebral-disk-disease
[4] Evaluation of electroacupuncture treatment for thoracolumbar: https://avmajournals.avma.org/view/journals/javma/231/6/javma.231.6.913.xml
[5] Dogs and cats with prepubic hernia often have concurrent: https://avmajournals.avma.org/view/journals/javma/263/4/javma.24.09.0593.xml
[6] Computed Tomography in Animals - Clinical Pathology: https://www.merckvetmanual.com/en-au/clinical-pathology-and-procedures/diagnostic-imaging/computed-tomography-in-animals
[7] Advanced imaging modalities in veterinary medicine: https://www.dvm360.com/view/advanced-imaging-modalities-in-veterinary-medicine
[8] Anatomic, differential diagnosis key to MRI success: https://www.dvm360.com/view/anatomic-differential-diagnosis-key-mri-success