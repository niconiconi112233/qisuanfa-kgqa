# 伴侣动物有机磷中毒

有机磷中毒是小动物兽医实践中最关键的毒理学急症之一。目前有数百种有机磷化合物用作农药，随着有机氯化合物的逐步淘汰，犬猫的接触事件变得越来越常见。本综合报告探讨了伴侣动物有机磷中毒的病理生理学、临床表现和管理。涵盖的关键领域包括特征性的毒蕈碱和烟碱效应引起的胆碱能危象、使用胆碱酯酶活性测量的诊断方法、使用阿托品和氯解磷定的紧急治疗方案，以及认识有机磷诱导的中间综合征作为一种需要长期监测和支持性护理的独特临床实体。

## 摘要

伴侣动物有机磷中毒表现为一种复杂的毒理学急症，需要立即识别和积极治疗。该病症通过三种不同的综合征表现：产生经典"SLUDDE"表现（流涎、流泪、排尿、腹泻、呼吸困难、呕吐）的毒蕈碱效应，引起肌肉颤搐和虚弱的烟碱效应，以及包括癫痫发作和行为改变的中枢神经系统效应。猫对中间综合征表现出特别的易感性，在接触后数天发展为迟发性四肢轻瘫和颈腹屈。

| 方面 | 关键特征 |
|--------|-------------|
| 诊断方法 | 血液胆碱酯酶活性<正常值的50%提示接触；<25%表示中毒 |
| 治疗方案 | 阿托品0.2-2 mg/kg + 氯解磷定20-50 mg/kg + 积极去污 |
| 预后 | 早期干预预后良好；并发症包括呼吸衰竭和中间综合征 |
| 物种考虑 | 猫更容易发生中间综合征；犬表现为典型的急性表现 |

通过及时识别和适当治疗，预后仍然良好，尽管有机磷诱导的中间综合征可能使恢复复杂化。兽医必须保持高度的临床怀疑，利用胆碱酯酶检测进行确认，并实施全面的支持性护理方案，以在这些具有挑战性的病例中优化患者结果。

## 疾病概述和常见病原体

**定义和流行病学背景**

有机磷中毒是由接触有机磷（OP）化合物引起的严重中毒，这些化合物是磷酸或膦酸的衍生物[1]。这些农药已基本取代被禁用的有机氯化物，现在是犬猫中毒的主要原因[1]。

目前，有数百种OP化合物在使用，它们在毒性、残留水平和排泄模式上差异很大[1]。许多有机磷需要通过微粒体氧化酶进行肝脏活化才能成为有效的胆碱酯酶抑制剂[1]。有机磷诱导的中间综合征（IMS）已在犬猫中观察到，发生在接触大剂量有机磷杀虫剂后，代表一种与急性中毒不同的独特临床实体[1]。

**常见有机磷化合物**

有机磷中毒涉及用作农药的特定化学化合物接触，而不是病原体。常见的有机磷包括毒死蜱、地亚农、杀螟硫磷、马拉硫磷、对硫磷、敌敌畏、乐果、乙拌磷和倍硫磷[1][2]。一些化合物特别危险——对硫磷在23-35 mg/kg剂量下可导致犬死亡，在15 mg/kg剂量下可导致猫死亡[1]。敌敌畏用于跳蚤项圈，可能引起皮肤反应，而一些佩戴敌敌畏浸渍项圈的宠物可能发展为共济失调-抑郁综合征，随后死亡[2]。

### Sources
[1] Organophosphate Toxicosis in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/organophosphate-toxicosis-in-animals
[2] Insecticide Poisoning - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/poisoning/insecticide-poisoning

## 临床症状和诊断方法

伴侣动物有机磷中毒通过三种影响不同受体系统的不同综合征表现[1]。毒蕈碱症状通常首先出现，包括经典的"SLUDDE"表现：流涎、流泪、排尿、腹泻、呼吸困难和呕吐[3][4]。额外的毒蕈碱效应包括流涎过多、瞳孔缩小、呕吐、绞痛以及支气管收缩伴支气管分泌物增加[1]。

烟碱效应包括肌肉颤搐、震颤、虚弱和可能瘫痪[1][3]。中枢神经系统症状表现为紧张不安、共济失调、忧虑、癫痫发作和行为改变[1][2]。犬猫通常表现为中枢神经系统兴奋进展为惊厥，而牛和羊通常表现为严重的中枢神经系统抑制[1]。

发作时间从接触后几分钟到几小时不等，但在某些情况下可能延迟超过2天[1]。猫对中间综合征特别敏感，在接触后数天发展为四肢轻瘫和颈腹屈，通常没有明显的急性中毒迹象[2]。瞳孔散大在受影响的猫中很常见[2]。

诊断方法包括使用EDTA管测量血液或血浆中的乙酰胆碱酯酶（AChE）活性[3][6]。AChE水平低于正常值的50%强烈提示有机磷接触，而低于25%表示中毒[4]。诊断性阿托品试验涉及静脉注射0.02 mg/kg；心率不增加或瞳孔不散大提示胆碱酯酶抑制剂接触[3][4]。脑AChE分析可以在死后进行，尽管在快速致命的病例中，血脑屏障效应可能影响结果[1]。

### Sources
[1] Organophosphate Toxicosis in Animals - Toxicology: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/organophosphate-toxicosis-in-animals
[2] Toxic Disorders of the Peripheral Nerves and Neuromuscular Junction in Animals: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/toxic-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals
[3] The toxic effects of disulfoton in pets: https://www.dvm360.com/view/toxic-effects-disulfoton-pets
[4] Flea control and insecticides (Proceedings): https://www.dvm360.com/view/flea-control-and-insecticides-proceedings
[5] The toxic effects of disulfoton in pets: https://www.dvm360.com/view/toxic-effects-disulfoton-pets-0

## 治疗选择和预防措施

现有的综合内容有效涵盖了有机磷中毒的治疗和预防方案。根据原始资料，我可以添加关于中间综合征的重要临床信息，这是兽医应在伴侣动物中监测的严重并发症。

**中间综合征监测**

有机磷诱导的中间综合征（IMS）代表一种与急性中毒和迟发性神经病变不同的独特临床实体[1]。这种情况已在接触大剂量有机磷的犬猫中记录[1]。IMS通常在初次接触后24-96小时发展，特征是呼吸肌、颈屈肌和肢体肌肉无力，可能持续数周[1]。

**增强的去污考虑**

原始资料强调，某些有机磷制剂可能是微胶囊化的，缓慢释放活性化合物，增加毒性作用的持续时间[1]。这种延长释放机制需要延长监测期，在涉及这些特殊制剂的情况下可能需要重复去污工作[1]。

**物种特异性毒性意识**

婆罗门牛对几种有机磷（包括毒虫畏和 famphur）表现出明显增加的易感性，与欧洲品种相比[1]。虽然这主要影响牲畜，但伴侣动物从业者在治疗有机磷接触时应意识到品种或个体敏感性的差异。

### Sources

[1] Merck Veterinary Manual Organophosphate Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/organophosphate-toxicosis-in-animals

[2] Merck Veterinary Manual Insecticide Poisoning - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/poisoning/insecticide-poisoning

[3] Merck Veterinary Manual Plant-Derived Insecticide Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/plant-derived-insecticide-toxicosis-in-animals

[4] Merck Veterinary Manual Carbamate Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/carbamate-toxicosis-in-animals

[5] Merck Veterinary Manual Toxic Disorders of the Peripheral Nerves and Neuromuscular Junction in Animals - Nervous System - Merck Veterinary Manual: https://www.merckvetmanual.com/nervous-system/diseases-of-the-peripheral-nerves-and-neuromuscular-junction/toxic-disorders-of-the-peripheral-nerves-and-neuromuscular-junction-in-animals

## 鉴别诊断和预后

### 鉴别诊断

有机磷中毒与几种胆碱酯酶抑制剂毒性和神经系统疾病具有相似的临床症状。主要鉴别包括氨基甲酸酯中毒，它产生类似的胆碱能症状，但乙酰胆碱酯酶抑制是可逆的[1][2]。关键区别因素是氨基甲酸酯通常临床症状持续时间较短，并且可能对氯解磷定治疗反应不同[2]。

其他重要的鉴别包括金属dehyde中毒，它引起严重的肌肉震颤和持续癫痫发作，但缺乏典型的毒蕈碱症状如瞳孔缩小和流涎过多[1]。士的宁中毒表现为由外部刺激触发的脊髓惊厥，与有机磷的持续癫痫活动形成对比[3]。

神经系统疾病如癫痫、脑炎和代谢紊乱如低钙血症可能模拟中枢神经系统效应，但缺乏特征性的胆碱能症状[1]。猫可能发展为慢性有机磷毒性，伴有厌食和虚弱的微妙症状，需要胆碱酯酶水平检测进行准确诊断[3]。

### 预后

有机磷中毒的预后因剂量、治疗时机和并发症发展而有显著差异。通过及时、积极的支持性护理，许多动物可以在2-3天内完全康复[1][4]。在严重呼吸抑制发生之前开始治疗，早期使用阿托品和氯解磷定治疗通常会产生良好结果[4]。

然而，接触大剂量的犬猫可能发展为有机磷诱导的中间综合征（IMS），代表一种预后可能更差的独立临床实体[1]。呼吸衰竭、持续癫痫发作或继发性并发症如吸入性肺炎的发展显著恶化预后[4]。猫可能特别具有挑战性，因为它们在胆碱酯酶水平低于正常值10%时可能表现临床正常[3]。

### Sources

[1] Merck Veterinary Manual Organophosphate Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/organophosphate-toxicosis-in-animals
[2] Merck Veterinary Manual Carbamate Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/carbamate-toxicosis-in-animals
[3] VIN Organophosphates & Carbamates: https://www.vin.com/vin_ce/abvp/html/organophosphates___carbamates.html
[4] Merck Veterinary Manual Insecticide Poisoning: https://www.merckvetmanual.com/special-pet-topics/poisoning/insecticide-poisoning