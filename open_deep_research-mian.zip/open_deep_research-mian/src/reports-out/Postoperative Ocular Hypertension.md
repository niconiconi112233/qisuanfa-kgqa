# 伴侣动物术后眼压升高

术后眼压升高是犬猫白内障手术后的一种严重并发症，影响20-48.9%的犬类患者在超声乳化术后数小时内出现。这种眼内压的急性升高，虽然通常是暂时性的并在24小时内消退，但当压力超过25 mmHg时，会对视力构成直接威胁。了解其病理生理学、临床识别和管理策略对进行眼内手术的兽医从业者至关重要。本报告考察了流行病学模式、涉及房水动力学破坏的潜在机制、使用眼压计的诊断方法、包括渗透剂和局部药物在内的循证治疗方案，以及当得到妥善管理时不到10%进展为慢性青光眼的长期结果。

## 疾病概述与流行病学

术后眼压升高（POH）定义为伴侣动物白内障手术后眼内压的急性升高[1]。这种情况代表了犬超声乳化手术的常见且重要的并发症，其表现为眼内压相对于正常基线值的急性升高。

最近的兽医文献报告，犬白内障手术后POH患病率在20%至48.9%之间[1]。这一广泛范围反映了研究方法、手术技术和患者群体的差异。POH被认为是犬白内障手术中最常遇到的并发症之一[2]。该情况通常在超声乳化和人工晶状体植入术后的即刻术后期发展。

在猫科患者中，白内障手术的频率低于犬，关于POH患病率的具体流行病学数据仍然稀缺[2]。然而，与犬相比，猫似乎不太容易发生POH。

POH的发病率高峰通常出现在术后前3小时内，眼内压峰值通常在24小时内消退[3]。标准手术方案现在已纳入预防性措施，包括拉坦前列素给药和在必要时进行前房穿刺，以管理预期的压力升高。尽管有预防性治疗，超过25mmHg的压力峰值仍需要立即干预以防止长期视觉后遗症，因为即使在非青光眼发作中，视网膜和视神经损伤仍可能发生[3]。

### Sources

[1] Ultrasound biomicroscopy in dogs suggests postoperative: https://avmajournals.avma.org/view/journals/javma/262/S2/javma.24.05.0309.xml
[2] Selected lens diseases and cataract treatment (Proceedings): https://www.dvm360.com/view/selected-lens-diseases-and-cataract-treatment-proceedings
[3] Update on cataract surgery (Proceedings): https://www.dvm360.com/view/update-cataract-surgery-proceedings

## 病理生理学与风险因素

犬猫术后眼压升高是由于手术后房水动力学的复杂破坏所致。葡萄膜炎可导致继发性青光眼，因为房水通过瞳孔或从虹膜角膜角流出受阻[1]。该情况表现为手术引起的眼内压暂时性升高，可能对视力造成毁灭性影响，且可能是永久性的[2]。

术后葡萄膜炎结合眼内残留的粘弹性物质可能导致术后眼压升高[5]。眼内压通常在术后3小时内开始升高，并在24小时内消退[5]。尽管这不被视为真正的青光眼发作，但如果压力超过25mmHg，视网膜和视神经仍可能受损[5]。

最近的超声生物显微镜研究表明，术后眼压升高可能与白内障手术相关的睫状裂变化有关[3]。在继发性青光眼病例中，压力升高是由于其他眼病引起的房水流出受阻所致[4]。患有原发性青光眼的犬面临特殊风险，因为对侧眼很可能在平均8个月内发展为该病[4]。某些品种表现出对房角发育不全的易感性，包括美国可卡犬和英国可卡犬、平毛寻回犬、拉布拉多寻回犬和金毛寻回犬、巴塞特猎犬、萨摩耶犬、松狮犬、大丹犬和西伯利亚哈士奇[4]。

### Sources
[1] Feline uveitis: A review of its causes, diagnosis, and treatment: https://www.dvm360.com/view/feline-uveitis-review-its-causes-diagnosis-and-treatment
[2] Current glaucoma therapy (Proceedings): https://www.dvm360.com/view/current-glaucoma-therapy-proceedings
[3] Ultrasound biomicroscopy in dogs suggests postoperative ocular hypertension may be associated with ciliary cleft changes related to cataract surgery: https://avmajournals.avma.org/view/journals/javma/262/S2/javma.24.05.0309.xml
[4] An overview of canine glaucoma: https://www.dvm360.com/view/an-overview-of-canine-glaucoma
[5] Disease and surgery of the lens (Proceedings): https://www.dvm360.com/view/disease-and-surgery-lens-proceedings

## 临床表现与诊断

现有章节内容为理解术后眼压升高提供了全面的基础。在这些既定的诊断原则基础上，兽医实践经验中出现了额外的考虑因素。

**增强的临床识别与监测**

除了既定的睑痉挛、巩膜充血和角膜水肿等临床体征外，从业者应监测可能先于显著压力升高的微妙早期指标。与正常值相比，>40-60 mm Hg的既定IOP阈值仍然是诊断基石，但术后监测期间的趋势模式可以提供更早的干预机会[4]。

**围手术期风险因素**

某些程序性因素可能增加术后高血压风险。区域麻醉技术虽然有益于疼痛管理，但需要仔细考虑潜在的并发症。眶下神经阻滞常用于牙科手术，但存在特定风险，包括意外穿透眼球，特别是在猫和短头颅犬中，这可能导致术后压力变化[2]。

**全身性考虑因素**

在术后患者中，全身性高血压与眼压之间的关系值得关注。患有潜在心血管疾病的动物可能经历眼部并发症，包括视网膜出血和前房积血，这可能使术后评估复杂化[1]。接受手术的老年患者面临额外挑战，因为与年龄相关的生理变化影响心血管和眼部功能[3]。

**监测方案**

常规眼压测量应超出即刻术后期，特别是在高风险品种和老年患者中。现有的鉴别诊断框架仍然有效，需注意区分术后压力升高与原发性青光眼或继发性疾病。

### Sources

[1] Blood pressure: a critical factor (Proceedings) - DVM 360: https://www.dvm360.com/view/blood-pressure-critical-factor-proceedings

[2] Dental extractions: from anesthesia to send home (Proceedings) - DVM 360: https://www.dvm360.com/view/dental-extractions-anesthesia-send-home-proceedings

[3] Age remains pertinent to anesthetic management - DVM 360: https://www.dvm360.com/view/age-remains-pertinent-anesthetic-management

[4] Senior dental care: Never too old for good dental health - DVM 360: https://www.dvm360.com/view/senior-dental-care-never-too-old-good-dental-health

## 治疗与预防

术后眼压升高（POH）的管理需要立即干预以防止永久性视力丧失和控制疼痛[1]。紧急治疗通常从渗透剂开始，如甘露醇，以1-2 g/kg的剂量在30分钟内静脉给药，在30-60分钟内提供快速的IOP降低[1][2]。或者，可以使用口服甘油（1-2 g/kg）或异山梨醇（1-1.5 g/kg），但由于葡萄糖代谢，甘油应避免用于糖尿病患者[1][2]。

长期医疗管理涉及局部碳酸酐酶抑制剂如多佐胺，每日给药2-3次，在4-5天内达到最大疗效[1][2]。前列腺素类似物，特别是拉坦前列素，代表犬青光眼最有效的治疗方法，通过增加房水流出实现，但在涉及葡萄膜炎的继发性青光眼病例中应谨慎使用[1][2]。β-受体阻滞剂如噻吗洛尔在犬和猫中疗效有限，但可提供补充治疗[1][2]。

手术干预包括对有视力眼睛进行激光睫状体光凝术和对失明疼痛眼睛进行睫状体冷冻术[1][2]。对于对药物治疗无反应的病例，眼球摘除术可提供明确的疼痛缓解[1][2]。

预防措施侧重于仔细的围手术期监测和维持足够的血压，因为平均动脉压>60 mmHg是器官充分灌注所必需的[3][6]。多模式疼痛管理可减少术后并发症，结合阿片类药物、非甾体抗炎药和区域神经阻滞进行预防性镇痛[7][8]。在手术期间维持正常体温并避免低血压是关键的预防策略[6][8]。局部麻醉浸润可提供有效的区域麻醉，同时减少全身药物需求[8]。

### Sources
[1] Your treatment options for glaucoma in small animals: https://www.dvm360.com/view/your-treatment-options-glaucoma-small-animals-0
[2] Glaucoma (Proceedings): https://www.dvm360.com/view/glaucoma-proceedings
[3] Blood pressure: a critical factor (Proceedings): https://www.dvm360.com/view/blood-pressure-critical-factor-proceedings
[4] Pain management for dental patients (Proceedings): https://www.dvm360.com/view/pain-management-dental-patients-proceedings
[5] Dental extractions: from anesthesia to send home: https://www.dvm360.com/view/dental-extractions-anesthesia-send-home-proceedings
[6] Anesthesia for the geriatric patient (Proceedings): https://www.dvm360.com/view/anesthesia-geriatric-patient-proceedings
[7] Multimodal approach to pain management analgesia: not "too much", rather a safe and effective synergy (Proceedings): https://www.dvm360.com/view/multimodal-approach-pain-management-analgesia-not-too-much-rather-safe-and-effective-synergy-proceed
[8] Anesthesia for ophthalmic surgery (Proceedings): https://www.dvm360.com/view/anesthesia-ophthalmic-surgery-proceedings

## 预后与结果

伴侣动物术后眼压升高（POH）的预后在及时识别和治疗时通常是有利的。POH通常发生在眼内手术后前24小时内，眼内压在术后3小时内开始升高，并在24小时内消退[1]。

**视力保留与结果**
虽然POH不被视为真正的青光眼发作，但它对视力构成与急性青光眼类似的直接危险[2]。当压力峰值超过25 mm Hg时，必须立即治疗以防止长期视觉后遗症[1]。如果在显著视力丧失发生前成功管理，应无残留后果[2]。

**长期并发症与青光眼风险**
最重要的长期关注点是进展为慢性青光眼。白内障手术后，至少在前3年内发展为青光眼的风险保持在10%以下[1]。某些品种面临增加的风险，波士顿梗和可卡犬表现出更高的术后青光眼易感性[1]。手术时患有过熟期白内障的犬也表现出更高的迟发性青光眼发生风险[1]。

**预后因素**
几个因素影响结果：及时的术后监测、适当的医疗管理以及主人对随访护理的依从性。研究表明，未能按预定随访检查带犬就诊的客户更可能对手术结果不满意，这表明并发症的早期发现和治疗显著提高了术后成功率[2]。

### Sources
[1] Disease and surgery of the lens (Proceedings): https://www.dvm360.com/view/disease-and-surgery-lens-proceedings
[2] Cataract surgery in veterinary medicine today (Proceedings): https://www.dvm360.com/view/cataract-surgery-veterinary-medicine-today-proceedings