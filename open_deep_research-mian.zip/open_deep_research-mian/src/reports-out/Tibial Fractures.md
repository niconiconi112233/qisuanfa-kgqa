# 犬猫胫骨骨折

胫骨骨折是伴侣动物中最常见的骨科损伤之一，显著影响其活动能力和生活质量。这些发生在小腿主要承重骨的骨折需要及时识别和适当治疗，以确保最佳治疗效果。本综合报告探讨了犬猫胫骨骨折的临床表现、诊断方法和治疗策略。涵盖的关键领域包括：显示年轻大型品种犬易感性的流行病学模式、手术规划必需的诊断影像技术、从外固定到先进钢板系统的各种稳定方法，以及影响愈合成功率的预后因素——在妥善管理的病例中成功率可达95%。

## 摘要

伴侣动物的胫骨骨折呈现复杂的临床挑战，需要系统性的诊断和治疗方法。4-10月龄的幼犬表现出特别的易感性，德国牧羊犬等大型品种风险增加。机动车事故和跌倒仍然是主要原因，造成闭合性和开放性骨折模式，需要不同的管理策略。

正交位X光检查提供诊断基础，而CT成像为复杂病例提供更优的可视化效果。治疗成功很大程度上取决于适当稳定方法的选择，外骨骼固定、骨板固定和交锁钉各有特定适应症。

| 关键预后因素 | 良好结果 | 不良结果 |
|------------------------|-------------------|---------------|
| 年龄 | >5个月 | <5个月（涉及生长板） |
| 骨折类型 | 闭合性、简单模式 | 开放性、粉碎性骨折 |
| 治疗时机 | 早期干预 | 延迟治疗 |
| 愈合率 | 适当固定下95% | 有并发症时变化不定 |

环境改造、体重管理和主人教育是关键的预防措施。通过适当治疗，愈合通常在57-71天内发生，在经验丰富的兽医使用循证方案管理的病例中，超过95%的病例可获得优异的功能结果。

## 疾病概述

胫骨骨折是指犬猫小腿中较大且位于内侧的胫骨发生断裂。胫骨是小腿的主要承重骨，从膝关节延伸至跗关节[1]。这些骨折可发生在多个解剖部位，包括近端干骺端、骨干和远端区域。

胫骨结节撕脱骨折（TTAF）是相对少见的创伤性损伤，影响幼犬，通常发生在4-10月龄之间[2]。在伴侣动物中，骨骨折常由车辆事故、枪伤、打斗或跌倒引起[4]。

创伤性骨折常涉及肩、肘、腕、髋、膝和跗关节。在未成熟动物中，生长板相对于邻近骨骼、韧带和关节囊的薄弱性使该区域易受损伤[5]。雄性犬似乎对某些胫骨损伤有易感性，在报道的大型品种犬骨科病例中，雄性占76%。大型和巨型品种犬，特别是德国牧羊犬和大丹犬，对胫骨区域损伤表现出更高的易感性。常见原因包括机动车事故、跌倒和高能冲击等创伤事件。体育活动和正常玩耍也可能导致年轻活跃犬发生撕脱型骨折，此时肌肉力量超过骨强度。

### Sources
[1] Cranial cruciate ligament disease in the dog (Proceedings): https://www.dvm360.com/view/cranial-cruciate-ligament-disease-dog-proceedings
[2] Good clinical outcomes achieved in young dogs with tibial...: https://avmajournals.avma.org/view/journals/javma/260/15/javma.22.07.0336.xml
[4] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[5] Joint Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 常见病原体

伴侣动物的胫骨骨折通常不是由传染性病原体引起的。然而，开放性胫骨骨折造成细菌污染和随后感染的显著风险[1]。

**葡萄球菌属**是骨科感染中最常见的细菌分离株，约占病例的50-60%[2]。这些包括*金黄色葡萄球菌*和*假中间葡萄球菌*（原中间葡萄球菌）。大多数葡萄球菌菌株因产生β-内酰胺酶而对青霉素耐药，对耐甲氧西林变种（MRSA和MRSP）的担忧日益增加[2]。

其他频繁分离的细菌包括*链球菌属*、*大肠杆菌*、*变形杆菌属*、*克雷伯菌属*和*假单胞菌属*[2]。在咬伤相关的骨折中，*巴斯德菌属*很常见，常伴有厌氧菌如*放线菌属*、*梭菌属*、*消化链球菌属*、*拟杆菌属*和*梭杆菌属*[2]。

医院获得性感染在创伤伤口中特别值得关注。新鲜伤口中的大多数感染源于医院环境而非初始损伤部位[3]。外固定装置带来独特的污染风险，因为当细菌在金属植入物上形成生物膜时，针道感染常会发生，保护它们免受吞噬作用和抗生素的影响[2]。

广谱抗生素预防应在伤口清创前开始，推荐使用第一代头孢菌素而非氟喹诺酮类药物进行初始治疗[3]。培养和药敏测试对于适当抗生素选择仍然至关重要[2]。

### Sources

[1] Postoperative management of external fixators in dogs and cats: https://www.dvm360.com/view/postoperative-management-external-fixators-dogs-and-cats
[2] Managing orthopedic infections (Proceedings): https://www.dvm360.com/view/managing-orthopedic-infections-proceedings
[3] Management of bad wounds and open fractures (Proceedings): https://www.dvm360.com/view/management-bad-wounds-and-open-fractures-proceedings

## 临床症状和体征

患有胫骨骨折的犬表现出特征性的跛行模式和体格检查结果[1]。跛行总是存在，根据骨折严重程度和位置，可从轻度负重跛行到完全不负重跛行不等[2]。患肢通常在骨折部位周围显示明显肿胀，胫骨可见或可触及变形。

疼痛是体格检查中的一致发现，犬在触诊患骨时表现出明显不适[2]。关节操作可能显示捻发音、活动范围减少和骨折部位不稳定[1]。在涉及胫骨近端或关节面的病例中，相邻关节可能出现积液。

品种特异性模式值得注意，玩具品种犬在使用外部固定治疗时特别容易发生桡骨和尺骨骨不连[4]。对于后肢骨折，犬表现出特征性的步态异常，在患肢负重时头部会下垂[1]。患侧步幅通常缩短。

在涉及胫骨的关节骨折病例中，其他体征包括关节肿胀和更明显的跛行[3]。慢性胫骨骨折可能表现为肢体成角畸形，特别是在未成熟动物中生长板受累的情况下[3]。开放性骨折可能显示明显的皮肤伤口和骨暴露，而闭合性骨折主要表现为软组织肿胀和正常肢体轮廓变形。

### Sources
[1] Merck Veterinary Manual - Lameness in Dogs: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/lameness-in-dogs
[2] Merck Veterinary Manual - Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[3] Merck Veterinary Manual - Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[4] VIN Conservative Treatment and External Coaptation for Fractures: https://www.vin.com/apputil/content/defaultadv1.aspx?pId=14365&catId=73691&id=7259321

## 诊断方法

犬猫胫骨骨折的诊断评估始于对跛行、疼痛和可见畸形的彻底临床评估[1]。体格检查显示特征性体征，包括不负重跛行、局部肿胀、捻发音和异常肢体成角。触诊可识别骨折部位的压痛点和潜在不稳定。

X光检查仍是胫骨骨折诊断的金标准[1]。正交X光视图（头尾位和内外侧位投照）对于充分表征骨折构型、移位和粉碎程度至关重要。多个视图有助于识别在单一投照中可能模糊的骨折线。

先进成像技术在有指征时提供额外的诊断价值。计算机断层扫描（CT）为复杂骨折提供更优的可视化效果，特别是涉及粉碎或关节面的骨折[2]。CT提供骨碎片、关节面和骨折几何形状的详细评估，这些在常规X光片上可能不明显。这些信息对手术规划特别有价值。

兽医骨折分类系统根据骨折位置、构型和稳定性指导治疗决策。兽医实践中常用的AO/ASIF分类系统按解剖位置（近端、骨干或远端）、骨折模式（简单、楔形或复杂）和粉碎程度对骨折进行分类[1]。这种系统化方法确保兽医之间的一致沟通和适当治疗选择。

### Sources

[1] Classifications of 202 tibial fractures in dogs and cats: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.03.0104/ajvr.25.03.0104.pdf

[2] Computed Tomography in Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/computed-tomography-in-animals

## 治疗选择

犬猫胫骨骨折需要综合治疗方法，结合手术稳定、保守管理、疼痛控制和康复[1][2][3]。

**手术稳定方法**
胫骨骨折修复有多种手术选择。外骨骼固定提供出色的稳定性，特别适用于闭合或半闭合手术方法[2][7]。骨板固定为适当骨折构型提供坚固的内固定，而交锁钉代表骨干骨折的先进选择[1][3]。

植入物选择对成功至关重要。年轻健康动物的不完全骨折可用外部夹板或石膏治疗[1][3]。其他损伤需要内固定装置，如骨板、螺钉、骨科钢丝、交锁钉和针[1][3]。经常使用松质骨移植来增强患病或年老患者的骨折愈合[1]。

**保守管理和支持**
外部固定可能适用于某些胫骨骨折，包括幼猫的不完全骨折[3]。当手术干预不可行时，这种方法包括夹板固定、石膏固定和支持性包扎。

**疼痛管理和康复**
围手术期镇痛药包括硬膜外吗啡、麻醉药贴剂、全身麻醉药和非甾体抗炎药，对舒适度至关重要[1]。物理治疗和康复对于恢复肢体功能和整体健康至关重要[1]。适当的术后护理包括加压包扎、固定元件-皮肤界面护理和严格的活动限制[7]。

### Sources
[1] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[2] Fracture Management Program: Level 1 & 2: https://www.dvm360.com/view/fracture-management-program-level-1-2
[3] Bone Disorders in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/bone-joint-and-muscle-disorders-of-cats/bone-disorders-in-cats
[4] Surgery STAT: Tailor your bone fracture repair technique: https://www.dvm360.com/view/surgery-stat-tailor-your-bone-fracture-repair-technique
[5] Postoperative management of external fixators in dogs and cats: https://www.dvm360.com/view/postoperative-management-external-fixators-dogs-and-cats
[6] Treating fracture disease and nonunion fractures (Proceedings): https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings

## 预防措施

现有内容为伴侣动物胫骨骨折预防提供了全面基础。在这些既定措施的基础上，额外的预防策略侧重于创造更安全的环境和实施适当的管理方案[5]。

体重管理在营养考虑之外发挥关键作用。肥胖增加骨结构的机械应力，并通过改变步态模式和减少活动性使动物易受创伤性损伤[6]。定期身体状况评分和适当热量限制有助于维持最佳骨骼健康，同时降低骨折风险。

环境改造超出一般安全措施，包括特定的住房考虑。铁丝网地板带来特殊风险，特别是在兔子和其他小动物中，不合适的住房表面可导致创伤性肢体损伤[9]。提供适当的垫料、防滑表面和消除肢体可能卡住的间隙是必要的预防措施。

品种特异性风险因素需要针对性的预防策略。某些品种对可能易发骨折的骨科条件表现出更高的易感性[6][8]。早期识别高风险个体允许在问题发展前实施预防措施。

对主人进行适当处理技术的专业教育，特别是对幼年动物，有助于防止因跌落或不当约束造成的创伤性骨折[3]。生长期的定期兽医监测能够早期检测可能增加骨折易感性的潜在疾病。

### Sources
[1] Rehabilitation of canine athletes (Proceedings): https://www.dvm360.com/view/rehabilitation-canine-athletes-proceedings
[2] Preventing injury in sporting dogs: https://www.dvm360.com/view/preventing-injury-sporting-dogs
[3] Disorders Associated with Calcium, Phosphorus, and Vitamin D in Cats: https://www.merckvetmanual.com/en-au/cat-owners/bone-joint-and-muscle-disorders-of-cats/disorders-associated-with-calcium-phosphorus-and-vitamin-d-in-cats
[4] Disorders Associated with Calcium, Phosphorus, and Vitamin D in Dogs: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/disorders-associated-with-calcium-phosphorus-and-vitamin-d-in-dogs
[5] Orthopedic surgery in small mammals (Proceedings): https://www.dvm360.com/view/orthopedic-surgery-small-mammals-proceedings
[6] Surgical management of cranial cruciate ligament disease (Proceedings): https://www.dvm360.com/view/surgical-management-cranial-cruciate-ligament-disease-proceedings
[7] Juvenile bone and joint diseases: large dogs, rear legs; and small dogs (Proceedings): https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-rear-legs-and-small-dogs-proceedings
[8] Cranial cruciate ligament disease in the dog (Proceedings): https://www.dvm360.com/view/cranial-cruciate-ligament-disease-dog-proceedings
[9] Outcome for client-owned domestic rabbits undergoing limb amputation: https://avmajournals.avma.org/view/journals/javma/244/8/javma.244.8.950.xml

## 鉴别诊断

将胫骨骨折与其他表现出相似临床体征的疾病区分开来需要系统评估多个因素。几种情况可以模拟胫骨骨折表现，必须在鉴别诊断中考虑[1]。

**模拟胫骨骨折的疾病**

骨髓炎表现为跛行、疼痛和局部肿胀，与骨折相似。然而，受影响的犬通常表现出发热、持续性食欲不振，并可能有脓性疮口，这与急性创伤性骨折不同[1]。骨肉瘤和其他骨肿瘤可引起病理性骨折，在实际骨折发生前表现为慢性进行性跛行和骨肿胀[1][2]。

十字韧带损伤可表现为跛行和疼痛，但显示关节不稳定而非骨不连续[3]。胫骨压缩测试揭示前十字韧带松弛，这与骨折相关的不稳定不同[3]。其他关节创伤包括脱位可能模拟胫骨骨折，但在体格检查上显示不同的移位模式。

**区分骨折类型**

X光评估有助于区分创伤性和病理性骨折。创伤性胫骨骨折通常显示干净的断裂模式，周围骨组织正常[4]。病理性骨折常在骨折部位周围显示溶骨性改变或异常骨密度[2]。胫骨最少的软组织覆盖使开放性骨折比其他长骨更常见[1]。

**关键鉴别特征**

病史因素在鉴别诊断中至关重要。创伤后急性发作提示创伤性骨折，而慢性进行性跛行可能表明病理性原因[2]。体格检查显示特定模式：急性不负重跛行伴明显变形提示完全骨折，而维持功能伴慢性疼痛可能表明应力骨折或潜在骨病[4]。

### Sources

[1] Fractures and luxations of the hind limb: https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[2] Bone Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs
[3] Joint Trauma in Dogs and Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats
[4] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats

## 预后

胫骨骨折的预后根据骨折类型、患者因素和治疗方法差异显著。在使用线性外固定治疗的猫骨不连病例中，骨愈合在平均57.8天内完成，范围为47至71天[1]。对于全髋关节置换术（THA）等手术程序，无痛功能的预后极佳，95%的病例具有良好至优异的结果[2]。

在围手术期（术后0至12周），几乎所有病例（51/52）的跛行已消失或轻微，仅有一例显示持续问题。长期术后结果（>12个月）也显示出有利结果[3]。年龄显著影响预后，特别是在生长板骨折中，小于5月龄的动物有更大的畸形和髋关节退行风险[4]。

小动物骨折的平均愈合时间取决于动物年龄、骨折类型和固定方法[5]。用外骨骼固定适当稳定的骨折通常比内固定愈合更快。并发症可影响预后，包括感染、脱位、骨折、坐骨神经失用症或植入物松动。早期手术干预改善结果，因为在损伤后不久进行修复时愈合通常良好。就诊时肌肉萎缩的严重程度也影响预后，较轻的萎缩与更好的功能恢复相关[2]。

### Sources
[1] Treatment of nonunion cases with linear external fixation in cats: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.11.0350.xml
[2] Arthritis in cats (Proceedings): https://www.dvm360.com/view/arthritis-cats-proceedings
[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/85/3/ajvr.23.09.0207.xml
[4] Fractures and luxations of the hind limb (Proceedings): https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[5] Treating fracture disease and nonunion fractures (Proceedings): https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings