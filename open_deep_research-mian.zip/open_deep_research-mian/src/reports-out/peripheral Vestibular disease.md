# 伴侣动物外周前庭疾病

外周前庭疾病是小动物临床中最常见的神经系统疾病之一，影响犬猫的内耳结构和前庭神经通路。本综合报告探讨了该疾病的多面性，从其多样化的病因（包括感染性中耳炎-内耳炎和特发性综合征）到其特征性临床表现（如头倾斜、眼球震颤和共济失调）。分析涵盖了利用先进神经检查技术和影像学模式的关键诊断方法，同时探讨了基于证据的治疗策略，从靶向抗菌治疗到TECA-LBO（全耳道切除术与外侧鼓室骨切开术）等手术干预。此外，报告还涉及了预防护理方案、区分外周性与中枢性前庭疾病的鉴别诊断考量，以及影响患病伴侣动物临床结果和恢复预期的预后因素。

## 疾病概述

外周前庭疾病是一种影响外周前庭系统的神经系统疾病，具体涉及内耳内的感受器官（半规管、椭圆囊和球囊）以及位于颞骨岩部内的第八对脑神经（CN VIII）的前庭部分[1]。与涉及脑干核的中枢性前庭疾病不同，外周前庭疾病起源于中耳和内耳结构的病理变化[1]。

该疾病在各种年龄段的犬猫中均常见观察到。特发性前庭综合征经常影响老年犬，通常被称为"老年犬前庭疾病"，典型表现于5岁以上的动物[1][2]。先天性外周前庭疾病已在特定品种中记录，包括德国牧羊犬、杜宾犬、英国可卡犬、暹罗猫和缅甸猫，在比格犬和秋田犬中已观察到双侧表现[2]。在猫中，猫特发性前庭疾病没有特定的品种、年龄或性别倾向，尽管在东北部地区7月和8月会出现季节性聚集[1]。

颞骨岩部内的解剖位置使外周结构易受炎症过程影响，其中中耳炎/内耳炎是外周前庭功能障碍的最常见原因[1][6]。

### Sources
[1] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[2] Cranial nerve disorders (Proceedings): https://www.dvm360.com/view/cranial-nerve-disorders-proceedings
[6] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings

## 常见病原体

外周前庭疾病最常与中耳炎和内耳炎相关，这些通常由细菌感染引起[1][2]。在小动物中 frequently 分离出的细菌病原体包括假单胞菌属和葡萄球菌属[3]。铜绿假单胞菌是一种革兰氏阴性杆菌，特别具有挑战性，因为它可引起耳道严重溃疡性病变，并对常用抗菌药物表现出耐药性[3]。

在犬中，中耳炎常发展为慢性外耳炎的延伸，许多病例涉及革兰氏阴性细菌感染[1][2]。患有中耳炎的猫可能同时患有呼吸道疾病和炎性息肉，这可能导致前庭功能障碍[1]。混合细菌感染在两个物种中都很常见，需要进行培养和药敏测试以选择适当的治疗[3]。

虽然病毒原因在外周前庭疾病中不常见，但猫疱疹病毒-1（FHV-1）已被提出作为猫前庭综合征的潜在触发因素，通过复发性感染[4]。作者认为猫前庭综合征可能是FHV-1再激活的另一种表现，类似于角膜炎和角膜溃疡[4]。

感染的传播通过多种途径发生，包括从外耳感染扩展、通过咽鼓管迁移，或罕见地通过血源性传播[3]。尽管特发性前庭综合征仍然是最常见的原因，但当神经学症状如面神经麻痹或霍纳综合征伴随前庭症状时，感染性病因具有重要意义[2]。

### Sources
[1] Otitis Media and Interna in Cats - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/ear-disorders-of-cats/otitis-media-and-interna-in-cats
[2] Vestibular disease in dogs and cats (Proceedings) - dvm360: https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings
[3] Otitis Media and Interna in Animals - Merck Veterinary Manual: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[4] Feline viral upper respiratory infection: Why it persists (Proceedings) - dvm360: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings

## 临床症状和体征

外周前庭疾病表现为特征性的神经系统体征组合，反映内耳或前庭神经功能障碍[1]。标志体征包括头倾斜、眼球震颤、共济失调和斜视，常伴有跌倒、翻滚、倾斜和转圈[1]。

**头倾斜**是最一致的发现，特征是头部中平面旋转，一只耳朵低于另一只[1][2]。这种异常姿势发生在病变同侧，由于受影响侧抗重力肌张力丧失[1]。头倾斜必须与头转动区分开来，后者中平面保持与地面垂直，但鼻子偏向一侧[1]。

**眼球震颤**表现为具有快相和慢相的不自主节律性眼球运动[1][2]。在外周前庭疾病中，眼球震颤通常是水平性或旋转性的，快相远离受影响侧[1][2]。与中枢性病变不同，眼球震颤不随不同头部位置改变方向，且不存在垂直性眼球震颤[1][2]。

**共济失调**表现为不对称性步态异常，伴有向受影响侧漂移、倾斜、跌倒和翻滚[2][5]。动物可能表现出紧密的转圈模式和难以保持平衡[1][2][5]。在双侧外周前庭疾病中，动物表现出宽幅、摆动的头部运动和蹲伏姿势，没有头倾斜或自发性眼球震颤[2]。

**其他体征**包括当头部抬高时的位置性腹侧斜视（"眼下垂"）[2][5]，以及在急性病例中的呕吐或恶心[1][5]。面神经麻痹和霍纳综合征可能伴随外周前庭疾病，因为这些神经在颞骨岩部内与前庭装置解剖位置接近[1][2]。

重要的是，在纯粹的外周前庭疾病中，姿势反应和本体感觉保持正常，这有助于将其与中枢性前庭疾病区分开来[1][2]。

### Sources
[1] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings
[2] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[3] The vestibular cat (Proceedings): https://www.dvm360.com/view/vestibular-cat-proceedings
[4] Full tilt! Diagnosing and managing vestibular dysfunction in dogs and cats (Proceedings): https://www.dvm360.com/view/full-tilt-diagnosing-and-managing-vestibular-dysfunction-dogs-and-cats-proceedings
[5] Full tilt! Diagnosing and managing vestibular dysfunction in dogs and cats (Proceedings): https://www.dvm360.com/view/full-tilt-diagnosing-and-managing-vestibular-dysfunction-dogs-and-cats-proceedings

## 诊断方法

诊断外周前庭疾病需要结合临床评估、神经检查和先进诊断模式的系统方法[1]。诊断过程从全面的临床表现评估开始，重点关注典型体征，包括头倾斜、水平性或旋转性眼球震颤以及没有姿势反应缺陷的不对称性共济失调[1]。

神经检查对于病变定位至关重要。外周前庭疾病的关键发现包括同侧头倾斜、快相远离病变的水平性或旋转性眼球震颤，以及保留的姿势反应[2]。伴随的第七对脑神经缺陷或霍纳综合征可能表明中耳或内耳受累，由于解剖位置接近[3]。

实验室检查应包括全血细胞计数、血清化学和甲状腺功能评估，因为甲状腺功能减退可引起前庭神经病变[5]。耳镜检查对于评估鼓膜完整性和识别中耳病理变化至关重要[5]。

影像学模式提供重要的诊断信息。鼓泡放射学检查需要全身麻醉和多个投照位置，尽管检测中耳疾病的敏感性有限[5]。CT或MRI的先进成像对检测中耳炎-内耳炎、肿瘤和炎症变化具有更高的敏感性[6]。

脑干听觉诱发电位（BAER）测试可以评估伴随的感觉神经性听力损失，并帮助区分外周性与中枢性病变[3]。当需要时，鼓膜切开术允许收集样本进行细胞学检查和细菌培养，以指导抗菌治疗[5]。

### Sources

[1] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[2] Vestibular disease (Proceedings): https://www.dvm360.com/view/vestibular-disease-proceedings
[3] The vestibular cat (Proceedings): https://www.dvm360.com/view/vestibular-cat-proceedings
[4] Once seen never forgotten: Unusual neurologic syndromes (Proceedings): https://www.dvm360.com/view/once-seen-never-forgotten-unusual-neurologic-syndromes-proceedings
[5] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings
[6] Full tilt! Diagnosing and managing vestibular dysfunction in dogs and cats (Proceedings): https://www.dvm360.com/view/full-tilt-diagnosing-and-managing-vestibular-dysfunction-dogs-and-cats-proceedings

## 治疗选择

外周前庭疾病的治疗方法根据潜在病因差异很大[2][6]。**中耳炎-内耳炎**作为最常见的原因，需要积极的抗菌治疗，使用能穿透骨骼的抗生素至少6-8周[2][6]。选择理想情况下应基于通过鼓膜切开术获得的培养和药敏测试[5]。当培养结果不可用时，通常使用氟喹诺酮类、阿莫西林-克拉维酸或头孢菌素[5]。

**手术干预**对于难治性病例或药物治疗失败时变得必要[2][6]。**全耳道切除术与外侧鼓室骨切开术（TECA-LBO）**代表了慢性中耳炎-内耳炎的确定性手术治疗[1][3]。该手术涉及完全切除耳道和引流鼓泡。术后并发症可能包括面神经麻痹、霍纳综合征和感染相关问题[1][3]。

**支持性护理**对所有前庭患者都是必不可少的[6]。严重受影响的动物可能需要身体约束以防止因翻滚造成自伤[6][7]。应提供软垫，抗组胺药如美克洛嗪可以帮助控制恶心和呕吐[7]。

**特发性前庭综合征**通常只需要支持性护理，在几天到几周内出现显著改善[6]。**甲状腺功能减退相关**的前庭疾病通常对左甲状腺素补充治疗反应良好[4][6]。患有**甲硝唑中毒**的动物在停药后通常完全恢复[6]。

### Sources
[1] Effect of empirical versus definitive antimicrobial selection on postoperative complications in dogs and cats undergoing total ear canal ablation with lateral bulla osteotomy: https://avmajournals.avma.org/view/journals/javma/260/8/javma.21.10.0462.xml
[2] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[3] Postoperative Complications Following TECA-LBO in the Dog and Cat: https://meridian.allenpress.com/jaaha/article-abstract/49/3/160/176691/Postoperative-Complications-Following-TECA-LBO-in
[4] Hypothyroidism in Animals - Endocrine System - Merck Veterinary Manual: https://www.merckvetmanual.com/endocrine-system/the-thyroid-gland/hypothyroidism-in-animals
[5] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings
[6] Full tilt! Diagnosing and managing vestibular dysfunction in dogs and cats (Proceedings): https://www.dvm360.com/view/full-tilt-diagnosing-and-managing-vestibular-dysfunction-dogs-and-cats-proceedings
[7] Vestibular syndrome: What's causing the head tilt and other neurologic signs?: https://www.dvm360.com/view/vestibular-syndrome-whats-causing-head-tilt-and-other-neurologic-signs

## 预防措施

外周前庭疾病的预防主要集中在通过全面的卫生实践和管理潜在疾病来维持最佳耳朵健康。使用适当的兽医批准的清洁剂定期清洁耳朵有助于防止碎屑和水分积聚，从而创造有利于继发感染的环境[1]。主人应每7-14天使用含有溶解角质物质的清洁剂进行维护性清洁，避免过度清洁可能引起刺激[4]。

正确的耳部清洁技术对于预防可能发展为前庭受累的耳炎至关重要。清洁犬耳时，不应使用棉签，因为它们可能将碎屑进一步推入耳道[3]。相反，应使用真正的棉球和兽医批准的耳部清洁溶液，完全填满耳道，按摩底部60秒，然后擦出松动的碎屑[3]。对于容易发生耳朵问题的犬，酸性清洁剂可能有益[1]。

环境控制措施包括尽量减少过度潮湿暴露并在易感品种中保持适当的耳部通风[4]。经常游泳的犬应使用适当的干燥剂干燥耳朵，以防止耳道软化而易患细菌感染[3]。应定期进行耳镜检查，以便在临床症状出现之前检测早期变化[4]。

虽然没有专门针对外周前庭疾病的疫苗，但保持针对上呼吸道病毒（特别是在猫中）的最新疫苗接种有助于预防可能导致中耳炎的上行感染[2]。在猫患者中，通过适当的疫苗接种方案解决慢性鼻炎和控制上呼吸道感染，降低了咽鼓管受累的风险[2]。

### Sources
[1] Ear no evil: Managing feline otitis: https://www.dvm360.com/view/ear-no-evil-managing-feline-otitis
[2] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals
[3] Ear Infections and Otitis Externa in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/ear-disorders-of-dogs/ear-infections-and-otitis-externa-in-dogs
[4] Diagnosing and managing ear disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-managing-ear-disease-proceedings

## 鉴别诊断

准确区分外周前庭疾病与中枢性前庭疾病对于正确的诊断和管理至关重要[1]。中枢性前庭疾病的预后更为谨慎，并且需要与外周疾病不同的诊断方法。

**中枢性前庭疾病**通过几个关键特征来区分。在任何头部位置出现的垂直性眼球震颤最符合中枢性受累[1]。动物通常表现出异常的姿势反应、精神状态下降和其他脑神经缺陷（CN V、VII、IX、X、XI、XII）[1][2]。大约95%患有中枢性前庭功能障碍的犬有异常姿势反应，45%表现出精神状态变化，60%有其他脑神经缺陷[8]。

**中枢性疾病的主要鉴别诊断**包括脑肿瘤（脑膜瘤、胶质瘤、脉络丛肿瘤）、肉芽肿性脑脊髓炎等炎症性疾病、血管事件和甲硝唑中毒[1][4][6]。小脑或脑干肿瘤经常导致进行性神经功能恶化[6]。

**外周前庭疾病**通常表现为保留的姿势反应和正常的精神状态[1]。伴随的面神经麻痹和霍纳综合征强烈提示外周受累，因为在颞骨岩部内解剖位置接近[1][4][5]。

**影响颞骨岩部的创伤**可引起严重的外周体征，伴有明显的转圈和翻滚[1]。如果发生脑干受累，头部创伤也可能导致中枢性前庭体征。

**关键区分因素**包括眼球震颤特征（垂直性提示中枢性）、姿势反应测试（中枢性疾病中异常）以及其他神经系统缺陷的存在。水平性或旋转性眼球震颤在头部位置变化时保持一致通常表明外周疾病[1]。

### Sources
[1] Vestibular disorders of dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disorders-dogs-and-cats-proceedings
[2] "I'll take neurology for 300" (Proceedings): https://www.dvm360.com/view/ill-take-neurology-300-proceedings
[4] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings
[5] The vestibular cat (Proceedings): https://www.dvm360.com/view/vestibular-cat-proceedings
[6] Neoplasia of the Nervous System in Animals: https://www.merckvetmanual.com/nervous-system/neoplasia-of-the-nervous-system/neoplasia-of-the-nervous-system-in-animals
[8] Vestibular syndrome: What's causing the head tilt and other neurologic signs?: https://www.dvm360.com/view/vestibular-syndrome-whats-causing-head-tilt-and-other-neurologic-signs

## 预后

外周前庭疾病的预后根据潜在病因和疾病严重程度差异很大[1]。大多数患有特发性前庭综合征的动物在1到3周内显示出显著改善，并且通常恢复正常功能[1]。临床症状通常在头72小时内改善，恢复通常在10-14天内发生[2]。然而，一些患者可能留下永久性神经缺陷，包括残留头倾斜或发作性共济失调[1]。

对于中耳炎/内耳炎病例，早期诊断和治疗可以导致感染和临床症状完全解决[3]。然而，慢性或无反应性病例的预后更为谨慎。应告知主人，即使在感染解决后，神经缺陷和听力损失可能持续存在[3]。一些动物可能保留永久性头倾斜和/或面神经麻痹[1]。

猫特发性前庭功能障碍的预后通常良好，大多数猫在几周内恢复[2]。即使是猫的双侧外周前庭疾病，虽然初期严重，伴有极端共济失调和宽幅头部摆动，通常也遵循类似的恢复模式[4]。甲硝唑中毒病例通常在停药后解决，尽管恢复可能需要几天到几周[1,2]。骑士查理王小猎犬的原发性分泌性中耳炎可能在鼓膜切开术后改善，但可能随时间复发[3]。

### Sources

[1] Vestibular disease in dogs and cats (Proceedings): https://www.dvm360.com/view/vestibular-disease-dogs-and-cats-proceedings  
[2] Vestibular syndrome: What's causing the head tilt and other neurologic signs?: https://www.dvm360.com/view/vestibular-syndrome-whats-causing-head-tilt-and-other-neurologic-signs  
[3] Otitis Media and Interna in Animals - Ear Disorders: https://www.merckvetmanual.com/ear-disorders/otitis-media-and-interna/otitis-media-and-interna-in-animals  
[4] Once seen never forgotten: Unusual neurologic syndromes (Proceedings): https://www.dvm360.com/view/once-seen-never-forgotten-unusual-neurologic-syndromes-proceedings