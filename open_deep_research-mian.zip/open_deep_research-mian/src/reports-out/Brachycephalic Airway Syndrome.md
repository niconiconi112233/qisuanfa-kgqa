# 伴侣动物的短头颅气道综合征

短头颅阻塞性气道综合征（BOAS）代表了现代伴侣动物医学中最重大的福利挑战之一，影响着全球数百万只短鼻犬和猫。随着法国斗牛犬在2023年成为美国最受欢迎的犬种，这种包括狭窄鼻孔、过长软腭和继发性气道改变的遗传性疾病已达到流行程度。本综合报告探讨了兽医从业人员管理BOAS患者所需掌握的解剖学基础、临床表现、诊断方法和治疗策略。分析涵盖了关键主题，包括品种特异性风险因素、手术干预时机、BRisk评分等新兴诊断工具，以及为预防这种进行性且可能危及生命的综合征而迫切需要的道德育种实践。

## 疾病概述

短头颅阻塞性气道综合征（BOAS）是一种影响短鼻犬和猫的病理状况，由短头颅品种中颅骨受压引起的解剖异常所致[1]。该综合征包括四种主要解剖异常：狭窄鼻孔（鼻孔狭窄）、过长软腭、喉囊外翻和喉塌陷[1]。

随着品种受欢迎程度的变化，BOAS的流行病学格局发生了巨大变化。法国斗牛犬在2023年成为美国最受欢迎的犬种，在近716,500只AKC注册犬中，约有1/7是法国斗牛犬[2]。这与25年前相比是一个显著的变化，当时法国斗牛犬甚至未进入前75名犬种[2]。

最常受影响的品种包括英国斗牛犬、法国斗牛犬、哈巴狗、波士顿梗、北京犬、西施犬和骑士查理王小猎犬，以及波斯猫和喜马拉雅猫[1]。诊断的平均年龄通常为3-4岁，雄性和雌性受影响程度相同[1]。虽然主要组成部分在出生时就已存在，但动物通常要到2-3岁时才表现出症状[1]。英国斗牛犬并发气管发育不全的发生率最高（55%），与其他品种相比手术效果较差[1]。

### Sources

[1] Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-1
[2] Addressing brachycephalic obstructive airway syndrome (BOAS) in general practice: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice

## 解剖异常和临床症状

短头颅气道综合征包括原发性解剖缺陷和由慢性上呼吸道阻塞发展而来的继发性改变[1]。主要组成部分包括狭窄鼻孔、过长软腭和发育不全的气管，而继发性改变涉及喉囊外翻和喉塌陷[2]。

**主要解剖组成部分**

狭窄鼻孔发生在鼻软骨畸形时，导致内侧塌陷并限制气流进入鼻腔[2]。过长的软腭延伸至会厌尖端之外，当其接触会厌或延伸至扁桃体后缘时引起气道阻塞[1]。发育不全的气管在英国斗牛犬中最常见（发生率55%），代表影响整个气管长度的先天性气管狭窄[2]。

**继发性改变**

喉囊外翻表现为声带前方的白色、有光泽的圆顶状结构，由于过度的负吸气压力而从其隐窝中被拉出[1][2]。喉塌陷分为三个进行性阶段：第1阶段（喉囊外翻）、第2阶段（楔状突塌陷）和第3阶段（角状突向中线塌陷）[2]。

**临床症状**

典型症状包括呼吸噪音、运动和热应激加重的吸气性呼吸困难、张口呼吸、喘气、打鼾和运动不耐[2][5]。其他症状包括干呕、窒息、反流、严重受影响动物出现发绀和晕厥[2]。英国斗牛犬常出现与进食无关的呕吐，这是由于呼吸努力导致腹内压力增加所致[2]。

### Sources
[1] DVM360: Brachycephalic airway syndrome, Part 2: https://www.dvm360.com/view/brachycephalic-airway-syndrome-part-2-veterinary-surgery-soft-palate-and-larynx
[2] DVM360: Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-0
[3] DVM360: Brachycephalic airway syndrome, Part 1: https://www.dvm360.com/view/brachycephalic-airway-syndrome-part-1-correcting-stenotic-nares/1000
[4] DVM360: Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-1
[5] DVM360: Addressing brachycephalic obstructive airway syndrome: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice

## 诊断方法

诊断短头颅气道综合征（BOAS）需要结合临床评估、分级系统和先进成像技术的综合方法[1]。诊断过程从彻底的体格检查开始，狭窄鼻孔通常仅通过目视检查即可识别。然而，对内部解剖异常的完整评估需要深度镇静或全身麻醉[1]。

临床检查利用呼吸功能分级系统（RFGS）评估严重程度，评估参数如呼吸努力、运动耐力和气道声音[1][3]。动物骨科基金会已将RFGS作为短头颅品种的标准化健康筛查测试，提供客观的评估工具[3]。麻醉前评估至关重要，因为短头颅品种的麻醉风险增加，包括全面的血液检查和胸部X光片以评估整体健康状况[1][4]。

麻醉下的喉镜检查允许直接观察过长的软腭、外翻的喉囊和喉塌陷[1][2]。先进的成像技术，特别是CT扫描，可提供鼻甲和整体气道解剖的详细评估。颈部和胸部的X光评估有助于识别气管狭窄、吸入性肺炎等肺部并发症和其他并发疾病[2][4]。

诊断工作必须考虑品种特异性差异，并利用BRisk评分等风险评估工具预测围手术期并发症[4][5]。早期诊断至关重要，因为该病是进行性的，在继发性并发症发展之前进行干预，手术结果显著更好[1]。

### Sources

[1] Brachycephalic Airway Syndrome in Dogs | VCA Animal Hospitals: https://vcahospitals.com/know-your-pet/brachycephalic-airway-syndrome-in-dogs

[2] Upper airway disease (Proceedings): https://www.dvm360.com/view/upper-airway-disease-proceedings

[3] Health screening test rolled out for brachycephalic dog breeds: https://avmajournals.avma.org/display/post/news/health-screening-test-rolled-out-for-brachycephalic-dog-breeds.xml

[4] Medical management of upper airway obstruction in dogs (Proceedings): https://www.dvm360.com/view/medical-management-upper-airway-obstruction-dogs-proceedings

[5] Addressing brachycephalic obstructive airway syndrome (BOAS) in general practice: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice

## 治疗选择

短头颅气道综合征的治疗根据疾病严重程度涉及保守和手术方法。保守管理侧重于体重控制，因为肥胖会加重呼吸损害，以及环境调整，包括避免热暴露和剧烈运动[3]。凉爽、湿润的环境有助于减轻呼吸窘迫。临时医疗管理包括抗焦虑药物、冷氧治疗和抗炎类固醇以减少气道肿胀，尽管这些仅提供短期缓解[3]。

对于中重度病例，通常需要手术干预。常见手术包括鼻成形术（鼻孔扩大）、悬雍垂腭咽成形术（软腭缩短）和喉囊切除术以切除外翻的声囊[1][2]。与传统方法相比，激光手术技术具有减少出血、术后肿胀最小化和手术时间更短的优势[2]。H-咽成形术等先进技术在改善气道功能方面显示出良好的效果[1]。

术后护理需要仔细监测呼吸并发症、疼痛管理和逐渐恢复正常活动[1][5]。对于严重病例，可能需要临时气管切开术，术后维持24小时[1]。地塞米松（1 mg/kg静脉注射）有助于减少术后喉水肿[1]。在恢复期间，凉爽、安静的环境和限制活动至关重要。

治疗时机至关重要 - 早期干预通常比延迟治疗产生更好的结果[2][5]。短头颅犬的吸入性肺炎风险是正常犬的4倍，7%出现术后并发症[3]。

### Sources
[1] Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-4
[2] Addressing brachycephalic obstructive airway syndrome (BOAS) in general practice: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice
[3] Medical management of canine upper airway diseases: https://www.dvm360.com/view/medical-management-of-canine-upper-airway-diseases
[4] Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-1
[5] The brachycephalic risk (BRisk) score's predictability: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0145/javma.25.03.0145.pdf

## 鉴别诊断和预后

BOAS必须与几种表现出相似呼吸道症状的疾病进行鉴别。喉麻痹，常见于老年大型犬，表现为吸气性喘鸣和运动不耐，但通过检查时特征性的双侧喉襞不动性可加以区分[1]。小型犬的气管塌陷产生独特的"鹅鸣"咳嗽，而BOAS通常表现为打鼾和呼吸窘迫[1]。年轻猫的鼻咽息肉引起吸气性噪音，但在麻醉期间通过可视化检查可区分[1]。

最近的研究已确定声带肉芽肿是短头颅品种中新兴的鉴别诊断。这些病变由肉芽组织而非真正的肉芽肿组成，与BOAS患者的慢性气道刺激和胃食管反流相关[5]。与肿瘤性喉部肿块不同，声带肉芽肿对手术切除联合BOAS矫正反应良好[5]。

预后因素显著影响BOAS患者的结局。就诊年龄至关重要，年龄每增加一岁，死亡风险增加29.8%[3]。BRisk评分已被证明对预测主要术后并发症（包括需氧、气管切开需求或死亡）有价值[2]。品种特异性考虑包括英国斗牛犬与其他短头颅程度较轻的品种相比预后更严重[6]。

早期手术干预产生更好的长期结果，研究报告在继发性改变发展之前进行手术，94%的病例结果良好至优秀[6]。然而，呼吸功能完全正常化很少实现，长期管理需要持续的体重控制和避免热应激[6][7]。

### Sources

[1] Diagnosing and treating upper airway disease (Proceedings): https://www.dvm360.com/view/diagnosing-and-treating-upper-airway-disease-proceedings
[2] The brachycephalic risk (BRisk) score's predictability for ...: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.03.0145/javma.25.03.0145.pdf
[3] Journal of the American Veterinary Medical Association ...: https://avmajournals.avma.org/view/journals/javma/260/S1/javma.20.09.0534.xml
[4] Breed-specific canine respiratory diseases: https://www.dvm360.com/view/breed-specific-canine-respiratory-diseases
[5] Vocal fold granuloma associated with brachycephalic ...: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0825.xml
[6] Brachycephalic airway syndrome (Proceedings): https://www.dvm360.com/view/brachycephalic-airway-syndrome-proceedings-1
[7] Addressing brachycephalic obstructive airway syndrome ...: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice

## 预防和未来方向

预防短头颅阻塞性气道综合征需要多方面的方法，侧重于负责任的育种实践、早期干预和福利考虑。最重要的预防策略涉及道德育种建议，因为BOAS具有很强的遗传成分[1]。

**育种和筛查计划**

动物骨科基金会（OFA）已将短头颅品种的呼吸功能分级作为健康筛查测试[2]。兽医必须教育主人，繁殖受影响的宠物是不道德的，并建议对BOAS受影响的动物进行强制性绝育[3]。建议在6-12个月大时进行早期气道评估和矫正手术，在继发性并发症发展之前[3]。极端短头颅品种日益普及，特别是2023年成为美国最受欢迎犬种的法国斗牛犬，需要提高兽医意识和积极干预[3]。

**福利考虑**

预防策略包括保持最佳体重，因为肥胖会加剧短头颅品种的呼吸损害[4]。环境调整，如避免过度热应激、减少压力和防止过度劳累，可以最小化临床症状[5]。早期手术干预显著改善生活质量，并预防危及生命的并发症，包括吸入性肺炎、高热和喉塌陷[3]。

### Sources

[1] Respiratory Medicine | Veterinary News & Animal Health: https://www.dvm360.com/clinical/respiratory-medicine
[2] Health screening test rolled out for brachycephalic dog breeds: https://avmajournals.avma.org/display/post/news/health-screening-test-rolled-out-for-brachycephalic-dog-breeds.xml
[3] Addressing brachycephalic obstructive airway syndrome (BOAS) in general practice: https://www.dvm360.com/view/addressing-brachycephalic-obstructive-airway-syndrome-boas-in-general-practice
[4] Implementation of a standard perioperative protocol: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.09.0598.pdf
[5] Managing upper airway obstruction in dogs (Proceedings): https://www.dvm360.com/view/managing-upper-airway-obstruction-dogs-proceedings