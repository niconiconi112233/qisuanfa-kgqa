# 宠物疾病：败血症

败血症是伴侣动物医学中最危急的紧急情况之一，其特征是细菌在血液循环中并产生全身性毒素。这种危及生命的状况影响犬和猫，但在猫科患者中呈现出独特的诊断和治疗挑战，因为它们表现出非典型的临床反应。尽管进行了积极治疗，犬的死亡率仍高达50-60%，而猫的预后则各不相同，早期识别和积极干预是成功治疗结果的关键。本报告探讨了败血症的综合兽医学方法，涵盖病原体识别、物种特异性临床表现、基于证据的诊断方案、治疗策略以及在小动物实践中优化患者管理所必需的预后因素。

## 预后

伴侣动物的败血症预后谨慎至不良，尽管进行了积极治疗，犬的死亡率仍为50-60%。序贯器官衰竭评估（SOFA）评分系统和脓毒症-3标准提供了有价值的预后工具，评分越高与死亡风险增加相关。关键预后指标包括反映组织低灌注的乳酸水平升高、C反应蛋白与白蛋白比值增加，以及持续的低白蛋白血症表明持续的炎症蛋白消耗。

猫因其主要表现为低动力状态而面临独特挑战，这使得早期识别比犬更为困难。物种特异性反应模式显著影响结果，猫很少表现出其他物种中常见的典型高动力性发热和心动过速。

| 预后因素 | 良好预后 | 不良预后 |
|-------------------|----------------|----------------|
| 乳酸水平 | 正常至轻度升高 | 持续升高 |
| CRP与白蛋白比值 | 较低比值 | 较高比值 |
| SOFA评分 | 较低分数 | 较高分数 |
| 物种反应 | 高动力性（犬） | 低动力性（猫） |

早期识别、及时的抗菌治疗、积极的液体复苏和源头控制仍然是影响败血症患者生存结果的最关键因素。

## 疾病概述

败血症是一种危及生命的全身性感染，其中细菌病原体在血液中循环并扩散到全身[1]。这种情况与菌血症（血液中存在细菌）和脓毒症（对感染的全身性炎症反应）密切相关但又有区别。这些术语经常互换使用，但败血症特指血液中毒，伴有细菌在血液中繁殖和产生毒素[2]。

猫脓毒症的发病率未知，部分原因是脓毒症在猫中诊断困难[1]。在兽医学中，脓毒症定义为存在感染证据加上全身性炎症反应综合征（SIRS）[2][3]。符合SIRS标准的犬显示敏感性范围为77-97%，而特异性保持在64-77%之间，尽管猫没有类似的研究[3]。在一项研究中，四只猫在住院期间发展为脓毒症，导致脓毒症发病率为每100次住院1.5例[4]。

风险因素包括免疫抑制性疾病，如猫白血病病毒或猫免疫缺陷病毒感染[1]。患有脓胸的猫更可能来自多猫家庭并有更多的户外活动机会[1]。在犬中，脓毒症最常起源于胃肠道，其次是呼吸道感染、严重牙病和污染伤口[2]。据报道，犬脓毒症的死亡率为50-60%，而脓毒性腹膜炎后遗症在猫中的死亡率范围为30-60%[5]。

### Sources
[1] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[2] Treatment of canine sepsis: First identify, eradicate the cause: https://www.dvm360.com/view/treatment-canine-sepsis-first-identify-eradicate-cause
[3] Sepsis and the critical cat (Proceedings): https://www.dvm360.com/view/sepsis-and-critical-cat-proceedings
[4] Epidemiology of systemic inflammatory response syndrome: https://avmajournals.avma.org/view/journals/javma/249/1/javma.249.1.65.xml
[5] Abdominal ultrasound has inconsistent agreement with: https://avmajournals.avma.org/view/journals/javma/263/3/javma.24.04.0271.xml

## 常见病原体

犬和猫的败血症由革兰氏阳性和革兰氏阴性细菌病原体引起，特定模式因物种而异[2]。最常见的分离生物包括大肠杆菌，它是急性和复发性血流感染中最常见的单一病原体[3]。其他常见细菌原因包括葡萄球菌属、变形杆菌属、链球菌属、克雷伯菌属和假单胞菌属[3]。

伴侣动物中存在物种特异性模式。在猫中，革兰氏阳性和革兰氏阴性病原体的发生率大致相等，而犬则根据原发性感染源显示变化[2]。肠杆菌目，特别是大肠杆菌、克雷伯菌和变形杆菌，在败血症起源于尿路感染的情况下占主导地位[4]。此外，厌氧病原体在败血症病例中发挥重要作用，梭菌属、放线菌属、拟杆菌属、梭杆菌属和消化链球菌属通常从咬伤和深部组织感染中分离出来[5][6]。

抗菌素耐药性是败血症病例中日益关注的问题。多重耐药性伤口感染 increasingly 与犬猫患者的革兰氏阳性和革兰氏阴性细菌相关[1]。耐甲氧西林假中间葡萄球菌和氟喹诺酮耐药肠杆菌科在治疗选择方面构成特殊挑战[3]。入院72小时后发展的医院获得性感染 frequently 涉及多重耐药性医院细菌，需要积极的培养和药敏试验方法[2]。

### Sources

[1] Multidrug-resistant wound infections are associated with gram-positive- and gram-negative-bacteria-associated canine and feline skin infections: https://avmajournals.avma.org/view/journals/javma/263/5/javma.24.11.0727.pdf

[2] Empirical antimicrobial therapy: making decisions without a culture (Proceedings): https://www.dvm360.com/view/empirical-antimicrobial-therapy-making-decisions-without-culture-proceedings

[3] Pharmacotherapeutics in Bacterial Urinary Tract Infections in Animals: https://www.merckvetmanual.com/en-au/pharmacology/systemic-pharmacotherapeutics-of-the-urinary-system/bacterial-urinary-tract-infections

[4] Collaboration with the clinical microbiology laboratory optimizes diagnosis of dog and cat infections: https://avmajournals.avma.org/view/journals/javma/263/S1/javma.24.12.0776.xml

[5] Antimicrobials in practice part 3: treating resistant infections (Proceedings): https://www.dvm360.com/view/antimicrobials-practice-part-3-treating-resistant-infections-proceedings

[6] Managing orthopedic infections (Proceedings): https://www.dvm360.com/view/managing-orthopedic-infections-proceedings

## 临床症状和体征

猫的败血症表现出独特的临床表现，与犬和人类显著不同。猫的特征性表现为低动力性反应，低温、苍白粘膜和心动过缓（心率<140次/分钟）比其他物种中常见的典型高动力性发热和心动过速更常见[1,2]。这种非典型表现使兽医的早期识别特别具有挑战性。

从全身性炎症反应综合征（SIRS）到脓毒性休克的进展在伴侣动物中遵循不同模式。早期体征包括精神抑郁、食欲不振和嗜睡[3]。随着病情发展，猫可能出现呼吸窘迫，肺作为主要的"休克器官"，使其特别容易发生肺水肿和胸腔积液[1,2]。

犬通常表现出更易识别的脓毒症体征，包括高动力阶段的发热、心动过速、呼吸急促和砖红色粘膜[4]。然而，随着脓毒症进展为脓毒性休克，两个物种都可能发展为低血压、代谢性酸中毒和多器官功能障碍[3,5]。

临床病理学发现包括可变的白细胞增多或白细胞减少、贫血、低白蛋白血症和低血糖[1,2]。猫经常因脓毒症引起的胆汁淤积和肝功能障碍而出现黄疸[2]。凝血异常很常见，表现为蛋白C和抗凝血酶水平降低[1]。

### Sources
[1] Clinical and immunologic assessment of sepsis and the systemic inflammatory response syndrome in cats: https://avmajournals.avma.org/view/journals/javma/238/7/javma.238.7.890.xml
[2] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[3] Infections Caused by Bacteria - Special Pet Topics - Merck Veterinary Manual: https://www.merckvetmanual.com/special-pet-topics/infections/infections-caused-by-bacteria
[4] Severe sepsis and septic shock protocol (Proceedings): https://www.dvm360.com/view/severe-sepsis-and-septic-shock-protocol-proceedings
[5] Peritonitis in Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/peritonitis/peritonitis-in-animals

## 诊断方法

伴侣动物败血症的诊断需要综合方法，结合临床评估与特定的实验室和影像学技术[1]。血培养仍然是金标准诊断工具，但由于先前的抗菌治疗或间歇性菌血症模式，可能会出现假阴性结果[1]。在不同时间点采集多个样本可提高诊断率。

全血细胞计数（CBC）通常显示白细胞增多伴左移，但在严重病例中可能出现白细胞减少，表明骨髓耗竭[2]。患有脓毒症的猫在早期通常表现为贫血和明显白细胞减少[2]。由于消耗性凝血病，血小板减少很常见[1]。生化谱通常显示肝酶升高、氮质血症、低血糖和电解质失衡，反映多器官功能障碍。

包括PT/PTT和D-二聚体在内的凝血测试有助于识别弥散性血管内凝血（DIC），这是败血症的严重并发症[1]。乳酸水平作为有价值的预后指标，持续升高提示不良结果[4]。腹腔液和血液之间的血糖梯度对快速诊断脓毒性腹膜炎显示出前景[3]。

包括胸部和腹部X光或超声检查在内的影像学检查对于识别潜在的感染源（如子宫蓄脓、前列腺脓肿或肺炎）至关重要[1]。超声心动图可能在细菌性败血症病例中显示提示心内膜炎的赘生物[1]。

### Sources
[1] Merck Veterinary Manual Infections Caused by Bacteria: https://www.merckvetmanual.com/special-pet-topics/infections/infections-caused-by-bacteria
[2] DVM 360 A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[3] DVM 360 Management of dogs and cats with septic peritonitis: https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[4] Merck Veterinary Manual Colisepticemia: https://www.merckvetmanual.com/generalized-conditions/colisepticemia/colisepticemia

## 治疗方案

败血症治疗需要立即、积极的多模式治疗，针对血流动力学稳定、抗菌干预和源头控制[1]。主要目标是在处理潜在感染的同时最大化组织灌注和氧气输送。

**液体复苏**构成初始管理的基石。晶体液是一线选择，优选乳酸林格氏液或平衡电解质溶液[1]。犬需要20 ml/kg的休克推注剂量，猫需要10-50 ml/kg的温晶体液快速输注[1][3]。当晶体液未能恢复充分灌注时，胶体液如羟乙基淀粉（犬5 ml/kg，猫2.5 ml/kg）可能提供更好的血管内容量扩张[1]。

**血管加压素支持**在充分容量替代后仍存在低血压时变得必要。多巴胺（2.5-15 μg/kg/min）作为一线血管加压剂，提供正性肌力和血管收缩作用[3]。多巴酚丁胺（2-20 μg/kg/min）提供额外的正性肌力支持，尽管在猫中长时间使用可能引起癫痫发作[3]。对于难治性低血压，可能需要去甲肾上腺素（0.1-3 μg/kg/min）或肾上腺素（0.1-2 μg/kg/min）[3]。

**抗菌治疗**必须及时开始，因为延迟会增加死亡率[3]。应在等待培养结果时给予广谱静脉内抗生素。对于疑似大肠杆菌感染，考虑阿米卡星（犬：15-30 mg/kg q24h；猫：9-14 mg/kg q24h）或亚胺培南-西司他丁[1]。葡萄球菌感染可能需要庆大霉素（10 mg/kg q24h）或克林霉素（11 mg/kg q12h）[1]。

**源头控制**通过手术引流、清创或去除感染组织对成功结果至关重要[1][3]。其他支持措施包括氧疗、必要时输血以及仔细的血糖管理以维持正常血糖[3]。

### Sources
[1] Severe sepsis and septic shock protocol (Proceedings): https://www.dvm360.com/view/severe-sepsis-and-septic-shock-protocol-proceedings
[2] The Fluid Resuscitation Plan in Animals - Therapeutics - Merck Veterinary Manual: https://www.merckvetmanual.com/therapeutics/fluid-therapy/the-fluid-resuscitation-plan-in-animals
[3] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats

## 预防措施

预防犬和猫的败血症需要多方面的方法，针对易感条件和环境风险因素。主要重点应放在维持优秀的围手术期方案上，包括严格的无菌手术技术和对高风险手术适当使用预防性抗生素[1]。

管理易感条件至关重要。免疫功能低下的患者，包括患有糖尿病 mellitus、猫白血病病毒或接受化疗的患者，需要加强监测并对感染早期迹象进行及时干预[1]。早期识别和积极治疗局部感染可防止进展为全身性脓毒症。

环境控制措施包括在兽医设施中保持适当的卫生，对疑似脓毒症患者实施隔离方案，并确保患者之间彻底消毒[1]。围手术期管理至关重要，脓毒性腹膜炎的手术干预需要快速稳定和广谱抗生素治疗[3]。对于脓毒性腹膜炎病例，适当的经验性抗生素治疗显著改善生存结果并缩短住院时间[3]。

适当的抗菌药物管理至关重要 - 尽可能使用窄谱抗生素，避免预防性使用氟喹诺酮类药物，除非在特定高风险情况下[2]。定期监测住院患者的脓毒症早期迹象，包括体温变化、精神状态改变和心血管不稳定，能够在进展为脓毒性休克之前进行快速干预[5]。维持最佳血压和提供充分的液体复苏是关键的预防措施[5]。

### Sources
[1] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[2] Antibiotic prophylaxis in veterinary chemotherapy: When its worth the risk: https://www.dvm360.com/view/antibiotic-prophylaxis-veterinary-chemotherapy-when-it-s-worth-risk
[3] Management of dogs and cats with septic peritonitis (Proceedings): https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[4] Recognizing and treating shock in cats: https://www.dvm360.com/view/recognizing-and-treating-shock-cats
[5] Initial Triage and Resuscitation of Small Animal Emergency Patients: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/evaluation-and-initial-treatment-of-small-animal-emergency-patients/initial-triage-and-resuscitation-of-small-animal-emergency-patients

## 鉴别诊断

败血症必须与几种可能模拟其临床表现的疾病相鉴别，特别是非感染性全身性炎症反应综合征（SIRS）和其他全身性炎症性疾病[1]。

**非感染性SIRS**代表主要的鉴别诊断。无感染的SIRS相关休克最常见原因包括胰腺炎、创伤和烧伤[3]。这些疾病可产生与败血症相同的临床体征，包括发热或低温、心动过速（或猫的心动过缓）、呼吸急促以及白细胞增多或白细胞减少[1,3]。

**免疫介导性疾病**可能表现相似，特别是那些引起全身炎症的疾病。自身免疫性疾病可能产生与败血症体征重叠的发热、嗜睡和异常白细胞计数[6]。然而，这些通常缺乏可识别的感染源，并可能显示不同的器官受累模式。

**肿瘤性疾病**，特别是淋巴瘤或白血病，可引起类似败血症的发热、体重减轻和血液学异常。患有肠道肿瘤的猫特别容易发展为继发性脓毒性腹膜炎，使鉴别诊断复杂化[1,5]。

**鉴别特征**包括通过血培养、影像学或体液细胞学识别记录的感染源[1,5]。SIRS标准特异性有限（犬为64-77%），使明确诊断具有挑战性[1,3]。猫带来额外的诊断复杂性，因为它们经常表现出非典型反应，包括低温和心动过缓，而不是预期的高动力性体征[1,5]。生物标志物和先进的实验室测试可能有助于区分感染性和非感染性原因，尽管伴侣动物的研究仍然有限[1,5]。

### Sources
[1] A fresh look at identifying sepsis in cats: https://www.dvm360.com/view/fresh-look-identifying-sepsis-cats
[2] SIRS, sepsis, and multiple organ dysfunction syndrome demystified: https://www.dvm360.com/view/sirs-sepsis-and-multiple-organ-dysfunction-syndrome-demystified-proceedings
[3] Sepsis and the critical cat: https://www.dvm360.com/view/sepsis-and-critical-cat-proceedings
[4] Excessive Immune Function in Animals: https://www.merckvetmanual.com/immune-system/immunologic-diseases/excessive-immune-function-in-animals

## 预后

伴侣动物败血症的预后根据疾病严重程度、潜在原因和干预时机而有显著差异。犬脓毒症的死亡率范围为50-60%，使其成为需要立即积极治疗的危急紧急情况[1][2]。早期识别和及时治疗是关键的预后因素。

脓毒症定义和评分系统的最新进展提供了更好的预后工具。序贯器官衰竭评估（SOFA）评分系统已被证明在危重犬中作为预后指标是有用的[3]。满足脓毒症-3标准与传统的脓毒症-2定义相比，与住院死亡风险增加相关，表明这些较新的标准能够识别结果较差的患者[4]。

几种生物标志物作为预后指标。升高的乳酸浓度反映组织灌注减少并与不良结果相关[1]。C反应蛋白与白蛋白比值可预测危重犬的结果，较高比值表明预后较差[2]。低白蛋白血症通常表明预后不良，由于持续的炎症蛋白消耗。

患有脓毒症的猫面临特殊挑战，很少表现出高动力阶段，通常表现为低动力特征，包括苍白粘膜和低血压[5]。物种特异性反应模式影响预后评估，猫"比犬更难识别脓毒症"[5]。

### Sources

[1] Management of septic peritonitis: more than surgery: https://www.dvm360.com/view/management-septic-peritonitis-more-surgery-proceedings

[2] C-reactive protein-to-albumin ratio is higher in dogs in the intensive care unit than in the general hospital population and is associated with outcome: https://avmajournals.avma.org/view/journals/javma/263/6/javma.24.12.0830.pdf

[3] SOFA-based scoring system in critically ill dogs: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.24.12.0413/ajvr.24.12.0413.pdf

[4] Comparison of Sepsis-2 and Sepsis-3 definitions: https://avmajournals.avma.org/view/journals/ajvr/86/5/ajvr.24.12.0413.xml

[5] Sepsis and the critical cat: https://www.dvm360.com/view/sepsis-and-critical-cat-proceedings