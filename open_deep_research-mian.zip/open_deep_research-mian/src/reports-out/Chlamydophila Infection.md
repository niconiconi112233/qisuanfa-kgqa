# 伴侣动物衣原体感染：综合临床指南

猫衣原体感染是猫结膜炎的一个重要病因，在某些地区占猫呼吸道病例的30%。这种专性细胞内细菌会产生特征性的严重结膜水肿和持续性眼部分泌物，给兽医从业者在诊断和治疗方面带来挑战。了解这种病原体的独特生物学特性、临床表现和基于循证的管理方案，对于有效实践至关重要。

本报告全面审视了衣原体感染的临床谱系，从其流行病学模式和致病机制到当前使用PCR技术的诊断方法。特别关注了全家庭多西环素治疗方案的关键重要性以及疫苗接种在流行情况下的作用，为从业者提供了管理这种持续性猫病的可行指导。

## 疾病概述

猫衣原体感染是一种影响猫的细菌性疾病，由专性细胞内细菌猫衣原体（以前称为鹦鹉热衣原体）引起[1]。这种病原体主要引起结膜炎，其特征是眼睑内衬膜的炎症[1]。该病是导致猫上呼吸道症状的几种传染性病原体之一，但与病毒性病因相比，其临床表现通常较轻[8]。

从流行病学角度看，猫衣原体感染在全球的患病率各不相同。在北美，它占猫呼吸道疾病病例的比例不到5%，而在英国，估计可能占猫呼吸道感染的30%[9]。该生物体常见于拥挤环境和多猫家庭中，传播通过直接接触或污染物污染发生[8]。猫衣原体的自然传播主要通过与受感染猫的密切接触、气溶胶化的生物体和污染物发生[2]。幼猫和小猫似乎更容易感染，特别是在动物收容所等压力大的饲养条件下[5]。该感染对人类的动物源性风险很小，尽管从猫身上获得的猫衣原体可引起人的角膜结膜炎[2]。该生物体在宿主体外不稳定[2]。

### Sources
[1] Feline Chlamydophila Disease - Merck Animal Health USA: https://www.merck-animal-health-usa.com/nobivac/feline-chlamydophila
[2] Chlamydiosis in Animals - Infectious Diseases: https://www.merckvetmanual.com/infectious-diseases/chlamydiosis/chlamydiosis-in-animals
[5] Feline vaccination: Guidelines, indications, and risks: https://www.dvm360.com/view/feline-vaccination-guidelines-indications-and-risks-proceedings
[8] Feline infectious respiratory disease: https://www.dvm360.com/view/feline-infectious-respiratory-disease-proceedings
[9] Feline viral upper respiratory infection: Why it persists: https://www.dvm360.com/view/feline-viral-upper-respiratory-infection-why-it-persists-proceedings

## 病原体特征和发病机制

猫衣原体（以前称为鹦鹉热衣原体猫变种）是一种革兰氏阴性、专性细胞内细菌，主要引起猫的结膜炎[1]。该生物体在环境中不稳定，主要通过猫与猫之间的直接接触传播，而不是通过污染物[1][3]。

细菌生命周期涉及两种不同的形态形式。原体作为细胞外的感染形式，而网状体代表细胞内的复制阶段[1]。结膜感染后，原体可以在吉姆萨染色的结膜刮片中被识别为细胞质内包涵体[1]。

发病始于暴露后5-10天，最初表现为单眼或双眼的浆液性眼部分泌物[3]。这发展为双侧黏液脓性分泌物并伴有水肿，同时伴有结膜淋巴样细胞浸润和上皮增生[1]。该生物体对结膜上皮表现出趋向性，解释了为什么主要表现为眼部症状，仅偶尔出现轻微的鼻部症状[3]。

猫衣原体感染的特点是产生持续性结膜炎，受感染的猫在明显康复后可能持续排出生物体数月[1][4]。该细菌缺乏细胞壁结构，使其对β-内酰胺类抗生素具有耐药性，但对四环素类和氟喹诺酮类药物敏感[3]。恢复期的猫可能经历复发，该感染已被证明具有动物源性潜力，偶尔会传播给人类引起结膜炎[1][4]。

### Sources
[1] Merck Veterinary Manual Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] MSD Veterinary Manual Chlamydial Conjunctivitis in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/chlamydial-conjunctivitis-in-cats-feline-pneumonitis
[3] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/cat-owners/lung-and-airway-disorders-of-cats/feline-respiratory-disease-complex-feline-viral-rhinotracheitis-feline-calicivirus
[4] AVMA Cytauxzoon felis infection in cats: https://avmajournals.avma.org/view/journals/javma/228/4/javma.228.4.568.xml

## 临床表现和诊断方法

衣原体感染在伴侣动物中表现出特征性的眼部和呼吸道症状。在猫中，临床症状包括浆液性至黏液脓性结膜炎、结膜充血、水肿和浆液性眼部分泌物，严重情况下第三眼睑出现明显的滤泡[1]。潜伏期为3-10天，症状在发病后9-13天最为严重[1]。鼻部分泌物和打喷嚏等呼吸道症状可能伴随结膜炎出现，但仅有鼻炎的猫不太可能感染猫衣原体[1]。

诊断确认主要依靠结膜拭子的PCR检测，这是当前衣原体诊断的金标准[1][2]。与传统方法相比，PCR具有更高的灵敏度和特异性，但由于间歇性排出或采样不足，可能出现假阴性结果[2]。结膜刮片的细胞学检查可能显示用罗曼诺夫斯基染料染成紫色的细胞质内衣原体包涵体，但这些通常仅在感染早期可见[1]。

衣原体的细胞培养虽然灵敏且特异，但常规诊断用途并不广泛，且需要特殊的运输培养基[1]。血清学检测由于商业可用检测试剂的灵敏度和特异性问题而价值有限[1]。建议使用PCR和血清学相结合的诊断方法，特别是在检测单个动物时[2]。对于亚临床受影响的动物，可能需要在3-5天内采集多个样本以检测间歇性排出[2]。

### Sources
[1] Chlamydial Conjunctivitis in Animals: https://www.merckvetmanual.com/en/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals
[2] Updates on disease testing in birds (Proceedings): https://www.dvm360.com/view/updates-disease-testing-birds-proceedings
[3] Chlamydiosis in Animals: https://www.merckvetmanual.com/infectious-diseases/chlamydiosis/chlamydiosis-in-animals
[4] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-

## 治疗方案和预防策略

猫衣原体感染的循证治疗以全身抗生素治疗和全家庭综合管理为中心。**口服多西环素（10 mg/kg/天）至少4周是首选治疗方法**[1]。一些猫可能需要延长治疗至6周以完全消除感染，并且**家庭中的所有猫必须同时治疗以防止再感染**[1]。

全身治疗优于局部治疗，因为**生物体从结膜以外的多个解剖部位排出**，包括直肠和阴道[1]。替代抗生素包括氟喹诺酮类药物如恩诺沙星和普拉多沙星，以及阿莫西林-克拉维酸，但这些药物的效果可能不如多西环素[1]。最近的研究表明，口服多西环素（10 mg/kg，每日一次，持续3周）可以补充或替代局部四环素治疗[2]。

**疫苗接种方案提供有限但有价值的保护**。猫衣原体疫苗不能完全预防感染，但能显著降低疾病严重程度和感染率[1]。在衣原体病流行的猫舍中应考虑使用这些疫苗[1]。**环境控制措施至关重要**，因为传播通过猫之间的直接接触和受污染的污染物发生[1]。该生物体在环境中存活能力差，因此彻底清洁和隔离受影响的猫是控制策略的重要组成部分。

### Sources
[1] Chlamydial Conjunctivitis in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/chlamydial-conjunctivitis/chlamydial-conjunctivitis-in-animals
[2] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-

## 鉴别诊断和预后

### 主要鉴别诊断

衣原体感染必须与其他常见的猫结膜炎和呼吸道疾病原因进行鉴别。主要的鉴别诊断是猫疱疹病毒-1（FHV-1），它是导致大多数猫急性上呼吸道感染的原因，倾向于影响结膜和鼻腔通道[1]。与衣原体不同，FHV-1通常引起更明显的结膜充血和更多的眼部分泌物，常伴有角膜炎和角膜溃疡[2]。

猫杯状病毒是另一个重要的鉴别诊断，其特征是口腔溃疡和倾向于累及下呼吸道[1]。猫支原体感染可引起严重的结膜水肿（水肿），但与衣原体相比通常产生较轻的鼻炎[2,3]。

衣原体感染的区别特征包括结膜特征性的严重水肿（"浮肿"），这比其他病原体更明显[2,4]。感染通常开始于单侧，随时间发展为双侧，如果不治疗，临床症状可持续数周至数月[4]。

### 预后

猫衣原体感染的预后在适当治疗下通常是有利的[2,3]。大多数病例对全身多西环素治疗反应良好，在开始治疗后2-4天内显示临床改善[4]。然而，需要至少4周的延长治疗疗程以完全消除感染并防止复发[3]。

预期结果包括结膜炎症消退、眼部分泌物减少和生物体消除。免疫功能正常的猫通常完全康复，尽管免疫功能受损动物的感染可能遵循更慢性病程[4]。预后仍然良好，因为该病通常是自限性的，死亡率低[1]。

### Sources
[1] Feline Respiratory Disease Complex: https://www.merckvetmanual.com/respiratory-system/respiratory-diseases-of-small-animals/feline-respiratory-disease-complex
[2] Feline conjunctivitis. A cat is not a small dog!: https://www.dvm360.com/view/feline-conjunctivitis-a-cat-is-not-a-small-dog-
[3] Sneezes, snots, and sniffles (Proceedings): https://www.dvm360.com/view/sneezes-snots-and-sniffles-proceedings
[4] How to approach the squinty cat (Proceedings): https://www.dvm360.com/view/how-approach-squinty-cat-proceedings