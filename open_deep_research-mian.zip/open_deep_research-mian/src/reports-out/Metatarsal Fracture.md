# 伴侣动物跖骨骨折：引言

跖骨骨折是犬猫中重要的骨科损伤，主要源于创伤事件，如汽车事故、被踩踏或爪部被困。这些发生在跗骨与趾骨之间的后足骨骼骨折会严重影响患病动物的活动能力和生活质量。

本综合报告探讨了跖骨骨折的多方面性质，涵盖其流行病学模式和临床表现，通过包括CT和应力放射摄影在内的先进诊断成像技术。治疗方法从保守的外部固定到使用髓内针和外骨骼固定的复杂手术干预。报告涉及开放性骨折感染预防的关键方面、包括代谢性骨病和软组织损伤的鉴别诊断，以及影响长期预后和恢复正常功能的循证预后因素。

## 疾病概述

犬猫跖骨骨折是影响位于跗骨和趾骨之间后足长骨的骨科损伤。这些骨折通常由直接创伤引起，如汽车事故、被踩踏或爪部被硬物卡住[1]。

流行病学背景显示，跖骨骨折是小动物临床中的常见损伤，其中掌骨骨折比跖骨骨折更常见[1]。幼年动物和赛犬品种可能特别易感，在 athletic 犬如赛格雷伊犬中观察到应力性骨折，这是由于在硬质表面上反复负荷所致[2]。

创伤性跖骨骨折没有特定的品种易感性，尽管赛犬和猎犬品种可能因其运动活动而面临更高风险。年龄分布因病因而异——创伤性骨折可发生于任何年龄，而应力性骨折更常见于运动动物[2]。

发生率在小动物临床中代表了肢体骨折的重要部分，如果管理不当，潜在并发症包括延迟愈合、畸形愈合或慢性跛行。地理位置和人口密度影响发生率，在车辆创伤常见的城市环境中更为普遍。

### Sources
[1] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[2] Preventing injury in sporting dogs: https://www.dvm360.com/view/preventing-injury-sporting-dogs

## 常见病原体

虽然跖骨骨折主要是骨科损伤，但继发性细菌并发症可显著影响愈合结果。开放性骨折为病原体入侵提供了直接途径，使感染成为骨折管理中的关键问题。

**细菌性骨髓炎**是最重要的感染并发症。常见细菌病原体包括葡萄球菌属、链球菌属、大肠杆菌、变形杆菌属、巴斯德氏菌属和假单胞菌属[1]。厌氧菌也可能在污染伤口中导致多微生物感染。

**开放性跖骨骨折中的伤口污染**引入了环境病原体，可建立局部感染。导致感染的因素包括组织缺血、骨坏死和骨折部位的血管供应受损[1]。

**真菌感染**较少见，但可能根据地理分布发生。球孢子菌、皮炎芽生菌、荚膜组织胞浆菌、新型隐球菌和曲霉属可引起骨感染，特别是在免疫功能低下的动物中[1]。

预防感染并发症需要积极的伤口清创、基于培养和药敏试验的适当抗菌治疗，以及正确的骨折稳定。使用阿莫西林-克拉维酸、头孢唑林或克林霉素等药物进行长期抗生素治疗对于已建立的骨髓炎可能是必要的[1]。

### Sources
[1] Osteomyelitis in Dogs and Cats - Musculoskeletal System: https://www.merckvetmanual.com/en-au/musculoskeletal-system/osteopathies-in-small-animals/osteomyelitis-in-dogs-and-cats

## 临床症状和体征

犬猫跖骨骨折表现出特征性临床体征，其严重程度因骨折位置和构型而异。最一致的发现是受影响肢体的急性发作跛行，从不负重到部分负重不等，取决于骨折稳定性[1]。体格检查通常显示受影响跖骨骨的疼痛性肿胀，在移位骨折中可触及骨擦音和可能的畸形[1]。

跛行严重程度与软组织创伤程度和涉及的骨骼数量相关。单根跖骨骨折的动物可能承受部分体重，而多根跖骨骨折通常导致完全不负重跛行。在创伤性损伤中，爪的内侧最常受影响，特别是在发生剪切力的车辆事故中[4]。

相关软组织损伤经常伴随跖骨骨折发生，包括侧副韧带损伤、足底垫撕裂和皮肤撕脱。在严重情况下，由于并发韧带损伤可能导致关节不稳定，造成额外的临床并发症[4]。虽然赛格雷伊犬对同时涉及多根骨骼的复杂跗跖损伤表现出更高的易感性，但尚未明确简单跖骨骨折的品种易感性[4]。

### Sources
[1] Tarsometatarsal stabilization after metatarsal bone ...: https://avmajournals.avma.org/view/journals/javma/259/3/javma.259.3.294.xml
[2] Distal limb injury: The hind-limb (Proceedings): https://www.dvm360.com/view/distal-limb-injury-hind-limb-proceedings

## 诊断方法

跖骨骨折诊断依赖于系统的临床评估和先进成像技术，以确保准确识别和分类。临床表现评估始于彻底的体格检查，评估跛行模式、可触及的畸形、骨擦音和局部疼痛反应[1]。当初始标准放射线照片显示正常但临床怀疑仍然很高时，应力放射摄影证明是必要的，因为应力视图可以显示不完全骨折或关节不稳定[2]。

放射学评估构成跖骨骨折诊断的基石。四个标准正交视图是必不可少的：背跖位、侧位、背外侧-跖内侧斜位和背内侧-跖外侧斜位投影[2]。这些多角度确保完全可视化骨折线、移位模式和相关的关节受累情况。

先进成像方式包括计算机断层扫描(CT)和磁共振成像(MRI)，为复杂病例提供卓越的细节[3]。线性断层扫描、CT或MRI可能需要用于可视化细微骨折或评估并发软组织损伤[6]。CT在显示皮质骨细节和骨折碎片关系方面表现出色，而MRI提供优越的软组织对比度，用于评估周围的韧带和肌腱结构。

分类系统有助于标准化治疗方法和预后。骨折按位置（近端、骨干中段或远端）、构型（横向、斜向或粉碎性）和稳定性分类[4]。这种系统分类指导治疗决策和手术规划，以获得最佳患者结果。

### Sources
[1] Distal limb injury: The hind-limb (Proceedings): https://www.dvm360.com/view/distal-limb-injury-hind-limb-proceedings
[2] Trauma and First Aid in Horses - Emergency Medicine: https://www.merckvetmanual.com/emergency-medicine-and-critical-care/emergency-medicine-in-horses/trauma-and-first-aid-in-horses
[3] a horse in the musculoskeletal imaging race in - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/83/7/ajvr.22.03.0051.xml
[4] ajvr.24.11.0364.pdf - AVMA Journals: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/86/4/ajvr.24.11.0364.pdf
[5] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[6] Juvenile bone and joint diseases: large dogs front leg: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings

## 治疗选项

伴侣动物跖骨骨折的治疗可以通过保守管理或手术干预进行，取决于骨折特征和患者因素[1]。

**保守管理**
保守治疗涉及闭合复位和外部固定。患者在深度镇静或麻醉下，将Allis组织钳放在第II和第V趾上，通过牵引辅助手动骨折复位[1]。应用柔软的衬垫绷带，配合外侧夹板或双瓣石膏进行跖骨稳定[1]。这种方法通常对1-4根跖骨骨折有效，与手术方法相比可能显示更快的愈合率[1]。外部固定结合物理治疗可为小动物提供有利结果[3]。

**手术干预**
当两根或更多跖骨骨折、涉及负重骨（第3和第4根）或对于大型品种、展示犬或运动犬时，传统上推荐内固定[1]。手术选择包括从远端段顺行插入髓内针，通过关节面近端的钻孔，最好在透视镜引导下进行[1]。拉力螺钉固定对斜向骨折有效，而小型骨板（1.5-2.0毫米）配合螺钉为各种骨折模式提供稳定[1]。

先进固定方法包括用于肢体骨折的加强自由形式外骨骼固定(rFF-ESF)[7]。外骨骼固定器可以与不同的髓内和经骨针构型结合，以优化机械性能[8]。

**术后护理和康复**
保守和手术治疗都需要术后6-8周的外部固定[1]。随访包括每10-14天更换绷带以预防并发症，以及每四周进行放射学监测以评估愈合进展[1]。术后10-14天的运动限制对最佳愈合至关重要[2]。

### Sources
[1] Surgery STAT: Metacarpal and metatarsal fractures: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management
[2] Juvenile orthopedic diseases (Proceedings): https://www.dvm360.com/view/juvenile-orthopedic-diseases-proceedings
[3] Congenital tarsal hyperextension in three cats: https://avmajournals.avma.org/view/journals/javma/228/8/javma.228.8.1200.xml
[4] Transfixation casting (Proceedings): https://www.dvm360.com/view/transfixation-casting-proceedings
[5] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml
[6] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/ajvr/81/7/ajvr.81.7.557.xml

## 预防措施

预防犬猫跖骨骨折需要全面的方法，重点关注环境安全修改和主人教育。这些骨折的主要原因包括车辆创伤、被踩踏和爪部被硬物卡住[1]。

环境安全对骨折预防至关重要。主人应使用适当的围栏保护其财产，并在散步时保持牵引绳以防止汽车事故[1]。应消除或固定室内危险物，如可能落在宠物身上或卡住爪子的重物[2]。

运动管理在预防中起着至关重要的作用。虽然定期体力活动维持骨强度，但应避免高危动物的高冲击活动[1]。体重管理特别重要，因为肥胖增加骨骼和关节的压力，可能使动物易患骨折[1]。

主人教育应强调识别跛行的早期迹象并及时寻求兽医关注[1]。大型品种犬、展示动物或高度活跃宠物的主人应特别警惕，因为这些动物如果发生骨折可能面临更高的并发症风险[2]。

正确的处理技术和玩耍期间的监督可以预防创伤相关损伤。教导主人创造安全环境和识别潜在危险有助于降低骨折风险[1][2]。

### Sources

[1] Bone Trauma in Dogs and Cats - Musculoskeletal System - Merck Veterinary Manual: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats

[2] Surgery STAT: Metacarpal and metatarsal fractures: conservative or surgical management?: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management

## 鉴别诊断

跖骨骨折必须与几种表现出相似跛行和不适模式的疾病进行鉴别[1]。**其他骨折类型**代表主要鉴别诊断，包括腕骨和跗骨骨折，这些可分为扭伤、脱位、骨折或这些损伤的组合[1]。侧副韧带附着处的撕脱骨折和前肢的副腕骨骨折表现出相似的临床体征[1]。

**软组织损伤**经常模拟跖骨骨折，特别是影响支撑结构的韧带扭伤[1]。1-3级扭伤导致不同程度的跛行和关节不稳定，可能被误认为骨折相关症状[1]。涉及多条韧带和关节囊破裂的**关节脱位**产生相似的疼痛和功能障碍模式[1]。

**代谢性骨病**代表重要的鉴别诊断，特别是营养性继发性甲状旁腺功能亢进导致的骨骼弱化，易发生病理性骨折[2][3]。猫的苏格兰折耳骨营养不良涉及跖骨畸形和肿胀，模拟创伤性骨折[2][3]。**发育性疾病**包括影响幼年动物长骨和椎骨干骺端表面的多发性软骨外生骨疣[4]。

**骨髓炎**表现为跛行、疼痛和潜在的骨破坏，可能类似骨折并发症[2][3]。骨肿瘤，特别是骨肉瘤，引起跛行、肿胀和无明显创伤的病理性骨折[2][3]。

**鉴别因素**包括放射学评估显示骨折线、骨移位或关节间隙异常，这些是骨损伤特有的，而软组织损伤则不同[1]。当放射线照片显示正常时，先进成像有助于诊断韧带损伤[1]。

### Sources
[1] Carpal and tarsal sports-related injuries (Proceedings): https://www.dvm360.com/view/carpal-and-tarsal-sports-related-injuries-proceedings
[2] Bone Disorders in Cats - Cat Owners: https://www.merckvetmanual.com/en-au/cat-owners/bone-joint-and-muscle-disorders-of-cats/bone-disorders-in-cats
[3] Bone Disorders in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/bone-joint-and-muscle-disorders-of-dogs/bone-disorders-in-dogs
[4] Developmental Osteopathies in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/developmental-osteopathies-in-dogs-and-cats

## 预后

犬猫跖骨骨折的预后在适当治疗下通常良好，尽管几个因素显著影响结果。单独使用外部固定的保守管理通常取得优异结果，研究表明手术和非手术方法之间的临床结果差异很小[1]。

愈合时间根据患者年龄、骨折类型和治疗方法而异[2]。大多数病例的平均愈合期为6-8周，无论是否使用内固定，通常在此期间都需要外部固定[1]。年轻健康的动物通常比老年患者愈合更快。

几个因素对恢复产生负面影响。手术干预的并发症可包括延迟愈合、感染和植入物上方皮肤坏死，特别是当开放手术方法损害血管供应时[1]。玩具品种犬的跖骨骨小尺寸为内固定带来了额外挑战[1]。

猫的外固定器管理显示出有希望的结果，一项研究报告93%的成功结果和8周的中位固定器移除时间[3]。然而，一些病例可能需要长达61周的延长治疗期[3]。

长期预后取决于骨折复杂性和患者因素。简单、最小移位的骨折通常愈合而无显著功能损害。延迟愈合或不愈合等并发症可能需要额外干预，包括骨移植或替代固定方法[2]。总体而言，大多数患者在适当治疗和术后管理下恢复正常功能。

### Sources

[1] Surgery STAT: Metacarpal and metatarsal fractures: conservative or surgical management?: https://www.dvm360.com/view/surgery-stat-metacarpal-and-metatarsal-fractures-conservative-or-surgical-management

[2] Treating fracture disease and nonunion fractures (Proceedings): https://www.dvm360.com/view/treating-fracture-disease-and-nonunion-fractures-proceedings

[3] Abstract - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/259/5/javma.259.5.510.xml