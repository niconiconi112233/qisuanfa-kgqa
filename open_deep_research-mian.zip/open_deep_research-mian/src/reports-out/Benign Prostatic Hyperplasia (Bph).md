# 犬良性前列腺增生：综合兽医指南

良性前列腺增生（BPH）是未去雄性犬最常见的前列腺疾病，影响高达80%的六岁以上犬只。这种激素介导的疾病导致前列腺进行性增大，可能从无症状到需要干预的临床显著疾病。本报告基于当前兽医文献和临床证据，探讨了犬BPH的病理生理学、诊断方法和治疗策略。主要主题包括苏格兰梗的品种易感性、使用犬前列腺特异性酯酶检测的先进诊断技术、用于种犬的医疗管理方案，以及非育种犬的手术干预。

## 摘要与临床意义

犬良性前列腺增生是一个复杂的临床挑战，需要根据育种状态和症状严重程度采取个体化治疗方案。该疾病影响63-80%的六岁以上未去势雄性犬，其中苏格兰梗表现出特殊的易感性。诊断依赖于超声检查和犬前列腺特异性酯酶检测，后者在61 ng/mL临界值时显示出97%的敏感性。

| 治疗方法 | 适应症 | 疗效 | 注意事项 |
|---------|--------|------|---------|
| 去势术 | 非育种犬 | 数月内完全消退 | 永久性，影响激素 |
| 非那雄胺 | 育种雄性犬 | 体积减少43-70% | 保留生育能力，需每日给药 |
| 奥沙替酮醋酸酯 | 育种雄性犬（欧洲） | 14天内改善50% | 可能改善精液质量 |
| GnRH植入剂 | 临时化学去势 | 体积减少60% | 可逆但影响生育能力 |

适当治疗的良好预后与前列腺肿瘤等鉴别诊断形成鲜明对比。早期识别和及时干预可预防并发症，因此对四岁以上未去势雄性犬进行常规前列腺监测至关重要。

查看现有部分内容和提供的来源，我可以看到当前部分已经包含关于BPH定义和流行病学的全面信息。来源材料提供了一些额外的品种特异性信息，可以与现有内容综合。

## 疾病概述与流行病学

良性前列腺增生（BPH）是未去势雄性犬最常见的前列腺疾病[1]。BPH是由雄激素刺激或改变的雄激素与雌激素比例导致的前列腺非肿瘤性增大[1]。

流行病学数据显示显著的年龄相关模式。在某些犬中，增生可能早在2.5岁就开始，囊性增生通常在4岁后发展[1]。一项对300只性成熟雄性犬的研究显示患病率为63.4%，其中231只犬患有BPH[6]。另一项研究报告6岁或以上犬的患病率为75-80%[4]。

苏格兰梗似乎比其他犬种受影响更严重，表现出对BPH的特殊易感性[5]。这些品种特异性模式表明遗传因素可能影响疾病易感性和严重程度。

目前尚不清楚为什么有些未去势雄性犬会患上BPH而其他犬不会，这表明个体在激素敏感性或遗传易感性方面存在差异[1]。该疾病仅与未去势雄性犬相关，因为去势通过去除雄激素刺激可防止疾病发展[1]。

在许多情况下，临床症状可能完全不存在，但当出现时，通常包括持续性或间歇性血尿、血精和出血性包皮排出物[1]。许多患有BPH的未去势雄性犬保持无症状，或仅表现为血精和不育症状[4]。

### Sources
[1] Benign Prostatic Hyperplasia in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/benign-prostatic-hyperplasia-in-dogs-and-cats
[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[3] Optimal age for gonadectomy in dogs and cats (Proceedings): https://www.dvm360.com/view/optimal-age-gonadectomy-dogs-and-cats-proceedings
[4] Prostatic Diseases in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-diseases-in-small-animals

## 病理生理学与临床表现

犬良性前列腺增生（BPH）通过未去势雄性犬中复杂的激素机制发展。该疾病主要由雄激素刺激引起，其中睾酮通过5α-还原酶转化为双氢睾酮[1]。双氢睾酮是促进犬前列腺增生的生物活性激素，导致腺体和基质细胞增殖[2]。

病理生理学涉及改变的雄激素：雌激素比例，导致前列腺进行性增大[2]。在某些犬中，增生可能早在2.5岁就开始，囊性增生通常在4岁后发展[2]。决定为什么有些雄性受影响而其他雄性不受影响的确切机制尚未完全了解[2]。

临床表现差异很大，许多犬尽管前列腺显著增大但仍保持无症状[1]。当出现临床症状时，最常见的症状包括持续性或间歇性血尿、血精和出血性包皮排出物[2]。体格检查通常显示无痛、对称增大的前列腺[2]。

从亚临床到症状性疾病的进展取决于前列腺增大程度和个体解剖因素[1]。如果增大的前列腺压迫邻近结构，犬可能排尿或排便困难，但在单纯性BPH病例中完全性尿道梗阻不常见[1]。排便时里急后重可能发生，因为增大的前列腺通常在尾腹部向头侧移位[1]。

### Sources

[1] Prostatic Diseases in Small Animals: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-diseases-in-small-animals
[2] Benign Prostatic Hyperplasia in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/benign-prostatic-hyperplasia-in-dogs-and-cats

## 诊断方法

犬良性前列腺增生的综合诊断评估结合多种方法以实现准确诊断。体格检查仍然是基础，包括同时进行腹部和直肠触诊以评估前列腺大小、形状、对称性、质地和活动度[1]。

**影像学技术**

经腹超声检查是前列腺评估的最佳影像学方法，允许评估前列腺实质和周围软组织[1]。在BPH中，超声检查通常显示弥漫性、相对对称的受累，伴有多发性弥漫性囊性结构[2]。高回声通常与良性前列腺增生相关[1]。计算机断层扫描显示出诊断潜力，研究表明能够使用亨氏单位测量前列腺密度和均匀性[3]。

腹部X线片有助于确定前列腺大小、形状和位置，同时评估腰下淋巴结和骨骼结构以发现潜在转移[1]。

**实验室检测**

犬前列腺特异性酯酶（CPSE）测量是一种有价值的诊断工具，在BPH病例中血清水平显著高于正常犬[1][6]。当使用61 ng/mL临界值时，CPSE对BPH诊断显示出97%的敏感性和90%的特异性[6]。

**细胞学评估**

通过手动射精和单独收集第三（前列腺）部分收集前列腺液，为细胞学检查提供代表性样本[1]。细胞学检查显示轻度炎症的出血，没有脓毒症或肿瘤证据[2]。当射精不可能时，可以采用前列腺按摩技术[1]。

**确诊**

确诊需要通过前列腺活检进行组织病理学检查，可通过剖腹术或由熟练的超声医师进行[1][2]。这仍然是确认BPH诊断的金标准。

### Sources
[1] Prostatic Diseases in Small Animals - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-diseases-in-small-animals
[2] Benign Prostatic Hyperplasia in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/benign-prostatic-hyperplasia-in-dogs-and-cats
[3] Computed Tomography and Canine Prostate Disease: https://www.dvm360.com/view/computed-tomography-and-canine-prostate-disease
[4] Neoplasms of the Prostate in Dogs and Cats - Reproductive System - Merck Veterinary Manual: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/neoplasms-of-the-prostate-in-dogs-and-cats
[5] What Is Your Diagnosis? in: Journal of the American Veterinary Medical Association Volume 259 Issue S1 (2022): https://avmajournals.avma.org/view/journals/javma/259/S1/javma.20.12.0705.xml
[6] Prostate-Specific Protein Can Be Used to Diagnose BPH in Middle-Aged Dogs: https://www.dvm360.com/view/prostatespecific-protein-can-be-used-to-diagnose-bph-in-middleaged-dogs
[7] Cytology - Clinical Pathology and Procedures - Merck Veterinary Manual: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗策略

对于不用于育种的犬，去势是BPH的首选治疗方法[1]。前列腺萎缩通常在去势后数周内开始，并在数月内完全完成[1]。对于育种犬，有几种医疗治疗方案可供选择。

非那雄胺对育种雄性犬非常有效，剂量为0.1-0.5 mg/kg每日[1]。这种5α-还原酶抑制剂阻止睾酮转化为双氢睾酮，在16-21周内使前列腺体积减少43-70%，而不影响精液质量或生育能力[1]。较低剂量（0.1 mg/kg/日）维持正常睾酮水平和性欲[1]。

在欧洲可用的奥沙替酮醋酸酯，剂量为0.25 mg/kg每日一次[1]。这种具有抗雄激素活性的睾酮类似物在约50%的犬中在14天内解决临床症状[1]。与其他治疗方法不同，奥沙替酮可以改善精液质量和生育能力[1]。

GnRH激动剂植入剂（地洛瑞林）提供持续6-12个月的可逆化学去势[1][2]。这些植入剂可将前列腺体积减少高达60%，但在活动期间会阻止精子发生[1]。地洛瑞林植入剂在欧洲、澳大利亚和新西兰被批准用于雄性犬的可逆去势[1]。

当BPH并发细菌性前列腺炎时，使用能穿透前列腺-血液屏障的抗生素治疗至关重要[2]。氟喹诺酮类、甲氧苄啶-磺胺和克林霉素是首选药物，至少给药6周[2]。

### Sources
[1] Benign Prostatic Hyperplasia in Dogs and Cats: https://www.merckvetmanual.com/en-au/reproductive-system/prostatic-diseases/benign-prostatic-hyperplasia-in-dogs-and-cats
[2] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings

## 预防、预后与鉴别诊断

**预防措施**
去势是BPH最有效的预防方法[1]。早期去势可完全预防该疾病，而患病犬的去势可阻止疾病进展[3]。对于育种犬，通过直肠检查和超声检查进行常规监测和早期发现至关重要。使用非那雄胺的药物治疗可防止未去势育种雄性犬的疾病进展[1]。

**预后**
BPH的预后在适当治疗下良好。通过去势，前列腺萎缩在数周内开始，并在数月内完全完成[1]。使用非那雄胺治疗的犬在16-21周内前列腺肥大减少50-70%[1]。然而，药物治疗需要持续给药，因为停药后前列腺增大会复发[5]。

**鉴别诊断**
关键鉴别诊断包括慢性细菌性前列腺炎，它引起类似的前列腺增大但伴有疼痛和全身症状[7]。前列腺囊肿表现为不对称增大，可通过超声检查鉴别[9]。前列腺肿瘤通常发生在老年犬中，引起不规则、疼痛性增大并可能转移[5]。与BPH不同，前列腺癌同样影响未去势和已去势雄性犬，且预后不良[5]。

### Sources
[1] Benign Prostatic Hyperplasia in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/benign-prostatic-hyperplasia-in-dogs-and-cats
[2] The gonad chronicles, part 2: Veterinary research explores neutering's elusive impact: https://www.dvm360.com/view/gonad-chronicles-part-2-veterinary-research-explores-neuterings-elusive-impact
[3] Prostatic disease in the dog (Proceedings): https://www.dvm360.com/view/prostatic-disease-dog-proceedings
[4] Prostatitis in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatitis-in-dogs-and-cats
[5] Prostatic and Paraprostatic Cysts in Dogs and Cats: https://www.merckvetmanual.com/reproductive-system/prostatic-diseases/prostatic-and-paraprostatic-cysts-in-dogs-and-cats