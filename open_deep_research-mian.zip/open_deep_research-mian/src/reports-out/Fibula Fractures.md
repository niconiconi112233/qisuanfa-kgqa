# 伴侣动物腓骨骨折

犬猫的腓骨骨折由于其常伴随胫骨损伤以及该骨的非承重特性，呈现出独特的临床挑战。这些骨折通常由高能量创伤引起，如机动车事故或跌落，幼年动物和大型犬表现出更高的易感性。虽然单纯的腓骨骨折可能因该骨的支撑而非承重功能而仅引起轻微跛行，但伴随的胫骨受累会显著增加治疗难度并影响预后。本报告探讨了管理伴侣动物腓骨骨折的解剖学考虑、诊断方法和基于证据的治疗选择，强调了系统评估和适当手术干预对于优化患者结果和预防长期并发症的重要性。

## 解剖学与生物力学

腓骨是犬猫后肢中一根较小的非承重骨骼，与胫骨平行排列。了解腓骨解剖学对于伴侣动物骨折的正确管理至关重要。

**解剖结构和物种差异**
腓骨骨干在不同物种间表现出明显的解剖学变异。与犬相比，猫的骨干解剖通常更直，这影响了骨折模式和固定方法[1][2]。腓骨近端与胫骨外侧髁形成关节，远端构成距小腿关节的一部分。骨软骨病可影响腓骨的内侧或外侧茎突，特别是在大型犬中[3]。

**生物力学功能**
与承重的胫骨不同，腓骨主要作为肌肉和韧带的附着点。胫骨作为主要的承重骨骼，对犬猫的运动至关重要[4]。腓骨提供外侧稳定性，并作为后肢各种肌肉的起点和止点。在桡尺骨发育不同步等发育性疾病中，类似的模式可影响胫骨和腓骨，腓骨缩短导致腓骨头脱位和外翻畸形[5]。

**临床意义**
腓骨的非承重特性意味着单纯的腓骨骨折很少引起明显的跛行。然而，当腓骨骨折与胫骨骨折同时发生时，它们可能影响整个肢体的稳定性和愈合。兽医从业者在评估后肢损伤和制定适当治疗策略时，理解这些解剖学和生物力学原理至关重要。

### Sources
[1] A generic precurved interlocking nail is more compatible with ...: https://avmajournals.avma.org/downloadpdf/view/journals/ajvr/86/3/ajvr.24.09.0267.pdf
[2] A generic precurved interlocking nail is more compatible with ...: https://avmajournals.avma.org/view/journals/ajvr/86/3/ajvr.24.09.0267.xml
[3] Bone appetit: an appetizer of developmental orthopedic ...: https://www.dvm360.com/view/bone-appetit-appetizer-developmental-orthopedic-radiology-proceedings
[4] Fully threaded headless cannulated screws ...: https://avmajournals.avma.org/view/journals/ajvr/aop/ajvr.25.03.0104/ajvr.25.03.0104.pdf
[5] Juvenile bone and joint diseases: large dogs front leg ...: https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings

## 病因学与流行病学

伴侣动物的腓骨骨折通常是由高能量力量引起的创伤性损伤，包括机动车事故、高处坠落和直接钝性创伤[1]。由于这些骨骼在下肢中的解剖位置接近和功能关系，这些骨折通常作为胫骨骨折的一部分同时发生[1]。与胫骨相比，腓骨主要作为肌肉附着点，提供最小的承重支持[1]。

年龄分布呈双峰模式，幼年动物（18个月以下）由于骨骼更柔软、更具可塑性以及活动水平较高而特别易感[1][2]。在生长动物中，骨骺损伤占长骨骨折的30%，在受伤时最活跃生长的骨骺最易受损[2]。大型犬对腓骨骨折表现出更高的易感性，特别是当与胫骨损伤相关时[1][2]。肥大性骨营养不良影响2至8月龄快速生长的大型至巨型犬，可能导致腓骨损伤，德国牧羊犬、魏玛犬和大丹犬显示出更高的发病率[3]。

性别易感性因年龄组而异，年轻、更活跃的犬无论性别都显示出更高的发病率[1]。然而，一些研究表明，与未绝育的动物相比，绝育动物可能具有稍高的风险[1]。胫骨和腓骨的同时受累由于双骨系统动力学而创造了独特的挑战，其中不同步的愈合可能导致显著的角状畸形和生长障碍，特别是当一个骨骼的骨骺过早闭合而另一个继续生长时[2]。

### Sources
[1] Juvenile bone and joint diseases: large dogs front leg (Proceedings): https://www.dvm360.com/view/juvenile-bone-and-joint-diseases-large-dogs-front-leg-proceedings
[2] Managing physeal and articular fractures (Proceedings): https://www.dvm360.com/view/managing-physeal-and-articular-fractures-proceedings
[3] Juvenile orthopedic diseases (Proceedings): https://www.dvm360.com/view/juvenile-orthopedic-diseases-proceedings

## 临床评估与诊断

犬猫腓骨骨折的临床评估需要系统检查和准确的诊断影像学检查，以确定骨折构型和相关损伤[1]。初步评估侧重于跛行严重程度、疼痛定位和骨折部位的肿胀[2]。

放射学检查对于明确诊断和手术规划至关重要[2]。正交放射线照片（侧位和头尾位视图）是强制性的，以可视化骨折模式、移位情况和伴随的胫骨受累情况[2]。数字放射线照相系统现在是标准，提供优越的对比度分辨率和即时图像可用性[2][3]。正确的患者定位对于准确测量和手术规划至关重要[2]。

分类系统根据骨折模式（简单、粉碎、斜行、横行或螺旋形）和损伤机制对腓骨骨折进行分类[2]。完整的骨科检查必须评估相关损伤，特别是伴随的胫骨骨折或膝关节不稳定，因为腓骨骨折通常继发于更严重的创伤[2][4]。

包括计算机断层扫描在内的先进影像学技术可能适用于复杂病例或怀疑有伴随损伤的情况[3]。系统评估还必须评估心肺和泌尿功能，因为骨折通常由重大创伤事件引起[2]。

### Sources
[1] Fracture Repair in Toy Breed Dogs & Cats: https://www.dvm360.com/view/fracture-repair-toy-breed-dogs-cats
[2] Bone Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/osteopathies-in-small-animals/bone-trauma-in-dogs-and-cats
[3] Diagnostic Imaging: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging
[4] Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats

## 治疗方法与结果

伴侣动物的腓骨骨折需要基于证据的治疗方法，考虑骨折类型、患者因素和预期结果。治疗选择范围从保守管理到手术干预，特定技术针对个体病例进行调整[1]。

**保守管理**
保守治疗通常保留用于稳定的、无移位的腓骨骨折或手术禁忌时。这种方法包括6-8周的严格笼养休息、使用非甾体抗炎药进行疼痛管理，以及控制性康复并逐渐恢复活动[2]。成功率各不相同，取决于骨折稳定性和患者依从性。

**手术干预**
腓骨骨折有多种手术固定方法可用。利用动力加压钢板（DCP）的钢板固定代表了兽医外科中最常用的技术，通过偏心加载螺钉孔来施加加压[4]。使用钉、线或螺钉进行内固定提供稳定的解剖重建以维持关节一致性[5]。外骨骼固定是另一种主要的手术选择，特别适用于复杂病例，利用穿过骨段的钉或线与外部连接杆相连[2]。

**专门技术**
对于涉及腓骨的踝部骨折，内侧踝可以用2根克氏针和骨科线进行复位和稳定[1]。关节骨折需要使用骨板和螺钉、钉和线或外骨骼固定对受影响的关节进行融合（关节固定术）[5]。

**并发症与结果**
常见并发症包括钉道引流（最常见）、元件松动和需要移除元件和抗生素治疗的感染[2]。恢复通常涉及放射学评估之间4-6周的间隔，以监测愈合进展[2]。

### Sources
[1] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/245/10/javma.245.10.1095.xml
[2] Postoperative management of external fixators in dogs and cats: https://www.dvm360.com/view/postoperative-management-external-fixators-dogs-and-cats
[3] Evaluation of recovery of limb function by use of force plate: https://avmajournals.avma.org/view/journals/ajvr/80/5/ajvr.80.5.461.xml
[4] Fractures and luxations of the hind limb: https://www.dvm360.com/view/fractures-and-luxations-hind-limb-proceedings
[5] Joint Trauma in Dogs and Cats: https://www.merckvetmanual.com/musculoskeletal-system/arthropathies-and-related-disorders-in-small-animals/joint-trauma-in-dogs-and-cats