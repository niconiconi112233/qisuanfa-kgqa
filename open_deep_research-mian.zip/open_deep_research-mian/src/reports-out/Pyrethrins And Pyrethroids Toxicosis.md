# 伴侣动物除虫菊酯和拟除虫菊酯中毒

除虫菊酯和拟除虫菊酯中毒是小动物兽医临床中最显著的中毒之一，尤其影响猫科患者。这种神经系统疾病是由于接触从菊花中提取的天然除虫菊酯化合物或在常见跳蚤和蜱虫控制产品中发现其合成拟除虫菊酯类似物所致。由于肝脏生物转化能力有限，猫对这些化合物表现出极高的敏感性，当中毒经常发生在将犬用氯菊酯产品不当用于猫身上时。本报告探讨了处理这种常见兽医紧急情况所需的病理生理学、临床表现、诊断方法和治疗方案，强调了物种特异性考虑因素和预防策略。

## 疾病概述

除虫菊酯和拟除虫菊酯中毒是一种神经系统疾病，由接触常见于跳蚤和蜱虫控制产品中的合成（拟除虫菊酯）和天然（除虫菊酯）杀虫剂引起 [1]。除虫菊酯源自菊花植物，而拟除虫菊酯是具有更高环境稳定性和有效性的合成类似物 [1]。这些化合物通过与神经膜中的钠通道结合，导致神经重复放电，从而产生神经系统症状 [1]。

由于通过肝脏生物转化代谢这些化合物的能力有限，猫对拟除虫菊酯极为敏感 [1][2]。最常见的接触情况是将犬用氯菊酯滴剂产品（含45%或65%氯菊酯）不当用于猫身上 [1][3]。猫也可能通过与最近接受过治疗的犬密切接触而发生中毒 [1][3]。

拟除虫菊酯中毒是前往兽医急诊中心的猫科患者中最常见的中毒之一，占2010年猫科相关毒理学咨询的9% [3][4]。该疾病对猫的影响比犬更严重，发作通常在接触后数小时内发生，但可能延迟至接触后24-72小时 [1][3]。季节性模式与温暖月份跳蚤控制产品使用增加相关。

### Sources
[1] Common toxicities in cats (Proceedings): https://www.dvm360.com/view/common-toxicities-cats-proceedings
[2] Potential toxins for "in town" pets (Proceedings): https://www.dvm360.com/view/potential-toxins-town-pets-proceedings
[3] Toxicology Brief: The 10 most common toxicoses in cats: https://www.dvm360.com/view/toxicology-brief-10-most-common-toxicoses-cats
[4] Top 5 household items toxic to cats: https://www.dvm360.com/view/top-5-household-items-toxic-cats

## 常见病原体

虽然除虫菊酯和拟除虫菊酯中毒不是由传统病原体引起的传染性疾病，但了解毒剂本身对兽医从业者至关重要。这种中毒的主要"毒剂"是从菊花中提取的天然除虫菊酯及其合成对应物拟除虫菊酯 [6,7]。

**天然除虫菊酯**
除虫菊酯是从菊花中提取的天然化合物，多年来一直是有效的杀虫剂 [9]。这些化合物存在于各种跳蚤和蜱虫控制产品中，包括香波、浸泡液、喷雾剂和滴剂制剂 [7]。

**合成拟除虫菊酯**
拟除虫菊酯是天然除虫菊酯的合成衍生物，通常更有效且具有更长的残留活性 [8,9]。常见的合成拟除虫菊酯包括氯菊酯、氰戊菊酯、苯氰菊酯、联苯菊酯、丙烯菊酯、胺菊酯和高效氯氰菊酯 [6,7,10]。根据其化学结构和毒理学效应，这些化合物被分为I型和II型类别 [7]。

**产品分类**
这些化合物常见于挤式外用跳蚤/蜱虫治疗产品、家用杀虫喷雾剂、跳蚤香波、跳蚤项圈、熏蒸剂和庭院杀虫剂制剂中 [6,7]。猫对这些化合物的敏感性显著高于犬，最大的担忧来自于将犬用拟除虫菊酯基滴剂产品用于猫身上 [6,7,10]。

### Sources
[1] 8 substances that can result in toxicoses in certain species: https://www.dvm360.com/view/8-substances-can-result-toxicoses-certain-species
[2] Common hazards for cats (Proceedings): https://www.dvm360.com/view/common-hazards-cats-proceedings
[3] Ectoparasiticides Used in Small Animals - Pharmacology: https://www.merckvetmanual.com/pharmacology/ectoparasiticides/ectoparasiticides-used-in-small-animals
[4] Insecticide Poisoning - Special Pet Topics: https://www.merckvetmanual.com/special-pet-topics/poisoning/insecticide-poisoning
[5] Common toxicities in cats (Proceedings): https://www.dvm360.com/view/common-toxicities-cats-proceedings

## 临床症状和体征

除虫菊酯和拟除虫菊酯中毒在伴侣动物中表现出独特的神经系统表现。初始临床症状通常在接触后几分钟到几小时内出现，尽管发作可能延迟至24-72小时 [1,6]。

**神经系统体征**
震颤是最具特征性的发现，开始时为细小的肌肉颤搐，逐渐发展为全身性震颤 [1,6,7]。猫可能表现出特定行为，包括耳朵抽动、浅表皮肤肌肉收缩和爪子摇晃 [6,8]。在严重情况下可能发生癫痫发作，并伴有过度兴奋和共济失调 [7,9]。

**胃肠道表现**
过度流涎是常见的观察现象，常伴有呕吐和厌食 [6,7,9]。这些症状可能在临床病程早期出现，并可能在整个中毒过程中持续存在。

**物种特异性模式**
与犬相比，猫对拟除虫菊酯毒性表现出明显增加的敏感性 [6,8]。猫科动物的接触通常是由于不当使用含有45-65%活性成分的犬用氯菊酯产品 [6,10]。即使通过梳理或密切身体接触与最近接受过治疗的犬进行极小接触，也可能导致猫中毒 [6,8]。

**其他临床特征**
其他表现包括抑郁、呼吸困难、虚弱、俯卧以及高热或低体温 [7,9]。II型拟除虫菊酯可能引起舞蹈手足徐动症或流涎综合征 [7]。临床症状的严重程度在接触相似剂量的个体动物之间差异显著，有些仅出现轻微的肌肉颤搐，而其他则发展为危及生命的症状 [6]。

### Sources
[1] Merck Veterinary Manual Plant-Derived Insecticide Toxicosis: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/plant-derived-insecticide-toxicosis-in-animals
[2] DVM 360 Pyrethroid toxicity in felines: https://www.dvm360.com/view/pyrethroid-toxicity-felines-prognosis-good-guarded
[3] DVM 360 Common hazards for cats: https://www.dvm360.com/view/common-hazards-cats-proceedings

## 诊断方法

除虫菊酯和拟除虫菊酯中毒的诊断主要依靠临床评估而非实验室确认 [1]。接触含除虫菊酯产品的病史至关重要，特别是当猫主人不当使用含有高浓度氯菊酯的犬用跳蚤产品时 [2]。体格检查结果通常显示特征性的神经系统症状，包括肌肉震颤、过度兴奋、癫痫发作，特别是在猫中，耳朵抽动和爪子摇晃 [1]。

一个关键的诊断鉴别涉及将拟除虫菊酯毒性与有机磷或氨基甲酸酯中毒区分开来，这些中毒表现出相似的临床症状 [1][3]。关键的鉴别测试是胆碱酯酶酶活性测量。正常的胆碱酯酶活性表明拟除虫菊酯接触，而活性降低则提示有机磷或氨基甲酸酯中毒 [1][2]。血液样本应提交给对测试物种有既定参考范围的实验室。

直接测量血液或组织样本中的拟除虫菊酯通常是徒劳的，因为血浆和组织酯酶在分析检测前会迅速水解这些化合物 [1]。因此，诊断必须依赖于接触史、相容的临床症状、正常胆碱酯酶水平和对症状性治疗的反应组合。对于无症状患者，应实施基本的去污程序，包括使用温和洗涤剂彻底洗澡以去除皮肤上的残留产品 [3]。

### Sources

[1] Pyrethroid toxicity in felines: prognosis good to guarded: https://www.dvm360.com/view/pyrethroid-toxicity-felines-prognosis-good-guarded
[2] Common toxicities in cats (Proceedings) - dvm360: https://www.dvm360.com/view/common-toxicities-cats-proceedings
[3] Potential toxins for "in town" pets (Proceedings): https://www.dvm360.com/view/potential-toxins-town-pets-proceedings

## 治疗方案

除虫菊酯和拟除虫菊酯中毒的治疗需要立即去污、症状性管理和支持性护理。这些中毒没有特定的解毒剂 [1]。

**去污**至关重要，包括使用液体洗洁精（如Dawn）和冷水彻底洗澡，以去除皮肤和毛发上的残留产品 [1][3]。洗澡应在震颤控制后进行，因为给正在震颤的猫洗澡可能引发癫痫发作 [3][6]。对于最近口服摄入的情况，可以给予活性炭和泻药 [1]。

**药物干预**侧重于震颤和癫痫发作控制。甲氧卡巴莫是治疗震颤的首选药物，剂量为50-150 mg/kg缓慢静脉注射，每天不超过330 mg/kg [3][4][6]。如果注射用甲氧卡巴莫不可用，可以将口服形式溶解在水中进行直肠给药 [3][6]。对于难治性癫痫发作，可能需要地西泮（0.2-2 mg/kg静脉注射至见效）或苯巴比妥（静脉注射至见效）[1][4]。对于严重病例，可能需要丙泊酚或吸入麻醉 [3][4]。

**支持性护理**包括静脉输液疗法以维持水分和保护严重震颤动物免受肌红蛋白分解产物的影响 [1][3]。体温调节至关重要，因为受影响的猫在洗澡后经常出现低体温，这可能加重震颤并降低氯菊酯代谢 [3][6]。**脂肪乳疗法**可能对涉及亲脂性拟除虫菊酯（如氯菊酯）的严重病例有益 [7]。

**监测要求**包括持续评估神经系统状态、体温和水分状况。轻度病例可能需要治疗24-48小时，大多数猫在适当护理下完全康复 [3][6]。

### Sources
[1] Plant-Derived Insecticide Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/plant-derived-insecticide-toxicosis-in-animals
[2] Pyrethrins & Pyrethroids: https://www.vin.com/vin_ce/abvp/html/pyrethrins___pyrethroids.html
[3] Common hazards for cats: https://www.dvm360.com/view/common-hazards-cats-proceedings
[4] Pyrethroid toxicity in felines: https://www.dvm360.com/view/pyrethroid-toxicity-felines-prognosis-good-guarded
[5] Journal Scan Methocarbamol as CRI: https://www.dvm360.com/view/journal-scan-methocarbamol-cri-pyrethroid-intoxication-look-three-cases
[6] Common toxicities in cats: https://www.dvm360.com/view/common-toxicities-cats-proceedings
[7] AAFP 2018 Decontamination of Toxicoses: https://www.dvm360.com/view/aafp-2018-decontamination-of-toxicoses-in-cats

## 预防措施

除虫菊酯和拟除虫菊酯中毒的预防主要依靠主人教育和正确的产品处理 [1]。宠物主人必须明白，标明用于犬的产品绝不能用于猫，因为猫特别容易受到氯菊酯毒性的影响 [1][2]。即使极小的接触也可能导致猫发生危及生命的中毒。

产品选择需要特别注意物种特异性配方。含有拟除虫菊酯的犬用跳蚤和蜱虫产品通过直接应用或在多宠物家庭中梳理接受过治疗的犬造成的二次接触，对猫构成重大风险 [2][3]。主人应在使用前核实产品标签上的物种限制。

环境控制措施包括将杀虫剂产品妥善存放在原容器中，远离儿童和宠物 [1]。应避免极端温度，因为它们可能导致产品变质或形成毒性更强的化合物。主人应严格按照所有标签说明操作，因为EPA监管农药的标签外使用是非法且可能危险的 [1]。

客户教育对于成功的预防计划至关重要。兽医应强调彻底阅读产品标签、理解使用率和识别中毒早期迹象的重要性 [1][4]。多宠物家庭需要特别注意通过仔细选择产品和安排应用时间来防止物种间的交叉污染。

### Sources
[1] Ectoparasiticides Used in Large Animals: https://www.merckvetmanual.com/pharmacology/ectoparasiticides/ectoparasiticides-used-in-large-animals
[2] Flea allergy dermatitis: What's new? (Proceedings): https://www.dvm360.com/view/flea-allergy-dermatitis-whats-new-proceedings
[3] Common toxicities in cats (Proceedings): https://www.dvm360.com/view/common-toxicities-cats-proceedings
[4] Plant-Derived Insecticide Toxicosis in Animals: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/plant-derived-insecticide-toxicosis-in-animals

## 鉴别诊断

在评估犬和猫的除虫菊酯和拟除虫菊酯中毒时，必须考虑几种情况。最重要的鉴别是有机磷和氨基甲酸酯毒性，其表现出相似的神经系统症状，包括流涎、震颤和癫痫发作 [1]。然而，这些可以通过胆碱酯酶酶活性测试来区分，在拟除虫菊酯病例中该酶活性保持正常，而在有机磷或氨基甲酸酯中毒中则会降低 [1][2]。

其他致震颤毒素需要鉴别，特别是来自霉变材料的青霉毒素A和洛克菲菌素，它们引起相似的肌肉震颤、僵硬和过度活跃 [3]。金属dehyde中毒也表现为震颤和癫痫发作，但通常发生在摄入蛞蝓诱饵后 [3]。

应考虑原发性神经系统疾病，如癫痫、中暑和神经病变 [3]。在涉及使用热源梳理的病例中，中暑可能特别相关，如在一头约克夏梗病例中所证明的，快速死亡伴有高热和出血表明是热诱导的DIC而非拟除虫菊酯毒性 [2]。

关键鉴别特征包括接触含拟除虫菊酯产品的病史、正常胆碱酯酶水平以及猫特有的耳朵抽动和爪子摇晃的临床表现 [1]。尝试测量生物样本中的拟除虫菊酯通常是徒劳的，因为血浆酯酶会迅速水解它们 [1]。

### Sources
[1] Merck Veterinary Manual Plant-Derived Insecticide Toxicosis in Animals - Toxicology - Merck Veterinary Manual: https://www.merckvetmanual.com/toxicology/insecticide-and-acaricide-organic-toxicity/plant-derived-insecticide-toxicosis-in-animals
[2] VIN Pyrethrins & Pyrethroids: https://www.vin.com/vin_ce/abvp/html/pyrethrins___pyrethroids.html
[3] Flora and fauna: Hazardous biotoxins for pets (Proceedings): https://www.dvm360.com/view/flora-and-fauna-hazardous-biotoxins-pets-proceedings

## 预后

猫除虫菊酯和拟除虫菊酯中毒的预后根据接触严重程度和治疗开始时间而有显著差异。通过早期、积极的干预，大多数猫可以获得良好的结果。

**早期治疗结果**
当及时提供适当的支持性护理时，预后通常良好 [1]。有轻微震颤的猫通常预后极好，但可能需要治疗24-48小时 [2]。大多数接受及时治疗的受影响猫通常在入院后24-96小时内病情好转到可以出院 [4]。

**严重程度依赖性预后**
接触相似量氯菊酯的个体猫之间临床症状的严重程度差异显著，有些仅出现轻微的肌肉颤搐，而其他则经历危及生命的症状 [2]。轻度受影响的猫通常预后良好，而重度受影响的猫需要更密集的管理，预后谨慎 [2]。猫拟除虫菊酯中毒的总体预后从良好到谨慎不等 [9]。

**并发症和不良预后指标**
持续的癫痫发作可能引发严重并发症，包括脑水肿和弥漫性血管内凝血（DIC），显著恶化预后 [4]。其他潜在并发症包括由于持续癫痫发作和高热引起的横纹肌溶解 [2]。即使进行积极的兽医护理，这些严重并发症的预后仍然谨慎。

**恢复时间框架**
轻度病例的治疗持续时间通常为24-48小时，尽管严重病例可能需要更长时间的强化护理。拟除虫菊酯没有直接的肝脏或肾脏毒性，这有助于当动物度过急性神经系统阶段后通常获得良好的长期结果。

### Sources

[1] Insecticides and other pesticides (Proceedings): https://www.dvm360.com/view/insecticides-and-other-pesticides-proceedings

[2] Common hazards for cats (Proceedings): https://www.dvm360.com/view/common-hazards-cats-proceedings

[4] Common toxicities in cats (Proceedings): https://www.dvm360.com/view/common-toxicities-cats-proceedings

[9] Pyrethroid toxicity in felines: prognosis good to guarded: https://www.dvm360.com/view/pyrethroid-toxicity-felines-prognosis-good-guarded