# 伴侣动物腹膜炎

腹膜炎是兽医学中最严重的腹部急症之一，影响犬和猫，可能危及生命。这种腹膜腔的炎症可由多种感染性和非感染性原因引起，从胃肠道穿孔后的细菌污染到独特的病毒形式——猫传染性腹膜炎（FIP）。腹膜炎的复杂性在于其多样化的表现形式——从需要立即手术干预的急性脓毒性病例到需要特殊抗病毒治疗的慢性形式如FIP。本综合报告探讨了伴侣动物腹膜炎的多方面性质，涵盖基本诊断方法包括细胞学分析和先进的PCR检测，从紧急稳定治疗到突破性抗病毒药物的治疗策略，以及影响生存结果的关键预后因素，根据根本原因不同，生存率从15%到88%不等。

## 疾病概述

腹膜炎被定义为犬猫腹膜腔浆膜的炎症[1]。这种复杂状况既可代表原发性疾病过程，也可作为影响伴侣动物其他病理状况的继发性并发症[1]。

腹膜炎可根据几个标准进行分类。按持续时间可分为急性或慢性，按性质可分为脓毒性或非脓毒性，按分布范围可分为局限性或弥漫性[1]。原发性腹膜炎比继发性腹膜炎少见，可能由感染性或特发性原因引起[1]。在感染性原发性腹膜炎中，病原体通过血源性途径扩散到腹膜腔，通常影响免疫功能低下的动物[1]。

继发性腹膜炎是当腹膜腔暴露于其他状况产生的感染性或非感染性因子时发展形成的[1]。这种形式通常是急性的，可发展为全身性疾病[1]。常见原因包括胃肠道穿孔、膀胱破裂和腹腔器官脓肿[1]。犬猫腹膜炎最常见的病史发现包括嗜睡、呕吐和厌食[2]。猫传染性腹膜炎（FIP）代表一种影响猫的特殊病毒形式，在总体人群中的报告患病率低于1%[3]。

### Sources

[1] Peritonitis in Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/peritonitis/peritonitis-in-animals

[2] Primary bacterial peritonitis in dogs and cats - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/234/7/javma.234.7.906.xml

[3] Feline infectious peritonitis (FIP): more complex than we thought (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-fip-more-complex-we-thought-proceedings-0

## 常见病原体

犬猫腹膜炎涉及多种传染性病原体，其中猫传染性腹膜炎（FIP）是最重要的病毒性原因。FIP由某些猫冠状病毒（FCoV）毒株引起，特定的突变将良性的肠道冠状病毒转化为毒力强的FIP病毒（FIPV）[1]。这种致病性转化发生在约5-12%感染猫冠状病毒的猫中[1]。

细菌病原体是小动物脓毒性腹膜炎的主要原因，其中大肠杆菌和肠球菌属是最常见的分离微生物[2]。这些细菌通常起源于胃肠道破裂，这是细菌性腹膜炎最常见的来源[2]。其他重要的细菌病原体包括凝固酶阳性金黄色葡萄球菌，它通常在肠道手术后引起术后并发症[3]。

继发性细菌感染常在免疫功能低下的动物中发展。猫白血病病毒（FeLV）感染抑制对FIP冠状病毒的免疫力，可能导致潜伏疾病的重新激活[4]。与肝功能障碍相关的病毒性疾病，包括FIP，当腹膜炎症涉及肝脏结构时会产生额外的并发症[5]。

细菌谱可能根据潜在病因而变化，在涉及肠穿孔或污染的病例中，典型的需氧和厌氧混合菌群[2]。通过适当的培养技术正确识别这些病原体对于靶向抗菌治疗和最佳患者结果至关重要。

### Sources
[1] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[2] Management of dogs and cats with septic peritonitis (Proceedings): https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[3] Enterotomy: Small intestinal anastomosis (Proceedings): https://www.dvm360.com/view/enterotomy-small-intestinal-anastomosis-proceedings
[4] Secondary Immunodeficiencies in Animals - Immune System: https://www.merckvetmanual.com/immune-system/immunologic-diseases/secondary-immunodeficiencies-in-animals
[5] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals

## 临床症状和体征

犬猫腹膜炎表现出不同的临床表现，其严重程度和进展各不相同。最常见的体征包括发热、腹痛、呕吐和进行性嗜睡[1]。犬通常发展为麻痹性肠梗阻，粪便排出减少、败血症、休克和血压降低[1]。

腹部膨隆是许多病例的标志性体征。体格检查常显示腹部膨隆并伴有液体波动，特别是在渗出性形式中[1]。随着病情进展，可能出现出血和液体积聚，猫表现出黏膜苍白和明显不适[1]。

在脓毒性腹膜炎病例中，动物表现出急性腹痛、脱水和休克体征（结合低血容量性和脓毒性/分布性成分）[3]。常见的就诊主诉包括呕吐、嗜睡、厌食、腹泻和虚脱[3]。

猫传染性腹膜炎（FIP）表现出独特的模式，有两种主要形式。渗出性"湿"形式引起腹水，呈现"啤酒肚"外观和胸腔积液，导致呼吸困难和心音减弱[2]。非渗出性"干"形式产生神经体征包括共济失调、癫痫和精神状态异常，以及眼部异常如前葡萄膜炎和脉络视网膜炎[2]。

品种特异性模式显示纯种猫，特别是阿比西尼亚猫、孟加拉猫、缅甸猫、喜马拉雅猫、布偶猫和雷克斯猫品种，对FIP表现出更高的易感性[2]。2岁以下的年轻猫和雄性猫似乎更容易发展为临床疾病[2]。

### Sources
[1] Peritonitis in Dogs: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/peritonitis-in-dogs
[2] Feline Infectious Peritonitis - Infectious Diseases - Merck Veterinary Manual: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[3] Management of dogs and cats with septic peritonitis (Proceedings): https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings

## 诊断方法

体格检查在腹膜炎病例中揭示重要发现，包括急性腹痛、脱水、发热和休克体征[1]。应仔细检查腹部是否有膨隆、液体波动或可触及的肿块，这些可能表明潜在原因。

腹腔液样本的细胞学评估是犬猫脓毒性腹膜炎急性诊断的首选诊断测试，准确率为57-87%[1]。样本可通过腹腔穿刺、四象限腹腔穿刺或诊断性腹腔灌洗（DPL）收集，DPL在检测显著腹腔疾病方面更优越[1]。

实验室检查包括腹腔液的生化分析，特别是葡萄糖测定。血液与腹腔液葡萄糖梯度>20mg/dL在犬中对脓毒性腹膜炎诊断的敏感性和特异性均为100%，在猫中敏感性为86%，特异性为100%[1]。样本应保存用于需氧和厌氧培养，早期革兰氏染色程序有助于指导经验性抗生素治疗[1]。

对于猫传染性腹膜炎（FIP），渗出液分析显示特征性发现：黄色、粘稠液体，蛋白质浓度高（>35 g/L），白蛋白：球蛋白比值<0.4，细胞计数低（<5×10⁹细胞/L）[3]。Rivalta试验作为有用的筛查工具——阳性结果提示FIP，而阴性结果强烈排除该病[3]。

PCR检测可在各种样本中检测FCoV RNA，包括血液、渗出液、脑脊液和房水[3,6]。渗出液的实时PCR检测似乎比血液检测更可靠，用于区分FIP与其他腹水原因[8]。

影像技术包括腹部X线和超声检查，有助于识别游离液体、器官异常并指导样本收集[1,2]。诊断性影像可能显示液体造成的毛玻璃样外观或识别污染的潜在原因。

### Sources
[1] Management of dogs and cats with septic peritonitis: https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[2] Specific surgical emergencies: https://www.dvm360.com/view/specific-surgical-emergencies-proceedings
[3] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[6] Infectious neurologic diseases of puppies and kittens: https://www.dvm360.com/view/infectious-neurologic-diseases-puppies-and-kittens-proceedings
[8] Feline infectious peritonitis: Strategies for diagnosing and treating this deadly disease in young cats: https://www.dvm360.com/view/feline-infectious-peritonitis-strategies-diagnosing-and-treating-deadly-disease-young-cats

## 治疗选择

犬猫腹膜炎的成功治疗需要及时的医疗稳定、手术干预和全面的术后护理。医疗管理侧重于积极的静脉输液治疗（犬高达90ml/kg/hr，猫高达60ml/kg/hr）、广谱抗生素治疗和支持性护理[1]。经验性抗生素组合包括氨苄西林/氨基糖苷类/甲硝唑或氨苄西林/恩诺沙星/甲硝唑，针对常见分离株如大肠杆菌和肠球菌属[1]。

手术干预旨在消除污染源，用温热无菌盐水进行彻底的腹腔灌洗，并建立适当的引流[1]。引流选择包括用于控制性污染的封闭式负压引流或用于持续性污染严重病例的开放式腹腔引流[1]。封闭式负压引流利用负压储液器，适用于大多数严重程度，而开放式引流需要密集的术后管理但提供更优越的引流能力[1]。

对于猫传染性腹膜炎（FIP），抗病毒治疗代表突破性治疗选择。核苷类似物GS-441524，以2-15mg/kg每日剂量给药至少12周，显示出超过80%的生存率[2][6]。核苷类似物molnupiravir作为有效的挽救治疗，以12-15mg/kg每日两次剂量用于治疗耐药性猫[2][6]。这些抗病毒药物通过延迟链终止机制抑制病毒RNA合成发挥作用[6]。

### Sources
[1] Management of dogs and cats with septic peritonitis: https://www.dvm360.com/view/management-dogs-and-cats-with-septic-peritonitis-proceedings
[2] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis

## 预防措施

猫和犬腹膜炎的预防主要集中在控制猫传染性腹膜炎（FIP），这是伴侣动物中最显著的病毒性腹膜炎形式。当前的预防策略具有挑战性，因为FIP的发病机制复杂，它是通过普通猫冠状病毒（FCoV）的突变发展而来的[1][2]。

**疫苗接种限制**
存在一种鼻内FIP疫苗，但效果存疑，一般不被兽医组织推荐[2][3]。该疫苗的局限性包括对已接触冠状病毒的猫效果不佳，以及无法预防导致FIP发展的病毒突变[2]。多猫环境中的大多数猫在推荐的16周疫苗接种年龄前已经感染FCoV[1]。

**环境控制措施**
有效的预防需要严格的环境管理，特别是在繁殖猫舍和收容所中[1][4]。关键策略包括维持小组规模（少于5-6只猫），提供足够数量的猫砂盒并频繁清洁，以及在4-6周实施早期断奶方案并严格隔离[4][8]。这些措施通过主要的粪口途径减少病毒传播[5]。

**细菌性腹膜炎预防**
对于细菌性腹膜炎，预防侧重于最小化脓毒性腹膜炎的风险因素[9]。在胃肠道手术过程中采用正确的手术技术以及及时治疗可能导致腹膜污染的状况至关重要[10]。在怀疑脓毒性腹膜炎的病例中，一旦考虑诊断就应尽早开始广谱抗生素治疗[10]。

### Sources
[1] Feline infectious peritonitis (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-proceedings-0
[2] Non-core vaccines: FIP, canine corona, lyme, and Bordetella (Proceedings): https://www.dvm360.com/view/non-core-vaccines-fip-canine-corona-lyme-and-bordetella-proceedings
[3] Nonprofit shelter collaborates on lifesaving FIP treatment: https://www.dvm360.com/view/nonprofit-shelter-collaborates-on-lifesaving-fip-treatment
[4] Vaccine aims to nip FIP in the bud: https://www.dvm360.com/view/vaccine-aims-to-nip-fip-in-the-bud
[5] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[6] An update on feline infectious peritonitis: https://www.dvm360.com/view/update-feline-infectious-peritonitis
[7] Feline infectious peritonitis: what's new? (Proceedings): https://www.dvm360.com/view/feline-infectious-peritonitis-whats-new-proceedings
[8] Feline infectious peritonitis: Strategies for diagnosing and treating this deadly disease in young cats: https://www.dvm360.com/view/feline-infectious-peritonitis-strategies-diagnosing-and-treating-deadly-disease-young-cats
[9] Peritonitis in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/peritonitis-in-dogs
[10] Management of septic peritonitis: more than surgery (Proceedings): https://www.dvm360.com/view/management-septic-peritonitis-more-surgery-proceedings

根据提供的来源材料，我无法撰写本节内容，因为来源不包含关于伴侣动物腹膜炎鉴别诊断的兽医特定信息。来源主要包含：

1. 没有医疗内容的一般兽医诊所网站
2. 一个优秀的兽医来源（PMC文章），我已在现有部分中使用
3. 不适用于兽医实践的人类医学腹膜炎来源

现有部分内容似乎已充分发展并引用了适当的兽医来源。为了适当扩展或修订本节，我需要额外的兽医来源，这些来源专门讨论：

- 犬猫腹膜炎的鉴别诊断
- 疾病之间的区分因素
- 兽医诊断算法
- 物种特异性考虑因素

当前部分已经使用适当的兽医文献涵盖了关键的鉴别诊断和区分因素。没有额外的相关兽医来源，我无法在保持所需兽医重点和引用标准的同时对本节做出有意义的贡献。

## 预后

犬猫腹膜炎的预后谨慎至不良，死亡率根据根本原因和严重程度而有显著差异。默克兽医手册报告犬腹膜炎死亡率为50%至70%[1]。对于围手术期脓毒性腹膜炎，犬的死亡率范围为37%至85%[2]。

几个因素影响预后和恢复结果。早期诊断和积极治疗是关键的预后指标。根本原因显著影响生存率——一项犬猫研究显示创伤性胆汁性腹膜炎的总体生存率为88.2%[3]。患者因素包括年龄、并发疾病和免疫状态也影响结果。

治疗反应在不同病例间差异很大。患有渗出性FIP（一种特殊类型的病毒性腹膜炎）的猫未经治疗通常只能存活几天到几周，而非渗出性形式可能允许存活几周到几个月[4]。然而，随着新的抗病毒治疗，FIP预后已显著改善，高达75%的接受治疗的猫能够存活6个月的治疗期[5]。

对于血腹 specifically，器官系统功能障碍与不良结果显著相关[6]。与较短生存期相关的术前因素包括虚弱或嗜睡、血小板减少、BUN浓度升高和PTT延长[7]。恶化预后的并发症包括休克、败血症、多器官衰竭和继发性细菌感染。

### Sources

[1] Peritonitis in Dogs: https://www.merckvetmanual.com/dog-owners/disorders-affecting-multiple-body-systems-of-dogs/peritonitis-in-dogs
[2] Identification of risk factors for septic peritonitis: https://avmajournals.avma.org/view/journals/javma/238/4/javma.238.4.486.xml
[3] Diagnostic and surgical treatment for traumatic bile peritonitis: https://avmajournals.avma.org/view/journals/javma/262/7/javma.24.01.0049.xml
[4] Feline Infectious Peritonitis: https://www.merckvetmanual.com/infectious-diseases/feline-infectious-peritonitis/feline-infectious-peritonitis
[5] Nonprofit shelter collaborates on lifesaving FIP treatment: https://www.dvm360.com/view/nonprofit-shelter-collaborates-on-lifesaving-fip-treatment
[6] Association between outcome and organ system dysfunction: https://avmajournals.avma.org/view/journals/javma/236/1/javma.236.1.83.xml
[7] Evaluation of prognostic factors in the surgical treatment of: https://avmajournals.avma.org/view/journals/javma/232/1/javma.232.1.77.xml