# 伴侣动物二尖瓣变性

二尖瓣变性是犬类最常见的心脏疾病，占所有犬类心脏病病例的75%，并表现出明显的年龄相关进展，从中年犬的10%到老年患者的30%以上。这种退行性疾病以瓣叶和支持结构的黏液样变化为特征，对管理无症状和有症状患者的兽医临床医生提出了重大的临床挑战。该报告探讨了指导现代兽医心脏病学实践的病理生理学、品种易感性、诊断方法和基于证据的治疗方案，强调了早期检测和分期适当干预在优化患者结果中的关键重要性。

## 摘要

二尖瓣变性是一种复杂的、进行性的心脏疾病，需要在多个临床维度进行全面理解。该疾病主要影响小型犬，具有明显的品种易感性，特别是骑士查理王小猎犬表现出80%的患病率。临床表现遵循可预测的分期模式，从无症状杂音进展到充血性心力衰竭，具有独特的体格检查结果和诊断挑战。

现代管理强调分期特异性治疗方案，匹莫苯丹在B2期患者中显示出显著疗效，可将心力衰竭发作延迟15个月。包含匹莫苯丹、利尿剂、ACE抑制剂和螺内酯的四联疗法为晚期病例提供了最佳结果。鉴别诊断需要通过全面的心脏评估，仔细区分肥厚型心肌病、扩张型心肌病和先天性瓣膜发育不良。

| 疾病分期 | 关键特征 | 治疗方法 | 预后 |
|---------------|--------------|-------------------|-----------|
| B1期 | 无症状杂音，无心肿大 | 仅监测 | 优秀 |
| B2期 | 无症状杂音，左心房扩大 | 匹莫苯丹单药治疗 | 心力衰竭延迟15个月 |
| C/D期 | 充血性心力衰竭体征 | 四联疗法 | 可变，可能>1年 |

兽医临床医生必须通过常规心脏听诊优先进行早期检测，实施基于证据的分期方案，并保持对疾病进展的警惕性监测，以优化患者护理和与主人的沟通。

## 疾病概述与流行病学

二尖瓣变性（MVD），也称为黏液样二尖瓣病（MMVD），是一种以二尖瓣叶和支持结构增厚和结构变化为特征的退行性疾病[1]。该疾病涉及瓣膜组织中粘多糖的积累，破坏细胞外基质并削弱瓣膜的结构完整性[8]。

MMVD是犬类最常见的心脏疾病，约占所有犬类心脏病的75%[1,8]。年龄相关患病率显示出明显的模式：大约10%的5-8岁犬受到影响，20-25%的9-12岁犬受到影响，30-35%的13岁以上犬受到影响[8]。该疾病主要影响小型犬，骑士查理王小猎犬显示出最高的品种易感性，影响该品种近80%的犬[7]。

在一些研究中，雄性似乎具有更高的易感性，尽管确切的遗传模式仍不清楚[2]。牛头梗也显示出对二尖瓣发育不良的品种特异性易感性，这是一种先天性变异，可导致幼犬左心衰竭[1]。

病理进展涉及瓣叶的黏液样变性，伴有糖胺聚糖浸润、胶原蛋白和弹性蛋白破坏以及缺乏炎症成分[8]。这种退行性过程导致瓣膜脱垂和反流，最终随着代偿机制的发展导致左心房和心室扩张。

### Sources
[1] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[2] Feline cardiovascular diseases: parts 1, 2, 3 (Proceedings): https://www.dvm360.com/view/feline-cardiovascular-diseases-parts-1-2-3-proceedings
[7] Gene therapy demonstrates benefit to dogs with myxomatous mitral valve disease: https://www.dvm360.com/view/gene-therapy-demonstrates-benefit-to-dogs-with-myxomatous-mitral-valve-disease
[8] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals

## 临床症状、体征和诊断方法

二尖瓣变性表现出多样的临床表现，随着疾病通过既定分期系统进展而发展。早期检测依赖于彻底的心脏听诊和适当的诊断检查。

**临床表现和体格检查结果**

最常见的初始发现是收缩期心脏杂音，通常在左心尖处最响亮[1]。最初，在B1期（无轻度心肿大）和B2期（存在轻度心肿大）疾病阶段，犬保持无症状[1]。随着疾病进展，出现临床症状，包括运动不耐受、咳嗽、呼吸困难和晕厥[1][2]。

体格检查显示平台型收缩期杂音掩盖第二心音，将其与喷射性杂音区分开来[5]。由于肺水肿引起的呼吸急促可能被犬的喘气所掩盖，因此睡眠呼吸率监测很有价值——呼吸率>30次/分钟表示异常发现[2]。

**品种特异性模式**

小型犬显示出更高的易感性，骑士查理王小猎犬、吉娃娃、惠比特犬、贵宾犬、西施犬、约克夏梗和边境牧羊犬风险较高[1]。患有左心尖收缩期杂音的大型犬需要更广泛的诊断评估，因为疾病患病率模式不同[5]。

**诊断方法**

胸部X线摄影作为一线影像学检查，用于评估心脏大小和检测心力衰竭[1]。超声心动图提供明确的诊断和分期，三尖瓣反流速度测量使肺压评估成为可能[1][3]。

心脏生物标志物，包括NT-proBNP和心肌肌钙蛋白I，提供额外的诊断价值。NT-proBNP浓度与疾病严重程度成比例增加，并有助于区分心脏和呼吸原因引起的呼吸困难[2][4]。然而，这些生物标志物不应单独使用，而应与其他诊断方式结合使用[2]。

**分期和监测**

美国兽医内科学会分期系统指导诊断决策和治疗建议[1]。通过睡眠呼吸率评估和定期X线摄影评估进行定期监测，有助于追踪疾病进展[1]。

### Sources
[1] When Should Mitral Valve Disease in Dogs Be Treated?: https://www.dvm360.com/view/when-should-mitralvalve-disease-in-dogs-be-treated
[2] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats
[3] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment
[4] Lecture Link: The NT-proBNP assay: A portent of heart health: https://www.dvm360.com/view/lecture-link-nt-probnp-assay-portent-heart-health
[5] Management of incidentally detected heart murmurs in dogs: https://avmajournals.avma.org/view/journals/javma/246/10/javma.246.10.1076.xml

## 治疗选择和管理策略

二尖瓣变性的治疗采用分期特异性方法，对晚期病例使用四联疗法。主要药物干预包括匹莫苯丹（0.25-0.3 mg/kg口服，每12小时一次），它作为一种正性肌力血管扩张剂，提供正性肌力和血管扩张作用[1]。匹莫苯丹已被证明可以改善生活质量，延迟临床前犬充血性心力衰竭的发作，并延长心力衰竭犬的生存期[1]。

袢利尿剂，特别是呋塞米（急性治疗2-4 mg/kg静脉注射，长期管理1-6 mg/kg口服每8-12小时一次），作为液体清除的主要疗法[1]。ACE抑制剂如依那普利（0.25-0.5 mg/kg口服每12-24小时一次）或贝那普利可对抗血管收缩并保护心血管结构免受肾素-血管紧张素-醛固酮系统激活的影响[2]。

当前指南建议对C期和D期采用四联疗法，加入螺内酯（1-2 mg/kg口服每12小时一次）作为盐皮质激素受体拮抗剂，以提供更广泛的RAAS抑制[3]。对于B2期患者，单独使用匹莫苯丹可将心力衰竭发作延迟约15个月，相比安慰剂[4]。

晚期病例可能需要托拉塞米，当呋塞米无效时，以及包括氧疗、硝普钠或硝酸甘油外用在内的紧急干预措施[4]。二尖瓣修复手术虽然可用性有限，但对合适的候选者提供了良好的预后[6]。饮食钠限制以及定期监测肾功能和电解质仍然是全面管理的重要组成部分[1]。

### Sources
[1] Principles of Therapy of Cardiovascular Disease in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/principles-of-therapy-of-cardiovascular-disease-in-animals
[2] Tool Kit Essentials for Canine Congestive Heart Failure: https://www.dvm360.com/view/tool-kit-essentials-for-canine-congestive-heart-failure
[3] Compliance for canine mitral valve disease therapy just got easier: https://www.dvm360.com/view/compliance-for-canine-mitral-valve-disease-therapy-just-got-easier
[4] New standards for treating heart failure (Proceedings): https://www.dvm360.com/view/new-standards-treating-heart-failure-proceedings
[5] Tool Kit Essentials for Canine Congestive Heart Failure: https://www.dvm360.com/view/tool-kit-essentials-for-canine-congestive-heart-failure/1000
[6] Repair Surgery Among Latest Treatments for Mitral Valve Disease: https://www.dvm360.com/view/repair-surgery-among-latest-treatments-for-mitral-valve-disease

## 鉴别诊断和预后

### 鉴别诊断

二尖瓣变性必须与几种表现出相似临床症状的疾病进行鉴别。肥厚型心肌病（HCM）是最常见的猫类心脏病，表现为左心房扩大和心脏杂音，但特征是原发性心室壁增厚而非瓣叶变性[1]。扩张型心肌病（DCM）引起收缩期心脏杂音和左心衰竭，但表现为心室扩张伴收缩力下降，而早期二尖瓣变性通常表现为收缩力保留[2]。

先天性二尖瓣发育不良在左心尖处产生全收缩期杂音伴心前区震颤，但发生在具有畸形瓣膜成分的幼年动物中，而非老年患者的退行性变化[3]。只有约30%患有退行性二尖瓣反流的犬会发展为充血性心力衰竭，因为具有高效的代偿机制，而发育不良的瓣膜通常更早引起更严重的临床症状[4]。

### 预后

预后因疾病分期和物种而异。患有B2期二尖瓣变性（左心房扩大但无临床症状）的犬从早期匹莫苯丹治疗中获益显著，比未治疗病例多获得15个月的无症状生命[5]。然而，一旦发生心力衰竭，生存时间差异很大，不应提供确切的估计[4]。

患有退行性瓣膜病的犬在适当治疗下可以存活一年以上，尽管一些受影响的犬已成功治疗超过两年[4]。患有退行性瓣膜病的猫如果早期诊断，在适当治疗下可以存活数年[6]。预后因素包括二尖瓣反流的严重程度、左心房扩大的程度、是否存在心律失常以及对药物治疗的反应。

### Sources

[1] Myxomatous Atrioventricular Valve Degeneration in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/myxomatous-atrioventricular-valve-degeneration-in-dogs-and-cats
[2] Mitral Valve Dysplasia in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/mitral-valve-dysplasia-in-animals
[3] When Should Mitral Valve Disease in Dogs Be Treated?: https://www.dvm360.com/view/when-should-mitralvalve-disease-in-dogs-be-treated
[4] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs
[5] Hypertrophic Cardiomyopathy in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/cardiomyopathy-in-dogs-and-cats/hypertrophic-cardiomyopathy-in-dogs-and-cats
[6] Acquired Heart and Blood Vessel Disorders in Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/acquired-heart-and-blood-vessel-disorders-in-cats