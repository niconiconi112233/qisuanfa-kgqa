# 伴侣动物鼻泪管闭锁

鼻泪管闭锁是一种影响犬猫的重要先天性眼科疾病，其特征是连接眼部与鼻腔的泪液引流系统发育失败。这种胚胎发育畸形导致管道闭锁或狭窄，从而引起慢性泪溢和继发性并发症，可能显著影响患犬的舒适度和生活质量。

本综合报告探讨了小动物临床实践中鼻泪管闭锁的临床表现、诊断方法和治疗策略。主要内容包括波斯猫和喜马拉雅猫的品种易感性、CT泪囊鼻腔造影等先进影像技术、包括内镜支架置入术在内的微创手术干预，以及对患病动物的长期管理考虑因素。

## 摘要

鼻泪管闭锁表现为一种复杂的先天性疾病，需要系统性的诊断评估和个体化的治疗方法。荧光素染料试验作为主要筛查方法，而CT泪囊鼻腔造影等先进影像技术则提供明确的解剖学评估。临床表现因物种而异，与犬相比，猫表现出较少的患犬不适，而波斯品种则显示出特殊的易感性。

治疗成功取决于早期干预和适当的手术技术选择。利用内镜和临时支架的现代微创方法已显示出良好的效果，加州大学戴维斯分校报告了15只犬、2只猫和1匹马的成功治疗结果。预后因解剖位置和治疗时机而有显著差异，早期进行的泪点闭锁手术矫正通常能获得良好效果。

| 治疗方法 | 成功率 | 恢复时间 | 长期管理 |
|---------|--------|----------|----------|
| 保守冲洗 | 不定 | 数周 | 持续监测 |
| 手术重建 | 早期则良好 | 2个月以上 | 最小化 |
| 内镜支架置入 | 有前景 | 2个月 | 需要随访 |

兽医临床医生应优先考虑早期识别和干预，以优化患病伴侣动物的治疗结果并预防继发性并发症。

## 疾病概述

鼻泪管闭锁是犬猫的一种先天性异常，其特征是鼻泪管系统正常发育或通畅性失败[2]。这种情况代表一种胚胎发育畸形，即在胎儿发育期间，连接眼部与鼻腔的管道未能正常管道化，导致管道闭锁或狭窄。

正常的鼻泪管将泪液从结膜囊通过位于内眦的泪点排出，经过骨性管道到达鼻腔[2]。在闭锁病例中，这条引流途径被阻塞或缺失，导致泪溢（泪液过多）和继发性并发症。

伴侣动物鼻泪管闭锁的特定流行病学数据在兽医文献中有限[2]。这种情况似乎不常见，但由于幼年动物表现轻微可能被漏诊。泪点闭锁是幼犬泪溢的罕见原因，而在马驹和幼年骆驼科动物中，鼻泪管鼻腔端闭锁是早期泪溢的常见原因[2]。波斯猫和喜马拉雅猫品种对慢性鼻泪管阻塞表现出易感性[4]。

病理生理学涉及正常泪液引流的阻塞，导致泪液溢出到面部皮肤，可能继发细菌感染，以及眼周组织的慢性刺激[2]。

### Sources
[1] Nasolacrimal duct obstruction prevalence is 0.3% among alpacas evaluated with ophthalmic disease: https://avmajournals.avma.org/view/journals/javma/262/7/javma.23.10.0579.xml
[2] Nasolacrimal and Lacrimal Apparatus in Animals - Eye Diseases and Disorders - Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[3] Disorders of the Nasal Cavity and Tear Ducts in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs
[4] Disorders of the Nasal Cavity and Tear Ducts in Cats - Cat Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-nasal-cavity-and-tear-ducts-in-cats

## 临床症状和体征

鼻泪管闭锁的临床表现在先天性和获得性形式之间有所不同，先天性病例的症状通常在生命早期显现。

**主要临床症状**
患有鼻泪管闭锁的犬表现为持续性泪溢（泪液过多），在内眦区域形成特征性的泪痕[1]。临床症状可包括眼睑痉挛、黏液性至黏液脓性眼部分泌物、结膜充血和不同程度的角膜刺激[1]。根据继发性细菌定植情况，分泌物可能从浆液性进展为黏液脓性。

**发病年龄和进展**
先天性病例通常在4至6个月大时出现临床症状，此时病情可能是单侧或双侧的[2]。如果不治疗，病情会逐渐进展，慢性病例会出现更严重的角膜变化和持续性分泌物。

**物种特异性差异**
在猫中，鼻泪管偶尔会发生阻塞，导致泪液慢性溢出（泪溢），在波斯猫和喜马拉雅猫中更为常见[3]。与犬不同，猫很少因这种情况表现出不适，外观通常是主要关注点[3]。据报道，眼睑泪点闭锁是犬泪点闭锁的最常见部位[1]。泪点闭锁是幼年动物流泪的罕见原因[4]。

**继发性并发症**
慢性病例可能在鼻眦下方出现轻度结膜肿胀，由于泪液滞留可能发生继发性细菌感染。持续的潮湿为眼周区域的皮炎创造了有利条件，特别是在面部皱褶明显的品种中。晚期病例可能导致难以治疗的结膜炎。

### Sources
[1] Lacrimal disease can make you cry: https://www.dvm360.com/view/lacrimal-disease-can-make-you-cry-what-do-proceedings
[2] Cranial nerve disorders in dogs: https://www.dvm360.com/view/cranial-nerve-disorders-dogs-proceedings
[3] Disorders of the Nasal Cavity and Tear Ducts in Cats: https://www.merckvetmanual.com/cat-owners/eye-disorders-of-cats/disorders-of-the-nasal-cavity-and-tear-ducts-in-cats
[4] Disorders of the Nasal Cavity and Tear Ducts in Dogs: https://www.merckvetmanual.com/dog-owners/eye-disorders-of-dogs/disorders-of-the-nasal-cavity-and-tear-ducts-in-dogs

## 诊断方法

鼻泪管闭锁的诊断需要系统的方法，结合临床检查和专业诊断技术。荧光素染料试验作为主要筛查方法，将荧光素局部应用于结膜囊，5-10分钟内鼻孔未出现染料表明导管阻塞或闭锁[1][2]。该试验也称为琼斯试验，当角膜染色后荧光素染色在鼻孔中可见时，确认鼻泪管系统通畅[3]。

先进的影像学技术提供明确诊断和解剖学评估。泪囊鼻腔造影包括将造影剂注入鼻泪管系统，然后进行放射成像以观察导管通畅性并识别解剖异常[1]。计算机断层扫描泪囊鼻腔造影（CT-DCG）提供优越的软组织对比度和横断面成像能力，能够精确定位闭锁段[1][2][4]。CT对比泪囊鼻腔造影对鼻泪管装置的全面评估特别有价值[4]。

标准放射线摄影可能显示继发性变化，如泪囊炎或面部骨骼异常，尽管它对鼻泪管系统本身的可视化有限[1]。超声检查可用于评估导管系统周围相关的软组织变化[2]。

临床检查应包括评估泪液溢出（泪溢）、结膜刺激和潜在的继发性细菌感染。鉴别诊断必须排除泪溢的其他原因，包括睑内翻、倒睫、干性角膜结膜炎以及由创伤或炎症引起的获得性鼻泪管阻塞。

### Sources

[1] Merck Veterinary Manual Diagnostic Imaging: https://www.merckvetmanual.com/special-pet-topics/diagnostic-tests-and-imaging/diagnostic-imaging
[2] Overview of Diagnostic Imaging of Animals: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-imaging/overview-of-diagnostic-imaging-of-animals
[3] Physical Examination of the Eye in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/physical-examination-of-the-eye-in-animals
[4] A multidisciplinary, minimally invasive approach combining lacrimoscopy and fluoroscopically guided stenting: https://avmajournals.avma.org/downloadpdf/view/journals/javma/252/12/javma.252.12.1527.pdf

## 治疗选择

鼻泪管闭锁的治疗方法因阻塞的严重程度和解剖位置而异。保守治疗最初包括鼻泪管冲洗以建立通畅性，结合局部抗菌剂和抗炎剂[1]。然而，当存在先天性闭锁或不可逆阻塞时，手术干预变得必要。

**手术程序**包括泪点闭锁的泪点重建和结膜鼻腔造口术以创建替代引流途径。犬、马驹和幼年骆驼科动物的治疗涉及手术打开阻塞的开口，并通过在愈合期间数周的临时导管插入来维持通畅性[1]。现代微创方法利用内镜、CT和荧光镜检查来识别阻塞并放置临时支架[6]。这些支架保留约两个月，以允许导管在开放位置充分愈合。

**术后护理**需要导管中暂时插入管子（聚乙烯或硅胶）或单丝尼龙缝线以维持通畅性[1]。在恢复期间给予局部抗菌剂和可能的全身抗生素。加州大学戴维斯分校已使用这种开创性的支架程序成功治疗了15只犬、2只猫和1匹马，这为传统手术方法提供了一种微创替代方案[6]。

**物种特异性考虑**很重要，因为猫由于其独特的鼻泪管解剖结构需要专门的方法，而马和骆驼科动物通常表现为远端鼻泪点闭锁，需要不同的手术技术。

### Sources
[1] Nasolacrimal and Lacrimal Apparatus in Animals: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] Dry-eyed at last: Nasolacrimal stenting procedure corrects a cat's tear duct obstruction: https://www.dvm360.com/view/dry-eyed-last-nasolacrimal-stenting-procedure-corrects-cats-tear-duct-obstruction

## 预防措施和预后

**预防措施：**
由于鼻泪管闭锁主要是先天性发育异常，特定的预防策略有限[1]。然而，可以通过适当的长期管理预防继发性并发症。对于进行手术重建的病例，在愈合期间通过数周的导管插入维持导管通畅性至关重要[1]。在成功进行樱桃眼修复的犬中，术后应监测泪液产生，因为即使正确保留腺体，20%的这些患者未来可能发展为干性角膜结膜炎（KCS）[1]。

预防继发性皮炎在管理慢性泪溢中至关重要。定期清洁受影响区域并保持面部毛发短剪可以减少细菌过度生长并最小化气味[2]。环境调整包括避免可能加重泪膜不稳定性的风况和通风口[2]。

**预后：**
鼻泪管闭锁的预后因解剖位置和治疗方法而有显著差异。患有泪点闭锁的犬，早期手术矫正通常有良好的预后[1]。对于需要结膜鼻腔造口术或结膜口腔造口术的病例，需要使用人工泪液长期管理并监测复发[1]。

**长期管理：**
当鼻泪管装置受到不可逆损伤时，可能需要手术创建新的引流途径以维持泪液引流[1]。生活质量考虑包括管理慢性泪溢和通过一致的局部护理和主人教育了解终身管理要求来预防继发性皮肤并发症[2]。

### Sources
[1] Merck Veterinary Manual: https://www.merckvetmanual.com/eye-diseases-and-disorders/ophthalmology/nasolacrimal-and-lacrimal-apparatus-in-animals
[2] DVM360: https://www.dvm360.com/view/management-tear-film-disorders-dog-and-cat-proceedings-0