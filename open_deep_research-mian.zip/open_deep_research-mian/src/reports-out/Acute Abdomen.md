# 伴侣动物的急性腹痛

急性腹痛是小动物兽医学中最具挑战性的急症表现之一，需要快速评估和干预以防止危及生命的并发症。该综合征涵盖多种潜在病因，从大型犬的胃扩张-扭转综合征到传染性腹膜炎和胃肠道梗阻。该病症的复杂性在于其表现为“伟大的模仿者”，相似的临床体征可能掩盖预后截然不同的潜在病理。本报告探讨了犬猫急性腹痛诊断和管理的综合方法，涵盖了影响急诊兽医实践中患者结果的基本病原体、诊断策略、治疗方案和关键预后因素。

## 摘要

伴侣动物的急性腹痛需要结合临床评估、高级诊断和及时干预进行系统评估。该病症在各年龄段均有表现，病因各异——从大肠杆菌相关的子宫蓄脓到病毒性肝炎，以及主要影响大型深胸犬种的胃扩张-扭转综合征。诊断成功很大程度上依赖于影像学检查方式，对于胰腺炎等疾病，超声检查的灵敏度（68%）优于X线检查（24%）。

治疗以积极的液体复苏、适当的镇痛以及通常的剖腹探查术为中心，以进行明确诊断和干预。关键预后指标包括血乳酸水平，当<6 mmol/L时存活率为99%，而升高时为58%。胃扩张-扭转综合征尽管经过积极治疗，仍有25-30%的死亡率，而异物梗阻若及时干预则预后极佳。

| 疾病 | 关键诊断发现 | 预后 | 关键因素 |
|-----------|----------------------|-----------|-----------------|
| 胃扩张-扭转综合征 | 干呕无物、腹胀 | 70-75%存活率 | 快速减压 |
| 脓毒性腹膜炎 | 葡萄糖差值>20 mg/dL | 不定 | 乳酸水平 |
| 异物 | 影像学确认 | 及时则极佳 | 手术时间 |

成功管理急性腹痛取决于快速识别、系统诊断方法，并理解早期干预能显著改善所有潜在病因的患者结果。

## 疾病概述和常见病原体

急性腹痛表现为急性发作的腹痛，需要及时诊断和立即干预以防止患者病情恶化[1]。这种被称为“伟大的模仿者”的病症，通常在伴侣动物中表现为严重的胃肠道症状、虚脱和腹痛[1]。该综合征涵盖广泛的潜在病因，从创伤到感染性和肿瘤性原因[2]。

急性腹痛是兽医急诊医学中常见的主诉，影响各年龄段的犬和猫[2]。虽然因兽医护理而就诊的伴侣动物中具有临床意义的腹痛发病率未知，但它与一系列疾病相关[2]。幼年动物可能表现为病毒性疾病、肠套叠或异物摄入，而中老年动物则更容易患代谢性疾病如阿狄森氏病或肿瘤性疾病[1]。

急诊临床医师的主要作用是确定患者是否需要手术干预[1]。常见致病原因包括子宫蓄脓和前列腺感染中的大肠杆菌[1]，食用生肉饮食动物中的沙门氏菌[1]，以及各种病毒病原体，包括传染性犬肝炎（犬腺病毒1型）和猫传染性腹膜炎病毒[3]。细菌性病因包括由问号钩端螺旋体血清型引起的钩端螺旋体病，引起泰泽氏病的毛样芽胞梭菌，以及导致化脓性肉芽肿性肝炎的各种分枝杆菌属[3]。

此外，全身性真菌病、包括弓形虫病和利什曼病在内的原生动物感染也导致急性腹痛表现[3]。最近发现的病毒因子，如与猫肝细胞癌相关的家猫嗜肝DNA病毒，也导致该综合征[3]。

### Sources

[1] Approach to the acute abdomen (Proceedings): https://www.dvm360.com/view/approach-acute-abdomen-proceedings
[2] Critical care analgesia: Abdominal pain (Proceedings): https://www.dvm360.com/view/critical-care-analgesia-abdominal-pain-proceedings
[3] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals

## 临床症状和诊断方法

患有急性腹痛的动物表现出复杂的临床症状，需要仔细评估和系统诊断方法。临床识别通常依赖于行为变化和体格检查结果，而非特定的特殊病征[1]。

**典型临床症状**

最常见的表现包括严重腹痛、呕吐和虚脱[2]。患有胃扩张-扭转综合征的大型深胸犬通常表现为干呕无物、腹部胀大和休克体征，包括心率增加、脉搏微弱和黏膜苍白[2]。动物可能表现出不安、明显不适、呼吸急促和过度流涎[2]。

小动物可能因泌尿生殖系统疾病而出现急性腹部症状，包括未绝育动物的发热和虚弱，提示子宫蓄脓或前列腺感染[2]。疼痛评估很大程度上依赖于行为指标，因为心率、血压等生理参数由于其非特异性而不可靠[3]。

**品种和物种模式**

胃扩张-扭转综合征主要影响大型深胸犬种，包括大丹犬、德国牧羊犬和标准贵宾犬[2]。德国牧羊犬在抗生素应答性肠病中比例过高[4]。存在某些品种特异性综合征，如软 coated Wheaten Terriers 的蛋白丢失性肠病和拳师犬的组织细胞性溃疡性结肠炎[4]。

**诊断方法**

诊断影像学是急性腹痛评估的基石。X线检查提供初步评估，但对胰腺炎的灵敏度仅为24%[2]。超声检查提供优越的软组织可视化，对胰腺异常的灵敏度为68%[2]。腹部超声评估应包括游离液体、器官移位和肠壁变化的评估[2]。

实验室诊断包括全血细胞计数、生化面板和尿液分析作为最低数据库[2]。当怀疑腹膜炎时，腹腔液分析至关重要，液体与血液之间的葡萄糖差值>20 mg/dl，或乳酸浓度>2 mmol/L可诊断为脓毒性腹膜炎[2]。

### Sources

[1] DVM 360: Approach to the acute abdomen (Proceedings): https://www.dvm360.com/view/approach-acute-abdomen-proceedings

[2] DVM 360: Imaging techniques for the pancreas (Proceedings): https://www.dvm360.com/view/imaging-techniques-pancreas-proceedings

[3] DVM 360: Clinical assessment of pain in dogs and cats--use of pain scales (Proceedings): https://www.dvm360.com/view/clinical-assessment-pain-dogs-and-cats-use-pain-scales-proceedings

[4] Merck Veterinary Manual: Chronic Enteropathies in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/chronic-enteropathies-in-small-animals

## 治疗选择和预防措施

### 治疗选择

**支持性管理**
初始治疗侧重于使用等渗晶体液（15-20分钟内20-30 mL/kg）进行积极的液体复苏，以稳定灌注异常[1]。疼痛管理至关重要，应在诊断程序前给予镇痛剂，以提高患者在检查期间的舒适度和配合度[1]。

**手术干预**
剖腹探查术仍然是急性腹痛病例的主要治疗方法[1]。手术通过目视检查提供诊断能力，并对已识别的病理进行即时治疗。对于胃扩张-扭转综合征（GDV）等特定疾病，在镇静下通过口腔胃管快速减压，然后进行手术矫正[1]。

**药物治疗**
当有指征时，抗生素治疗针对特定的传染性病因。对于脓毒性腹膜炎，使用氨苄青霉素/氨基糖苷类/甲硝唑的联合方案提供适当的经验性覆盖[1]。质子泵抑制剂和硫糖铝比H2受体阻滞剂更有效地管理胃肠道出血[1]。

### 预防措施

**风险降低策略**
预防侧重于最小化创伤暴露并在初始手术过程中实施适当的手术技术[1]。与传染病不同，急性腹痛的预防缺乏特定的疫苗接种方案，但依赖于仔细的患者管理和环境安全措施[6]。

**环境控制**
在多动物环境中保持适当的生物安全措施有助于预防疾病传播[6]。当传染性病因导致急性腹痛表现时，隔离协议变得至关重要[10]。

### Sources

[1] Approach to the acute abdomen (Proceedings): https://www.dvm360.com/view/approach-acute-abdomen-proceedings
[6] Hazards Related to Environmental and Infectious Diseases in Veterinary Medicine: https://www.merckvetmanual.com/public-health/occupational-safety-and-health/hazards-related-to-environmental-and-infectious-diseases-in-veterinary-medicine
[10] Handling Disease Outbreaks in Animals: https://www.merckvetmanual.com/public-health/biosecurity/handling-disease-outbreaks-in-animals

## 鉴别诊断和预后

### 鉴别诊断

急性腹痛必须与众多具有相似临床表现的疾病进行鉴别[1]。**胃肠道梗阻**是一个主要的鉴别诊断，通常由异物、肠套叠或肿瘤引起，表现为呕吐、腹痛和潜在的腹胀[1]。大型犬的**胃扩张-扭转综合征（胃胀气）**导致急性腹部胀大并伴有干呕尝试[3]。

**炎症性疾病**包括胰腺炎、腹膜炎和炎症性肠病可能模拟急性腹痛症状[2]。**泌尿系统急症**如尿道梗阻或尿腹必须考虑，特别是当腹腔液肌酐超过血清水平两倍时[2]。

**代谢性疾病**如肾上腺皮质功能减退症表现为呕吐、虚弱和电解质异常，这些与急性腹痛重叠[5]。鉴别因素包括特定的实验室检查结果、影像学结果和对诊断性腹腔灌洗的反应[2]。

### 预后

预后根据潜在病因和及时干预而有显著差异。**异物梗阻**若及时诊断和治疗则预后极佳（高存活率），但延迟治疗会增加并发症[1]。**胃扩张-扭转综合征**尽管经过积极治疗，仍有约25-30%的死亡率[3]。

**血乳酸水平**作为重要的预后指标，乳酸<6 mmol/L的犬存活率为99%，而超过此阈值时为58%[2]。**手术并发症**包括裂开最常发生在术后3-5天的愈合滞后期[1]。影响恢复的因素包括患者稳定性、并发脓毒症、低白蛋白血症（<2-2.5 g/dL）和腹膜炎的存在[1]。

### Sources
[1] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[2] Managing the acute abdomen (Part 1): evaluation, diagnosis and decision making: https://www.dvm360.com/view/managing-acute-abdomen-part-1-evaluation-diagnosis-and-decision-making-proceedings
[3] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs
[4] Diagnosis and management of GI motility disorders: https://www.dvm360.com/view/diagnosis-and-management-of-gi-motility-disorders
[5] Difficult vomiting disorders: https://www.dvm360.com/view/difficult-vomiting-disorders-proceedings