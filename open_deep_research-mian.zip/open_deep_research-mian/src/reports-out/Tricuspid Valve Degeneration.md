# 伴侣动物三尖瓣退行性病变

三尖瓣退行性病变是影响犬猫的一种重要心脏疾病，其特征为右房室瓣结构和功能的进行性恶化。这种退行性病变主要影响老龄伴侣动物，可导致右侧充血性心力衰竭，并产生严重的临床后果。该疾病表现为特征性的收缩期杂音、运动耐受力下降，在晚期病例中因液体积聚而出现腹部膨大。本综合兽医报告探讨了三尖瓣退行性病变的病理生理学、临床表现和管理策略，涵盖了从心脏生物标志物到超声心动图评估的诊断方法，包括药物治疗和新兴手术干预在内的治疗方案，以及指导受影响患者长期护理决策的预后考量。

## 疾病概述

**定义**

三尖瓣退行性病变是一种进行性心脏疾病，其特征为三尖瓣叶和支持结构的黏液样退行性病变，导致三尖瓣反流和潜在的右侧心力衰竭（默克兽医手册，2024年）。这种退行性过程涉及瓣膜组织的增厚和变形，阻止了收缩期瓣膜的正常闭合。

**流行病学背景**

三尖瓣退行性病变影响犬和猫，但比二尖瓣病少见。该疾病通常影响老年动物，小型犬种表现出特殊易感性，包括查理王小猎犬、玩具贵宾犬、吉娃娃和约克夏梗（DVM360，2024年）。雄性犬与雌性犬相比，风险高出1.5:1.0（DVM360，2024年）。

拉布拉多寻回犬对先天性三尖瓣发育不良表现出特殊易感性，这是一种可能发展为退行性病变的发育畸形（默克兽医手册，2024年）。约30%患有二尖瓣反流的犬也会同时发生三尖瓣反流，表明多瓣膜受累较为常见（默克兽医手册，2024年）。该疾病代表了影响伴侣动物的获得性瓣膜病广泛谱系的一部分，在受影响品种中患病率随年龄增长而增加。

## 常见病原体

在犬和猫中，三尖瓣退行性病变主要是一种退行性疾病，而非传染性疾病。然而，细菌病原体可通过感染性心内膜炎影响三尖瓣，导致进行性瓣膜损伤。

从患有影响心脏瓣膜的感染性心内膜炎的犬和猫中最常分离出的细菌病原体包括链球菌属、葡萄球菌属、克雷伯菌属和大肠杆菌[1]。此外，巴尔通体属已被确认为犬感染性心内膜炎的病因，特别影响主动脉瓣[1]。巴尔通体是革兰氏阴性生物，通过跳蚤、蜱虫和其他节肢动物等媒介传播，可引起犬和猫的心内膜炎[6]。

与二尖瓣和主动脉瓣相比，三尖瓣很少受感染性心内膜炎影响，但当感染确实发生时，通常由血源性细菌播种引起[1]。感染逐渐破坏瓣膜组织并阻止瓣膜正常功能，最终导致瓣膜功能不全。

病毒病原体通常不被报道为三尖瓣退行性病变的直接原因。然而，全身性病毒感染可间接影响心脏功能并对瓣膜结构造成额外负担。

值得注意的是，伴侣动物中绝大多数三尖瓣退行性病变病例是非感染性的，代表了通常影响老年犬房室瓣的黏液样退行性病变过程的一部分[2]。继发性细菌感染可能偶尔使预先存在的退行性瓣膜病复杂化，但在小动物临床实践中，三尖瓣退行性病变的原发性感染原因仍然不常见。

### Sources

[1] Infectious Endocarditis in Dogs and Cats: https://www.merckvetmanual.com/circulatory-system/various-heart-diseases-in-dogs-and-cats/infectious-endocarditis-in-dogs-and-cats
[2] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[3] About Bartonella | Bartonella Infection | CDC: https://www.cdc.gov/bartonella/about/index.html
[4] Bartonella - Wikipedia: https://en.wikipedia.org/wiki/Bartonella
[5] Acquired Heart and Blood Vessel Disorders in Cats: https://www.merckvetmanual.com/cat-owners/heart-and-blood-vessel-disorders-of-cats/acquired-heart-and-blood-vessel-disorders-in-cats
[6] Acquired Heart and Blood Vessel Disorders in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/acquired-heart-and-blood-vessel-disorders-in-dogs

## 临床症状和体征

三尖瓣退行性病变表现出可变的临床表现，主要与右心衰竭相关。犬最初可能无症状，当疾病进展时，有些表现出右侧充血性心力衰竭的体征[1]。最具特征性的早期发现是在右侧心尖部听到的收缩期杂音，这与三尖瓣反流相对应[1]。

晚期病例出现右心衰竭的典型体征，包括因腹水导致的腹部膨大、外周水肿和颈静脉扩张伴异常搏动[1][2]。这些犬可能表现出全身性肌肉无力和进行性运动耐受力下降，因为严重瓣膜反流损害了心输出量[1]。与左心衰竭不同，咳嗽和呼吸窘迫并不常见，除非同时存在左侧疾病。

存在品种特异性模式，拉布拉多寻回犬特别易患三尖瓣发育不良，这是一种三尖瓣畸形的先天性形式[6]。在这些病例中，心律失常，特别是突发性心动过速很常见，可能导致猝死[6]。体格检查发现右侧心尖部有响亮的心脏杂音，超声心动图可显示畸形瓣膜并量化反流严重程度[6]。

一些患有多瓣膜受累的慢性退行性瓣膜病的犬可能表现出左心和右心衰竭的体征[1]。三尖瓣反流的发生可能是继发于肺动脉高压，或是原发性三尖瓣退行性病变的结果[1]。

### Sources
[1] Managing chronic valvular disease (Proceedings): https://www.dvm360.com/view/managing-chronic-valvular-disease-proceedings
[2] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals
[6] Congenital and Inherited Disorders of the Cardiovascular System in Dogs: https://www.merckvetmanual.com/dog-owners/heart-and-blood-vessel-disorders-of-dogs/congenital-and-inherited-disorders-of-the-cardiovascular-system-in-dogs

## 诊断方法

诊断三尖瓣退行性病变需要综合的多模式方法，结合临床评估、实验室检测和先进成像技术[1]。

**临床评估**
体格检查侧重于检测特征性的听诊发现，特别是在右半胸壁听到的最响亮的三尖瓣反流收缩期杂音[1]。评估包括颈静脉扩张、股动脉脉搏质量、黏膜颜色和呼吸速率的评估，以识别右侧充血性心力衰竭的体征[5]。

**心脏生物标志物**
N末端B型利钠肽原（NT-proBNP）和心肌肌钙蛋白I是犬猫心脏病和心力衰竭检测中临床验证最多的生物标志物[1]。NT-proBNP浓度随疾病严重程度成比例增加，有助于区分心脏性和非心脏性呼吸体征原因[1]。这些生物标志物应与其他诊断方式结合使用，而不是单独使用[1]。

**影像学检查**
超声心动图是诊断三尖瓣退行性病变的金标准，提供瓣膜形态学、反流严重程度和心室功能的详细评估[1,3]。胸部X线摄影评估心脏大小进展，并识别与右侧心力衰竭相关的并发症，如胸腔积液或腹水[3]。心电图可能揭示心脏增大模式或心律失常，尽管其对结构性心脏病的诊断敏感性较低[3]。

### Sources

[1] Heart Failure in Dogs and Cats - Circulatory System: https://www.merckvetmanual.com/circulatory-system/heart-failure-in-dogs-and-cats/heart-failure-in-dogs-and-cats

[2] Heart Failure in Dogs - Dog Owners: https://www.merckvetmanual.com/en-au/dog-owners/heart-and-blood-vessel-disorders-of-dogs/heart-failure-in-dogs

[3] Management of acquired canine heart disease: part 1 & 2 (Proceedings): https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings

[4] Management of incidentally detected heart murmurs in dogs and cats: https://avmajournals.avma.org/view/journals/javma/246/10/javma.246.10.1076.xml

[5] ECG of the Month in: Journal of the American Veterinary: https://avmajournals.avma.org/view/journals/javma/248/11/javma.248.11.1245.xml

## 治疗选择

三尖瓣退行性病变的治疗侧重于通过多种治疗方法管理充血性心力衰竭（CHF）和支持心脏功能[1]。标准药物治疗方案包括呋塞米米作为主要利尿剂，通常根据CHF严重程度以2-6 mg/kg静脉注射、肌肉注射、皮下注射或口服给药[3]。袢利尿剂在急性和慢性管理阶段对于消除水肿和防止液体潴留仍然至关重要。

ACE抑制剂构成治疗的另一个基石，贝那普利、依那普利和雷米普利通常以0.25-0.5 mg/kg每日一次或两次给药[3]。这些药物提供静脉扩张以降低静脉压力、动脉扩张以降低后负荷以及心脏保护作用。匹莫苯丹是首选的正性肌力药物，以0.2-0.3 mg/kg每12小时口服一次给药，提供肌力支持和血管扩张特性[1][3]。螺内酯（2 mg/kg每日口服）作为心脏保钾利尿剂，通常与呋塞米联合使用以实现最佳CHF管理[3]。

现在可以为严重病例提供先进的手术干预。经导管缘对缘修复（TEER）手术为开胸手术提供了微创替代方案，在动物患者中成功率达95%[4]。该手术涉及通过小胸部切口放置装置连接三尖瓣边缘，显著减少反流。对于难治性CHF病例，可能需要定期腹腔穿刺术来管理腹水[7]。康复包括6周的活动限制和长期随访预约。

### Sources

[1] Pimobendan: Understanding its cardiac effects in dogs with myocardial disease: https://www.dvm360.com/view/pimobendan-understanding-its-cardiac-effects-dogs-with-myocardial-disease
[2] Current strategies on diagnosis and treatment of feline cardiomyopathy: https://www.dvm360.com/view/current-strategies-diagnosis-and-treatment-feline-cardiomyopathy-proceedings
[3] Management of acquired canine heart disease: https://www.dvm360.com/view/management-acquired-canine-heart-disease-part-1-2-proceedings
[4] BluePearl Pet Hospital in Tampa, Florida, becomes eighth hospital in US to offer TEER procedure: https://www.dvm360.com/view/bluepearl-pet-hospital-in-tampa-florida-becomes-8th-hospital-in-us-to-offer-teer-procedure
[5] Dysplasia and Stenosis of Atrioventricular Valves in Animals: https://www.merckvetmanual.com/circulatory-system/congenital-and-inherited-anomalies-of-the-cardiovascular-system/dysplasia-and-stenosis-of-atrioventricular-valves-in-animals

## 预防措施

三尖瓣退行性病变主要是一种与衰老相关的退行性疾病，使得传统预防措施有限。目前，没有针对该疾病的特定疫苗，因为它代表的是黏液样退行性病变而非传染性疾病[1][2]。

环境控制措施侧重于管理可能加速疾病进展的风险因素。保持最佳体重有助于减少心脏负荷，而适合患者病情的规律运动支持心血管健康[1]。血压监测和管理至关重要，因为全身性高血压会加重瓣膜功能不全并加速心力衰竭发展[4]。

繁殖建议集中在易感品种的遗传咨询上。小型犬包括查理王小猎犬、玩具贵宾犬、吉娃娃和约克夏梗表现出较高的患病率[2][7]。雄性犬与雌性犬相比，风险高出1.5:1.0[1]。负责任的繁殖实践应包括繁殖动物的心脏筛查，尽管没有杂音并不能保证没有疾病，特别是在易患三尖瓣发育不良的品种如拉布拉多寻回犬中[4][7]。

高风险人群通过常规检查期间定期心脏听诊受益于早期检测。具有3/6级或更响杂音的犬需要超声心动图评估以评估疾病严重程度并指导管理决策[1]。虽然隔离指南不适用于这种非传染性疾病，但基于疾病进展的监测和分期干预仍然是管理的基石。

### Sources

[1] Managing chronic valvular disease (Proceedings): https://www.dvm360.com/view/managing-chronic-valvular-disease-proceedings
[2] Acquired cardiac diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/acquired-cardiac-diseases-dog-and-cat-proceedings
[3] The thrill of arrhythmias: https://www.dvm360.com/view/thrill-arrhythmias
[4] Back to basics: clinical cardiovascular exam and diagnostic testing (Proceedings): https://www.dvm360.com/view/back-basics-clinical-cardiovascular-exam-and-diagnostic-testing-proceedings
[5] The malformed canine heart: https://www.dvm360.com/view/the-malformed-canine-heart
[6] Congenital diseases of the dog and cat (Proceedings): https://www.dvm360.com/view/congenital-diseases-dog-and-cat-proceedings
[7] Tool Kit Essentials for Canine Congestive Heart Failure: https://www.dvm360.com/view/tool-kit-essentials-for-canine-congestive-heart-failure

## 鉴别诊断

三尖瓣退行性病变必须与几种表现出相似临床症状和诊断发现的疾病进行鉴别[1]。最重要的鉴别诊断包括其他形式的心脏瓣膜病、心肌病和呼吸系统疾病。

**二尖瓣退行性病变**是最常见的鉴别诊断，因为两种疾病经常同时发生。约30%患有二尖瓣反流的犬也会发生三尖瓣反流[1]。鉴别因素包括杂音位置（左侧心尖与右侧心尖）和超声心动图对特定瓣膜受累的评估。

**肺动脉高压**表现出显著的重叠诊断特征，因为三尖瓣反流最大速度测量通常用于诊断收缩期肺动脉高压[2]。超声心动图对右心变化和肺动脉速度谱的评估有助于区分原发性肺动脉高压和继发性三尖瓣疾病。

**扩张型心肌病**可产生相似的右侧心力衰竭体征，并可能因瓣环扩张继发三尖瓣功能障碍[1]。超声心动图显示所有四个心室的特征性腔室扩张和收缩功能不良，将其与原发性瓣膜病区分开来。

**原发性呼吸系统疾病**包括慢性支气管炎、肺炎和心丝虫病可引起相似的运动耐受力下降和咳嗽。胸部X光片和肺动脉内心丝虫的超声心动图评估提供明确鉴别[1]。

**致心律失常性右心室心肌病**，特别是在拳师犬中，导致原发性右心衰竭并因右心室扩张继发三尖瓣反流[1]。品种易感性和右心室壁变薄和脂肪浸润的超声心动图发现可区分这种情况。

### Sources

[1] Abnormalities of the Cardiovascular System in Animals: https://www.merckvetmanual.com/circulatory-system/cardiovascular-system-introduction/abnormalities-of-the-cardiovascular-system-in-animals

[2] Canine pulmonary hypertension, Part 2: Diagnosis and treatment: https://www.dvm360.com/view/canine-pulmonary-hypertension-part-2-diagnosis-and-treatment