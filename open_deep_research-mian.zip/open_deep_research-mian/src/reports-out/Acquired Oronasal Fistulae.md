# 伴侣动物的获得性口鼻瘘

获得性口鼻瘘在小动物兽医临床实践中代表了重大的临床挑战，它们在口腔和鼻腔之间形成了病理性通道，可能严重影响患者的生活质量。这些情况最常见于晚期牙周病的并发症，特别是在腊肠犬等品种中，或是在拔牙手术后发生。本综合报告探讨了获得性口鼻瘘的多面性，涵盖了其潜在的病理生理学、包括先进成像技术在内的诊断方法，以及基于证据的治疗方案。报告综合了当前兽医关于手术修复技术、预防策略和预后因素的知识，为临床医生提供了管理这些复杂病例的基本指导，并通过正确的诊断和干预实现最佳的患者预后。

## 摘要

获得性口鼻瘘代表了复杂的临床状况，需要全面了解其病因学、诊断和管理。晚期牙周病仍然是主要原因，腊肠犬表现出特别的品种易感性。成功的诊断依赖于结合牙周探查、牙科X光摄影和荧光素染料测试的系统评估，而CT成像为复杂病例提供了更优的可视化效果。

治疗成功关键取决于正确的手术技术，单层移位瓣作为主要的修复方法。避免瓣张力的基本原则再怎么强调也不为过——张力是导致裂开和修复失败的"杀手"。通过全面的牙科预防和正确的拔牙技术进行预防提供了最有效的方法。

| 因素 | 关键考虑因素 |
|--------|------------------|
| **主要原因** | 晚期牙周病（上颌犬齿） |
| **诊断金标准** | 口内牙科X光摄影 |
| **手术成功因素** | 无张力瓣闭合 |
| **并发症率** | 上颌拔牙后11% |
| **预防策略** | 定期牙科预防和正确的拔牙闭合 |

早期识别和干预显著改善预后，强调了常规牙科检查和在瘘管形成之前及时治疗牙周病的重要性。

## 疾病概述和流行病学

获得性口鼻瘘是口腔和鼻腔之间的病理性通道，继发于疾病过程或创伤[1]。这些瘘管代表了允许口腔和呼吸道之间直接沟通的开口，导致慢性鼻炎、鼻腔感染、打喷嚏、口臭和鼻腔分泌物[1]。

获得性口鼻瘘的最常见原因是晚期牙周病[2]。这些病变经常作为拔牙后的并发症发生，特别是当拔牙部位没有正确闭合时[3]。与牙周病相关的瘘管通常发生在上颌犬齿的腭侧，那里由于垂直骨丢失而形成深腭袋[3]。

腊肠犬表现出特别高的发生口鼻瘘的易感性，有品种特定的建议使用牙科X光摄影和仔细的牙周探查进行定期评估[3]。这种情况也常见于小型犬和长头品种[5]。解剖位置各不相同，与影响后前臼齿和臼齿区域的口上颌窦瘘相比，口鼻瘘通常发生在前部区域（门齿、犬齿和前臼齿区域）[3]。尽管有近期牙科预防的病史，这种情况主要影响中老年犬[4]。虽然最常见于犬，但口鼻瘘也可能发生在猫中，尽管频率较低[3]。

### Sources

[1] Your 4 pearls for oronasal fistula repair in dogs and cats: https://www.dvm360.com/view/your-4-pearls-for-oronasal-fistula-repair-in-dogs-and-cats

[2] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings

[3] What are oronasal or oroantral fistulas?: https://www.dvm360.com/view/what-are-oronasal-or-oroantral-fistulas

[4] Diagnostic dilemmas of the upper respiratory tract: https://www.dvm360.com/view/diagnostic-dilemmas-upper-respiratory-tract-proceedings

[5] Normal occlusion or malocclusion: that is the question (Proceedings): https://www.dvm360.com/view/normal-occlusion-or-malocclusion-question-proceedings

## 病因学和发病机制

获得性口鼻瘘通过多种病因学途径发展，晚期牙周病是主要原因[1]。病理生理学进展通常始于细菌斑块的积累，特别是含有牙周致病菌种如*牙龈卟啉单胞菌*和*脆弱拟杆菌*的龈下斑块[2]。这些生物体引发炎症反应，逐渐破坏牙周组织和支持性牙槽骨。

深腭袋通常在上颌犬齿附近发展，那里的垂直骨丢失在口腔和鼻腔之间创造了沟通[1]。腊肠犬对此状况表现出特别的易感性，有些病例早在三岁时就表现为慢性打喷嚏[1]。

拔牙并发症代表了第二个最常见的原因，特别是在上颌犬齿拔牙后[3]。拔牙期间医源性腭骨骨折或拔牙部位闭合不当可能导致持续的口鼻沟通[4]。其他重要原因包括牙齿创伤性脱位、异物穿透、咬伤和口腔肿瘤[1]。

从初始牙周损伤到瘘管形成的进展涉及细菌渗透、炎症介质释放和进行性组织破坏[2]。宿主免疫反应结合细菌代谢产物，直接导致牙根周围的骨骼和软组织损伤，最终损害口鼻屏障的完整性。

### Sources

[1] What are oronasal or oroantral fistulas?: https://www.dvm360.com/view/what-are-oronasal-or-oroantral-fistulas
[2] Periodontal Disease in Small Animals - Digestive System - Merck Vet Manual: https://www.merckvetmanual.com/digestive-system/dentistry/periodontal-disease-in-small-animals
[3] Oronasal fistula closure (Proceedings): https://www.dvm360.com/view/oronasal-fistula-closure-proceedings
[4] Your 4 pearls for oronasal fistula repair in dogs and cats: https://www.dvm360.com/view/your-4-pearls-for-oronasal-fistula-repair-in-dogs-and-cats

## 诊断方法

获得性口鼻瘘的诊断依赖于结合临床检查结果与先进诊断技术的系统评估。麻醉下的体格检查是必要的，因为许多瘘管在清醒检查时可能不明显[10]。彻底的牙周探查是基础，当存在沟通时，探针会直接滑入鼻腔，通常伴有血液从相应的鼻孔出现[10]。

口内牙科X光摄影代表了诊断成像的金标准[8]。这些X光片有效地展示了骨骼变化、附着丧失和受影响牙齿周围牙周破坏的程度。然而，牙科X光片可能并不总是能可视化软组织缺陷本身[2]。计算机断层扫描（CT）或锥形束计算机断层扫描等先进成像提供了病变全范围的优异可视化，对于需要手术治疗计划的复杂病例特别有价值[8][9]。

荧光素染料测试提供了额外的诊断确认。当荧光素染料放置在疑似缺陷中时，其在同侧鼻孔的出现证实了口腔和鼻腔之间的沟通[2]。疑似病变的冲洗也可以证明沟通，冲洗液从相应的鼻孔流出[2]。

软组织缺陷的外观通常比潜在的骨骼破坏小得多，强调了在治疗计划之前进行X光评估的重要性[2]。记录应包括详细的测量和照片记录，以促进适当的治疗决策。

### Sources
[1] Malocclusion with severe tissue destruction in a dog: https://www.dvm360.com/view/malocclusion-with-severe-tissue-destruction-dog
[2] What are oronasal or oroantral fistulas?: https://www.dvm360.com/view/what-are-oronasal-or-oroantral-fistulas
[8] Periodontal Disease in Small Animals - Digestive System: https://www.merckvetmanual.com/en/digestive-system/dentistry-in-small-animals/periodontal-disease-in-small-animals
[9] The ABCs of veterinary dentistry: "I" is for informed consent: https://www.dvm360.com/view/abcs-veterinary-dentistry-i-informed-consent
[10] Oral pathology and anatomic abnormalities (Proceedings): https://www.dvm360.com/view/oral-pathology-and-anatomic-abnormalities-proceedings

## 治疗选项

### 手术修复技术

单层移位瓣仍然是获得性口鼻瘘修复的主要手术方法[1]。兽医牙科专科医生建议掌握这种技术，因为它对大多数病例"应该总是有效"[1]。双瓣技术保留用于修复失败的单瓣程序或需要保证结果的复杂病例[1]。

先进的手术选项包括用于牙周病继发缺陷的颊瓣，边缘清创并通过牙龈和牙槽粘膜进行发散切口[2]。对于较大的缺陷，重叠瓣技术通过双层闭合和减少缝合线张力提供优越的强度[2]。

### 术前和麻醉考虑因素

术前X光片对于手术计划和了解解剖变异至关重要[3]。麻醉管理包括静脉导管置入、液体治疗和使用阿片类药物、α2-激动剂和区域神经阻滞的多模式镇痛[9]。在加热毯上正确的患者定位可以防止长时间手术期间的低温[3]。

### 术后护理和并发症

关键的术后原则包括避免瓣上的张力，这是导致裂开的"杀手"[1]。骨膜释放切口减少瓣张力，四角粘膜骨膜瓣应该是缺陷的1.5倍大[4]。口鼻瘘形成在2.9%的病例中作为2级并发症发生[8]。

最常见的并发症包括唇创伤（13.4%）、口鼻瘘形成（11.0%）和出血[8]。大多数并发症是轻微的（≤2级）并且可以通过保守治疗控制。由于暴露不足导致的瓣张力是修复失败的主要原因[10]。

### Sources
[1] Your 4 pearls for oronasal fistula repair in dogs and cats: https://www.dvm360.com/view/your-4-pearls-for-oronasal-fistula-repair-in-dogs-and-cats
[2] Managing challenging oral cases in dogs: part I: https://www.dvm360.com/view/managing-challenging-oral-cases-dogs-part-i-proceedings
[3] Surgical extraction and oronasal fistula repair: https://www.dvm360.com/view/surgical-extraction-and-oronasal-fistula-repair-proceedings
[4] Six common pitfalls in veterinary dentistry: https://www.dvm360.com/view/six-common-pitfalls-veterinary-dentistry-and-how-avoid-them
[8] Intraoperative and postoperative complications of partial maxillectomy: https://avmajournals.avma.org/view/journals/javma/252/12/javma.252.12.1538.xml
[9] Dental extractions: from anesthesia to send home: https://www.dvm360.com/view/dental-extractions-anesthesia-send-home-proceedings
[10] "Uh-oh... maybe I should have referred that": https://www.dvm360.com/view/uh-oh-maybe-i-should-have-referred

## 预防、鉴别诊断和预后

### 预防措施

获得性口鼻瘘的预防集中在全面的牙科预防和正确的拔牙技术上。每日刷牙、牙科饮食和定期的专业牙科清洁有助于防止通常导致口鼻沟通的牙周病进展[1]。围手术期计划至关重要——所有拔牙部位都应使用设计良好的粘膜牙龈瓣进行闭合，确保充足的血液供应和无张力闭合[2][3]。

上颌犬齿上的深牙周缺陷，在腊肠犬中特别常见，需要早期识别和治疗以防止瘘管形成[1][4]。在沟通发展之前进行正确的刮治、根面平整和引导组织再生可以保存牙齿附着[1]。

关键的手术技术涉及在拔牙前去除足够的牙槽骨和仔细的瓣提升以防止过度用力[5][6]。拔牙带来潜在的并发症，包括医源性颌骨骨折和口鼻瘘形成[7]。

### 鉴别诊断

关键的鉴别诊断包括先天性腭裂（断奶时出现并伴有喂养困难）、鼻腔肿瘤（进行性单侧分泌物、面部变形）、慢性鼻炎（双侧分泌物、炎症变化）和牙根脓肿（面部肿胀、根尖X光变化）[5][6]。异物通常引起急性发作的打喷嚏和面部抓挠[6]。

单侧鼻腔分泌物提示局部状况如口鼻瘘，而双侧分泌物表明更弥漫的过程[6]。

### 预后

手术修复成功取决于正确的瓣设计、组织活力和术后护理。当使用足够的组织边缘和无张力闭合进行时，粘膜牙龈瓣修复显示出优异的结果[4]。慢性病例可能需要双层修复以获得最佳结果[4]。术后遵守软食物限制和口腔卫生显著影响愈合成功率。

口鼻瘘形成发生在大约11%的上颌拔牙病例中，并发症通常在术后几周内发展[8]。

### Sources

[1] A foundation for treating canine periodontal disease: https://www.dvm360.com/view/dental-corner-foundation-treating-canine-periodontal-disease
[2] An update on periodontal disease in dogs (Proceedings): https://www.dvm360.com/view/update-periodontal-disease-dogs-proceedings
[3] Decision making and extraction techniques in dogs: https://www.dvm360.com/view/decision-making-and-extraction-techniques-dogs-proceedings
[4] What are oronasal or oroantral fistulas?: https://www.dvm360.com/view/what-are-oronasal-or-oroantral-fistulas
[5] Upper airway troubles (Proceedings): https://www.dvm360.com/view/upper-airway-troubles-proceedings
[6] Clinical approach to nasal discharge (Proceedings): https://www.dvm360.com/view/clinical-approach-nasal-discharge-proceedings
[7] Vital pulp therapy in dogs maintains an 80% success rate: https://avmajournals.avma.org/view/journals/javma/aop/javma.25.04.0224/javma.25.04.0224.xml
[8] Intraoperative and postoperative complications of partial: https://avmajournals.avma.org/view/journals/javma/252/12/javma.252.12.1538.xml