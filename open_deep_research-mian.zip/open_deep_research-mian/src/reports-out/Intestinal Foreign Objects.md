# 伴侣动物肠道异物

肠道异物摄入是兽医临床中最常见的胃肠道急症之一，影响犬猫并可能危及生命。这种情况发生在宠物摄入非食物物品后，这些物品滞留在胃肠道内，造成部分或完全性阻塞。幼年动物和某些品种表现出更高的易感性，猫尤其容易摄入线性异物如绳子或线。临床表现因阻塞部位和持续时间而差异显著，从轻微的胃肠道不适到需要立即手术干预的严重代谢紊乱。本报告探讨了管理肠道异物的综合方法，涵盖诊断策略、治疗选择以及影响伴侣动物临床成功结果的预后因素。

## 异物类型与特征

犬猫体内的异物可分为两大类：线性和非线性异物[1]。线性异物包括绳子、线、纱线、牙线和地毯纤维，这些在猫中特别常见[2]。非线性异物包括多种材料，如塑料玩具、石头、骨头、织物和各种家居物品[3]。

放射学上，异物分为不透射线（X光下可见）或可透射线（X光下不可见）[4]。不透射线材料包括金属物品、骨头和一些塑料，而可透射线的物品如织物、橡胶或有机材料需要造影检查或超声才能检测到[2]。

解剖分布因异物类型而异。线性异物通常锚定在口腔（特别是猫的舌下）并延伸至整个胃肠道，导致特征性的肠道折叠或"手风琴状褶皱"[2][5]。非线性异物更常见于胃、幽门区或小肠[3]。

阻塞的病理生理机制因类型而异。线性异物通常引起部分阻塞，并伴有黏膜撕裂和腹膜炎风险，这是由于蠕动过程中的锯切作用所致[5]。非线性异物更常见地造成完全性机械阻塞，导致近端肠道扩张、液体积聚，如不治疗可能发生穿孔[4]。

### Sources

[1] Clinical features and outcomes of dogs with attempted medical management for discrete gastrointestinal foreign material: https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml

[2] Diagnostic imaging for linear foreign bodies in cats: https://www.dvm360.com/view/diagnostic-imaging-linear-foreign-bodies-cats

[3] What Is Your Diagnosis? in - AVMA Journals: https://avmajournals.avma.org/view/journals/javma/246/9/javma.246.9.955.xml

[4] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals

[5] Practical imaging of the gastrointestinal tract: https://www.dvm360.com/view/practical-imaging-gastrointestinal-tract-proceedings

## 临床症状与体征

肠道异物的临床表现因阻塞部位、持续时间和类型而显著不同。犬通常表现为呕吐、嗜睡和食欲不振，而在某些情况下主人可能目睹异物摄入[1]。幼猫和大型品种犬比老年动物更常受影响[2]。

**基于部位的表现：**
近端阻塞通常引起顽固性呕吐，而远端小肠阻塞可能表现为呕吐频率较低[2]。完全性阻塞比部分性阻塞症状更严重，线性异物更可能引起部分阻塞，而大型圆形异物通常导致完全性阻塞[2]。

**体格检查发现：**
体格检查可能揭示腹痛、可触及的肠道肿块或脱水迹象[1]。在猫中，彻底的口腔检查至关重要，因为线性异物可能锚定在舌根[2]。

**实验室异常：**
常见的生化变化包括低氯血症（51.2%的病例）、代谢性碱中毒（45.2%）、高乳酸血症（40.5%）、低钾血症（25%）和低钠血症（20.5%）[3]。常出现白细胞增多伴轻度左移，而显著的白细胞增多或白细胞减少伴退行性左移提示穿孔和腹膜炎[2]。

**诊断影像学：**
放射学发现包括节段性肠扩张、胃扩张、不透射线异物或线性异物引起的肠道折叠[1,2]。超声检查可识别异物和肠道液体积聚，"靶样"病变提示肠套叠[2]。

### Sources
[1] Clinical features and outcomes of dogs with attempted medical management for discrete gastrointestinal foreign material: 68 cases (2018–2023): https://avmajournals.avma.org/view/journals/javma/262/9/javma.24.01.0050.xml
[2] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[3] Research Update: Determining the significance of blood chemistry changes in dogs with GI foreign bodies: https://www.dvm360.com/view/research-update-determining-significance-blood-chemistry-changes-dogs-with-gi-foreign-bodies

## 治疗策略与手术管理

**内镜取出**
内镜取出通常是可行时的首选方法。使用带锯齿状钳口的钳子、异物抓取器和篮式取出器的软式内镜可以成功取出可及的异物[4]。对于食管异物，球囊导管技术包括将导管通过异物，充气球囊并向近端拉出[2]。然而，内镜成功取决于病例选择——尖锐物品、锚定在幽门的线性异物或延伸至十二指肠以外的物品可能需要手术干预[2,4]。

**手术决策**
当内镜取出失败、异物在8小时内无法移动或在36-48小时内未能通过时，手术成为必要[1]。多种手术方法包括针对胃内异物的胃切开术、肠道取出的肠切开术，以及当肠道受损时的肠切除吻合术[1,2]。多个固体异物通常可以通过"挤奶"方式通过肠道并通过单一切口取出，而线性异物通常需要多处肠切开术[2]。

**术后管理**
标准护理包括液体纠正、广谱抗生素和仔细监测[1,2]。可在恢复后12小时提供饮水，如果没有呕吐，可在12-24小时后引入食物[2]。并发症包括吻合口裂开（通常在术后3-5天），异物病例的泄漏风险比其他肠道手术更大[2]。术后镇痛药、胃肠道保护剂和运动限制是必要的[2]。

### Sources
[1] Gastrointestinal Obstruction in Small Animals: https://www.merckvetmanual.com/en-au/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastrointestinal-obstruction-in-small-animals
[2] Surgery STAT: Surgical management of gastrointestinal foreign bodies: https://www.dvm360.com/view/surgery-stat-surgical-management-gastrointestinal-foreign-bodies
[3] Key gastrointestinal surgeries: Gastrotomy: https://www.dvm360.com/view/key-gastrointestinal-surgeries-gastrotomy
[4] Clinical indications and techniques for upper and lower GI endoscopy: https://www.dvm360.com/view/clinical-indications-and-techniques-upper-and-lower-gi-endoscopy-proceedings