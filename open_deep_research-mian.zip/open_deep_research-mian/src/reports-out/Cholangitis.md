# 伴侣动物胆管炎

胆管炎，即胆管的炎症，是兽医临床中影响犬猫最重要的肝胆疾病之一。本综合报告探讨了管理伴侣动物胆管炎的复杂病理生理学、诊断挑战和治疗方法。由于犬猫肝胆系统的解剖差异，该疾病在犬和猫中的表现不同，其中猫胆管炎/胆管肝炎综合征是家猫最常见的获得性炎症性肝病。探讨的关键领域包括：驱动化脓性形式的细菌病原体、淋巴细胞变体潜在的免疫介导机制、结合影像学和组织病理学的先进诊断方案，以及从抗菌治疗到免疫抑制和手术干预的多模式治疗策略。

## 疾病概述

胆管炎是胆管的炎症，而胆管肝炎则涉及炎症扩展到胆管上皮以外的门脉周围区域[1]。这种肝胆综合征影响犬和猫，但在不同物种中表现不同。

猫胆管炎/胆管肝炎综合征（CCHS）是家猫最常见的获得性炎症性肝病[2]。与犬相比，猫的胆管和胰腺导管之间的解剖差异长期以来被认为是一个潜在的风险因素，因为猫通常具有共同的胰胆管系统[2]。

分类系统根据主要炎症细胞类型将胆管炎分为化脓性和非化脓性两类[1][3]。化脓性形式通常涉及中性粒细胞炎症和细菌感染，而非化脓性变体则以淋巴细胞或淋巴浆细胞浸润为特征[3]。WSAVA（世界小动物兽医协会）的组织学分类将疾病分为中性粒细胞性胆管炎、淋巴细胞性胆管炎和与肝吸虫相关的胆管炎[4]。

在犬中，胆管肝炎通常与胆囊黏液囊肿和其他胆道疾病相关。犬的病例常涉及来自胃肠道的细菌移位，特别是在食用生食、觅食或存在潜在肠道疾病之后[1]。该疾病可能从急性化脓性炎症发展为伴有纤维化的慢性混合性炎症模式。

### Sources
[1] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis
[2] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[3] Inflammatory liver disease in the cat (Proceedings): https://www.dvm360.com/view/inflammatory-liver-disease-cat-proceedings
[4] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings

## 常见病原体

猫胆管炎主要涉及通过胃肠道上行感染获得的细菌病原体[1]。受感染猫的细菌培养结果显示69%的病例呈阳性，其中肠球菌属和大肠杆菌是最常见的分离菌[1]。其他细菌原因包括链球菌、梭菌、葡萄球菌和拟杆菌属[3]。

急性中性粒细胞性胆管炎通常由革兰氏阴性菌引起，特别是大肠杆菌，它是受感染猫胆汁或肝脏样本中最常培养出的病原体[3]。由于猫的胆管和胰腺导管之间存在独特的解剖连接，上行感染途径得以发生，促进了细菌从肠道的移位[5]。在犬胆管肝炎中，约30%的病例发生多微生物感染，联合细菌培养以肠球菌属和大肠杆菌为主要分离菌[6]。

病毒病原体可能导致犬的肝胆炎症，包括由犬腺病毒1型引起的传染性犬肝炎，如果抗体反应不足，可能发展为慢性肝炎[1]。意外胃肠外注射鼻内支气管败血波氏杆菌疫苗可导致急性肝细胞变性，进而发展为慢性肝炎[1]。

螺杆菌属可能促进中性粒细胞性胆管炎的发展，但其具体作用仍在研究中[3]。寄生虫原因包括肝吸虫，特别是那些引起伴有胆管破坏的慢性胆管炎的吸虫[5]。发病机制涉及细菌通过胆总管上行，导致胆管炎症，进而可能累及周围肝实质，通常伴有胰腺和肠道炎症[2]。

### Sources
[1] Infectious Diseases of the Liver in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/infectious-diseases-of-the-liver-in-small-animals
[2] Clinical features, concurrent disorders, and survival time in: https://avmajournals.avma.org/view/journals/javma/260/2/javma.20.10.0555.xml
[3] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings
[4] Disorders of the Liver and Gallbladder in Dogs - Dog Owners: https://www.merckvetmanual.com/dog-owners/digestive-disorders-of-dogs/disorders-of-the-liver-and-gallbladder-in-dogs
[5] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[6] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis

## 临床症状和体征

胆管炎表现出不同的临床模式，在犬和猫之间，以及疾病的急性和慢性形式之间存在显著差异[1]。

**患有胆管炎的犬**
在犬中，临床症状出现的频率依次降低，包括嗜睡和呕吐（>70%）、食欲减退（~65%）和腹泻（~30%）[1]。体格检查显示发热（~30%）、黄疸（~25%）、嗜睡（26%）、可触及的肝肿大（10%），以及偶尔的多尿/烦渴和腹水[1]。化脓性形式通常急性发作，发热是常见表现[6]。

**患有胆管炎的猫**
猫的临床表现因疾病慢性程度而有较大差异。急性中性粒细胞性胆管炎引起明显的临床疾病，病史通常少于5天[2][5]。体征包括发热、嗜睡、脱水、食欲不振、呕吐和不同程度的黄疸，许多猫表现出腹痛，有些可触及肝肿大[8]。

猫的慢性形式表现更为隐匿，病程从数周到数年不等[2][5]。这些猫表现为间歇性呕吐和腹泻、发作性厌食、体重减轻、孤僻和自限性黄疸[8]。晚期病例可能发展为腹水、高球蛋白血症和肝性脑病[2]。

**神经系统表现**
可能发生肝性脑病，表现为流涎、嗜睡、抑郁、反应迟钝、转圈、顶头、无目的游荡、虚弱、协调性差、失明、过度流涎、行为改变、痴呆、虚脱、癫痫发作和昏迷[4][5]。这些体征反映了肝功能障碍和毒素积累对神经功能的影响。

**物种特异性差异**
由于胆管解剖结构的差异，猫比犬表现出更明显的胆道受累[8]。猫的胆总管-胰管连接处易并发胰腺炎和炎症性肠病，形成“三体炎综合征”[2][5]。

### Sources
[1] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis
[2] Feline cholangitis and chronic pancreatitis (Proceedings): https://www.dvm360.com/view/feline-cholangitis-and-chronic-pancreatitis-proceedings
[3] Diagnosis of liver disease in dogs and cats (Proceedings): https://www.dvm360.com/view/diagnosis-liver-disease-dogs-and-cats-proceedings
[4] Disorders of the Liver and Gallbladder in Cats - Cat Owners: https://www.merckvetmanual.com/cat-owners/digestive-disorders-of-cats/disorders-of-the-liver-and-gallbladder-in-cats
[5] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease
[6] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings
[7] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[8] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome

## 诊断方法

由于胆管炎这种肝胆疾病的复杂性和可变性，其诊断需要结合临床病理学、先进影像学和组织取样的多模式方法[1]。

### 临床病理学发现

全血细胞计数检查可能显示约30%的中性粒细胞性胆管炎病例出现核左移伴中毒性中性粒细胞[1]。血清生化通常显示丙氨酸转氨酶（ALT）、天冬氨酸转氨酶（AST）和γ-谷氨酰转移酶（GGT）中度升高，而碱性磷酸酶（ALP）升高程度较小[1]。由于炎症和胆汁淤积，高胆红素血症很常见[1]。由于胆汁淤积引起的维生素K吸收不良，25-60%的病例出现凝血异常[1]。

### 影像学检查

超声检查可能显示肝肿大、不均质的肝实质、胆管壁增厚、胆泥或并发胰腺炎[1]。然而，仅凭超声无法诊断胆管炎，有时可能看不到任何异常[1]。当超声检查结果不确定时，CT或MRI扫描等先进影像技术可提供额外的诊断信息[2]。

### 细胞学和组织病理学

细胞学检查可以识别并发的肝脂质沉积，革兰氏染色时可能显示细菌[1]。然而，肝细胞学无法诊断胆管肝炎，需要进行肝活检和组织病理学以明确诊断[1]。与手术活检相比，超声引导下活检的符合率约为50%[1]。

### 多模式诊断

最佳评估需要从多个肝叶获取肝活检样本，同时提交进行组织病理学检查以及细菌培养和抗菌药物敏感性测试[1]。建议进行胆囊穿刺术进行胆汁细胞学和培养，因为胆汁的培养阳性率通常高于肝组织[1]。细胞学涂片的结果可以指示细胞数量、细胞类型、是否存在肿瘤细胞以及是否存在细菌[2]。

### Sources

[1] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[2] Cytology - Clinical Pathology and Procedures: https://www.merckvetmanual.com/clinical-pathology-and-procedures/diagnostic-procedures-for-the-private-practice-laboratory/cytology

## 治疗选择

胆管炎的治疗因疾病类型而异，需要结合抗菌治疗、抗炎药物、支持性护理和在必要时进行手术干预的多模式管理[1]。

**抗菌治疗**
对于化脓性胆管炎，靶向革兰氏阴性菌和厌氧菌的广谱抗菌药物至关重要。联合甲硝唑（每12小时7.5 mg/kg）、恩诺沙星和氨苄西林-舒巴坦的三联抗生素方案提供了全面覆盖[1][2]。急性病例的治疗时间为2-4周，而伴有持续性细菌移位的慢性疾病则需要数月[2]。

**免疫抑制治疗**
非化脓性胆管炎需要使用泼尼松龙进行免疫调节，剂量为每日2-4 mg/kg，在6-12周内逐渐减量至隔日给药[1][3]。甲硝唑（每12小时7.5 mg/kg）有助于免疫调节，并可能减少糖皮质激素的剂量[1]。对于难治性病例或破坏性胆管炎，可能需要使用苯丁酸氮芥（每日2 mg/猫）或甲氨蝶呤（每周0.4 mg/猫，分三次给药）[1]。

**利胆药物**
熊去氧胆酸（每日10-15 mg/kg）可改善胆汁流动并减少胆汁酸毒性，但不应在破坏性胆管炎或完全性胆管梗阻时使用[1][2][6]。S-腺苷甲硫氨酸（每日40-50 mg/kg）和维生素E（每日10 U/kg）提供抗氧化支持[1][3]。

**手术干预**
对于伴有细菌感染的胆囊疾病，建议进行胆囊切除术[2][4]。对于肝外胆管梗阻，可能需要进行胆道减压，尽管与犬相比，猫进行胆道支架置入的发病率更高[4]。

### Sources

[1] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[2] Canine Cholangiohepatitis - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/canine-cholangiohepatitis
[3] Update on hepatoprotective therapies (Proceedings): https://www.dvm360.com/view/update-hepatoprotective-therapies-proceedings
[4] Cholecystitis in Small Animals - Digestive System: https://www.merckvetmanual.com/en-au/digestive-system/hepatic-disease-in-small-animals/cholecystitis-in-small-animals
[5] Management of chronic liver disease in dogs (Proceedings): https://www.dvm360.com/view/management-chronic-liver-disease-dogs-and-proceedings
[6] Pharmacological management of canine and feline liver disease (Proceedings): https://www.dvm360.com/view/pharmacological-management-canine-and-feline-liver-disease-proceedings

## 预防措施

预防猫胆管炎需要全面的风险因素管理和环境控制策略。当前的预防措施应强调对并存疾病的管理，因为炎症性肠病和胰腺炎与中性粒细胞性和淋巴细胞性胆管炎密切相关[4]。胆管炎、胰腺炎和炎症性肠病同时发生，称为“三体炎”，这凸显了综合胃肠道健康管理的重要性。

对于寄生虫性胆管炎，环境控制侧重于通过限制接触中间宿主（如爬行动物和两栖动物）来预防肝吸虫感染，特别是在流行地区[1][2]。定期粪便检查对于通过直接检查和常规筛查方案早期发现吸虫感染仍然至关重要。

饮食管理通过高度易消化、适度限制脂肪的配方支持整体肝胆健康，特别是对于伴有炎症性疾病的患者[2]。适当的营养有助于维持免疫功能，同时减少受损器官系统的代谢压力。

对高危患者的监测方案应包括常规评估肝脏酶活性，特别是碱性磷酸酶和γ-谷氨酰转移酶[3]。这些淤胆性酶会随着胆道疾病而增加，从而能够在临床症状出现之前进行早期干预。定期血液检查有助于在出现异常时及时做出治疗反应。

### Sources
[1] Hepatobiliary diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/hepatobiliary-diseases-dogs-and-cats-proceedings
[2] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease
[3] Inflammatory liver disease in the cat (Proceedings): https://www.dvm360.com/view/inflammatory-liver-disease-cat-proceedings-0
[4] Feline Cholangitis / Cholangiohepatitis Syndrome - Digestive System: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome

## 鉴别诊断

胆管炎的主要鉴别诊断包括肝脂质沉积症、慢性肝炎、肿瘤和肝外胆管梗阻[1]。肝脂质沉积症的特征是细胞学上>80%的肝细胞显示空泡状脂质扩张，常见于过度肥胖且厌食的猫[4]。慢性肝炎通常缺乏胆管炎特有的导管周围炎性浸润[1]。

肿瘤性疾病，特别是胆管腺癌和肝淋巴瘤，需要通过组织病理学与炎症过程进行鉴别[2][5]。胆管腺癌是猫最常见的原发性恶性肝肿瘤，其临床表现可能与胆管肝炎相似[5]。肝外胆管梗阻在4小时内引起快速发作的黄疸和显著的淤胆性酶升高，这与胆管炎更多变的表现形成对比[8]。

中性粒细胞性和淋巴细胞性胆管炎形式之间的关键鉴别特征包括发病年龄、病程和炎症细胞类型[2]。中性粒细胞性胆管炎通常影响伴有急性体征（<5天）、发热和中性粒细胞增多的年轻猫，通常与细菌感染相关[2]。淋巴细胞性胆管炎主要发生于中老年猫，伴有慢性疾病（数周至数月），白细胞计数多变，需要组织病理学确认[2]。

必须考虑并存疾病，因为猫三体炎（胆管肝炎、胰腺炎和肠炎）经常同时发生[6]。GGT-ALP关系有助于鉴别潜在的导管病理，GGT活性显著升高表明包括胰腺炎在内的导管结构受累[4]。

### Sources
[1] Canine Cholangiohepatitis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/canine-cholangiohepatitis
[2] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[3] Liver disease and treatment in dogs and cats (Proceedings): https://www.dvm360.com/view/liver-disease-and-treatment-dogs-and-cats-proceedings
[4] Feline Hepatic Lipidosis: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-hepatic-lipidosis
[5] Hepatic Neoplasia in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-disease-in-small-animals/hepatic-neoplasia-in-small-animals
[6] The icteric cat: diagnosis and treatment of common feline hepatopathies: https://www.dvm360.com/view/the-icteric-cat-diagnosis-and-treatment-of-common-feline-hepatopathies
[7] Clinical features, concurrent disorders, and survival time: https://avmajournals.avma.org/downloadpdf/view/journals/javma/260/2/javma.20.10.0555.pdf
[8] Extrahepatic Bile Duct Obstruction in Small Animals: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/extrahepatic-bile-duct-obstruction-in-small-animals

## 预后

猫胆管炎的预后因疾病的形式和严重程度而有显著差异[1]。据报道，患有急性和慢性胆管炎的猫的平均存活时间为29个月[1]。然而，在一项涉及16个病例的回顾性研究中，平均存活时间为29.3个月，但超过一半的病例存在影响预后的严重并存疾病[4]。

急性中性粒细胞性胆管炎通常预后良好，许多猫在及时治疗后能够完全康复[1][2]。一些病例尽管接受了适当治疗，仍可能发展为慢性形式。慢性中性粒细胞性胆管炎的预后变化较大，患者可能需要长期药物治疗，有些会发展为终末期肝硬化[1]。

淋巴细胞性胆管炎由于其进行性性质和对免疫抑制治疗反应不佳，预后谨慎[1][2]。患有并发胰腺炎或炎症性肠病（三体炎）的猫可能面临影响康复的额外并发症[1]。

患有破坏性胆管炎（硬化性胆管炎）的非化脓性胆管炎猫最终可能发展为广泛的小胆管破坏，导致永久性高胆红素血症和间歇性白陶土样粪便[3]。早期诊断和积极治疗可显著改善预后。凝血病、细菌感染和肝性脑病等继发性并发症会使预后恶化，需要及时处理[4]。

### Sources

[1] Feline liver disease (Proceedings): https://www.dvm360.com/view/feline-liver-disease-proceedings
[2] Inflammatory liver disease in the cat (Proceedings): https://www.dvm360.com/view/inflammatory-liver-disease-cat-proceedings-0
[3] Feline Cholangitis / Cholangiohepatitis Syndrome: https://www.merckvetmanual.com/digestive-system/hepatic-diseases-of-small-animals/feline-cholangitis-cholangiohepatitis-syndrome
[4] Identifying and helping cats with inflammatory hepatobiliary disease: https://www.dvm360.com/view/identifying-and-helping-cats-with-inflammatory-hepatobiliary-disease