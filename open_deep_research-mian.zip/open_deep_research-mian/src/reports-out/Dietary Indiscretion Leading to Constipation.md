# 饮食不当导致伴侣动物便秘

饮食不当是犬猫便秘最常见的原因之一，发生在宠物摄入不适当物品扰乱正常消化功能时。这种情况影响所有年龄段的动物，但在年幼、好奇心强的宠物和有觅食行为倾向的品种中尤为普遍。本报告检查了从简单里急后重到严重便秘的临床表现，包括体格检查和影像学检查的诊断方法，以及从药物治疗到手术干预的综合治疗策略。通过环境控制和主人教育进行预防仍然至关重要，因为没有适当管理，复发率可能很高。了解鉴别诊断和预后因素使兽医能够为受影响的伴侣动物提供最佳护理并预防并发症。

## 疾病概述

饮食不当导致的便秘是伴侣动物中常见的胃肠道疾病，其中不适当的食物摄入扰乱了正常的肠道功能。便秘被定义为排便困难，特征是不完全或很少排出硬便[1]。这种情况包括多种情况，如摄入不适当物品、暴食、食用餐桌残渣或食用垃圾和异物，随后干扰正常消化过程[2]。

饮食不当常被确定为幼年动物慢性胃肠道疾病的主要原因，与寄生虫病和先天性疾病并列[2]。这种情况通常是由于宠物摄入常规饮食以外的物品引起的，包括骨头、织物、植物材料或其他难以消化的物质，这些物质会在消化道中积聚并阻碍正常粪便排出。

从流行病学角度看，饮食不当影响所有年龄段的犬猫，尽管年幼动物由于其探索行为和不加选择的饮食习惯可能更容易受到影响[2]。饮食不当本身没有特定的品种易感性，但某些品种可能更容易出现觅食行为。自由活动或能接触垃圾的犬风险增加[3]。在节假日期间，当宠物更容易获得不寻常食物时，患病率特别高。由消化不良物质与粪便物质混合引起的腔内梗阻是最常见的机制，通常继发于水分摄入不足或排便困难[6]。

### Sources
[1] Glossary: https://www.merckvetmanual.com/resourcespages/glossary
[2] Difficult canine vomiting cases (Proceedings): https://www.dvm360.com/view/difficult-canine-vomiting-cases-proceedings
[3] Dietary management of GI diseases in dogs and cats (Proceedings): https://www.dvm360.com/view/dietary-management-gi-diseases-dogs-and-cats-proceedings
[4] Merck Veterinary Manual Constipation, Obstipation, and Megacolon in Small Animals: https://merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/constipation-and-obstipation-in-small-animals

## 常见病原体

虽然饮食不当导致的便秘主要是机械性和消化系统疾病而非传染病，但慢性粪便嵌塞和肠道停滞可引起继发性细菌并发症。小肠细菌过度生长（SIBO）是便秘犬猫中最显著的继发性病原体相关并发症[1]。

当粪便物质在结肠中长时间保持静止状态时，正常肠道菌群可能异常增殖，导致细菌过度生长[1]。这种情况的特征是受影响动物血清叶酸浓度升高，钴胺素水平降低[2]。改变的细菌群体可产生炎症介质和毒素，加重胃肠道功能障碍。

继发性细菌过度生长可由任何慢性肠道炎症或运动障碍引起[3]。在严重情况下，正常肠道细菌可能进入受损的肠道组织和血液，可能导致全身性并发症[1]。在患有慢性便秘的免疫功能低下动物中，肠杆菌科的机会性病原革兰氏阴性菌和铜绿假单胞菌可能成为问题[4]。

治疗通常包括抗生素如泰乐菌素或甲硝唑来控制细菌过度生长[2][3]。然而，这些细菌并发症是继发性影响，而非饮食不当相关便秘的主要原因。

### Sources

[1] Disorders of the Stomach and Intestines in Dogs: https://www.merckvetmanual.com/en/dog-owners/digestive-disorders-of-dogs/disorders-of-the-stomach-and-intestines-in-dogs

[2] Iams Nutrition Insider for the Veterinary Team: https://www.dvm360.com/view/iams-nutrition-insider-veterinary-team-comparing-prebiotics-and-antibiotics-treating-sibo-dogs-spons

[3] Inflammatory bowel disease (Proceedings): https://www.dvm360.com/view/inflammatory-bowel-disease-proceedings

[4] Chinchillas - Exotic and Laboratory Animals: https://www.merckvetmanual.com/en-au/exotic-and-laboratory-animals/rodents/chinchillas

## 临床症状和体征

饮食不当引起的便秘的典型临床表现包括**里急后重和排出坚硬、干燥的粪便**[1]。体格检查显示腹部触诊和直肠检查可触及结肠内滞留的粪便物质[1]。当粪便排出被肿块或增大的结构阻碍时，粪便可能呈细条或"带状"外观[1]。

受影响的动物通常表现出全身性症状，包括嗜睡、抑郁、厌食、呕吐（尤其是猫）和腹部不适[1]。排出的粪便特征性地具有恶臭[1]。临床症状的严重程度与粪便嵌塞程度相关，有些动物看起来相当病重，而其他动物则保持相对正常的状态[1]。

**存在品种易感性**，特别是在结肠肌肉收缩不良的老年超重猫、经历慢性脱水的慢性肾病猫以及有过往便秘发作史的猫中[1]。有饮食不当史的犬，特别是"什么都吃的傻拉布拉多犬"，通常因异物相关便秘就诊[2]。

病史因素包括最近摄入难以消化的物质（毛发、骨头、猫砂），这些物质增加粪便体积或在排便时引起疼痛[1]。由于压力、脏污的猫砂盒或疼痛导致的排便 reluctance 促成症状发展[1]。有些动物可能表现出经典的"祈祷"姿势，后躯抬高，胸部降低，以缓解前腹部不适[3]。

### Sources

[1] Constipation, Obstipation, and Megacolon in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/constipation-obstipation-and-megacolon-in-small-animals

[2] Difficult canine vomiting cases (Proceedings): https://www.dvm360.com/view/difficult-canine-vomiting-cases-proceedings

[3] Gastritis in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/gastritis-in-small-animals

## 诊断方法

饮食不当引起便秘的诊断方法需要使用临床、实验室和影像学方式进行综合评估，以确认诊断并评估严重程度[1]。多种诊断工具协同工作，将这种情况与其他便秘原因区分开来。

**临床评估**：详细的病史记录仍然是基础，记录最近的摄入事件、便秘持续时间和影响因素[1]。体格检查包括腹部触诊以识别滞留的粪便物质和直肠检查以确认嵌塞的粪便，同时排除肿块或异物[1]。临床表现结合饮食不当史为诊断提供有力支持。

**实验室检测**：全血细胞计数可能揭示与脱水相关的变化，包括红细胞增多、血浆蛋白增加和白细胞减少[1]。血清生化谱有助于识别全身性原因，血清T4水平在慢性病例中特别重要，以排除甲状腺功能减退症[1]。这些测试有助于排除代谢原因，同时评估水合状态。

**影像学检查**：腹部X线摄影是主要的诊断影像学工具，显示滞留粪便物质的分布和严重程度评估[1]。普通X线片可能显示摄入的骨头或其他导致嵌塞的物质[1]。钡剂灌肠等对比检查可在复杂病例中显示梗阻性病变[1]。腹部超声评估肠道壁完整性、蠕动，并排除穿孔等并发症[1]。

### Sources
[1] Merck Veterinary Manual Constipation, Obstipation, and Megacolon in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-stomach-and-intestines-in-small-animals/constipation-and-obstipation-in-small-animals

## 治疗选择

饮食不当引起的便秘治疗涉及多模式方法，包括药物和非药物干预，在严重情况下升级到手术选择。

**即时药物干预**包括使用温水（5-10 ml/kg）或多库酯钠（DSS）溶液灌肠[1]。泻药分为膨胀性（洋车前子、麦麸）、渗透性（乳果糖0.5 ml/kg每日2-3次、聚乙二醇）、润滑性（多库酯钠）或刺激性类型（比沙可啶）[2]。促动力药物如西沙必利（2.5-5 mg/猫每8-12小时）通过激活5-HT4受体增强结肠推进性运动[1][2]。

**非药物方法**优先考虑再水化作为治疗的基石，使用皮下或静脉注射等渗液体[3]。饮食调整包括高纤维饮食和添加洋车前子的配方，以及通过湿粮增加水分摄入[3]。环境管理确保干净、可及的猫砂盒和减轻压力[3]。

**手术考虑**在难治性病例中变得必要。在气管插管麻醉下进行手动解除嵌塞，以防呕吐时发生误吸[1][2]。次全结肠切除术保留给对药物治疗六个月无反应的不可逆巨结肠猫[2][5]。骨盆截骨术可能对骨盆骨折畸形愈合少于六个月的病例有益[5]。

### Sources
[1] Constipation in cats (Proceedings): https://www.dvm360.com/view/constipation-cats-proceedings
[2] Managing constipation in cats (Proceedings): https://www.dvm360.com/view/managing-constipation-cats-proceedings
[3] All bunged up: Unclogging the constipated cat: https://www.dvm360.com/view/all-bunged-unclogging-constipated-cat
[4] GI motility disorders (Proceedings): https://www.dvm360.com/view/gi-motility-disorders-proceedings
[5] Constipation, Obstipation, and Megacolon in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/constipation-obstipation-and-megacolon-in-small-animals

## 预防措施

**环境管理和安全通道控制**
实施环境改造对预防饮食不当至关重要[1]。安全的垃圾容器、抬高的食物储存区域和限制接触潜在饮食危险有效减少不适当摄入的机会。厨房台面应清除食物物品，户外区域必须定期检查异物或变质材料。

**结构化喂养方案和饮食指南**
建立一致的进餐时间表和份量控制有助于满足营养需求，同时减少觅食行为[1]。**新型蛋白质饮食**和**高纤维商品粮**可以改善胃肠道功能并减少饮食不当相关并发症的可能性。在饮食中补充**低聚果糖（FOSs）**促进有益结肠细菌并支持正常消化健康。

**行为修正和主人教育**
**反应替代**技术可将不适当的进食行为重定向到可接受的替代方案[2]。主人应学会识别饮食不当的早期预警信号，并使用正向强化实施一致的训练方案。**反条件作用和脱敏**方法有助于改变宠物对触发不当进食行为的食物刺激的反应。

关于物种适当营养、环境危险识别和应急反应方案的综合主人教育显著降低了伴侣动物中饮食不当导致便秘的发生率。

### Sources

[1] Colitis in Small Animals - Digestive System: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/colitis-in-small-animals

[2] Behavior Modification in Dogs - Dog Owners - Merck Veterinary Manual: https://www.merckvetmanual.com/dog-owners/behavior-of-dogs/behavior-modification-in-dogs

## 鉴别诊断

在评估伴侣动物便秘时，饮食不当必须与其他几个重要原因区分开来。**巨结肠**代表最重要的鉴别诊断，特征是大肠病理性运动功能减退和扩张[1]。与通常对饮食管理迅速反应的饮食不当不同，巨结肠表现为不可逆的结肠功能障碍，当药物治疗失败时需要手术干预[1]。

**骨盆创伤**伴骨折畸形愈合造成骨盆通道机械性梗阻，通过X线检查显示狭窄的骨盆入口和创伤史可与饮食原因区分开来[2]。体格检查显示可触及的骨盆异常，与饮食不当病例中正常的骨盆结构形成对比。

**神经系统疾病**表现出不同特征，包括异常神经系统检查结果，特别是尾部脊髓功能、肛门张力和会阴反射的缺陷[1]。曼岛猫骶脊髓畸形或自主神经功能障碍等疾病可能显示尿失禁或瞳孔扩大等并发症状，这些在单纯饮食不当中不存在。

**代谢疾病**需要通过实验室检测进行鉴别。甲状腺功能减退症可能表现出并发嗜睡和心动过缓[3]，而高钙血症和低钾血症在血清生化上显示特征性电解质异常[1]。这些全身性疾病通常表现出除便秘外的其他临床症状，不像饮食不当的孤立性胃肠道影响。

关键区别特征是饮食不当通常在肠道排空和饮食调整后迅速改善，而这些其他疾病需要针对其潜在病理生理学的特定靶向治疗[1]。

### Sources

[1] Constipation, Obstipation, and Megacolon in Small Animals: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/constipation-obstipation-and-megacolon-in-small-animals

[2] Feline megacolon: The hard facts (Proceedings): https://www.dvm360.com/view/feline-megacolon-hard-facts-proceedings

[3] What Is Your Diagnosis?: https://avmajournals.avma.org/view/journals/javma/260/5/javma.21.04.0175.xml

## 预后

犬猫中饮食不当引起的便秘在适当管理时预后通常良好[1]。大多数病例在移除问题饮食物质和实施支持性护理（包括饮食纠正和水合支持）后24-72小时内完全解决。

涉及饮食不当引起的腔内梗阻的简单病例通常对肠道排空和预防未来饮食不当反应良好[1]。恢复显著受便秘持续时间、动物整体健康状况和并发疾病（如慢性肾病或脱水）存在的影响。

虽然单纯饮食相关便秘具有极好的短期预后，但复发率可能中等到高，特别是在有觅食行为倾向或家庭喂养实践不一致的动物中[1]。长期成功很大程度上取决于主人对饮食管理建议和环境修改以防止接触不适当材料的依从性。

潜在并发症不常见，但可能包括慢性或严重病例进展为顽固性便秘、反复发作发展为巨结肠或继发性代谢紊乱[1]。当实施适当的预防措施时，大多数动物在康复后保持正常的消化功能和生活质量。

### Sources
[1] Constipation, Obstipation, and Megacolon in Small Animals - Digestive System - Merck Veterinary Manual: https://www.merckvetmanual.com/digestive-system/diseases-of-the-large-intestine-in-small-animals/constipation-obstipation-and-megacolon-in-small-animals