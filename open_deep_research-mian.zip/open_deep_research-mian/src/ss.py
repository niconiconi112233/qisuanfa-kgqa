#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import re
import sys
import argparse
import unicodedata as ud
from pathlib import Path

# 零宽/不可见字符（常见问题源）
ZERO_WIDTH = [
    "\u200b", "\u200c", "\u200d", "\ufeff",  # ZWSP/ZWNJ/ZWJ/BOM
    "\u2060", "\u180e", "\u202a", "\u202b", "\u202c", "\u202d", "\u202e"  # 控制类
]
ZW_RE = re.compile("|".join(map(re.escape, ZERO_WIDTH)))

# 典型“花体标点/符号” -> 朴素替换（保持可读，提升解析稳定性）
REPLACE_MAP = {
    "“": '"', "”": '"', "„": '"', "‟": '"', "″": '"', "＂": '"',
    "‘": "'", "’": "'", "‚": "'", "‛": "'", "′": "'", "＇": "'",
    "—": "-", "–": "-", "―": "-", "‐": "-", "-": "-", "‒": "-",
    "…": "...",
    "·": "·", "•": "-", "◦": "-", "●": "-",
    "\u00a0": " ",  # 不间断空格 -> 普通空格
    "\u202f": " ",  # 窄不间断空格
}

# Emoji/符号范围（保守移除，避免触发编码器/日志问题）
EMOJI_RE = re.compile(
    "[" +
    "\U0001F300-\U0001F6FF" +  # Misc symbols and pictographs
    "\U0001F700-\U0001F77F" +  # Alchemical
    "\U0001F780-\U0001F7FF" +
    "\U0001F800-\U0001F8FF" +
    "\U0001F900-\U0001F9FF" +
    "\U0001FA00-\U0001FAFF" +
    "\U00002700-\U000027BF" +  # Dingbats
    "\U00002600-\U000026FF" +  # Misc symbols
    "]+",
    flags=re.UNICODE
)

# 允许的基本换行压缩：最多保留 2 个连续空行
BLANKS_RE = re.compile(r"\n{3,}")

def normalize_text(s: str, to_ascii_safe: bool = False) -> str:
    # 1) 先做 Unicode 规范化（NFC：组合更自然）
    s = ud.normalize("NFC", s)

    # 2) 去掉 BOM/零宽/方向控制符
    s = ZW_RE.sub("", s)

    # 3) 替换花体标点/不间断空格
    for k, v in REPLACE_MAP.items():
        s = s.replace(k, v)

    # 4) 删除 Emoji/大部分装饰符号（保守）
    s = EMOJI_RE.sub("", s)

    # 5) Windows 换行 -> Unix 换行
    s = s.replace("\r\n", "\n").replace("\r", "\n")

    # 6) 压缩过长空行
    s = BLANKS_RE.sub("\n\n", s)

    # 7) 可选：尽量 ASCII 化（不建议中文内容使用；仅在你要最大兼容时开启）
    if to_ascii_safe:
        s = ud.normalize("NFKD", s)
        # 去掉音标/环绕（对拉丁语系有用；中文不受影响）
        s = "".join(ch for ch in s if not ud.combining(ch))
        # 依然保留中文；如果你要**完全** ASCII，可以再加一刀：保留基本可打印 ASCII
        s = "".join(ch if 32 <= ord(ch) <= 126 or ch == "\n" or ch == "\t" else " " for ch in s)

    # 8) 末尾保证换行
    if not s.endswith("\n"):
        s += "\n"
    return s

def should_skip(p: Path) -> bool:
    # 跳过 macOS 资源叉与隐藏文件
    name = p.name
    return name.startswith("._") or name.startswith(".")

def process_one(src: Path, dst: Path, ascii_mode: bool = False) -> None:
    # 尝试 utf-8 读取，失败则忽略非法字节（保最大保真）
    try:
        text = src.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        # 极端情况兜底
        raw = src.read_bytes()
        text = raw.decode("utf-8", errors="ignore")

    clean = normalize_text(text, to_ascii_safe=ascii_mode)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_text(clean, encoding="utf-8")

def main():
    ap = argparse.ArgumentParser(description="预处理 Markdown：统一 UTF-8、去零宽/Emoji/花体标点、压缩空行")
    ap.add_argument("--input_dir", required=True, help="原始 .md 文件目录")
    ap.add_argument("--output_dir", required=True, help="清洗后输出目录（将覆盖同名文件）")
    ap.add_argument("--ascii_safe", action="store_true",
                    help="开启后尽量 ASCII 化（不推荐中文内容，除非你要喂给只支持 ASCII 的下游）")
    args = ap.parse_args()

    in_dir = Path(args.input_dir)
    out_dir = Path(args.output_dir)

    if not in_dir.exists():
        print(f"[ERR] input_dir not found: {in_dir}", file=sys.stderr)
        sys.exit(1)

    md_files = sorted(list(in_dir.glob("*.md")))
    if not md_files:
        print(f"[WARN] no .md files in {in_dir}")
        return

    count = 0
    for p in md_files:
        if should_skip(p):
            continue
        rel = p.name  # 同名输出
        dst = out_dir / rel
        try:
            process_one(p, dst, ascii_mode=args.ascii_safe)
            count += 1
        except Exception as e:
            print(f"[ERR] failed: {p.name} reason={e}", file=sys.stderr)

    print(f"[OK] cleaned {count} files -> {out_dir}")

if __name__ == "__main__":
    main()
