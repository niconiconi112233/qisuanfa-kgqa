# #!/usr/bin/env python3
# # -*- coding: utf-8 -*-

# import argparse, json, logging, random, re
# from pathlib import Path
# from collections import defaultdict, Counter

# FENCE_RE = re.compile(r"```(?:json)?\s*(\{.*?\})\s*```", re.S | re.I)

# def try_load_json_from_text(txt: str):
#     # 1) fenced ```json``` block
#     m = FENCE_RE.search(txt)
#     if m:
#         block = m.group(1).strip()
#         try:
#             return json.loads(block)
#         except Exception:
#             pass
#     # 2) whole file as JSON
#     try:
#         return json.loads(txt)
#     except Exception:
#         pass
#     # 3) fallback: first '{' .. last '}'
#     s, e = txt.find("{"), txt.rfind("}")
#     if s != -1 and e != -1 and e > s:
#         cand = txt[s:e+1]
#         try:
#             return json.loads(cand)
#         except Exception:
#             pass
#     return None

# def get_first_value(list_of_objs):
#     if isinstance(list_of_objs, list) and list_of_objs:
#         v = list_of_objs[0].get("value") if isinstance(list_of_objs[0], dict) else None
#         if isinstance(v, str) and v.strip():
#             return v.strip()
#     return ""

# def normalize_key(s: str) -> str:
#     return re.sub(r"\s+", " ", (s or "").strip().lower())

# def collect_symptoms_from_file(fp: Path):
#     """Return list of (symptom_name, attrs_dict) for one file."""
#     try:
#         txt = fp.read_text(encoding="utf-8", errors="ignore")
#     except Exception as e:
#         logging.warning(f"Skip unreadable: {fp} ({e})")
#         return []

#     data = try_load_json_from_text(txt)
#     if not isinstance(data, dict):
#         return []

#     ents = data.get("entities")
#     if not isinstance(ents, dict):
#         return []

#     sym_list = ents.get("Symptom") or ents.get("symptom")
#     if not isinstance(sym_list, list):
#         return []

#     out = []
#     for sym in sym_list:
#         # 确保是 dict，且像你示例那样：每个字段是一个列表[{value, source_full}, ...]
#         if not isinstance(sym, dict):
#             continue
#         name = get_first_value(sym.get("description", []))
#         if not name:
#             # 如果没有 description，则无法作为同名键，跳过
#             continue
#         out.append((name, sym))
#     return out

# def pretty_attrs(attrs: dict) -> str:
#     """Pretty print the whole attributes dict (keep all keys, original lists intact)."""
#     # 直接美化 JSON，保持 {key: list[{value, source_full}]} 的结构
#     try:
#         return json.dumps(attrs, ensure_ascii=False, indent=2)
#     except Exception:
#         # 兜底：非标准对象时尽量转换成字符串
#         return str(attrs)

# def main():
#     ap = argparse.ArgumentParser(description="Show all attributes for same-named Symptom across files (10 examples).")
#     ap.add_argument("--dir", required=True, help="Directory containing KG .json/.md files")
#     ap.add_argument("--samples", type=int, default=10, help="How many symptom names (with ≥2 files) to print")
#     args = ap.parse_args()

#     logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")

#     base = Path(args.dir)
#     if not base.exists():
#         raise SystemExit(f"Not found: {base}")

#     files = sorted(list(base.glob("*.json")) + list(base.glob("*.md")))
#     if not files:
#         raise SystemExit("No .json or .md files found in the directory.")

#     # name_norm -> list of {name_raw, file, attrs (full dict)}
#     index = defaultdict(list)
#     total_mentions = 0

#     for fp in files:
#         items = collect_symptoms_from_file(fp)
#         for name, attrs in items:
#             index[normalize_key(name)].append({
#                 "name_raw": name,
#                 "file": fp.name,
#                 "attrs": attrs  # keep full
#             })
#             total_mentions += 1

#     logging.info(f"Files scanned: {len(files)} | Symptom mentions collected: {total_mentions} | Unique names: {len(index)}")

#     # 只保留出现在 >=2 个不同文件的症状
#     multi_file_names = []
#     for key_norm, recs in index.items():
#         files_set = {r["file"] for r in recs}
#         if len(files_set) >= 2:
#             multi_file_names.append(key_norm)

#     if not multi_file_names:
#         logging.info("No symptoms with the same name across multiple files.")
#         return

#     # 为了更有代表性，可以按“涉及文件数”排序后随机取样
#     multi_file_names.sort(key=lambda k: len({r["file"] for r in index[k]}), reverse=True)
#     random.shuffle(multi_file_names)
#     picks = multi_file_names[:args.samples]

#     for i, key_norm in enumerate(picks, 1):
#         recs = index[key_norm]
#         # 用第一个记录的原始名作为展示名
#         display_name = recs[0]["name_raw"]
#         print("="*80)
#         print(f"[{i}] Symptom name: {display_name}  (normalized: {key_norm})")
#         print(f"Appears in {len({r['file'] for r in recs})} files, {len(recs)} mentions.")
#         print("-"*80)
#         # 按文件分组展示，保证同一文件如果有多个相同症状条目，也全部展示
#         by_file = defaultdict(list)
#         for r in recs:
#             by_file[r["file"]].append(r)

#         for fname in sorted(by_file.keys()):
#             print(f"■ File: {fname}")
#             for j, r in enumerate(by_file[fname], 1):
#                 print(f"  — Occurrence #{j} attributes:")
#                 print(pretty_attrs(r["attrs"]))
#                 print()
#         print()

# if __name__ == "__main__":
#     main()
from zai import ZhipuAiClient

client = ZhipuAiClient(api_key="106350c189a5410cd95897207e4eafa2.Giu1p55HaVP6RCGu")  # TODO: 填你的 API Key

# Problem to solve (can be replaced with your own)
QUESTION = """	
	
If the equation $(5x+ \frac {5}{x})-|4x- \frac {4}{x}|=m$ has exactly four distinct real roots in $(0,+\infty)$, then the range of the real number $m$ is \_\_\_\_\_\_."""

# Fixed format instructions (to be included in the prompt to ensure the model follows the structure)
FORMAT_INSTRUCTION = """You are a strict mathematical reasoning model. Follow the exact format below:

<think>
- Provide your reasoning process and derivation steps, allowing multi-step thinking.
- Include key equations and intermediate conclusions when necessary, and finish with a consistency check (e.g., modulo check or substitution).
</think>

<answer>
\\boxed{final answer}
</answer>

Requirements:
1) Must contain both <think>...</think> and <answer>...</answer> blocks.
2) The <answer> block must contain only a single LaTeX \\boxed{...}, with no other words or punctuation.
3) If there are multiple solutions, separate them with commas inside the same \\boxed{...} (e.g., \\boxed{3,5,7}).
4) Complete the reasoning and verification in the <think> block before giving the <answer>."""


response = client.chat.completions.create(
    model="glm-z1-air",          # 智谱模型名；若用别的模型请替换
    messages=[
        {"role": "user", "content": FORMAT_INSTRUCTION},
        {"role": "user", "content": QUESTION}
    ],
    thinking={"type": "enabled"},   # 启用深度思考
    stream=True,                    # 流式输出
    max_tokens=8192,                # 视题目长度调整
    temperature=0.9,                # 高温以鼓励可解释推理
    top_p=0.9
)

# 实时打印
for chunk in response:
    if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end='')
