import os
import json

# === 配置 ===
input_dir = '/home/bmm-system/data/private/yangjianxin/qisuanfa/tripe_outputs_0707'  # ← 修改为你自己的目录
output_path = 'merged_graph.jsonl'

# === 初始化 ===
entities = []
relations = []
entity_id_counter = 0

# 添加 Disease 父节点
disease_parent_id = "ENT_DISEASE_ROOT"
entities.append({
    "id": disease_parent_id,
    "text": "Disease",
    "type": "Category"
})

# 遍历文件夹中的所有 .jsonl 文件（不去重，编号持续增长）
for filename in sorted(os.listdir(input_dir)):  # 排序确保编号稳定
    if filename.endswith('.jsonl'):
        filepath = os.path.join(input_dir, filename)
        print(f"📂 正在处理文件: {filename}")

        # 当前文件的实体映射（只影响当前文件内的关系）
        local_entity_text_to_id = {}

        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line)

                    # === 处理实体 ===
                    if data.get("type") == "entity":
                        ent_text = data.get("entity_text")
                        ent_type = data.get("entity_type")

                        if not isinstance(ent_text, str) or not isinstance(ent_type, str):
                            continue

                        ent_id = f"ENT_{entity_id_counter:06d}"
                        entity_id_counter += 1

                        # 添加实体
                        entities.append({
                            "id": ent_id,
                            "text": ent_text,
                            "type": ent_type,
                            "attr": data.get("attr", {}),
                            "reference": data.get("reference", "")
                        })

                        # 加入当前文件实体映射
                        local_entity_text_to_id[ent_text] = ent_id

                        # 如果是 Disease，添加 Contain 关系
                        if ent_type == "Disease":
                            relations.append({
                                "type": "relation",
                                "head": disease_parent_id,
                                "relation": "Contain",
                                "tail": ent_id
                            })

                    # === 处理关系 ===
                    elif data.get("type") == "relation":
                        head = data.get("head")
                        tail = data.get("tail")
                        relation = data.get("relation_type")

                        if not all([isinstance(head, str), isinstance(tail, str), isinstance(relation, str)]):
                            continue

                        head_id = local_entity_text_to_id.get(head)
                        tail_id = local_entity_text_to_id.get(tail)

                        if head_id and tail_id:
                            relations.append({
                                "type": "relation",
                                "head": head_id,
                                "relation": relation,
                                "tail": tail_id
                            })

                except json.JSONDecodeError:
                    print(f"⚠️ 跳过格式错误的行：{line[:50]}")
                    continue

# === 写入输出 JSONL 文件 ===
with open(output_path, 'w', encoding='utf-8') as out_f:
    for ent in entities:
        out_f.write(json.dumps({"type": "entity", **ent}, ensure_ascii=False) + '\n')
    for rel in relations:
        out_f.write(json.dumps(rel, ensure_ascii=False) + '\n')

print(f"\n✅ 构建完成，实体总数：{len(entities)}，关系总数：{len(relations)}")
print(f"📄 输出文件保存于：{output_path}")
