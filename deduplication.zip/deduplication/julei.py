import os
import json
import numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer, util

# === 配置路径 ===
definition_dir = Path("category_definitions")
embedding_model_path = "/home/bmm-system/data/private/yangjianxin/qisuanfa/models/bge-large-en-v1.5/BAAI/bge-large-en-v1.5"
output_cluster_dir = Path("clusters_softmerge")
output_cluster_dir.mkdir(exist_ok=True)

# === 加载嵌入模型 ===
embedding_model = SentenceTransformer(embedding_model_path)

# === 聚类逻辑 ===
def soft_cluster(definition_strings, sim_threshold=0.87):
    embeddings = embedding_model.encode(definition_strings, normalize_embeddings=True)
    sim_matrix = util.cos_sim(embeddings, embeddings).numpy()

    n = len(definition_strings)
    parent = list(range(n))  # 并查集结构

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    def union(i, j):
        pi, pj = find(i), find(j)
        if pi != pj:
            parent[pj] = pi

    for i in range(n):
        for j in range(i + 1, n):
            if sim_matrix[i][j] >= sim_threshold:
                union(i, j)

    clusters = {}
    for idx in range(n):
        root = find(idx)
        clusters.setdefault(root, []).append(idx)  # 保存索引

    return clusters

# === 主处理流程 ===
for file in definition_dir.glob("*_definitions.jsonl"):
    category = file.stem.replace("_definitions", "")
    print(f"\n🔍 正在处理类别: {category}")

    entries = []
    definition_strings = []

    with open(file, "r", encoding="utf-8") as f:
        for line in f:
            item = json.loads(line)
            text = item.get("text", "").strip()
            definition = item.get("definition", "").strip()
            if text and definition:
                full_text = f"{text}: {definition}"
                entries.append({
                    "id": item.get("id"),
                    "text": text,
                    "definition": definition,
                    "category": category,
                    "combined": full_text
                })
                definition_strings.append(full_text)

    if len(entries) < 2:
        print(f"⚠️ 实体数不足，跳过: {category}")
        continue

    # === 聚类 ===
    index_clusters = soft_cluster(definition_strings, sim_threshold=0.85)

    # === 构造输出聚类结果 ===
    final_clusters = {}
    for cid, indices in index_clusters.items():
        final_clusters[f"cluster_{cid}"] = [entries[i] for i in indices]

    # === 保存为 JSON 文件 ===
    output_path = output_cluster_dir / f"clusters_{category}.json"
    with open(output_path, "w", encoding="utf-8") as out_f:
        json.dump(final_clusters, out_f, ensure_ascii=False, indent=2)

    print(f"✅ 聚类完成，共 {len(final_clusters)} 个簇 --> {output_path}")
