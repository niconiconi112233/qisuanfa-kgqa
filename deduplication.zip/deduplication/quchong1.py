import json

input_path = '/home/bmm-system/data/private/yangjianxin/qisuanfa/merged_graph.jsonl'
output_path = 'merged_graph_dedup_by_type.jsonl'

original_entities = []
relations = []

# === 读取实体和关系 ===
with open(input_path, 'r', encoding='utf-8') as f:
    for line in f:
        try:
            item = json.loads(line)

            # 只要不是 relation 都是实体（type 是实体类型）
            if item.get("type") != "relation":
                original_entities.append(item)
            else:
                relations.append(item)
        except json.JSONDecodeError:
            print("⚠️ 跳过格式错误行")
            continue

# === 去重实体（按小写text + 类型）===
deduped_entities = {}           # key: (text_lower, type) → entity
text_type_to_id = {}            # key: (text_lower, type) → entity_id
old_id_to_new_id = {}           # old_id → dedup_id

for entity in original_entities:
    text_key = entity["text"].strip().lower()
    entity_type = entity.get("type")
    key = (text_key, entity_type)

    if key not in deduped_entities:
        deduped_entities[key] = entity         # 保留第一次出现的
        text_type_to_id[key] = entity["id"]

    # 不管是第几次，都建立映射
    old_id_to_new_id[entity["id"]] = text_type_to_id[key]

# === 更新关系表 ===
updated_relations = []
for rel in relations:
    head = rel.get("head")
    tail = rel.get("tail")
    relation = rel.get("relation")

    if head in old_id_to_new_id and tail in old_id_to_new_id:
        updated_relations.append({
            "type": "relation",
            "head": old_id_to_new_id[head],
            "relation": relation,
            "tail": old_id_to_new_id[tail]
        })

# === 写入新文件 ===
with open(output_path, 'w', encoding='utf-8') as f:
    for ent in deduped_entities.values():
        f.write(json.dumps(ent, ensure_ascii=False) + '\n')
    for rel in updated_relations:
        f.write(json.dumps(rel, ensure_ascii=False) + '\n')

# === 总结 ===
print(f"✅ 按类型去重后实体数：{len(deduped_entities)}，关系数：{len(updated_relations)}")
print(f"📄 输出文件保存为：{output_path}")
