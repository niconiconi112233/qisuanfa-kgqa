import json
import os
from pathlib import Path
from collections import defaultdict

# === 参数配置 ===
input_file = Path("merged_graph_dedup_by_type.jsonl")  # 原始实体+关系数据文件
synonym_dir = Path("cluster_synonym_results")  # 同义词聚类输出目录
output_file = Path("full_data_deduplicated.jsonl")  # 最终输出路径

# === 1. 加载所有同义词聚类结果（构建 ID 映射）
def load_synonym_mapping(synonym_dir: Path):
    id_map = {}
    for file in synonym_dir.glob("synonyms_*.json"):
        with open(file, "r", encoding="utf-8") as f:
            clusters = json.load(f)
        for cluster in clusters:
            synonym_list = cluster.get("synonyms", [])
            if len(synonym_list) < 2:
                continue
            main_id = synonym_list[0]["id"]
            for item in synonym_list:
                id_map[item["id"]] = main_id
    return id_map

# === 2. 处理实体与关系
def deduplicate_entities_and_relations(input_file, id_map, output_file):
    seen_entities = {}
    final_output = []

    with open(input_file, "r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)

            if obj["type"] == "relation":
                obj["head"] = id_map.get(obj["head"], obj["head"])
                obj["tail"] = id_map.get(obj["tail"], obj["tail"])
                final_output.append(obj)

            else:  # 实体类型
                eid = obj["id"]
                mapped_id = id_map.get(eid, eid)
                if mapped_id not in seen_entities:
                    obj["id"] = mapped_id
                    seen_entities[mapped_id] = obj
                # 否则为同义词 → 跳过重复实体

    for ent in seen_entities.values():
        final_output.append(ent)

    with open(output_file, "w", encoding="utf-8") as out_f:
        for item in final_output:
            out_f.write(json.dumps(item, ensure_ascii=False) + "\n")

    print(f"✅ 去重完成！输出文件: {output_file}")
    print(f"🔢 实体保留数: {len(seen_entities)}, 关系数: {sum(1 for x in final_output if x['type']=='relation')}")

# === 主流程 ===
if __name__ == "__main__":
    id_mapping = load_synonym_mapping(synonym_dir)
    deduplicate_entities_and_relations(input_file, id_mapping, output_file)
