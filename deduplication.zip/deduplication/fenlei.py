import os
import json
from collections import defaultdict

# === 配置 ===
input_path = 'merged_graph_dedup_by_type.jsonl'
output_base_dir = 'entities_by_category_split'
os.makedirs(output_base_dir, exist_ok=True)

# === 加载实体并按类型分组 ===
entity_by_type = defaultdict(list)

with open(input_path, 'r', encoding='utf-8') as f:
    for line in f:
        try:
            item = json.loads(line)
            if item.get("type") == "relation":
                continue  # 跳过关系
            entity_type = item.get("type")
            entity_text = item.get("text")
            entity_id = item.get("id")

            if entity_type and entity_text and entity_id:
                entity_by_type[entity_type].append((entity_id, entity_text))

        except json.JSONDecodeError:
            print(f"⚠️ 跳过格式错误行")
            continue

# === 写入不同文件夹，每类实体十个一组 ===
for entity_type, entity_list in entity_by_type.items():
    safe_type = entity_type.replace(" ", "_")
    type_dir = os.path.join(output_base_dir, safe_type)
    os.makedirs(type_dir, exist_ok=True)

    for i in range(0, len(entity_list), 10):
        chunk = entity_list[i:i+10]
        file_index = i // 10 + 1
        file_path = os.path.join(type_dir, f'{safe_type}_{file_index:03d}.txt')
        with open(file_path, 'w', encoding='utf-8') as f:
            for eid, text in chunk:
                f.write(f"{eid}\t{text}\n")

print(f"✅ 按类别拆分完成，输出目录：{output_base_dir}")
